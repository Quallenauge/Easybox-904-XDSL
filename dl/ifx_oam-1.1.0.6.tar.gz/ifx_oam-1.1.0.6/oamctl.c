/******************************************************************************

                               Copyright (c) 2010
                            Lantiq Deutschland GmbH
                     Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>

#include "oam.h"
#include "oam_api.h"

void f5_usage(char *str)
{
	printf("To config F5\n");
	printf("        %s --f5 options\n", str);
	printf("    avaliable options:\n");
	printf("        --vpi value                    which vpi to be used\n");
	printf("        --vci value                    which vci to be used\n");
	printf("        --scope 0|1                    set scope, 0: end-to-end, 1: seg-to-seg\n");
	printf("        --continuity-check 1|2|3       enable continuity check and set direction, 1: sink, 2: source, 3:both\n");
	printf("        --no-continuity-check 1|2|3    disable continuity check of direction, 1: sink, 2: source, 3:both\n");
	printf("        --loopback [value]             enable loopback and set frequency, 5-64K msec, default 600\n");
	printf("        --no-loopback [value]          disable loopback of frequency, 5-64K second\n");
	printf("        --num-of-pings [value]         specify number of loopback cells to be sent\n");
	printf("        --cell-cnt 0|1                 cell counters, 0: get, 1: reset\n");
	printf("        --timer-set 0|1                set FSM timers, 0: default, 1: user\n");
	printf("        --ais-not-rx [value]           recovery AIS timer\n");
	printf("        --ais-persist [value]          failure alarm AIS timer\n");
	printf("        --rdi-not-rx [value]           recovery RDI timer\n");
	printf("        --rdi-persist [value]          failure alarm RDI timer\n");
	printf("        --cc-sink-down [value]         link down CC timer\n");
	return;
}

void f4_usage(char *str)
{
	printf("To config F4\n");
	printf("        %s --f4 options\n", str);
	printf("    avaliable options:\n");
	printf("        --vpi value                    which vpi to be used\n");
	printf("        --scope 0|1                    set scope, 0: end-to-end, 1: seg-to-seg\n");
	printf("        --continuity-check 1|2|3       enable continuity check and set direction, 1: sink, 2: source, 3:both\n");
	printf("        --no-continuity-check 1|2|3    disable continuity check of direction, 1: sink, 2: source, 3:both\n");
	printf("        --loopback [value]             enable loopback and set frequency, 5-64K msec, default 600\n");
	printf("        --no-loopback [value]          disable loopback of frequency, 5-64K second\n");
	printf("        --num-of-pings [value]         specify number of loopback cells to be sent\n");
	printf("        --cell-cnt 0|1                 cell counters, 0: get, 1: reset\n");
	printf("        --timer-set 0|1                set FSM timers, 0: default, 1: user\n");
	printf("        --ais-not-rx [value]           recovery AIS timer\n");
	printf("        --ais-persist [value]          failure alarm AIS timer\n");
	printf("        --rdi-not-rx [value]           recovery RDI timer\n");
	printf("        --rdi-persist [value]          failure alarm RDI timer\n");
	printf("        --cc-sink-down [value]         link down CC timer\n");
	return;
}

int main(int argc, char **argv)
{
   int ret = 0;
	int c;
	int option_index = 0;
	static int ena_f4 = 0, ena_f5 = 0;
	int vpi=0, vci=0;
	int scope = 0;		/* E-T-E:0, SEG-T-SEG:1 */
   int cell_cnt_op = -1, timer_op = -1;
	int cc_status = 0;	/* 1: enable, 2: disable */
	int lb_status = 0;	/* 1: enable, 2: disable */
	int freq = 0, nping = 0;
	int direction = 0;
   oam_fsm_timer_cfg_t timer_cfg = {-1, -1, -1, -1, -1};

	static struct option long_options[] =
	{
		{"f4", no_argument, &ena_f4, 1},
		{"f5", no_argument, &ena_f5, 1},
		{"vpi", required_argument, 0, '1'},
		{"vci", required_argument, 0, '2'},
		{"scope", required_argument, 0, '3'},
		{"continuity-check", required_argument, 0, '4'},
		{"no-continuity-check", required_argument, 0, '5'},
		{"loopback", required_argument, 0, '6'},
		{"no-loopback", required_argument, 0, '7'},
		{"num-of-pings", required_argument, 0, '8'},
		{"cell-cnt", required_argument, 0, '9'},
		{"timer-set", required_argument, 0, 'a'},
		{"ais-not-rx", required_argument, 0, 'b'},
		{"ais-persist", required_argument, 0, 'c'},
		{"rdi-not-rx", required_argument, 0, 'd'},
		{"rdi-persist", required_argument, 0, 'e'},
		{"cc-sink-down", required_argument, 0, 'f'},
		{NULL, 0, 0, 0}
	};

	if (argc > 1)
	{
		while ((c = getopt_long(argc, argv,"1:2:3:4:5", long_options, &option_index)) != EOF)
		{
			switch(c) {
			case 0:
				/* tc.chen  2005/07/27 remove debug message
				printf("option %s", long_options[option_index].name);
				if (optarg)
					printf(" with arg %s", optarg);
				printf("\n");
				*/
				break;
			case '1':
				vpi = atoi(optarg);
				break;
			case '2':
				vci = atoi(optarg);
				break;
			case '3':
				scope = atoi(optarg);
				if ((scope != 0) && (scope != 1))
					goto ERR_RET;
				break;
			case '4':
				cc_status = 1;
				direction = atoi(optarg);
				if ((direction < 1) || (direction > 3))
					goto ERR_RET;
				break;
			case '5':
				cc_status = 2;
				direction = atoi(optarg);
				if ((direction < 1) || (direction > 3))
					goto ERR_RET;
				break;
			case '6':
				lb_status = 1;
				freq = atoi(optarg);
				if (nping)
					break;
				else {
			  		if ((freq < 6) || (freq > 65535))
						 goto ERR_RET;
				}
				break;
			case '7':
				lb_status = 2;
				freq = atoi(optarg);
				if ((freq < 6) || (freq > 65535))
					goto ERR_RET;
				break;
			case '8':
				if (lb_status != 1)
               goto ERR_RET;

            nping = atoi(optarg);

            if (nping <= 0) {
               printf("Incorrect num-of-pings=%d, setting default to 5\n",nping);
               nping = 5;
            }
            break;
         case '9':
				cell_cnt_op = atoi(optarg);
				if ((cell_cnt_op != 0) && (cell_cnt_op != 1))
					goto ERR_RET;
            break;
         case 'a':
				timer_op = atoi(optarg);
				if ((timer_op != 0) && (timer_op != 1))
					goto ERR_RET;
            break;
         /* FSM Timers*/
         case 'b':
            timer_cfg.oam_ais_not_rx = atoi(optarg);
            break;
         case 'c':
            timer_cfg.oam_ais_persist = atoi(optarg);
            break;
         case 'd':
            timer_cfg.oam_rdi_not_rx = atoi(optarg);
            break;
         case 'e':
            timer_cfg.oam_rdi_persist = atoi(optarg);
            break;
         case 'f':
            timer_cfg.oam_cc_sink = atoi(optarg);
            break;
			default:
				goto ERR_RET;
			}
		}

		if (ena_f4) {
			if (scope == 0)
				vci = 4;
			else
				vci = 3;
			ena_f5 = 0;
		}

		/*tc.chen 2005/07/27 printf("vpi=%d, vci=%d, scope=%d, direction=%d\n", vpi, vci, scope, direction);*/

      /* Handle Cell Counters*/
      if (cell_cnt_op == 0) {
         oam_cell_counters_t counters;

         ret = ifx_oam_cell_counters_get(
            (unsigned char) vpi, (unsigned short) vci, &counters);
         if (ret != 0) {
            printf("ERROR: cell counters get failed, vpi[%d], vci[%d]!\n",
               vpi, vci);
         }
         else {
            printf("Cell Counters for vpi[%d], vci[%d]: ", vpi, vci);
            printf("oam_lb_req_tx=%u oam_lb_reply_rx=%u oam_lb_req_rx=%u "
                   "oam_lb_reply_tx=%u oam_cc_req_tx=%u oam_cc_reply_rx=%u "
                   "oam_cc_req_rx=%u oam_cc_reply_tx=%u oam_ais_fail_count=%u "
                   "oam_ais_rx=%u oam_rdi_fail_count=%u oam_rdi_rx=%u\n",
                   counters.oam_lb_req_tx, counters.oam_lb_reply_rx, counters.oam_lb_req_rx,
                   counters.oam_lb_reply_tx, counters.oam_cc_req_tx, counters.oam_cc_reply_rx,
                   counters.oam_cc_req_rx, counters.oam_cc_reply_tx, counters.oam_ais_fail_count,
                   counters.oam_ais_rx, counters.oam_rdi_fail_count, counters.oam_rdi_rx);
         }
      }
      else if (cell_cnt_op == 1) {
         ret = ifx_oam_cell_counters_reset(
            (unsigned char) vpi, (unsigned short) vci);

         if (ret != 0) {
            printf("ERROR: cell counters reset failed, vpi[%d], vci[%d]!\n",
               vpi, vci);
         }
      }


      /* Handle FSM timers*/
      if (timer_op != -1) {
         if (timer_op == 0) {
            timer_cfg.oam_ais_not_rx  = OAM_RECOVERY_TIME;
            timer_cfg.oam_ais_persist = OAM_ALARM_TIME;
            timer_cfg.oam_rdi_not_rx  = OAM_RECOVERY_TIME;
            timer_cfg.oam_rdi_persist = OAM_ALARM_TIME;
            timer_cfg.oam_cc_sink = OAM_CC_SINK_DOWN_TIME;
         }

         ret = ifx_oam_fsm_timer_config_set(
                  (unsigned char) vpi,
                  (unsigned short) vci,
                  &timer_cfg);
         if (ret != 0) {
            printf("ERROR: FSM timers set failed, vpi[%d], vci[%d]!\n",
               vpi, vci);
         }
      }

		if (cc_status == 1)
			ifx_oam_enable_cc(vpi, vci, scope, direction);
		else if (cc_status == 2)
			ifx_oam_disable_cc(vpi, vci, scope, direction);

		if (lb_status == 1 && !nping)
			ifx_oam_enable_loopback(vpi, vci, scope, freq);
		else if (lb_status == 2)
			ifx_oam_disable_loopback(vpi, vci, scope, freq);

		if (lb_status == 1 && nping) {
         int num_cells_rx, max_resp_time, min_resp_time, avg_resp_time;

		   if (ena_f4) {
            if (ifx_oam_f4_ping(
                  vpi, scope, freq, nping,
                  &num_cells_rx, &max_resp_time, &min_resp_time, &avg_resp_time) != 0) {
               printf("ERROR: F4 Loopback Ping failed!\n");

               return -1;
            }
         }
         else {
            if (ifx_oam_f5_ping(
                  vpi, vci, scope, freq, nping,
                  &num_cells_rx, &max_resp_time, &min_resp_time, &avg_resp_time) != 0) {
               printf("ERROR: F5 Loopback Ping failed!\n");

               return -1;
            }
         }

         printf("Ping Statistics:\n");
         printf("     num_cells_tx : %d\n", nping);
         printf("     num_cells_rx : %d\n", num_cells_rx);
         printf("     min_resp_time: %d\n", min_resp_time);
         printf("     max_resp_time: %d\n", max_resp_time);
         printf("     avg_resp_time: %d\n", avg_resp_time);
      }

		return 0;
	}
ERR_RET:
	if (ena_f4 == 1)
		f4_usage(argv[0]);
	else if (ena_f5 == 1)
		f5_usage(argv[0]);
	else {
		f4_usage(argv[0]);
		f5_usage(argv[0]);
	}
	return -1;
}
