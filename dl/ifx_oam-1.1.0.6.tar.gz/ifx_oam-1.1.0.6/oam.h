/******************************************************************************

                               Copyright (c) 2010
                            Lantiq Deutschland GmbH
                     Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/

#ifndef _OAM_H
#define _OAM_H	1

#include <stdio.h>
#include <time.h>

#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <syslog.h>
#include "timer.h"
#include <asm/types.h>
#include <sys/socket.h>
#include <netinet/in.h> 
#include <linux/netlink.h> 
#include <semaphore.h>

#include "oam_api.h"

#define AMAZON_OAM 1
#define OAM_PING
#undef OAM_DEBUG
/*#define OAM_DEBUG*/
#ifdef OAM_DEBUG
    #define OAMPRINTF printf
    #define CCOAMPRINTF printf
#else
#define OAMPRINTF(args...) 
#define CCOAMPRINTF(args...) 
#endif

#if defined(INCLUDE_IFX_OAM_F5_LOOPBACK) || \
    defined(INCLUDE_IFX_OAM_F4_LOOPBACK)
#define INCLUDE_IFX_OAM_LOOPBACK
#endif /* #if defined(INCLUDE_IFX_OAM_F5_LOOPBACK) ||
              defined(INCLUDE_IFX_OAM_F4_LOOPBACK)*/

#if defined(INCLUDE_IFX_OAM_F5_LOOPBACK_PING) || \
    defined(INCLUDE_IFX_OAM_F4_LOOPBACK_PING)
#define INCLUDE_IFX_OAM_LOOPBACK_PING
#endif /* #if defined(INCLUDE_IFX_OAM_F5_LOOPBACK_PING) ||
              defined(INCLUDE_IFX_OAM_F4_LOOPBACK_PING)*/

#if !defined(INCLUDE_IFX_OAM_F5_LOOPBACK) && !defined(INCLUDE_IFX_OAM_F4_LOOPBACK) && \
    !defined(INCLUDE_IFX_OAM_AIS) && !defined(INCLUDE_IFX_OAM_RDI) && !defined(INCLUDE_IFX_OAM_CC)
#error "All OAM features are disabled, please check configuration!"
#endif

#define OAM_MAX_CONSEC_LB_FAILS    3

#define OAM_TRUE    1
#define OAM_FALSE   0
#define OAM_CELL_HEADER_SIZE       4
#define OAM_CELL_PAYLOAD_SIZE      52
#define OAM_CELL_HEADER_PT_OFFSET  3
#define ATM_CELL_PAYLOAD_SIZE      48
/* Offsets into cell*/

#define OAM_DRIVER_SOCKET 	"/home/test/sd"
#define OAM_USR_SOCKET 		"/home/test/rd"
#define OAM_TYPE_FN             (OAM_CELL_HEADER_SIZE+0)

#define OAM_LB_INDICATOR  	(OAM_TYPE_FN+1)
#define OAM_LB_CORR_TAG	        (OAM_TYPE_FN+2)
#define OAM_LB_LLID		(OAM_LB_CORR_TAG+4)
#define OAM_LB_SRCID		(OAM_LB_LLID+16)
#define OAM_LB_UNUSED		(OAM_LB_SRCID+16)

#define OAM_CC_FIELD 	 	(OAM_TYPE_FN+1)

#define OAM_CC_MSGID_AND_DIR       (OAM_TYPE_FN+1)

#define OAM_AIS_DEFECT_TYPE       (OAM_TYPE_FN+1)
#define OAM_AIS_DEFECT_LOC       (OAM_AIS_DEFECT_TYPE+1)
#define OAM_AIS_RESERV         (OAM_AIS_DEFECT_LOC +16)

#define OAM_LB_LLID_VAL		0xFF

#define OAM_OPTIONAL		   0x6A

/* Function and type definitions*/
#define OAM_ACTIVATION_CC       0x81
#define OAM_AIS                 0x10
#define OAM_RDI                 0x11
#define OAM_CC                  0x14
#define OAM_LB                  0x18

#define OAM_CC_CT2              0x3

/* Masks  values for various fields*/
#define OAM_MASK_MSGID          0xFC
#define OAM_MASK_DIR            0x03
#define OAM_MASK_DIR_AB         0x02     /*1*/
#define OAM_MASK_DIR_BA         0x01     /*2*/
#define OAM_LOOPBACK_REPLY_MASK 0x01
#define OAM_ACTIVATE_REQUEST            0x04
#define OAM_ACTIVATE_CONFIRMED          0x08
#define OAM_ACTIVATE_REQUEST_DENIED     0x0C
#define OAM_DEACTIVATE_REQUEST          0x14
#define OAM_DEACTIVATE_CONFIRMED        0x18
#define OAM_DEACTIVATE_REQUEST_DENIED   0x1C

/* oam state*/
#define OAM_NORMAL         0x00
#define OAM_AIS_FAILURE    0x01
#define OAM_RDI_FAILURE    0x01
#define OAM_AIS_DEFECT     0x02
#define OAM_RDI_DEFECT     0x02
#define OAM_LB_STATE       0x01

/* OAM timer values*/
#define OAM_FAILURE_TIME   350   /* 3.5*/
#define OAM_RECOVERY_TIME  250  /*TBD for testing 2.5*/
#define OAM_ALARM_TIME     350
#define OAM_CC_TX_TIME     100 
#define OAM_CC_TIME_1      500 
#define OAM_CC_TIME_3      500 
#define OAM_AIS_TX_TIME    100 

#define OAM_CC_SINK_DOWN_TIME 500


/* OAM cell types*/
#define OAM_NONE                0x00
#define OAM_F4_SEGMENT          0x01
#define OAM_F4_ENDTOEND         0x02
#define OAM_F5_SEGMENT          0x03
#define OAM_F5_ENDTOEND         0x04

#define OAM_ETE	0
#define OAM_SEG	1
#define OAM_F4	0
#define OAM_F5	1
#define ATM_CELL_REMOVE_GFC_MASK         	0x00FFFFFF


#define	ATM_GFC_AND_VPI 	0
#define	ATM_VPI_AND_VCI		1
#define	ATM_VCI			2
#define	ATM_VCI_AND_PTI		3
#define	ATM_HEC			4
/*macro*/

#define storeCRC10(CellPtr) \
{ \
	unsigned short OAMCRC10; \
	CellPtr[OAM_CRC10_0] = 0; \
	CellPtr[OAM_CRC10_1] = 0; \
	OAMCRC10 = calcCRC10((unsigned char *)(CellPtr+OAM_CELL_HEADER_SIZE), \
	ATM_CELL_PAYLOAD_SIZE); \
	CellPtr[OAM_CRC10_0] ^= (OAMCRC10 >> 8); \
	CellPtr[OAM_CRC10_1] ^= (OAMCRC10 & 0xFF); \
}

#if 0
unsigned long le32_to_cpu(unsigned long x)
{
	return (((x & 0x000000ffU) << 24) |
		((x & 0x0000ff00U) <<  8) |
		((x & 0x00ff0000U) >>  8) |
		((x & 0xff000000U) >> 24));
	}
#endif


#define MAKE_OAM_FILENAME(vpi, vci, file)	\
	sprintf((file), "/var/run/ping_%d_%d.oam", (vpi), (vci))

#define MAKE_OAM_STATS_FIFONAME(vpi, vci, fifo)	\
	sprintf((fifo), "/var/run/fifo_stats_%d_%d.oam", (vpi), (vci))

#define MAKE_OAM_CNT_FIFONAME(vpi, vci, fifo)	\
	sprintf((fifo), "/var/run/fifo_cnt_%d_%d.oam", (vpi), (vci))


typedef unsigned char           UINT8;
typedef unsigned short          UINT16;
typedef unsigned int            UINT32;
typedef unsigned long           UINT64;
typedef int            		     INT32;

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
#define OAM_DEFAULT_EVENT_SCRIPT   "oam_event.sh"

#define OAM_MAX_ENV_VAR_LENGTH     (40)

typedef struct OAM_EnvList
{
   struct OAM_EnvList *pNext;
   char *pEnvEntry;
} OAM_EnvList_t;
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/

#define OAM_LOCK_INIT_VALID(P_LOCK_ID)\
   (((P_LOCK_ID)) ? (((P_LOCK_ID)->bValid == OAM_TRUE) ? OAM_TRUE : OAM_FALSE) : OAM_FALSE)

/** LINUX User - LOCK, user space semaphore for synchronisation. */
typedef struct
{
   /** lock id */
   sem_t object;  
   /** valid flag */
   UINT8 bValid;
} OAM_Lock_t;


typedef struct
{
   int vpi;
   int vci;
   UINT32 num_cells_rx;
   UINT32 max_resp_time;
   UINT32 min_resp_time;
   UINT32 avg_resp_time;
} OAM_FIFO_MSG_STATS;

typedef struct
{
   UINT8  vpi;
   UINT16 vci;
   oam_cell_counters_t cnt;
} OAM_FIFO_MSG_COUNTERS;

typedef struct _oam_cell{
	UINT8 cell[52];
	UINT32 pid;
}OAM_CELL;

#define OAM_CELL_SIZE           sizeof(OAM_CELL)
#define OAM_CRC10_0             (OAM_CELL_PAYLOAD_SIZE-2)
#define OAM_CRC10_1             (OAM_CELL_PAYLOAD_SIZE-1)
#define OAM_FIRST_UNUSED_BYTE   (OAM_TYPE_FN+1)
#define OAM_LAST_UNUSED_BYTE    (OAM_CELL_SIZE-3)


#define get_vci(ns_rsqep) \
        ((((ns_rsqep)->vpi) & 0x0000FFFF) >> 4)
#define get_vpi(ns_rsqep) \
        ((((ns_rsqep)->vpi) & 0x00FF0000) >> 20)
#define get_pti(ns_rsqep) \
				        (((ns_rsqep)->vpi & 0x0000000F) >> 1)

struct amazon_atm_cell_header {
#ifdef CONFIG_CPU_LITTLE_ENDIAN
	struct{
		UINT32 clp  :1;	/* Cell Loss Priority*/
		UINT32 pti  :3;	/* Payload Type Identifier*/
		UINT32 vci 	:16;	/* Virtual Channel Identifier*/
		UINT32 vpi  :8;	/* Vitual Path Identifier*/
		UINT32 gfc  :4;	/* Generic Flow Control*/
   }bit;
#else
	struct{
		UINT32 gfc  :4;	/* Generic Flow Control*/
		UINT32 vpi  :8;	/* Vitual Path Identifier*/
		UINT32 vci  :16;	/* Virtual Channel Identifier*/
		UINT32 pti  :3;	/* Payload Type Identifier*/
		UINT32 clp  :1;	/* Cell Loss Priority*/
   }bit;
#endif
};

typedef struct _vpci *vpciPtr;

typedef struct _vpci {
	UINT8 vpi;
	UINT16 vci;
	UINT8 defect_type;
	UINT16 defect_loc;
	UINT16 rdi_ete_state : 2;
	UINT16 ais_ete_state:2;
	UINT16 rdi_seg_state:2;
	UINT16 ais_seg_state:2;
	UINT16 cc_ete_state:3;
	UINT16 cc_seg_state:3;
	UINT16 reserved:2;

	UINT8 cc_ete_direction:2;
	UINT8 cc_seg_direction:2;
	UINT8 lb_state : 2;
	UINT8 reserved1 : 2;

   UINT8   loopback_active[2];
   UINT8   cc_active[2];
	UINT16  lb_freq[2] ;
	UINT16  cc_ete_counter_1:3;
	UINT16  cc_seg_counter_1:3;
	UINT16  cc_ete_counter_2:3;
	UINT16  cc_seg_counter_2:3;
	UINT16  reserved3:4;
	UINT32  oam_corr_tag[2];
	timer_t lb_wait_timer[2];
	timer_t lb_tx_timer[2];
	timer_t cc_tx_timer[2];
	timer_t link_failure_alarm;
	timer_t ete_ais_recovery_timer;
   timer_t ete_ais_alarm_timer;
	timer_t ete_rdi_recovery_timer;
	timer_t ete_rdi_alarm_timer;
	timer_t seg_ais_recovery_timer;
   timer_t seg_ais_alarm_timer;
	timer_t seg_rdi_recovery_timer;
	timer_t seg_rdi_alarm_timer;
	timer_t cc_ete_timer_1;
	timer_t cc_ete_timer_3;
	timer_t cc_seg_timer_1;
	timer_t cc_seg_timer_3;
	vpciPtr next;     		/*points to the next entry */	
	vpciPtr vpcTable;     	/* Pointer to vci table, VCI willuse 
					       it to point to vpi table */
	UINT32  oam_pings; /* Number of OAM LB cells to Tx */
	UINT32  num_cells_rx;
	UINT32  max_resp_time;
	UINT32  min_resp_time;
	UINT32  avg_resp_time;
	UINT32  ping_freq;
	UINT32  ping_timeout;
   UINT8   ping_active;
   OAM_Lock_t tbl_lock;
   /* Specifies the number of consecutive LB fails*/
   UINT32  lb_consec_fail_cnt;

   oam_cell_counters_t cell_counters;

   oam_fsm_timer_cfg_t fsm_timer_cfg;
}VPCI;

enum ais_state{
	AIS_NORMAL =0,
	F4_ETE_AIS_DECLARE=1,
	F4_SEG_AIS_DECLARE=2,
	F5_ETE_AIS_DECLARE=4,
	F5_SEG_AIS_DECLARE=8,
};

enum rdi_state{
	RDI_NORMAL=0,
	F4_ETE_RDI_DECLARE=1,
	F4_SEG_RDI_DECLARE=2,
	F5_ETE_RDI_DECLARE=4,
	F5_SEG_RDI_DECLARE=8,

};

enum cc_state{
	CC_READY=0,
	CC_WAIT_ACT_CON,
	CC_WAIT_ACT_RES,
	CC_ACTIVE,
	CC_WAIT_DEACT_CON,
};

typedef enum cc_state cc_state_t;

enum cc_events {
	CC_NA=-1,
	CC_ACTIVATE=0,
	CC_ACT_CONF, 
	CC_ACTIVATION_DENIED,
	CC_DEACTIVATE,
	CC_DEACT_CONF 
};

typedef enum cc_events cc_events_t;

typedef struct _oam_stats{
	UINT32 oam_cell;
	UINT32 f4_ais_cell;
	UINT32 f4_rdi_cell;
	UINT32 f4_lb_cell;
	UINT32 f4_cc_cell;
	UINT32 f5_ais_cell;
	UINT32 f5_rdi_cell;
	UINT32 f5_lb_cell;
	UINT32 f5_cc_cell;
}oam_stats;


/* OAM function prototypes*/

void *oamd(void *);
int  infi_push_oam(UINT8 *cell, UINT32) ;
int create_socket(void) ;
void f4_ais_failure_alarm(unsigned long);
void f4_rdi_failure_alarm(unsigned long);
void f4_ete_ais_recovery_timer(unsigned long);
void f4_ete_ais_alarm_timer(unsigned long vpi);
void f4_ete_rdi_recovery_timer(unsigned long);
void f4_ete_rdi_alarm_timer(unsigned long vpi);
void f4_seg_ais_recovery_timer(unsigned long);
void f4_seg_ais_alarm_timer(unsigned long vpi);
void f4_seg_rdi_recovery_timer(unsigned long);
void f4_seg_rdi_alarm_timer(unsigned long vpi);
vpciPtr getVpciPtr(UINT32,UINT32);
void f5_ais_failure_alarm(unsigned long);
void f5_rdi_failure_alarm(unsigned long);
void f5_ete_ais_recovery_timer(unsigned long);
void f5_ete_ais_alarm_timer(unsigned long vpiVci);
void f5_ete_rdi_recovery_timer(unsigned long);
void f5_ete_rdi_alarm_timer(unsigned long vpiVci);
void f5_seg_ais_recovery_timer(unsigned long);
void f5_seg_ais_alarm_timer(unsigned long vpiVci);
void f5_seg_rdi_recovery_timer(unsigned long);
void f5_seg_rdi_alarm_timer(unsigned long vpiVci);
void tx_ete_cc(unsigned long pTable);
void tx_seg_cc(unsigned long pTable);
void cc_timer_ete_1(unsigned long pTable) ;
void cc_timer_ete_3(unsigned long pTable) ;
void cc_timer_seg_1(unsigned long pTable) ;
void cc_timer_seg_3(unsigned long pTable) ;
void send_loopback(unsigned long);
void process_loopback(vpciPtr pTable, OAM_CELL *pCell, UINT8 scope);
/*static UINT16 calcCRC10(UINT8* pData, UINT32 Size);*/
UINT16 checkCRC10(UINT8* pData);
void	create_header(OAM_CELL*,UINT32,UINT16,UINT32);
OAM_CELL* create_lb(UINT32 vpi, UINT16 vci, UINT32 pti,UINT32 corr_tag);
OAM_CELL* create_ais(UINT32 vpi, UINT16 vci, UINT32 pti);
OAM_CELL* create_rdi(UINT32 vpi, UINT16 vci, UINT32 pti);
OAM_CELL* create_cc(UINT32 vpi, UINT16 vci, UINT8 scope);
void activate_cc(VPCI *pTable, u_int8_t scope, OAM_CELL* pCell, u_int8_t eventId );
void send_cc_res(vpciPtr pTable, UINT8 scope, UINT8 action) ;

char  getEvent(UINT8 eventId);
void actRes2Active(vpciPtr pTable, UINT8 scope, OAM_CELL* pCell) ;
int ready2ActRes(vpciPtr, UINT8, OAM_CELL*);
int ready2Deact(vpciPtr, UINT8, OAM_CELL*);
int actCon2Ready(vpciPtr, UINT8, OAM_CELL*);
int actCon2Active(vpciPtr, UINT8, OAM_CELL*);
int act2Act(vpciPtr, UINT8, OAM_CELL*);
int act2Ready(vpciPtr, UINT8, OAM_CELL*);
int deactCon2Ready(vpciPtr, UINT8, OAM_CELL*);
int invMsg(vpciPtr, UINT8, OAM_CELL*);
void tx_ais(unsigned long Table);

int link_failure(OAM_CELL *pCell);
int link_recovery(OAM_CELL *pCell);
void ete_lb_fail(unsigned long);
void seg_lb_fail(unsigned long);

void tx_ete_f4_lb(unsigned long);
void tx_seg_f4_lb(unsigned long);
void tx_ete_f5_lb(unsigned long);
void tx_seg_f5_lb(unsigned long);
int stop_loopback(UINT8 vpi,UINT32 vci, UINT8 scope);

#endif /*_OAM_H*/
