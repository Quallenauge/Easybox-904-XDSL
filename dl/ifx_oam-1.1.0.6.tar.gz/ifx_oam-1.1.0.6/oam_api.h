/******************************************************************************

                               Copyright (c) 2010
                            Lantiq Deutschland GmbH
                     Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/

#ifndef _OAM_API_H_
#define _OAM_API_H_

typedef struct {
   /** F5/F4 LB cells Tx*/
   unsigned int oam_lb_req_tx;
   /** F5/F4 LB cells Reply Rx in response to Request Tx cells*/
   unsigned int oam_lb_reply_rx;
   /** F5/F4 LB cells Request Rx (from CO)*/
   unsigned int oam_lb_req_rx;
   /** F5/F4 LB cells Reply Tx in response to Rx Request cells*/
   unsigned int oam_lb_reply_tx;
   /** F5/F4 CC Request cells Tx*/
   unsigned int oam_cc_req_tx;
   /** F5/F4 CC cells Reply Rx in response to Request Tx cells*/
   unsigned int oam_cc_reply_rx;
   /** F5/F4 CC cells Request Rx (from CO)*/
   unsigned int oam_cc_req_rx;
   /** F5/F4 CC cells Reply Tx in response to Rx Request cells -
       usually always same as req_rx*/
   unsigned int oam_cc_reply_tx;
   /** Number of times F5/F4 AIS outage has happened*/
   unsigned int oam_ais_fail_count;
   /** OAM F5/F4 AIS Cells Rx*/
   unsigned int oam_ais_rx;
   /** Number of times F5/F4 RDI outage has happened*/
   unsigned int oam_rdi_fail_count;
   /** OAM F5/F4 RDI Cells Rx*/
   unsigned int oam_rdi_rx;
} oam_cell_counters_t;



typedef struct {
   /** Time in msec for VC/VP to be in RDI defect state for it to indicate
       failure. Special value -1 to indicate no change in parameter.*/
   int oam_rdi_persist;
   /** Time in msec for which if RDI cells are not received for VC/VP,
       it is brought out of defect state (normal state).
       Special value -1 to indicate no change in parameter.*/
   int oam_rdi_not_rx;
   /** Time in msec for VC/VP to be in AIS defect state for it to indicate
       failure. Special value -1 to indicate no change in parameter.*/
   int oam_ais_persist;
   /** Time in msec for which if AIS cells are not received for VC/VP,
       it is brought out of defect state (normal state).
       Special value -1 to indicate no change in parameter.*/
   int oam_ais_not_rx;
   /** Time in mseconds after which link will be brought down if no CC cell
       is received. VC/VP set to AIS fail state.
       Special value -1 to indicate no change in parameter.*/
   int oam_cc_sink;
} oam_fsm_timer_cfg_t;

int ifx_oam_enable_loopback(int vpi, int vci, char scope, int freq);

int ifx_oam_disable_loopback(int vpi, int vci, char scope, int freq);

int ifx_oam_enable_cc(int vpi, int vci, char scope, char direction);

int ifx_oam_disable_cc(int vpi, int vci, char scope, char direction);

int ifx_oam_f5_ping(
         int vpi, int vci, char scope, int
         ping_timeout, int num_cells_tx, int *num_cells_rx, int
         *max_resp_time, int *min_resp_time, int *avg_resp_time);

int ifx_oam_f4_ping(
         int vpi, char scope, int ping_timeout,
         int num_cells_tx, int *num_cells_rx, int *max_resp_time,
         int *min_resp_time, int *avg_resp_time);

int ifx_oam_cell_counters_get(
         unsigned char vpi,
         unsigned short vci,
         oam_cell_counters_t *counters);

int ifx_oam_cell_counters_reset(
         unsigned char vpi,
         unsigned short vci);

int ifx_oam_fsm_timer_config_set(
         unsigned char vpi,
         unsigned short vci,
         oam_fsm_timer_cfg_t *timer_cfg);

#endif  /* _OAM_API_H_ */
