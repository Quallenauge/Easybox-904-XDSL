/******************************************************************************

                               Copyright (c) 2010
                            Lantiq Deutschland GmbH
                     Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/

#include <netinet/in.h> 
#include <linux/atm.h> 
#include "oam.h"
#include <linux/netlink.h> 
#include <string.h>
#include <syslog.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>

#define syslog(a,args...) printf(args)
#define perror	printf 

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
static char g_EventScript[255] = OAM_DEFAULT_EVENT_SCRIPT;
static OAM_EnvList_t g_EnvList = {0};
static UINT8  g_bScriptWarn = 0;
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/

static int oam_sd;

#ifdef INCLUDE_IFX_OAM_LOOPBACK
static void (* lb_tx_func[2][2])(unsigned long) = {
	{tx_ete_f4_lb, tx_seg_f4_lb },
	{tx_ete_f5_lb, tx_seg_f5_lb },
};
static void (* lb_wait_func[2])(unsigned long) = {
	ete_lb_fail, seg_lb_fail };
#endif /* #ifdef INCLUDE_IFX_OAM_LOOPBACK*/

#ifdef INCLUDE_IFX_OAM_CC
static void (* cc_tx_timer[2])(unsigned long) = {
	tx_ete_cc, tx_seg_cc };

/* State machine array */
static int (* cc_state_table[5][5])(vpciPtr, UINT8, OAM_CELL*) = {
	{ready2ActRes, invMsg,        invMsg,       ready2Deact,    invMsg},
	{actCon2Ready, actCon2Active, actCon2Ready, invMsg,         invMsg},
	{invMsg,       invMsg,        invMsg,       invMsg,         invMsg},
	{act2Act,      invMsg,        invMsg,       act2Ready,      invMsg},
	{invMsg,       invMsg,        invMsg,       deactCon2Ready, deactCon2Ready} 
};
#endif /* #ifdef INCLUDE_IFX_OAM_CC*/

int create_nl_socket(void);
vpciPtr vpciHead = NULL;

static UINT16 calcCRC10(UINT8 *pData, UINT32 Size);

int oam_daemon(void);
int command(OAM_CELL *pCell);
int enable_oam(UINT32 vpi, UINT32 vci);
INT32 send_oam(OAM_CELL * pCell);
INT32 check_segment(OAM_CELL *pCell);
INT32 send_ais(void);

void process_f4_ete( OAM_CELL* pCell, UINT32 vpi);
void process_f4_seg(OAM_CELL* pCell, u_int32_t vpi);
void process_f5_seg( OAM_CELL* pCell, u_int32_t vpi, u_int32_t vci);
void process_f5_ete( OAM_CELL* pCell, u_int32_t vpi, u_int32_t vci);

#ifdef INCLUDE_IFX_OAM_LOOPBACK_PING
int update_oam_stats(VPCI *pTable);
#endif /* #ifdef INCLUDE_IFX_OAM_LOOPBACK_PING*/
int check_adsl_status();

#ifdef OAM_DEBUG
void oam_dump_data(unsigned int len, char *data)
{
   int i;
   for (i=0;i<len;i++) {
      printf("%2.2x ",(unsigned char)(data[i]));
      if (i % 16 == 15)
         printf("\n");
   }
   printf("\n");
}
#endif

static int lock_create(
               OAM_Lock_t *lockId)
{
   if(lockId)
   {
      if (OAM_LOCK_INIT_VALID(lockId))
      {
         if(sem_init(&lockId->object, 0, 1) == 0)
         {
            lockId->bValid = OAM_TRUE;

            return 0;
         }
      }
   }
   
   return -1;
}



#ifdef OAM_SUPPORT_SAFE_EXIT
static int lock_delete(
               OAM_Lock_t *lockId)
{
   /* delete semaphore */
   if(lockId)
   {
      if (OAM_LOCK_INIT_VALID(lockId))
      {
         if (sem_destroy(&lockId->object) == 0)
         {
            lockId->bValid = OAM_FALSE;

            return 0;
         }
      }
   }
 
   return -1;
}
#endif /* #ifdef OAM_SUPPORT_SAFE_EXIT*/



static int lock_get(
               OAM_Lock_t *lockId)
{
   if(lockId)
   {
      if (OAM_LOCK_INIT_VALID(lockId))
      {
         if (sem_wait(&lockId->object) == 0)
         {
            return 0;
         }
      }
   }

   return -1;
}



static int lock_set(
               OAM_Lock_t *lockId)
{
   if(lockId)
   {
      if (OAM_LOCK_INIT_VALID(lockId))
      {
         if (sem_post(&lockId->object) == 0)
         {
            return 0;
         }
      }
   }

   return -1;
}



#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
static void event_script_run(const char *sScript)
{
   if (system(sScript) != 0 && g_bScriptWarn == 0)
   {
      g_bScriptWarn = 1;
      OAMPRINTF("ERROR - event script file (%s) execution failed!\n",
         sScript);
   }

   return;
}



static int set_env(const char *sName, const char *sValue)
{
   OAM_EnvList_t *pEnvList = &g_EnvList, *pEnvListPrev = &g_EnvList;
   const UINT16 namelen = strlen (sName);
   const UINT16 vallen  = sValue != NULL ? strlen (sValue) : 0;

   if (namelen == 0) {
		OAMPRINTF("Can't set zero-length env variable!\n");
      return -1;
   }

   if (vallen > OAM_MAX_ENV_VAR_LENGTH) {
		OAMPRINTF("Unsupported environment variable value length=%d, variable value: %s!\n",
   		vallen, sValue);
      return -1;
   }

   while(1) {
      if (pEnvList == NULL) {
         pEnvList = (OAM_EnvList_t*)malloc(sizeof(OAM_EnvList_t));

         if (!pEnvList) {
		      OAMPRINTF("Failed to allocate Env list entry!\n");
            return -1;
         }

         memset(pEnvList, 0x0, sizeof(OAM_EnvList_t));

         pEnvListPrev->pNext = pEnvList;
      }

      if (pEnvList->pEnvEntry == NULL) {
         pEnvList->pEnvEntry = (char*)malloc(namelen + OAM_MAX_ENV_VAR_LENGTH + 2);

         if (!(pEnvList->pEnvEntry)) {
            OAMPRINTF("Failed to allocate Env entry!\n");
            return -1;
         }

         memset(pEnvList->pEnvEntry, 0x0, namelen + OAM_MAX_ENV_VAR_LENGTH + 2);

         break;
      }
      else if (!strncmp (pEnvList->pEnvEntry, sName, namelen)) {
         /* variable already exists*/
         break;
      }
      else {
         pEnvListPrev = pEnvList;
         pEnvList     = pEnvList->pNext;
         continue;
      }
   }

   sprintf(pEnvList->pEnvEntry, "%s=%s", sName, sValue != NULL ? sValue : "");
   putenv(pEnvList->pEnvEntry);

   return 0;
}

#ifdef INCLUDE_IFX_OAM_LOOPBACK

static void reverse(char s[])
{
   int i, j;
   char c;

   for (i = 0, j = strlen(s)-1; i<j; i++, j--) {
      c = s[i];
      s[i] = s[j];
      s[j] = c;
   }
}


static void itoa(int n, char s[])
{
   int i, sign;

   if ((sign = n) < 0)
     n = -n;
   i = 0;
   do {
     s[i++] = n % 10 + '0';
   } while ((n /= 10) > 0);
   if (sign < 0)
     s[i++] = '-';
   s[i] = '\0';
   reverse(s);
}


static int OAM_Fx_LB_FAIL_event(vpciPtr pTable, UINT8 scope)
{
   UINT8 bEvent = OAM_FALSE, bF4 = OAM_FALSE;
   char s[16];

   pTable->lb_consec_fail_cnt++;

   if (!(pTable->lb_consec_fail_cnt % OAM_MAX_CONSEC_LB_FAILS)) {
      bEvent = OAM_TRUE;
   }

   if (!bEvent)
      return 0;

	if((pTable->vci ==3) || (pTable->vci ==4) ||
      (pTable->vci ==0)) { 
      bF4 = OAM_TRUE;
	}

   itoa((int)pTable->vpi, s);
   if (set_env("OAM_VPI", s) != 0)
      return -1;

   itoa((int)pTable->vci, s);
   if (set_env("OAM_VCI", s) != 0)
      return -1;

   if (set_env("OAM_SCOPE", scope == OAM_ETE ? "ETE" : "SEG") != 0)
      return -1;

   itoa(OAM_MAX_CONSEC_LB_FAILS, s);
   if (set_env("OAM_NUM_FAIL", s) != 0)
      return -1;

   if (set_env("OAM_EVENT", bF4 ? "OAM_F4_LB_FAIL" : "OAM_F5_LB_FAIL") != 0)
      return -1;

   event_script_run(g_EventScript);

   return 0;
}
#endif /* #ifdef INCLUDE_IFX_OAM_LOOPBACK*/



#ifdef INCLUDE_IFX_OAM_CC
static int OAM_CC_event(vpciPtr pTable, UINT8 scope, cc_events_t ccState)
{
   cc_state_t ccStatus = (cc_state_t)
      ((scope == OAM_ETE) ? pTable->cc_ete_state : pTable->cc_seg_state);
   UINT8 cc_dir = 0;
   char *events[] = {"ACTIVATE", "ACT_CONF",
                     "ACTIVATION_DENIED", "DEACTIVATE", "DEACT_CONF"};

   if (set_env("OAM_CC_LINK_STATUS", ccStatus == CC_ACTIVE ? "UP" : "DOWN") != 0)
      return -1;

   if (set_env("OAM_SCOPE", scope == OAM_ETE ? "ETE" : "SEG") != 0)
      return -1;

   if (set_env("OAM_STATE", ccState == CC_NA ? "NA" : events[ccState]) != 0)
      return -1;

   cc_dir = scope == OAM_ETE ? pTable->cc_ete_direction :
                               pTable->cc_seg_direction;

   if (set_env("OAM_SINK", cc_dir ? "TRUE" : "FALSE") != 0)
      return -1;


   if (set_env("OAM_EVENT", "OAM_CC_EVENT") != 0)
      return -1;

   event_script_run(g_EventScript);

   return 0;
}
#endif /* #ifdef INCLUDE_IFX_OAM_CC*/

#ifdef INCLUDE_IFX_OAM_AIS
static int OAM_AIS_event(vpciPtr pTable, UINT8 scope, UINT8 bOamCcRx)
{
   UINT16 aisState = (UINT16)(scope == OAM_ETE ? pTable->ais_ete_state :
                                                 pTable->ais_seg_state);

   if (set_env("OAM_AIS_LINK_STATUS", aisState ==  OAM_AIS_FAILURE ? "DOWN" : "UP") != 0)
      return -1;

   if (set_env("OAM_CC_RX", bOamCcRx ? "TRUE" : "FALSE") != 0)
      return -1;

   if (set_env("OAM_SCOPE", scope == OAM_ETE ? "ETE" : "SEG") != 0)
      return -1;

   if (set_env("OAM_EVENT", "OAM_AIS_EVENT") != 0)
      return -1;

   event_script_run(g_EventScript);

   return 0;
}
#endif /* #ifdef INCLUDE_IFX_OAM_AIS*/

#ifdef INCLUDE_IFX_OAM_RDI
static int OAM_RDI_event(vpciPtr pTable, UINT8 scope)
{
   UINT16 aisState = (UINT16)(scope == OAM_ETE ? pTable->ais_ete_state :
                                                 pTable->ais_seg_state);

   if (set_env("OAM_AIS_LINK_STATUS", aisState ==  OAM_AIS_FAILURE ? "DOWN" : "UP") != 0)
      return -1;

   if (set_env("OAM_SCOPE", scope == OAM_ETE ? "ETE" : "SEG") != 0)
      return -1;

   if (set_env("OAM_EVENT", "OAM_AIS_EVENT") != 0)
      return -1;

   event_script_run(g_EventScript);

   return 0;
}
#endif /* #ifdef INCLUDE_IFX_OAM_AIS*/


#ifdef OAM_SUPPORT_SAFE_EXIT
static void env_free(void)
{
   OAM_EnvList_t *pEnvListHead = &g_EnvList, *pEnvListNext = NULL;

   if (pEnvListHead->pEnvEntry)
      free(pEnvListHead->pEnvEntry);

   pEnvListHead = pEnvListHead->pNext;

   while(pEnvListHead)
   {
      if (pEnvListHead->pEnvEntry)
         free(pEnvListHead->pEnvEntry);
      
      pEnvListNext = pEnvListHead->pNext;

      free(pEnvListHead);
      
      pEnvListHead = pEnvListNext;
   }
}
#endif /* #ifdef OAM_SUPPORT_SAFE_EXIT*/
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/



static int arg_parse(int argc, char *argv [])
{
   int c, nOptIndex;

   static struct option pOptString[] = {
      { "help",    no_argument,       0, 'h' },
      { "version", no_argument,       0, 'v' },
#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
      { "script",  required_argument, 0, 's' },
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/
      { NULL,      no_argument,       0,  0 }
   };

   static const char pLongOpts[] =
   "hv"
#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
   "s:"
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/
   ;

   while (1) {
      c = getopt_long(argc, argv, pLongOpts, pOptString, &nOptIndex);

      if (c == -1)
         return 0;

      switch (c) {
      case 'v':
         /* TBD: print version here*/
         break;
      case 'h':
            printf("Usage: %s [options]\n", argv[0]);
#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
            printf("-s, --script=<file>      Event script file\n");
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/
            printf("-h, --help               Print help (this message) and exit\n");
         return -1;
#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
      case 's':
         if (strlen(optarg) + 1 > sizeof(g_EventScript)) {
            printf("ERROR - Event Script file path is too long!\n");
            return -1;
         }

         strcpy(g_EventScript, optarg);
         break;
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/
      }
   }

   return 0;
}							


/**********************************************************
 * following function will create netlink socket for sending and 
 * receving oam cells and from atm driver and start the oam daemon 
 * running in user mode
 *********************************************************/

int main(int argc, char *argv [])
{
	FILE *foam;
	int pid=0;

   if (arg_parse(argc, argv) != 0)
      return -1;

	create_nl_socket();
	pid = getpid();
	OAMPRINTF("oam: PID:%d \n",pid);
	foam = fopen("/var/run/oam.pid","w");
	if(!foam){
		OAMPRINTF("Error opening file\n");
		return -1;
	}
	
	fprintf(foam,"%d",pid);
	fclose(foam);

	oam_daemon();

	return 0;
}



/* 	wait for OAM packets from ATM Driver and process 'em
	OAM cells are Categorised based on 
	VCI Interpretation Category:
	"	VCI 3, Segment OAM F4 flow cell Non-user cell
	"	VCI 4, End-to-end OAM F4 flow cell

	End-to-end F5 flow: This flow, identified by a standardized PTI value 5
	is used for end-to-end VCC operations communications.
	Segment F5 flow: This flow, identified by a standardized PTI value 4
	is used for communicating operations information within the boundaries 
	of the VCC segment.
*/

int create_nl_socket(void)
{

	struct sockaddr_nl oamRxSockAdd;
	int addr_len;


	/* Wait for OAM cells from driver */
	oam_sd = socket(AF_NETLINK, SOCK_RAW, NETLINK_USERSOCK);
	if (oam_sd < 0){
		perror("Error opening OAM socket");
	}	

	/* bind socket */
	oamRxSockAdd.nl_family = AF_NETLINK;
	oamRxSockAdd.nl_pad = 0;
	oamRxSockAdd.nl_pid = getpid();
	oamRxSockAdd.nl_groups = 0;
	
	if(bind(oam_sd, (struct sockaddr *)&oamRxSockAdd, 
				sizeof(oamRxSockAdd)) <0){
		perror(" Error binding OAM socket");
	}

	addr_len = sizeof(oamRxSockAdd);

	if (getsockname(oam_sd, (struct sockaddr*)&oamRxSockAdd, (socklen_t *) &addr_len) < 0)
	{
	    perror("cannot getsockname");
	    return -1;
	}

	if (addr_len != sizeof(oamRxSockAdd)) {
	    OAMPRINTF("wrong address lenght %d\n", addr_len);
	    return -1;
	}

	if (oamRxSockAdd.nl_family != AF_NETLINK) {
	    OAMPRINTF("wrong address family %d\n", oamRxSockAdd.nl_family);
	    return -1;
	}

	return 0;
}

/**********************************************************************
 * This is oam daemon that will be waiting on netlink socket for reciving 
 * oam cells from remote end 
 *********************************************************************/

int oam_daemon(void)
{
	UINT32  vci,vpi, pti;
	OAM_CELL *pCell;
	int  size;

	struct msghdr rxmsg;
	struct iovec rxiov;
	struct sockaddr_nl oamRxSockAdd;
	struct amazon_atm_cell_header * amz_cell_hdr;

	/* inform our pid to kernel module */
	pCell = create_lb(0, 0, 0,0);
	send_oam(pCell);
	free(pCell);
	
	pCell = (OAM_CELL *)malloc(OAM_CELL_SIZE);
	if(!pCell){
		OAMPRINTF("\n No Memory!!");
		return -1;
	}

	memset(pCell,'\0', OAM_CELL_SIZE);
	rxiov.iov_base = pCell;
	rxiov.iov_len = OAM_CELL_SIZE;
	
	rxmsg.msg_name = (void *)&oamRxSockAdd;
	rxmsg.msg_namelen = sizeof(oamRxSockAdd);
	rxmsg.msg_iov = &rxiov;
	rxmsg.msg_iovlen = 1; 
	rxmsg.msg_control = NULL;
	rxmsg.msg_controllen = 0;
	rxmsg.msg_flags = 0;


	while (1) {
		memset(pCell, 0x00, OAM_CELL_SIZE);

		/* read whole structure */
      size = recvmsg(oam_sd, &rxmsg, 0);
         
		if (size != OAM_CELL_SIZE) {
		   OAMPRINTF("\noam [%s]: size: %d\n", __FUNCTION__, size);
         continue;
      }

#ifdef OAM_DEBUG
		printf("\n Received:");
		oam_dump_data(52, pCell->cell);
#endif
		/* Check error detection code value, crc-10 value check -TBD*/
		if ( !checkCRC10(pCell->cell)){
			/*printf("oam [%s]: ERROR Wrong CRC10\n", __FUNCTION__);*/
#if 0
			printf("oam [%s]: drop and wait another one!\n", __FUNCTION__);
			continue;
#else
			/*printf("oam [%s]: TESTING and NODROP: continue process\n", __FUNCTION__);*/
#endif
		} 
			
		amz_cell_hdr = (struct amazon_atm_cell_header *)pCell->cell;
		vpi = amz_cell_hdr->bit.vpi;
		vci = amz_cell_hdr->bit.vci;
		pti = amz_cell_hdr->bit.pti;
		pCell->pid = getpid();

		OAMPRINTF("oam [%s]: vpi:%d, vci:%d, pti:%d\n", __FUNCTION__, vpi, vci, pti);

		/* Check cell type should be 1 (oam packet) */
		if (((pCell->cell[OAM_TYPE_FN] & 0x10) != 0x10)
			&&((pCell->cell[OAM_TYPE_FN] & 0x81) != 0x81)) {
			syslog(LOG_ERR,"ERROR Wrong type and function\n");
			OAMPRINTF("ERROR Wrong type and function\n");
			continue;
		}
	   
		if (vci == 4) {
			OAMPRINTF("Its an VPI end to end packet\n");
#ifndef F5_OPTIMIZED
			process_f4_ete(pCell,vpi);
#else
			OAMPRINTF("Not support in this releaset\n");
#endif /* F5_OPTIMIZED */
		}
		else if (vci == 3) {
			OAMPRINTF("it's a VPI segment packet\n"); 
#ifndef F5_OPTIMIZED
			process_f4_seg(pCell,vpi);
#else
			OAMPRINTF("Not support in this releaset\n");
#endif /* F5_OPTIMIZED */
		}
		else if ((pti == 0x05) &&
         		(vci != 0x00) && (vci != 0x03) &&
         		(vci != 0x04) && (vci != 0x06) && (vci != 0x07)) {
			OAMPRINTF("it's a VCI end to end packet  If (PTI(cell) == 5)\n");
			process_f5_ete(pCell, vpi, vci);
		}
		else if ((pti == 0x04) &&
         		(vci != 0x00) && (vci != 0x03) &&
         		(vci != 0x04) && (vci != 0x06) && (vci != 0x07)) {
			OAMPRINTF("it's a VCI segment packet  If (PTI(cell) == 4)\n");
			process_f5_seg(pCell, vpi, vci);
		}
		else if (vci == 0) {
			command(pCell);
		}
		else {
			syslog(LOG_WARNING,"Invalid Cell received\n");
		}

		fflush(stdout);
	}
}

#ifndef F5_OPTIMIZED
/* 
	On reception of VP_AIS e_t_e cells, VP is marked to be in defect state 
	and RDI cells are generated at the VPC sink point. if no AIS is received 
	for 2.5 sec, VP is returned to normal state. 
*/ 
void process_f4_ete( OAM_CELL* pCell, UINT32 vpi)
{

	VPCI	*pTable;
#ifdef INCLUDE_IFX_OAM_CC
	char	eventId;
#endif /* #ifdef INCLUDE_IFX_OAM_CC*/
	
	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	pTable = (VPCI *)getVpciPtr(vpi,0);

	if(pTable == NULL) {
		perror("f4 ete");
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return;
	}

   lock_get(&pTable->tbl_lock);

   switch (pCell->cell[OAM_TYPE_FN]) {
#ifdef INCLUDE_IFX_OAM_AIS
   case OAM_AIS:
		putchar('A');
		fflush(stdout);

      pTable->cell_counters.oam_ais_rx++;

		if (pTable->ais_ete_state == OAM_NORMAL) {
			/* syslog the failure */
			syslog(LOG_ERR," f4 ais failure : VPI:%d Failed",vpi);

			/*mark f4_ete_AIS_state in VPtable.*/
			pTable->ais_ete_state = OAM_AIS_DEFECT;

         /* 3.5 sec timer to generate user alarm and to change
         the state to failure */ 
			if (!pTable->ete_ais_alarm_timer) {
				OAMPRINTF("creating f4 ete ais recovery timer\n");
				pTable->ete_ais_alarm_timer=
					timerCreate(  
						INFI_TIMER_ONESHOT,
						f4_ete_ais_alarm_timer,
						(unsigned long)vpi);
			}
         
			timerStart(pTable->ete_ais_alarm_timer, 
						(unsigned int)pTable->fsm_timer_cfg.oam_ais_persist,
						INFI_TIMER_ONESHOT);


			/* in case no AIS is received for 2.5 sec return 
			to normal state. to be initialized in case of cc, user
			cell appears on this VP, Driver to indicate arrival  of 
			user cell */
			if (!pTable->ete_ais_recovery_timer) {
				OAMPRINTF("creating f4 ete ais recovery timer\n");
				pTable->ete_ais_recovery_timer=
					timerCreate(  
						INFI_TIMER_ONESHOT,
						f4_ete_ais_recovery_timer,
						(unsigned long)vpi);
			}

			timerStart(pTable->ete_ais_recovery_timer, 
						(unsigned int)pTable->fsm_timer_cfg.oam_ais_not_rx, 
						INFI_TIMER_ONESHOT);

			/* Send RDI cell in opposite direction */ 
			pCell->cell[OAM_TYPE_FN] = OAM_RDI;
			send_oam(pCell);

			/*Transmit AIS in forward direction: Not used in our case */
			send_ais();
      }
		else {
			OAMPRINTF(" eteAisRecovery reset\n");
			timerReset(pTable->ete_ais_recovery_timer,
						(unsigned int)pTable->fsm_timer_cfg.oam_ais_not_rx, 
						INFI_TIMER_ONESHOT);

			/* Send RDI cell in opposite direction */ 
			pCell->cell[OAM_TYPE_FN] = OAM_RDI;
			send_oam(pCell);

			/*Transmit AIS in forward direction: Not used in our case */
			send_ais();
      }
      break;
#endif /* #ifdef INCLUDE_IFX_OAM_AIS*/

#ifdef INCLUDE_IFX_OAM_RDI
   case OAM_RDI:
		putchar('R');
		fflush(stdout);

      pTable->cell_counters.oam_rdi_rx++;

		/* First RDI cell receoved */
		if (pTable->rdi_ete_state == OAM_NORMAL) {
			pTable->rdi_ete_state = OAM_RDI_DEFECT;

			/* syslog the failure*/
			syslog(LOG_ERR," f4 rdi failure : VPI:%d Failed\n",vpi);

         /* 3.5 sec timer to generate user alarm and to change
         the state to failure */ 
			if (!pTable->ete_rdi_alarm_timer) {
				OAMPRINTF("creating f4 ete rdi alarm timer\n");
				pTable->ete_rdi_alarm_timer=
					timerCreate(  
						INFI_TIMER_ONESHOT,
						f4_ete_rdi_alarm_timer,
						(unsigned long)vpi);
			}

			timerStart(pTable->ete_rdi_alarm_timer, 
						(unsigned int)pTable->fsm_timer_cfg.oam_rdi_persist, 
						INFI_TIMER_ONESHOT);

			/* in case no RDI is received for 2.5 sec return 
			to normal state. to be initialized in case of cc, user
			cell appears on this VP, Driver to indicate arrival  of 
			user cell */
			if (!pTable->ete_rdi_recovery_timer) {
				OAMPRINTF("creating f4 ete rdi recovery timer \n");
				pTable->ete_rdi_recovery_timer=
					timerCreate(  
						INFI_TIMER_ONESHOT,
						f4_ete_rdi_recovery_timer,
						(unsigned long)vpi);
			}

			timerStart(pTable->ete_rdi_recovery_timer,
						(unsigned int)pTable->fsm_timer_cfg.oam_rdi_not_rx, 
						INFI_TIMER_ONESHOT);
      }
		else {
			timerReset(pTable->ete_rdi_recovery_timer,
					(unsigned int)pTable->fsm_timer_cfg.oam_rdi_not_rx, 
					INFI_TIMER_ONESHOT);
		}
      break;
#endif /* #ifdef INCLUDE_IFX_OAM_RDI*/

#ifdef INCLUDE_IFX_OAM_F4_LOOPBACK
   case OAM_LB:
		putchar('L');
		fflush(stdout);
		process_loopback(pTable,pCell, OAM_ETE);
      break;
#endif /* #ifdef INCLUDE_IFX_OAM_F4_LOOPBACK*/

#ifdef INCLUDE_IFX_OAM_CC
   case OAM_ACTIVATION_CC:
		eventId = (pCell->cell[OAM_CC_MSGID_AND_DIR] >> 2) ;
		eventId = getEvent(eventId);
		if (eventId <0) {
			OAMPRINTF("Invalid Event\n");
			return;
		}

		putchar('C');
		fflush(stdout);
		activate_cc(pTable, OAM_ETE, pCell, eventId);
      break;
#endif /* #ifdef INCLUDE_IFX_OAM_CC*/
   default:
      break;
   }

   lock_set(&pTable->tbl_lock);
}



/* 
	On reception of VP_AIS segment cells, VP is marked to be in 
	defect state and RDI cells are generated at the VPC sink point. 
	if no AIS is received for 2.5 sec, VP is returned to normal state. 
	Segment are specified by the network manager. 
*/ 
void process_f4_seg(OAM_CELL* pCell, u_int32_t vpi)
{

	VPCI	*pTable;
#ifdef INCLUDE_IFX_OAM_CC
	char eventId;
#endif /* #ifdef INCLUDE_IFX_OAM_CC*/

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	if (!check_segment(pCell)){
		OAMPRINTF("\nOAM: Segment failure ");
		return;
   }
	
	pTable = (VPCI *)getVpciPtr(vpi,0);

	if(pTable == NULL){
		OAMPRINTF("\noam [%s]: OAM Couldnt get VPCI table pointer\n", __FUNCTION__);
		return;
	}

   lock_get(&pTable->tbl_lock);

   switch (pCell->cell[OAM_TYPE_FN]) {
#ifdef INCLUDE_IFX_OAM_AIS
   case OAM_AIS:
		putchar('A');
		fflush(stdout);

      pTable->cell_counters.oam_ais_rx++;

		/* First AIS cell received */
		if(pTable->ais_seg_state == OAM_NORMAL)
		{
			/* syslog the failure */
			syslog(LOG_ERR," f4 seg ais failure : VPI:%d Failed\n",vpi);

			/*mark f4_ete_AIS_state in VPtable.*/
			pTable->ais_seg_state = OAM_AIS_DEFECT;

         /* 3.5 sec timer to generate user alarm and to change
         the state to failure */ 
			if(!pTable->seg_ais_alarm_timer){
				pTable->seg_ais_alarm_timer = 
					timerCreate(
						INFI_TIMER_ONESHOT,
						f4_seg_ais_alarm_timer, 
						(unsigned long)vpi);
			}

         timerStart(pTable->seg_ais_alarm_timer,
	            (unsigned int)pTable->fsm_timer_cfg.oam_ais_persist, 
	            INFI_TIMER_ONESHOT);

			
			/* in case no AIS is received for 2.5 sec return 
			to normal state. to be initialized in case of cc, user
			cell appears on this VP, Driver to indicate arrival  of 
			user cell */
			if(!pTable->seg_ais_recovery_timer){
				pTable->seg_ais_recovery_timer = 
					timerCreate(
						INFI_TIMER_ONESHOT,
						f4_seg_ais_recovery_timer, 
						(unsigned long)vpi);
			}

         timerStart(pTable->seg_ais_recovery_timer,
	            (unsigned int)pTable->fsm_timer_cfg.oam_ais_not_rx, 
	            INFI_TIMER_ONESHOT);

			/* Send RDI cell in opposite direction */ 
			pCell->cell[OAM_TYPE_FN] = OAM_RDI;
			send_oam(pCell);

			/*Transmit AIS in forward direction: Not used in our case */
			send_ais();
		}
		else {
			timerReset(pTable->seg_ais_recovery_timer,
				(unsigned int)pTable->fsm_timer_cfg.oam_ais_not_rx, 
				INFI_TIMER_ONESHOT);

			/* Send RDI cell in opposite direction */ 
			pCell->cell[OAM_TYPE_FN] = OAM_RDI;
			send_oam(pCell);

			/*Transmit AIS in forward direction: Not used in our case */
			send_ais();
		}
      break;
#endif /* #ifdef INCLUDE_IFX_OAM_AIS*/

#ifdef INCLUDE_IFX_OAM_RDI
   case OAM_RDI:
		putchar('R');
		fflush(stdout);

      pTable->cell_counters.oam_rdi_rx++;

		/* received first RDI cell */
		if(pTable->rdi_seg_state == OAM_NORMAL){
			/* syslog the failure */
			syslog(LOG_ERR," f4 seg rdi defect : VPI:%d Failed\n",vpi);
			
			pTable->rdi_seg_state = OAM_RDI_DEFECT;

         /* 3.5 sec timer to generate user alarm and to change
         the state to failure */ 
			if(!pTable->seg_rdi_alarm_timer){
				pTable->seg_rdi_alarm_timer = 
					timerCreate(
						INFI_TIMER_ONESHOT,
						f4_seg_rdi_alarm_timer, 
						(unsigned long)vpi);
			}

         timerStart(pTable->seg_rdi_alarm_timer,
	            (unsigned int)pTable->fsm_timer_cfg.oam_rdi_persist, 
	            INFI_TIMER_ONESHOT);
			
			/* in case no RDI is received for 2.5 sec return 
			to normal state. to be initialized in case of cc, user
			cell appears on this VP, Driver to indicate arrival  of 
			user cell */
			if(!pTable->seg_rdi_recovery_timer){
			 	pTable->seg_rdi_recovery_timer = 
					timerCreate(
				 		INFI_TIMER_ONESHOT,
						f4_seg_rdi_recovery_timer,
						(unsigned long)vpi);
			}

			timerStart(pTable->seg_rdi_recovery_timer,
            (unsigned int)pTable->fsm_timer_cfg.oam_rdi_not_rx, 
            INFI_TIMER_ONESHOT);
		}
		else {
         timerReset(pTable->seg_rdi_recovery_timer,
            (unsigned int)pTable->fsm_timer_cfg.oam_rdi_not_rx, 
            INFI_TIMER_ONESHOT);
		}
      break;
#endif /* #ifdef INCLUDE_IFX_OAM_RDI*/

#ifdef INCLUDE_IFX_OAM_F4_LOOPBACK
   case OAM_LB:
		putchar('L');
		fflush(stdout);
		process_loopback(pTable,pCell, OAM_SEG);
      break;
#endif /* #ifdef INCLUDE_IFX_OAM_F4_LOOPBACK*/

#ifdef INCLUDE_IFX_OAM_CC
   case OAM_ACTIVATION_CC:
		eventId = (pCell->cell[OAM_CC_MSGID_AND_DIR] >>2) ;
		eventId = getEvent(eventId);
		if(eventId <0){
			OAMPRINTF("Invalid Event\n");
			return;
		}
		putchar('C');
		fflush(stdout);
		activate_cc(pTable,OAM_SEG,pCell,eventId);
      break;
#endif /* #ifdef INCLUDE_IFX_OAM_CC*/
   default:
      break;
   }

   lock_set(&pTable->tbl_lock);
}



#ifdef INCLUDE_IFX_OAM_AIS
/*
   No AIS, RDI cell received on this VPC for 2.5 sec 
   return to normal state
*/
void f4_ete_ais_recovery_timer(unsigned long vpi)
{
	vpciPtr	pTable;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	OAMPRINTF("oam [%s]: Segment VPI: %lu Functional\n", __FUNCTION__, vpi);
	syslog(LOG_ERR,"VPI:%lu Operational\n",vpi);

	/* Get vpci table pointer */
	pTable = (vpciPtr)getVpciPtr(vpi,0);
	if (pTable == NULL) {
		perror("f4_ete_ais_recovery_timer: ");
		OAMPRINTF("oam [%s]: No memory!\n", __FUNCTION__);
		return;
	}

   lock_get(&pTable->tbl_lock);

	pTable->ais_ete_state = OAM_NORMAL;

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
   if (OAM_AIS_event(pTable, OAM_ETE, OAM_FALSE) != 0) {
		syslog(LOG_INFO,"Event OAM_AIS_EVENT failed!\n");
      OAMPRINTF("Event OAM_AIS_EVENT failed!\n");
   }
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/

	timerReset(pTable->ete_ais_alarm_timer, 
				1, INFI_TIMER_ONESHOT);
	
	timerDelete(pTable->ete_ais_recovery_timer);
	pTable->ete_ais_recovery_timer = 0;

   lock_set(&pTable->tbl_lock);
}

void f4_ete_ais_alarm_timer(unsigned long vpi)
{
	vpciPtr	pTable;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	/* Get vpci table pointer */
	pTable = (vpciPtr)getVpciPtr(vpi,0);
	if (pTable == NULL) {
		perror("f4_ete_ais_alarm_timer: ");
		OAMPRINTF("oam [%s]: No memory!\n", __FUNCTION__);
		return;
	}

   lock_get(&pTable->tbl_lock);

   if (pTable->ais_ete_state == OAM_AIS_DEFECT) {
	   OAMPRINTF("oam [%s]: Segment VPI: %lu Failure\n", __FUNCTION__, vpi);
	   syslog(LOG_ERR,"VPI:%lu Failure\n",vpi);

   	pTable->ais_ete_state = OAM_AIS_FAILURE;

      pTable->cell_counters.oam_ais_fail_count++;

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
      if (OAM_AIS_event(pTable, OAM_ETE, OAM_FALSE) != 0) {
		   syslog(LOG_INFO,"Event OAM_AIS_EVENT failed!\n");
         OAMPRINTF("Event OAM_AIS_EVENT failed!\n");
      }
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/
   }

	
	timerDelete(pTable->ete_ais_alarm_timer);
	pTable->ete_ais_alarm_timer = 0;

   lock_set(&pTable->tbl_lock);
}
#endif /* #ifdef INCLUDE_IFX_OAM_AIS*/



#ifdef INCLUDE_IFX_OAM_RDI
/* No AIS, RDI cell received on this VPC for 2.5 sec 
    return to normal state*/
void f4_ete_rdi_recovery_timer(unsigned long vpi)
{
	vpciPtr	pTable;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	OAMPRINTF("oam [%s]: Segement VPI: %lu Functional\n", __FUNCTION__, vpi);
	syslog(LOG_ERR, "VPI: %lu Functional",vpi); 

	/* Get vpci table pointer */
	pTable = (vpciPtr)getVpciPtr(vpi,0);
	if (pTable == NULL) {
		perror("f4_ete_rdi_recovery_timer: ");
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return;
	}

   lock_get(&pTable->tbl_lock);

	pTable->rdi_ete_state = OAM_NORMAL;

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
   if (OAM_RDI_event(pTable, OAM_ETE) != 0) {
		syslog(LOG_INFO,"Event OAM_RDI_EVENT failed!\n");
      OAMPRINTF("Event OAM_RDI_EVENT failed!\n");
   }
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/
	
	timerDelete (pTable->ete_rdi_recovery_timer);
	pTable->ete_rdi_recovery_timer = 0;

   lock_set(&pTable->tbl_lock);
}



void f4_ete_rdi_alarm_timer(unsigned long vpi)
{
	vpciPtr	pTable;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	/* Get vpci table pointer */
	pTable = (vpciPtr)getVpciPtr(vpi,0);
	if (pTable == NULL) {
		perror("f4_ete_rdi_recovery_timer: ");
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return;
	}

   lock_get(&pTable->tbl_lock);

   if (pTable->rdi_ete_state == OAM_RDI_DEFECT) {
	   OAMPRINTF("oam [%s]: Segement VPI: %lu Failure\n", __FUNCTION__, vpi);
	   syslog(LOG_ERR, "VPI: %lu Failure",vpi); 

   	pTable->rdi_ete_state = OAM_RDI_FAILURE;

      pTable->cell_counters.oam_rdi_fail_count++;

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
      if (OAM_RDI_event(pTable, OAM_ETE) != 0) {
		   syslog(LOG_INFO,"Event OAM_RDI_EVENT failed!\n");
         OAMPRINTF("Event OAM_RDI_EVENT failed!\n");
      }
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/
   }
	
	timerDelete (pTable->ete_rdi_alarm_timer);
	pTable->ete_rdi_alarm_timer = 0;

   lock_set(&pTable->tbl_lock);
}
#endif  /* #ifdef INCLUDE_IFX_OAM_RDI*/



#ifdef INCLUDE_IFX_OAM_RDI
/* No AIS, RDI cell received on this VPC for 2.5 sec 
    return to normal state*/
void f4_seg_rdi_recovery_timer(unsigned long vpi)
{
	VPCI *pTable;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	syslog(LOG_ERR, "Segment VPI: %lu Functional", vpi);
	OAMPRINTF("oam [%s]: Segement VPI: %lu Functional\n", __FUNCTION__, vpi);

	/* Get vpci table pointer */
	pTable = (vpciPtr)getVpciPtr(vpi,0);
	if (pTable == NULL) {
		perror("f4_seg_rdi_recovery_timer: ");
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return;
	}

   lock_get(&pTable->tbl_lock);

	pTable->rdi_seg_state = OAM_NORMAL;

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
   if (OAM_RDI_event(pTable, OAM_SEG) != 0) {
		syslog(LOG_INFO,"Event OAM_RDI_EVENT failed!\n");
      OAMPRINTF("Event OAM_RDI_EVENT failed!\n");
   }
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/
	
	timerDelete (pTable->seg_rdi_recovery_timer);
	pTable->seg_rdi_recovery_timer = 0;

   lock_set(&pTable->tbl_lock);
}



void f4_seg_rdi_alarm_timer(unsigned long vpi)
{
	VPCI *pTable;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	/* Get vpci table pointer */
	pTable = (vpciPtr)getVpciPtr(vpi,0);
	if (pTable == NULL) {
		perror("f4_seg_rdi_recovery_timer: ");
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return;
	}

   lock_get(&pTable->tbl_lock);

   if (pTable->rdi_seg_state == OAM_RDI_DEFECT) {
	   syslog(LOG_ERR, "Segment VPI: %lu Failure", vpi);
	   OAMPRINTF("oam [%s]: Segement VPI: %lu Failure\n", __FUNCTION__, vpi);

   	pTable->rdi_seg_state = OAM_RDI_FAILURE;

      pTable->cell_counters.oam_rdi_fail_count++;

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
      if (OAM_RDI_event(pTable, OAM_SEG) != 0) {
		   syslog(LOG_INFO,"Event OAM_RDI_EVENT failed!\n");
         OAMPRINTF("Event OAM_RDI_EVENT failed!\n");
      }
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/
   }
	
	timerDelete (pTable->seg_rdi_alarm_timer);
	pTable->seg_rdi_alarm_timer = 0;

   lock_set(&pTable->tbl_lock);
}
#endif /* #ifdef INCLUDE_IFX_OAM_RDI*/



#ifdef INCLUDE_IFX_OAM_AIS
void f4_seg_ais_recovery_timer(unsigned long vpi)
{
	VPCI *pTable;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	syslog(LOG_ERR, "Segment VPI: %lu Functional", vpi);
	OAMPRINTF("oam [%s]: Segement VPI: %lu Functional\n", __FUNCTION__, vpi);

	/* Get vpci table pointer */
	pTable = (vpciPtr)getVpciPtr(vpi,0);
	if (pTable == NULL) {
		perror("f4_seg_ais_recovery_timer: ");
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return;
	}

   lock_get(&pTable->tbl_lock);

	pTable->ais_seg_state = OAM_NORMAL;

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
   if (OAM_AIS_event(pTable, OAM_SEG, OAM_FALSE) != 0) {
		syslog(LOG_INFO,"Event OAM_AIS_EVENT failed!\n");
      OAMPRINTF("Event OAM_AIS_EVENT failed!\n");
   }
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/

	timerReset(pTable->seg_ais_alarm_timer, 
				1, INFI_TIMER_ONESHOT);
	
	timerDelete (pTable->seg_ais_recovery_timer);
	pTable->seg_ais_recovery_timer = 0;

   lock_set(&pTable->tbl_lock);
}



void f4_seg_ais_alarm_timer(unsigned long vpi)
{
	VPCI *pTable;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	/* Get vpci table pointer */
	pTable = (vpciPtr)getVpciPtr(vpi,0);
	if (pTable == NULL) {
		perror("f4_seg_ais_recovery_timer: ");
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return;
	}

   lock_get(&pTable->tbl_lock);

   if (pTable->ais_ete_state == OAM_AIS_DEFECT) {
	   syslog(LOG_ERR, "Segment VPI: %lu Failure", vpi);
	   OAMPRINTF("oam [%s]: Segement VPI: %lu Failure\n", __FUNCTION__, vpi);

   	pTable->ais_ete_state = OAM_AIS_FAILURE;

      pTable->cell_counters.oam_ais_fail_count++;

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
      if (OAM_AIS_event(pTable, OAM_SEG, OAM_FALSE) != 0) {
		   syslog(LOG_INFO,"Event OAM_AIS_EVENT failed!\n");
         OAMPRINTF("Event OAM_AIS_EVENT failed!\n");
      }
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/
   }


	timerDelete (pTable->seg_ais_alarm_timer);
	pTable->seg_ais_alarm_timer = 0;

   lock_set(&pTable->tbl_lock);
}
#endif /* #ifdef INCLUDE_IFX_OAM_AIS*/

#endif /* F5_OPTIMIZED */



/* 
	On reception of VC_AIS e_t_e cells, VP is marked to be in defect state 
	and RDI cells are generated at the VPC sink point. if no AIS is received 
	for 2.5 sec, VP is returned to normal state. 
*/ 
void process_f5_ete( OAM_CELL* pCell, u_int32_t vpi, u_int32_t vci)
{
	vpciPtr		pTable;
#ifdef INCLUDE_IFX_OAM_CC
	char	eventId;
#endif /* #ifdef INCLUDE_IFX_OAM_CC*/
	u_int32_t	vpiVci=0;
	
	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	pTable = (VPCI *)getVpciPtr(vpi,vci);
	if (pTable == NULL) {
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return;
	}

	vpiVci = (vpi << 16) & 0x00FF0000;
	vpiVci = vpiVci | (vci & 0x0000FFFF);

	if(pTable == NULL)
		perror("f5 ete");

   lock_get(&pTable->tbl_lock);

   switch (pCell->cell[OAM_TYPE_FN]) {
#ifdef INCLUDE_IFX_OAM_AIS
   case OAM_AIS:
		putchar('a');
		fflush(stdout);

      pTable->cell_counters.oam_ais_rx++;

		if (pTable->ais_ete_state == OAM_NORMAL) {
			/* syslog the failure */
			syslog(LOG_ERR," f5 ete ais failure : VPI:%d, VCI:%d Failed\n",vpi,vci);

			/*mark f4_ete_AIS_state in VPtable.*/
			pTable->ais_ete_state = OAM_AIS_DEFECT;

         /* 3.5 sec timer to generate user alarm and to change
         the state to failure */ 
			if (!pTable->ete_ais_alarm_timer) {
				OAMPRINTF("creating f5 ete ais alarm timer \n");
				pTable->ete_ais_alarm_timer = 
					timerCreate(
						INFI_TIMER_ONESHOT,
						f5_ete_ais_alarm_timer,
						(unsigned long)vpiVci);
			}

			timerStart(pTable->ete_ais_alarm_timer,
						(unsigned int)pTable->fsm_timer_cfg.oam_ais_persist, 
						INFI_TIMER_ONESHOT);

			/* in case no AIS is received for 2.5 sec return 
			to normal state. to be initialized in case of cc, user
			cell appears on this VP, Driver to indicate arrival  of 
			user cell */
			if (!pTable->ete_ais_recovery_timer) {
				OAMPRINTF("creating f5 ete ais recovery timer \n");
				pTable->ete_ais_recovery_timer = 
					timerCreate(
						INFI_TIMER_ONESHOT,
						f5_ete_ais_recovery_timer,
						(unsigned long)vpiVci);
			}
			timerStart(pTable->ete_ais_recovery_timer,
						(unsigned int)pTable->fsm_timer_cfg.oam_ais_not_rx,
						INFI_TIMER_ONESHOT);

			/* Send RDI cell in opposite direction */ 
			pCell->cell[OAM_TYPE_FN] = OAM_RDI;
			send_oam(pCell);

			/*Transmit AIS in forward direction: Not used in our case */
			send_ais();
		}
		else {
			timerReset(pTable->ete_ais_recovery_timer,
						(unsigned int)pTable->fsm_timer_cfg.oam_ais_not_rx, 
						INFI_TIMER_ONESHOT);

			/* Send RDI cell in opposite direction */ 
			pCell->cell[OAM_TYPE_FN] = OAM_RDI;
			send_oam(pCell);

			/*Transmit AIS in forward direction: Not used in our case */
			send_ais();
		}
      break;
#endif /* #ifdef INCLUDE_IFX_OAM_AIS*/

#ifdef INCLUDE_IFX_OAM_RDI
   case OAM_RDI:
		putchar('r');
		fflush(stdout);

      pTable->cell_counters.oam_rdi_rx++;

		/* First RDI cell receoved */
		if (pTable->rdi_ete_state == OAM_NORMAL) {
			pTable->rdi_ete_state = OAM_RDI_DEFECT;

         /* 3.5 sec timer to generate user alarm and to change
         the state to failure */ 
			if (!pTable->ete_rdi_alarm_timer) {
				OAMPRINTF("creating f5 ete rdi alarm timer \n");
				pTable->ete_rdi_alarm_timer = 
					timerCreate(
						INFI_TIMER_ONESHOT,
						f5_ete_rdi_alarm_timer,
						(unsigned long)vpiVci);
			}

			timerStart(pTable->ete_rdi_alarm_timer,
						(unsigned int)pTable->fsm_timer_cfg.oam_rdi_persist, 
						INFI_TIMER_ONESHOT);


			/* syslog failure */
			syslog(LOG_ERR," f5 ete rdi failure : VPI:%d, VCI:%d Failed\n",vpi,vci);

			/* in case no RDI is received for 2.5 sec return 
			to normal state. to be initialized in case of cc, user
			cell appears on this VP, Driver to indicate arrival  of 
			user cell */
			if (!pTable->ete_rdi_recovery_timer) {
				OAMPRINTF("creating f5 ete rdi recovery timer \n");
				pTable->ete_rdi_recovery_timer= 
					timerCreate(
						INFI_TIMER_ONESHOT,
						f5_ete_rdi_recovery_timer,
						(unsigned long)vpiVci);
			}
			timerStart(pTable->ete_rdi_recovery_timer,
						(unsigned int)pTable->fsm_timer_cfg.oam_rdi_not_rx, 
						INFI_TIMER_ONESHOT);
		}
		else {
			timerReset(pTable->ete_rdi_recovery_timer,
					(unsigned int)pTable->fsm_timer_cfg.oam_rdi_not_rx, 
					INFI_TIMER_ONESHOT);
		}
      break;
#endif /* #ifdef INCLUDE_IFX_OAM_RDI*/

#ifdef INCLUDE_IFX_OAM_F5_LOOPBACK
   case OAM_LB:
		putchar('l');
		fflush(stdout);
		process_loopback(pTable, pCell, OAM_ETE);
      break;
#endif /* #ifdef INCLUDE_IFX_OAM_LOOPBACK*/

#ifdef INCLUDE_IFX_OAM_CC
   case OAM_ACTIVATION_CC:
		eventId = (pCell->cell[OAM_CC_MSGID_AND_DIR] >>2) ;
		eventId = getEvent(eventId);
		if (eventId <0) {
			OAMPRINTF("Invalid Event\n");
			return;
		}
		putchar('c');
		fflush(stdout);
		activate_cc(pTable, OAM_ETE, pCell, eventId );
      break;
#endif /* #ifdef INCLUDE_IFX_OAM_CC*/
   default:
      break;
   }

   lock_set(&pTable->tbl_lock);
}



/* 
	On reception of VP_AIS segment cells, VP is marked to be in 
	defect state and RDI cells are generated at the VPC sink point. 
	if no AIS is received for 2.5 sec, VP is returned to normal state. 
	Segment are specified by the network manager. 
*/ 

void  process_f5_seg( OAM_CELL* pCell, u_int32_t vpi, u_int32_t vci)
{
	VPCI	*pTable;
	unsigned long vpiVci;
#ifdef INCLUDE_IFX_OAM_CC
	char eventId;
#endif /* #ifdef INCLUDE_IFX_OAM_CC*/

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	if (!check_segment(pCell)) {
		OAMPRINTF("\nOAM: Segment failure ");
		return;
		}
	
	pTable = (vpciPtr)getVpciPtr(vpi,vci);
	if (pTable == NULL) {
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return;
	}

	vpiVci = (vpi << 16) & 0x00FF0000;
	vpiVci = vpiVci | (vci & 0x0000FFFF);

	if (pTable == NULL) {
		OAMPRINTF("\nOAM Couldnt get VPCI table pointer ");
		return;
	}

   lock_get(&pTable->tbl_lock);

   switch (pCell->cell[OAM_TYPE_FN]) {
#ifdef INCLUDE_IFX_OAM_AIS
   case OAM_AIS:
		putchar('a');
		fflush(stdout);

      pTable->cell_counters.oam_ais_rx++;

		/* First AIS cell received */
		if (pTable->ais_seg_state == OAM_NORMAL) {
			/* syslog the failure */
			syslog(LOG_ERR," f5 seg ais failure : VPI:%d, VCI:%d Failed\n",vpi,vci);

			/*mark f4_ete_AIS_state in VPtable.*/
			pTable->ais_seg_state = OAM_AIS_DEFECT;

         /* 3.5 sec timer to generate user alarm and to change
         the state to failure */ 
			if (!pTable->seg_ais_alarm_timer) {
				OAMPRINTF("creating f5 ete ais alarm timer \n");
				pTable->seg_ais_alarm_timer = 
					timerCreate(
						INFI_TIMER_ONESHOT,
						f5_seg_ais_alarm_timer,
						(unsigned long)vpiVci);
			}

			timerStart(pTable->seg_ais_alarm_timer,
						(unsigned int)pTable->fsm_timer_cfg.oam_ais_persist, 
						INFI_TIMER_ONESHOT);
			
			/* in case no AIS is received for 2.5 sec return 
			to normal state. to be initialized in case of cc, user
			cell appears on this VP, Driver to indicate arrival  of 
			user cell */
			if (!pTable->seg_ais_recovery_timer) {
				pTable->seg_ais_recovery_timer = 
					timerCreate(
						INFI_TIMER_ONESHOT,
						f5_seg_ais_recovery_timer, 
						(unsigned long)vpiVci);
			}

			timerStart(pTable->seg_ais_recovery_timer,
					(unsigned int)pTable->fsm_timer_cfg.oam_ais_not_rx,
					INFI_TIMER_ONESHOT);

			/* Send RDI cell in opposite direction */ 
			pCell->cell[OAM_TYPE_FN] = OAM_RDI;
			send_oam(pCell);

			/*Transmit AIS in forward direction: Not used in our case */
			send_ais();
		}
		else {
			timerReset(pTable->seg_ais_recovery_timer,
				(unsigned int)pTable->fsm_timer_cfg.oam_ais_not_rx, 
				INFI_TIMER_ONESHOT);

			/* Send RDI cell in opposite direction */ 
			pCell->cell[OAM_TYPE_FN] = OAM_RDI;
			send_oam(pCell);

			/*Transmit AIS in forward direction: Not used in our case */
			send_ais();
		}
      break;
#endif /* #ifdef INCLUDE_IFX_OAM_AIS*/

#ifdef INCLUDE_IFX_OAM_RDI
   case OAM_RDI:
		putchar('r');
		fflush(stdout);

      pTable->cell_counters.oam_rdi_rx++;

		/* received first RDI cell */
		if (pTable->rdi_seg_state == OAM_NORMAL) {
			
			pTable->rdi_seg_state = OAM_RDI_DEFECT;

         /* 3.5 sec timer to generate user alarm and to change
         the state to failure */ 
			if (!pTable->seg_rdi_alarm_timer) {
				OAMPRINTF("creating f5 ete rdi alarm timer \n");
				pTable->seg_rdi_alarm_timer = 
					timerCreate(
						INFI_TIMER_ONESHOT,
						f5_seg_rdi_alarm_timer,
						(unsigned long)vpiVci);
			}

			timerStart(pTable->seg_rdi_alarm_timer,
						(unsigned int)pTable->fsm_timer_cfg.oam_rdi_persist, 
						INFI_TIMER_ONESHOT);


			/* syslog failure */
			syslog(LOG_ERR," f5 seg rdi failure: VPI:%d, VCI:%d Failed\n",vpi,vci);

			/* in case no RDI is received for 2.5 sec return 
			to normal state. to be initialized in case of cc, user
			cell appears on this VP, Driver to indicate arrival  of 
			user cell */
			if (!pTable->seg_rdi_recovery_timer) {
				pTable->seg_rdi_recovery_timer = 
					timerCreate(
						INFI_TIMER_ONESHOT,
						f5_seg_rdi_recovery_timer,
						(unsigned long)vpiVci);
			}
			timerStart(pTable->seg_rdi_recovery_timer,
				(unsigned int)pTable->fsm_timer_cfg.oam_rdi_not_rx, 
				INFI_TIMER_ONESHOT);
		}
		else {
				timerReset(pTable->seg_rdi_recovery_timer,
					(unsigned int)pTable->fsm_timer_cfg.oam_rdi_not_rx, 
					INFI_TIMER_ONESHOT);
		}
      break;
#endif /* #ifdef INCLUDE_IFX_OAM_RDI*/

#ifdef INCLUDE_IFX_OAM_F5_LOOPBACK
   case OAM_LB:
		putchar('l');
		fflush(stdout);
		process_loopback(pTable,pCell, OAM_SEG);
      break;
#endif /* #ifdef INCLUDE_IFX_OAM_F5_LOOPBACK*/

#ifdef INCLUDE_IFX_OAM_CC
   case OAM_ACTIVATION_CC:
		eventId = (pCell->cell[OAM_CC_MSGID_AND_DIR] >>2) ;
		eventId = getEvent(eventId);
		if (eventId < 0) {
			OAMPRINTF("Invalid Event\n");
			return;
		}
		putchar('c');
		fflush(stdout);
		activate_cc(pTable,OAM_SEG,pCell,eventId);
      break;
#endif /* #ifdef INCLUDE_IFX_OAM_CC*/
   default:
      break;
   }

   lock_set(&pTable->tbl_lock);
}



#ifdef INCLUDE_IFX_OAM_AIS
/* No AIS, RDI cell received on this VPC for 2.5 sec 
    return to normal state*/
void f5_ete_ais_recovery_timer(unsigned long vpiVci)
{
	VPCI	*pTable;
	u_int32_t vpi, vci;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	vpi = (vpiVci & 0x00FF0000) >> 16;
	vci = (vpiVci & 0x0000FFFF);

	syslog(LOG_ERR, "VPI-VCI: %d- %d Functional", vpi,vci);
	OAMPRINTF("oam [%s]: Segement VPI-VCI: %d-%d Functional\n", __FUNCTION__, vpi, vci);

	/* Get vpci table pointer */
	pTable = (vpciPtr)getVpciPtr(vpi,vci);
	if (pTable == NULL) {
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return;
	}

   lock_get(&pTable->tbl_lock);

	pTable->ais_ete_state = OAM_NORMAL;

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
   if (OAM_AIS_event(pTable, OAM_ETE, OAM_FALSE) != 0) {
		syslog(LOG_INFO,"Event OAM_AIS_EVENT failed!\n");
      OAMPRINTF("Event OAM_AIS_EVENT failed!\n");
   }
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/
	
	timerDelete (pTable->ete_ais_recovery_timer);
	pTable->ete_ais_recovery_timer=0;

   lock_set(&pTable->tbl_lock);
}



void f5_ete_ais_alarm_timer(unsigned long vpiVci)
{
	VPCI	*pTable;
	u_int32_t vpi, vci;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	vpi = (vpiVci & 0x00FF0000) >> 16;
	vci = (vpiVci & 0x0000FFFF);

	/* Get vpci table pointer */
	pTable = (vpciPtr)getVpciPtr(vpi,vci);
	if (pTable == NULL) {
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return;
	}

   lock_get(&pTable->tbl_lock);

   if (pTable->ais_ete_state == OAM_AIS_DEFECT) {
	   syslog(LOG_ERR, "VPI-VCI: %d- %d Failure", vpi,vci);
	   OAMPRINTF("oam [%s]: Segment VPI-VCI: %d-%d Failure\n", __FUNCTION__, vpi, vci);

   	pTable->ais_ete_state = OAM_AIS_FAILURE;

      pTable->cell_counters.oam_ais_fail_count++;

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
      if (OAM_AIS_event(pTable, OAM_ETE, OAM_FALSE) != 0) {
		   syslog(LOG_INFO,"Event OAM_AIS_EVENT failed!\n");
         OAMPRINTF("Event OAM_AIS_EVENT failed!\n");
      }
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/
   }

	timerDelete(pTable->ete_ais_alarm_timer);
	pTable->ete_ais_alarm_timer = 0;

   lock_set(&pTable->tbl_lock);
}
#endif /* #ifdef INCLUDE_IFX_OAM_AIS*/



#ifdef INCLUDE_IFX_OAM_RDI
/* No AIS, RDI cell received on this VPC for 2.5 sec 
    return to normal state*/
void f5_ete_rdi_recovery_timer(unsigned long vpiVci)
{
	VPCI	*pTable;
	u_int32_t vpi, vci;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	vpi = (vpiVci & 0x00FF0000) >> 16;
	vci = (vpiVci & 0x0000FFFF);

	syslog(LOG_ERR, "VPI-VCI: %d- %d Functional", vpi,vci);
	OAMPRINTF("oam [%s]: Segement VPI-VCI: %d-%d Functional\n", __FUNCTION__, vpi, vci);

	/* Get vpci table pointer */
	pTable = (vpciPtr)getVpciPtr(vpi,vci);
	if (pTable == NULL) {
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return;
	}

   lock_get(&pTable->tbl_lock);

	pTable->rdi_ete_state = OAM_NORMAL;

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
   if (OAM_RDI_event(pTable, OAM_ETE) != 0) {
		syslog(LOG_INFO,"Event OAM_RDI_EVENT failed!\n");
      OAMPRINTF("Event OAM_RDI_EVENT failed!\n");
   }
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/
	
	timerDelete (pTable->ete_rdi_recovery_timer);
	pTable->ete_rdi_recovery_timer=0;

   lock_set(&pTable->tbl_lock);
}



void f5_ete_rdi_alarm_timer(unsigned long vpiVci)
{
	VPCI	*pTable;
	u_int32_t vpi, vci;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	vpi = (vpiVci & 0x00FF0000) >> 16;
	vci = (vpiVci & 0x0000FFFF);

	/* Get vpci table pointer */
	pTable = (vpciPtr)getVpciPtr(vpi,vci);
	if (pTable == NULL) {
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return;
	}

   lock_get(&pTable->tbl_lock);

   if (pTable->rdi_ete_state == OAM_RDI_DEFECT) {
	   syslog(LOG_ERR, "VPI-VCI: %d- %d Failure", vpi,vci);
	   OAMPRINTF("oam [%s]: Segement VPI-VCI: %d-%d Failure\n", __FUNCTION__, vpi, vci);

   	pTable->rdi_ete_state = OAM_RDI_FAILURE;

      pTable->cell_counters.oam_rdi_fail_count++;

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
      if (OAM_RDI_event(pTable, OAM_ETE) != 0) {
		   syslog(LOG_INFO,"Event OAM_RDI_EVENT failed!\n");
         OAMPRINTF("Event OAM_RDI_EVENT failed!\n");
      }
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/
   }

	timerDelete(pTable->ete_rdi_alarm_timer);
	pTable->ete_rdi_alarm_timer = 0;

   lock_set(&pTable->tbl_lock);
}
#endif /* #ifdef INCLUDE_IFX_OAM_RDI*/



#ifdef INCLUDE_IFX_OAM_AIS
/* No AIS, RDI cell received on this VPC for 2.5 sec 
    return to normal state*/
void f5_seg_ais_recovery_timer(unsigned long vpiVci)
{
	VPCI	*pTable;
	u_int32_t vpi, vci;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	vpi = (vpiVci & 0x00FF0000) >> 16;
	vci = (vpiVci & 0x0000FFFF);

	syslog(LOG_INFO, "Segment VPI-VCI: %d- %d Functional", vpi,vci);
	OAMPRINTF("oam [%s]: Segment VPI-VCI: %d-%d Functional\n", __FUNCTION__, vpi, vci);

	/* Get vpci table pointer */
	pTable = (vpciPtr)getVpciPtr(vpi,vci);
	if (pTable == NULL) {
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return;
	}

   lock_get(&pTable->tbl_lock);

	pTable->ais_seg_state = OAM_NORMAL;

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
   if (OAM_AIS_event(pTable, OAM_SEG, OAM_FALSE) != 0) {
		syslog(LOG_INFO,"Event OAM_AIS_EVENT failed!\n");
      OAMPRINTF("Event OAM_AIS_EVENT failed!\n");
   }
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/
	
	timerDelete (pTable->seg_ais_recovery_timer);
	pTable->seg_ais_recovery_timer=0;

   lock_set(&pTable->tbl_lock);
}



void f5_seg_ais_alarm_timer(unsigned long vpiVci)
{
	VPCI	*pTable;
	u_int32_t vpi, vci;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	vpi = (vpiVci & 0x00FF0000) >> 16;
	vci = (vpiVci & 0x0000FFFF);

	/* Get vpci table pointer */
	pTable = (vpciPtr)getVpciPtr(vpi,vci);
	if (pTable == NULL) {
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return;
	}

   lock_get(&pTable->tbl_lock);

   if (pTable->ais_seg_state == OAM_AIS_DEFECT) {
	   syslog(LOG_ERR, "VPI-VCI: %d- %d Failure", vpi,vci);
	   OAMPRINTF("oam [%s]: Segment VPI-VCI: %d-%d Failure\n", __FUNCTION__, vpi, vci);

   	pTable->ais_seg_state = OAM_AIS_FAILURE;

      pTable->cell_counters.oam_ais_fail_count++;

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
      if (OAM_AIS_event(pTable, OAM_SEG, OAM_FALSE) != 0) {
		   syslog(LOG_INFO,"Event OAM_AIS_EVENT failed!\n");
         OAMPRINTF("Event OAM_AIS_EVENT failed!\n");
      }
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/
   }
	
	timerDelete(pTable->seg_ais_alarm_timer);
	pTable->seg_ais_alarm_timer = 0;

   lock_set(&pTable->tbl_lock);
}
#endif /* #ifdef INCLUDE_IFX_OAM_AIS*/



#ifdef INCLUDE_IFX_OAM_RDI
/* No AIS, RDI cell received on this VPC for 2.5 sec 
    return to normal state*/
void f5_seg_rdi_recovery_timer(unsigned long vpiVci)
{
	VPCI	*pTable;
	u_int32_t vpi, vci;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	vpi = (vpiVci & 0x00FF0000) >> 16;
	vci = (vpiVci & 0x0000FFFF);

	syslog(LOG_INFO, "Segment VPI-VCI: %d- %d Functional", vpi,vci);
	OAMPRINTF("oam [%s]: Segement VPI-VCI: %d-%d Functional\n", __FUNCTION__, vpi, vci);

	/* Get vpci table pointer */
	pTable = (vpciPtr)getVpciPtr(vpi,vci);
	if (pTable == NULL) {
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return;
	}

   lock_get(&pTable->tbl_lock);

	pTable->rdi_seg_state = OAM_NORMAL;

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
   if (OAM_RDI_event(pTable, OAM_SEG) != 0) {
		syslog(LOG_INFO,"Event OAM_RDI_EVENT failed!\n");
      OAMPRINTF("Event OAM_RDI_EVENT failed!\n");
   }
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/
	
	timerDelete(pTable->seg_rdi_recovery_timer);
	pTable->seg_rdi_recovery_timer=0;

   lock_set(&pTable->tbl_lock);
}



void f5_seg_rdi_alarm_timer(unsigned long vpiVci)
{
	VPCI	*pTable;
	u_int32_t vpi, vci;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	vpi = (vpiVci & 0x00FF0000) >> 16;
	vci = (vpiVci & 0x0000FFFF);

	/* Get vpci table pointer */
	pTable = (vpciPtr)getVpciPtr(vpi,vci);
	if (pTable == NULL) {
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return;
	}

   lock_get(&pTable->tbl_lock);

   if (pTable->rdi_seg_state == OAM_RDI_DEFECT) {
	   syslog(LOG_INFO, "Segment VPI-VCI: %d- %d Failure", vpi,vci);
	   OAMPRINTF("oam [%s]: Segement VPI-VCI: %d-%d Failure\n", __FUNCTION__, vpi, vci);

   	pTable->rdi_seg_state = OAM_RDI_FAILURE;

      pTable->cell_counters.oam_rdi_fail_count++;

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
      if (OAM_RDI_event(pTable, OAM_SEG) != 0) {
		   syslog(LOG_INFO,"Event OAM_RDI_EVENT failed!\n");
         OAMPRINTF("Event OAM_RDI_EVENT failed!\n");
      }
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/
   }

	timerDelete(pTable->seg_rdi_alarm_timer);
	pTable->seg_rdi_alarm_timer = 0;

   lock_set(&pTable->tbl_lock);
}
#endif /* #ifdef INCLUDE_IFX_OAM_RDI*/

/*CC*/

#ifdef INCLUDE_IFX_OAM_CC
/*
   This function implements the state machine for 
   activation and deactivation of continuity check module
*/
void activate_cc(VPCI *pTable, u_int8_t scope, OAM_CELL* pCell, u_int8_t eventId )
{
	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	if (scope == OAM_ETE) {
		CCOAMPRINTF("cc state: %d, event:%d\n",	pTable->cc_ete_state, eventId);
		cc_state_table[pTable->cc_ete_state][eventId](pTable, scope, pCell);
	}
	else if (scope == OAM_SEG) {
		CCOAMPRINTF("cc state: %d, event:%d\n", pTable->cc_seg_state, eventId);
		cc_state_table[pTable->cc_seg_state][eventId](pTable, scope, pCell);
	}

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
   if (OAM_CC_event(pTable, scope, (cc_events_t)eventId) != 0) {
		syslog(LOG_INFO,"Event OAM_CC failed!\n");
      OAMPRINTF("Event OAM_CC failed!\n");
   }
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/
}



/* 
   This function is called on getting INT_SIG_ACT_req  message from 
   ATM layer manegment in ready state. Upon receiving a CC activation 
   request from system management: Start the timer_1, send to
   peer entity activate_CC with a correlation_tag, direction and 
   block_size conveyed from system management, set counter_1 to 1, 
   and go to wait-activate-confirm state.
*/ 
int activateCC(UINT32 vpi, UINT32 vci, UINT8 scope, UINT8 dir) 
{
	vpciPtr pTable;

	OAMPRINTF("oam [%s]: vpi=%d, vci=%d, scope=%d, dir=%d\n", __FUNCTION__, vpi, vci, scope, dir);

	if ((vci == 3) || (vci==4)) {
		pTable = (vpciPtr)getVpciPtr(vpi,0);
   }
	else {
		pTable = (vpciPtr)getVpciPtr(vpi,vci);
   }

	if (pTable == NULL) {
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return -1;
	}

   lock_get(&pTable->tbl_lock);

	if (scope == OAM_ETE) {
      if (pTable->cc_ete_state != CC_READY) {
		   OAMPRINTF("oam [%s]: ETE CC is not ready!\n", __FUNCTION__);
         lock_set(&pTable->tbl_lock);
		   return -1;
      }

		if (!pTable->cc_ete_timer_1) {
			pTable->cc_ete_timer_1 =
				timerCreate(
					INFI_TIMER_ONESHOT,
					cc_timer_ete_1,
					(unsigned long)pTable);
		}
		timerStart(pTable->cc_ete_timer_1,
			OAM_CC_TIME_1,
			INFI_TIMER_ONESHOT);

		pTable->cc_ete_counter_1 = 1;
		pTable->cc_ete_state = CC_WAIT_ACT_CON;
		pTable->cc_ete_direction = dir;
	}
	else if (scope == OAM_SEG) {
      if (pTable->cc_seg_state != CC_READY) {
		   OAMPRINTF("oam [%s]: SEG CC is not ready!\n", __FUNCTION__);
         lock_set(&pTable->tbl_lock);
		   return -1;
      }

		if(!pTable->cc_seg_timer_1) {
			pTable->cc_seg_timer_1 =
				timerCreate(
					INFI_TIMER_ONESHOT,
					cc_timer_seg_1,
					(unsigned long)pTable);
		}
		timerStart(pTable->cc_seg_timer_1,
			OAM_CC_TIME_1,
			INFI_TIMER_ONESHOT);

		pTable->cc_seg_counter_1 = 1;
		pTable->cc_seg_state = CC_WAIT_ACT_CON;
		pTable->cc_seg_direction = dir;
	}

   lock_set(&pTable->tbl_lock);

	syslog(LOG_INFO,"sending Activate\n");
	OAMPRINTF("oam [%s]: Sending Activate\n", __FUNCTION__);
	send_cc_res(pTable, scope, OAM_ACTIVATE_REQUEST);

	return 0;
}



/* 
   This function is called on getting Activate message from remote end
   in ready state. Upon receiving an activate_CC: Send a CC activation 
   request indication to system management, start the timer_2, and 
   go to wait-activate-response state.
*/ 
int ready2ActRes(vpciPtr pTable, u_int8_t scope, OAM_CELL* cell) 
{
	syslog(LOG_INFO,"Recieved Activate\n");
	OAMPRINTF("oam [%s]: Recieved Activate\n", __FUNCTION__);

	if(scope == OAM_ETE) {
      pTable->cc_ete_state = CC_WAIT_ACT_RES;	
      actRes2Active(pTable, scope, cell); 		
	}
	else if (scope == OAM_SEG) {
      pTable->cc_seg_state = CC_WAIT_ACT_RES;	
      actRes2Active(pTable, scope, cell); 		
	}

	return 0;	
}



/*  This function is called when CC_DEACTIVATE event is recieved 
    in ready state
*/
int ready2Deact(vpciPtr pTable, u_int8_t scope, OAM_CELL* pCell) 
{
	syslog(LOG_INFO,"Sending Deactivate\n");
	OAMPRINTF("oam [%s]: Sending Deactivate\n", __FUNCTION__);

	send_cc_res(pTable, scope, OAM_DEACTIVATE_CONFIRMED); 

	return 0;
}



/* 
   This function is called on getting INT_SIG_ACT_res  
   message from ATM layer management. If system management accepts 
   this request: Stop timer_2, send to peer entity CC_activation_confirmed; 
   activate the CC process; and go to active state.
*/ 
void actRes2Active(vpciPtr pTable, u_int8_t scope, OAM_CELL* pCell) 
{
	UINT8 cc_dir = 0, retval = OAM_FALSE;
			
	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	if (scope == OAM_ETE) {
		pTable->cc_ete_direction = pCell->cell[OAM_CC_MSGID_AND_DIR] & OAM_MASK_DIR;

		if (!pTable->cc_ete_direction) {
			CCOAMPRINTF("Error Received Direction\n ");
			return;
		}

		cc_dir = pTable->cc_ete_direction; 
		pTable->cc_ete_state = CC_ACTIVE;

		retval = OAM_TRUE;
	}
	else if (scope == OAM_SEG) {
		cc_dir = pTable->cc_seg_direction = pCell->cell[OAM_CC_MSGID_AND_DIR] & OAM_MASK_DIR;

		if (!pTable->cc_seg_direction) {
			CCOAMPRINTF("\n Error Received Direction ");
			return;
		}

		pTable->cc_seg_state = CC_ACTIVE;

		retval = OAM_TRUE;
	}

	if (cc_dir & OAM_MASK_DIR_BA) {
		CCOAMPRINTF("activating CC tx timer\n");

      pTable->cc_active[scope] = OAM_TRUE;

		if (!pTable->cc_tx_timer[scope]) {
			pTable->cc_tx_timer[scope] = 
				timerCreate(
					INFI_TIMER_PERIODIC, 
					cc_tx_timer[scope],
					(unsigned long)pTable);
		}
		timerStart(pTable->cc_tx_timer[scope],
			OAM_CC_TX_TIME, 
			INFI_TIMER_PERIODIC);
	}

	if (retval == OAM_TRUE) {
		pCell->cell[OAM_CC_MSGID_AND_DIR] = cc_dir | OAM_ACTIVATE_CONFIRMED;
		syslog(LOG_INFO,"sending activate con\n");
		send_oam(pCell);
	}
}



void tx_ete_cc( unsigned long vpTable)
{
	OAM_CELL *pCell;
	vpciPtr pTable = (vpciPtr)vpTable;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

   lock_get(&pTable->tbl_lock);

   if (!pTable->cc_active[OAM_ETE]) {
		timerStop(pTable->cc_tx_timer[OAM_ETE]);
		timerDelete(pTable->cc_tx_timer[OAM_ETE]);
		pTable->cc_tx_timer[OAM_ETE] = 0;
      return;
   }

	if (pTable->cc_ete_state == CC_ACTIVE) {
		pCell = create_cc(pTable->vpi, pTable->vci, OAM_ETE);
		send_oam(pCell);
		free(pCell);

      pTable->cell_counters.oam_cc_req_tx++;
	}

   lock_set(&pTable->tbl_lock);

	return;
}



void tx_seg_cc( unsigned long vpTable)
{
	OAM_CELL *pCell;
	vpciPtr pTable = (vpciPtr)vpTable;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

   lock_get(&pTable->tbl_lock);

   if (!pTable->cc_active[OAM_SEG]) {
		timerStop(pTable->cc_tx_timer[OAM_SEG]);
		timerDelete(pTable->cc_tx_timer[OAM_SEG]);
		pTable->cc_tx_timer[OAM_SEG] = 0;
      return;
   }

	if (pTable->cc_seg_state == CC_ACTIVE) {
		pCell = create_cc(pTable->vpi, pTable->vci, OAM_SEG);
		send_oam(pCell);
		free(pCell);

      pTable->cell_counters.oam_cc_req_tx++;
	}

   lock_set(&pTable->tbl_lock);

	return;
}



/* 
   This function is called on getting Activation denied or Activate 
   message from remote node. Upon receiving a CC_activation_denied 
   or an activate_CC, or upon expiration of timer_1 and counter_1 
   is greater than or equal to CT1: Stop timer_1, send a CC 
   activation-failure indication to system management, and go to ready state. 
*/ 
int actCon2Ready(vpciPtr pTable, u_int8_t scope, OAM_CELL* pCell) 
{
	syslog(LOG_INFO,"recieved Act denined\n");
	OAMPRINTF("oam [%s]: Received Act denined\n", __FUNCTION__);

	if (scope == OAM_ETE) {
		if (pTable->cc_ete_timer_1) {
         pTable->cc_ete_counter_1 = OAM_CC_CT2;
		   timerReset(pTable->cc_ete_timer_1,
			   1, INFI_TIMER_ONESHOT);
		}

		pTable->cc_ete_state = CC_READY;
	}
	else if (scope == OAM_SEG) {
		if(pTable->cc_seg_timer_1){
         pTable->cc_seg_counter_1 = OAM_CC_CT2;
		   timerReset(pTable->cc_seg_timer_1,
			   1, INFI_TIMER_ONESHOT);
		}

		pTable->cc_seg_state = CC_READY;
	}

	return 0;
}




/* 
   This function is called on getting Activation confirmed 
   message from remote node. Upon receiving a CC_activation_confirmed: 
   Stop the timer_1; activate the CC process; send CC 
   activation-success confirmation to system management, and go to 
   active state. 
*/ 
int actCon2Active(vpciPtr pTable, u_int8_t scope, OAM_CELL* pCell) 
{
	UINT32 direction;

	syslog(LOG_INFO,"receieved Act Con\n");
	OAMPRINTF("oam [%s]: Received Act Con\n", __FUNCTION__);

	if (scope == OAM_ETE) {
		if (pTable->cc_ete_timer_1) {
			timerStop(pTable->cc_ete_timer_1);
			timerDelete(pTable->cc_ete_timer_1);
			pTable->cc_ete_timer_1=0;
		}
		pTable->cc_ete_state = CC_ACTIVE;
	}
	else if(scope == OAM_SEG) {
		if (pTable->cc_seg_timer_1) {
			timerStop(pTable->cc_seg_timer_1);
			timerDelete(pTable->cc_seg_timer_1);
			pTable->cc_seg_timer_1=0;
		}
		pTable->cc_seg_state = CC_ACTIVE;
	}
	
	direction = pCell->cell[OAM_CC_MSGID_AND_DIR] & OAM_MASK_DIR;	
	/*create 1 sec timer to send cc cell periodically */
	if (direction & OAM_MASK_DIR_AB) {
		CCOAMPRINTF("starting CC TX timer\n");

      pTable->cc_active[scope] = OAM_TRUE;

		if (!pTable->cc_tx_timer[scope]) {
			pTable->cc_tx_timer[scope] = 
				timerCreate(
					INFI_TIMER_PERIODIC,
					cc_tx_timer[scope],
					(unsigned long)pTable);
		}

		timerStart(pTable->cc_tx_timer[scope],
			OAM_CC_TX_TIME,
			INFI_TIMER_PERIODIC);
	}

	return 0;
}



/* 
   This function is called on getting INT_SIG_ACT_req  message from 
   ATM layer management. Upon receiving a deactivate_CC: Send a CC 
   deactivation request indication to system management, send to 
   peer entity CC_deactivation_confirmed, and go to ready state.
*/ 
int act2Ready(vpciPtr pTable, u_int8_t scope, OAM_CELL* pCell) 
{
	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	send_cc_res(pTable, scope, OAM_DEACTIVATE_CONFIRMED); 

	if (pTable->cc_tx_timer[scope]) {

      pTable->cc_active[scope] = OAM_FALSE;

	   timerReset(pTable->cc_tx_timer[scope],
		   1, INFI_TIMER_ONESHOT);
	}

	if (scope == OAM_ETE) {
		pTable->cc_ete_state = CC_READY;
	}
	else if (scope == OAM_SEG) {
		pTable->cc_seg_state = CC_READY;
	}

	return 0;
}




/* 
   This function is called on getting Deactivate 
   message from remote node. Upon receiving a CC deactivation 
   request from system management: Send deactivate_CC with a 
   correlation_tag and direction conveyed from system management, start 
   the timer_3, set counter_2 to 1 and go to wait-deactivate-confirm state. 
*/ 
int deActivateCC(UINT8 vpi, UINT16 vci, UINT8 scope, UINT8 dir) 
{
	vpciPtr pTable;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	if((vci == 3) || (vci==4)) {
		pTable = (vpciPtr)getVpciPtr(vpi,0);
   }
	else {
		pTable = (vpciPtr)getVpciPtr(vpi,vci);
   }

	if (pTable == NULL) {
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return -1;
	}

	OAMPRINTF("oam [%s]: Sending DeActive\n", __FUNCTION__);
	syslog(LOG_INFO,"sending DeActivate\n");

   lock_get(&pTable->tbl_lock);

	if (scope == OAM_ETE) {
		/*send Deactivate_cc to remote end */
		send_cc_res(pTable, scope, OAM_DEACTIVATE_REQUEST); 
		if (!pTable->cc_ete_timer_3) {
			pTable->cc_ete_timer_3 = 
				timerCreate(
					INFI_TIMER_ONESHOT,
					cc_timer_ete_3,
					(unsigned long)pTable);
		}
		timerStart(pTable->cc_ete_timer_3,
			OAM_CC_TIME_3,
			INFI_TIMER_ONESHOT);

		pTable->cc_ete_counter_2 = 1;
		pTable->cc_ete_state = CC_WAIT_DEACT_CON;
	}
	else if(scope == OAM_SEG) {
		/*send Deactivate_cc to remote end */
		send_cc_res(pTable, scope, OAM_DEACTIVATE_REQUEST); 
		if (!pTable->cc_seg_timer_3) {
			pTable->cc_seg_timer_3 = 
				timerCreate(
					INFI_TIMER_ONESHOT,
					cc_timer_seg_3,
					(unsigned long)pTable);
		}
		timerStart(pTable->cc_seg_timer_3,
			OAM_CC_TIME_3,
			INFI_TIMER_ONESHOT);

		pTable->cc_seg_counter_2 = 1;
		pTable->cc_seg_state = CC_WAIT_DEACT_CON;
	}

   lock_set(&pTable->tbl_lock);

	return 0;
}




/* 
   This function is called on getting Deactivate/Deact confirmed 
   message from remote node. Upon receiving a deactivate_CC: Send 
   a CC deactivation request indication to system management, send 
   to peer entity CC_deactivation_confirmed, and go to ready state.
*/ 
int deactCon2Ready(vpciPtr pTable, u_int8_t scope, OAM_CELL* pCell) 
{
	syslog(LOG_INFO,"recieved DeAct Con\n");
	OAMPRINTF("oam [%s]: Received DeAct Con\n", __FUNCTION__);

	if (scope == OAM_SEG) {
		if (pTable->cc_seg_timer_3) {
			timerStop(pTable->cc_seg_timer_3);
			timerDelete(pTable->cc_seg_timer_3);
		}
		pTable->cc_seg_timer_3 = 0;
		pTable->cc_seg_state = CC_READY;
	}
	else if (scope == OAM_ETE) {
		if (pTable->cc_ete_timer_3) {
			timerStop(pTable->cc_ete_timer_3);
			timerDelete(pTable->cc_ete_timer_3);
		}
		pTable->cc_ete_timer_3 = 0;
		pTable->cc_ete_state = CC_READY;
	}

	if (pTable->cc_tx_timer[scope]) {

      pTable->cc_active[scope] = OAM_FALSE;

	   timerReset(pTable->cc_tx_timer[scope],
		   1, INFI_TIMER_ONESHOT);
	}

	return 0;
}

/* Invalid message recieved */
int invMsg(vpciPtr pTable, u_int8_t scope, OAM_CELL* pCell) 
{
	OAMPRINTF("oam [%s]: Invalid message received\n", __FUNCTION__);
	CCOAMPRINTF("Invalid message received\n");

	return 0;
}



/*
   This function is called when CC_ACTIVATE event is recieved 
   in activate state
*/
int act2Act(vpciPtr pTable, u_int8_t scope, OAM_CELL* pCell) 
{
	CCOAMPRINTF("recieved Activate: dummy function \n");
	OAMPRINTF("oam [%s]: Received Activate: dummy function\n", __FUNCTION__);

/*	send_cc_res(pTable, scope, OAM_ACTIVATE_CONFIRMED); */

	return 0;
}




/* 
   This is the minimum waiting time for the response from the peer 
   entity (in case of receiving a request to deactivate the CC process 
   from system management). The value of T3 is  5 seconds.  This value 
   is greater than the round trip delay plus the processing time at 

   the peer entity to generate the corresponding response. In case of 
   message loss, this constant also indicates the elapsed time between 
   the generation of two consecutive deactivate_CC messages.
*/ 
void cc_timer_ete_3(unsigned long  vpTable) 
{
	vpciPtr pTable = (vpciPtr)vpTable;

	CCOAMPRINTF("in ete_3 timer\n");

   lock_get(&pTable->tbl_lock);

	if (pTable->cc_ete_counter_2 < OAM_CC_CT2) {
		pTable->cc_ete_counter_2 = pTable->cc_ete_counter_2 + 1; 
		send_cc_res(pTable, OAM_ETE, OAM_DEACTIVATE_REQUEST); 
		timerReset(pTable->cc_ete_timer_3,
			OAM_CC_TIME_3,
			INFI_TIMER_ONESHOT);
	}
	else {
#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
      if (pTable->cc_ete_state == CC_ACTIVE) {
         pTable->cc_ete_state = CC_READY;

         if (OAM_CC_event(pTable, OAM_ETE, CC_NA) != 0) {
		      syslog(LOG_INFO,"Event OAM_CC failed!\n");
            OAMPRINTF("Event OAM_CC failed!\n");
         }
      }
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/

		pTable->cc_ete_state = CC_READY;

		if (pTable->cc_tx_timer[OAM_ETE]) {

         pTable->cc_active[OAM_ETE] = OAM_FALSE;

	      timerReset(pTable->cc_tx_timer[OAM_ETE],
		      1, INFI_TIMER_ONESHOT);
		}

		if (pTable->cc_ete_timer_3) {
			timerStop(pTable->cc_ete_timer_3);
			timerDelete(pTable->cc_ete_timer_3);
			pTable->cc_ete_timer_3 = 0;
		}
	}

   lock_set(&pTable->tbl_lock);
}



void cc_timer_seg_3(unsigned long  vpTable) 
{
	vpciPtr pTable = (vpciPtr)vpTable;

	CCOAMPRINTF("in seg_3 timer\n");

   lock_get(&pTable->tbl_lock);

	if (pTable->cc_seg_counter_2 < OAM_CC_CT2) {
		pTable->cc_seg_counter_2 = pTable->cc_seg_counter_2 + 1 ;
		send_cc_res(pTable, OAM_SEG, OAM_DEACTIVATE_REQUEST); 
		timerReset(pTable->cc_seg_timer_3,
			OAM_CC_TIME_3,
			INFI_TIMER_ONESHOT);
	}
	else {
#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
      if (pTable->cc_seg_state == CC_ACTIVE) {
         pTable->cc_seg_state = CC_READY;

         if (OAM_CC_event(pTable, OAM_SEG, CC_NA) != 0) {
		      syslog(LOG_INFO,"Event OAM_CC failed!\n");
            OAMPRINTF("Event OAM_CC failed!\n");
         }
      }
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/

		pTable->cc_seg_state = CC_READY;

		timerDelete(pTable->cc_seg_timer_3);
		pTable->cc_seg_timer_3 = 0;

		if (pTable->cc_tx_timer[OAM_SEG]) {

         pTable->cc_active[OAM_SEG] = OAM_FALSE;

	      timerReset(pTable->cc_tx_timer[OAM_SEG],
		      1, INFI_TIMER_ONESHOT);
		}
	}

   lock_set(&pTable->tbl_lock);
}



/* 
   T1 is the minimum waiting time for the response from the peer 
   entity (in case of receiving a request to activate the CC process 
   from system management). The value of T1 is  5 seconds. This value 
   is greater than the round trip delay plus the processing time (whose 
   maximum value is T2) at the peer entity to generate the corresponding 
   response. In case of message loss, this constant also indicates the 
   elapsed time between the generation of two consecutive activate_CC messages.
*/ 
void cc_timer_seg_1(unsigned long  vpTable) 
{

	vpciPtr pTable = (vpciPtr)vpTable;
	CCOAMPRINTF("in seg_1 timer\n");

   lock_get(&pTable->tbl_lock);

	if (pTable->cc_seg_counter_1 < OAM_CC_CT2) {
		pTable->cc_seg_counter_1 = pTable->cc_seg_counter_1+1; 
		send_cc_res(pTable, OAM_SEG, OAM_ACTIVATE_REQUEST); 
		timerReset(pTable->cc_seg_timer_1,
			OAM_CC_TIME_1,
			INFI_TIMER_ONESHOT);
	}
	else {
		pTable->cc_seg_state = CC_READY;
		timerDelete(pTable->cc_seg_timer_1);
		pTable->cc_seg_timer_1 = 0;
	}

   lock_set(&pTable->tbl_lock);
}



void cc_timer_ete_1(unsigned long vpTable) 
{
	vpciPtr pTable = (vpciPtr)vpTable;

	CCOAMPRINTF("oam [%s]: in ete_1 timer\n", __FUNCTION__);

   lock_get(&pTable->tbl_lock);

	if (pTable->cc_ete_counter_1 < OAM_CC_CT2){
		pTable->cc_ete_counter_1 = pTable->cc_ete_counter_1 + 1; 
		send_cc_res(pTable, OAM_ETE, OAM_ACTIVATE_REQUEST); 
		timerReset(pTable->cc_ete_timer_1,
			OAM_CC_TIME_1,
			INFI_TIMER_ONESHOT);
	}
	else {
		pTable->cc_ete_state = CC_READY;
		timerDelete(pTable->cc_ete_timer_1);
		pTable->cc_ete_timer_1 = 0;
	}

   lock_set(&pTable->tbl_lock);
}



/*
   This function is called to send CC activation/deactivation 
   message to the remote node
*/
void send_cc_res(vpciPtr pTable, UINT8 scope, UINT8 action) 
{
	UINT8 direction=0;
	OAM_CELL* pCell;
	UINT32 vci=0,pti=0;

	if((!pTable->vci) ||(pTable->vci==3)|| (pTable->vci==4)){
		if(scope == OAM_ETE){
			pti=0;
			vci=4;
			direction = pTable->cc_ete_direction;
		}
		else if(scope==OAM_SEG){
			pti=0;	
			vci=3;
			direction = pTable->cc_seg_direction;
		}
	}
	else{
		if(scope == OAM_ETE){
			pti=5;
			vci=pTable->vci;
			direction = pTable->cc_ete_direction;
		}
		else if(scope==OAM_SEG){
			pti=4;	
			vci=pTable->vci;
			direction = pTable->cc_seg_direction;
		}
	}

	pCell = (OAM_CELL *)malloc(OAM_CELL_SIZE);
	if(!pCell){
		syslog(LOG_INFO,"\n No Memory!!");
		return ;
	}
	create_header(pCell,pTable->vpi,vci,pti);

	pCell->cell[OAM_TYPE_FN] = OAM_ACTIVATION_CC;
	pCell->cell[OAM_CC_MSGID_AND_DIR] = direction | action;
	CCOAMPRINTF("Sending cc res:%x\n",action);
	send_oam(pCell);
	free(pCell);
	
	return;	
}
#endif /* #ifdef INCLUDE_IFX_OAM_CC*/



#ifdef INCLUDE_IFX_OAM_LOOPBACK
/* This function is called on reception of f4 loopback cell */
void process_loopback(vpciPtr pTable, OAM_CELL *pCell, UINT8 scope)
{
#ifdef INCLUDE_IFX_OAM_LOOPBACK_PING
	struct amazon_atm_cell_header * amz_cell_hdr;
	int vpi,vci;
#endif /* #ifdef INCLUDE_IFX_OAM_LOOPBACK_PING*/

#if 0 /* XXX: Temp for DFE loopback. Disable for normal operation */
	pCell->cell[OAM_LB_INDICATOR] &= ~(OAM_LOOPBACK_REPLY_MASK);
#endif
	/* Loopback the received packet */
	OAMPRINTF("Inside (%s) ...\n", __FUNCTION__);

	if(!(pTable->lb_state & (OAM_LB_STATE<<scope))){
		if (pCell->cell[OAM_LB_INDICATOR] & OAM_LOOPBACK_REPLY_MASK) {
			/* loopback this cell */
			pCell->cell[OAM_LB_INDICATOR] = 0;

         pTable->cell_counters.oam_lb_req_rx++;

			goto tx_lb;
		}
		else {
			/* we are not supposed to get it */
			printf("\n we are not supposed to get it, LB_State: %d Scope:%d", pTable->lb_state, scope);

			goto discard;
		}
	}
	else { /* we are waiting for response */
		/* we might have got the response */
		if (!pCell->cell[OAM_LB_INDICATOR]& OAM_LOOPBACK_REPLY_MASK) {
			if ((*((UINT32 *)&(pCell->cell[OAM_LB_CORR_TAG]))) != 
					pTable->oam_corr_tag[scope]) {
				printf("\n Corr Tag: %d, Scope: %d", pTable->oam_corr_tag[scope], scope);
				goto discard;
			}
		   /*	if(pCell->cell[OAM_SOURCE_ID] != source_id) TBD
				   goto discard; */

			/* Ok.. we got the response
			 * , circuit is fine */
			timerStop(pTable->lb_wait_timer[scope]);

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
         pTable->lb_consec_fail_cnt = 0;
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/

         pTable->cell_counters.oam_lb_reply_rx++;

#ifdef INCLUDE_IFX_OAM_LOOPBACK_PING
         if (pTable->ping_active) {
			   if(pTable->oam_pings) {
				   struct itimerspec ispec;
				   int ms = 0;

					 bzero(&ispec, sizeof(ispec));

				   amz_cell_hdr = (struct amazon_atm_cell_header *)pCell->cell;
				   vpi = amz_cell_hdr->bit.vpi;
				   vci = amz_cell_hdr->bit.vci;
				   pTable->oam_pings--;
				   pTable->num_cells_rx ++;
				   timerPending(pTable->lb_tx_timer[scope],
						   &ispec);
				   ms = (ispec.it_interval.tv_sec - ispec.it_value.tv_sec) * 1000 + (ispec.it_interval.tv_nsec - ispec.it_value.tv_nsec) / 1000000; 
				   pTable->avg_resp_time += ms;
				   if (ms > pTable->max_resp_time)
					   pTable->max_resp_time = ms;
				   if (ms < pTable->min_resp_time)
					   pTable->min_resp_time = ms;

				   if (pTable->oam_pings == 0) {
					   update_oam_stats(pTable);
					   stop_loopback(vpi, vci, scope);
				   }
			   }
         }
#endif /* #ifdef INCLUDE_IFX_OAM_LOOPBACK_PING*/
		}
		else { /* cell needs to be looped back */
			pCell->cell[OAM_LB_INDICATOR] = 0;

         pTable->cell_counters.oam_lb_req_rx++;

			goto tx_lb;
		}
	}
	return;

tx_lb:
	send_oam(pCell);
   pTable->cell_counters.oam_lb_reply_tx++;
	return;

discard:
	syslog(LOG_INFO,"ERROR: Discarding packet\n");
	return;
}



/* This function will be called when user initiates the 
 * Loopback test to verify integrity of the circuit. This 
 * could be called once or periodically depending upon 
 * the configuration */
int start_loopback(UINT32 vpi, UINT32 vci, UINT8 scope, UINT32 freq)
{
	vpciPtr pTable;
	UINT8 f4_f5;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	printf ("%s called with vpi = %d vci = %d\n", __FUNCTION__, vpi, vci);
	if(freq < 1) {
		syslog(LOG_INFO,"Error: Loopback frequency \n");
		return -1;
	}

   if((vci == 3) ||(vci == 4)) {
      pTable = (vpciPtr)getVpciPtr(vpi,0);
		f4_f5  = OAM_F4;
		/* f4 socket will not be opend so we open it here*/
		enable_oam(vpi,vci);
   }
   else {
      pTable = (vpciPtr)getVpciPtr(vpi,vci);
		f4_f5  = OAM_F5;
   }

	if(pTable == NULL){
		perror("oam: tx_loopback");
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return -1;
	}

#ifdef INCLUDE_IFX_OAM_LOOPBACK_PING
	if(scope == 4) {
		OAMPRINTF("oam ping enabled\n");
		
		pTable->oam_pings = freq >> 16; /* MSW contains # cells tx*/
		freq &= 0xFFFF;
		scope = OAM_ETE;
		pTable->min_resp_time = -1;
		pTable->max_resp_time = 0;
		pTable->avg_resp_time = 0;
      pTable->ping_active   = OAM_TRUE;
	}
#endif /* #ifdef INCLUDE_IFX_OAM_LOOPBACK_PING*/

   pTable->loopback_active[scope] = OAM_TRUE;

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
   pTable->lb_consec_fail_cnt = 0;
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/

	/* pTable->vci = vci;*/
	freq *= INFI_TICK;    /* convert to ticks */
	freq /= 1000; /* In case of OAM ping, timeout is in ms */
	pTable->ping_freq      = freq;
	pTable->lb_freq[scope] = freq;
   pTable->ping_timeout   = freq-10;
	
	if(pTable->lb_state & (OAM_LB_STATE<<scope) ) {
		CCOAMPRINTF("Already in Loopback state \n");
		return -1;
	}

	pTable->lb_state |= (OAM_LB_STATE<<scope) ;
	if(pTable->lb_state >2)
		syslog(LOG_INFO,"ERROR: state cant be 3\n");

	if(!pTable->lb_tx_timer[scope]) {
		pTable->lb_tx_timer[scope] = timerCreate(
			INFI_TIMER_PERIODIC,
			lb_tx_func[f4_f5][scope],
			(unsigned long)pTable);
	}

	if(!pTable->lb_wait_timer[scope]) {
		pTable->lb_wait_timer[scope] = timerCreate(
			INFI_TIMER_ONESHOT,
			lb_wait_func[scope],
			(unsigned long)pTable);
	}

	timerStart(pTable->lb_tx_timer[scope],
      /*freq + 4,*/
      freq,
		INFI_TIMER_PERIODIC);

	return 0;
}



/*
   This function will be called when user termiates the 
   Loopback test to verify integrity of the circuit. This 
   could be called once or periodically depending upon 
   the configuration
*/
int stop_loopback(UINT8 vpi,UINT32 vci, UINT8 scope)
{
	vpciPtr pTable;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);


	if((vci == 3) ||(vci ==4)) {
		pTable = (VPCI *)getVpciPtr(vpi,0);
	}
	else {
		pTable = (VPCI *)getVpciPtr(vpi,vci);
	}

	if(pTable == NULL) {
		perror("tx_loopback");
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return -1;
	}

	/* Reset ping values */
	pTable->num_cells_rx  = 0;
	pTable->min_resp_time = -1;
	pTable->max_resp_time = 0;
	pTable->avg_resp_time = 0;
   pTable->ping_active   = 0;

	if(!(pTable->lb_state & (OAM_LB_STATE<<scope))){
		syslog(LOG_INFO,"Not in Loopback state \n");
		return -1;
	}

   /* Charge both timers for removal inside the corresponding CB*/
	timerReset(pTable->lb_tx_timer[scope],
		1, INFI_TIMER_ONESHOT);
	timerReset(pTable->lb_wait_timer[scope],
		1, INFI_TIMER_ONESHOT);

   pTable->loopback_active[scope] = OAM_FALSE;

   pTable->lb_state &= ~(OAM_LB_STATE<<scope) ;

	return 0;
}

void ete_lb_fail(unsigned long Table)
{
	vpciPtr pTable;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	pTable = (vpciPtr)Table;

	OAMPRINTF("oam [%s]: Table = 0x%lx, pTable = %p\n", __FUNCTION__, Table, pTable);

   lock_get(&pTable->tbl_lock);

   if (!pTable->loopback_active[OAM_ETE]) {
      /* Remove LB fail timer*/
	   if(pTable->lb_wait_timer[OAM_ETE]) {
		   timerStop(pTable->lb_wait_timer[OAM_ETE]);
		   timerDelete(pTable->lb_wait_timer[OAM_ETE]);
	   }
	   pTable->lb_wait_timer[OAM_ETE] = 0;

      lock_set(&pTable->tbl_lock);
      return;
   }

	if((pTable->vci ==3) ||
		(pTable->vci ==4) ||
		(pTable->vci ==0)) { 
		syslog(LOG_INFO,"Loopback end to end failure VPI: %d\n", pTable->vpi);
		OAMPRINTF("Loopback end to end failure VPI: %d\n", pTable->vpi);
	}
	else {
		syslog(LOG_INFO,"Loopback end to end failure VPI/VCI: %d/%d\n", pTable->vpi, pTable->vci);
		OAMPRINTF("Loopback end to end failure VPI/VCI: %d/%d\n", pTable->vpi, pTable->vci);
	}

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
   if (OAM_Fx_LB_FAIL_event(pTable, OAM_ETE) != 0) {
		syslog(LOG_INFO,"Event OAM_Fx_LB_FAIL failed!\n");
      OAMPRINTF("Event OAM_Fx_LB_FAIL failed!\n");
   }
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/

#ifdef INCLUDE_IFX_OAM_LOOPBACK_PING
   if (pTable->ping_active) {
      /* Itf its for PING, write to file and clear timers */
	   if(pTable->oam_pings) {
		   pTable->oam_pings--;
		   if(pTable->oam_pings == 0) {
			   update_oam_stats(pTable);

			   stop_loopback(pTable->vpi, pTable->vci, OAM_ETE);
	      }
	   }
   }
#endif /* #ifdef INCLUDE_IFX_OAM_LOOPBACK_PING*/

   lock_set(&pTable->tbl_lock);
}

void seg_lb_fail(unsigned long Table)
{
	vpciPtr pTable;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	pTable = (vpciPtr)Table;

   lock_get(&pTable->tbl_lock);

   if (!pTable->loopback_active[OAM_SEG]) {
      /* Remove LB fail timer*/
	   if(pTable->lb_wait_timer[OAM_SEG]) {
		   timerStop(pTable->lb_wait_timer[OAM_SEG]);
		   timerDelete(pTable->lb_wait_timer[OAM_SEG]);
	   }
	   pTable->lb_wait_timer[OAM_SEG] = 0;

      lock_set(&pTable->tbl_lock);
      return;
   }

	/* syslog) */
	if((pTable->vci ==3) ||
      (pTable->vci ==4) ||
      (pTable->vci ==0)) { 
		syslog(LOG_INFO,"f4 Loopback segment failure VPI:%d\n",
				pTable->vpi);
	}
	else{
		syslog(LOG_INFO,"f5 Loopback segment failure VPI/VCI:%d/ %d\n",
				pTable->vpi, pTable->vci);
	}

#ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT
   if (OAM_Fx_LB_FAIL_event(pTable, OAM_SEG) != 0) {
		syslog(LOG_INFO,"Event OAM_Fx_LB_FAIL failed!\n");
   }
#endif /* #ifdef INCLUDE_IFX_OAM_EVENT_SCRIPT*/

   lock_set(&pTable->tbl_lock);
}
#endif /* #ifdef INCLUDE_IFX_OAM_LOOPBACK*/


#ifdef INCLUDE_IFX_OAM_AIS
INT32 send_ais(void)
{
	/* dummy function */
	OAMPRINTF("oam [%s]: dummy function\n", __FUNCTION__);
	return 0;
}
#endif /* #ifdef INCLUDE_IFX_OAM_AIS */



vpciPtr getVpciPtr(UINT32 vpi, UINT32 vci)
{
	vpciPtr currPtr = vpciHead;
	vpciPtr vpiPtr = vpciHead;
	vpciPtr vciPtr = NULL;
	char found = OAM_FALSE;
	UINT8 bNew = OAM_FALSE;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	if(!vpciHead){ /* first time we are here */
		vpciHead = (vpciPtr)malloc(sizeof(VPCI));
		OAMPRINTF("\noam [%s]: pTable: New Mem %d:%d\n", __FUNCTION__, vpi, vci);
		if(!vpciHead){
			syslog(LOG_INFO,"\n No Memory!!");
			OAMPRINTF("oam [%s]: No Memory\n", __FUNCTION__);
			return NULL;
		}
		memset(vpciHead,0,sizeof(VPCI));
      bNew = OAM_TRUE;
		vpciHead->vpi = vpi;
		/*vpciHead->vci = vci;*/
		vpciHead->next = NULL;
		if(!vci){
			currPtr = vpciHead;
			vpciHead->vpcTable = NULL;
		}
		else{ /* we need to return vci entry */
			vpciHead->vpcTable = (vpciPtr)malloc(sizeof(VPCI));
			OAMPRINTF("pTable:New Mem %d:%d\n",vpi,vci);
			if(!vpciHead->vpcTable){
				syslog(LOG_INFO,"\n No Memory!!");
				return 0;
			}
			memset(vpciHead->vpcTable,0,sizeof(VPCI));
         bNew = OAM_TRUE;
			currPtr = vpciHead->vpcTable;
			currPtr->vpi = vpi;
			currPtr->vci = vci;
			currPtr->next = NULL;
			currPtr->vpcTable = NULL;
		}
	}
	else{ /* there are some entries in the list */
		/* search the entry */
		while(vpiPtr ){
			if(vpiPtr->vpi == vpi){
				if(!vci){
					found = OAM_TRUE;
					currPtr=vpiPtr;
					break;
				} /*if !vci*/
				else{
					vciPtr=vpiPtr->vpcTable;
					if(!vciPtr ){
						vpiPtr->vpcTable = (vpciPtr)malloc(sizeof(VPCI));	
						OAMPRINTF("pTable:New Mem %d:%d\n",vpi,vci);
						if(!vpiPtr->vpcTable){
							syslog(LOG_INFO,"\n No Memory!!");
							return 0;
						}
						memset(vpiPtr->vpcTable,0,sizeof(VPCI));
                  bNew = OAM_TRUE;
						currPtr = vpiPtr->vpcTable;
						currPtr->vpi = vpi;
						currPtr->vci = vci;
						currPtr->next = NULL;
						currPtr->vpcTable = NULL;
						found = OAM_TRUE;
					}
					while(vciPtr){
						if(vciPtr->vci ==vci){
							found=OAM_TRUE;	
							currPtr=vciPtr;
							break;
						}/*if vci*/
						currPtr = vciPtr;
						vciPtr=vciPtr->next;
					} /*while vciPtr*/
					if(!found){
									currPtr->next = (vpciPtr)malloc(sizeof(VPCI));
									if(currPtr->next == NULL){	
													syslog(LOG_INFO,"\n malloc failue no memory");
													return NULL;
									}
									OAMPRINTF("pTable:New Mem %d:%d\n",vpi,vci);
									if(!vpciHead){
													syslog(LOG_INFO,"\n No Memory!!");
													return NULL;
									}
									memset(currPtr->next,0,sizeof(VPCI));
									bNew = OAM_TRUE;
									currPtr = currPtr->next;
									currPtr->vpi = vpi;
									currPtr->vci = vci;
									currPtr->next = NULL;
									currPtr->vpcTable = NULL;
									found = OAM_TRUE;
					}
				}/*else*/
			}/*if vpi found*/	
			else{
				currPtr = vpiPtr;
				vpiPtr = vpiPtr->next;
			}
			if(found)
				break;
		} /*while vpitable*/
		if(!found){ /* didnt find vpi entry*/
			currPtr->next = (vpciPtr)malloc(sizeof(VPCI));	
			OAMPRINTF("pTable:New Mem %d:%d\n",vpi,vci);

			if(!currPtr->next){
				syslog(LOG_INFO,"\n No Memory!!");
				return NULL;
			}
			memset(currPtr->next,0,sizeof(VPCI));
         bNew = OAM_TRUE;
			currPtr = currPtr->next;
			currPtr->vpi = vpi;
			currPtr->vci = vci;
			currPtr->next = NULL;
			currPtr->vpcTable = NULL;
			found = OAM_TRUE;
			if(vci){
				currPtr->vpcTable = (vpciPtr)malloc(sizeof(VPCI));
				OAMPRINTF("pTable:New Mem %d:%d\n",vpi,vci);
				if(!currPtr->vpcTable){
					syslog(LOG_INFO,"\n No Memory!!");
					return 0;
				}
				memset(currPtr->vpcTable,0,sizeof(VPCI));
            bNew = OAM_TRUE;
				currPtr = currPtr->vpcTable;
				currPtr->vpi = vpi;
				currPtr->vci = vci;
				currPtr->next = NULL;
				currPtr->vpcTable = NULL;
			}
		}/*  if vpi not found*/
	}/*else !first entry */

   if (!currPtr->tbl_lock.bValid) {
      lock_create(&currPtr->tbl_lock);
   }

   /* Set defualt FSM timers values*/
   if (bNew) {
      currPtr->fsm_timer_cfg.oam_rdi_persist = OAM_ALARM_TIME;
      currPtr->fsm_timer_cfg.oam_rdi_not_rx  = OAM_RECOVERY_TIME;
      currPtr->fsm_timer_cfg.oam_ais_persist = OAM_ALARM_TIME;
      currPtr->fsm_timer_cfg.oam_ais_not_rx  = OAM_RECOVERY_TIME;
   }
		
	return currPtr;
}


INT32 send_oam(OAM_CELL * pCell)
{
	struct msghdr txmsg;
	struct iovec txiov;
	struct sockaddr_nl oamTxSockAdd;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	if (!pCell) {
		return -1;
	}

	txiov.iov_base = (void *)pCell;
	txiov.iov_len = OAM_CELL_SIZE;
	
	txmsg.msg_name = (void *)&oamTxSockAdd;
	txmsg.msg_namelen = sizeof(oamTxSockAdd);
	txmsg.msg_iov = &txiov;
	txmsg.msg_iovlen = 1;  
	txmsg.msg_control = NULL;
	txmsg.msg_controllen = 0;
	txmsg.msg_flags = 0;

	memset(&oamTxSockAdd,0, sizeof(oamTxSockAdd));
	oamTxSockAdd.nl_family = AF_NETLINK;
	oamTxSockAdd.nl_pid = 0;
	oamTxSockAdd.nl_groups = 0;

	storeCRC10(pCell->cell);
#ifdef OAM_DEBUG
	printf("\n Send:");
	oam_dump_data(52, pCell->cell);
#endif
	if(sendmsg(oam_sd, &txmsg,0) < 0) {
      perror("tx_oam");
      return -1;
   }

   return 0;
}



#ifdef INCLUDE_IFX_OAM_F4_LOOPBACK
void tx_seg_f4_lb(unsigned long table)
{
	vpciPtr pTable;
	OAM_CELL *pCell;
	UINT32 pti=0, corr_tag;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	pTable = (vpciPtr)table;

   lock_get(&pTable->tbl_lock);

   if (!pTable->loopback_active[OAM_SEG]) {
      /* Remove LB transmit timer*/
	   if(pTable->lb_tx_timer[OAM_SEG]) {
		   timerStop(pTable->lb_tx_timer[OAM_SEG]);
		   timerDelete(pTable->lb_tx_timer[OAM_SEG]);
	   }
	   pTable->lb_tx_timer[OAM_SEG] = 0;

      return;
   }

	corr_tag = ++(pTable->oam_corr_tag[OAM_SEG]);
	pCell = create_lb(pTable->vpi, 3, pti,corr_tag);
	send_oam(pCell);

   pTable->cell_counters.oam_lb_req_tx++;

	timerStart(pTable->lb_wait_timer[OAM_SEG],
		pTable->ping_timeout,
		INFI_TIMER_ONESHOT);

	free(pCell);

   lock_set(&pTable->tbl_lock);
}



void tx_ete_f4_lb(unsigned long table)
{
	vpciPtr pTable;
	OAM_CELL *pCell;
	UINT32 pti=0, corr_tag;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	pTable = (vpciPtr)table;

   lock_get(&pTable->tbl_lock);

   if (!pTable->loopback_active[OAM_ETE]) {
      /* Remove LB transmit timer*/
	   if(pTable->lb_tx_timer[OAM_ETE]) {
		   timerStop(pTable->lb_tx_timer[OAM_ETE]);
		   timerDelete(pTable->lb_tx_timer[OAM_ETE]);
	   }
	   pTable->lb_tx_timer[OAM_ETE] = 0;

      return;
   }

	corr_tag = ++(pTable->oam_corr_tag[OAM_ETE]);
	pCell = create_lb(pTable->vpi, 4, pti,corr_tag);
	send_oam(pCell);

   pTable->cell_counters.oam_lb_req_tx++;

	timerStart(pTable->lb_wait_timer[OAM_ETE],
		pTable->ping_timeout,
		INFI_TIMER_ONESHOT);

	free(pCell);

   lock_set(&pTable->tbl_lock);
}

#else /* #ifdef INCLUDE_IFX_OAM_F4_LOOPBACK */

void  tx_ete_f4_lb(unsigned long table)
{
	printf("\n Should not be here !!!");
}



void tx_seg_f4_lb(unsigned long table)
{
	printf("\n Should not be here !!!");
}
#endif /* #ifdef INCLUDE_IFX_OAM_F4_LOOPBACK*/


#ifdef INCLUDE_IFX_OAM_F5_LOOPBACK
void  tx_ete_f5_lb(unsigned long table)
{
	vpciPtr pTable;

	OAM_CELL *pCell;
	UINT32 pti=5, corr_tag;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	pTable = (vpciPtr)table;

   lock_get(&pTable->tbl_lock);

   if (!pTable->loopback_active[OAM_ETE]) {
      /* Remove LB transmit timer*/
	   if(pTable->lb_tx_timer[OAM_ETE]) {
		   timerStop(pTable->lb_tx_timer[OAM_ETE]);
		   timerDelete(pTable->lb_tx_timer[OAM_ETE]);
	   }

	   pTable->lb_tx_timer[OAM_ETE] = 0;
   	 lock_set(&pTable->tbl_lock);
      return;
   }

	corr_tag = ++(pTable->oam_corr_tag[OAM_ETE]);
	pCell =  create_lb(pTable->vpi, pTable->vci, pti,corr_tag);
	send_oam(pCell);

   pTable->cell_counters.oam_lb_req_tx++;

	timerStart(pTable->lb_wait_timer[OAM_ETE],
		pTable->ping_timeout,
		INFI_TIMER_ONESHOT);
	
	free(pCell);

   lock_set(&pTable->tbl_lock);
}


void tx_seg_f5_lb(unsigned long table)
{
	vpciPtr pTable;
	OAM_CELL *pCell;
	UINT32 pti=4, corr_tag;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	pTable = (vpciPtr)table;

   lock_get(&pTable->tbl_lock);

   if (!pTable->loopback_active[OAM_SEG]) {
      /* Remove LB transmit timer*/
	   if(pTable->lb_tx_timer[OAM_SEG]) {
		   timerStop(pTable->lb_tx_timer[OAM_SEG]);
		   timerDelete(pTable->lb_tx_timer[OAM_SEG]);
	   }
	   pTable->lb_tx_timer[OAM_SEG] = 0;

   lock_set(&pTable->tbl_lock);
      return;
   }

	corr_tag = ++(pTable->oam_corr_tag[OAM_SEG]);
	pCell =  create_lb(pTable->vpi, pTable->vci, 
			 pti,corr_tag);
	send_oam(pCell);

   pTable->cell_counters.oam_lb_req_tx++;

	timerStart(pTable->lb_wait_timer[OAM_SEG],
		pTable->ping_timeout,
		INFI_TIMER_ONESHOT);

	free(pCell);

   lock_set(&pTable->tbl_lock);
}
#endif /* #ifdef INCLUDE_IFX_OAM_F5_LOOPBACK*/


INT32 check_segment(OAM_CELL *pCell)
{
	/*TBD*/
	OAMPRINTF("oam [%s]: TBD\n", __FUNCTION__);
	/*507281:tc.chen return 0;*/
	return 1;
}



#ifdef INCLUDE_IFX_OAM_AIS
OAM_CELL* create_ais(UINT32 vpi, UINT16 vci, UINT32 pti)
{
	OAM_CELL *pCell;
	UINT8 i;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	pCell = (OAM_CELL *)malloc(OAM_CELL_SIZE);
	if (!pCell) {
		syslog(LOG_INFO,"\n No Memory!!");
		return NULL;
	}

	create_header(pCell,vpi,vci,pti);
	pCell->cell[OAM_TYPE_FN] = OAM_AIS;
	pCell->cell[OAM_AIS_DEFECT_TYPE] = OAM_OPTIONAL;
	for (i=0; i<16; i++)
		pCell->cell[OAM_AIS_DEFECT_LOC +i] = i; /*OAM_OPTIONAL;*/

	for (i=0; i<28; i++)
		pCell->cell[OAM_AIS_RESERV +i] = i; /*OAM_OPTIONAL;*/

	return pCell;
}
#endif /* #ifdef INCLUDE_IFX_OAM_AIS*/



#ifdef INCLUDE_IFX_OAM_RDI
OAM_CELL* create_rdi(UINT32 vpi, UINT16 vci, UINT32 pti)
{
	OAM_CELL *pCell;
	UINT8 i;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	pCell = (OAM_CELL *)malloc(OAM_CELL_SIZE);
	if (!pCell) {
		syslog(LOG_INFO,"\n No Memory!!");
		return NULL;
	}

	create_header(pCell,vpi,vci,pti);
	pCell->cell[OAM_TYPE_FN] = OAM_RDI;
	pCell->cell[OAM_AIS_DEFECT_TYPE] = OAM_OPTIONAL;
	for (i=0; i<16; i++)
		pCell->cell[OAM_AIS_DEFECT_LOC +i] = OAM_OPTIONAL;

	for (i=0; i<28; i++)
		pCell->cell[OAM_AIS_RESERV +i] = OAM_OPTIONAL;

	return pCell;
}
#endif /* #ifdef INCLUDE_IFX_OAM_RDI*/



#ifdef INCLUDE_IFX_OAM_CC
OAM_CELL* create_cc(UINT32 vpi, UINT16 vci, UINT8 scope)
{
	OAM_CELL *pCell;
	UINT8 i,pti=0;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	if ((!vci) || (vci==3) || (vci ==4)) {
		if (scope == OAM_ETE) {
			pti=0;
			vci=4;
		}
		else if (scope==OAM_SEG) {
			pti=0;	
			vci=3;
		}
	}
	else {
		if (scope == OAM_ETE) {
			pti=5;
		}
		else if (scope==OAM_SEG) {
			pti=4;	
		}
	}

	pCell = (OAM_CELL *)malloc(OAM_CELL_SIZE);
	if (!pCell) {
		syslog(LOG_INFO,"\n No Memory!!");
		return 0;
	}
	create_header(pCell,vpi,vci,pti);
	pCell->cell[OAM_TYPE_FN] = OAM_CC;
	for (i=0; i<45; i++)
		*(pCell->cell+(OAM_CC_FIELD +i)) = OAM_OPTIONAL;

	return pCell;
}
#endif /* #ifdef INCLUDE_IFX_OAM_CC*/



OAM_CELL* create_lb(UINT32 vpi, UINT16 vci, UINT32 pti,UINT32 corr_tag)
{
   OAM_CELL *pCell;
   UINT8 i;
                                                                                
   OAMPRINTF("oam [%s]\n", __FUNCTION__);

   pCell = (OAM_CELL *)malloc(OAM_CELL_SIZE);

   if (!pCell) {
      syslog(LOG_INFO,"\n No Memory!!");
      return NULL;
   }

   create_header(pCell,vpi,vci,pti);
   pCell->cell[OAM_TYPE_FN] = OAM_LB;
   pCell->cell[OAM_LB_INDICATOR] = 0x01;
   /*        *((UINT32 *)&(pCell->cell[OAM_LB_CORR_TAG])) = htonl(corr_tag);*/
   *((UINT32 *)&(pCell->cell[OAM_LB_CORR_TAG])) = corr_tag;
   for (i=0; i<16; i++)
      pCell->cell[OAM_LB_LLID +i] = OAM_LB_LLID_VAL;
                                                                          
   for (i=0; i<16; i++)
      pCell->cell[OAM_LB_SRCID +i] = OAM_LB_LLID_VAL;
                                                                          
   for (i=0; i<8; i++)
      pCell->cell[OAM_LB_UNUSED +i] = OAM_OPTIONAL;
                                                                          
   return pCell;
}


void  create_header(OAM_CELL *pCell,UINT32 vpi, UINT16 vci, UINT32 pti)
{
	struct amazon_atm_cell_header * cell_header;
                                                                                
	pCell->pid = getpid();

	cell_header = (struct amazon_atm_cell_header*) (&pCell->cell[0]);
	cell_header->bit.vpi = vpi;
	cell_header->bit.vci = vci;
	cell_header->bit.pti = pti;
	cell_header->bit.clp = 0; 
	cell_header->bit.gfc = 0; 
}



#ifdef INCLUDE_IFX_OAM_CC
char  getEvent(UINT8 eventId)
{
	switch(eventId){
		case 1:
			return 0;
		case 2:
			return 1;
		case 3:
			return 2;
		case 5:
			return 3;
		case 6:
			return 4;
		default:
			return -1;
	}
}
#endif /* #ifdef INCLUDE_IFX_OAM_CC*/



#ifdef INCLUDE_IFX_OAM_AIS
int link_failure(OAM_CELL *pCell)
{
	vpciPtr pTable;
	struct amazon_atm_cell_header * cell_header;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	cell_header = (struct amazon_atm_cell_header *)(pCell->cell);

	if ((cell_header->bit.vci == 3) ||(cell_header->bit.vci == 4)) {
		pTable = (VPCI *)getVpciPtr(cell_header->bit.vpi, 0);
	}
	else {
		pTable = (VPCI *)getVpciPtr(cell_header->bit.vpi, cell_header->bit.vci);
	}

	if (pTable == NULL) {
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return -1;
	}
	
	pTable->vci = cell_header->bit.vci;
	if (pTable->ais_ete_state || pTable->ais_seg_state) {
		syslog(LOG_INFO,"Already in failure state \n");
		return 0;
	}

	pTable->ais_ete_state = OAM_AIS_FAILURE;
	pTable->ais_seg_state = OAM_AIS_FAILURE;

	if (!pTable->link_failure_alarm) {
		pTable->link_failure_alarm = timerCreate(
			INFI_TIMER_PERIODIC,
			tx_ais,
			(unsigned long)pTable);
	}

	timerStart(pTable->link_failure_alarm,
		OAM_AIS_TX_TIME,
		INFI_TIMER_PERIODIC);

	return 0;	
}


int link_recovery(OAM_CELL *pCell)
{
	vpciPtr pTable;
	struct amazon_atm_cell_header * cell_header;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

   cell_header = (struct amazon_atm_cell_header *)(pCell->cell);

	if ((cell_header->bit.vci == 3) ||(cell_header->bit.vci ==4)) {
		pTable = (VPCI *)getVpciPtr(cell_header->bit.vpi, 0);
	}
	else {
		pTable = (VPCI *)getVpciPtr(cell_header->bit.vpi, cell_header->bit.vci);
	}

	if (pTable == NULL) {
		perror("tx_loopback");
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return -1;
	}

	pTable->ais_ete_state = OAM_NORMAL;
	pTable->ais_seg_state = OAM_NORMAL;

	if (pTable->link_failure_alarm) {
		timerStop(pTable->link_failure_alarm);
		timerDelete(pTable->link_failure_alarm);
		pTable->link_failure_alarm =0;
	}

	return 0;	
}



void tx_ais(unsigned long Table)
{
	OAM_CELL *pCell;
	vpciPtr pTable;
	
	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	pTable = (vpciPtr)Table;

	if((pTable->vci == 3) || (pTable->vci==4)) {
		pCell = create_ais(pTable->vpi, 4, 0);
	}
	else {
		pCell = create_ais(pTable->vpi, pTable->vci, 5);
	}

	send_oam(pCell);
	free(pCell);

	return;
}
#endif /* INCLUDE_IFX_OAM_AIS*/

static int oam_cell_counters_report(UINT8 vpi, UINT16 vci)
{
	vpciPtr pTable;
	char fifoname[100];
   int fd_fifo_daemon, wr_sz, ret = 0;
   OAM_FIFO_MSG_COUNTERS fifo_msg = {0};

	OAMPRINTF("oam_api [%s]: vpi[%d], vci[%d]\n", __FUNCTION__, vpi, vci);

   pTable = (vpciPtr)getVpciPtr(vpi, ((vci == 3) ||(vci == 4)) ? 0 : vci);

	if(pTable == NULL){
		perror("oam: oam_cell_counters_report");
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return -1;
	}

   /* Get unique access*/
   lock_get(&pTable->tbl_lock);

   fifo_msg.vpi = vpi;
   fifo_msg.vci = vci;

   /* Get celll counters*/
   memcpy(&(fifo_msg.cnt), &(pTable->cell_counters), sizeof(oam_cell_counters_t));

   /* Release unique access*/
   lock_set(&pTable->tbl_lock);

   MAKE_OAM_CNT_FIFONAME(vpi, (vci == 3 || vci == 4) ? 0 : vci, fifoname);

   /* make FIFO*/
   if (mkfifo(fifoname, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH) == -1 && errno != EEXIST) {
      OAMPRINTF("OAM_D: make FIFO %s failed!\n", fifoname);
      return -1;
   }

   fd_fifo_daemon = open(fifoname, O_WRONLY);

   if (fd_fifo_daemon < 0) {
      OAMPRINTF("OAM_D: open FIFO %s failed!\n", fifoname);
      return -1;
   }

   wr_sz = write(fd_fifo_daemon, &fifo_msg, sizeof(fifo_msg));

   if (wr_sz != sizeof(fifo_msg)) {
      OAMPRINTF("OAM_D: write FIFO %s %d bytes write failed!\n",
         fifoname, sizeof(fifo_msg));
      ret = -1;
   }

   close(fd_fifo_daemon);

	return ret;
}



static int oam_cell_counters_reset(UINT8 vpi, UINT16 vci)
{
	vpciPtr pTable;

	OAMPRINTF("oam_api [%s]: vpi[%d], vci[%d]\n", __FUNCTION__, vpi, vci);

   pTable = (vpciPtr)getVpciPtr(vpi, ((vci == 3) ||(vci == 4)) ? 0 : vci);

	if (pTable == NULL) {
		perror("oam: oam_cell_counters_report");
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return -1;
	}

   /* Get unique access*/
   lock_get(&pTable->tbl_lock);

   /* Get celll counters*/
   memset(&(pTable->cell_counters), 0x0, sizeof(oam_cell_counters_t));

   /* Release unique access*/
   lock_set(&pTable->tbl_lock);

   return 0;
}



static int oam_fsm_timer_config_set(
         unsigned char vpi,
         unsigned short vci,
         oam_fsm_timer_cfg_t *timer_cfg)
{
	vpciPtr pTable;

	OAMPRINTF("oam [%s]: vpi[%d], vci[%d]\n", __FUNCTION__, vpi, vci);
	OAMPRINTF("oam [%s]: oam_rdi_persist=%d oam_rdi_not_rx=%d "
	          "oam_ais_persist=%d oam_ais_not_rx=%d oam_cc_sink=%d\n",
	          __FUNCTION__,
	          timer_cfg->oam_rdi_persist, timer_cfg->oam_rdi_not_rx,
	          timer_cfg->oam_ais_persist, timer_cfg->oam_ais_not_rx,
	          timer_cfg->oam_cc_sink);

   pTable = (vpciPtr)getVpciPtr(vpi, ((vci == 3) ||(vci == 4)) ? 0 : vci);

	if (pTable == NULL) {
		perror("oam: oam_fsm_timer_config_set");
		OAMPRINTF("oam [%s]: pTable == NULL\n", __FUNCTION__);
		return -1;
	}

   /* Get unique access*/
   lock_get(&pTable->tbl_lock);

   if (timer_cfg->oam_rdi_persist > 0)
      pTable->fsm_timer_cfg.oam_rdi_persist = (timer_cfg->oam_rdi_persist * INFI_TICK) / 1000;
   if (timer_cfg->oam_rdi_not_rx > 0)
      pTable->fsm_timer_cfg.oam_rdi_not_rx  = (timer_cfg->oam_rdi_not_rx * INFI_TICK) / 1000;
   if (timer_cfg->oam_ais_persist > 0)
      pTable->fsm_timer_cfg.oam_ais_persist = (timer_cfg->oam_ais_persist * INFI_TICK) / 1000;
   if (timer_cfg->oam_ais_not_rx > 0)
      pTable->fsm_timer_cfg.oam_ais_not_rx  = (timer_cfg->oam_ais_not_rx * INFI_TICK) / 1000;
   if (timer_cfg->oam_cc_sink > 0)
      pTable->fsm_timer_cfg.oam_cc_sink     = (timer_cfg->oam_cc_sink * INFI_TICK) / 1000;

   /* Release unique access*/
   lock_set(&pTable->tbl_lock);

   return 0;
}



int command(OAM_CELL *pCell)
{
	UINT32 vpi=0,vci=0,scope=0,freq=0;
#ifdef INCLUDE_IFX_OAM_CC
	UINT32 dir;
#endif /* #ifdef INCLUDE_IFX_OAM_CC*/
   oam_fsm_timer_cfg_t *timer_cfg;

	OAMPRINTF("oam [%s]: received command cell\n", __FUNCTION__);

	switch (pCell->cell[OAM_TYPE_FN+5]) {
#ifdef INCLUDE_IFX_OAM_AIS
		case 1:
			vpi = pCell->cell[OAM_TYPE_FN+1];
			vci = pCell->cell[OAM_TYPE_FN+2];
			link_failure(pCell);
			break;

		case 2:
			vpi = pCell->cell[OAM_TYPE_FN+1];
			vci = pCell->cell[OAM_TYPE_FN+2];
			link_recovery(pCell);
			break;
#endif /* #ifdef INCLUDE_IFX_OAM_AIS*/
#ifdef INCLUDE_IFX_OAM_LOOPBACK
		case 3:
			vpi = pCell->cell[OAM_TYPE_FN+1];
			vci = pCell->cell[OAM_TYPE_FN+2];
			scope = pCell->cell[OAM_TYPE_FN+3];
			freq = pCell->cell[OAM_TYPE_FN+4];
			if (freq == 0xFF)
				freq = *(UINT32 *)&pCell->cell[OAM_TYPE_FN+6];
			if (vci == 0xFF)
				vci = *(UINT32 *)&pCell->cell[OAM_TYPE_FN+6+(sizeof(freq))];
			/*nping = pCell->cell[OAM_TYPE_FN+6+(sizeof(freq))+(sizeof(vci))];*/
			start_loopback(vpi, vci, scope, freq);
			break;
		case 4:
			vpi = pCell->cell[OAM_TYPE_FN+1];
			vci = pCell->cell[OAM_TYPE_FN+2];
			scope = pCell->cell[OAM_TYPE_FN+3];
			freq = pCell->cell[OAM_TYPE_FN+4];
			if (vci == 0xFF)
				vci = *(UINT32 *)&pCell->cell[OAM_TYPE_FN+6];
			stop_loopback(vpi, vci, scope);
			break;
#endif /* #ifdef INCLUDE_IFX_OAM_LOOPBACK*/

#ifdef INCLUDE_IFX_OAM_CC
		case 5:
			vpi = pCell->cell[OAM_TYPE_FN+1];
			vci = pCell->cell[OAM_TYPE_FN+2];
			scope = pCell->cell[OAM_TYPE_FN+3];
			dir = pCell->cell[OAM_TYPE_FN+4];
			if (vci == 0xFF)
				vci = *(UINT32 *)&pCell->cell[OAM_TYPE_FN+6];
			activateCC(vpi, vci, scope, dir);
			break;
		case 6:
			vpi = pCell->cell[OAM_TYPE_FN+1];
			vci = pCell->cell[OAM_TYPE_FN+2];
			scope = pCell->cell[OAM_TYPE_FN+3];
			dir = pCell->cell[OAM_TYPE_FN+4];
			if (vci == 0xFF)
				vci = *(UINT32 *)&pCell->cell[OAM_TYPE_FN+6];
			deActivateCC(vpi, vci, scope, dir);
			break;
#endif /* #ifdef INCLUDE_IFX_OAM_CC*/
		case 10:
			vpi = pCell->cell[OAM_TYPE_FN+1];
			vci = pCell->cell[OAM_TYPE_FN+2];
			enable_oam(vpi,vci);
			break;
      case 11:
			vpi = pCell->cell[OAM_TYPE_FN+1];
			vci = pCell->cell[OAM_TYPE_FN+2];
			if (vci == 0xFF)
				vci = *(UINT16 *)&pCell->cell[OAM_TYPE_FN+6];
			oam_cell_counters_report((UINT8)vpi, (UINT16)vci);
         break;
      case 12:
			vpi = pCell->cell[OAM_TYPE_FN+1];
			vci = pCell->cell[OAM_TYPE_FN+2];
			if (vci == 0xFF)
				vci = *(UINT16 *)&pCell->cell[OAM_TYPE_FN+6];
			oam_cell_counters_reset((UINT8)vpi, (UINT16)vci);
         break;
      case 13:
			vpi = pCell->cell[OAM_TYPE_FN+1];
			vci = pCell->cell[OAM_TYPE_FN+2];
			if (vci == 0xFF)
				vci = *(UINT16 *)&pCell->cell[OAM_TYPE_FN+6];
         timer_cfg = (oam_fsm_timer_cfg_t*)(&pCell->cell[OAM_TYPE_FN + 6 + sizeof(UINT16)]);
			oam_fsm_timer_config_set((UINT8)vpi, (UINT16)vci, timer_cfg);
         break;


		default:
			syslog(LOG_INFO,"ERROR: Bad command\n");
			OAMPRINTF("ERROR: Bad command\n");
			break;
	}

	return 0;
}


int enable_oam(UINT32 vpi, UINT32 vci)
{
	int oam_f4, result=-1;
	struct sockaddr_atmpvc oam_f4addr;
	struct atm_qos qos;

	OAMPRINTF("oam [%s]\n", __FUNCTION__);

	/* if not F4 oam then VC will be already existing */
#ifdef TB_REMOVED
	if (!((vci == 3)||(vci==4))) {
		return -1;
	}
#endif

   oam_f4 = socket(PF_ATMPVC, SOCK_DGRAM, ATM_AAL0);
	if (oam_f4 < 0) {
		syslog(LOG_INFO,"error opening socket\n");
		return -1;
	}

	bzero(&qos, sizeof(qos));
	qos.rxtp.max_sdu = 0;
	qos.rxtp.traffic_class = ATM_UBR;
	/*qos.rxtp.pcr= ATM_MAX_PCR;*/
	qos.txtp = qos.rxtp ;
	qos.aal = ATM_AAL0;
	if (setsockopt(oam_f4, SOL_ATM, SO_ATMQOS, &qos, sizeof(qos)) < 0) {
		perror("setsockopt:");
		goto ERR_RET;
	}

	bzero(&oam_f4addr, sizeof(oam_f4addr));
	oam_f4addr.sap_family = AF_ATMPVC;
	oam_f4addr.sap_addr.itf = 0;
	oam_f4addr.sap_addr.vpi = vpi;
	oam_f4addr.sap_addr.vci = vci;
	result = bind(oam_f4, (struct sockaddr *)&oam_f4addr, sizeof(oam_f4addr));

ERR_RET:
	close(oam_f4);
	return result;
}



/****************************************************
 * Function to calculate crc-10 checksum
 * **************************************************/

#define POLYNOMIAL 0x633

static UINT16 calcCRC10(UINT8 *pData, UINT32 Size)
{
   UINT32 i;
   UINT16 crc10_accum = 0;
   static char AlreadyDone = OAM_FALSE;
   static UINT16 byte_crc10_table[256];

   /* Generate byte values for use, needs to be done once*/
   if (!AlreadyDone) {
      UINT32 k, j;
      UINT16 Gen_crc10_accum;

      for (k = 0;  k < 256;  k++) {
         Gen_crc10_accum = ((UINT16) k << 2);
         for (j = 0;  j < 8;  j++) {
            if ((Gen_crc10_accum <<= 1) & 0x400) 
               Gen_crc10_accum ^= POLYNOMIAL;
         }
         byte_crc10_table[k] = Gen_crc10_accum;
      }   

      AlreadyDone = OAM_TRUE;
   }

   for (i = 0;  i < Size;  i++) {
      crc10_accum = ((crc10_accum << 8) & 0x3ff) ^ byte_crc10_table[( crc10_accum >> 2) & 0xff] ^ *pData++;
   }

    /*printf("oam [%s]: crc10 = 0x%x\n", __FUNCTION__, crc10_accum);*/
    return crc10_accum;
}

UINT16  checkCRC10(UINT8 *CellPtr) 
{ 
	unsigned short oamCRC10=0; 
	unsigned short oamCRC11=0; 

	oamCRC11 |= (CellPtr[OAM_CRC10_0] & 0x03) <<8;  
	oamCRC11 |= CellPtr[OAM_CRC10_1] ; 

	CellPtr[OAM_CRC10_0] = 0; 
	CellPtr[OAM_CRC10_1] = 0; 

	oamCRC10 = calcCRC10((unsigned char *)(CellPtr+OAM_CELL_HEADER_SIZE), 
			ATM_CELL_PAYLOAD_SIZE); 

	/*printf("oam [%s]: crc11 = 0x%x\n", __FUNCTION__, oamCRC11);*/

	if(oamCRC10==oamCRC11)
		return 1;
	else
		return 0;
}



#ifdef INCLUDE_IFX_OAM_LOOPBACK_PING
int update_oam_stats(VPCI *pTable)
{
	char fifoname[100];
   int fd_fifo_daemon, wr_sz, ret = 0;
   OAM_FIFO_MSG_STATS fifo_msg = {0};
	int vpi, vci;

#if 0
	if (pTable->num_cells_rx == 0) {
		/* No ping reply received */
		vpi = -1;
		vci = -1;
		pTable->avg_resp_time=0;
	} else {
		vpi = pTable->vpi;
		vci = pTable->vci;
	}
#else /* Do not change vpi/vci since the api expects the
         correct FIFO filename!*/
	if (pTable->num_cells_rx == 0) {
		/* No ping reply received */
		pTable->avg_resp_time=0;
   }
	vpi = pTable->vpi;
	vci = pTable->vci;
#endif

	if (pTable->num_cells_rx != 0) {
	    pTable->avg_resp_time = pTable->avg_resp_time / pTable->num_cells_rx;
	}

   MAKE_OAM_STATS_FIFONAME(vpi, (vci == 3 || vci == 4) ? 0 : vci, fifoname);

   /* make FIFO*/
   if (mkfifo(fifoname, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH) == -1 && errno != EEXIST) {
      OAMPRINTF("OAM_D: make FIFO %s failed!\n", fifoname);
      return -1;
   }

   fd_fifo_daemon = open(fifoname, O_WRONLY | O_NONBLOCK);

   if (fd_fifo_daemon < 0) {
      OAMPRINTF("OAM_D: open FIFO %s failed!\n", fifoname);
      return -1;
   }

   fifo_msg.vpi = vpi;
   fifo_msg.vci = vci;
   fifo_msg.num_cells_rx = pTable->num_cells_rx;
   fifo_msg.max_resp_time = pTable->max_resp_time;
   fifo_msg.min_resp_time = pTable->min_resp_time;
   fifo_msg.avg_resp_time = pTable->avg_resp_time;

   wr_sz = write(fd_fifo_daemon, &fifo_msg, sizeof(fifo_msg));

   if (wr_sz != sizeof(fifo_msg)) {
      OAMPRINTF("OAM_D: write FIFO %s %d bytes write failed!\n",
         fifoname, sizeof(fifo_msg));
      ret = -1;
   }

   close(fd_fifo_daemon);

	return ret;
}
#endif /* #ifdef INCLUDE_IFX_OAM_LOOPBACK_PING*/



int check_adsl_status()
{
	int status;
	FILE *fadsl;

	fadsl = fopen("/tmp/adsl_status","r");
	if (!fadsl) {
		syslog(LOG_INFO,"OAM ERROR: need to run dsl_cpe_control. stop!\n");
		return -1;
	}

	fscanf(fadsl,"%d",&status);
	fclose(fadsl);

	/* status 7: showtime, 0: not in showtime*/
	if (status != 7) {
		syslog(LOG_INFO,"OAM ERROR: adsl not in showtime. stop!\n");
		return -1;
	}

	return 0;
}
