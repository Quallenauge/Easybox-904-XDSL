/******************************************************************************

                               Copyright (c) 2010
                            Lantiq Deutschland GmbH
                     Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/

#include <netinet/in.h> 
#include <linux/atm.h> 
#include "oam.h"
#include <linux/netlink.h> 
#include <signal.h>
#include <string.h>
#include <syslog.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>


static char g_RawCell[255];

static int g_sim_action = -1, g_vpi = 0, g_vci = 0, g_pti = 0;


#define POLYNOMIAL 0x633


#define SIM_ACTION_AIS_SEND   0
#define SIM_ACTION_RDI_SEND   1
#define SIM_ACTION_RAW_SEND   2

static UINT16 crc10_calc(UINT8 *pData, UINT32 Size)
{
   UINT32 i;
   UINT16 crc10_accum = 0;
   static char AlreadyDone = OAM_FALSE;
   static UINT16 byte_crc10_table[256];

   /* Generate byte values for use, needs to be done once*/
   if (!AlreadyDone) {
      UINT32 k, j;
      UINT16 Gen_crc10_accum;

      for (k = 0;  k < 256;  k++) {
         Gen_crc10_accum = ((UINT16) k << 2);
         for (j = 0;  j < 8;  j++) {
            if ((Gen_crc10_accum <<= 1) & 0x400) 
               Gen_crc10_accum ^= POLYNOMIAL;
         }
         
         byte_crc10_table[k] = Gen_crc10_accum;
      }   
      AlreadyDone = OAM_TRUE;
   }

   for (i = 0;  i < Size;  i++) {
      crc10_accum = ((crc10_accum << 8) & 0x3ff) ^ byte_crc10_table[( crc10_accum >> 2) & 0xff] ^ *pData++;
   }

   return crc10_accum;
}


#if 0
static UINT16 crc10_check(UINT8 *CellPtr) 
{ 
	unsigned short oamCRC10=0; 
	unsigned short oamCRC11=0; 

	oamCRC11 |= (CellPtr[OAM_CRC10_0] & 0x03) <<8;  
	oamCRC11 |= CellPtr[OAM_CRC10_1] ; 

	CellPtr[OAM_CRC10_0] = 0; 
	CellPtr[OAM_CRC10_1] = 0; 

	oamCRC10 = crc10_calc((unsigned char *)(CellPtr+OAM_CELL_HEADER_SIZE), 
			ATM_CELL_PAYLOAD_SIZE); 

	if(oamCRC10 == oamCRC11)
		return 1;
	else
		return 0;
}
#endif /* #if 0*/


static INT32 sim_oam_send(int oam_sock, OAM_CELL *pCell)
{
	int pid=0;
   char oamd_pid[] = "/var/run/oam.pid";
	struct msghdr txmsg;
	struct iovec txiov;
	struct sockaddr_nl oamTxSockAdd;
   unsigned short OAMCRC10;
	FILE *foam;

   foam = fopen(oamd_pid, "r");
	if (!foam) {
		printf("ERROR: opening file %s failed!\n", oamd_pid);
		return -1;
	}
	fscanf(foam, "%d", &pid);
	fclose(foam);

	txiov.iov_base = (void *)pCell;
	txiov.iov_len  = OAM_CELL_SIZE;
	
	txmsg.msg_name    = (void *)&oamTxSockAdd;
	txmsg.msg_namelen = sizeof(oamTxSockAdd);
	txmsg.msg_iov     = &txiov;
	txmsg.msg_iovlen  = 1; 
	txmsg.msg_control = NULL;
	txmsg.msg_controllen = 0;
	txmsg.msg_flags      = 0;

	memset(&oamTxSockAdd,0, sizeof(oamTxSockAdd));
	oamTxSockAdd.nl_family = AF_NETLINK;
	oamTxSockAdd.nl_pid    = pid;   /*PID */
	oamTxSockAdd.nl_groups = 0;

   pCell->cell[OAM_CRC10_0] = 0;
   pCell->cell[OAM_CRC10_1] = 0;
   OAMCRC10 = crc10_calc(
	            (unsigned char *)(pCell->cell + OAM_CELL_HEADER_SIZE), ATM_CELL_PAYLOAD_SIZE);
   pCell->cell[OAM_CRC10_0] ^= (OAMCRC10 >> 8);
   pCell->cell[OAM_CRC10_1] ^= (OAMCRC10 & 0xFF);

	if(sendmsg(oam_sock, &txmsg,0) < 0) {
      printf("ERROR: SIM OAM TX failed!\n");
      return -1 ;
   }

   return 0;
}

static void sim_oam_cell_header_create(
               OAM_CELL *pCell,
               unsigned char vpi,
               unsigned short vci,
               unsigned char pti)
{
	struct amazon_atm_cell_header * cell_header;
                                                                                
	pCell->pid = getpid();

	cell_header = (struct amazon_atm_cell_header*) (&pCell->cell[0]);
	cell_header->bit.vpi = vpi;
	cell_header->bit.vci = vci;
	cell_header->bit.pti = pti;
	cell_header->bit.clp = 0; 
	cell_header->bit.gfc = 0; 
}



static INT32 sim_oam_ais_send(
               int oam_sock,
               unsigned char vpi,
               unsigned short vci,
               unsigned char pti)
{
	OAM_CELL *pCell;
	UINT8 i;

	pCell = (OAM_CELL *)malloc(OAM_CELL_SIZE);
	if (!pCell) {
		printf("ERROR: cell memory allocation failed!\n");
		return -1;
	}

   sim_oam_cell_header_create(pCell, vpi, vci, pti);

	pCell->cell[OAM_TYPE_FN] = OAM_AIS;
	pCell->cell[OAM_AIS_DEFECT_TYPE] = OAM_OPTIONAL;
	for (i=0; i<16; i++)
		pCell->cell[OAM_AIS_DEFECT_LOC +i] = i; /*OAM_OPTIONAL;*/

	for (i=0; i<28; i++)
		pCell->cell[OAM_AIS_RESERV +i] = i; /*OAM_OPTIONAL;*/

   if (sim_oam_send(oam_sock, pCell) != 0) {
		printf("ERROR: OAM cell send failed!\n");
      free(pCell);
		return -1;
   }

   free(pCell);

   return 0;
}



static INT32 sim_oam_rdi_send(
               int oam_sock,
               unsigned char vpi,
               unsigned short vci,
               unsigned char pti)
{
	OAM_CELL *pCell;
	UINT8 i;

	pCell = (OAM_CELL *)malloc(OAM_CELL_SIZE);
	if (!pCell) {
		printf("ERROR: cell memory allocation failed!\n");
		return -1;
	}

   sim_oam_cell_header_create(pCell, vpi, vci, pti);

	pCell->cell[OAM_TYPE_FN] = OAM_RDI;
	pCell->cell[OAM_AIS_DEFECT_TYPE] = OAM_OPTIONAL;
	for (i=0; i<16; i++)
		pCell->cell[OAM_AIS_DEFECT_LOC +i] = i; /*OAM_OPTIONAL;*/

	for (i=0; i<28; i++)
		pCell->cell[OAM_AIS_RESERV +i] = i; /*OAM_OPTIONAL;*/

   if (sim_oam_send(oam_sock, pCell) != 0) {
		printf("ERROR: OAM cell send failed!\n");
      free(pCell);
		return -1;
   }

   free(pCell);

   return 0;
}



static void sim_oam_usage_print(void)
{
   printf("Available options:\n");
   printf("  --help               Print help (this message) and exit\n");
   printf("  --version            Print OAM SIM version and exit\n");
   printf("  --action <val>       SIM action, 0: send AIS, 1: send RDI, 2: send RAW\n");
   printf("  --raw-file <file>    RAW cell file\n");
   printf("  --vpi <val>          VPI\n");
   printf("  --vci <val>          VCI\n");
   printf("  --pti <val>          PTI\n");
}


static int sim_arg_parse(int argc, char *argv [])
{
   int c, nOptIndex;

   static struct option pOptString[] = {
      { "help",      no_argument,       0,           'h' },
      { "version",   no_argument,       0,           'v' },
      { "action",    required_argument, 0,           '1' },
      { "raw-file",  required_argument, 0,           '2' },
      { "vpi",       required_argument, 0,           '3' },
      { "vci",       required_argument, 0,           '4' },
      { "pti",       required_argument, 0,           '5' },
      { NULL,        no_argument,       0,            0  }
   };

   static const char pLongOpts[] = "hvr:1:2:3:4:5:";

   while (1) {
      c = getopt_long(argc, argv, pLongOpts, pOptString, &nOptIndex);

      if (c == -1) {
         return 0;
      }

      switch (c) {
      case 'v':
         /* TBD: print version here*/
         break;
      case 'h':
         sim_oam_usage_print();
         return 0;
      case '1':
         g_sim_action = atoi(optarg);
         break;
      case '2':
         if (strlen(optarg) + 1 > sizeof(g_RawCell)) {
            printf("ERROR - RAW cell file path is too long!\n");
            return -1;
         }

         strcpy(g_RawCell, optarg);
         break;
      case '3':
         g_vpi = atoi(optarg);
         break;
      case '4':
         g_vci = atoi(optarg);
         break;
      case '5':
         g_pti = atoi(optarg);
         break;
      }
   }

   return 0;
}							



static int sim_nl_socket_create(void)
{

	struct sockaddr_nl oamRxSockAdd;
	int addr_len;
   int oam_sd;

	/* Wait for OAM cells from driver */
	oam_sd = socket(AF_NETLINK, SOCK_RAW, NETLINK_USERSOCK);
	if (oam_sd < 0){
		printf("ERROR: Netlink socket create failed!\n");
      return oam_sd;
	}	

	/* bind socket */
	oamRxSockAdd.nl_family = AF_NETLINK;
	oamRxSockAdd.nl_pad    = 0;
	oamRxSockAdd.nl_pid    = getpid();
	oamRxSockAdd.nl_groups = 0;
	
	if (bind(oam_sd, (struct sockaddr *)&oamRxSockAdd, 
				sizeof(oamRxSockAdd)) < 0) {
		printf("ERROR - Error binding OAM SIM socket!\n");
	}

	addr_len = sizeof(oamRxSockAdd);

	if (getsockname(oam_sd, (struct sockaddr*)&oamRxSockAdd, (socklen_t *) &addr_len) < 0)
	{
	    printf("ERROR: getsockname failed!\n");
	    return -1;
	}

	if (addr_len != sizeof(oamRxSockAdd)) {
	    printf("ERROR: wrong address lenght %d\n", addr_len);
	    return -1;
	}

	if (oamRxSockAdd.nl_family != AF_NETLINK) {
	    printf("ERROR: wrong address family %d\n", oamRxSockAdd.nl_family);
	    return -1;
	}

	return oam_sd;
}



static int sim_nl_socket_close(int oam_sock)
{
	close(oam_sock);
	return (0);
}



static void sim_term(int sig)
{
   /* ignore the signal, we'll handle by ourself */
   signal (sig, SIG_IGN);

   if (sig == SIGINT || sig == SIGTERM) {
      printf("\nBye from the OAM SIM\n");
   }
}



int main(int argc, char *argv [])
{
	FILE *foam;
   int ret = 0, oam_sd;
   char sim_pid[] = "/var/run/oamsim.pid";

   signal(SIGINT, sim_term);
   signal(SIGTERM, sim_term);

   if (argc < 2) {
      sim_oam_usage_print();
      return -1;
   }

   if (sim_arg_parse(argc, argv) != 0) {
      return -1;
   }

   /* Write our PID to the shared file*/
	foam = fopen(sim_pid, "w");
	if (!foam) {
		printf("ERROR: opening file %s failed!\n", sim_pid);
		return -1;
	}
	fprintf(foam,"%d", getpid());
	fclose(foam);

   /* Create NL socket*/
	oam_sd = sim_nl_socket_create();
   if (oam_sd < 0) {
      return -1;
   }

   /* Start cell RX thread */

   /*

   TBD if we need to handle RX cells

   */


   /* Handle SIM action*/
   switch (g_sim_action) {
   case SIM_ACTION_AIS_SEND:
   	printf("SIM_ACTION_AIS_SEND\n");
      /* Create and send AIS cell*/
      ret = sim_oam_ais_send(
               oam_sd,
               (unsigned char)g_vpi,
               (unsigned short)g_vci,
               (unsigned char)g_pti);
      break;
   case SIM_ACTION_RDI_SEND:
   	printf("SIM_ACTION_RDI_SEND\n");
      /* Create and send AIS cell*/
      ret = sim_oam_rdi_send(
               oam_sd,
               (unsigned char)g_vpi,
               (unsigned short)g_vci,
               (unsigned char)g_pti);
      break;
   case SIM_ACTION_RAW_SEND:
   	printf("SIM_ACTION_RAW_SEND\n");
      break;
   default:
   	printf("ERROR: unknown SIM action %d\n", g_sim_action);
      break;
   }

   if (ret != 0) {
      printf("ERROR: SIM action %d failed!\n", g_sim_action);
   }

   /* Close NL socket*/
	sim_nl_socket_close(oam_sd);

	return 0;
}




