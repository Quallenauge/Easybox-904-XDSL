/******************************************************************************

                               Copyright (c) 2010
                            Lantiq Deutschland GmbH
                     Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/

#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "oam.h"

/****************************************************
 * Function to calculate crc-10 checksum
 * **************************************************/

#if defined(INCLUDE_IFX_OAM_LOOPBACK) || \
    defined (INCLUDE_IFX_OAM_LOOPBACK_PING) || \
    defined(INCLUDE_IFX_OAM_CC)

#define POLYNOMIAL 0x633

static UINT16 calcCRC10(UINT8 *pData, UINT32 Size)
{
   UINT32 i;
   UINT16 crc10_accum = 0;
   static char AlreadyDone = OAM_FALSE;
   static UINT16 byte_crc10_table[256];

   /* Generate byte values for use, needs to be done once*/
   if (!AlreadyDone) {
      UINT32 k, j;
      UINT16 Gen_crc10_accum;

      for (k = 0;  k < 256;  k++) {
         Gen_crc10_accum = ((UINT16) k << 2);
         for (j = 0;  j < 8;  j++) {
            if ((Gen_crc10_accum <<= 1) & 0x400) 
               Gen_crc10_accum ^= POLYNOMIAL;
         }
         byte_crc10_table[k] = Gen_crc10_accum;
      }   

      AlreadyDone = OAM_TRUE;
   }

   for (i = 0;  i < Size;  i++) {
      crc10_accum = ((crc10_accum << 8) & 0x3ff) ^ byte_crc10_table[( crc10_accum >> 2) & 0xff] ^ *pData++;
   }

    /* tc.chen 2005/07/27 printf("oam [%s]: crc10 = 0x%x\n", __FUNCTION__, crc10_accum);*/
    return crc10_accum;
}


int oam_create_sock(void)
{
	int  oam_sock;

	/* Wait for OAM cells from driver */
	oam_sock = socket(AF_NETLINK, SOCK_RAW, NETLINK_USERSOCK);
	if (oam_sock<0){
		perror("Error opening OAM socket");
	}	

	return oam_sock;
}

void oam_close_sock(int oam_sock)
{
	close(oam_sock);
}



int infi_push_oam(unsigned char *cell, UINT32 oam_sock)
{
	int pid=0;

	struct msghdr txmsg;
	struct iovec txiov;
	struct sockaddr_nl oamTxSockAdd;
	FILE *foam;
	OAM_CELL *pCell=(OAM_CELL *)cell;

	/*printf("send_oam \n");*/
   foam = fopen("/var/run/oam.pid","r");
	if (!foam) {
		printf("Error opening file\n");
		return -1;
	}
	fscanf(foam,"%d", &pid);
	fclose(foam);

	txiov.iov_base = (void *)cell;
	txiov.iov_len = OAM_CELL_SIZE;
	
	txmsg.msg_name = (void *)&oamTxSockAdd;
	txmsg.msg_namelen = sizeof(oamTxSockAdd);
	txmsg.msg_iov = &txiov;
	txmsg.msg_iovlen = 1; 
	txmsg.msg_control = NULL;
	txmsg.msg_controllen = 0;
	txmsg.msg_flags = 0;

	memset(&oamTxSockAdd,0, sizeof(oamTxSockAdd));
	oamTxSockAdd.nl_family = AF_NETLINK;
	oamTxSockAdd.nl_pid = pid;   /*PID */
	oamTxSockAdd.nl_groups = 0;

	storeCRC10(pCell->cell);

	if (sendmsg(oam_sock, &txmsg,0) < 0) {
      perror("tx_oam: sendto");
      return -1 ;
   }

   return 0;
}
#endif /* #if defined(INCLUDE_IFX_OAM_LOOPBACK) ||
              defined (INCLUDE_IFX_OAM_LOOPBACK_PING) ||
              defined(INCLUDE_IFX_OAM_CC) */


#ifdef INCLUDE_IFX_OAM_LOOPBACK 
int ifx_oam_enable_loopback(int vpi, int vci, char scope, int freq)
{
	OAM_CELL *pCell;
	int oam_sock, result;
	UINT32 cmdId, dummy1,dummy2;

	oam_sock = oam_create_sock();
	if(oam_sock<0){
		return -1;
	}

	pCell = (OAM_CELL *)malloc(OAM_CELL_SIZE);
	if (!pCell) {
		oam_close_sock(oam_sock);
		return -1;
	}

	memset(pCell, 0x00, OAM_CELL_SIZE);	

	/* initiate loopback */
	cmdId=3;dummy1=0;dummy2=0; /* command id 3 */
	pCell->cell[OAM_TYPE_FN] = 0x10; /* oam cell */
	pCell->cell[1+OAM_TYPE_FN] = vpi;  /* vpi*/
	pCell->cell[2+OAM_TYPE_FN] = 0xFF; /* vci */
	pCell->cell[3+OAM_TYPE_FN] = scope; /* scope: ETE-0, SEG-1 */
	pCell->cell[4+OAM_TYPE_FN] = 0xFF; /* frequency 5-64K sec*/
	pCell->cell[5+OAM_TYPE_FN] = cmdId;
	memcpy(&pCell->cell[6+OAM_TYPE_FN], (char *)&freq, sizeof(freq));
	memcpy(&pCell->cell[6+OAM_TYPE_FN+sizeof(freq)], (char *)&vci, sizeof(vci));
	/*pCell->cell[6+OAM_TYPE_FN+(sizeof(freq)+sizeof(vci))] =nping;*/

	result = infi_push_oam((UINT8 *)pCell,oam_sock);
	free(pCell);
	oam_close_sock(oam_sock);

	return result;
}



int ifx_oam_disable_loopback(int vpi, int vci, char scope, int freq)
{
	OAM_CELL *pCell;
	int oam_sock, result;
	UINT32 cmdId, dummy1,dummy2;

	oam_sock = oam_create_sock();
	if(oam_sock<0){
		return -1;
	}

	pCell = (OAM_CELL *)malloc(OAM_CELL_SIZE);
	if (!pCell) {
		oam_close_sock(oam_sock);
		return -1;
	}

	memset(pCell, 0x00, OAM_CELL_SIZE);	
	/* terminate loopback */
	cmdId = 4; dummy1 = 0; dummy2 = 0;  /* command id 4*/
	pCell->cell[OAM_TYPE_FN] = 0x10;    /* oam cell */
	pCell->cell[1+OAM_TYPE_FN] = vpi;   /* vpi*/
	pCell->cell[2+OAM_TYPE_FN] = 0xFF;  /* vci */
	pCell->cell[3+OAM_TYPE_FN] = scope; /* scope: ETE-0, SEG-1 */
	pCell->cell[4+OAM_TYPE_FN] = freq;  /* frequency 5-64K sec*/
	pCell->cell[5+OAM_TYPE_FN] = cmdId;
	memcpy(&pCell->cell[6+OAM_TYPE_FN], (char *)&vci, sizeof(vci));

	result = infi_push_oam((UINT8 *)pCell,oam_sock);
	free(pCell);
	oam_close_sock(oam_sock);

	return result;
}
#else
int ifx_oam_enable_loopback(int vpi, int vci, char scope, int freq)
{
	printf("\n This feature is not supported in this Release \n");

	return 0;
}

int ifx_oam_disable_loopback(int vpi, int vci, char scope, int freq)
{
	printf("\n This feature is not supported in this Release \n");

	return 0;
}
#endif /* #ifdef INCLUDE_IFX_OAM_LOOPBACK */

#if defined(INCLUDE_IFX_OAM_F5_LOOPBACK_PING) || defined(INCLUDE_IFX_OAM_F4_LOOPBACK_PING)
static int ifx_oam_ping(
         int vpi, int vci, char scope,
         int ping_timeout, int num_cells_tx, int *num_cells_rx,
         int *max_resp_time, int *min_resp_time, int *avg_resp_time )
{
	unsigned int fvpi=0, fvci=0; 
	unsigned int rep_and_timeout = 0;
   int fd_fifo_api, rd_sz, ret = 0;
	char fifoname[100];
   OAM_FIFO_MSG_STATS fifo_msg = {0};

	if (ping_timeout == 0) {
		ping_timeout = 5;
	}
	if (num_cells_tx == 0) {
		num_cells_tx = 1;
	}

	*num_cells_rx = 0;
	*max_resp_time = 0;
	*min_resp_time = 0;
	*avg_resp_time = 0;

	rep_and_timeout = num_cells_tx << 16;
	rep_and_timeout |= ping_timeout & 0xFFFF;

	OAMPRINTF("\noam [%s]: vpi[%d],vci[%d],scope[%d],#tx[%d], timeout[%d]\n", 
				__FUNCTION__, vpi,vci,scope, num_cells_tx, ping_timeout);
	OAMPRINTF("\noam [%s]: rep_timeout: 0x%x\n", 
				__FUNCTION__, rep_and_timeout);


   MAKE_OAM_STATS_FIFONAME(vpi, ((vci == 3) ||(vci ==4)) ? 0 : vci, fifoname);

   /* make FIFO*/
   if (mkfifo(fifoname, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH) == -1 && errno != EEXIST) {
		printf("OAM_API[%s]: make FIFO %s failed!\n", __FUNCTION__, fifoname);
      return -1;
   }

   fd_fifo_api = open(fifoname, O_RDONLY | O_NONBLOCK);

   if (fd_fifo_api < 0) {
		printf("OAM_API[%s]: open FIFO %s failed!\n", __FUNCTION__, fifoname);
      return -1;
   }

	ifx_oam_enable_loopback(vpi,vci,4,rep_and_timeout); 
   /* num_cells_tx + 1 because 1st ping starts after the timeout
      + wait timeout after the last ping*/
	sleep((num_cells_tx + 1) * ping_timeout / 1000 + 4);

   rd_sz = read(fd_fifo_api, &fifo_msg, sizeof(fifo_msg));

   if (rd_sz <= 0 || rd_sz < sizeof(OAM_FIFO_MSG_STATS)) {
		printf("OAM_API[%s]: FIFO %s read size %d error!\n",
		   __FUNCTION__, fifoname, rd_sz);
		ret = -1;
   }
   else {
      fvpi = fifo_msg.vpi;
      fvci = fifo_msg.vci;

      vci  = ((vci == 3) ||(vci ==4)) ? 0 : vci;

      if ((vpi == fvpi) && (vci == fvci)) {
         *num_cells_rx  = fifo_msg.num_cells_rx;
         *max_resp_time = fifo_msg.max_resp_time;
         *min_resp_time = fifo_msg.min_resp_time;
         *avg_resp_time = fifo_msg.avg_resp_time;
      }
      else {
	      printf("OAM_API[%s]: wrong (vpi/vci)=%d/%d received, expected (vpi/vci)=%d/%d!\n",
		      __FUNCTION__, fvpi, fvci, vpi, vci);

         ret = -1;
      }
   }

   close(fd_fifo_api);
   remove(fifoname);

   return ret;
}
#endif /* #if defined(INCLUDE_IFX_OAM_F5_LOOPBACK_PING) || defined(INCLUDE_IFX_OAM_F4_LOOPBACK_PING)*/

#if defined(INCLUDE_IFX_OAM_F5_LOOPBACK_PING)
int ifx_oam_f5_ping(
         int vpi, int vci, char scope,
         int ping_timeout, int num_cells_tx, int *num_cells_rx,
         int *max_resp_time, int *min_resp_time, int *avg_resp_time )
{
   return ifx_oam_ping(
            vpi, vci, scope, ping_timeout,
            num_cells_tx, num_cells_rx, max_resp_time,
            min_resp_time, avg_resp_time);
}
#else
int ifx_oam_f5_ping(
         int vpi, int vci, char scope,
         int ping_timeout, int num_cells_tx, int *num_cells_rx,
         int *max_resp_time, int *min_resp_time, int *avg_resp_time )
{
	printf("\n This feature is not supported in this Release \n");

	return -1;
}
#endif /* #if defined(INCLUDE_IFX_OAM_F5_LOOPBACK_PING)*/

#if defined(INCLUDE_IFX_OAM_F4_LOOPBACK_PING)
int ifx_oam_f4_ping(
         int vpi, char scope, int ping_timeout,
         int num_cells_tx, int *num_cells_rx, int *max_resp_time,
         int *min_resp_time, int *avg_resp_time)
{
   return ifx_oam_ping(vpi, 4, scope, ping_timeout,
            num_cells_tx, num_cells_rx, max_resp_time,
            min_resp_time, avg_resp_time);
}
#else
int ifx_oam_f4_ping(
         int vpi, char scope, int ping_timeout,
         int num_cells_tx, int *num_cells_rx, int *max_resp_time,
         int *min_resp_time, int *avg_resp_time)
{
	printf("\n This feature is not supported in this Release \n");

	return -1;
}
#endif /* #if defined(INCLUDE_IFX_OAM_F4_LOOPBACK_PING)*/



#ifdef INCLUDE_IFX_OAM_CC
int ifx_oam_enable_cc(int vpi, int vci, char scope, char direction)
{	
	OAM_CELL *pCell;
	int oam_sock, result;
	UINT32 cmdId, dummy1,dummy2;

	oam_sock = oam_create_sock();
	if (oam_sock < 0) {
		return -1;
	}

	pCell = (OAM_CELL *)malloc(OAM_CELL_SIZE);
	if (!pCell) {
		return -1;
	}

	memset(pCell, 0x00, OAM_CELL_SIZE);	

	/* initiate CC */
	cmdId = 5; dummy1 = 0; dummy2 = 0;      /* command id 5 */
	pCell->cell[OAM_TYPE_FN] = 0x10;        /* oam cell */
	pCell->cell[1+OAM_TYPE_FN] = vpi;       /* vpi*/
	pCell->cell[2+OAM_TYPE_FN] = 0xFF;      /* vci */
	pCell->cell[3+OAM_TYPE_FN] = scope;     /* scope: ETE-0, SEG-1 */
	pCell->cell[4+OAM_TYPE_FN] = direction; /* frequency 5-64K sec*/
	pCell->cell[5+OAM_TYPE_FN] = cmdId;
	memcpy(&pCell->cell[6+OAM_TYPE_FN], (char *)&vci, sizeof(vci));

	result = infi_push_oam((UINT8 *)pCell,oam_sock);
	free(pCell);
	oam_close_sock(oam_sock);

	return result;
}

int ifx_oam_disable_cc(int vpi, int vci, char scope, char direction)
{	
	OAM_CELL *pCell;
	int oam_sock, result;
	UINT32 cmdId, dummy1,dummy2;

	oam_sock = oam_create_sock();
	if(oam_sock<0){
		return -1;
	}

	pCell = (OAM_CELL *)malloc(OAM_CELL_SIZE);
	if (!pCell) {
		return -1;
	}

	memset(pCell, 0x00, OAM_CELL_SIZE);	

	/* disable CC */
	cmdId = 6; dummy1 = 0; dummy2 = 0;      /* command ID 6*/
	pCell->cell[OAM_TYPE_FN] = 0x10;        /* oam cell */
	pCell->cell[1+OAM_TYPE_FN] = vpi;       /* vpi*/
	pCell->cell[2+OAM_TYPE_FN] = 0xFF;      /* vci */
	pCell->cell[3+OAM_TYPE_FN] = scope;     /* scope: ETE-0, SEG-1 */
	pCell->cell[4+OAM_TYPE_FN] = direction; /* frequency 5-64K sec*/
	pCell->cell[5+OAM_TYPE_FN] = cmdId;
	memcpy(&pCell->cell[6+OAM_TYPE_FN], (char *)&vci, sizeof(vci));

	result = infi_push_oam((UINT8 *)pCell,oam_sock);
	free(pCell);
	oam_close_sock(oam_sock);

	return result;
}
		

#else
int ifx_oam_enable_cc(int vpi, int vci, char scope, char direction)
{
	printf("\n This feature is not supported in this Release");

	return 0;
}


int ifx_oam_disable_cc(int vpi, int vci, char scope, char direction)
{

	printf("\n This feature is not supported in this Release");

	return 0;
}
#endif /* #ifdef INCLUDE_IFX_OAM_CC*/



int ifx_oam_cell_counters_get(
         unsigned char vpi,
         unsigned short vci,
         oam_cell_counters_t *counters)
{
   int fd_fifo_api, rd_sz, ret = 0;
	char fifoname[100];
   OAM_FIFO_MSG_COUNTERS fifo_msg = {0};

	OAM_CELL *pCell;
	int oam_sock, result;
	UINT32 cmdId, dummy1,dummy2;

	OAMPRINTF("oam_api [%s]: vpi[%d], vci[%d]\n", __FUNCTION__, vpi, vci);

   if (counters == NULL) {
      return -1;
   }

	oam_sock = oam_create_sock();
	if(oam_sock<0){
		return -1;
	}

	pCell = (OAM_CELL *)malloc(OAM_CELL_SIZE);
	if(!pCell){
		oam_close_sock(oam_sock);
		return -1;
	}
	memset(pCell, 0x00, OAM_CELL_SIZE);	

	cmdId = 11; dummy1 = 0; dummy2 = 0;  /* command id 7 */
	pCell->cell[OAM_TYPE_FN]   = 0x10;   /* oam cell */
	pCell->cell[1+OAM_TYPE_FN] = vpi;    /* vpi*/
	pCell->cell[2+OAM_TYPE_FN] = 0xFF;   /* vci */
	pCell->cell[3+OAM_TYPE_FN] = 0xFF;   /* scope: ETE-0, SEG-1 */
	pCell->cell[4+OAM_TYPE_FN] = 0xFF;   /* frequency 5-64K sec*/
	pCell->cell[5+OAM_TYPE_FN] = cmdId;
	memcpy(&pCell->cell[6+OAM_TYPE_FN], (char *)&vci, sizeof(vci));

	result = infi_push_oam((UINT8 *)pCell,oam_sock);
	free(pCell);
	oam_close_sock(oam_sock);

	if (result != 0) {
      return -1;
   }

   MAKE_OAM_CNT_FIFONAME(vpi, ((vci == 3) ||(vci ==4)) ? 0 : vci, fifoname);

   /* make FIFO*/
   if (mkfifo(fifoname, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH) == -1 && errno != EEXIST) {
		printf("OAM_API[%s]: make FIFO %s failed!\n", __FUNCTION__, fifoname);
      return -1;
   }

   fd_fifo_api = open(fifoname, O_RDONLY);

   if (fd_fifo_api < 0) {
		printf("OAM_API[%s]: open FIFO %s failed!\n", __FUNCTION__, fifoname);
      return -1;
   }

   rd_sz = read(fd_fifo_api, &fifo_msg, sizeof(fifo_msg));

   if (rd_sz <= 0 || rd_sz < sizeof(OAM_FIFO_MSG_STATS)) {
		printf("OAM_API[%s]: FIFO %s read size %d error!\n",
		   __FUNCTION__, fifoname, rd_sz);

		ret = -1;
   }
   else {
      memcpy(counters, &fifo_msg.cnt, sizeof(oam_cell_counters_t));
		ret = 0;
   }

   close(fd_fifo_api);
   remove(fifoname);

   return ret;
}



int ifx_oam_cell_counters_reset(
         unsigned char vpi,
         unsigned short vci)
{
	OAM_CELL *pCell;
	int oam_sock, result;
	UINT32 cmdId, dummy1,dummy2;

	OAMPRINTF("oam_api [%s]: vpi[%d], vci[%d]\n", __FUNCTION__, vpi, vci);

	oam_sock = oam_create_sock();
	if(oam_sock<0){
		oam_close_sock(oam_sock);
		return -1;
	}
	pCell = (OAM_CELL *)malloc(OAM_CELL_SIZE);
	if(!pCell){
		return -1;
	}
	memset(pCell, 0x00, OAM_CELL_SIZE);	

	cmdId = 12; dummy1 = 0; dummy2 = 0;   /* command id 7 */
	pCell->cell[OAM_TYPE_FN]   = 0x10;   /* oam cell */
	pCell->cell[1+OAM_TYPE_FN] = vpi;    /* vpi*/
	pCell->cell[2+OAM_TYPE_FN] = 0xFF;   /* vci */
	pCell->cell[3+OAM_TYPE_FN] = 0xFF;   /* scope: ETE-0, SEG-1 */
	pCell->cell[4+OAM_TYPE_FN] = 0xFF;   /* frequency 5-64K sec*/
	pCell->cell[5+OAM_TYPE_FN] = cmdId;
	memcpy(&pCell->cell[6+OAM_TYPE_FN], (char *)&vci, sizeof(vci));

	result = infi_push_oam((UINT8 *)pCell,oam_sock);
	free(pCell);
	oam_close_sock(oam_sock);

	if (result != 0) {
      return -1;
   }

   return 0;
}



int ifx_oam_fsm_timer_config_set(
         unsigned char vpi,
         unsigned short vci,
         oam_fsm_timer_cfg_t *timer_cfg)
{
	OAM_CELL *pCell;
	int oam_sock, result;
	UINT32 cmdId, dummy1,dummy2;

	OAMPRINTF("oam_api [%s]: vpi[%d], vci[%d]\n", __FUNCTION__, vpi, vci);

   if (timer_cfg == NULL) {
      return -1;
   }

   if (timer_cfg->oam_ais_not_rx == 0 || timer_cfg->oam_ais_persist == 0 ||
       timer_cfg->oam_cc_sink == 0 || timer_cfg->oam_rdi_not_rx == 0 ||
       timer_cfg->oam_rdi_persist == 0) {
   	OAMPRINTF("oam_api [%s]: ERROR - inconsistent timer configuration!\n", __FUNCTION__);

      return -1;
   }

	oam_sock = oam_create_sock();
	if (oam_sock < 0) {
		return -1;
	}

	pCell = (OAM_CELL *)malloc(OAM_CELL_SIZE);
	if (!pCell) {
		oam_close_sock(oam_sock);
		return -1;
	}
	memset(pCell, 0x00, OAM_CELL_SIZE);	

	cmdId = 13; dummy1 = 0; dummy2 = 0;   /* command id 7 */
	pCell->cell[OAM_TYPE_FN]   = 0x10;   /* oam cell */
	pCell->cell[1+OAM_TYPE_FN] = vpi;    /* vpi*/
	pCell->cell[2+OAM_TYPE_FN] = 0xFF;   /* vci */
	pCell->cell[3+OAM_TYPE_FN] = 0xFF;   /* scope: ETE-0, SEG-1 */
	pCell->cell[4+OAM_TYPE_FN] = 0xFF;   /* frequency 5-64K sec*/
	pCell->cell[5+OAM_TYPE_FN] = cmdId;
	memcpy(&pCell->cell[6+OAM_TYPE_FN], (char *)&vci, sizeof(vci));
	memcpy(&pCell->cell[6+OAM_TYPE_FN + sizeof(vci)], (char *)timer_cfg, sizeof(oam_fsm_timer_cfg_t));

	result = infi_push_oam((UINT8 *)pCell,oam_sock);
	free(pCell);
	oam_close_sock(oam_sock);

	if (result != 0) {
      return -1;
   }

   return 0;
}
