/****************************************************************************
** FILE NAME     : ifx_debug.h
** PROJECT       : TR69 Team
** MODULES       : Debug Management module
** SRC VERSION   : V0.1
** DATE          : 01-10-2004
** AUTHOR        : Hari
** DESCRIPTION   : This file contains the code for Debug Management
** REFERENCE     : Coding guide lines.
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author      $Comment
*****************************************************************************/

/*! \file ifx_debug.h
    \brief This file contains the code for Debug Management
*/

#ifndef __IFX_DEBUG_H__


/*! \def IFX_SUCCESS 
    \brief Success
*/
#define IFX_SUCCESS 0

/*! \def IFX_FAIL 
    \brief Fail
 */
#define IFX_FAIL   -1

/* No debug */
/*! \def IFX_DBG_LVL_NONE 
    \brief No debug
 */
#define IFX_DBG_LVL_NONE  0


/*! \def IFX_DBG_LVL_ERROR 
    \brief Used only for all Error Handling Debugs
 */
#define IFX_DBG_LVL_ERROR  1
/* Guidelines 
 * File Open Error
 * Socket Open Error
 * Memory Initialisation Error
 * Fifo Creation Error
 * Process Creation Error
 */

/* Minimal Information to describe the control flow */
/*! \def IFX_DBG_LVL_LOW 
    \brief Minimal Information to describe the control flow
 */
#define IFX_DBG_LVL_LOW    2
/* Guidelines 
 * Module Initialisation Success
 * Memory/Timer Initialisation Success
 */


/* More Information to describe the control flow */
/*! \def IFX_DBG_LVL_NORMAL 
    \brief More Information to describe the control flow
 */
#define IFX_DBG_LVL_NORMAL 3
/* Guidelines 
 * Interprocess Communication Messages
 * Important Function Calls
 * Minimal Info on Signalling Path
 * Minimal Info on Voice Path setup
 */


/* Used for Testing/Debugging - Should not be set during final builds */
/*! \def IFX_DBG_LVL_HIGH 
    \brief Used for Testing/Debugging
 */
#define IFX_DBG_LVL_HIGH 4
/* Guidelines
 * Used for anything else other than mentioned for other Debug Levels
 * Inside for Loops
 * Printing of Parameters
 * Full Control flow between modules with values of all parameters
 */


/*! \def IFX_DBG_TYPE_NONE 
    \brief TODO
 */
#define IFX_DBG_TYPE_NONE    0

/*! \def IFX_DBG_TYPE_CONSOLE 
    \brief TODO
 */
#define IFX_DBG_TYPE_CONSOLE 1

/*! \def IFX_DBG_TYPE_FILE 
    \brief TODO
 */
#define IFX_DBG_TYPE_FILE    2

/*! \enum x_IFX_DBG_Types
    \brief Enum containing all debug info types .
*/
typedef enum
{
   /* Common Errors */
   IFX_DBG_FIFO_CREATION_ERR,    /*!< TODO */
   IFX_DBG_FIFO_OPEN_ERR,        /*!< TODO */
   IFX_DBG_FIFO_READ_ERR,        /*!< TODO */
   IFX_DBG_FIFO_WRITE_ERR,       /*!< TODO */
   IFX_DBG_PROCESS_CREATION_ERR, /*!< TODO */
   IFX_DBG_GENERAL_ERR,          /*!< TODO */
   IFX_DBG_INVALID_MSG_ERR,      /*!< TODO */
   IFX_DBG_MSG_PROCESS_ERR,      /*!< TODO */
   IFX_DBG_FUNC_ERROR,           /*!< TODO */
   IFX_DBG_MODULE_INIT_ERR,      /*!< TODO */
   IFX_DBG_CONFIG_FAILURE,       /*!< TODO */
   IFX_DBG_SOCK_CREATE_ERR,      /*!< TODO */
   IFX_DBG_SOCK_RECV_ERR,        /*!< TODO */
   IFX_DBG_SOCK_SEND_ERR,        /*!< TODO */ 
   IFX_DBG_READ_FAILURE,         /*!< TODO */
   IFX_DBG_WRITE_FAILURE,        /*!< TODO */
   
   /* Memory Errors */

   IFX_DBG_MEM_LIB_INIT_ERR,   /*!< TODO */
   IFX_DBG_MEM_ALLOC_ERR,      /*!< TODO */
   IFX_DBG_MEM_FREE_ERR,       /*!< TODO */

   /* Timer Errors */ 

   IFX_DBG_TIMER_LIB_INIT,     /*!< TODO */
   IFX_DBG_TIMER_START_ERR,    /*!< TODO */
   IFX_DBG_TIMER_STOP_ERR,     /*!< TODO */
	IFX_DBG_TIMER_ERR,     /*!< TODO */
   
   /* Common Informative Debugs */

   IFX_DBG_STR,                 /*!< TODO */
   IFX_DBG_PROCESS_STARTED,     /*!< TODO */
   IFX_DBG_MODULE_INITIALIZED,  /*!< TODO */  
   IFX_DBG_MSG_RECEIVED,        /*!< TODO */
   IFX_DBG_FUNC_SUCCESS,        /*!< TODO */
   IFX_DBG_CONFIG_SUCCESS,      /*!< TODO */
   IFX_DBG_SELECT_UNBLOCK,      /*!< TODO */

   /* CM Info Type */
   IFX_DBG_CM_REQ_TYPE,      /*!< TODO */
   IFX_DBG_CM_INFO_TYPE,     /*!< TODO */
 
   /* Module Specific Errors */

   /* TR69 */
   
   IFX_DBG_TR69_CM_IF,            /*!< TODO */
   IFX_DBG_TR69_RTP_IF,           /*!< TODO */
   IFX_DBG_TR69_RM_IF,            /*!< TODO */
   IFX_DBG_TR69_PA_IF,            /*!< TODO */
   IFX_DBG_TR69_SEND_ERR,         /*!< TODO */
   IFX_DBG_TR69_HANDLE_RSP_ERR,   /*!< TODO */
   IFX_DBG_TR69_HANDLE_REQ_ERR,   /*!< TODO */
   IFX_DBG_TR69_CHANNEL_ID_ERR,   /*!< TODO */
   IFX_DBG_TR69_RTP_PORT_ERR,     /*!< TODO */
   IFX_DBG_TR69_REPLACE_ERR,      /*!< TODO */
   IFX_DBG_TR69_CONTACT_HDR_ERR,  /*!< TODO */
   IFX_DBG_TR69_ENC_ERR,          /*!< TODO */
   IFX_DBG_TR69_DEC_ERR,          /*!< TODO */
   IFX_DBG_TR69_ERR,              /*!< TODO */
   IFX_DBG_TR69_SEND_RSP_ERR,     /*!< TODO */
   IFX_DBG_TR69_ADDR,             /*!< TODO */

   /* PA */
   IFX_DBG_PA_FD_OPEN_ERR,        /*!< TODO */
   IFX_DBG_PA_FD_CLOSE_ERR,       /*!< TODO */
   IFX_DBG_PA_FILE_ERR,           /*!< TODO */
   IFX_DBG_PA_TIMEOUT,            /*!< TODO */
   IFX_DBG_PA_ADDR_TYPE,          /*!< TODO */
   IFX_DBG_PA_ADDR_INFO,          /*!< TODO */ 
   IFX_DBG_PA_TEL_ADDR_INFO,      /*!< TODO */ 
   IFX_DBG_PA_IGNR_EVNT,          /*!< TODO */
   IFX_DBG_PA_FSM,                /*!< TODO */ 
   IFX_DBG_PA_FCN_RET_ERR,        /*!< TODO */
   IFX_DBG_PA_AUTH,               /*!< TODO */
   IFX_DBG_PA_SET_FREE,           /*!< TODO */
   IFX_DBG_PA_SET_USED,           /*!< TODO */
   IFX_DBG_PA_CONF_STATE,         /*!< TODO */    
   IFX_DBG_PA_FIRST_CALL_STATE,   /*!< TODO */
   IFX_DBG_PA_SECOND_CALL_STATE,  /*!< TODO */
   IFX_DBG_PA_CALL_REGISTER,      /*!< TODO */
   IFX_DBG_PA_DEVICE_MODE,        /*!< TODO */
   IFX_DBG_PA_CALL_PROCESSING,    /*!< TODO */
   IFX_DBG_PA_CURSOR,             /*!< TODO */
   IFX_DBG_PA_CALL_CONF,          /*!< TODO */
   IFX_DBG_PA_INBOX_DBG,          /*!< TODO */
	IFX_DBG_PA_COMPOSE_DBG,   /*!< TODO */ 
   IFX_DBG_PA_RING_MUTE,          /*!< TODO */
   IFX_DBG_PA_VOICE_PARAM,        /*!< TODO */
	IFX_DBG_PA_VAL,           /*!< TODO */


   /* ATA */
   /* Error */
   IFX_DBG_ATA_PLAY_TONE_ERR,     /*!< TODO */
   IFX_DBG_ATA_GENERAL_ERR,       /*!< TODO */
   IFX_DBG_ATA_SIGNAL_ERR,        /*!< TODO */
   IFX_DBG_ATA_CHANNEL_ERR,       /*!< TODO */
   IFX_DBG_ATA_INTERFACE_ERR,     /*!< TODO */
   IFX_DBG_ATA_DTMF_AUTH_ERR,     /*!< TODO */
   IFX_DBG_ATA_DTMF_FEATCODE_ERR, /*!< TODO */
   IFX_DBG_ATA_DTMF_FEATINFO_ERR, /*!< TODO */

   /* Informative */
   IFX_DBG_ATA_SHUTDOWN,         /*!< TODO */
   IFX_DBG_ATA_DIALED_DIGIT,     /*!< TODO */
   IFX_DBG_ATA_CHANNEL_NO,       /*!< TODO */
   IFX_DBG_ATA_CONNECTIONID,     /*!< TODO */
   IFX_DBG_ATA_FIFO_INFO,        /*!< TODO */
   IFX_DBG_ATA_TAPI_EXCEPT_BIT,  /*!< TODO */
   IFX_DBG_ATA_TAPI_EVENT,       /*!< TODO */
   IFX_DBG_ATA_TIMEOUT_VALUE,    /*!< TODO */
   IFX_DBG_ATA_CID_INFO,         /*!< TODO */
   IFX_DBG_ATA_STATE_EVENT_INFO,   /*!< TODO */
   IFX_DBG_ATA_DTMF_TIMER_STATUS,  /*!< TODO */
   IFX_DBG_ATA_USERNAMEORPASSWD,   /*!< TODO */
   IFX_DBG_ATA_DTMF_EXTN_NO_INFO,  /*!< TODO */
   IFX_DBG_ATA_DTMF_PASSWD_INFO,   /*!< TODO */
   IFX_DBG_ATA_DTMF_FEATINFOSTR,   /*!< TODO */
   IFX_DBG_ATA_DTMF_DHCP_INFO,     /*!< TODO */
   IFX_DBG_ATA_DTMF_CM_EXTN_TEST,  /*!< TODO */
   IFX_DBG_ATA_DTMF_CM_INT_TEST,   /*!< TODO */
   IFX_DBG_ATA_DTMF_CM_STRING_TEST,/*!< TODO */
   IFX_DBG_ATA_DTMF_DELIM_CNT,     /*!< TODO */
	IFX_DBG_ATA_STRING_INFO,   /*!< TODO */
	IFX_DBG_ATA_INT_INFO,      /*!< TODO */


   /* RTP */

   IFX_DBG_RTP_STR_ERR,             /*!< TODO */
   IFX_DBG_RTP_STR_PRINT,           /*!< TODO */
   IFX_DBG_RTP_IOCTL_STR_PRINT,     /*!< TODO */
   IFX_DBG_RTP_RTCP_STR_PRINT,      /*!< TODO */
   IFX_DBG_RTP_TR69_IF,             /*!< TODO */
   IFX_DBG_RTP_RM_IF,               /*!< TODO */
   IFX_DBG_RTP_SRTP_IF,             /*!< TODO */

   /* RM */

   IFX_DBG_RM_CODEC_LIST_ERR,       /*!< TODO */
   IFX_DBG_RM_CODEC_LIST,           /*!< TODO */
   IFX_DBG_RM_RES_TBL_FILL_ERR,     /*!< TODO */
   IFX_DBG_RM_RES_TBL_FILL_SUC,     /*!< TODO */
   IFX_DBG_RM_GET_BW_ERR,           /*!< TODO */
   IFX_DBG_RM_SUPP_CODECS,          /*!< TODO */
   IFX_DBG_RM_CONFIG_CODECS,        /*!< TODO */
   IFX_DBG_RM_CODEC_CHANGE,         /*!< TODO */
   IFX_DBG_RM_PREF_CODEC_CHANGE_ERR, /*!< TODO */
   IFX_DBG_RM_CODEC_CHANGE_SUCCESS,  /*!< TODO */
   IFX_DBG_RM_CODEC_CHANGE_FAIL,     /*!< TODO */
   IFX_DBG_RM_LINK_BW_ERR,           /*!< TODO */
   IFX_DBG_RM_FRAME_SIZE,            /*!< TODO */
   IFX_DBG_RM_FUNC_PARAMS,           /*!< TODO */
   IFX_DBG_RM_ALLOC_CODER_SUCCESS,   /*!< TODO */
   IFX_DBG_RM_CODEC_BANDWIDTH,       /*!< TODO */
   IFX_DBG_RM_FUNC_START,            /*!< TODO */
   IFX_DBG_RM_LINK_BW,               /*!< TODO */
   IFX_DBG_RM_FRAMESIZE_CM,          /*!< TODO */
   IFX_DBG_RM_ERR_COUNT,             /*!< TODO */
   IFX_DBG_RM_ERR_CODE,              /*!< TODO */
   IFX_DBG_RM_PREF_CODEC,            /*!< TODO */
   IFX_DBG_RM_ALLOC_CODER,           /*!< TODO */
   IFX_DBG_RM_DEALLOC_CODER,         /*!< TODO */
   IFX_DBG_RM_MODIFY_CODER,          /*!< TODO */
   IFX_DBG_RM_ALLOC_CODEC,           /*!< TODO */
   IFX_DBG_RM_SESS_BW,               /*!< TODO */
   IFX_DBG_RM_ERR_REASON,            /*!< TODO */
   IFX_DBG_RM_LOCK_CODEC,            /*!< TODO */
   IFX_DBG_RM_CODER_MSG,             /*!< TODO */
   IFX_DBG_RM_LOCK_UNLOCK,           /*!< TODO */
   IFX_DBG_RM_LESS_BW_ERR,           /*!< TODO */
   IFX_DBG_RM_LOCK_CODEC_INFO,       /*!< TODO */
   IFX_DBG_RM_UNLOCK_CODEC_INFO,     /*!< TODO */
   IFX_DBG_RM_ALLOC_ANALOG,          /*!< TODO */
   IFX_DBG_RM_DEALLOC_ANALOG,        /*!< TODO */
   IFX_DBG_RM_CONV_INFO,             /*!< TODO */
   IFX_DBG_RM_FW_INFO,               /*!< TODO */
   IFX_DBG_RM_DEV_NAME,              /*!< TODO */
   IFX_DBG_RM_DEV_ERR,               /*!< TODO */


   /* CM */
   IFX_DBG_CM_REQ_TYPE_ERR,          /*!< TODO */
   IFX_DBG_CM_INFO_TYPE_ERR,         /*!< TODO */
   IFX_DBG_CM_CFG_FILE_ABSENT,       /*!< TODO */
   IFX_DBG_CM_CFG_FILE_VER_ERR,      /*!< TODO */
   IFX_DBG_CM_CFG_FILE_READ_ERR,     /*!< TODO */
   IFX_DBG_CM_CFG_FILE_WRITE_ERR,    /*!< TODO */
   IFX_DBG_CM_CFG_FILE_WRITE_SIZE,   /*!< TODO */
   IFX_DBG_CM_CFG_FILE_WRITE_INFO,   /*!< TODO */

   /* SRTP */

   IFX_DBG_SRTP_STREAM_ERR,         /*!< TODO */
   IFX_DBG_SRTP_PKT_ROC,            /*!< TODO */
   IFX_DBG_SRTP_FROM_TO_EXPIRY,     /*!< TODO */
   IFX_DBG_SRTP_ENABLE_ENC_DEC_ERR, /*!< TODO */
   IFX_DBG_SRTP_ENC_DEC_ERR,        /*!< TODO */
   IFX_DBG_SRTP_SSRC,               /*!< TODO */
   IFX_DBG_SRTP_PKT_LEN,            /*!< TODO */
   IFX_DBG_SRTP_AUTH_ERR,           /*!< TODO */
   IFX_DBG_SRTP_AUTH_SUCCESS,       /*!< TODO */
   IFX_DBG_SRTP_SEQ_NUM,            /*!< TODO */
   IFX_DBG_SRTP_HIGH_SEQ_NUM,       /*!< TODO */
   IFX_DBG_SRTP_REKEY,              /*!< TODO */
   IFX_DBG_SRTP_SESS_KEY_REFRESH,   /*!< TODO */
   IFX_DBG_SRTP_PKT_IDX,            /*!< TODO */
   IFX_DBG_SRTP_REPLAY_LIST_UPDATE, /*!< TODO */
   IFX_DBG_SRTP_MKI_MISMATCH_ERR,   /*!< TODO */

   /* Fax */

   IFX_DBG_FA_SEND_PKT_TO_NET,     /*!< TODO */
   IFX_DBG_FA_END_OF_FAX,          /*!< TODO */
   IFX_DBG_FA_GET_STATS_ERR,       /*!< TODO */
   IFX_DBG_FA_SESS_START_ERR,      /*!< TODO */
   IFX_DBG_FA_SESS_STOP_ERR,       /*!< TODO */
   IFX_DBG_FA_GENERAL_ERR,         /*!< TODO */
   IFX_DBG_FA_SEND_DATA_TO_DP,     /*!< TODO */
   IFX_DBG_FA_FUNC_START,          /*!< TODO */
   IFX_DBG_FA_DP_ERR,              /*!< TODO */
   IFX_DBG_FA_FUNC_SUCCCESS,       /*!< TODO */
   IFX_DBG_FA_FUNC_FAIL,           /*!< TODO */
   IFX_DBG_FA_RX_MSG,              /*!< TODO */
   IFX_DBG_FA_RX_ERR_MSG,          /*!< TODO */
   IFX_DBG_FA_INIT_PARAM,          /*!< TODO */
   IFX_DBG_FA_REMOTE_ADDR,         /*!< TODO */
   IFX_DBG_FA_SESS_REQ,            /*!< TODO */
   IFX_DBG_FA_T38_PARAM,           /*!< TODO */
   IFX_DBG_FA_ERR_REASON,          /*!< TODO */
   IFX_DBG_FA_DATA,                /*!< TODO */
   IFX_DBG_FA_CHANNEL,             /*!< TODO */
	IFX_DBG_FA_HEX_DISPLAY,    /*!< TODO */
   
} x_IFX_DBG_Types;

#ifdef DEBUG_ENABLED

/*!\fn void IFX_DBG_Init(IN char8 * pcModuleName, IN char8 ucDbgType, IN char8 ucDbgLvl, OUT uchar8 * pucModuleId, OUT char8 * pcRet)
   \brief extern void type function Initialises the Debug for a particular module
   \param[in] pcModuleName 
   \param[in] ucDbgType
   \param[in] ucDbgLvl
   \param[out] pucModuleId
   \param[out] pcRet
   \return IFX_SUCCESS/IFX_FAIL
*/

EXTERN void IFX_DBG_Init(IN char8 * pcModuleName, IN char8 ucDbgType,
             IN char8 ucDbgLvl, OUT uchar8 * pucModuleId, OUT char8 * pcRet);

/*!\fn char8 IFX_DBG_Set(IN char8 * pcModuleName, IN uchar8 cModuleId, IN char8 ucDbgType, IN char8 ucDbgLvl)
   \brief extern char8 type function Modifies the Debug settings at run-time. 
   \param[in] pcModuleName 
   \param[in] cModuleId
   \param[in] ucDbgType
   \param[in] ucDbgLvl
   \return IFX_SUCCESS/IFX_FAIL
*/
EXTERN char8 IFX_DBG_Set(IN char8 * pcModuleName, IN uchar8 cModuleId,
            IN char8 ucDbgType, IN char8 ucDbgLvl);

/*!\fn void IFX_DBG_Shut(IN uchar8  ucModuleId, OUT char8 * pcRet)
   \brief extern void type function Cleans up the Debug Registration for a particular module
   \param[in] ucModuleId 
   \param[out] pcRet
   \return IFX_SUCCESS/IFX_FAIL
*/

EXTERN void IFX_DBG_Shut(IN uchar8  ucModuleId, OUT char8 * pcRet);

/*!\fn void IFX_DBG_Log(IN uchar8 ucModuleId, IN uchar8 ucDbgLvl, IN char8 * pucStr, ...)
   \brief extern void type function Logs Debug messages
   \param[in] ucModuleId 
   \param[in] ucDbgLvl
   \param[in] pucStr
   \return IFX_SUCCESS/IFX_FAIL
*/
EXTERN void IFX_DBG_Log(IN uchar8 ucModuleId, IN uchar8 ucDbgLvl, 
             IN char8 * pucStr, ...);

/*!\fn char8 * vacMsgTbl[]
   \brief extern char8 type function TODO
   \return TODO
*/

EXTERN char8 * vacMsgTbl[];

#else /* DEBUG_ENABLED */

/*!\def IFX_DBG_Init
   \brief Modifies the Debug settings at run-time
*/
#define IFX_DBG_Init(pcModuleName, ucDbgType, ucDbgLvl, pucModuleId, pcRet) \
{ \
   *pcRet = 0; \
}

/*!\def IFX_DBG_Set
   \brief Modifies the Debug settings at run-time
*/
#define IFX_DBG_Set(pcModuleName, cModuleId, ucDbgType, ucDbgLvl) 

/*!\def IFX_DBG_Shut
   \brief Cleans up the Debug Registration for a particular module
*/
#define IFX_DBG_Shut(ucModuleId, pcRet) \
{ \
   *pcRet = 0; \
}

/*!\def IFX_DBG_Log
   \brief Logs Debug messages
*/
#define IFX_DBG_Log(ucModuleId, ucDbgLvl, pucStr, ...)

#endif /* DEBUG_ENABLED */

/*!\def IFX_DBGA
   \brief TODO
*/
#define IFX_DBGA(ucModuleId, ucDbgLvl, unMsgId, ...) \
{ \
   IFX_DBG_Log(ucModuleId, ucDbgLvl, vacMsgTbl[unMsgId], __VA_ARGS__); \
}

/*!\def IFX_DBG
   \brief TODO
*/
/*#define IFX_DBG(ucModuleId, ucDbgLvl, unMsgId) \
{ \
   IFX_DBG_Log(ucModuleId, ucDbgLvl, vacMsgTbl[unMsgId]); \
}*/

#endif /* __IFX_DEBUG_H__ */
