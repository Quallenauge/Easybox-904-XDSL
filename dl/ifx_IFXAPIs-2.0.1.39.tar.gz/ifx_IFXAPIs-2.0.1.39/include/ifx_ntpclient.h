/* ============================================================================
 * Copyright (C) 2004 - Infineon Technologies.
 *
 * All rights reserved.
 * ============================================================================
 *
 * ============================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ============================================================================
 *
 * Revision History:
 *      - 2004/07/13, MarsLin
 *         init version
 *
 * ============================================================================
 */

/*! \file ifx_ntpclient.h
    \brief This function contains the NTP Client API function prototypes
*/
#ifndef _IFX_NTPCLIENT_H_
#define _IFX_NTPCLIENT_H_


/*! \brief  This function starts the NTP client
        \param[in] pServerName
        \param[in] iTimeMinuteOffset
        \return Returns zero on success 
*/
int ifx_ntpclient_enable(char *pServerName, int iTimeMinuteOffset);

/*! \brief  This function stops the NTP client
          \return Returns zero on success
*/
int ifx_ntpclient_disable();

#endif /* _IFX_NTPCLIENT_H_ */

