#ifndef __IFX_ALG_H_
#define __IFX_ALG_H_

#include "ifx_alg_common.h"


/*! \file ifx_alg.h
    \brief This header file contains macros and structures for ALGs
*/
/** \defgroup IFX_ALG  Description of ALG
    \brief TBD
*/
/* @{ */


/*!
    \brief Structure describing the RTSP parameters
*/
struct rtsp_params
{
	int alg_port;  /*!< ALG port */
	enum AlgControlProtocol ip_proto;  /*!< ALG control protocal */
};


/*!
    \brief Structure describing the SIP parameters
*/
struct sip_params
{
	int src_port;  /*!< Source Port */
	int dst_port;   /*!< Destination Port */
	enum AlgControlProtocol ip_proto;  /*!< ALG control protocal */
};


/*!
    \brief Structure describing the alg information
*/
struct alg_info
{
	int protocol_name;  /*!< Protocal name */
	enum AlgControlProtocol ip_protocol;  /*!< ALG control protocal */
	int port;  /*!< Port */ 
	int nat_flag;  /*!< NAT Flag */ 
	char lanitf[20];  /*!< LAN interface */ 
	char wanitf[20];  /*!< WAN interface */ 
	struct alg_info *next;  /*!< ALG info type */
};


/*!
    \brief Structure describing the SIP DNAT parameters
*/
struct sip_dnat_param
{
	int original_port;  /*!< Original Port */
	int changed_port;    /*!< Changed Port */
	char original_ip_address[16];  /*!< Original IP address */
	char changed_ip_address[16];  /*!< Changed IP address */
	enum AlgControlProtocol proto;  /*!< ALG control Protocol  */
	int typeofchange;  /*!< Type of change */
	int validdataflag;  /*!< Valid Data flag */
};


/* The major device number. We can't rely on dynamic 
 * registration any more, because ioctls need to know 
 * it. */


/*!\def MAJOR_NUM_RTSP
   \brief RTSP Major Number 
*/
#define MAJOR_NUM_RTSP 		100


/*!\def MAJOR_NUM_RTSP_CONN
   \brief RTSP Connection Major Number
*/
#define MAJOR_NUM_RTSP_CONN 	231


/*!\def MAJOR_NUM_SIP
   \brief SIP Major Number
*/
#define MAJOR_NUM_SIP		233


/*!\def MAJOR_NUM_SIP_CONN
   \brief SIP Connection Major Number
*/
#define MAJOR_NUM_SIP_CONN	234




/*!\def IOCTL_DEREGISTER_SIP_PORT
   \brief ioctl call to deregister SIP Port  
*/
#define IOCTL_DEREGISTER_SIP_PORT _IOWR(MAJOR_NUM_SIP, 3, struct rtsp_params*)


/*!\def IOCTL_DEREGISTER_SIP_PORT_CONN
   \brief ioctl call to deregister SIP Port connection
*/
#define IOCTL_DEREGISTER_SIP_PORT_CONN _IOWR(MAJOR_NUM_SIP_CONN, 3, struct rtsp_params*)


/*!\def IOCTL_DEREGISTER_RTSP_PORT
   \brief ioctl call to deregister RTSP Port 
*/
#define IOCTL_DEREGISTER_RTSP_PORT _IOR(MAJOR_NUM_RTSP, 3, struct rtsp_params*)


/*!\def IOCTL_DEREGISTER_RTSP_PORT_CONN
   \brief 
*/
#define IOCTL_DEREGISTER_RTSP_PORT_CONN _IOR(MAJOR_NUM_RTSP_CONN, 3, struct rtsp_params*)



/* Get the n'th byte of the message */
//#define IOCTL_GET_NTH_BYTE _IOWR(MAJOR_NUM, 2, int)


/*!\def IOCTL_REGISTER_SIP_PORT
   \brief ioctl call for to register SIP Port
*/
#define IOCTL_REGISTER_SIP_PORT _IOWR(MAJOR_NUM_SIP, 2, struct rtsp_params*)


/*!\def IOCTL_REGISTER_SIP_PORT_CONN
   \brief ioctl call to register SIP port connection
*/
#define IOCTL_REGISTER_SIP_PORT_CONN _IOWR(MAJOR_NUM_SIP_CONN, 2, struct rtsp_params*)


/*!\def IOCTL_REGISTER_RTSP_PORT
   \brief ioctl call to register RTSP port
*/
#define IOCTL_REGISTER_RTSP_PORT _IOWR(MAJOR_NUM_RTSP, 2, struct rtsp_params*)


/*!\def IOCTL_REGISTER_RTSP_PORT_CONN
   \brief ioctl call to register RTSP port connection
*/
#define IOCTL_REGISTER_RTSP_PORT_CONN _IOWR(MAJOR_NUM_RTSP_CONN, 2, struct rtsp_params*)


/*!\def IOCTL_SIP_ALG_DAEMON
   \brief ioctl call to SIP alg daemon
*/
#define IOCTL_SIP_ALG_DAEMON _IOWR(MAJOR_NUM_SIP, 4, struct sip_dnat_param*)


/*!\def IOCTL_SIP_TEST_CASE
   \brief ioctl call to SIP test case
*/
#define IOCTL_SIP_TEST_CASE _IOWR(MAJOR_NUM_SIP, 5, struct rtsp_params*)




/* The IOCTL is used for both input and output. It 
  * receives from the user a number, n, and returns 
  * Message[n]. */


/* The name of the device file */

/*!\def DEVICE_FILE_NAME_SIP
   \brief SIP device file
*/
#define DEVICE_FILE_NAME_SIP		"/dev/sip_dev"


/*!\def DEVICE_FILE_NAME_SIP_CONN
   \brief SIP connection device file
*/
#define DEVICE_FILE_NAME_SIP_CONN	"/dev/sip_conn_dev"


/*!\def DEVICE_FILE_NAME_RTSP
   \brief RTSP device file
*/
#define DEVICE_FILE_NAME_RTSP		"/dev/rtsp_dev"


/*!\def DEVICE_FILE_NAME_RTSP_CONN
   \brief RTSP connection device file
*/
#define DEVICE_FILE_NAME_RTSP_CONN 	"/dev/rtsp_conn_dev"

/* @} */ 

#endif
