/* ============================================================================
 * Copyright (C) 2004 - Infineon Technologies.
 *
 * All rights reserved.
 * ============================================================================
 *
 * ============================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ============================================================================
 *
 * Revision History:
 *      - 2004/07/13, MarsLin
 *         init version
 *
 * ============================================================================
 */

/*! \file ifx_webserver.h
    \brief This function contains the webserver API function prototypes
*/

#ifndef _IFX_WEBSERVER_H_
#define _IFX_WEBSERVER_H_

/*! \brief  This function is used to enable webserver
        \param[in] iPort
        \return Status of the webserver enable execution
*/
int ifx_webserver_enable(int iPort);


/*! \brief  This function is used to disable webserver
        \return Status of the webserver disable execution
*/
int ifx_webserver_disable();

#endif /* _IFX_WEBSERVER_H_ */
