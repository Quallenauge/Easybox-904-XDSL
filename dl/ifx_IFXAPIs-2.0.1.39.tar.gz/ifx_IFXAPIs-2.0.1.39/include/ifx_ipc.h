/*****************************************************************************
** FILE NAME     : ifx_ipc.c
** PROJECT       : TR69
** MODULES       : Common Libs
** SRC VERSION   : V0.1
** DATE          : 21-03-2005
** AUTHOR        : Hari
** DESCRIPTION   : This file contains all the data declarations that are
**                 shared across the modules
** REFERENCE     : Coding guide lines.
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author      $Comment
******************************************************************************/

/*! \file ifx_ipc.h 
    \brief This file contains all the data declarations that are shared across the modules
*/


#ifndef __IFX_IPC_H__
#define __IFX_IPC_H__

#ifdef IIP
/*! \def IFX_IPC_FIFO_DIR
    \brief IPC FIFO directory
*/
#define IFX_IPC_FIFO_DIR   "./tmp"
#endif
#ifdef ATA
/*! \def IFX_IPC_FIFO_DIR
    \brief IPC FIFO directory
*/
#define IFX_IPC_FIFO_DIR   "/tmp"
#endif

#define IFX_IPC_FIFO_PERM  0644

/* All modules write to Monitor thru this Fifo */
/*! \def IFX_IPC_MON_FIFO
    \brief All modules write to Monitor thru this Fifo
*/
#define IFX_IPC_MON_FIFO     IFX_IPC_FIFO_DIR"/MonFifo"

/* All modules write to RM thru this Fifo */
/*! \def IFX_IPC_RM_FIFO
    \brief All modules write to RM thru this Fifo
*/
#define IFX_IPC_RM_FIFO     IFX_IPC_FIFO_DIR"/RmFifo"


/* All modules write to RTP thru this Fifo */
/*! \def IFX_IPC_RTP_FIFO
    \brief All modules write to RTP thru this Fifo
*/
#define IFX_IPC_RTP_FIFO    IFX_IPC_FIFO_DIR"/RtpFifo"

/* All modules writes to APP thru this Fifo */
/* For IIP, APP = PA: for ATA, APP = ATA */
/*! \def IFX_IPC_APP_FIFO
    \brief All modules writes to APP thru this Fifo
*/
#define IFX_IPC_APP_FIFO     IFX_IPC_FIFO_DIR"/AppFifo"

/* All modules write to CM thru this Fifo */
/*! \def IFX_IPC_CM_FIFO
    \brief All modules write to CM thru this Fifo
*/
#define IFX_IPC_CM_FIFO     IFX_IPC_FIFO_DIR"/CmFifo"

/* All modules write to FA thru this Fifo */
/*! \def IFX_IPC_FA_FIFO
    \brief All modules write to FA thru this Fifo
*/
#define IFX_IPC_FA_FIFO     IFX_IPC_FIFO_DIR"/FaFifo"

/* All modules write to SS thru this Fifo */
/*! \def IFX_IPC_SS_FIFO
    \brief All modules write to SS thru this Fifo
*/
#define IFX_IPC_SS_FIFO     IFX_IPC_FIFO_DIR"/SsFifo"

/* CM writes to WebServer thru this Fifo */
/*! \def IFX_IPC_WEB_FIFO
    \brief CM writes to WebServer thru this Fifo
*/
#define IFX_IPC_WEB_FIFO   IFX_IPC_FIFO_DIR"/WebFifo"

/* CM writes to SNMP Agent thru this Fifo */
/*! \def IFX_IPC_SNMP_FIFO
    \brief CM writes to SNMP Agent thru this Fifo
*/
#define IFX_IPC_SNMP_FIFO   IFX_IPC_FIFO_DIR"/SnmpFifo"

/* DHCP writes to CM thru this Fifo */
/*! \def IFX_DHCP_CM_FIFO
    \brief DHCP writes to CM thru this Fifo
*/
#define IFX_DHCP_CM_FIFO   IFX_IPC_FIFO_DIR"/DhcpFifo"

/*! \def IFX_IPC_SUCCESS
    \brief Success.
*/
#define IFX_IPC_SUCCESS 0


/*! \def IFX_IPC_FAIL
    \brief Failure.
*/
#define IFX_IPC_FAIL    -1

/*! \def IFX_IPC_APP_NAME_START
    \brief IPC application - VoIP startup.
*/
#define IFX_IPC_APP_NAME_START  "VoIPStartup"

/*! \def IFX_IPC_APP_NAME_PA
    \brief IPC application - phoneApp
*/
#define IFX_IPC_APP_NAME_PA  "PhoneApp"

/*! \def IFX_IPC_APP_NAME_ATA
    \brief IPC application AtaApp
*/
#define IFX_IPC_APP_NAME_ATA  "AtaApp"

/*! \def IFX_IPC_APP_NAME_CM
    \brief IPC application Config Mode
*/
#define IFX_IPC_APP_NAME_CM    "CfgMod"

/*! \def IFX_IPC_APP_NAME_RM
    \brief IPC application Resource Manager
*/
#define IFX_IPC_APP_NAME_RM    "ResMgr"

/*! \def IFX_IPC_APP_NAME_RTP
    \brief IPC application RTP 
*/
#define IFX_IPC_APP_NAME_RTP   "Rtp"

/*! \def IFX_IPC_APP_NAME_SRTP
    \brief IPC application Srtp
*/
#define IFX_IPC_APP_NAME_SRTP "Srtp"

/*! \def IFX_IPC_APP_NAME_TR69
    \brief IPC application TR69
*/
#define IFX_IPC_APP_NAME_TR69   "TR69UA"

/*! \def IFX_IPC_APP_NAME_FA
    \brief IPC application Fax Agent
*/
#define IFX_IPC_APP_NAME_FA    "FaxAgt"

/*! \def IFX_IPC_APP_NAME_DHCP
    \brief IPC application DHCP
*/
#define IFX_IPC_APP_NAME_DHCP "Dhcp"

/*! \def IFX_IPC_APP_NAME_SNMP
    \brief IPC application Snmp
*/
#define IFX_IPC_APP_NAME_SNMP "Snmp"


/*! \enum e_IFX_IPC_AppId
    \brief This enumeration is used for IPC Application ID.
*/
typedef enum
{
   IFX_IPC_APP_ID_START = 1, /*!< TBD  */
   IFX_IPC_APP_ID_APP = 2, /*!< TBD  */
   IFX_IPC_APP_ID_CM = 3, /*!< TBD  */
   IFX_IPC_APP_ID_RM = 4, /*!< TBD  */
   IFX_IPC_APP_ID_RTP = 5, /*!< TBD  */
   IFX_IPC_APP_ID_WEB = 6, /*!< TBD  */
   IFX_IPC_APP_ID_TR69 = 7, /*!< TBD  */
   IFX_IPC_APP_ID_FA = 8, /*!< TBD  */
   IFX_IPC_APP_ID_DHCP =9, /*!< TBD  */
   IFX_IPC_APP_ID_SNMP =10 /*!< TBD  */

} e_IFX_IPC_AppId;


/*!
    \brief Structure describing the IPC Message Header.
*/
typedef struct
{
   uchar8 ucFrom;  	/*!< ID of the module sending the message  */
   uchar8 ucTo; 	/*!< ID of the module to which the message is addressed */
   /* ucTo may be just used for strict validation, since
      the message destined for a module will be in the 
      module's FIFO anyway
    */
   uint16 unMsgSize; 	/*!< Size of the Message */
   uint32 uiReserved; 	/*!< Reserved for future use */

} x_IFX_IPC_MsgHdr;

/*! \def IFX_IPC_HDR_SIZE
    \brief Macro that defines the IPC Header Size.
*/
#define IFX_IPC_HDR_SIZE sizeof(x_IFX_IPC_MsgHdr) 


/*! \def IFX_IPC_MAX_MSG_SIZE
    \brief Macro that defines the Maximum IPC message Size.
*/
#define IFX_IPC_MAX_MSG_SIZE (4192 - IFX_IPC_HDR_SIZE)

/*!
    \brief Structure describing the IPC Message.
*/
typedef struct
{
   x_IFX_IPC_MsgHdr xHdr; 	/*!< Buffer to contain the message */
   char8 acMsg[IFX_IPC_MAX_MSG_SIZE]; /*!< Each module is expected to write a union in the acMsg part  */
 
} x_IFX_IPC_Msg;


/* Error Codes */

/*! \enum e_IFX_IPC_Error
    \brief This enumeration is used for IPC error codes.
*/
typedef enum
{
   IFX_IPC_NO_ERR = 0, /*!< TBD  */
   IFX_IPC_FIFO_READ_ERR = 1, /*!< TBD  */
   IFX_IPC_HDR_ERR, /*!< TBD  */
   IFX_IPC_FIFO_WRITE_ERR, /*!< TBD  */
   IFX_IPC_MSG_ERR /*!< TBD  */
} e_IFX_IPC_Error;

/* PUBLIC Functions */


/*!       
   \brief extern integer type function 
   \param[in] iFd FIFO fd
   \param[in] ucFrom Module Id of the addressee
   \param[in] ucTo Module Id of the addressed
   \param[in] unMsgSize Size of message
   \param[in] uiReserved
   \param[in] pcMsg Pointer to message
   \return IFX_IPC_SUCCESS/IFX_IPC_FAIL
*/

EXTERN char8
IFX_IPC_SendMsg(IN int32 iFd,             /* FIFO fd */
                IN uchar8 ucFrom,         /* Module Id of the addressee */
                IN uchar8 ucTo,           /* Module Id of the addressed */
                /* ucFrom and ucTo take one of e_IFX_IPC_AppId values */
                IN uint16 unMsgSize,      /* Size of message */
                IN uint32 uiReserved,
                IN char8 * pcMsg);        /* Pointer to message */





/*!
   \brief Function to receive IPC Receive Message. 
   \param[in] iFd TBD
   \param[out] pucFrom TBD
   \param[out] pucTo TBD
   \param[out] punMsgSize TBD
   \param[out] puiReserved TBD
   \param[out] pcMsg TBD
   \param[out] pErr TBD
   \return IFX_IPC_SUCCESS/IFX_IPC_FAIL
*/

EXTERN char8
IFX_IPC_RecvMsg(IN int32 iFd,
                OUT uchar8 * pucFrom,
                OUT uchar8 * pucTo,
                OUT uint16 * punMsgSize,
                OUT uint32 * puiReserved,
                OUT char8 * pcMsg,
                OUT char8 * pErr);


#endif  /* __IFX_IPC_H__ */

