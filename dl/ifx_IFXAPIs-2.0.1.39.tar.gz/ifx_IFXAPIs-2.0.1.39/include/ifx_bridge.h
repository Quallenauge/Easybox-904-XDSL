/* ============================================================================
 * Copyright (C) 2004 - Infineon Technologies.
 *
 * All rights reserved.
 * ============================================================================
 *
 * ============================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ============================================================================
 *
 * Revision History:
 *      - 2004/07/13, MarsLin
 *         init version
 *
 * ============================================================================
 */

/*! \file ifx_bridge.h
    \brief This file contains function prototypes of time configuration using ntpclient.
*/

#ifndef _IFX_BRIDGE_H_
#define _IFX_BRIDGE_H_


/*! \brief  This function is used for enabling of time sync on the device with time server.
        \param[in] *pServerName Name of NTP server
	\param[in] iTimeMinuteOffset Time offset w.r.t. GMT
        \return IFX_SUCCESS/IFX_FAILURE
*/   
int ifx_bridge_enable(char *pServerName, int iTimeMinuteOffset);



/*! \brief  This function is used for disabling of time sync on the device with time server.
       \return IFX_SUCCESS / IFX_FAILURE
*/   
int ifx_bridge_disable();

#endif /* _IFX_NTPCLIENT_H_ */

