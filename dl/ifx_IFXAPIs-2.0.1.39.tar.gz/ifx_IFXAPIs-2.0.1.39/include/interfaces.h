#ifndef __be16
#define __be16 short int
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/param.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/socketvar.h>
#include <sys/time.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <net/if.h>
#include <net/route.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <sys/queue.h>
#include <netinet/if_ether.h>
#include <sys/sysctl.h>

/** \ingroup MAPI
       \defgroup INTERFACES Interfaces
       \brief TBD.
*/
/* @{ */


/*! \def MINLOADFREQ 
    \brief Minimum reload frequency in seconds
 */
#define MINLOADFREQ 0                     /* min reload frequency in seconds */

static unsigned long LastLoad = 0;        /* ET in secs at last table load */
static struct ifnet *ifnetaddr_list;
static struct ifnet *ifnetaddr, *saveifnet, *saveifnetaddr;
static char     saveName[16];


/*!
    \brief This structure contains interface configuration details
*/
typedef struct _conf_if_list {
    char           *name;
    int             type;
    u_long          speed;
    struct _conf_if_list *next;
} conf_if_list;

static conf_if_list *conf_list;

struct in_ifaddr;
struct ifnet;

/*!
    \brief TODO
*/
struct in_ifaddr {
         int             dummy;
     };



/*! 
    \brief This function gets count of interface
    \return interface count
 */
int             Interface_Scan_Get_Count(void);

/*! 
    \brief This function indexes by name
    \param[in]
    \return 
 */
int             Interface_Index_By_Name(char *, int);

/*! 
    \brief This function inits the interface scan
 */
void            Interface_Scan_Init(void);

/*! 
    \brief This function scans the next interface.
    \param[in] Index
    \param[in] Name
    \param[in] Retifnet
    \param[in] dummy
    \return 0
 */
int  Interface_Scan_Next(short * Index, char * Name, struct ifnet * Retifnet,  struct in_ifaddr * dummy);

/*! \fn void init_interfaces(void)
    \brief This function inits interfaces
 */
void init_interfaces(void);

/*! \fn void GetIfIndex(char *,short *)
    \brief  This function gets interface index
    \param[in] *Name 
    \param[in] *index
    \return 
 */
void GetIfIndex(char *,short *);

/*! \fn int Interface_Scan_Get_IfNumber(void)
    \brief This function gets interface number.
    \return 
 */
int  Interface_Scan_Get_IfNumber(void);






/*! 
    \brief Interface number
 */
#define IFNUMBER        0

/*! 
    \brief Interface index
 */
#define IFINDEX         1

/*! 
    \brief TODO
 */
#define IFDESCR         2

/*! 
    \brief Interface Type
 */
#define IFTYPE          3

/*!  
    \brief Interface MTU 
 */
#define IFMTU           4

/*! \def IFSPEED  
    \brief Interface speed
 */
#define IFSPEED         5

/*! \def IFPHYSADDRESS 
    \brief Interface physcial address
 */
#define IFPHYSADDRESS   6

/*! \def IFADMINSTATUS
    \brief Interface admin status
 */
#define IFADMINSTATUS   7

/*! \def  IFOPERSTATUS
    \brief Interface operation status 
 */
#define IFOPERSTATUS    8

/*! \def  IFLASTCHANGE
    \brief Interface last change
 */
#define IFLASTCHANGE    9

/*! \def  IFINOCTETS
    \brief TODO
 */
#define IFINOCTETS      10

/*! \def IFINUCASTPKTS 
    \brief TODO
 */
#define IFINUCASTPKTS   11

/*! \def IFINNUCASTPKTS 
    \brief TODO
 */
#define IFINNUCASTPKTS  12

/*! \def  IFINDISCARDS
    \brief Interface in Discards
 */
#define IFINDISCARDS    13

/*! \def  IFINERRORS
    \brief Interface in errors
 */
#define IFINERRORS      14

/*! \def  IFINUNKNOWNPROTOS
    \brief TODO
 */
#define IFINUNKNOWNPROTOS 15

/*! \def  IFOUTOCTETS
    \brief TODO
 */
#define IFOUTOCTETS     16

/*! \def  IFOUTUCASTPKTS
    \brief TODO
 */
#define IFOUTUCASTPKTS  17

/*! \def  IFOUTNUCASTPKTS
    \brief TODO
 */
#define IFOUTNUCASTPKTS 18

/*! \def IFOUTDISCARDS 
    \brief Interface out discards
 */
#define IFOUTDISCARDS   19

/*! \def  IFOUTERRORS
    \brief Interface out errors
 */
#define IFOUTERRORS     20

/*! \def  IFOUTQLEN
    \brief Interface out queue length
 */
#define IFOUTQLEN       21

/*! \def  IFSPECIFIC
    \brief Interface specific
 */
#define IFSPECIFIC      22



/*
 * this struct ifnet is cloned from the generic type and somewhat modified.
 * it will not work for other un*x'es...
 */
/*!
    \brief Structure describing information common to all interfaces. It is cloned from the generic type and customised.
*/
     struct ifnet {
         char           *if_name;       /*!< name, e.g. ``en'' or ``lo'' */
         char           *if_unit;       /*!< sub-unit for lower level driver */
         short           if_mtu;        /*!< maximum transmission unit */
         short           if_flags;      /*!< up/down, broadcast, etc. */
         int             if_metric;     /*!< routing metric (external only) */
         char            if_hwaddr[6];  /*!< ethernet address */
         int             if_type;       /*!< interface type: 1=generic,
                                         * 28=slip, ether=6, loopback=24 */
         u_long          if_speed;      /*!< interface speed: in bits/sec */

         struct sockaddr if_addr;       /*!< interface's address */
         struct sockaddr ifu_broadaddr; /*!< broadcast address */
         struct sockaddr ia_subnetmask; /*!< interface's mask */

         struct ifqueue {
             int             ifq_len;
             int             ifq_drops;
         } if_snd;              /*!< output queue */
         u_long          if_ibytes;     /*!< octets received on interface */
         u_long          if_ipackets;   /*!< packets received on interface */
         u_long          if_ierrors;    /*!< input errors on interface */
         u_long          if_iqdrops;    /*!< input queue overruns */
         u_long          if_obytes;     /*!< octets sent on interface */
         u_long          if_opackets;   /*!< packets sent on interface */
         u_long          if_oerrors;    /*!< output errors on interface */
         u_long          if_collisions; /*!< collisions on csma interfaces */
         /*
          * end statistics
          */
         struct ifnet   *if_next;
     };

/*! 
    \brief  This function gets interface.
    \param[in] Index Interface Index 
    \param[in] Name Interface Name
    \return Pointer to Interface Structure
 */	 
struct ifnet *Get_Ifnet (short Index, char *Name);
/* @} */
