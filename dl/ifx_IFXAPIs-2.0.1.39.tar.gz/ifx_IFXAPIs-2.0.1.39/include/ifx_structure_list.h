/* ============================================================================
 * Copyright (C) 2004 - Infineon Technologies.
 *
 * All rights reserved.
 * ============================================================================
 *
 * ============================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ============================================================================
 *
 * Revision History:
 *      - 2004/07/13, MarsLin
 *         init version
 *      - 2004/07/16, MarsLin
 *         add list extension to add some useful variable.
 *         it'll speed up list process but cost additional 8 bytes per list/node
 *
 * ============================================================================
 */


/*! \file ifx_structure_list.h
    \brief This function contains the structure list API macros, structures and function prototypes
*/


#ifndef _IFX_STRUCTURE_LIST_H_
#define _IFX_STRUCTURE_LIST_H_



/*!
    \brief Structure describing the Single list.
*/
typedef struct _IFX_SINGLE_LIST
{
    struct _IFX_SINGLE_LIST     *prev;     /*!< pointing previous node */
    struct _IFX_SINGLE_LIST     *next;     /*!< pointing next node */
    struct _IFX_SINGLE_LIST     *parent;   /*!< parent node */     /* if this is list node, it'll record it's list head */
    int                         num_child; /*!< number of child nodes */     /* if this is list head, it'll record total list node it has */
} IFX_SINGLE_LIST, *P_IFX_SINGLE_LIST;


/*! \def IFX_SINGLE_LIST_INIT
    \brief Single list init 
 */
#define IFX_SINGLE_LIST_INIT(list)                                             \
{                                                                              \
    (list)->prev        = NULL;                                                \
    (list)->next        = NULL;                                                \
    (list)->parent      = NULL;                                                \
    (list)->num_child  = 0;                                                    \
}


/*! \def __IFX_SINGLE_LIST_ADD_FIRST
    \brief Single list add at first 
 */
#define __IFX_SINGLE_LIST_ADD_FIRST(list, node)                                \
{                                                                              \
    (node)->prev        = NULL;                                                \
    (node)->next        = NULL;                                                \
    (list)->prev        = node;                                                \
    (list)->next        = node;                                                \
    (node)->parent      = list;                                                \
    (list)->num_child  += 1;                                                   \
}


/*! \def __IFX_SINGLE_LIST_ADD_BACK
    \brief Single list add at the back 
 */
#define __IFX_SINGLE_LIST_ADD_BACK(list, node)                                 \
{                                                                              \
    (node)->prev        = (list)->prev;                                        \
    (node)->next        = NULL;                                                \
    (list)->prev->next  = (node);                                              \
    (list)->prev        = (node);                                              \
    (node)->parent      = list;                                                \
    (list)->num_child  += 1;                                                   \
}


/*! \def __IFX_SINGLE_LIST_ADD_FRONT
    \brief Single list add at the front
 */
#define __IFX_SINGLE_LIST_ADD_FRONT(list, node)                                \
{                                                                              \
    (node)->prev        = NULL;                                                \
    (node)->next        = (list)->next;                                        \
    (list)->next->prev  = (node);                                              \
    (list)->next        = (node);                                              \
    (node)->parent      = list;                                                \
    (list)->num_child  += 1;                                                   \
}




/*! \fn inline int IFX_SINGLE_LIST_ADD_BACK(P_IFX_SINGLE_LIST list,P_IFX_SINGLE_LIST node)
    \brief This inline function add a node at the back of the single list
    \param[in] list
    \param[in] node
    \return 0 or -1
 */
static inline int IFX_SINGLE_LIST_ADD_BACK
    (
        P_IFX_SINGLE_LIST list,
        P_IFX_SINGLE_LIST node
    )
{
	if (node->parent != NULL) {
		return -1;
	}
	else {
		if (list->prev != NULL) {
			__IFX_SINGLE_LIST_ADD_BACK(list, node);
		}
		else {
			__IFX_SINGLE_LIST_ADD_FIRST(list, node);
		}
		return 0;
	}
}



/*! \fn inline int IFX_SINGLE_LIST_ADD_FRONT (P_IFX_SINGLE_LIST list, P_IFX_SINGLE_LIST node )
    \brief This inline function add a node at the front of the single list
    \param[in] list
    \param[in] node
    \return 0 or -1
 */
static inline int IFX_SINGLE_LIST_ADD_FRONT
    (
        P_IFX_SINGLE_LIST list,
        P_IFX_SINGLE_LIST node
    )
{
	if (node->parent != NULL) {
		return -1;
	}
	else {
		if (list->next != NULL) {
			__IFX_SINGLE_LIST_ADD_FRONT(list, node);
		}
		else {
			__IFX_SINGLE_LIST_ADD_FIRST(list, node);
		}
		return 0;
	}
}


/*! \def __IFX_SINGLE_LIST_ADD_AFTER
    \brief Single list add after 
 */
#define __IFX_SINGLE_LIST_ADD_AFTER(list, node1, node2)                        \
{                                                                              \
    (node2)->next       = (node1)->next;                                       \
    (node2)->prev       = (node1);                                             \
    (node1)->next       = (node2);                                             \
    (node2)->parent     = list;                                                \
    (list)->num_child  += 1;                                                   \
}



/*! \def __IFX_SINGLE_LIST_ADD_BEFORE
    \brief Single list add before
 */
#define __IFX_SINGLE_LIST_ADD_BEFORE(list, node1, node2)                       \
{                                                                              \
    (node2)->prev = (node1)->prev;                                             \
    (node2)->next = (node1);                                                   \
    (node1)->prev = (node2);                                                   \
    (node2)->parent     = list;                                                \
    (list)->num_child  += 1;                                                   \
}



/*! \fn inline int IFX_SINGLE_LIST_ADD_AFTER ( P_IFX_SINGLE_LIST list,
                                               P_IFX_SINGLE_LIST node1,
                                               P_IFX_SINGLE_LIST node2 )
    \brief This inline function add a node after a specified node in the single list
    \param[in] list
    \param[in] node1
    \param[in] node2
    \return 0 or -1
 */
static inline int IFX_SINGLE_LIST_ADD_AFTER
    (
        P_IFX_SINGLE_LIST list,
        P_IFX_SINGLE_LIST node1,
        P_IFX_SINGLE_LIST node2
    )
{
	if ((node1->parent != list) || (node2->parent != NULL)) {
		return -1;
	}
	else {
		if (node1->parent != list)
			return -1;
		if (node1 == list->prev)
			IFX_SINGLE_LIST_ADD_BACK(list, node2);
		else
			__IFX_SINGLE_LIST_ADD_AFTER(list, node1, node2);
		return 0;
	}
}





/*! \fn inline int IFX_SINGLE_LIST_ADD_BEFORE ( P_IFX_SINGLE_LIST list,
                                               P_IFX_SINGLE_LIST node1,
                                               P_IFX_SINGLE_LIST node2 )
    \brief This inline function add a node before a specified node in the single list
    \param[in] list
    \param[in] node1
    \param[in] node2
    \return 0 or -1
 */

static inline int IFX_SINGLE_LIST_ADD_BEFORE
    (
        P_IFX_SINGLE_LIST list,
        P_IFX_SINGLE_LIST node1,
        P_IFX_SINGLE_LIST node2
    )
{
	if ((node1->parent != list) || (node2->parent != NULL)) {
		return -1;
	}
	else {
		if (node1->parent != list)
			return -1;
		if (node1 == list->next)
			IFX_SINGLE_LIST_ADD_FRONT(list, node2);
		else
			__IFX_SINGLE_LIST_ADD_BEFORE(list, node1, node2);
		return 0;
	}
}




/*! \fn static inline P_IFX_SINGLE_LIST IFX_SINGLE_LIST_REMOVE_FRONT (P_IFX_SINGLE_LIST list)  
    \brief This inline function deletes a node from the front of the single list
    \param[in] list
    \return node
 */
static inline P_IFX_SINGLE_LIST IFX_SINGLE_LIST_REMOVE_FRONT
    (
        P_IFX_SINGLE_LIST   list
    )
{
    P_IFX_SINGLE_LIST   node = list->next;
    if (node != NULL) {
        list->next = node->next;
        if (node->next != NULL)
            node->next->prev = node->prev;
        else
            list->prev = NULL;  /* single node */
        IFX_SINGLE_LIST_INIT(node);
        list->num_child -= 1;
    }
    return node;
}





/*! \fn inline P_IFX_SINGLE_LIST IFX_SINGLE_LIST_REMOVE_BACK ( P_IFX_SINGLE_LIST   list)
    \brief This inline function deletes a node from the back of the single list
    \param[in] list
    \return node
 */
static inline P_IFX_SINGLE_LIST IFX_SINGLE_LIST_REMOVE_BACK
    (
        P_IFX_SINGLE_LIST   list
    )
{
    P_IFX_SINGLE_LIST   node = list->prev;
    if (node != NULL) {
        list->prev = node->prev;
        if (node->prev != NULL)
            node->prev->next = node->next;
        else
            list->next = NULL;  /* single node */
        IFX_SINGLE_LIST_INIT(node);
        list->num_child -= 1;
    }
    return node;
}

/*! \def __IFX_SINGLE_LIST_REMOVE_NODE
    \brief Single list remove node
 */
#define __IFX_SINGLE_LIST_REMOVE_NODE(list, node)                              \
{                                                                              \
    if ((node) == (list)->next)                                                \
        IFX_SINGLE_LIST_REMOVE_FRONT(list);                                    \
    else if ((node) == (list)->prev)                                           \
        IFX_SINGLE_LIST_REMOVE_BACK(list);                                     \
    else                                                                       \
    {                                                                          \
        (node)->prev->next = (node)->next;                                     \
        (node)->next->prev = (node)->prev;                                     \
        IFX_SINGLE_LIST_INIT(node);                                            \
        list->num_child -= 1;                                                  \
    }                                                                          \
}



/*! \fn int IFX_SINGLE_LIST_REMOVE_NODE (P_IFX_SINGLE_LIST   list, P_IFX_SINGLE_LIST   node)
    \brief This inline function removes a node from a single list
    \param[in] list
    \param[in] node
    \return 0 or -1
 */
static inline int IFX_SINGLE_LIST_REMOVE_NODE
    (
        P_IFX_SINGLE_LIST   list,
        P_IFX_SINGLE_LIST   node
    )
{
    if (node->parent != list)
        return -1;
    __IFX_SINGLE_LIST_REMOVE_NODE(list, node);
    return 0;
}

/*
 * NOTE:
 *      When using following macro, you "MUST NOT" change any content or info
 *      in list/node.
 */

/*! \def IFX_SINGLE_LIST_GET_FIRST
    \brief Single list get first
 */
#define IFX_SINGLE_LIST_GET_FIRST(list)     ((list)->next)


/*! \def IFX_SINGLE_LIST_GET_LAST
    \brief Single list get last
 */
#define IFX_SINGLE_LIST_GET_LAST(list)      ((list)->prev)

#endif  /* _IFX_STRUCTURE_LIST_H_ */

