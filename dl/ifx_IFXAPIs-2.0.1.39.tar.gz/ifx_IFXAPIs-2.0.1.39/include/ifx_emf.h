
/*! \file ifx_emf.h
    \brief This file defines the string operation related macros used by httpd component.
*/

#ifndef IFX_EMF_H
#define IFX_EMF_H

#include	<sys/types.h>
#include	<sys/stat.h>
#include	<sys/param.h>
#include	<limits.h>
#include	<stdio.h>
#include	<stdlib.h>
#include	<unistd.h>
#include	<sys/socket.h>
#include	<sys/select.h>
#include	<netinet/in.h>
#include 	<arpa/inet.h>
#include 	<netdb.h>
#include	<time.h>
#include	<fcntl.h>
#include	<errno.h>

#include	<ctype.h>
#include	<stdarg.h>
#include	<string.h>

#define	T(s) 				s
typedef char				char_t;
typedef unsigned short		bool_t;

#ifndef O_BINARY
/*! \def O_BINARY
    \brief Macro that defines binary.
*/
#define O_BINARY 		0
#endif 

/* Ensure TRUE & FALSE are defined */
#ifndef TRUE
/*! \def TRUE
    \brief Macro that defines True.
*/
#define TRUE 1
#endif

#ifndef FALSE
/*! \def FALSE
    \brief Macro that defines False.
*/
#define FALSE 0
#endif

/*! \def gsprintf
    \brief Macro that defines sprintf
*/
#define gsprintf	sprintf

/*! \def gsscanf
    \brief Macro that defines sscanf
*/
#define gsscanf		sscanf


/*! \def gstrcpy
    \brief Macro that defines strcpy
*/
#define gstrcpy		strcpy

/*! \def gstrncpy
    \brief Macro that defines strncpy
*/
#define gstrncpy	strncpy

/*! \def gstrncat
    \brief Macro that defines strncat
*/
#define gstrncat	strncat

/*! \def gstrlen
    \brief Macro that defines strlen
*/
#define gstrlen		strlen

/*! \def gstrcat
    \brief Macro that defines strcat
*/
#define gstrcat		strcat


/*! \def gstrcmp
    \brief Macro that defines strcmp
*/
#define gstrcmp		strcmp

/*! \def gstrncmp
    \brief Macro that defines strncmp
*/
#define gstrncmp	strncmp

/*! \def gstrchr
    \brief Macro that defines strchr
*/
#define gstrchr		strchr


/*! \def gstrrchr
    \brief Macro that defines strrchr
*/
#define gstrrchr	strrchr

/*! \def gstrtok
    \brief Macro that defines strtok
*/
#define gstrtok		strtok

/*! \def gstrstr
    \brief Macro that defines strstr
*/
#define gstrstr		strstr

/*! \def gstrtol
    \brief Macro that defines strtol
*/
#define gstrtol		strtol

/*! \def gfopen
    \brief Macro that defines fopen
*/
#define gfopen		fopen

/*! \def gfclose
    \brief Macro that defines fclose
*/
#define gfclose		fclose

/*! \def gisspace
    \brief Macro that defines isspace
*/
#define gisspace	isspace

/*! \def gatoi
    \brief Macro that defines atoi
*/
#define gatoi		atoi


/********************* Defines ***********************************/

/*
 * Assert macro 
 */

/*! \def error
    \brief Macro that defines error prints
*/
#define error(file, line, errstr)	\
	printf("(%s:%d) %s\n" (file), (line), (errstr))

#if (defined (ASSERT))
	/*! \def a_assert
            \brief defines Assert macro
        */
        #define a_assert(C)		if (C) ; else error(T(__FILE__), __LINE__,  T(#C))
#else
	/*! \def a_assert
            \brief defines Assert macro
       */
        #define a_assert(C)		if (1) ; else
#endif /* ASSERT */

#endif /* ] IFX_EMF_H */
