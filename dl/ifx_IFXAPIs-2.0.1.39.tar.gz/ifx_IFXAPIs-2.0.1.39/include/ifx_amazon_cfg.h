/* 
** =============================================================================
**   FILE NAME        : ifx_amazon_cfg.h
**   PROJECT          : AMAZON 
**   DATE             : 07-Jun-2005
**   AUTHOR           : Amazon Team
**   DESCRIPTION      : This file contains the CGI constant definitions

**   REFERENCES       : 
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/

/*! \file ifx_amazon_cfg.h 
    \brief This file contains the CGI constant definitions
*/



/*
000001:tc.chen 2005/06/07 add IP QoS and 802.1P priority queue
507082:linmars VLAN cfg added
508181:tc.chen 2005/08/18 add routing support for sip
509023:linmars 2005/09/02 add PIF for physical port interface
511091:leejack 2005/11/09 Change service starting method from script to binary code.
601111:leejack 2006/01/11 add Bringup_dns_relay
6090401:hsur add ipsec support
604041:sumedh 2006/04/04 Parental Control feature added (modified MAC Filter)
604042:sumedh 2006/04/04 VLAN Membership
*/

#define DEBUG       // Mark this to hide debug message in stdout

#ifndef MAX_DATA_LEN
/*!\def MAX_DATA_LEN
   \brief Maximum Data Length 
*/
#define MAX_DATA_LEN 2000
#endif
#ifndef MAX_FILELINE_LEN

/*!\def MAX_FILELINE_LEN
   \brief Maximum file length
*/
#define MAX_FILELINE_LEN 324
#endif
#ifndef MAX_SMALLFILELINE_LEN
/*!\def MAX_SMALLFILELINE_LEN
   \brief Maximum small file line length 
*/
#define MAX_SMALLFILELINE_LEN	100
#endif

/*!\def MAX_WEB_DATA
   \brief Maximum web Data
*/
#define MAX_WEB_DATA 30

/*!\def HARDWARE_VER
   \brief Hardware version
*/
#define HARDWARE_VER                    "1.00.00"

/*!\def MAX_VCCs
   \brief Maximuim VCCs
*/
#define MAX_VCCs						20

/*!\def ADSL_FIRMWARE_VERSION_FILE
   \brief Location of ADSL firmware version File
*/
#define ADSL_FIRMWARE_VERSION_FILE      "/tmp/adsl_fw_date"


//#define FIRMWARE_VERSION_FILE           "/etc/version"

/*!\def PREFIX_ROUTING
   \brief Prefix route
*/
#define PREFIX_ROUTING					"route"

/*!\def PREFIX_STATICROUTE
   \brief  Prefix static route
*/
#define PREFIX_STATICROUTE              "staticRoute"

/*!\def PREFIX_ALIASIP
   \brief Prefix Alias IP
*/
#define PREFIX_ALIASIP                  "aliasIP"

/*!\def PREFIX_FIREWALLMAC
   \brief Prefix firewall MAC
*/
#define PREFIX_FIREWALLMAC              "MAC_DENY_"

/*!\def PREFIX_IPSEC_TUNNEL_INFO
   \brief prefix ipsec tunnel info
*/
#define PREFIX_IPSEC_TUNNEL_INFO	"ipsec_tunnel"

/*!\def PREFIX_FIREWALL_PC
   \brief Prefix firewall Parental Control
*/
#define PREFIX_FIREWALL_PC	   		    "PC_" //604041:sumedh - Parental Control

/*!\def PREFIX_FIREWALL_PACKETFILTER
   \brief Prefix Firewall Packetfilter
*/
#define PREFIX_FIREWALL_PACKETFILTER    "PF_"

/*!\def PREFIX_POLICY_ROUTING
   \brief Prefix policy routing 
*/
#define PREFIX_POLICY_ROUTING		    "PR"

/*!\def PREFIX_SIP
   \brief Prefix SIP
*/
#define PREFIX_SIP					    "SIP_"

/*!\def PREFIX_SNMPv3_USER
   \brief Prefix SNMPv3 user
*/
#define PREFIX_SNMPv3_USER				"SNMPv3User_"

/*!\def PREFIX_PASSWORD_FILE
   \brief Prefix password file
*/
#define PREFIX_PASSWORD_FILE			"password_file"

/*!\def PREFIX_QOS_PRIORITY
   \brief QOS priority setting Prefix 
*/
#define PREFIX_QOS_PRIORITY    			"QP_" //000001:tc.chen qos priority setting prefix

/*!\def PREFIX_ADSL_VCCHANNEL
   \brief Prefix ADSL VCChannel
*/
#define PREFIX_ADSL_VCCHANNEL			"VCChannel"

/*!\def PREFIX_WAN_CONN_DEV
   \brief Prefix WAN connection device
*/
#define PREFIX_WAN_CONN_DEV				"wan_dev"

/*!\def PREFIX_NAT_VIRTUALSER
   \brief NAT virtualser Prefix 
*/
#define PREFIX_NAT_VIRTUALSER			"natvs"

/*!\def PREFIX_WAN_MAIN
   \brief WAN main Prefix 
*/
#define PREFIX_WAN_MAIN					"wan"

/*!\def PREFIX_WAN_IP
   \brief WAN IP Prefix 
*/
#define PREFIX_WAN_IP					"wanip"

/*!\def PREFIX_WAN_PPP
   \brief WAN PPP Prefix 
*/
#define PREFIX_WAN_PPP					"wanppp"
// #define PREFIX_WAN_ATMF5			"wan_atmf5"

/*!\def PREFIX_WAN_ATMF5
   \brief Prefix WAN ADSL OAM f5
*/
#define PREFIX_WAN_ATMF5				"adsl_oam_f5"

/*!\def PREFIX_NAT_VS
   \brief NAT virtualser prefix
*/
#define PREFIX_NAT_VS					"nat_virtualser"

/*!\def PREFIX_DSL_DIAG
   \brief DSL diagnostic Prefix 
*/
#define PREFIX_DSL_DIAG					"dsl_diag"

/*!\def PREFIX_WLAN_PHY
   \brief WLAN phy Prefix 
*/
#define PREFIX_WLAN_PHY                "wlphy"

/*!\def PREFIX_WLAN_MAIN
   \brief WLAN main Prefix 
*/
#define PREFIX_WLAN_MAIN               "wlmn"

/*!\def PREFIX_WLAN_SEC
   \brief WLAN secondary Prefix 
*/
#define PREFIX_WLAN_SEC                "wlsec"	

/*!\def PREFIX_WLAN_SEC_1X
   \brief WLAN security Prefix 1X
*/
#define PREFIX_WLAN_SEC_1X             "wl1x"	

/*!\def PREFIX_WLAN_WEP
   \brief WLAN WEP Prefix
*/
#define PREFIX_WLAN_WEP                "wlwep"

/*!\def PREFIX_WLAN_PASSPHRASE
   \brief WLAN passphrase Prefix
*/
#define PREFIX_WLAN_PASSPHRASE         "wlpsk"

/*!\def PREFIX_WLAN_WPS
   \brief WLAN WPS Prefix
*/
#define PREFIX_WLAN_WPS                "wlwps"

/*!\def PREFIX_WLAN_WPS_REGS
   \brief WALN wps register Prefix
*/
#define PREFIX_WLAN_WPS_REGS           "wlwpsregs"

/*!\def PREFIX_WLAN_WMM_AP
   \brief WLAN WMM Access Point Prefix
*/
#define PREFIX_WLAN_WMM_AP             "wlawmm"

/*!\def PREFIX_WLAN_WMM_STA
   \brief WLAN WMM Station Prefix
*/
#define PREFIX_WLAN_WMM_STA            "wlswmm"

/*!\def PREFIX_WLAN_MAC_CONTROL
   \brief WLAN MAC control Prefix
*/
#define PREFIX_WLAN_MAC_CONTROL        "wlmacctrl"

/*!\def PREFIX_WLAN_GLOBAL_MAC_CONTROL
   \brief WLAN global MAC control Prefix
*/
#define PREFIX_WLAN_GLOBAL_MAC_CONTROL "gmaccntrl"

/*!\def PREFIX_LAN_DHCP_COND_INFO
   \brief LAN DHCP Info Prefix
*/

/*!\def PREFIX_WLAN_GEN_VB
   \brief WLAN VB Prefix
*/
#define PREFIX_WLAN_GEN_VB             "gbc"

/*!\def PREFIX_WLAN_VB_LAN
   \brief WLAN VB LAN Prefix
*/
#define PREFIX_WLAN_VB_LAN             "lbc"

/*!\def PREFIX_VB_ETH_PHY
   \brief VB ETH PHY Port Prefix
*/
#define PREFIX_VB_ETH_PHY           	"ephy"

/*!\def PREFIX_VB_WLAN
   \brief WLAN VB Prefix
*/
#define PREFIX_VB_WLAN_CFG             "wlstacfg"

/*!\def PREFIX_VB_WMM_STA_CFG
   \brief WLAN VB WMM Prefix
*/
#define PREFIX_VB_WMM_STA_CFG          "wlsstawmm"

/*!\def PREFIX_VB_WLAN_PROFILE
   \brief WLAN VB Prefix
*/
#define PREFIX_VB_WLAN_PROFILE         "wlprof"

#define PREFIX_LAN_DHCP_COND_INFO      "ldc"

/*!\def PREFIX_LAN_MAIN
   \brief Main LAN Prefix
*/
#define PREFIX_LAN_MAIN                "lan_main"

/*!\def PREFIX_LAN_DHCP_SERVER
   \brief LAN DHCP server Prefix
*/
#define PREFIX_LAN_DHCP_SERVER         "lan_dhcps"

#define PREFIX_ETH_CHANNEL	       "EthChannel"
#define PREFIX_PTM_CHANNEL         "PtmChannel"

#define PREFIX_WAN_PHY_CFG         "wanphy"
#define TAG_WAN_PHY_CFG         "wan_phy_cfg"

#define TAG_XDSL_CONFIG         "xDSL_Config"

/*!\def PROTOCOL_TYPE_TCP
   \brief Protocal type TCP
*/
#define PROTOCOL_TYPE_TCP               "TCP"

/*!\def PROTOCOL_TYPE_UDP
   \brief Protocal type UDP
*/
#define PROTOCOL_TYPE_UDP               "UDP"

/*!\def IPTABLE_PREROUTING
   \brief IPtable prerouting
*/
#define IPTABLE_PREROUTING              "iptables -t nat -A PREROUTING"

/*!\def IPTABLE_POSTROUTING
   \brief IPtable Postrouting
*/
#define IPTABLE_POSTROUTING             "iptables -t nat -A POSTROUTING"


/*!\def NAT_TRIGGER_LINK_NUM
   \brief NAT trigger link number
*/
#define NAT_TRIGGER_LINK_NUM            10

/*!\def NAT_RD_LINK_NUM
   \brief NAT RD Link Number
*/
#define NAT_RD_LINK_NUM                 5

/*!\def NAT_VS_LINK_NUM
   \brief NAT VS Link Number
*/
#define NAT_VS_LINK_NUM                 5

/*!\def NAT_VS_CLONE_NUM
   \brief NAT VS clone number
*/
#define NAT_VS_CLONE_NUM                16

/*!\def NAT_MASQ_NUM
   \brief Nat Masquerade Number
*/
#define NAT_MASQ_NUM                    5

/*!\def FIREW_PFILTER_NUM
   \brief Firewall packet filter number
*/
#define FIREW_PFILTER_NUM               16

/*!\def PLCY_ROUTING_NUM
   \brief Policy based Routing number
*/
#define PLCY_ROUTING_NUM 	            16 //sumedh (Policy based Routing)

/*!\def SIP_TABLE_NUM
   \brief SIP Table number 
*/
#define SIP_TABLE_NUM 	            	16 //sumedh (SIP)

/*!\def SNMPv3_USERS_NUM
   \brief SNMPv3 users number
*/
#define SNMPv3_USERS_NUM		24 // Subbi (SNMPv3)

/*!\def URL_FILTER_STR_LEN
   \brief URL filter string length 
*/
#define URL_FILTER_STR_LEN              50

/*!\def FIREW_URL_FILTER_NUM
   \brief Firewall URL filter number
*/
#define FIREW_URL_FILTER_NUM            10

/*!\def IP_CFG_MAX_ALIAS_NUM
   \brief IP config maximum alias number 
*/
#define IP_CFG_MAX_ALIAS_NUM            10

/*!\def MAX_WEB_IDELTIME
   \brief Maximum WEB idle time
*/
#define MAX_WEB_IDELTIME                300

/*!\def IP_BOOT_DHCPC
   \brief IP boot DHCPC
*/
#define IP_BOOT_DHCPC                   1

/*!\def IP_BOOT_FIXED
   \brief IP boot fixed
*/
#define IP_BOOT_FIXED                   2

/*!\def IP_BOOT_PPPOE
   \brief IP boot PPPOE
*/
#define IP_BOOT_PPPOE                   3

/*!\def IP_BOOT_PPPOA
   \brief IP boot PPPOA
*/
#define IP_BOOT_PPPOA                   4

/*!\def IP_BOOT_BRIDGE
   \brief IP boot bridge
*/
#define IP_BOOT_BRIDGE                  5

/*!\def IP_BOOT_TR037
   \brief IP boot TR037
*/
#define IP_BOOT_TR037                   6
#define IP_BOOT_ETH			                7
#define IP_BOOT_PTM                     8

/*!\def IP_BOOT_UNKNOWN
   \brief IP boot unknown
*/
#define IP_BOOT_UNKNOWN                 0

/*!\def IP_CFG_MAX_ALIAS_NUM
   \brief IP config maximum alias number 
*/
#define IP_CFG_MAX_ALIAS_NUM            10

/*!\def APPS_NUM_OF_STATIC_ROUTE_ENTRY
   \brief Application number of static route entry
*/
#define APPS_NUM_OF_STATIC_ROUTE_ENTRY  10

/*!\def APPS_NUM_OF_ETHFTR_ENTRY
   \brief Application number of ETHFTR entry
*/
#define APPS_NUM_OF_ETHFTR_ENTRY        32

/*!\def APPS_PASSWORD_MIN_SIZE
   \brief Application password minimum size
*/
#define APPS_PASSWORD_MIN_SIZE          3

/*!\def APPS_PASSWORD_MAX_SIZE
   \brief Application password maximum size
*/
#define APPS_PASSWORD_MAX_SIZE          256

/*!\def APPS_SECURITYLOG_NUM
   \brief Application security log number 
*/
#define APPS_SECURITYLOG_NUM            20

/*!\def APPS_DDNS_NUM
   \brief Application DDNS number 
*/
#define APPS_DDNS_NUM                   3

/*!\def ETHFTR_CFG_ALLOW
   \brief ETHFTR CFG ALLOW Flag
*/
#define ETHFTR_CFG_ALLOW                1

/*!\def ETHFTR_CFG_DENY
   \brief ETHFTR CFG DENY Flag
*/
#define ETHFTR_CFG_DENY                 0

/*!\def QOS_PRIORITY_TABLE_NUM
   \brief Max number of qos priority table
*/
#define QOS_PRIORITY_TABLE_NUM          16 //000001:tc.chen max number of qos priority table
//#define MAX_RULES						30 //604041:sumedh

/*!\def MAX_RULES
   \brief Maximum rules
*/
#define MAX_RULES						10 //Pramod

/*!\def PREFIX_AND_TAG_LEN
   \brief Prefix and Tag length 
*/
#define PREFIX_AND_TAG_LEN 				64


/*!\def FILE_IMAGE_KERNEL
   \brief Kernel image file location 
*/
#define FILE_IMAGE_KERNEL               "/tmp/fw"

/*!\def FILE_SYSLOG
   \brief Syslog file location 
*/
#define FILE_SYSLOG                     "../web/sys.log"

/*!\def FILE_MESSAGES
   \brief Messages files location 
*/
#define FILE_MESSAGES                   "/var/log/messages"


#ifndef FILE_RC_CONF

/*!\def FILE_RC_CONF
   \brief rc.conf file location 
*/
#define FILE_RC_CONF                    "/flash/rc.conf"
#endif // FILE_RC_CONF

/*!\def FILE_RESOLV_CONF
   \brief resolv.conf file location 
*/
#define FILE_RESOLV_CONF                "/ramdisk/etc/resolv.conf"

/*!\def FILE_UDHCPD_CONF
   \brief udhcpd.conf file location 
*/
#define FILE_UDHCPD_CONF                "/ramdisk/etc/udhcpd.conf"

/*!\def FILE_RIPD_CONF
   \brief ripd.conf file location 
*/
#define FILE_RIPD_CONF                  "/ramdisk/etc/ripd.conf"

/*!\def FILE_ROUTE_TMP
   \brief route.tmp location 
*/
#define FILE_ROUTE_TMP                  "/tmp/route.tmp"

/*!\def FILE_ADSL_STATUS
   \brief adsl_status file 
*/
#define FILE_ADSL_STATUS                "/tmp/adsl_status"

/*!\def FILE_SYSTEM_STATUS
   \brief System_status file
*/
#define FILE_SYSTEM_STATUS		"/tmp/system_status"

//511091:leejack start

/*!\def SERVICE_PPPOE_STOP
   \brief PPPOE Service stop
*/
#define SERVICE_PPPOE_STOP              "/etc/rc.d/init.d/pppoe stop"

/*!\def SERVICE_PPPOE_START
   \brief PPPOE Service start
*/
#define SERVICE_PPPOE_START             "/etc/rc.d/init.d/pppoe start" // Process in front-ground

/*!\def SERVICE_PPPOE_RESTART
   \brief PPPOE Service restart
*/
#define SERVICE_PPPOE_RESTART             "/etc/rc.d/init.d/pppoe restart" // Process in front-ground

/*!\def SERVICE_PPPOA_STOP
   \brief PPPOA Service stop
*/
#define SERVICE_PPPOA_STOP              "/etc/rc.d/init.d/pppoa stop"

/*!\def SERVICE_PPPOA_START
   \brief PPPOA Service start
*/
#define SERVICE_PPPOA_START             "/etc/rc.d/init.d/pppoa start" // Process in front-ground

/*!\def SERVICE_PPPOA_RESTART
   \brief PPPOA Service restart
*/
#define SERVICE_PPPOA_RESTART             "/etc/rc.d/init.d/pppoa restart" // Process in front-ground
//#define SERVICE_PPPOE_STOP              "/usr/sbin/bringup_pppoe stop"
//#define SERVICE_PPPOE_START             "/usr/sbin/bringup_pppoe start" // Process in front-ground
//#define SERVICE_PPPOA_STOP              "/usr/sbin/bringup_pppoa stop"
//#define SERVICE_PPPOA_START             "/usr/sbin/bringup_pppoa start" // Process in front-ground
//511091:leejack end

/*!\def SERVICE_DHCPS_STOP
   \brief DHCPS Service stop
*/
#define SERVICE_DHCPS_STOP              "/etc/rc.d/init.d/udhcpd stop"

/*!\def SERVICE_DHCPS_START
   \brief DHCPS Service start
*/
#define SERVICE_DHCPS_START             "/etc/rc.d/init.d/udhcpd start"

/*!\def SERVICE_DHCPS_RESTART
   \brief  DHCPS Service restart
*/
#define SERVICE_DHCPS_RESTART           "/etc/rc.d/init.d/udhcpd restart"


/*!\def SERVICE_DHCPC_STOP
   \brief DHCPC Service stop
*/
#define SERVICE_DHCPC_STOP              "/etc/rc.d/init.d/udhcpc stop"


/*!\def SERVICE_DHCPC_START
   \brief DHCPC Service start
*/
#define SERVICE_DHCPC_START             "/etc/rc.d/init.d/udhcpc start"

/*!\def SERVICE_DHCPC_RESTART
   \brief DHCPC Service restart
*/
#define SERVICE_DHCPC_RESTART           "/etc/rc.d/init.d/udhcpc restart"

/*!\def SERVICE_NAT_RESTART
   \brief NAT Service restart
*/
#define SERVICE_NAT_RESTART             "/etc/rc.d/rc.iptables"

/*!\def SERVICE_FIREWALL_RESTART
   \brief Firewall Service restart
*/
#define SERVICE_FIREWALL_RESTART        "/etc/rc.d/rc.firewall restart"
#ifdef IFX_DOS_ENABLE

/*!\def SERVICE_FIREWALL_DOS_RESTART
   \brief Firewall DOS Service restart
*/
#define SERVICE_FIREWALL_DOS_RESTART    "/etc/rc.d/rc.firewall_dos restart"
#endif

/*!\def SERVICE_POLICY_ROUTING_RESTART
   \brief Policy routing Service restart
*/
#define SERVICE_POLICY_ROUTING_RESTART  "/etc/init.d/policy_routing restart"

/*!\def SERVICE_POLICY_ROUTING_START
   \brief Policy routing Service start
*/
#define SERVICE_POLICY_ROUTING_START  "/etc/init.d/policy_routing start"

/*!\def SERVICE_POLICY_ROUTING_STOP
   \brief Policy routing Service stop
*/
#define SERVICE_POLICY_ROUTING_STOP  "/etc/init.d/policy_routing stop"

/*!\def SERVICE_RIPD_START
   \brief RIPD Service start
*/
#define SERVICE_RIPD_START              "/etc/rc.d/init.d/ripd start"

/*!\def SERVICE_RIPD_STOP
   \brief RIPD Service stop
*/
#define SERVICE_RIPD_STOP               "/etc/rc.d/init.d/ripd stop"

/*!\def SERVICE_RIPD_RESTART
   \brief RIPD Service restart
*/
#define SERVICE_RIPD_RESTART               "/etc/rc.d/init.d/ripd restart"

/*!\def SERVICE_NTPC_RESTART
   \brief NTPC Service restart
*/
#define SERVICE_NTPC_RESTART            "/etc/rc.d/init.d/ntpc restart"

/*!\def SERVICE_UPNPD_START
   \brief UPNPD Service start
*/
#define SERVICE_UPNPD_START             "/usr/sbin/upnpd"

/*!\def SERVICE_UPNPD_STOP
   \brief UPNPD Service stop
*/
#define SERVICE_UPNPD_STOP              "killall upnpd"

/*!\def SERVICE_UPNPD_RESTART
   \brief UPNPD Service restart
*/
#define SERVICE_UPNPD_RESTART           "/etc/rc.d/init.d/upnp"

//511091:leejack start

/*!\def SERVICE_WAN_STOP
   \brief WAN Service stop
*/
#define SERVICE_WAN_STOP                "/etc/rc.d/rc.bringup_wan stop"

/*!\def SERVICE_WAN_START
   \brief WAN Service start
*/
#define SERVICE_WAN_START               "/etc/rc.d/rc.bringup_wan start "

/*!\def SERVICE_WAN_RESTART
   \brief WAN Service restart
*/
#define SERVICE_WAN_RESTART             "/etc/rc.d/rc.bringup_wan restart "
//#define SERVICE_WAN_STOP                "/usr/sbin/bringup_wan stop"
//#define SERVICE_WAN_START               "/usr/sbin/bringup_wan start "
//#define SERVICE_WAN_RESTART             "/usr/sbin/bringup_wan restart "
//511091:leejack end


/*!\def SERVICE_LAN_STOP
   \brief LAN Service stop
*/
#define SERVICE_LAN_STOP                "/etc/rc.d/rc.bringup_lan stop"

/*!\def SERVICE_LAN_START
   \brief LAN Service start
*/
#define SERVICE_LAN_START               "/etc/rc.d/rc.bringup_lan start"


/*!\def SERVICE_LAN_RESTART
   \brief LAN Service restart
*/
#define SERVICE_LAN_RESTART             "/etc/rc.d/rc.bringup_lan restart"

/*!\def SERVICE_DDNS_STOP
   \brief DDNS Service stop
*/
#define SERVICE_DDNS_STOP               "/etc/rc.d/init.d/ddns stop"

/*!\def SERVICE_DDNS_START
   \brief DDNS Service start
*/
#define SERVICE_DDNS_START              "/etc/rc.d/init.d/ddns start"

/*!\def SERVICE_DDNS_RESTART
   \brief  DDNS Service restart
*/
#define SERVICE_DDNS_RESTART            "/etc/rc.d/init.d/ddns restart"

//601111:leejack start

/*!\def SERVICE_DNS_RELAY_START
   \brief DNS relay Service start
*/
#define SERVICE_DNS_RELAY_START         "/etc/rc.d/init.d/dns_relay start"


/*!\def SERVICE_DNS_RELAY_STOP
   \brief  DNS relay Service stop
*/
#define SERVICE_DNS_RELAY_STOP          "/etc/rc.d/init.d/dns_relay stop"


/*!\def SERVICE_DNS_RELAY_RESTART
   \brief  DNS relay Service restart 
*/
#define SERVICE_DNS_RELAY_RESTART       "/etc/rc.d/init.d/dns_relay restart"
//#define SERVICE_DNS_RELAY_START         "/usr/sbin/bringup_dns_relay start"
//#define SERVICE_DNS_RELAY_STOP          "/usr/sbin/bringup_dns_relay stop"
//#define SERVICE_DNS_RELAY_RESTART       "/usr/sbin/bringup_dns_relay restart"
//601111:leejack stop


/*!\def SERVICE_QOS_RESTART
   \brief QOS Service restart 
*/
#define SERVICE_QOS_RESTART             "/etc/rc.d/init.d/qos restart"

/*!\def SERVICE_QOS_PRIORITY_RESTART
   \brief QOS priority Service restart 
*/
#define SERVICE_QOS_PRIORITY_RESTART   	"/etc/rc.d/init.d/qos_apply_priority" //000001:tc.chen for update qos priority rule command

/*!\def SERVICE_ALGS_START
   \brief ALGS Service start 
*/
#define SERVICE_ALGS_START              "/etc/rc.d/init.d/algs start"

/*!\def SERVICE_ALGS_STOP
   \brief  ALGS Service stop
*/
#define SERVICE_ALGS_STOP               "/etc/rc.d/init.d/algs stop"

/*!\def SERVICE_ALGS_RESTART
   \brief  ALGS Service restart
*/
#define SERVICE_ALGS_RESTART            "/etc/rc.d/init.d/algs restart" //510251: sumedh (ALGs)
//511091:leejack start

/*!\def SERVICE_OAM_START
   \brief OAM Service start
*/
#define SERVICE_OAM_START               "/etc/rc.d/init.d/oam start"

/*!\def SERVICE_OAM_STOP
   \brief OAM Service stop
*/
#define SERVICE_OAM_STOP                "/etc/rc.d/init.d/oam stop"
//#define SERVICE_OAM_START               "/usr/sbin/bringup_oam start"
//#define SERVICE_OAM_STOP                "/usr/sbin/bringup_oam stop"
//511091:leejack end


/*!\def SERVICE_INETD_RESTART
   \brief INETD Service restart
*/
#define SERVICE_INETD_RESTART           "/etc/rc.d/init.d/inetd restart"

/*!\def SERVICE_HTTP_START
   \brief HTTP Service start
*/
#define SERVICE_HTTP_START              "/etc/rc.d/init.d/httpd start"

/*!\def SERVICE_HTTP_STOP
   \brief HTTP Service stop
*/
#define SERVICE_HTTP_STOP               "/etc/rc.d/init.d/httpd stop"

/*!\def SERVICE_TELNET_START
   \brief TELNET Service start
*/
#define SERVICE_TELNET_START            "/etc/rc.d/init.d/telnetd start"


/*!\def SERVICE_TELNET_STOP
   \brief TELNET Service stop
*/
#define SERVICE_TELNET_STOP             "/etc/rc.d/init.d/telnetd stop"


/*!\def SERVICE_SSH_START
   \brief SSH Service start
*/
#define SERVICE_SSH_START               "/etc/rc.d/init.d/sshd start"

/*!\def SERVICE_SSH_STOP
   \brief SSH Service stop
*/
#define SERVICE_SSH_STOP                "/etc/rc.d/init.d/sshd stop"

/*!\def SERVICE_TFTP_START
   \brief TFTP Service start
*/
#define SERVICE_TFTP_START              "/etc/rc.d/init.d/tftpd start"

/*!\def SERVICE_TFTP_STOP
   \brief TFTP Service stop
*/
#define SERVICE_TFTP_STOP               "/etc/rc.d/init.d/tftpd stop"

/*!\def SERVICE_FTP_START
   \brief FTP Service start
*/
#define SERVICE_FTP_START               "/etc/rc.d/init.d/ftpd start"

/*!\def SERVICE_FTP_STOP
   \brief FTP Service stop
*/
#define SERVICE_FTP_STOP                "/etc/rc.d/init.d/ftpd stop"

/*!\def NAPTCFG
   \brief NAPT config
*/
#define NAPTCFG                         "/usr/sbin/naptcfg"
//Sumedh - IGMP


/*!\def SERVICE_IGMP_RESTART
   \brief IGMP Service restart
*/
#define SERVICE_IGMP_RESTART		"/etc/rc.d/init.d/igmp restart"	
//Sumedh end

/* 509023:linmars start */

/*!\def SERVICE_PIF_START
   \brief PIF Service start
*/
#define SERVICE_PIF_START		"/etc/rc.d/init.d/pif start"	// 000001:tc.chen

/*!\def SERVICE_PIF_RESTART
   \brief PIF Service restart
*/
#define SERVICE_PIF_RESTART		"/etc/rc.d/init.d/pif restart"

/*!\def SERVICE_PIF_STOP
   \brief PIF Service stop
*/
#define SERVICE_PIF_STOP		"/etc/rc.d/init.d/pif stop"	// 000001:tc.chen

/*!\def SERVICE_VLAN_START
   \brief VLAN Service start
*/
#define SERVICE_VLAN_START		"/etc/rc.d/init.d/vlan start"

/*!\def SERVICE_VLAN_RESTART
   \brief VLAN Service restart
*/
#define SERVICE_VLAN_RESTART            "/etc/rc.d/init.d/vlan restart"

/*!\def SERVICE_VLAN_STOP
   \brief VLAN Service stop
*/
#define SERVICE_VLAN_STOP		"/etc/rc.d/init.d/vlan stop"
/* 509023:linmars end */


/*!\def SERVICE_UDHCPD_RESTART
   \brief UDHCPD Service restart
*/
#define SERVICE_UDHCPD_RESTART "/etc/rc.d/init.d/udhcpd restart"

/*!\def SERVICE_UDHCPD_START
   \brief UDHCPD Service start
*/
#define SERVICE_UDHCPD_START "/etc/rc.d/init.d/udhcpd start"

/*!\def SERVICE_UDHCPD_STOP
   \brief UDHCPD Service stop
*/
#define SERVICE_UDHCPD_STOP "/etc/rc.d/init.d/udhcpd stop"

/*!\def SERVICE_OPENSWAN_RESTART
   \brief OPENSWAN Service restart
*/
#define SERVICE_OPENSWAN_RESTART	"/etc/init.d/ipsec restart" //6090401:hsur add ipsec support

/* Wireless LAN Configuration Scripts */

/*!\def SERVICE_WLAN_START
   \brief WLAN Service start
*/
#define SERVICE_WLAN_START			         "/etc/rc.d/rc.bringup_wlan start"

/*!\def SERVICE_WLAN_STOP
   \brief WLAN Service stop
*/
#define SERVICE_WLAN_STOP			         "/etc/rc.d/rc.bringup_wlan stop"

/*!\def SERVICE_WLAN_REMOVE_VAP
   \brief WLAN Service remove
*/
#define SERVICE_WLAN_REMOVE_VAP           "/etc/rc.d/rc.bringup_wlan remove"

/*!\def SERVICE_WLAN_ADD_VAP
   \brief WLAN Service add
*/
#define SERVICE_WLAN_ADD_VAP           "/etc/rc.d/rc.bringup_wlan add"

/*!\def SERVICE_WLAN_SEC_MODIFY
   \brief WLAN SEC modify Service
*/
#define SERVICE_WLAN_SEC_MODIFY           "/etc/rc.d/rc.bringup_wlan sec_mod"

/*!\def SERVICE_WLAN_WMM_MODIFY
   \brief WLAN WMM modify Service
*/
#define SERVICE_WLAN_WMM_MODIFY           "/etc/rc.d/rc.bringup_wlan wmm_mod"

/*!\def SERVICE_WLAN_WPS_CONFIG
   \brief WLAN WPS config Service
*/
#define SERVICE_WLAN_WPS_CONFIG           "/etc/rc.d/rc.bringup_wlan wps_conf"


/*!\def SERVICE_WLAN_WPS_PBC_PAIRING
   \brief WLAN WPS PBC pairing Service
*/
#define SERVICE_WLAN_WPS_PBC_PAIRING      "/etc/rc.d/rc.bringup_wlan wps_trigger_pbc"

/*!\def SERVICE_WLAN_WPS_PIN_PAIRING
   \brief WLAN WPS Pin pairing Service
*/
#define SERVICE_WLAN_WPS_PIN_PAIRING      "/etc/rc.d/rc.bringup_wlan wps_trigger_pin"

/*!\def SERVICE_WLAN_GET_WPS_PIN
   \brief WLAN get WPS Pin Service
*/
#define SERVICE_WLAN_GET_WPS_PIN          "/etc/rc.d/rc.bringup_wlan get_wps_pin"


/*!\def SERVICE_WLAN_RESTORE_WPS_PIN
   \brief  WLAN restore WPS Pin Service
*/
#define SERVICE_WLAN_RESTORE_WPS_PIN      "/etc/rc.d/rc.bringup_wlan restore_wps_pin"
#define SERVICE_WLAN_RESET_WPS            "/etc/rc.d/rc.bringup_wlan reset_wps"

/*!\def SERVICE_WLAN_GENERATE_WPS_PIN
   \brief  WLAN generate WPS Pin Service
*/
#define SERVICE_WLAN_GENERATE_WPS_PIN     "/etc/rc.d/rc.bringup_wlan generate_wps_pin"

/*!\def SERVICE_WLAN_MAC_CTRL_MODIFY
   \brief  WLAN MAC control modify Service
*/
#define SERVICE_WLAN_MAC_CTRL_MODIFY      "/etc/rc.d/rc.bringup_wlan mac_ctrl_mod"

/*!\def SERVICE_WLAN_GET_STATS
   \brief  WLAN get stats Service
*/
#define SERVICE_WLAN_GET_STATS            "/etc/rc.d/rc.bringup_wlan get_stats"

/*!\def SERVICE_WLAN_GET_AP_DYN_INFO
   \brief WLAN Access Point dyn info get service
*/
#define SERVICE_WLAN_GET_AP_DYN_INFO      "/etc/rc.d/rc.bringup_wlan get_ap_dyn_info"


/*!\def SERVICE_WLAN_GET_ASSOC_DEV
   \brief WLAN device ASSOC get service
*/
#define SERVICE_WLAN_GET_ASSOC_DEV        "/etc/rc.d/rc.bringup_wlan get_assoc_dev"

/*!\def SERVICE_WLAN_GET_DEV_CAP
   \brief WLAN device capability get service
*/
#define SERVICE_WLAN_GET_DEV_CAP          "/etc/rc.d/rc.bringup_wlan capability"

/*!\def SERVICE_WLAN_GET_DEV_SEC_CAP
   \brief WLAN device capability get service
*/
#define SERVICE_WLAN_GET_DEV_SEC_CAP          "/etc/rc.d/rc.bringup_wlan capability_sec"

/*!\def SERVICE_WLAN_GET_RADIO_DYN_INFO
   \brief  WLAN get Radio dynamic info Service
*/
#define SERVICE_WLAN_GET_RADIO_DYN_INFO   "/etc/rc.d/rc.bringup_wlan get_radio_dyn_info"

/*!\def SERVICE_WLAN_GET_WPS_DYN_INFO
   \brief WLAN get WPS dynamic info Service
*/
#define SERVICE_WLAN_GET_WPS_DYN_INFO     "/etc/rc.d/rc.bringup_wlan get_wps_dyn_info"

/*!\def SERVICE_WLAN_GET_WPS_PROFILE
   \brief WLAN get WPS profile Service
*/
#define SERVICE_WLAN_GET_WPS_PROFILE      "/etc/rc.d/rc.bringup_wlan get_wps_profile"

/*!\def SERVICE_WLAN_GET_WPS_REGS_DYN_INFO
   \brief WLAN get WPS registers dynamic info Service
*/
#define SERVICE_WLAN_GET_WPS_REGS_DYN_INFO "/etc/rc.d/rc.bringup_wlan get_wps_regs_dyn_info"

#ifdef CONFIG_FEATURE_LTQ_WIRELESS_VB
/*!\def SERVICE_VB_CONFIG
   \brief VB get link status
*/
#define SERVICE_VB_CONFIG "/etc/rc.d/rc.bringup_wlan vb_config_mod"

/*!\def SERVICE_WLAN_VB_CONNECT
   \brief WLAN VB connection Service
*/
#define SERVICE_WLAN_VB_CONNECT			"/etc/rc.d/rc.bringup_wlan vb_trigger_connect"

/*!\def SERVICE_WLAN_VB_DISCONNECT
   \brief WLAN VB disconnect Service
*/
#define SERVICE_WLAN_VB_DISCONNECT			"/etc/rc.d/rc.bringup_wlan vb_trigger_disconnect"

/*!\def SERVICE_VB_GET_WLAN_LINK_STATUS
   \brief VB get link status
*/
#define SERVICE_VB_GET_WLAN_LINK_STATUS "/etc/rc.d/rc.bringup_wlan vb_get_wlan_link_status"

/*!\def SERVICE_VB_GET_WLAN_SCAN
   \brief VB get scan results
*/
#define SERVICE_VB_GET_WLAN_SCAN "/etc/rc.d/rc.bringup_wlan vb_get_wlan_scan_results"

/*!\def SERVICE_VB_WMM_CONFIG
   \brief VB modify WMM config
*/
#define SERVICE_VB_WMM_CONFIG "/etc/rc.d/rc.bringup_wlan vb_wmm_config"
#endif

#ifdef CONFIG_FEATURE_IFX_WIRELESS_TSC
/*!\def WLAN_UTIL_SCRIPT
   \brief WLAN utility script
*/
#define WLAN_UTIL_SCRIPT			      "/etc/rc.d/get_wlan_stats"
#endif /* #ifdef CONFIG_FEATURE_IFX_WIRELESS_TSC */


//#ifdef AMAZON [Sumedh Flag not used anymore. Always define the below
    
/*!\def IFX_LAN_IF
   \brief Lan interface
*/
#define IFX_LAN_IF              "eth0"    // adm0 (GW) must modify to br0(WL).
   
/*!\def IFX_PPP_IF
   \brief PPP interface
*/
#define IFX_PPP_IF              "ppp0"    // PPTP & PPPoE Interface
  
/*!\def IFX_WLAN_IF
   \brief WLAN interface
*/
#define IFX_WLAN_IF             "ath0"    // Wireless LAN Interface
  

/*!\def IFX_BRIDGE_IF
   \brief Bridge interface
*/
#define IFX_BRIDGE_IF           "br0"
  
/*!\def IFX_RFC2684_IF
   \brief RFC2684 interface
*/
#define IFX_RFC2684_IF          "nas0"
  

/*!\def IFX_CLIP_IF
   \brief Clip interface
*/
#define IFX_CLIP_IF             "atm0"



// Define Encryption Type
/*!\def ADSL_AUTO
   \brief ADSL encryption Auto type
*/
#define ADSL_AUTO 0

/*!\def ADSL_G9921A
   \brief ADSL encryption G9921A type
*/
#define ADSL_G9921A 1
  
/*!\def ADSL_G9921B
   \brief ADSL encryption G9921B type
*/
#define ADSL_G9921B 2
  
/*!\def ADSL_G9923A
   \brief ADSL encryption G9923A type
*/
#define ADSL_G9923A 3
  
/*!\def ADSL_G9923B
   \brief ADSL encryption G9923Btype
*/
#define ADSL_G9923B 4
  
/*!\def ADSL_G9925A
   \brief ADSL encryption G9925A type
*/
#define ADSL_G9925A 5
  
/*!\def ADSL_G9925B
   \brief ADSL encryption G9925B type
*/
#define ADSL_G9925B 6
	
//#endif Sumedh end ]

/*!\def PACKET_FILTER_TABLE_TYPE
   \brief Packet filter table type
*/
#define PACKET_FILTER_TABLE_TYPE    1

/*!\def MAC_FILTER_TABLE_TYPE
   \brief MAC filter table type
*/
#define MAC_FILTER_TABLE_TYPE       2

/*!\def QOS_PRIORITY_TABLE_TYPE
   \brief QOS priority table type
*/
#define QOS_PRIORITY_TABLE_TYPE	    3 // 000001:tc.chen

/*!\def POLICY_ROUTE_TABLE_TYPE
   \brief Policy route table type
*/
#define POLICY_ROUTE_TABLE_TYPE		4 //510251: sumedh (Policy based Routing)


/*!\def SIP_TABLE_TYPE
   \brief SIP table type
*/
#define SIP_TABLE_TYPE				5 //sumedh (SIP)

/*!\def SNMPv3_USER_TABLE_TYPE
   \brief SNMPv3 user table type
*/
#define SNMPv3_USER_TABLE_TYPE		6 // Subbi - SNMPv3 User Database

/*!\def VLAN_TABLE_TYPE
   \brief VLAN table type
*/
#define VLAN_TABLE_TYPE				8 // 604042: Sumedh
		

/*!\def LAN_IF_TYPE
   \brief LAN interface type
*/
#define LAN_IF_TYPE					0

/*!\def WAN_IF_TYPE
   \brief WAN interface type
*/
#define WAN_IF_TYPE					1

/*!\def OTHER_IF_TYPE
   \brief Other interface type
*/
#define OTHER_IF_TYPE					2

/*!\def IP_INFO
   \brief IP info
*/
#define IP_INFO						0


/*!\def MASK_INFO
   \brief Mask info 
*/
#define MASK_INFO					1

//////////////////////////////////////////////////////////////////////
// tag define begin
//


/*!\def TAG_HOSTNAME
   \brief Tag Host name
*/
#define TAG_HOSTNAME                        "hostname"
//#define TAG_TIME_ZONE                       "wizard_tz"

/*!\def TAG_TIME_SECTION
   \brief Tag time section 
*/
#define TAG_TIME_SECTION					"ntp"

/*!\def TAG_SYSTEM_PASSWORD
   \brief Tag system password
*/
#define TAG_SYSTEM_PASSWORD                 "system_password"

/*!\def TAG_SYSTEM_LOG
   \brief Tag system log 
*/
#define TAG_SYSTEM_LOG						"system_log"


/*!\def TAG_SYSTEM_AUTOLOGOUT
   \brief Tag system autologout 
*/
#define TAG_SYSTEM_AUTOLOGOUT                                   "system_autologout"

/*!\def TAG_WAN_MAIN
   \brief Tag WAN main 
*/
#define TAG_WAN_MAIN                        "wan_main"

#define DUMMY_WAN_MODE                      "dummy_wan_mode_sec"



/*!\def TAG_DHCP_BINPOND
   \brief Tag DHCP big pond
*/
#define TAG_DHCP_BINPOND                    "dhcp_bigpond"

/*!\def TAG_WAN_DHCPC
   \brief Tag WAN DHCPC
*/
#define TAG_WAN_DHCPC                       "wan_dhcpc"

/*!\def TAG_ROUTING
   \brief Tag routing
*/
#define TAG_ROUTING							"routing"

/*!\def TAG_WAN_STATIC
   \brief WAN static Tag
*/
#define TAG_WAN_STATIC                      "wan_static"

/*!\def TAG_WAN_STATIC_ALIAS
   \brief WAN static Alias Tag
*/
#define TAG_WAN_STATIC_ALIAS                "wan_static_alias"

/*!\def TAG_ROUTE_STATIC
   \brief Route static Tag
*/
#define TAG_ROUTE_STATIC                    "route_static"


/*!\def TAG_FIREWALLMAC_STAT
   \brief Firewall MAC stat Tag
*/
#define TAG_FIREWALLMAC_STAT                "firewall_mac_status"


/*!\def TAG_FIREWALLMAC
   \brief Fireall MAC Tag
*/
#define TAG_FIREWALLMAC                     "firewall_mac"

/*!\def TAG_UPNPCONFIG
   \brief UPNP config Tag 
*/
#define TAG_UPNPCONFIG                      "upnp_config"

/*!\def TAG_DDNSSTATUS
   \brief DDNS status Tag
*/
#define TAG_DDNSSTATUS                      "ddns_status"

/*!\def TAG_DDNSCONFIG
   \brief DDNS config Tag 
*/
#define TAG_DDNSCONFIG                      "ddns_config"

/*!\def TAG_WAN_PPPOE
   \brief WAN PPPOE Tag
*/
#define TAG_WAN_PPPOE                       "wan_pppoe"

/*!\def TAG_WAN_PPPOA
   \brief WAN PPPOA Tag 
*/
#define TAG_WAN_PPPOA                       "wan_pppoa"

/*!\def TAG_WAN_BRIDGE
   \brief WAN bridge Tag
*/
#define TAG_WAN_BRIDGE                      "wan_bridge"

/*!\def TAG_WAN_PPTP
   \brief WAN PPTP Tag 
*/
#define TAG_WAN_PPTP                        "wan_pptp"

/*!\def TAG_WAN_DNS
   \brief WAN DNS Tag
*/
#define TAG_WAN_DNS                         "wan_dns"

/*!\def TAG_WAN_TR037
   \brief WAN TR037 Tag 
*/
#define TAG_WAN_TR037                       "ilmi"

/*!\def TAG_LAN_MAIN
   \brief LAN main Tag 
*/
#define TAG_LAN_MAIN                        "lan_main"

/*!\def TAG_LAN_DHCPS
   \brief LAN DHCPS Tag
*/
#define TAG_LAN_DHCPS                       "lan_dhcps"

/*!\def TAG_LAN_DHCP_RELAY
   \brief LAN DHCP relay Tag 
*/
#define TAG_LAN_DHCP_RELAY                  "lan_dhcp_relay"

/*!\def TAG_LAN_DHCP_CLIENTS
   \brief LAN DHCP clients Tag
*/
#define TAG_LAN_DHCP_CLIENTS                "lan_dhcp_clients"

/*!\def TAG_LAN_STP_BRIDGE
   \brief LAN STP bridge Tag
*/
#define TAG_LAN_STP_BRIDGE                  "lan_stp_bridge"

#ifdef CONFIG_FEATURE_SAMBA /* CONFIG_FEATURE_SAMBA_SERVER */
/*!\def PREFIX_SMB_PASSWORD_FILE
   \brief Prefix SMB password file
*/
#define PREFIX_SMB_PASSWORD_FILE	    "smb_password_file"

/*!\def TAG_SAMBA_SERVER
   \brief SAMBA Server Tag 
*/
#define TAG_SAMBA_SERVER                    "samba_server"

/*!\def TAG_FILE_SHARE
   \brief File Share Tag 
*/
#define TAG_FILE_SHARE                      "file_share"

/*!\def TAG_SMB_PASSWORD_FILE_LINE
   \brief SMB Password file line Tag 
*/
#define TAG_SMB_PASSWORD_FILE_LINE    	    "smbPassFileLineCount"	 

/*!\def TAG_FILE_USER
   \brief File User Tag 
*/
#define TAG_FILE_USER                       "file_user"
#endif /* CONFIG_FEATURE_SAMBA_SERVER */

/*!\def TAG_WLAN_SETTINGS
   \brief WLAN settings Tag
*/
#define TAG_WLAN_SETTINGS                   "wlan_settings"

/*!\def TAG_WLAN_SECURITY
   \brief WAL security Tag 
*/
#define TAG_WLAN_SECURITY                   "wlan_security"

/*!\def TAG_NAT_FIREWALL_SHARE 
   \brief NAT Firewall Share Tag
*/
#define TAG_NAT_FIREWALL_SHARE              "nat_firewall_share"

/*!\def TAG_NAT_SPECIALAPP
   \brief NAT Special Application Tag 
*/
#define TAG_NAT_SPECIALAPP                  "nat_specialapp"

/*!\def TAG_NAT_VIRTUALSER
   \brief NAT virtualser Tag
*/
#define TAG_NAT_VIRTUALSER                  "nat_virtualser"

/*!\def TAG_NAT_PORTMAP
   \brief NAT Portmap Tag 
*/
#define TAG_NAT_PORTMAP                     "nat_portmap"

/*!\def TAG_NAT_ADDRMAP
   \brief NAT Addr map Tag 
*/
#define TAG_NAT_ADDRMAP                     "nat_addrmap"

/*!\def TAG_NAT_MAIN
   \brief NAT Main Tag 
*/
#define TAG_NAT_MAIN                        "nat_main"

/*!\def TAG_FIREWALL_MAIN
   \brief Firewall main Tag
*/
#define TAG_FIREWALL_MAIN                   "firewall_main"

/*!\def TAG_FIREWALL_DMZ
   \brief Firewall DMZ Tag 
*/
#define TAG_FIREWALL_DMZ                    "firewall_dmz"

/*!\def TAG_FIREWALL_DISABLEWAN
   \brief Firewall disable WAN Tag 
*/
#define TAG_FIREWALL_DISABLEWAN             "firewall_disablewan"

/*!\def TAG_FIREWALL_PACKETFILTER
   \brief Firewall Packet filter Tag 
*/
#define TAG_FIREWALL_PACKETFILTER           "firewall_packetfilter"

/*!\def TAG_FIREWALL_PACKETFILTER_STATUS
   \brief Firewall Packet filter status Tag 
*/
#define TAG_FIREWALL_PACKETFILTER_STATUS    "firewall_packetfilter_status"

/*!\def TAG_ROUTE_DYNAMIC
   \brief Route Dynamic Tag
*/
#define TAG_ROUTE_DYNAMIC                   "route_dynamic"

/*!\def TAG_ROUTE_TABLE
   \brief Route table Tag
*/
#define TAG_ROUTE_TABLE                     "route_table"

/*!\def TAG_WLAN_STATUS
   \brief WLAN status Tag 
*/
#define TAG_WLAN_STATUS                     "wlan_status"

/*!\def TAG_WLAN_CONFIG
   \brief WLAN config Tag 
*/
#define TAG_WLAN_CONFIG						"wlan_config"

/*!\def TAG_SNMP_AGENT
   \brief SNMP agent Tag 
*/
#define TAG_SNMP_AGENT                      "snmp_agent"

/*!\def TAG_MIB2_SYSTEM
   \brief MIB2 system Tag 
*/
#define TAG_MIB2_SYSTEM						"mib2_system"

/*!\def TAG_SNMP_TRANSPORT
   \brief SNMP Transport Tag 
*/
#define TAG_SNMP_TRANSPORT					"snmp_transport"

/*!\def TAG_SNMPv3_STATUS
   \brief SNMPv3 status Tag 
*/
#define TAG_SNMPv3_STATUS					"snmpv3_status"

/*!\def TAG_SNMPv3_USERDB
   \brief SNMPv3 userdb Tag 
*/
#define TAG_SNMPv3_USERDB					"snmpv3_users"

/*!\def TAG_ADSL_VCCHANNEL
   \brief ADSL vcchannel 
*/
#define TAG_ADSL_VCCHANNEL                  "adsl_vcchannel"

/*!\def TAG_ADSL_PHY
   \brief ADSL phy Tag 
*/
#define TAG_ADSL_PHY                        "adsl_phy"

/*!\def TAG_QOS_CONFIG
   \brief QOS config Tag 
*/
#define TAG_QOS_CONFIG                      "qos_config"

/*!\def TAG_QOS_DIFFSERV_CONFIG
   \brief QOS diffserv config Tag 
*/
#define TAG_QOS_DIFFSERV_CONFIG             "diffserv_config"

/*!\def TAG_NAPT_ALGS
   \brief NAPT Algs Tag
*/
#define TAG_NAPT_ALGS                       "napt_algs"

/*!\def TAG_ADSL_OAM
   \brief ADSL OAM Tag 
*/
#define TAG_ADSL_OAM                        "adsl_oam"

/*!\def TAG_ADSL_OAM_F4
   \brief ADSL OAM f4 Tag
*/
#define TAG_ADSL_OAM_F4                     "adsl_oam_f4"

/*!\def TAG_ADSL_OAM_F5
   \brief ADSL OAM f5 Tag 
*/
#define TAG_ADSL_OAM_F5                     "adsl_oam_f5"

/*!\def TAG_APPLICATION_SERVER
   \brief Application server Tag 
*/
#define TAG_APPLICATION_SERVER              "application_server"

/*!\def TAG_PASSWORD_FILE_LINE
   \brief Password file line Tag 
*/
#define TAG_PASSWORD_FILE_LINE		    	"passFileLineCount"	 

/*!\def TAG_SERVERS_ACL
   \brief Servers ACL Tag 
*/
#define TAG_SERVERS_ACL                     "servers_acl"

/*!\def TAG_SERVERS_ACL_STATUS
   \brief Servers ACL status Tag 
*/
#define TAG_SERVERS_ACL_STATUS              "servers_acl_status"

/*!\def TAG_VLAN_BRIDGE
   \brief VLAN Bridge Tag  
*/
#define TAG_VLAN_BRIDGE                     "vlan_bridge"   // 507082:linmars

/*!\def TAG_VLAN_BRIDGE_PB
   \brief VLAN bridge PB Tag 
*/
#define TAG_VLAN_BRIDGE_PB                  "vlan_bridge_pb"

/*!\def TAG_VLAN_BRIDGE_VB
   \brief VLAN bridge VB Tag 
*/
#define TAG_VLAN_BRIDGE_VB                  "vlan_bridge_vb"

/*!\def TAG_QOS_PRIORITY
   \brief QOS priority Tag 
*/
#define TAG_QOS_PRIORITY                    "qos_priority"  //000001:tc.chen qos priority

/*!\def TAG_SIP
   \brief SIP Tag 
*/
#define TAG_SIP				    			"sip" // 508181:tc.chen

/*!\def TAG_IPSEC
   \brief IPSec Tag 
*/
#define TAG_IPSEC_TUNNEL               			"ipsec_tunnel"

/*!\def TAG_AUTO_PVC
   \brief Auto PVC Tag 
*/
#define TAG_AUTO_PVC               			"auto_pvc"  //805071:<IFTW-leon> 

/*!\def TAG_AUTO_PVC_DB
   \brief Auto PVC DB Tag 
*/
#define TAG_AUTO_PVC_DB               			"auto_pvc_db" //805071:<IFTW-leon> 

/*!\def TAG_AUTO_PVC_MODE
   \brief Auto PVC Mode Tag
*/
#define TAG_AUTO_PVC_MODE             		"auto_pvc_mode"  //805151:<IFTW-leon>

/*!\def TAG_AUTO_PVC_PREVIOUS
   \brief Auto PVC Previous Tag 
*/
#define TAG_AUTO_PVC_PREVIOUS         		"auto_pvc_db_previous"  //805151:<IFTW-leon>
#define TAG_ETH_CHANNEL         "eth_channel"
#define TAG_PTM_CHANNEL         "ptm_channel"
//510251: sumedh start (Tags for DoS, ALGs, Policy based Routing)
#ifdef IFX_DOS_ENABLE

/*!\def TAG_DOS_MAIN
   \brief DOS Enable Main Tag 
*/
#define TAG_DOS_MAIN						"dos_main"

/*!\def TAG_DOS_APPLICATIONS
   \brief DOS Applications Tag 
*/
#define TAG_DOS_APPLICATIONS				"dos_applications"

/*!\def TAG_DOS_SCANS
   \brief DOS SCANS Tag 
*/
#define TAG_DOS_SCANS						"dos_scans"

/*!\def TAG_DOS_NETWORKING
   \brief DOS Networking Tag 
*/
#define TAG_DOS_NETWORKING					"dos_networking"
#endif

/*!\def TAG_ALG
   \brief Alg Tag 
*/
#define TAG_ALG								"algs"

/*!\def TAG_POLICY_ROUTING
   \brief Policy routing Tag 
*/
#define TAG_POLICY_ROUTING					"policy_routing"

/*!\def TAG_POLICY_ROUTING_STATUS
   \brief Policy routing status Tag 
*/
#define TAG_POLICY_ROUTING_STATUS			"policy_routing_status"

/*!\def TAG_SIP_MAIN
   \brief SIP Main Tag 
*/
#define TAG_SIP_MAIN						"sip_main"

/*!\def TAG_SIP_INFO
   \brief SIP Info Tag 
*/
#define TAG_SIP_INFO						"sip_info"

/*!\def TAG_NEXT_CPEID
   \brief Next CPEID Tag 
*/
#define	TAG_NEXT_CPEID						"next_cpeid"

/*!\def TAG_DEFAULT_WAN
   \brief Default WAN Tag 
*/
#define TAG_DEFAULT_WAN						"default_wan_iface"

/*!\def TAG_WAN_IP
   \brief WAN IP Tag 
*/
#define TAG_WAN_IP							"wan_ip"

/*!\def TAG_WAN_PPP
   \brief WAN PPP Tag 
*/
#define TAG_WAN_PPP							"wan_ppp"

/*!\def TAG_WAN_CONN_DEVICE
   \brief WAN Connection device Tag 
*/
#define	TAG_WAN_CONN_DEVICE					"wan_conndev"
/* TR-69 Specific Tags */

/*!\def TAG_WAN_DEVICE
   \brief WAN device Tag 
*/
#define	TAG_WAN_DEVICE						"wan_device"

/*!\def TAG_IGD
   \brief IGD Tag
*/
#define TAG_IGD								"igd"

/*!\def TAG_LAN_DEVICE
   \brief LAN device Tag 
*/
#define TAG_LAN_DEVICE						"land"

/*!\def TAG_ETH_CFG
   \brief ETH CFG Tag 
*/
#define	TAG_ETH_CFG							"eth_cfg"
// #define TAG_WAN_ATMF5						"wan_atmf5_diagnostics"

/*!\def TAG_WAN_ATMF5
   \brief WAN ATM F5 Tag 
*/
#define TAG_WAN_ATMF5						TAG_ADSL_OAM_F5

/*!\def TAG_DSL_DIAG
   \brief WAN DSL Diagnostics Tag 
*/
#define TAG_DSL_DIAG                   "wan_dsl_diagnostics"

/*!\def TAG_IPV6
   \brief IPv6 feature Tag 
*/
#define TAG_IPV6                       "ipv6_features"
#define TAG_LAN_IPV6                                    "lan_main_ipv6"
#define TAG_LAN_RADVD_IPV6                              "lan_radvd"
#define TAG_LAN_DHCP6S_IPV6                             "lan_dhcp6s"

/*!\def TAG_WLAN_PHY
   \brief WLAN phy Tag 
*/
#define TAG_WLAN_PHY                   "wlan_phy"

/*!\def TAG_WLAN_MAIN
   \brief WLAN main Tag 
*/
#define TAG_WLAN_MAIN                  "wlan_main"

/*!\def TAG_WLAN_WEP
   \brief WLAN WEP Tag 
*/
#define TAG_WLAN_WEP                   "wlan_wep"

/*!\def TAG_WLAN_PASSPHRASE
   \brief WLAN Passphrase Tag 
*/
#define TAG_WLAN_PASSPHRASE            "wlan_psk"

/*!\def TAG_WLAN_SEC
   \brief WLAN security Tag 
*/
#define TAG_WLAN_SEC                   "wlan_security"

/*!\def TAG_WLAN_1X
   \brief WLAN 1X Tag 
*/
#define TAG_WLAN_1X                    "wlan_1x"

/*!\def TAG_WLAN_GLOBAL_MAC_CONTROL
   \brief WLAN global MAC control Tag 
*/
#define TAG_WLAN_GLOBAL_MAC_CONTROL    "global_mac_control"

/*!\def TAG_WLAN_MAC_CONTROL
   \brief WLAN MAC control Tag 
*/
#define TAG_WLAN_MAC_CONTROL           "wlan_mac_control"

/*!\def TAG_WLAN_WMM_AP
   \brief WLAN WMM Access Point Tag
*/
#define TAG_WLAN_WMM_AP                "wlan_ap_wmm"

/*!\def TAG_WLAN_WMM_STA
   \brief WLAN WMM sta Tag 
*/
#define TAG_WLAN_WMM_STA               "wlan_sta_wmm"

/*!\def TAG_WLAN_WPS
   \brief WLAN WPS Tag 
*/
#define TAG_WLAN_WPS                   "wlan_wps"

/*!\def TAG_WLAN_WPS_REGISTRAR
   \brief WLAN WPS registrar Tag  
*/
#define TAG_WLAN_WPS_REGISTRAR         "wlan_wps_regs"

/*!\def TAG_WLAN_GEN_VB
   \brief VB GBD Tag
*/
#define TAG_WLAN_GEN_VB                "gen_bd_cfg"

/*!\def TAG_WLAN_VB_LAN
   \brief VB LBD Tag
*/
#define TAG_WLAN_VB_LAN                "lan_bd_cfg"

/*!\def TAG_VB_ETH_PHY
   \brief VB ETH PHY Tag
*/
#define TAG_VB_ETH_PHY          		"eth_phy_if"

/*!\def TAG_VB_WLAN_CFG
   \brief VB WLAN CONFIG Tag
*/
#define TAG_VB_WLAN_CFG            		"wlan_sta_cfg"

/*!\def TAG_VB_WLAN_PROF
   \brief VB WLAN PROFILE Tag
*/
#define TAG_VB_WLAN_PROF           		"wlan_profile"

/*!\def TAG_VB_WLAN_SCAN
   \brief VB WLAN SCAN Tag
*/
#define TAG_VB_WLAN_SCAN           		"wlan_scan"

/*!\def TAG_VB_WLAN_WMM
   \brief WLAN WMM sta Tag
*/
#define TAG_VB_WLAN_WMM					"wlan_bd_sta_wmm"

/*!\def TAG_LAN_DHCP_COND_INFO 
   \brief LAN DHCP Cond Info Tag 
*/
#define TAG_LAN_DHCP_COND_INFO         "lan_dhcps_condserv"

/*!\def TAG_IPSEC_INFO
   \brief Ipsec  Tag  Info
*/
#define TAG_IPSEC_INFO         "ipsec_tunnel"

//510251: sumedh end (Tags for DoS, ALGs, Policy based Routing)
//////////////////////////////////////////////////////////////////////



///////////////////////////////////////////////////////////////////
//vipul start


/*!\def TAG_LAN_DHCPS_STATIC_LEASE
   \brief LAN DHCPS static lease Tag 
*/
#define TAG_LAN_DHCPS_STATIC_LEASE                      "lan_dhcps_static_lease"

/*!\def PREFIX_LAN_DHCPS_STATIC_LEASE
   \brief LAN DHCPS static lease prefix 
*/
#define PREFIX_LAN_DHCPS_STATIC_LEASE 			"ldhcp"


/*!\def TAG_NAT_PORT_TRIGGER
   \brief NAT port trigger Tag 
*/
#define TAG_NAT_PORT_TRIGGER				"nat_port_trigger"

/*!\def PREFIX_NAT_PORT_TRIGGER
   \brief NAT port trigger prefix 
*/
#define PREFIX_NAT_PORT_TRIGGER 			"porttrigger"

//vipul end
//////////////////////////////////////////////////////////////////







/*!\def TAG_APP_FILTER
   \brief Application filtering Tag 
*/
#define TAG_APP_FILTER						"applicaion_filtering"

/*!\def TAG_WAN_VLAN
   \brief WAN VLAN Tag 
*/
#define TAG_WAN_VLAN						"wan_vlan_config"

/*!\def IFX_DEVICE_INFO_SECTION
   \brief Device info section
*/
#define IFX_DEVICE_INFO_SECTION                   "device_info"

/*!\def IFX_DEVICE_INFO_MANUFACTURER
   \brief Device info Manufacturer
*/
#define IFX_DEVICE_INFO_MANUFACTURER              "manu"

/*!\def IFX_DEVICE_INFO_MANUFACTUREROUI
   \brief Device info manufactureroui
*/
#define IFX_DEVICE_INFO_MANUFACTUREROUI           "oui"

/*!\def IFX_DEVICE_INFO_MODELNAME
   \brief Device info modelname 
*/
#define IFX_DEVICE_INFO_MODELNAME                 "modname"

/*!\def IFX_DEVICE_INFO_DESCRIPTION
   \brief Device info description 
*/
#define IFX_DEVICE_INFO_DESCRIPTION               "desc"

/*!\def IFX_DEVICE_INFO_PRODUCTCLASS
   \brief Device info productclass
*/
#define IFX_DEVICE_INFO_PRODUCTCLASS              "prodclass"

/*!\def IFX_DEVICE_INFO_SERIALNUMBER
   \brief Device Info serial number 
*/
#define IFX_DEVICE_INFO_SERIALNUMBER              "sernum"

/*!\def IFX_DEVICE_INFO_HARDWAREVERSION
   \brief Device info Hardware version 
*/
#define IFX_DEVICE_INFO_HARDWAREVERSION           "hwver"

/*!\def IFX_DEVICE_INFO_SOFTWAREVERSION
   \brief Device info software version 
*/
#define IFX_DEVICE_INFO_SOFTWAREVERSION           "swver"

/*!\def IFX_DEVICE_INFO_MODEMFIRMWAREVERSION
   \brief Device info Modem firmware version 
*/
#define IFX_DEVICE_INFO_MODEMFIRMWAREVERSION      "modfwver"

/*!\def IFX_DEVICE_INFO_SPECVERSION
   \brief Device info spec version 
*/
#define IFX_DEVICE_INFO_SPECVERSION               "specver"

/*!\def IFX_DEVICE_INFO_PROVISIONINGCODE
   \brief Device info provisioning code
*/
#define IFX_DEVICE_INFO_PROVISIONINGCODE          "provcode"

/*!\def IFX_DEVICE_INFO_UPTIME
   \brief Device info uptime 
*/
#define IFX_DEVICE_INFO_UPTIME                    "uptime"

/*!\def IFX_DEVICE_INFO_MODELNUMBER
   \brief Device info Model number 
*/
#define IFX_DEVICE_INFO_MODELNUMBER               "modnum"

/*!\def IFX_DEVICE_INFO_TR64URL
   \brief Device info TR64 URL 
*/
#define IFX_DEVICE_INFO_TR64URL                   "tr64url"


/*!\def IFX_DEVICE_INFO_SYSCONTACT
   \brief Device info sys contact 
*/
#define IFX_DEVICE_INFO_SYSCONTACT				  "syscontact"

/*!\def IFX_DEVICE_INFO_SYSNAME
   \brief Device info sys name 
*/
#define IFX_DEVICE_INFO_SYSNAME					  "sysname"

/*!\def IFX_DEVICE_INFO_SYSLOCATION
   \brief Device info sys location 
*/
#define IFX_DEVICE_INFO_SYSLOCATION				  "syslocation"

/*!\def IFX_DEVICE_INFO_SYSOBJECT_ID
   \brief Device info sys object ID 
*/
#define IFX_DEVICE_INFO_SYSOBJECT_ID			  "sysobjid"

/*!\def IFX_DEVICE_INFO_SYSSERVICES
   \brief Device info sys services 
*/
#define IFX_DEVICE_INFO_SYSSERVICES				  "sysservices"

/*IPQoS related TAGS and prefixes */

/*!\def TAG_IPQOS_QM
   \brief IPQOS queue management Tag 
*/
#define TAG_IPQOS_QM						"qos_queuemgmt"

/*!\def TAG_IPQOS_CAPABILITY
   \brief  IPQOS capability Tag 
*/
#define TAG_IPQOS_CAPABILITY				"qos_capability"

/*!\def TAG_IPQOS_CLASSIFY
   \brief IPQOS classify Tag 
*/
#define TAG_IPQOS_CLASSIFY					"qos_class"

/*!\def TAG_IPQOS_QUEUE
   \brief IPQOS queue Tag 
*/
#define TAG_IPQOS_QUEUE						"qos_queue"

/*!\def TAG_IPQOS_POLICER
   \brief IPQOS policer Tag 
*/
#define TAG_IPQOS_POLICER						"qos_policer"


/*!\def PREFIX_IPQOS_CLASSIFY
   \brief  IPQOS classify Prefix 
*/
#define PREFIX_IPQOS_CLASSIFY                           "qcl"

/*!\def PREFIX_IPQOS_QUEUE
   \brief IPQOS queue Prefix 
*/
#define PREFIX_IPQOS_QUEUE                                      "qq"

/*!\def PREFIX_IPQOS_CAPABILITY
   \brief IPQOS capability Prefix 
*/
#define PREFIX_IPQOS_CAPABILITY                         "qcap"

/*!\def PREFIX_IPQOS_QM
   \brief IPQOS queue managment Prefix 
*/
#define PREFIX_IPQOS_QM                                         "qm"

/*!\def PREFIX_IPQOS_POLICER
   \brief IPQOS policer prefix 
*/
#define PREFIX_IPQOS_POLICER                                         "qpl"

//scripts called from MAPI

/*!\def IPQOS_INIT
   \brief IPQOS init 
*/
#define IPQOS_INIT					"/etc/rc.d/ipqos_init"

/*!\def IPQOS_DISABLE
   \brief IPQOS disable 
*/
#define IPQOS_DISABLE				"/etc/rc.d/ipqos_disable"

/*!\def IPQOS_CLASSIFY_ADD
   \brief IPQOS classify Add 
*/
#define IPQOS_CLASSIFY_ADD			"/etc/rc.d/ipqos_class_add"

/*!\def IPQOS_CLASSIFY_SKIP
   \brief IPQOS classify Skip 
*/
#define IPQOS_CLASSIFY_SKIP			"/etc/rc.d/ipqos_class_skip"

/*!\def IPQOS_CLASSIFY_DELETE
   \brief IPQOS classify delete
*/
#define IPQOS_CLASSIFY_DELETE       "/etc/rc.d/ipqos_class_delete"

/*!\def IPQOS_QUEUE_MGMT
   \brief IPQOS queue management 
*/
#define IPQOS_QUEUE_MGMT             "/etc/rc.d/ipqos_q_mgmt"

/*!\def IPQOS_MGMT
   \brief IPQOS management 
*/
#define IPQOS_MGMT                   "/etc/rc.d/ipqos_mgmt"

//QoS Scripts with PPA enabled
#define PPE_IPQOS_INIT			"/etc/rc.d/ppe_ipqos_init"
#define PPE_IPQOS_MAIN			"/etc/rc.d/ppe_ipqos_main"
#define PPE_IPQOS_QUEUE_INIT		"/etc/rc.d/ppe_ipqos_q_init"
#define PPE_IPQOS_QUEUE_MGMT		"/etc/rc.d/ppe_ipqos_q_mgmt"
#define PPE_IPQOS_DISABLE		"/etc/rc.d/ppe_ipqos_disable"


/* IPQoS end */


/* Media Server related Tags, Prefixes and Scripts */

/*!\def TAG_MEDIA_SERVER
   \brief Media Server Tag
*/
#define TAG_MEDIA_SERVER			"media_server"

/*!\def PREFIX_MEDIA_SERVER
   \brief Media Server Prefix
*/
#define PREFIX_MEDIA_SERVER			"ms"

/*!\def TAG_MEDIA_LOCATIONS
   \brief Media Locations Tag
*/
#define TAG_MEDIA_LOCATIONS			"media_locations"

/*!\def PREFIX_MEDIA_LOCATIONS
   \brief Media Locations Prefix
*/
#define PREFIX_MEDIA_LOCATIONS			"ml"

/*!\def SERVICE_MEDIASERVER_START
   \brief Media Server Service start
*/
#define SERVICE_MEDIASERVER_START		"/etc/init.d/minidlna start"

/*!\def SERVICE_MEDIASERVER_STOP
   \brief Media Server Service stop
*/
#define SERVICE_MEDIASERVER_STOP		"/etc/init.d/minidlna stop"

/*!\def SERVICE_PPPOE_RESTART
   \brief Media Server Service restart
*/
#define SERVICE_MEDIASERVER_RESTART		"/etc/init.d/minidlna restart"

/* Media Server end */

/*!\def TAG_HTTP_SRV_CFG
	\brief Section name for HTTP Server configuration params in rc.conf
*/
#define TAG_HTTP_SRV_CFG		"http_srv_cfg"
