/**************************************************************************
** FILE NAME     : IFX_Types.h
** PROJECT       : TR69
** MODULES       : Common Libs. 
** SRC VERSION   : V2.0
** DATE          : 15-12-2004
** AUTHOR        : Narendra.V.P
** DESCRIPTION   : Type definitions for data types.
** REFERENCE     : Coding guide lines.
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author      $Comment
***********************************************************************/


/*! \file ifx_types.h
    \brief This file contains Type definitions for data types.
*/


#ifndef   __IFIN_TR69_TYPES_H__
#define   __IFIN_TR69_TYPES_H__


#ifndef _IFX_BASIC_TYPES_H


/*! \def char8
*/
typedef char char8;

/*! \def uchar8
*/
typedef unsigned char uchar8;

/*! \def int8
*/
typedef char int8;

/*! \def uint8
*/
typedef unsigned char uint8;

/*! \def int16
*/
typedef short int int16;

/*! \def uint16
*/
typedef unsigned short int uint16;

/*! \def int32
*/
typedef int int32;

/*! \def uint32
*/
typedef unsigned int uint32;

/*! \def int64
*/
typedef long long int int64;

/*! \def uint64
*/
typedef unsigned long long int uint64;

/*! \def float32
*/
typedef float float32;

/*! \def float64
*/
typedef double float64;

/*! \def IFIN_TR69_Void
*/
typedef void IFIN_TR69_Void;

/*! \def bool
*/
typedef char bool;



#endif

#endif    /* __IFIN_TR69_TYPES_H__ */
