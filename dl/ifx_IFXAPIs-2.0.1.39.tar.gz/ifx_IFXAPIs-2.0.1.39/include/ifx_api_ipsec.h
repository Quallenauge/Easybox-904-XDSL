
/*! \brief  This API sets an ipsec tunnel entry configuration. It writes tunnel configuration
                    into rc.conf by taking values from input structure array.
        \param[out] ipsec_tunnel info written to rc.conf
        \param[in] flags Any of the flags IFX_F_MODIFY,
                                        IFX_F_DELETE,
                                        IFX_F_DEFAULT,
                                        IFX_F_DONT_ACTIVATE | IFX_F_DONT_VALIDATE,
                                        IFX_F_DEACTIVATE
                                        can be passed to this API
        \param[in] operation Any of the flags IFX_OP_ADD,
                                        IFX_OP_DEL,
                                        IFX_OP_MODIFY
                                        can be passed to this API
        \return IFX_SUCCESS / IFX_FAILURE
*/
extern int32 ifx_set_ipsec_tunnel_entry(int32 operation, IFX_IPSEC_TUNNEL *p_ipsec_tunnel_info, uint32 flags);

/*! \brief  This API returns all the ipsec tunnel configuration for all existing tunnel entries. It reads all the tunnel
                    from rc.conf and returns them in the output structure array. Also the count of
                    tunnel entries read, will be returned in num_entries.
        \param[out] num_entries Output number of the tunnel entries read.
        \param[out] ipsec_tunnel Allocated array of Tunnel entries. Caller has to free the memory allocated.
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                        IFX_F_GET_INCOMP,
                                        IFX_F_GET_ENA or IFX_F_DEFAULT
                                        can be passed to this API
        \return IFX_SUCCESS / IFX_FAILURE
*/
extern int32 ifx_get_all_ipsec_tunnel_entries(int32 *num_entries, IFX_IPSEC_TUNNEL **pp_ipsec_tunnel_info, uint32 flags);

/*! \brief  This API returns an ipsec tunnel entry configuration. It reads tunnel configuration
                    from rc.conf and returns them in the output structure array.
        \param[out] ipsec_tunnel info structure filled.
        \param[in] flags Any of the flags IFX_F_GET_DIS,
                                        IFX_F_GET_INCOMP,
                                        IFX_F_GET_ENA or IFX_F_DEFAULT
                                        can be passed to this API
        \return IFX_SUCCESS / IFX_FAILURE
*/
extern int32 ifx_get_ipsec_tunnel_entry(IFX_IPSEC_TUNNEL *pp_ipsec_tunnel_info, uint32 flags);
