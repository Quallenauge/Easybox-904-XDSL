/* ============================================================================
 * Copyright (C) 2004 - Infineon Technologies.
 *
 * All rights reserved.
 * ============================================================================
 *
 * ============================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ============================================================================
 *
 * Revision History:
 *      - 2004/07/20, TC Chen
 *         init version
 *
 * ============================================================================
 */

/*! \file ifx_api_fw.h 
    \brief This file contains the macros and extern function prototypes for firewall MAPI
*/

#ifndef _IFX_API_FW_H_
#define _IFX_API_FW_H_

#include <linux/if_ether.h>
#include <ifx_api_ipt_common.h>

/*! \def DISCARD_PING_WAN_RESPONSE 
    \brief Ping WAN response discard flag 
*/
#define DISCARD_PING_WAN_RESPONSE     0  /*!< value is 0. */

/*! \def DISCARD_PING_WAN_RESPONSE 
    \brief Ping forward response discard flag
*/
#define DISCARD_PING_FORWARD_RESONSE  1  /*!< value is 1. */

/*! 
    \brief This function enables firewall extern boolean function 
	\param[in] operation 
	\param[in]  *pbIFX_SET_Enable
	\return TRUE / FALSE
*/
extern bool IFXSetFirewallEnable(int operation, bool *pbIFX_SET_Enable); /*!< this function enables firewall */

/*! 
    \brief This function enables DOS Attack Protect extern boolean function 
	\param[in] operation 
	\param[in]  *pbEnable
	\return TRUE / FALSE
*/
	
extern bool IFXSetFirewallDosProtoectEnable(int operation, bool *pbEnable); /*!< these are firewall enabling functions */

/*! 
     \brief This function enables ping response extern boolean function 
	\param[in] operation 
	\param[in] type
	\param[in]  *pbEnable
	\return TRUE / FALSE
*/

extern bool IFXSetFirewallPingResponse(int operation, int type, bool *pbEnable); /*!< these are firewall enabling functions */

/*! 
     \brief This function enables the client filter extern boolean function 
	\param[in] operation 
	\param[in]  *pbEnable
	\return TRUE / FALSE
*/

extern bool IFXSetClientFilterEnable(int operation, bool *pbEnable); /*!< these are firewall enabling functions */

/*! 
     \brief This function enables firewall MAC filter extern boolean function 
	\param[in] operation 
	\param[in]  *pbEnable
	\return TRUE / FALSE
*/

extern bool IFXSetFirewallMacFilterEnable(int operation, bool *pbEnable);  /*!<  these are firewall enabling functions */


/*! 
     \brief This function sets MAC filter drop  extern boolean function 
	\param[in] operation 
	\param[out] pCfg
	\param[in]  *piEnteriesSize
	\return TRUE / FALSE
*/

extern bool IFXSetFirewallMacFilterDropEntry(int operation, P_IFX_IPT_RULE pCfg, int *piEnteriesSize);  /*!< these are firewall enabling functions */


/*! \fn bool IFXSetFirewallMacFilterPermitEntry(int operation, P_IFX_IPT_RULE pCfg, int *piEnteriesSize)
     \brief This function sets MAC filter permit extern boolean function 
	\param[in] operation 
	\param[out] pCfg
	\param[in]  *piEnteriesSize
	\return TRUE / FALSE
*/

extern bool IFXSetFirewallMacFilterPermitEntry(int operation, P_IFX_IPT_RULE pCfg, int *piEnteriesSize);  /*!<these are firewall enabling functions */



/*! \fn bool IFXSetFirewallPacketFilterEnable(int operation, bool *pbEnable)
     \brief  This function enables firewall packet filter extern boolean function 
	\param[in] operation 
	\param[in]  *pbEnable
	\return TRUE / FALSE
*/

extern bool IFXSetFirewallPacketFilterEnable(int operation, bool *pbEnable);  /*!< these are firewall enabling functions */


/*! \fn bool IFX_SET_FIREWALL_DNAT_VIRTUALSERVER_Entry(int operation, P_IFX_IPT_RULE pCfg, int *piEnteriesSize)
     \brief This function sets DNAT virtual server entry extern boolean function 
	\param[in] operation 
	\param[out] pCfg
	\param[in]  *piEnteriesSize
	\return TRUE / FALSE
*/

extern bool IFX_SET_FIREWALL_DNAT_VIRTUALSERVER_Entry(int operation, P_IFX_IPT_RULE pCfg, int *piEnteriesSize);  /*!< these are firewall enabling functions */


/*! \fn bool IFX_SET_FIREWALL_DNAT_VIRTUALSERVER_ENABLE(int operation, bool *pbEnable)
     \brief This function enables DNAT virtual server extern boolean function 
	\param[in] operation 
	\param[in]  *pbEnable
	\return TRUE / FALSE
*/

extern bool IFX_SET_FIREWALL_DNAT_VIRTUALSERVER_ENABLE(int operation, bool *pbEnable);  /*!< these are firewall enabling functions */


/*! \fn bool IFX_SET_FIREWALL_DNAT_PORTMAPPING_Entry(int operation, P_IFX_IPT_RULE pCfg, int *piEnteriesSize)
     \brief This function sets DNAT port mapping entry extern boolean function 
	\param[in] operation 
	\param[out] pCfg
	\param[in]  *piEnteriesSize
	\return TRUE / FALSE
*/

extern bool IFX_SET_FIREWALL_DNAT_PORTMAPPING_Entry(int operation, P_IFX_IPT_RULE pCfg, int *piEnteriesSize);  /*!< these are firewall enabling functions */


/*! \fn bool IFX_SET_FIREWALL_DNAT_PORTMAPPING_ENABLE(int operation, bool *pbEnable)
     \brief This function enables DNAT port mapping extern boolean function 
	\param[in] operation 
	\param[in]  *pbEnable
	\return TRUE / FALSE
*/

extern bool IFX_SET_FIREWALL_DNAT_PORTMAPPING_ENABLE(int operation, bool *pbEnable);  /*!<these are firewall enabling functions */

/*! \fn bool IFX_SET_FIREWALL_DMZ(int operation, __u32 DMZ_IP)
     \brief This function sets DMZ rule extern boolean function 
	\param[in] operation 
	\param[out] DMZ_IP
	\return TRUE / FALSE
*/

extern bool IFX_SET_FIREWALL_DMZ(int operation, __u32 DMZ_IP);  /*!< these are firewall enabling functions */


/*! \fn bool IFX_SET_FIREWALL_DMZ_ENABLE(int operation, bool *pbEnable)
     \brief This function enables DMZ chain extern boolean function 
	\param[in] operation 
	\param[in]   *pbEnable
	\return TRUE / FALSE
*/

extern bool IFX_SET_FIREWALL_DMZ_ENABLE(int operation, bool *pbEnable);  /*!<these are firewall enabling functions */



/*! \fn bool IFX_SET_FIREWALL_DENY_SERVICES(int operation, int IFtype, __u16 port , __u16 protocol)
     \brief This function sets rules to drop connections to LAN/WAN sides extern boolean function 
	\param[in] operation 
	\param[in] IFtype
	\param[out] port
	\param[out] protocol 
	\return TRUE / FALSE
*/

extern bool IFX_SET_FIREWALL_DENY_SERVICES(int operation, int IFtype, __u16 port , __u16 protocol);  /*!<these are firewall enabling functions */


/*! \fn bool IFX_SET_FIREWALL_ACCEPT_SERVICES(int operation,__u16 port , __u16 protocol,bool acl)
     \brief This function sets rules to accept connections to LAN/WAN sides extern boolean function 
	\param[in] operation 
	\param[out] port
	\param[out] protocol 
	\param[in] acl
	\return TRUE / FALSE
*/

extern bool IFX_SET_FIREWALL_ACCEPT_SERVICES(int operation,__u16 port , __u16 protocol,bool acl);  /*!< these are firewall enabling functions  */


/*! \fn bool IFX_FIREWALL_SET_LAN(int operation, char *IFNAME, __u32 IPADDR )
     \brief Thsi function adds LAN interface to firewall extern boolean function 
	\param[in] operation 
	\param[in]  *IFNAME
	\param[out] IPADDR
	\return TRUE / FALSE
*/

extern bool IFX_FIREWALL_SET_LAN(int operation, char *IFNAME, __u32 IPADDR );  /*!< this function enables firewall */

 
/*! \fn bool IFXSetFirewallEnable(int operation, bool *pbIFX_SET_Enable)
     \brief This function adds WAN interface to firewall extern boolean function 
	\param[in] operation 
	\param[in]  *pbIFX_SET_Enable
	\return TRUE / FALSE
*/

extern bool IFX_FIREWALL_SET_WAN_IF(int operation, char *IFNAME);  /*!< this function enables firewall */


/*! \fn bool IFX_FIREWALL_SET_WAN_IP(int operation, __u32 IPADDR )
     \brief This functions adds WAN IP to firewall extern boolean function 
	\param[in] operation 
	\param[out] IPADDR
	\return TRUE / FALSE
*/

extern bool IFX_FIREWALL_SET_WAN_IP(int operation, __u32 IPADDR );  /*!< this function enables firewall */


/*! \fn bool IFX_SET_FIREWALL_ACCEPT_WAN_SERVICES_TO_LAN(int operation,__u16 port , __u16 protocol)
     \brief This functionsets rukes to accept WAN services to LAN extern boolean function 
	\param[in] operation 
	\param[out] port
	\param[out] protocol 
	\return TRUE / FALSE
*/

extern bool IFX_SET_FIREWALL_ACCEPT_WAN_SERVICES_TO_LAN(int operation,__u16 port , __u16 protocol);  /*!< this function enables firewall */


#endif
