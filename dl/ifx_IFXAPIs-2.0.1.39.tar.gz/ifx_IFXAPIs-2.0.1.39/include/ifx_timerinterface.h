/**************************************************************************
** FILE NAME     : IFX_TimerInterface.h
** PROJECT       : TR60
** MODULES       : Commong Libs.
** SRC VERSION   : V2.0
** DATE          : 15-12-2004
** AUTHOR        : TR69 Team
** DESCRIPTION   : Wrapper functions for timer library
** REFERENCE     : Coding guide lines.
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author      $Comment
***********************************************************************/



/*! \file ifx_timerinterface.h
    \brief This file contains Wrapper functions for timer library.
*/



#ifndef __IFIN_TR69_TIMER_INTERFACE_H__
#define __IFIN_TR69_TIMER_INTERFACE_H__



/*!  \brief This structure contains TR69 timer information parameters
 */
typedef struct {
  char8 cIsFree;  /*!< Timer free flag */
  uint16 unTimerId;  /*!< Timer ID */
  void( *pfnCallBackFn)(void*);  /*!< Pointer to call back function */
  void* pCallBackFnParam;  /*!< Pointer to call back function parameter */
}
x_IFIN_TR69_TimerInfo;


/*! \fn e_IFIN_TR69_Return IFIN_TR69_TimerInit();
    \brief Initializes the endpoint info
    \return IFIN_TR69_SUCCESS/IFIN_TR69_FAILURE
 */
PUBLIC e_IFIN_TR69_Return IFIN_TR69_TimerInit();


/*! \fn void IFIN_TR69_ProcessTimerMsg(IN x_IFIN_TR69_TimerInfo *pxTimerInfo);
    \brief Initializes the endpoint info
    \param[in] pxTimerInfo
    \return void
 */
PUBLIC void IFIN_TR69_ProcessTimerMsg(IN x_IFIN_TR69_TimerInfo *pxTimerInfo);



/*! \fn e_IFIN_TR69_Return IFIN_TR69_StartTimer(IN uint32 uiTimeOutValue, 
                                                IN void* pfn_IFIN_TR69_CallBackFn,
                                                IN void* pCallBackFnParam,
                                                OUT uint16* punTimerId,
                                                OUT uint32* peEcode);
    \brief Initializes the endpoint info
    \param[in] uiTimeOutValue
    \param[in] pfn_IFIN_TR69_CallBackFn
    \param[in] pCallBackFnParam
    \param[out] punTimerId
    \param[out] peEcode
    \return IFIN_TR69_SUCCESS/IFIN_TR69_FAILURE
 */
EXTERN PUBLIC e_IFIN_TR69_Return
IFIN_TR69_StartTimer(IN uint32 uiTimeOutValue, /* milli seconds */
    IN void* pfn_IFIN_TR69_CallBackFn,
    IN void* pCallBackFnParam,
    OUT uint16* punTimerId,
    OUT uint32* peEcode);


/*! \fn e_IFIN_TR69_Return IFIN_TR69_StartDnsTimer(IN uint32 uiTimeOutValue, 
                                                   IN void* pfn_IFIN_TR69_CallBackFn,
                                                   IN void* pCallBackFnParam,
                                                   OUT uint16* punTimerId,
                                                   OUT uint32* peEcode);
    \brief Initializes the endpoint info
    \param[in] uiTimeOutValue
    \param[in] pfn_IFIN_TR69_CallBackFn
    \param[in] pCallBackFnParam
    \param[out] punTimerId
    \param[out] peEcode
    \return IFIN_TR69_SUCCESS/IFIN_TR69_FAILURE
 */
EXTERN PUBLIC e_IFIN_TR69_Return
IFIN_TR69_StartDnsTimer(IN uint32 uiTimeOutValue, /* milli seconds */
    IN void* pfn_IFIN_TR69_CallBackFn,
    IN void* pCallBackFnParam,
    OUT uint16* punTimerId,
    OUT uint32* peEcode);

/*! \fn e_IFIN_TR69_Return IFIN_TR69_StopTimer(uint16)
    \brief Initializes the endpoint info
    \param[in] unTimerId
    \return IFIN_TR69_SUCCESS/IFIN_TR69_FAILURE
 */
EXTERN e_IFIN_TR69_Return IFIN_TR69_StopTimer(uint16);

#endif /*__IFIN_TR69_TIMER_INTERFACE_H__*/
