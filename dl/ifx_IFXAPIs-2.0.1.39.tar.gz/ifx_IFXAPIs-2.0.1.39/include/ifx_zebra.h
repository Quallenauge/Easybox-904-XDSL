/* ============================================================================
 * Copyright (C) 2004 - Infineon Technologies.
 *
 * All rights reserved.
 * ============================================================================
 *
 * ============================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ============================================================================
 *
 * Revision History:
 *      - 2004/07/13, MarsLin
 *         init version
 *
 * ============================================================================
 */



/*! \file ifx_zebra.h
    \brief This header file contains macros, structures and function prototypes for zebra sources
*/



#ifndef _IFX_ZEBRA_H_
#define _IFX_ZEBRA_H_



/*! \def IFX_ZEBRA_LENGTH_IFNAME
    \brief Zebra interface name length 
 */
#define IFX_ZEBRA_LENGTH_IFNAME     IFX_LENGTH_IFNAME

/*! \def IFX_ZEBRA_RIP2_LENGTH_KEY
    \brief Zebra RIP2 Key length
 */
#define IFX_ZEBRA_RIP2_LENGTH_KEY   100



/*! \enum 
    \brief enumeration for RIP authentication
*/
enum {
    IFX_ZEBRA_RIP_AUTH_UNSET = 0,
    IFX_ZEBRA_RIP_AUTH_SIMPLE,
    IFX_ZEBRA_RIP_AUTH_MD5,
};



/*! \enum 
    \brief enumearation for RIP version
*/
enum {
    IFX_ZEBRA_RIP_VERSION_UNSET = 0,
    IFX_ZEBRA_RIP_VERSION_1,
    IFX_ZEBRA_RIP_VERSION_2,
    IFX_ZEBRA_RIP_VERSION_BOTH,
};



/*!
    \brief Structure describing the Zebra route entry
*/
typedef struct _IFX_ZEBRA_ROUTE_ENTRY {
    unsigned long address; /*!< Address */
    unsigned long netmask; /*!< Netmask */
    unsigned long gateway; /*!< Gateway */
    unsigned long metric; /*!< metric */
    char outIfName[IFX_ZEBRA_LENGTH_IFNAME+1]; /*!< outgoing interface name */
} IFX_ZEBRA_ROUTE_ENTRY, *PIFX_ZEBRA_ROUTE_ENTRY;



/*!
    \brief Structure describing the RIP interface information
*/
typedef struct _IFX_ZEBRA_RIP_IF_INFO {
    IFX_SINGLE_LIST    list; /*!< Single List */
    int    ifindex; /*!< Interface index */
    bool    enable; /*!< Enable */
    int    ver_send; /*!< version send */
    int    ver_recv; /*!< version recive */
    struct _auth {
        bool enable; /*!< Enable */
        int type; /*!< Type */
        char key[IFX_ZEBRA_RIP2_LENGTH_KEY+1]; /*!< Key */
    } rip2_auth; 
} IFX_ZEBRA_RIP_IF_INFO, *PIFX_ZEBRA_RIP_IF_INFO;


/*!
    \brief Structure describing the Zebra config 
*/
typedef struct _IFX_ZEBRA_CONFIG {
    struct _rip
    {
        bool        enable; /*!< Enable */
        IFX_SINGLE_LIST    if_list;  /*!< single list that store all interface information */ 
    } rip; 
} IFX_ZEBRA_CONFIG, *PIFX_ZEBRA_CONFIG;




/*! \fn void *ifx_zebra_create_handle(int flag, PIFX_ZEBRA_CONFIG pOrigCfg, void *reserved)
    \brief This function create a handle for Zebra
    \param[in] flag
    \param[in] pOrigCfg
    \param[in] reserved
    \return 
 */
void *ifx_zebra_create_handle(int flag, PIFX_ZEBRA_CONFIG pOrigCfg, void *reserved);

/*! \fn int ifx_zebra_rip_add_interface_by_ifindex(void *hHandle, int ifindex)
    \brief This function adds interface by interface index
    \param[in] hHandle
    \param[in] ifindex
    \return
 */
int ifx_zebra_rip_add_interface_by_ifindex(void *hHandle, int ifindex);

/*! \fn int ifx_zebra_rip_remove_interface_by_ifindex(void *hHandle, int ifindex)
    \brief This function removes interface by interface index
    \param[in] hHandle
    \param[in] ifindex
    \return
 */
int ifx_zebra_rip_remove_interface_by_ifindex(void *hHandle, int ifindex);

/*! \fn int ifx_zebra_rip_start(void *hHandle)
    \brief This function starts Zebra Rip
    \param[in] hHandle
    \param[in] ifindex
    \return
 */
int ifx_zebra_rip_start(void *hHandle);

/*! \fn int ifx_zebra_rip_stop(void *hHandle)
    \brief This function stops Zebra Rip
    \param[in] hHandle
    \return
 */
int ifx_zebra_rip_stop(void *hHandle);

/*! \fn int ifx_zebra_set_rip_enable_by_ifindex(void *hHandle, int ifindex, bool bEnable)
    \brief This function enables RIP by interface index 
    \param[in] hHandle
    \param[in] ifindex
    \param[in] bEnable
    \return
 */
int ifx_zebra_set_rip_enable_by_ifindex(void *hHandle, int ifindex, bool bEnable);

/*! \fn int ifx_zebra_get_rip_enable_by_ifindex(void *hHandle, int ifindex, bool *pbEnable)
    \brief This function return RIP enable value of the given interface
    \param[in] hHandle
    \param[in] ifindex
    \param[in] pbEnable
    \return
 */
int ifx_zebra_get_rip_enable_by_ifindex(void *hHandle, int ifindex, bool *pbEnable);

/*! \fn int ifx_zebra_set_rip_send_version_by_ifindex(void *hHandle, int ifindex, int iVersion)
    \brief This function sets RIP send version from given interface index 
    \param[in] hHandle
    \param[in] ifindex
    \param[in] iVersion
    \return
 */
int ifx_zebra_set_rip_send_version_by_ifindex(void *hHandle, int ifindex, int iVersion);

/*! \fn int ifx_zebra_get_rip_send_version_by_ifindex(void *hHandle, int ifindex, int *piVersion)
    \brief This function returns RIP send version from given interface index
    \param[in] hHandle
    \param[in] ifindex
    \param[in] piVersion
    \return
 */
int ifx_zebra_get_rip_send_version_by_ifindex(void *hHandle, int ifindex, int *piVersion);

/*! \fn int ifx_zebra_set_rip_recv_version_by_ifindex(void *hHandle, int ifindex, int iVersion)
    \brief This function sets RIP receive version from given interface index
    \param[in] hHandle
    \param[in] ifindex
    \param[in] piVersion
    \return
 */
int ifx_zebra_set_rip_recv_version_by_ifindex(void *hHandle, int ifindex, int iVersion);

/*! \fn int ifx_zebra_get_rip_recv_version_by_ifindex(void *hHandle, int ifindex, int *piVersion)
    \brief This function returns RIP receive version from given interface index
    \param[in] hHandle
    \param[in] ifindex
    \param[in] piVersion
    \return
 */
int ifx_zebra_get_rip_recv_version_by_ifindex(void *hHandle, int ifindex, int *piVersion);

/*! \fn int ifx_zebra_set_rip_enable_rip2_auth_by_ifindex(void *hHandle, int ifindex, bool bEnable)
    \brief This function sets RIP2 authentication enable value from given interface index 
    \param[in] hHandle
    \param[in] ifindex
    \param[in] bEnable
    \return
 */
int ifx_zebra_set_rip_enable_rip2_auth_by_ifindex(void *hHandle, int ifindex, bool bEnable);

/*! \fn int ifx_zebra_get_rip_enable_rip2_auth_by_ifindex(void *hHandle, int ifindex, bool *pbEnable)
    \brief This function returns RIP2 authentication enable value from given interface index
    \param[in] hHandle
    \param[in] ifindex
    \param[in] pbEnable
    \return
 */
int ifx_zebra_get_rip_enable_rip2_auth_by_ifindex(void *hHandle, int ifindex, bool *pbEnable);

/*! \fn int ifx_zebra_set_rip_auth_type_and_key_by_ifindex(void *hHandle, int ifindex, int iType, char *pKey)
    \brief This function sets RIP authentication type and key from interface index
    \param[in] hHandle
    \param[in] ifindex
    \param[in] iType
    \param[in] pKey
    \return
 */
int ifx_zebra_set_rip_auth_type_and_key_by_ifindex(void *hHandle, int ifindex, int iType, char *pKey);

/*! \fn int ifx_zebra_get_rip_auth_type_and_key_by_ifindex(void *hHandle, int ifindex, int *piType, char *pKey)
    \brief This function returns RIP authentication type and key from interface index
    \param[in] hHandle
    \param[in] ifindex
    \param[in] piType
    \param[in] pKey
    \return
 */
int ifx_zebra_get_rip_auth_type_and_key_by_ifindex(void *hHandle, int ifindex, int *piType, char *pKey);

/*! \fn int ifx_zebra_get_dynamic_routing_table(void *hHandle, PIFX_ZEBRA_ROUTE_ENTRY pEntryBuf, int *iEntries)
    \brief This function returns dynamic routing table 
    \param[in] hHandle
    \param[in] pEntryBuf
    \param[in] iEntries
    \return
*/
int ifx_zebra_get_dynamic_routing_table(void *hHandle, PIFX_ZEBRA_ROUTE_ENTRY pEntryBuf, int *iEntries);



#endif /* _IFX_ZEBRA_H_ */
