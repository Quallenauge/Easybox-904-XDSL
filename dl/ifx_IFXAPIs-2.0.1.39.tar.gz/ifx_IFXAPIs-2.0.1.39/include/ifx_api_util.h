#ifndef __IFX_API_UTIL_H
#define __IFX_API_UTIL_H
#include "ifx_common.h"


/*! \fn int32 ifx_get_IID(IFX_ID *passed_iid, char8 *distinct_param)
    \brief This function is called for allocating a new IFX Id for any new object instance addition. The function gets a new CpeId and also invokes IFX_ALLOC_MEID to get the ME specific identifier . It is mandatory to provide parent identifier information to this function.
	\param[in] passed_iid Ifx iid containing parentCpeId, parentSectionName,and sectionName. The TR-069 Id and CpeId of child comes filled back, upon success.
	\param[in]  distinct_param  Any Distinct Section Parameter name within this section of object. This is an optional argument and can be passed as NULL, wherever not needed
	\return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_IID(IFX_ID *passed_iid, char8 *distinct_param);

/*! \fn ifx_get_IID_Without_TR69(IFX_ID *passed_iid, char8 *distinct_param)
    \brief  This function fetches only the Instance ID of the object instance and does not fetch the TR69 ID
	\param[in] passed_iid
	\param[in] distinct_param
   	\return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_get_IID_Without_TR69(IFX_ID *passed_iid, char8 *distinct_param);

/*! \fn int32 build_route_command(char8 *ipaddr, char8 *netmask, char8 *gw, char8 *iface, int32 metric, int32 type, char8 *sCommand, char8 *op_type)
    \brief  This function takes the arguments required to build an Add command for a Route,
            and returns the command built
	\param[in] ipaddr
	\param[in] netmask
	\param[in] gw
	\param[in] iface
	\param[in] metric
	\param[in] type
	\param[in] sCommand
	\param op_type
   	\return BUILD_SUCCESS / BUILD_FAILURE
*/

int32 build_route_command(char8 *ipaddr, char8 *netmask, char8 *gw, char8 *iface, int32 metric, int32 type, char8 *sCommand, char8 *op_type);


/*! \fn int32  ifx_copy_file(char8 *src_file, char8 *dst_file)
    	 \brief This function does copy of source file to destination file.
	\param[in] src_file Source file that is getting copied.
	\param[in]  dst_file Destination File name where source will get copied
	\return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_copy_file(char8 *src_file, char8 *dst_file);

/*! \fn int32 ifx_get_maxLeases(struct in_addr start_ip, struct in_addr end_ip, int *maxLeases)
     \brief This function takes the arguments required to build an Delete command for a Route,
            and returns the command built
     \param[in] start_ip
     \param[in] end_ip
     \param[in] maxLeases
     \return IFX_SUCCESS / IFX_FAILURE

*/

int32 ifx_get_maxLeases(struct in_addr start_ip, struct in_addr end_ip, int *maxLeases);

/*! \fn int32 ifx_fill_ArrayFvp_FName(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, char8 *pData[])
     \brief    This function fills the array FVP field name
	\param[in]  arrayFvp[]
	\param[out]  arrayFvp[]
	\param[in]  start_index
	\param[in]  nDataCount
	\param[in]  pData[]
	\return IFX_SUCCESS / IFX_FAILURE

*/
int32 ifx_fill_ArrayFvp_FName(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, char8 *pData[]);

/*! \fn int32 ifx_fill_ArrayFvp_strValues(IFX_NAME_VALUE_PAIR array_fvp[], int32 start_index, int32 nDataCount, char8 *pData, ...)
    \brief This function fills string values into array FVP 
	\param[in] array_fvp[]
	\param[out] array_fvp[]
	\param[in] start_index
	\param[in] nDataCount
	\param[in] pData
	\return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_fill_ArrayFvp_strValues(IFX_NAME_VALUE_PAIR array_fvp[], int32 start_index, int32 nDataCount, char8 *pData, ...);

/*! \fn int32 ifx_fill_ArrayFvp_intValues(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, int32 *pData, ...)
    \brief  This function fills integer values to array FVP
	\param[in] arrayFvp[]
	\param[out] arrayFvp[]
	\param[in] start_index
	\param[in] nDataCount
	\param[in] pData
	\return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_fill_ArrayFvp_intValues(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, int32 *pData, ...);

/*! \fn int32 ifx_get_iid_from_ap_name(char8 ap_name[], IFX_ID *iid)
	\brief This function will search for the pattern _ap_name=input_ap_name in wlan_main section
               and return the cpeid and pcpeid of the found instance
	\param[in] ap_name[]
	\param[in] iid
	\return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_get_iid_from_ap_name(char8 ap_name[], IFX_ID *iid);

/*! \fn int32 ifx_get_iid_from_ssid(char8 ssid[], IFX_ID *iid)
	\brief This function will search for the pattern _ssid=input_ssid in wlan_main section
               and return the cpeid and pcpeid of the found instance
	\param[in] ssid[]
	\param[in] iid
	\return IFX_SUCCESS / IFX_FAILURE
*/


int32 ifx_get_iid_from_ssid(char8 ssid[], IFX_ID *iid);

/*! \fn int32 ifx_fill_ArrayFvp_uintValues(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, uint32 *pData, ...)
	\brief  This function fills the unsigned integer values into array FVP
	\param[in] arrayFvp[]
	\param[out] arrayFvp[]
	\param[in] start_index
	\param[in] nDataCount
	\param[in] pData
	\return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_fill_ArrayFvp_uintValues(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, uint32 *pData, ...);


/*! \fn int32 ifx_fill_uintValues_ArrayFvp(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, uint32 *pData, ...)
     	\brief  This function gets unsigned integer values from array FVP
	\param[in] arrayFvp[]
	\param[out] arrayFvp[]
	\param[in]  start_index
	\param[in] nDataCount
	\param[in] pData
	\return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_fill_uintValues_ArrayFvp(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, uint32 *pData, ...);


/*! \fn int32 ifx_fill_intValues_ArrayFvp(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, int32 *pData, ...)
	\brief  This function gets integer values from array FVP
	\param[in] arrayFvp[]
	\param[in]  start_index
	\param[in] nDataCount
	\param[in] pData
	\param[out] pData
	\return IFX_SUCCESS / IFX_FAILURE
*/

int32 ifx_fill_intValues_ArrayFvp(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, int32 *pData, ...);

/*! \fn int32 ifx_fill_boolValues_ArrayFvp(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, uchar8 *pData, ...)
	\brief  This function gets bool values from array FVP
	\param[in] arrayFvp[]
	\param[in]  start_index
	\param[in] nDataCount
	\param[in] pData
	\param[out] pData
	\return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_fill_boolValues_ArrayFvp(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, uchar8 *pData, ...);

/*! \fn int32 ifx_fill_ArrayFvp_boolValues(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, uchar8 *pData, ...);
	\brief  This function fills bool values into array FVP
	\param[in] arrayFvp[]
	\param[out] arrayFvp[]
	\param[in]  start_index
	\param[in] nDataCount
	\param[in] pData
	\return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_fill_ArrayFvp_boolValues(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, uchar8 *pData, ...);

/*! \fn int32 ifx_fill_strValues_ArrayFvp(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, char8 *pData, ...)
	\brief  This function gets string values from aaray FVP
	\param[in] arrayFvp[]
	\param[in]  start_index
	\param[in] nDataCount
	\param[in] pData
	\param[out] pData
	\return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_fill_strValues_ArrayFvp(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, char8 *pData, ...);

/*! \fn int32 ifx_get_another_fvp_from_dist_fvp(char8 *secName, char8 *fName, char8 *fValue, char8 *fRetName, char8 *fRetValue, uint32 flags)	
	\brief  This function fetches a field value from a section whose distinct field is given as input
	\param[in] secName
	\param[in]  fName
	\param[in] fValue
	\param[in] fRetName
	\param[in] fRetValue
	\param[out] fRetValue
	\param[in] flags
	\return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_check_unique_fvp_for_qos_iface(IFX_MAPI_QoS_Interface_Type mode,char8 *fName, char8 *fValue, char8 *fRetName, char8 *fRetValue,uint32 flags);
int32 ifx_get_another_fvp_from_dist_fvp(char8 *secName, char8 *fName, char8 *fValue, char8 *fRetName, char8 *fRetValue, uint32 flags);

/*! \fn int32 ifx_modify_n_reorder_fvp(char8 *secName, char8 *prefix, char8 *fName, char8 *oldValue, char8 *newValue, uint32 flags, int32 count)
	\brief This function modifies the value of field fName, of the instance matching oldValue, to newValue.
               Since the values of field fName are unique within the section secName, the function also
               modifies values of fName for other entries greater than or equal to the lower of the old and new values,
               and less than the larger of the old and new values.
               This function supports only DELETE and MODIFY operations
	\param[in] secName
	\param[in] prefix
	\param[in]  fName
	\param[in] oldValue
	\param[in] newValue
	\param[in] flags
	\param[in] count
	\return IFX_SUCCESS / IFX_FAILURE
*/
int32 ifx_modify_n_reorder_fvp(char8 *secName, char8 *prefix, char8 *fName, char8 *oldValue, char8 *newValue, uint32 flags);

int32 ifx_modify_n_reorder_fvp_queue(char8 *secName, char8 *prefix, char8 *fName, char8 *oldValue, char8 *newValue, uint32 flags,IFX_MAPI_QoS_Interface_Type qIfType);

/*! \fn void ifx_make_canonical_key(char8 *)
	\brief  This function creates a canonical key from the input key
	\return IFX_SUCCESS / IFX_FAILURE
*/
void ifx_make_canonical_key(char8 *key);
#endif //__IFX_API_UTIL_H
