/* ============================================================================
 * Copyright (C) 2004 - Infineon Technologies.
 *
 * All rights reserved.
 * ============================================================================
 *
 * ============================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ============================================================================
 *
 * Revision History:
 *      - 2004/07/14, MarsLin
 *         init version
 *
 * ============================================================================
 */

/*! \file ifx_definition.h 
    \brief  This file contains macro definitions used by the component Zebra
*/


#ifndef _IFX_DEFINITION_H_
#define _IFX_DEFINITION_H_

/* =============================================================================
 * TYPE RELATED DEFINITION
 * =============================================================================
 */

#ifndef bool

/*! \brief typedef unsigned character variable
 */
typedef unsigned char    bool;
#endif

#ifndef TRUE
/*! \def TRUE
    \brief  True
 */
#define TRUE    1
#endif

#ifndef FALSE
/*! \def FALSE
    \brief  False
 */
#define FALSE   0
#endif

/* =============================================================================
 * RETURN VALUE DEFINITION
 * =============================================================================
 */


/*! \def IFX_RET_OK  
    \brief  Return value ok
 */
#define IFX_RET_OK                  				0

/*! \def IFX_RET_ERR                 
    \brief  Return value error
 */
#define IFX_RET_ERR                 				-1

/*! \def IFX_RET_ERR_RESTORE_WRONG_FORMAT
    \brief  Return value error restore wrong format
 */
#define IFX_RET_ERR_RESTORE_WRONG_FORMAT			-2

/*! \def IFX_RET_ERR_ALLOC_MEM       
    \brief  Return value error allocate memory
 */
#define IFX_RET_ERR_ALLOC_MEM       				-3

/*! \def IFX_RET_ERR_INVALID_VALUE   		
    \brief  Return value error invalid value
 */
#define IFX_RET_ERR_INVALID_VALUE   				-4

/*! \def IFX_RET_ERR_BUF_TOO_SMALL   
    \brief  Return value error buffer too small
 */
#define IFX_RET_ERR_BUF_TOO_SMALL   				-5


/* =============================================================================
 * RETURN VALUE FOR CFG BUF RESTORE/SAVE
 * =============================================================================
 */

/*! \def IFX_CFGBUF_RESTORE_RET_NO_DATA		
    \brief  Return value for CFG buffer return no data
 */
#define IFX_CFGBUF_RESTORE_RET_NO_DATA				-1

/*! \def IFX_CFGBUF_RESTORE_RET_BUF_TOO_SMALL
    \brief  Return value for CFG buffer return buffer too small
 */
#define IFX_CFGBUF_RESTORE_RET_BUF_TOO_SMALL		-2

/*! \def IFX_CFGBUF_SAVE_RET_NOT_ENOUTH_SPACE
    \brief  Return value for CFG buffer return not enough space
 */
#define IFX_CFGBUF_SAVE_RET_NOT_ENOUTH_SPACE		-3


/* =============================================================================
 * PHYSICAL RELATED DEFINITION
 * =============================================================================
 */

/*! \def IFX_HARDWARE_MAX_ATM_IF          
    \brief  Maximum ATM hardware interfaces
 */
#define IFX_HARDWARE_MAX_ATM_IF          1

/*! \def IFX_HARDWARE_MAX_ETHER_IF        
    \brief  Maximum ethernet hardware interfaces
 */
#define IFX_HARDWARE_MAX_ETHER_IF        1

/*! \def IFX_HARDWARE_MAX_WIRELESS_IF     
    \brief  Maximum wireless hardware interfaces
 */
#define IFX_HARDWARE_MAX_WIRELESS_IF     1

/*! \def IFX_HARDWARE_MAX_USB_IF          
    \brief  Maximum USB hardware interfaces
 */
#define IFX_HARDWARE_MAX_USB_IF          1

/*! \def IFX_HARDWARE_MAX_INTERFACE              
    \brief  
 */
#define IFX_HARDWARE_MAX_INTERFACE              \
    (                                           \
        IFX_HARDWARE_MAX_ATM_IF          +      \
        IFX_HARDWARE_MAX_ETHER_IF        +      \
        IFX_HARDWARE_MAX_WIRELESS_IF     +      \
        IFX_HARDWARE_MAX_USB_IF                 \
    )

/* !\brief  enumerations for hardware interface types */
enum {
    IFX_HARDWARE_IF_TYPE_ATM = 0,
    IFX_HARDWARE_IF_TYPE_ETHER,
    IFX_HARDWARE_IF_TYPE_WIRELESS,
    IFX_HARDWARE_IF_TYPE_USB,
};

/* =============================================================================
 * COMPONENT API RELATED DEFINITION
 * =============================================================================
 */

/* Flags definition */

/*! \def IFX_COMPAPI_FLAG_NO_CMPD        
    \brief  Macro for no CMP daemon
 */
#define IFX_COMPAPI_FLAG_NO_CMPD        0    /* without C.M.P daemon */

/*! \def IFX_COMPAPI_FLAG_CMPD_INIT      
    \brief  CMP daemon initialization without restoration configuration
 */
#define IFX_COMPAPI_FLAG_CMPD_INIT      1    /* C.M.P init without restoration configuration */

/*! \def  IFX_COMPAPI_FLAG_CMPD_RESTORE   
    \brief  MP daemon initialization with restoration configuration
 */
#define IFX_COMPAPI_FLAG_CMPD_RESTORE   2    /* C.M.P init with restoration configuration */


/* =============================================================================
 * CONFIGURATION RELATED DEFINITION
 * =============================================================================
 */

/* Length definition */

/*! \def IFX_LENGTH_IFNAME       
    \brief  Interface name length
 */
#define IFX_LENGTH_IFNAME       10

/*! \def IFX_LENGTH_USERNAME     
    \brief  Username Length
 */
#define IFX_LENGTH_USERNAME     100

/*! \def IFX_LENGTH_PASSWORD     
    \brief  Password Length
 */
#define IFX_LENGTH_PASSWORD     100

#endif /* _IFX_DEFINITION_H_ */
