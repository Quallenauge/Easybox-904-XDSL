//510251:sumedh Modified to add support for ALGs

#ifndef _IFX_ALG_COMMON_H_
#define _IFX_ALG_COMMON_H_

/*! \file ifx_alg.h
    \brief This header file contains macros, structures and function declarations for ALGs
*/


/*!\def SUCCESS
   \brief Success
*/
#define SUCCESS 			0

/*!\def SET_FLAG
   \brief Enble the flag
*/
#define SET_FLAG 			1

/*!\def RESET_FLAG
   \brief reset the flag
*/
#define RESET_FLAG			0



/*!\def DEFAULT_RTSP_PORT
   \brief Default RTSP port
*/
#define DEFAULT_RTSP_PORT		554

/*!\def DEFAULT_SIP_PORT
   \brief Default SIP port
*/
#define DEFAULT_SIP_PORT		5060

/*!\def PROTO_RTSP
   \brief Protocal as RTSP
*/
#define PROTO_RTSP			1

/*!\def PROTO_SIP
   \brief Protocal as SIP 
*/
#define PROTO_SIP			2


/*!\def PROTO_NETMEETING
   \brief Protocal as Netmeeting
*/
#define PROTO_NETMEETING	3

/*!\def PROTO_IPSEC
   \brief Protocal as IPSec
*/
#define PROTO_IPSEC			4

/*!\def PROTO_FTP
   \brief Protocal as FTP
*/
#define PROTO_FTP			5


/*!\def PROTO_PPTP
   \brief Protocal as PPTP
*/
#define PROTO_PPTP			6


/*!\def ADD_RULE
   \brief Addition of a rule
*/
#define ADD_RULE			1

/*!\def DELETE_RULE
   \brief Deletion of a rule 
*/
#define DELETE_RULE			2

/*!\def NAT_ENABLE
   \brief NAT Enabled
*/
#define NAT_ENABLE 			1

/*!\def NAT_DISABLE
   \brief NAT disabled
*/
#define NAT_DISABLE 			2

/*!\def NAT_DONTCARE
   \brief NAT Dont care
*/
#define NAT_DONTCARE			0

/*!\def ENABLE
   \brief Enable
*/
#define ENABLE 				1

/*!\def DISABLE
   \brief Disable
*/
#define DISABLE 			2

/*!\def FORWARD
   \brief Forward 
*/
#define FORWARD				1

/*!\def INPUT
   \brief Input
*/
#define INPUT				2

/*!\def OUTPUT
   \brief Output
*/
#define OUTPUT				3

/*!\def NAT
   \brief NAT
*/
#define NAT				4

/*!\def DST_PORTS
   \brief DST ports
*/
#define DST_PORTS			1

/*!\def SRC_PORTS
   \brief SRC ports
*/
#define SRC_PORTS			2

/*!\def BOTH_PORTS
   \brief DST and SRS ports
*/
#define BOTH_PORTS			3

/*!\def STATE_NEW_EST
   \brief New state established
*/
#define STATE_NEW_EST		"NEW,ESTABLISHED"

/*!\def STATE_EST
   \brief state established
*/
#define STATE_EST			"ESTABLISHED"

/*!\def STATE_NEW_REL
   \brief New state releted
*/
#define STATE_NEW_REL		"NEW,RELATED"

/*!\def STATE_EST_REL
   \brief state Established and Related
*/
#define STATE_EST_REL		"ESTABLISHED,RELATED"


/*!\def STATE_NEW_EST_REL
   \brief New state Established and Related
*/
#define STATE_NEW_EST_REL	"NEW,ESTABLISHED,RELATED"


/*!\def RTSP_PORT_LIST
   \brief RTSP port list 
*/
#define RTSP_PORT_LIST			"554"

/*!\def NETMEETING_PORT_LIST
   \brief Netmeeting port list
*/
#define NETMEETING_PORT_LIST	"1720,1731,1503,389,522"

/*!\def IPSEC_PORT_LIST
   \brief IPSec port list
*/
#define IPSEC_PORT_LIST			"500,4500"

/*!\def FTP_PORT_LIST
   \brief FTP port list
*/
#define FTP_PORT_LIST			"21"

/*!\def PPTP_PORT_LIST
   \brief PPTP port list
*/
#define PPTP_PORT_LIST			"1723"

/*!\def DEFAULT_RTSP_PORT
   \brief Default RTSP port  
*/
#define DEFAULT_RTSP_PORT		554

/*!\def DEFAULT_SIP_PORT
   \brief Default SIP port
*/
#define DEFAULT_SIP_PORT		5060

/*!\def DEFAULT_IPSEC_PORT
   \brief default IPSec port
*/
#define DEFAULT_IPSEC_PORT		500

/*!\def DEFAULT_NETMEETING_PORT
   \brief default netmeeting port
*/
#define DEFAULT_NETMEETING_PORT		1720

/*!\def DEFAULT_FTP_PORT
   \brief  Default FTP port
*/
#define DEFAULT_FTP_PORT		21

/*!\def DEFAULT_PPTP_PORT
   \brief  Default PPTP port
*/
#define DEFAULT_PPTP_PORT		1723

/*!\def ALG_FORWARD_CHAIN
   \brief ALG forward chain
*/
#define ALG_FORWARD_CHAIN		"IFX_FW_ALGS"

/*!\def ALG_INPUT_CHAIN
   \brief ALG input chain
*/
#define ALG_INPUT_CHAIN			"IFX_INPUT_ALGS"

/*!\def ALG_OUTPUT_CHAIN
   \brief ALG output chain
*/
#define ALG_OUTPUT_CHAIN		"IFX_OUTPUT_ALGS"

/*!\def ALG_NAT_CHAIN
   \brief ALG NAT chain
*/
#define ALG_NAT_CHAIN			"IFX_NAT_ALGS"
 

/*! \brief enumeration for ALG Control Protocol
*/

enum AlgControlProtocol
{
	IP_PROTO_TCP=1, /*!< TBD*/
	IP_PROTO_UDP, /*!< TBD*/
	IP_PROTO_TCP_UDP, /*!< TBD*/
	IP_PROTO_ESP, /*!< TBD*/
	IP_PROTO_AH, /*!< TBD*/
	IP_PROTO_GRE /*!< TBD*/
};



/*!
   \brief extern integer type function Enables protocol specific ALG and adds corresponding nodes
   \param[in] protocol name, ip protocol, port number, lan interface name, wan interface name, NAT flag, bidirectional flag	
   \return returns success on enable
*/
extern	int ifx_enable_alg(int ,int ,int ,char *,char *, int , int );


/*!
   \brief integer type function Disable protocol specific ALG and delete all corresponding nodes from list
   \param[in] protocol name, ip protocol, port number, lan interface name, wan interface name, NAT flag, bidirectional flag
   \return returns success on disable 
*/
int ifx_disable_alg(int ,int ,int ,char *,char *,int );


/*!
   \brief integer type function 
   \param[in] application name  
   \return application alg protocol
*/
int ifx_find_app_proto(char *);


/*!
   \brief integer type function 
   \param[in] first_init
   \return returns success on init
*/
int ifx_alg_app_init(int first_init);

#endif /* IFX_ALG_COMMON_H_ */
