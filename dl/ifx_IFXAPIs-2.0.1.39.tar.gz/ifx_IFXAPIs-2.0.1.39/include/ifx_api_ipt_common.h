/* ============================================================================
 * Copyright (C) 2004 - Infineon Technologies.
 *
 * All rights reserved.
 * ============================================================================
 *
 * ============================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ============================================================================
 *
 * Revision History:
 *      - 2004/07/20, TC Chen
 *         init version
 *      - 2005/10/25, Sumedh ::[ 510251:sumedh Support for DoS Attacks, ALGs, QoS, Policy based Routing ]
 *	- 2006/04/04, Sumedh ::[ 604041:sumedh Parental Control feature added (Modified MAC Filter)
 *
 * ============================================================================
 */

/*
 * ===========================================================================
 *                           INCLUDE FILES
 * ===========================================================================
 */

/*! \file ifx_api_ipt_common.h
     \brief This file defined macros and strutures used for iptables rule configuration
*/


#ifndef _IFX_API_IPT_COMMON_H_
#define _IFX_API_IPT_COMMON_H_

#ifndef __be16
/*! \def __be16
    \brief This macro denotes shot integer data type
*/
#define __be16 short int
#endif

#include <linux/if_ether.h>
#include <netinet/in.h>
#include <linux/if.h>
#include <stdlib.h>

#include "ifx_common.h"
 
/*
 * ===========================================================================
 *                           GLOBAL DEFINITIONS
 * ===========================================================================
 */


/*! \def FIREWALL
    \brief set value of FIREWALL
*/
#define FIREWALL 0 /*!< value is 0. */


/*! \def NAPT
    \brief set value of NAPT
*/
#define NAPT 1  /*!< value is 1. */


/*! \def MANGLE
    \brief set value of MANGLE
*/
#define MANGLE 2	//510251:sumedh /*!< value is 2. */


#ifndef __u32
/*! \def __u32 
    \brief set value of __u32 
*/
#define __u32 unsigned long int
#endif

#ifndef bool
/*! \def bool
    \brief set value of bool
*/
#define bool int /*!< bool is int. */
#endif


/*! \def SET
    \brief set value of SET
*/
#define SET 0  /*!< value is 0. */


/*! \def GET
    \brief set value of GET
*/
#define GET 1 /*!< value is 1. */


/*! \def ADD 
    \brief set value of ADD 
*/
#define ADD         0  /*!< value is 0. */


/*! \def INSERT      
    \brief set value of INSERT      
*/
#define INSERT      1  /*!< value is 1. */


/*! \def DELETE      
    \brief set value of DELETE      
*/
#define DELETE      2  /*!< value is 2. */


/*! \def DELETE_ALL 
    \brief set value of DELETE_ALL 
*/
#define DELETE_ALL  3 /*!< value is 3. */


/*! \def POLICY      
    \brief set value of POLICY      
*/
#define POLICY      4  /*!< value is 4. */

/*! \def FALSE 
    \brief set value of FALSE 
*/
#define FALSE 0 /*!< value is 0. */

/*! \def TRUE 
    \brief set value of TRUE 
*/
#define TRUE 1 /*!< value is 1. */

/*! \def DISABLE 
    \brief set value of DISABLE 
*/
#define DISABLE 0 /*!< value is 0. */


/*! \def ENABLE 
    \brief set value of ENABLE 
*/
#define ENABLE 1 /*!< value is 1. */


/*! \def MAC_DISABLE 
    \brief set value of MAC_DISABLE 
*/
#define MAC_DISABLE 	0  /*!< value is 0. */

/*! \def MAC_DROP 
    \brief set value of MAC_DROP 
*/
#define MAC_DROP    	1  /*!< value is 1. */

/*! \def MAC_PERMIT
    \brief set value of MAC_PERMIT
*/
#define MAC_PERMIT    	2  /*!< value is 2. */


/*! \def PROTO_ALL  
    \brief set value of PROTO_ALL  
*/
#define PROTO_ALL  0x0  /*!< value is 0x0 enable to pass all protocol. */

/*! \def PROTO_ICMP 
    \brief set value of PROTO_ICMP 
*/
#define PROTO_ICMP 1  /*!< value is 1 enable ICMP protocol. */


/*! \def PROTO_TCP
    \brief set value of PROTO_TCP
*/
#define PROTO_TCP  6  /*!< value is 6 enable TCP protocol. */

/*! \def PROTO_UDP  
    \brief set value of PROTO_UDP  
*/
#define PROTO_UDP  17  /*!< value is 17 enable UDP protocol. */


/*! \def PROTO_ESP  
    \brief set value of PROTO_ESP  
*/
#define PROTO_ESP  50  /*!< value is 50 enable ESP. */


/*! \def PROTO_AH   
    \brief set value of PROTO_AH   
*/
#define PROTO_AH   51  /*!< value is 51 enable AH. */


/*! \def IF_WAN 
    \brief set value of IF_WAN 
*/
#define IF_WAN 	 0  /*!< value is 0 enable WAN. */


/*! \def IF_LAN   
    \brief set value of IF_LAN   
*/
#define IF_LAN   1  /*!< value is 1 enable LAN. */

 
/*! \def ACCEPT
    \brief set value of ACCEPT
*/
#define ACCEPT  0  /*!< value is 0. */


/*! \def DROP
    \brief set value of DROP
*/
#define DROP    1  /*!< value is 1. */


/*! \def RETURN 
    \brief set value of RETURN 
*/
#define RETURN  2 /*!< value is 2. */


/*
 * ============================================================================
 *                              STRUCTURES
 * ============================================================================
 */


/*!
    \brief Structure describing the ipt Rules.
*/


typedef struct __ifx_ipt_rule
{
    __u32 srcip;                  /*!< Source IP Address */
    unsigned short srcip_mask;    /*!< Source IP Mask */
    __u32 dstip;                  /*!< Destination IP Address */
    unsigned short dstip_mask;    /*!< Destination IP Mask */
    __u32 targetip;               /*!< Target IP Address */
    unsigned short srcport_start; /*!< Starting Source Port Number*/
    unsigned short srcport_end;   /*!< Ending Source Port Number */
    unsigned short dstport_start; /*!< Destination Port Start Number */
    unsigned short dstport_end;   /*!< Destination Port End Number */
    unsigned short targetport_start; /*!< Target Port Start Number */
    unsigned short targetport_end; /*!< Target Port End Number */
    unsigned short protocol;       /*!< Protocol */
    unsigned char MAC[ETH_ALEN];   /*!< MAC Address */
    char          inif[IFNAMSIZ];  /*!< Input Interface  */
    char          outif[IFNAMSIZ]; /*!< Output Interface */
    char	  diffserv[64]; 	//510251:sumedh (added for policy based routing) /*!< Differenciated Services */
    char	  route_oif[64]; 	//510251:sumedh (added for policy based routing) /*!< Route Output Interface */
    char	  route_continue; 	//510251:sumedh (added for policy based routing) /*!< continue tarversing rules */
	char		DAY[9];			//604041:Sumedh - Parental Control /*!< DAY */
	char		TIMESTART[6];	//604041:Sumedh - Parental Control /*!< START TIME */
	char		TIMEEND[6];		//604041:Sumedh - Parental Control /*!< END TIME */

}IFX_IPT_RULE, * P_IFX_IPT_RULE;


/*! \fn bool IFX_IPT_SET_SINGLE_RULE(int type, int operation ,char *ChainName, P_IFX_IPT_RULE rule,int target)
     \brief extern boolean function TODO
	\param[in] operation 
	\param[in]  *ChainName
	\param[out] rule
	\param[in] target
	\return TRUE / FALSE
*/
extern bool IFX_IPT_SET_SINGLE_RULE(int type, int operation ,char *ChainName, P_IFX_IPT_RULE rule,int target); /*!< this function set the rules for ipt*/

/*! \fn bool IFX_IPT_SET_RULE2(int type, int operation, char *ChainName, char *proto,char *target, char *cmdstr1, char *cmdstr2)
     \brief extern boolean function  TODO
	\param[in] type
	\param[in] *ChainName
	\param[in] *proto
	\param[in] *target
	\param[in] *cmdstr1
	\param[in] *cmdstr2
	\param[in] operation 
	
	\return TRUE / FALSE
*/
extern bool IFX_IPT_SET_RULE2(int type, int operation, char *ChainName, char *proto,char *target, char *cmdstr1, char *cmdstr2); /*!< this function set the rules for ipt*/


/*! \def STR_COMMAND
    \brief set value of STR_COMMAND
*/
#define STR_COMMAND	256 /*!< value is 256. */

#endif /* _IFX_API_IPT_COMMON_H_ */
