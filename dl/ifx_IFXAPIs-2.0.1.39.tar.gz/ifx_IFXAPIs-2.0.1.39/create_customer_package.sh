#!/bin/sh

if [ ! -n "$1" ] ; then
	echo "Usage : create_customer_package.sh SOURCE_PATH"
	exit 0
fi

#mv src/build.sh .
#rm -rf src/*
#mv build.sh src/
#mkdir -p lib
#rm -f include/*
#cp $1/include/*.h include/
#ln -s ../../../opensource/openssl-0.9.7e/include/openssl/ include/openssl
#cp $1/lib/* lib/

rm -f create_customer_package.sh
