
/*
** =============================================================================
** FILE NAME     : IFIN_Obj_API.c
** PROJECT       : TR69
** MODULES       : Object API
** DATE          : 11-08-2006
** AUTHOR        : TR69 team
** DESCRIPTION   :
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author      $Comment
**
** ============================================================================
*/



/* =============================================================================
**                                <INCLUDE FILES>
** =============================================================================
*/
#include "../common/ifx_common.h"
#include "ifx_api_include.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>

/* =============================================================================
**                              <LOCAL DEFINITIONS>
** =============================================================================
*/

#define IFX_MGMT_SERVER_SECTION                   "mgmt_server"
#define IFX_MGMT_SERVER_URL                       "acsurl"
#define IFX_MGMT_SERVER_USERNAME                  "acsuname"
#define IFX_MGMT_SERVER_PASSWORD                  "acspasswd"
#define IFX_MGMT_SERVER_PERIODICINFORMENABLE      "perinfena"
#define IFX_MGMT_SERVER_PERIODICINFORMINTERVAL    "perinfint"
#define IFX_MGMT_SERVER_PERIODICINFORMTIME        "perinftime"
#define IFX_MGMT_SERVER_PARAMETERKEY              "paramkey"
#define IFX_MGMT_SERVER_CONNECTIONREQUESTURL      "conrequrl"
#define IFX_MGMT_SERVER_CONNECTIONREQUESTUSERNAME "conrequname"
#define IFX_MGMT_SERVER_CONNECTIONREQUESTPASSWORD "conreqpasswd"
#define IFX_MGMT_SERVER_UPGRADESMANAGED           "upgsmanaged"

//TR-111 related parameters
#define IFX_MGMT_SERVER_UDPCONNREQADDRESS         "udpconrequrl"
#define IFX_MGMT_SERVER_UDPCONNREQADDRESSNOTIFYLIMIT    "udpconreqnotifylimit"
#define IFX_MGMT_SERVER_STUNENABLE                "stunenable"
#define IFX_MGMT_SERVER_STUNSERVERADDRESS         "stunserveripaddress"
#define IFX_MGMT_SERVER_STUNSERVERPORT            "stunserverport"
#define IFX_MGMT_SERVER_STUNUSERNAME              "stunusername"
#define IFX_MGMT_SERVER_STUNPASSWORD              "stunpasswd"
#define IFX_MGMT_SERVER_STUNMAXKEEPALIVEPERIOD    "stunmaxkeepalivetime"
#define IFX_MGMT_SERVER_STUNMINKEEPALIVEPERIOD    "stunminkeepalivetime"
#define IFX_MGMT_SERVER_STUNNATDETECTED           "natdetected"
#define IFX_MGMT_SERVER_MNGDEVICENOTIFYLIMIT      "mngdevnotifylimit"

#define IFX_DEVICE_INFO_SECTION                   "device_info"
#define IFX_DEVICE_INFO_MANUFACTURER              "manu"
#define IFX_DEVICE_INFO_MANUFACTUREROUI           "oui"
#define IFX_DEVICE_INFO_MODELNAME                 "modname"
#define IFX_DEVICE_INFO_DESCRIPTION               "desc"
#define IFX_DEVICE_INFO_PRODUCTCLASS              "prodclass"
#define IFX_DEVICE_INFO_SERIALNUMBER              "sernum"
#define IFX_DEVICE_INFO_HARDWAREVERSION           "hwver"
#define IFX_DEVICE_INFO_SOFTWAREVERSION           "swver"
#define IFX_DEVICE_INFO_MODEMFIRMWAREVERSION      "modfwver"
#define IFX_DEVICE_INFO_SPECVERSION               "specver"
#define IFX_DEVICE_INFO_PROVISIONINGCODE          "provcode"
#define IFX_DEVICE_INFO_UPTIME                    "uptime"
#define IFX_GATEWAY_INFO_SECTION                  "gwinfo"
#define IFX_GATEWAY_INFO_MANUFACTUREROUI          "oui"
#define IFX_GATEWAY_INFO_PRODUCTCLASS             "prodclass"
#define IFX_GATEWAY_INFO_SERIALNUMBER             "sernum"

#define IFX_DEVICE_INFO_SYSCONTACT                "syscontact"
#define IFX_DEVICE_INFO_SYSNAME                   "sysname"
#define IFX_DEVICE_INFO_SYSLOCATION               "syslocation"
#define IFX_DEVICE_INFO_SYSOBJECT_ID              "sysobjid"
#define IFX_DEVICE_INFO_SYSSERVICES               "sysservices"

#define IFX_GATEWAY_INFO_SECTION                  "gwinfo"
#define IFX_GATEWAY_INFO_MANUFACTUREROUI          "oui"
#define IFX_GATEWAY_INFO_PRODUCTCLASS             "prodclass"
#define IFX_GATEWAY_INFO_SERIALNUMBER             "sernum"

#define IFX_MANAGEABLE_DEVICE_SECTION             "manageable_device"
#define IFX_MANAGEABLE_DEVICE_SECTION_PREFIX      "ManagDev"
#define IFX_MANAGEABLE_DEVICE_MANUFACTUREROUI     "oui"
#define IFX_MANAGEABLE_DEVICE_PRODUCTCLASS        "prodclass"
#define IFX_MANAGEABLE_DEVICE_SERIALNUMBER        "sernum"
#define IFX_MANAGEABLE_DEVICE_IPADDR              "ipaddr"

#define IFX_DL_AUTH_SECTION                       "dl_auth"
#define IFX_DL_AUTH_USERNAME                      "uname"
#define IFX_DL_AUTH_PASSWORD                      "passwd"
#define IFX_DL_AUTH_REALM                         "realm"
#define IFX_DL_AUTH_NONCE                         "nonce"
#define IFX_DL_AUTH_URI                           "uri"
#define IFX_DL_AUTH_ALGO                          "algo"
#define IFX_DL_AUTH_CNONCE                        "cnonce"
#define IFX_DL_AUTH_OPAQUE                        "opaque"
#define IFX_DL_AUTH_QOP                           "qop"
#define IFX_DL_AUTH_NC                            "nc"
#define IFX_DL_AUTH_PROCESSCOOKIE                 "procookie"
#define IFX_DL_AUTH_FILETYPE                      "ftype"
#define IFX_DL_AUTH_FILENAME                      "fname"
#define IFX_DL_AUTH_COMMANDKEY                    "cmdkey"
#define IFX_DL_AUTH_STATUS                        "status"
#define IFX_DL_AUTH_STARTTIME                     "starttime"
#define IFX_DL_AUTH_ENDTIME                       "endtime"
#define IFX_DL_AUTH_FUTURETIME                    "futuretime"
#define IFX_DL_AUTH_SIZE                          "size"

#define IFX_TR69_AUTH_SECTION                     "tr69_auth"
#define IFX_TR69_AUTH_REALM                       "realm"
#define IFX_TR69_AUTH_NONCE                       "nonce"
#define IFX_TR69_AUTH_URI                         "uri"
#define IFX_TR69_AUTH_ALGO                        "algo"
#define IFX_TR69_AUTH_CNONCE                      "cnonce"
#define IFX_TR69_AUTH_OPAQUE                      "opaque"
#define IFX_TR69_AUTH_QOP                         "qop"
#define IFX_TR69_AUTH_NC                          "nc"

#define IFX_TR69_MISC_SECTION                     "tr69_misc"
#define IFX_TR69_MISC_AUTHACS                     "authacs"
#define IFX_TR69_MISC_AUTHTYPE                    "authtype"
#define IFX_TR69_MISC_EVENTCODE                   "event"
#define IFX_TR69_MISC_COMMANDKEY                  "cmdkey"
#define IFX_TR69_MISC_INCLUDEXML                  "incxml"
#define IFX_TR69_MISC_INCLUDESOAPACTION           "incsoapact"
#define IFX_TR69_MISC_ACSGETRPC                   "acsgetrpc"
#define IFX_TR69_MISC_BOOTSTRAP                   "bootstrap"
#define IFX_TR69_MISC_TR69ENABLE                  "tr69enable"
#define IFX_TR69_MISC_TR64ENABLE                  "tr64enable"
#define IFX_TR69_MISC_PREVIOUSTIME                "prevtime"

#define IFX_IPPING_DIAG_SECTION                   "ipping_diag"
#define IFX_IPPING_DIAG_DIAGSTATE                 "diagstate"
#define IFX_IPPING_DIAG_INTERFACE                 "interface"
#define IFX_IPPING_DIAG_HOST                      "host"
#define IFX_IPPING_DIAG_NUMREPEAT                 "numrepeat"
#define IFX_IPPING_DIAG_TIMEOUT                   "timeout"
#define IFX_IPPING_DIAG_DATASIZE                  "datasize"
#define IFX_IPPING_DIAG_DSCP                      "dscp"
#define IFX_IPPING_DIAG_SUCCESSCNT                "successcnt"
#define IFX_IPPING_DIAG_FAILURECNT                "failurecnt"
#define IFX_IPPING_DIAG_AVGRESPTIME               "avgresptime"
#define IFX_IPPING_DIAG_MINRESPTIME               "minresptime"
#define IFX_IPPING_DIAG_MAXRESPTIME               "maxresptime"


#define IFX_LAN_CONF_SECURITY_SECTION             "lanconf_security"
#define IFX_LAN_CONF_CONFPASSWORD                 "confPassword"
#define IFX_LAN_CONF_RESETPASSWORD                "resetPassword"

#define MAKE_PARAM_ELEMENT_TAG(tag_prefix, index, field, buf)  sprintf(buf, "%s_%d_%s", tag_prefix, index, field);

/* ORP - SHould be moved to ifx_amazon_cfg.h */
#define TAG_DHCP_OPTION                     "dhcp_opt"
#define PREFIX_DHCP_OPTION              "dhcp_opt"
#define TAG_LAN_MAIN                        "lan_main"
/* Should go with MAPI  dhcp_option.c file */
#define DHCP_OPTION_PARAM_COUNT   6
char8 *dhcp_opt_params[] = {"cpeId", "pcpeId", "ena", "req", "tag", "val"};
/* Would come from ifx_api_util.h . Placed here to resolve compilation errors */
int32 ifx_fill_ArrayFvp_FName(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, char8 *pData[]);
int32 ifx_fill_ArrayFvp_intValues(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, int32 *pData, ...);
int32 ifx_fill_ArrayFvp_strValues(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, char8 *pData, ...);


// #ifdef IFX_DBG
// #undef IFX_DBG
// #define IFX_DBG(fmt, args...)    
// #endif


/* =============================================================================
**                                <LOCAL TYPES>
** =============================================================================
*/


/* =============================================================================
**                                 <LOCAL DATA>
** =============================================================================
*/

/* =============================================================================
**                           <LOCAL FUNCTION PROTOTYPES>
** =============================================================================
*/


/* =============================================================================
**                               <LOCAL FUNCTIONS>
** =============================================================================
*/


/* =============================================================================
**                             <EXPORTED FUNCTIONS>
** =============================================================================
*/
extern int32 ifx_copy_file(char8 *src_file, char8 *dst_file);
extern int32 ifx_get_IID(IFX_ID *passed_iid, char8 *distinct_param);


int32 ifx_get_lan_conf_security(char8 *ConfPassword, char8 *ResetPassword)
{
    int32       iRtn = IFX_SUCCESS;
    char8       sVal[MAX_FILELINE_LEN];
    uint32      flags=IFX_F_GET_ANY;
    uint32      ulOutFlag;

    memset(sVal,'\0', MAX_FILELINE_LEN);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_LAN_CONF_SECURITY_SECTION,
        IFX_LAN_CONF_SECURITY_SECTION "_" IFX_LAN_CONF_CONFPASSWORD,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get LANConfigSec Conf Password !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }

    strcpy(ConfPassword,sVal);

    memset(sVal,'\0', MAX_FILELINE_LEN);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_LAN_CONF_SECURITY_SECTION,
        IFX_LAN_CONF_SECURITY_SECTION "_" IFX_LAN_CONF_RESETPASSWORD,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get LANConfigSec Reset Password !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }

    strcpy(ResetPassword,sVal);

    return IFX_SUCCESS;

    IFX_Handler:
        return iRtn;

}

int32 ifx_set_lan_conf_security(int32 operation,char8 *password,uint32 flags)
{
    int    count = 0, ret = IFX_SUCCESS;
    uint32 changed_fcount = 0;
    char8    buf[MAX_DATA_LEN];
    char8    sConfPassword[65]={0};
    char8    sResetPassword[65]={0};
    IFX_ID    iid;
    IFX_NAME_VALUE_PAIR array_fvp[MAX_FIELD_RANGE], *array_changed_fvp = NULL;

    memset(buf, 0, sizeof(buf));
    memset(&iid, 0, sizeof(iid));
    memset(array_fvp, 0, sizeof(array_fvp));


    /***  PROLOG BLOCK  ***/

    /* Append internal flags */
    if (operation == IFX_OP_DEL)
        flags |= IFX_F_DELETE;
    else if (operation == IFX_OP_MOD)
        flags |= IFX_F_MODIFY;
    else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
         flags |= IFX_F_INT_ADD;

    /********  VALIDATION BLOCK  ***********/
    /* For ops other than DELETE do the verification of input params */
    if (IFX_DELETE_F_NOT_SET(flags))
    {
        /*** Validation Checking Block ***/
        if(IFX_DONT_VALIDATE_F_NOT_SET(flags))
        {
            /* Do simple validation of pointer such as NULL */
            //IFX_VALIDATE_PTR(mgmt_server)
            /* Do simple validation of flags such as less than 0 */
            IFX_VALIDATE_FLAGS(flags)
        }
    }

    /*******  VALIDATION BLOCK END *********/

    /* Read the iid structure from rc.conf */
   //iid = mgmt_server->iid;
   //strcpy(iid.cpeId.secName, IFX_LAN_CONF_SECURITY_SECTION);
   if(ifx_get_iid_from_conf(&iid, FILE_RC_CONF, IFX_LAN_CONF_SECURITY_SECTION) != IFX_SUCCESS)
    {
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

   /********** Get the resetPassword from DB file **************/
    if(ifx_get_lan_conf_security(sConfPassword,sResetPassword) != IFX_SUCCESS)
    {
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    /*********** Name Value Formation As Per RC.CONF ****************/
    /* Build the API Specific name value pair */
    sprintf(array_fvp[0].fieldname, "%s_%s", IFX_LAN_CONF_SECURITY_SECTION, "cpeId");
    sprintf(array_fvp[0].value, "%d", iid.cpeId.Id);
    sprintf(array_fvp[1].fieldname, "%s_%s", IFX_LAN_CONF_SECURITY_SECTION, "pcpeId");
    sprintf(array_fvp[1].value, "%d", iid.pcpeId.Id);
    sprintf(array_fvp[2].fieldname, "%s_%s", IFX_LAN_CONF_SECURITY_SECTION, IFX_LAN_CONF_CONFPASSWORD);
    sprintf(array_fvp[2].value, "%s", password);
    sprintf(array_fvp[3].fieldname, "%s_%s", IFX_LAN_CONF_SECURITY_SECTION, IFX_LAN_CONF_RESETPASSWORD);
    sprintf(array_fvp[3].value, "%s", sResetPassword);
    count = 4;

    /***  PROLOG BLOCK END  ***/

    /**************** ACL CHECK BLOCK *****************/

    CHECK_ACL_RET(iid, count, array_fvp,
        changed_fcount, array_changed_fvp, flags, IFX_Handler)

    /**************** ACL CHECK BLOCK END *****************/

    /********* SYSTEM CONFIG FILE UPDATE BLOCK  **********/

    /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
    if (IFX_MODIFY_F_SET(flags))
    {
        //form_cfgdb_buf(buf, changed_fcount, array_changed_fvp);
        form_cfgdb_buf(buf, count, array_fvp);
    }
    else
    {
        form_cfgdb_buf(buf, count, array_fvp);
    }

    /* Backup rc.conf before proceeding with configuration */
    CHECKPOINT_RET(flags, FILE_RC_CONF, CHKPOINT_FILE, IFX_Handler)

    /* Update rc.conf */
    ret = ifx_SetObjData(FILE_RC_CONF, IFX_LAN_CONF_SECURITY_SECTION, flags, 1, buf);

    /* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
    if(ret != IFX_SUCCESS)
    {
        ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE, flags | IFX_F_INT_DONT_RESTART_SERVICES, IFX_Handler)
    }

    /********* SYSTEM CONFIG FILE UPDATE BLOCK END **********/

    /************ DEVICE CONFIGURATION BLOCK ***********/
    /************ DEVICE CONFIGURATION BLOCK END ***********/

    /**************** NOTIFICATION BLOCK ******************/

    /* Notify the Internal TR69 Stack */
    CHECK_N_SEND_NOTIFICATION (iid, changed_fcount, array_changed_fvp, flags, IFX_Handler)

    /**************** NOTIFICATION BLOCK ******************/

    /***************** EPILOG BLOCK **********************/
    ret = ifx_config_write(FILE_RC_CONF, flags);
    if(ret != IFX_SUCCESS)
    {
        ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE, flags | IFX_F_INT_DONT_RESTART_SERVICES, IFX_Handler)
    }
    /***************** EPILOG BLOCK END **********************/

IFX_Handler:
    IFX_MEM_FREE(array_changed_fvp)
    if(ret != IFX_SUCCESS)
        return ret;
    else
        return IFX_SUCCESS;
}



int32 ifx_set_mgmt_server(int32 operation, MGMT_SERVER *mgmt_server, uint32 flags)
{
    int    count = 0, ret = IFX_SUCCESS;
    uint32 changed_fcount = 0;
    char8    buf[MAX_DATA_LEN];
    IFX_ID    iid;
    IFX_NAME_VALUE_PAIR array_fvp[MAX_FIELD_RANGE], *array_changed_fvp = NULL;

    memset(buf, 0, sizeof(buf));
    memset(&iid, 0, sizeof(iid));
    memset(array_fvp, 0, sizeof(array_fvp));


    /***  PROLOG BLOCK  ***/

    /* Append internal flags */
    if (operation == IFX_OP_DEL)
        flags |= IFX_F_DELETE;
    else if (operation == IFX_OP_MOD)
        flags |= IFX_F_MODIFY;
    else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
         flags |= IFX_F_INT_ADD;

    /********  VALIDATION BLOCK  ***********/
    /* For ops other than DELETE do the verification of input params */
    if (IFX_DELETE_F_NOT_SET(flags))
    {
        /*** Validation Checking Block ***/
        if(IFX_DONT_VALIDATE_F_NOT_SET(flags))
        {
            /* Do simple validation of pointer such as NULL */
            IFX_VALIDATE_PTR(mgmt_server)
            /* Do simple validation of flags such as less than 0 */
            IFX_VALIDATE_FLAGS(flags)
        }
    }

    /*******  VALIDATION BLOCK END *********/

    /* Read the iid structure from rc.conf */
    iid = mgmt_server->iid;
    if(ifx_get_iid_from_conf(&iid, FILE_RC_CONF, IFX_MGMT_SERVER_SECTION) != IFX_SUCCESS)
    {
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    /*********** Name Value Formation As Per RC.CONF ****************/
    /* Build the API Specific name value pair */
    sprintf(array_fvp[0].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, "cpeId");
    sprintf(array_fvp[0].value, "%d", iid.cpeId.Id);
    sprintf(array_fvp[1].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, "pcpeId");
    sprintf(array_fvp[1].value, "%d", iid.pcpeId.Id);
    sprintf(array_fvp[2].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_URL);
    sprintf(array_fvp[2].value, "%s", mgmt_server->url);
    sprintf(array_fvp[3].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_USERNAME);
    sprintf(array_fvp[3].value, "%s", mgmt_server->uname);
    sprintf(array_fvp[4].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_PASSWORD);
    sprintf(array_fvp[4].value, "%s", mgmt_server->passwd);
    sprintf(array_fvp[5].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_PERIODICINFORMENABLE);
    sprintf(array_fvp[5].value, "%d", mgmt_server->period_inform_enable);
    sprintf(array_fvp[6].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_PERIODICINFORMINTERVAL);
    sprintf(array_fvp[6].value, "%u", mgmt_server->period_inform_interval);
    sprintf(array_fvp[7].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_PERIODICINFORMTIME);
    sprintf(array_fvp[7].value, "%u", mgmt_server->period_abs_inform_time);
    sprintf(array_fvp[8].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_PARAMETERKEY);
    sprintf(array_fvp[8].value, "%s", mgmt_server->parameter_key);
    sprintf(array_fvp[9].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_CONNECTIONREQUESTURL);
    sprintf(array_fvp[9].value, "%s", mgmt_server->conn_req_url);
    sprintf(array_fvp[10].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_CONNECTIONREQUESTUSERNAME);
    sprintf(array_fvp[10].value, "%s", mgmt_server->conn_req_uname);
    sprintf(array_fvp[11].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_CONNECTIONREQUESTPASSWORD);
    sprintf(array_fvp[11].value, "%s", mgmt_server->conn_req_passwd);
    sprintf(array_fvp[12].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_UPGRADESMANAGED);
    sprintf(array_fvp[12].value, "%d", mgmt_server->upgrades_managed);

    /*TR111 related parameters*/
    sprintf(array_fvp[13].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_UDPCONNREQADDRESS);
    sprintf(array_fvp[13].value, "%s", mgmt_server->udp_conn_req_url);
    sprintf(array_fvp[14].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_UDPCONNREQADDRESSNOTIFYLIMIT);
    sprintf(array_fvp[14].value, "%d", mgmt_server->udp_conn_req_address_notification_limit);
    sprintf(array_fvp[15].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_STUNENABLE);
    sprintf(array_fvp[15].value, "%d", mgmt_server->stun_enable);
    sprintf(array_fvp[16].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_STUNSERVERADDRESS);
    //sprintf(array_fvp[15].value, "%d", mgmt_server->stun_server_address);    
    strncpy(array_fvp[16].value,	inet_ntoa(mgmt_server->stun_server_address),
						(MAX_IP_ADDR_LEN));
    sprintf(array_fvp[17].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_STUNSERVERPORT);
    sprintf(array_fvp[17].value, "%d", mgmt_server->stun_server_port);
    sprintf(array_fvp[18].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_STUNUSERNAME);
    sprintf(array_fvp[18].value, "%s", mgmt_server->stun_server_uname);
    sprintf(array_fvp[19].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_STUNPASSWORD);
    sprintf(array_fvp[19].value, "%s", mgmt_server->stun_passwd);
    sprintf(array_fvp[20].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_STUNMAXKEEPALIVEPERIOD);
    sprintf(array_fvp[20].value, "%d", mgmt_server->stun_max_keep_alive_period);
    sprintf(array_fvp[21].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_STUNMINKEEPALIVEPERIOD);
    sprintf(array_fvp[21].value, "%d", mgmt_server->stun_min_keep_alive_period);
    sprintf(array_fvp[22].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_STUNNATDETECTED);
    sprintf(array_fvp[22].value, "%d", mgmt_server->nat_detected);
    sprintf(array_fvp[23].fieldname, "%s_%s", IFX_MGMT_SERVER_SECTION, IFX_MGMT_SERVER_MNGDEVICENOTIFYLIMIT);
    sprintf(array_fvp[23].value, "%d", mgmt_server->mngdevnotifylimit);



    count = 24;

    /***  PROLOG BLOCK END  ***/

    /**************** ACL CHECK BLOCK *****************/

    CHECK_ACL_RET(iid, count, array_fvp,
        changed_fcount, array_changed_fvp, flags, IFX_Handler)

    /**************** ACL CHECK BLOCK END *****************/

    /********* SYSTEM CONFIG FILE UPDATE BLOCK  **********/

    /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
    if (IFX_MODIFY_F_SET(flags))
    {
        //form_cfgdb_buf(buf, changed_fcount, array_changed_fvp);
        form_cfgdb_buf(buf, count, array_fvp);
    }
    else
    {
        form_cfgdb_buf(buf, count, array_fvp);
    }

    /* Backup rc.conf before proceeding with configuration */
    CHECKPOINT_RET(flags, FILE_RC_CONF, CHKPOINT_FILE, IFX_Handler)

    /* Update rc.conf */
	IFX_DBG("mgmt buf [%s]", buf);
    ret = ifx_SetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION, flags, 1, buf);

    /* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
    if(ret != IFX_SUCCESS)
    {
        ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE, flags | IFX_F_INT_DONT_RESTART_SERVICES, IFX_Handler)
	goto IFX_Handler;
    }

    /********* SYSTEM CONFIG FILE UPDATE BLOCK END **********/

    /************ DEVICE CONFIGURATION BLOCK ***********/
    /************ DEVICE CONFIGURATION BLOCK END ***********/

    /**************** NOTIFICATION BLOCK ******************/

    /* Notify the Internal TR69 Stack */
    CHECK_N_SEND_NOTIFICATION (iid, changed_fcount, array_changed_fvp, flags, IFX_Handler)

    /**************** NOTIFICATION BLOCK ******************/

    /***************** EPILOG BLOCK **********************/
    ret = ifx_config_write(FILE_RC_CONF, flags);
    if(ret != IFX_SUCCESS)
    {
        ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE, flags | IFX_F_INT_DONT_RESTART_SERVICES, IFX_Handler)
    }
    /***************** EPILOG BLOCK END **********************/
	system("echo mgmt server set done >> /tmp/t_log");

IFX_Handler:
    IFX_MEM_FREE(array_changed_fvp)
    if(ret != IFX_SUCCESS)
        return ret;
    else
        return IFX_SUCCESS;
}

int32 ifx_get_mgmt_server(MGMT_SERVER * mgmt_server, uint32 flags)
{
    int32       iRtn = IFX_SUCCESS;
    char8       sVal[MAX_FILELINE_LEN];
    uint32      ulOutFlag;
    MGMT_SERVER xMS;

    memset(&xMS, 0, sizeof(xMS));

    memset(sVal,'\0', MAX_FILELINE_LEN);
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_URL,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get URL !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_URL_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> URL len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xMS.url, sVal,MAX_URL_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_USERNAME,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get UserName !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_UNAME_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> UserName len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xMS.uname, sVal,MAX_UNAME_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_PASSWORD,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Password !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_PASSWORD_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> Password len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xMS.passwd, sVal,MAX_PASSWORD_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_PERIODICINFORMENABLE,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get PeriodicInformEnable !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xMS.period_inform_enable = atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_PERIODICINFORMINTERVAL,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get PeriodicInformInterval !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xMS.period_inform_interval = atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_PERIODICINFORMTIME,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get PeriodicInformTime !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xMS.period_abs_inform_time = atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_PARAMETERKEY,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get ParameterKey !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_PARAMETER_KEY_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> ParameterKey len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xMS.parameter_key, sVal,MAX_PARAMETER_KEY_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_CONNECTIONREQUESTURL,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get ConnectionRequestURL !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_CONN_REQ_URL_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> ConnectionRequestURL len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xMS.conn_req_url, sVal,MAX_CONN_REQ_URL_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_CONNECTIONREQUESTUSERNAME,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get ConnectionRequestUserName !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_CONN_REQ_UNAME_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> ConnectionRequestUserName len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xMS.conn_req_uname, sVal,MAX_CONN_REQ_UNAME_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_CONNECTIONREQUESTPASSWORD,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get ConnectionRequestPassword !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_CONN_REQ_PASSWD_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> ConnectionRequestPassword len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xMS.conn_req_passwd, sVal,MAX_CONN_REQ_PASSWD_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_UPGRADESMANAGED,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get UpgradesManaged !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xMS.upgrades_managed = atoi(sVal);


   /****** TR-111 related parameters ************/

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_UDPCONNREQADDRESS,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get udpconrequrl !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_CONN_REQ_URL_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> udpconrequrl len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xMS.udp_conn_req_url, sVal,MAX_CONN_REQ_URL_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_UDPCONNREQADDRESSNOTIFYLIMIT,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get udpconreqnotifylimit !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xMS.udp_conn_req_address_notification_limit= atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_STUNENABLE,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get stunenable !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xMS.stun_enable= atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_STUNSERVERADDRESS,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get stunserveripaddress !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    //xMS.stun_enable= atoi(sVal);
    if(strcmp(sVal, "") == 0)
        strlcpy(sVal, "0.0.0.0",MAX_FILELINE_LEN);
    if((inet_aton(sVal, &(xMS.stun_server_address))) == 0)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get stunserveripaddress !!\n\n", __FUNCTION__);
        iRtn = IFX_FAILURE;
        goto IFX_Handler;
    }

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_STUNSERVERPORT,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get stunserverport !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xMS.stun_server_port= atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_STUNUSERNAME,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get stunusername !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_CONN_REQ_UNAME_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> stunusername len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xMS.stun_server_uname, sVal,MAX_CONN_REQ_UNAME_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_STUNPASSWORD,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get stunpasswd !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_CONN_REQ_PASSWD_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> stunpasswd len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xMS.stun_passwd, sVal,MAX_CONN_REQ_PASSWD_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_STUNMAXKEEPALIVEPERIOD,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get stunmaxkeepalivetime !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xMS.stun_max_keep_alive_period= atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_STUNMINKEEPALIVEPERIOD,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get stunminkeepalivetime !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xMS.stun_min_keep_alive_period= atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_STUNNATDETECTED,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get natdetected !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xMS.nat_detected= atoi(sVal);

     memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_MGMT_SERVER_SECTION,
        IFX_MGMT_SERVER_SECTION "_" IFX_MGMT_SERVER_MNGDEVICENOTIFYLIMIT,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get mngdevnotifylimit !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xMS.mngdevnotifylimit= atoi(sVal);

    /* Fill the structure to be returned to the user */
    strlcpy(mgmt_server->url, xMS.url,MAX_URL_LEN);
    strlcpy(mgmt_server->uname, xMS.uname,MAX_UNAME_LEN);
    strlcpy(mgmt_server->passwd, xMS.passwd,MAX_PASSWORD_LEN);
    mgmt_server->period_inform_enable = xMS.period_inform_enable;
    mgmt_server->period_inform_interval = xMS.period_inform_interval;
    mgmt_server->period_abs_inform_time = xMS.period_abs_inform_time;
    strlcpy(mgmt_server->parameter_key, xMS.parameter_key,MAX_PARAMETER_KEY_LEN);
    strlcpy(mgmt_server->conn_req_url, xMS.conn_req_url,MAX_CONN_REQ_URL_LEN);
    strlcpy(mgmt_server->conn_req_uname, xMS.conn_req_uname,MAX_CONN_REQ_UNAME_LEN);
    strlcpy(mgmt_server->conn_req_passwd, xMS.conn_req_passwd,MAX_CONN_REQ_PASSWD_LEN);
    mgmt_server->upgrades_managed = xMS.upgrades_managed;
#if 0
    strcpy(mgmt_server->udp_conn_req_url, xMS.udp_conn_req_url);
    mgmt_server->udp_conn_req_address_notification_limit =xMS.udp_conn_req_address_notification_limit;
    mgmt_server->stun_enable=xMS.stun_enable;
    mgmt_server->stun_server_address = xMS.stun_server_address;
    mgmt_server->stun_server_port = xMS.stun_server_port;
    strcpy(mgmt_server->stun_server_uname, xMS.stun_server_uname);
    strcpy(mgmt_server->stun_passwd,xMS.stun_passwd);
    mgmt_server->stun_max_keep_alive_period=xMS.stun_max_keep_alive_period;
    mgmt_server->stun_min_keep_alive_period=xMS.stun_min_keep_alive_period;
    mgmt_server->nat_detected=xMS.nat_detected;
    mgmt_server->mngdevnotifylimit = xMS.mngdevnotifylimit;
#endif
    strlcpy(mgmt_server->udp_conn_req_url, xMS.udp_conn_req_url,MAX_CONN_REQ_URL_LEN);
    mgmt_server->udp_conn_req_address_notification_limit =xMS.udp_conn_req_address_notification_limit;
    mgmt_server->stun_enable=xMS.stun_enable;
    mgmt_server->stun_server_address = xMS.stun_server_address;
    mgmt_server->stun_server_port = xMS.stun_server_port;
    strlcpy(mgmt_server->stun_server_uname, xMS.stun_server_uname,MAX_CONN_REQ_UNAME_LEN);
    strlcpy(mgmt_server->stun_passwd,xMS.stun_passwd,MAX_CONN_REQ_PASSWD_LEN);
    mgmt_server->stun_max_keep_alive_period=xMS.stun_max_keep_alive_period;
    mgmt_server->stun_min_keep_alive_period=xMS.stun_min_keep_alive_period;
    mgmt_server->nat_detected=xMS.nat_detected;
    mgmt_server->mngdevnotifylimit = xMS.mngdevnotifylimit;

IFX_Handler:
    return (iRtn);
}

int32 ifx_get_ipping_diag(IPPING_DIAG * ipping_diag, uint32 flags)
{
    int32       iRet = IFX_SUCCESS;
#ifdef IFX_TR69_IPPING
    /* sVal buffer should be large enough to accomodate
       the biggest string in the obj */
    char8       sVal[MAX_IF_NAME];
    uint32      ulInFlag = IFX_F_DEFAULT, ulOutFlag;

    /* TBD: flags are not considered. Also iid struct in IPPING_DIAG is not
       considered */

    memset(ipping_diag, '\0', sizeof(IPPING_DIAG));

    if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
        IFX_IPPING_DIAG_SECTION "_" IFX_IPPING_DIAG_DIAGSTATE,
        ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;

    if ((strlen(sVal) + 1) > MAX_DIAGSTATE_LEN) {
        fprintf(stderr, "DiagState Value len exceeded=%d\n", strlen(sVal));
        iRet = IFX_FAILURE;
        goto IFX_Handler;
    }
    strcpy(ipping_diag->diag_state, sVal);

    if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
        IFX_IPPING_DIAG_SECTION "_" IFX_IPPING_DIAG_INTERFACE,
        ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS) goto IFX_Handler;
    if ((strlen(sVal) + 1) > MAX_IF_NAME) {
        fprintf(stderr, "Interface Value len exceeded=%d\n", strlen(sVal));
        iRet = IFX_FAILURE;
        goto IFX_Handler;
    }
    strcpy(ipping_diag->interface, sVal);

    if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
        IFX_IPPING_DIAG_SECTION "_" IFX_IPPING_DIAG_HOST,
        ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS) goto IFX_Handler;
    if ((strlen(sVal) + 1) > MAX_HOST_NAME) {
        fprintf(stderr, "Host Value len exceeded=%d\n", strlen(sVal));
        iRet = IFX_FAILURE;
        goto IFX_Handler;
    }
    strcpy(ipping_diag->host, sVal);

    if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
        IFX_IPPING_DIAG_SECTION "_" IFX_IPPING_DIAG_NUMREPEAT,
        ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;

    ipping_diag->num_repeat = atoi(sVal);

    if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
        IFX_IPPING_DIAG_SECTION "_" IFX_IPPING_DIAG_TIMEOUT,
        ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;

    ipping_diag->timeout = atoi(sVal);

    if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
        IFX_IPPING_DIAG_SECTION "_" IFX_IPPING_DIAG_DATASIZE,
        ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;

    ipping_diag->data_size = atoi(sVal);

    if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
        IFX_IPPING_DIAG_SECTION "_" IFX_IPPING_DIAG_DSCP,
        ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;

    ipping_diag->dscp = atoi(sVal);

    if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
        IFX_IPPING_DIAG_SECTION "_" IFX_IPPING_DIAG_SUCCESSCNT,
        ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;

    ipping_diag->success_cnt = atoi(sVal);

    if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
        IFX_IPPING_DIAG_SECTION "_" IFX_IPPING_DIAG_FAILURECNT,
        ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;

    ipping_diag->failure_cnt = atoi(sVal);

    if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
        IFX_IPPING_DIAG_SECTION "_" IFX_IPPING_DIAG_AVGRESPTIME,
        ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;

    ipping_diag->avg_resp_time = atoi(sVal);

    if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
        IFX_IPPING_DIAG_SECTION "_" IFX_IPPING_DIAG_MINRESPTIME,
        ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;

    ipping_diag->min_resp_time = atoi(sVal);

    if ((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
        IFX_IPPING_DIAG_SECTION "_" IFX_IPPING_DIAG_MAXRESPTIME,
        ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;

    ipping_diag->max_resp_time = atoi(sVal);

IFX_Handler:
#endif
    return (iRet);
}


int32 ifx_set_ipping_diag(int32 operation, IPPING_DIAG * ipping_diag, uint32 flags)
{
    int32         iRet = IFX_SUCCESS;
#ifdef IFX_TR69_IPPING
    /* sVal should always be large enough to accomodate
       the biggest string in the obj */
    char8         *sVal = NULL;

    sVal = (char8 *)malloc(512);

    if (sVal == NULL) {
        IFX_DBG("%s:%d Error--> Failed to Malloc !!\n", __FUNCTION__, __LINE__);
        goto IFX_Handler;
    }

    /* TBD: flags are not considered. Also iid struct in IPPING_DIAG is not
       considered*/

    sprintf(sVal, "%s_%s=\"%s\"\n", IFX_IPPING_DIAG_SECTION,
            IFX_IPPING_DIAG_DIAGSTATE, ipping_diag->diag_state);

    sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_IPPING_DIAG_SECTION,
            IFX_IPPING_DIAG_INTERFACE, ipping_diag->interface);

    sprintf(sVal, "%s%s_%s=\"%s\"\n", sVal, IFX_IPPING_DIAG_SECTION,
            IFX_IPPING_DIAG_HOST, ipping_diag->host);

    sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_IPPING_DIAG_SECTION,
            IFX_IPPING_DIAG_NUMREPEAT, ipping_diag->num_repeat);

    sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_IPPING_DIAG_SECTION,
            IFX_IPPING_DIAG_TIMEOUT, ipping_diag->timeout);

    sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_IPPING_DIAG_SECTION,
            IFX_IPPING_DIAG_DATASIZE, ipping_diag->data_size);

    sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_IPPING_DIAG_SECTION,
            IFX_IPPING_DIAG_DSCP, ipping_diag->dscp);

    sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_IPPING_DIAG_SECTION,
            IFX_IPPING_DIAG_SUCCESSCNT, ipping_diag->success_cnt);

    sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_IPPING_DIAG_SECTION,
            IFX_IPPING_DIAG_FAILURECNT, ipping_diag->failure_cnt);

    sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_IPPING_DIAG_SECTION,
            IFX_IPPING_DIAG_AVGRESPTIME, ipping_diag->avg_resp_time);

    sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_IPPING_DIAG_SECTION,
            IFX_IPPING_DIAG_MINRESPTIME, ipping_diag->min_resp_time);

    sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_IPPING_DIAG_SECTION,
            IFX_IPPING_DIAG_MAXRESPTIME, ipping_diag->max_resp_time);

    if ((iRet = ifx_SetObjData(IFX_DIAG_FILE, IFX_IPPING_DIAG_SECTION,
        flags, 1, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;

IFX_Handler:
    free(sVal);
#endif
    return iRet;
}

int32 ifx_get_dl_auth(DL_AUTH *dl_auth, uint32 flags)
{
    int32       iRtn = IFX_SUCCESS;
    char8       sVal[MAX_FILELINE_LEN];
    uint32      ulOutFlag;
    DL_AUTH     xAuth;

    memset(&xAuth, 0, sizeof(DL_AUTH));

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
        IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_USERNAME,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Username !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_UNAME_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> Username len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xAuth.uname, sVal,MAX_UNAME_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
        IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_PASSWORD,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Password !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_PASSWORD_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> Password len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xAuth.passwd, sVal,MAX_PASSWORD_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
        IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_REALM,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Realm !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> Realm len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xAuth.realm, sVal,MAX_AUTH_PARAM_LONG_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
        IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_NONCE,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Nonce !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> Nonce len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xAuth.nonce, sVal,MAX_AUTH_PARAM_LONG_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
        IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_URI,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get URI !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> URI len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xAuth.uri, sVal,MAX_AUTH_PARAM_LONG_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
        IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_ALGO,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Algo !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_SHORT_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> Algo len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xAuth.algo, sVal,MAX_AUTH_PARAM_SHORT_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
        IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_CNONCE,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get CNonce !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> CNonce len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xAuth.cnonce, sVal,MAX_AUTH_PARAM_LONG_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
        IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_OPAQUE,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Opaque !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> Opaque len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xAuth.opaque, sVal,MAX_AUTH_PARAM_LONG_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
        IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_QOP,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get QOP !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> QOP len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xAuth.qop, sVal,MAX_AUTH_PARAM_LONG_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
        IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_NC,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get NC !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_SHORT_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> NC len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xAuth.nc, sVal,MAX_AUTH_PARAM_SHORT_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
        IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_PROCESSCOOKIE,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get ProcessCookie !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xAuth.process_cookie = atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
        IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_FILETYPE,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get FileType !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> FileType len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xAuth.file_type, sVal,MAX_AUTH_PARAM_LONG_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
        IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_FILENAME,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get FileName !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_FILE_NAME_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> FileName len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xAuth.file_name, sVal,MAX_FILE_NAME_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
        IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_COMMANDKEY,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get CommandKey !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_COMMAND_KEY_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> CommandKey len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xAuth.cmd_key, sVal,MAX_COMMAND_KEY_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
        IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_STATUS,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Status !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xAuth.status = atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
        IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_STARTTIME,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get StartTime !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xAuth.abs_start_time = atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
        IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_ENDTIME,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get EndTime !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xAuth.abs_end_time = atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
        IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_FUTURETIME,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get EndTime !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xAuth.abs_fut_time = atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION,
        IFX_DL_AUTH_SECTION "_" IFX_DL_AUTH_SIZE,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get EndTime !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xAuth.size = atoi(sVal);

    /* Fill the structure to be returned to the user */
    strlcpy(dl_auth->uname, xAuth.uname,MAX_UNAME_LEN);
    strlcpy(dl_auth->passwd, xAuth.passwd,MAX_PASSWORD_LEN);
    strlcpy(dl_auth->realm, xAuth.realm,MAX_AUTH_PARAM_LONG_LEN);
    strlcpy(dl_auth->nonce, xAuth.nonce,MAX_AUTH_PARAM_LONG_LEN);
    strlcpy(dl_auth->uri, xAuth.uri,MAX_AUTH_PARAM_LONG_LEN);
    strlcpy(dl_auth->algo, xAuth.algo,MAX_AUTH_PARAM_SHORT_LEN);
    strlcpy(dl_auth->cnonce, xAuth.cnonce,MAX_AUTH_PARAM_LONG_LEN);
    strlcpy(dl_auth->opaque, xAuth.opaque,MAX_AUTH_PARAM_LONG_LEN);
    strlcpy(dl_auth->qop, xAuth.qop,MAX_AUTH_PARAM_LONG_LEN);
    strlcpy(dl_auth->nc, xAuth.nc,MAX_AUTH_PARAM_SHORT_LEN);
    dl_auth->process_cookie = xAuth.process_cookie;
    strlcpy(dl_auth->file_type, xAuth.file_type,MAX_AUTH_PARAM_LONG_LEN);
    strlcpy(dl_auth->file_name, xAuth.file_name,MAX_FILE_NAME_LEN);
    strlcpy(dl_auth->cmd_key, xAuth.cmd_key,MAX_COMMAND_KEY_LEN);
    dl_auth->status         = xAuth.status;
    dl_auth->abs_start_time = xAuth.abs_start_time;
    dl_auth->abs_end_time   = xAuth.abs_end_time;
    dl_auth->abs_fut_time   = xAuth.abs_fut_time;
    dl_auth->size   = xAuth.size;

IFX_Handler:
    return (iRtn);
}

int32 ifx_get_tr69_auth(TR69_AUTH *tr69_auth, uint32 flags)
{
    int32       iRtn = IFX_SUCCESS;
    char8       sVal[MAX_FILELINE_LEN];
    uint32      ulOutFlag;
    TR69_AUTH   xAuth;

    memset(&xAuth, 0, sizeof(TR69_AUTH));

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_AUTH_SECTION,
        IFX_TR69_AUTH_SECTION "_" IFX_TR69_AUTH_REALM,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Realm !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> Realm len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xAuth.realm, sVal,MAX_AUTH_PARAM_LONG_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_AUTH_SECTION,
        IFX_TR69_AUTH_SECTION "_" IFX_TR69_AUTH_NONCE,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Nonce !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> Nonce len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xAuth.nonce, sVal,MAX_AUTH_PARAM_LONG_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_AUTH_SECTION,
        IFX_TR69_AUTH_SECTION "_" IFX_TR69_AUTH_URI,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get URI !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> URI len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xAuth.uri, sVal,MAX_AUTH_PARAM_LONG_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_AUTH_SECTION,
        IFX_TR69_AUTH_SECTION "_" IFX_TR69_AUTH_ALGO,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Algo !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_SHORT_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> Algo len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xAuth.algo, sVal,MAX_AUTH_PARAM_SHORT_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_AUTH_SECTION,
        IFX_TR69_AUTH_SECTION "_" IFX_TR69_AUTH_CNONCE,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get CNonce !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> CNonce len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xAuth.cnonce, sVal,MAX_AUTH_PARAM_LONG_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_AUTH_SECTION,
        IFX_TR69_AUTH_SECTION "_" IFX_TR69_AUTH_OPAQUE,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Opaque !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> Opaque len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xAuth.opaque, sVal,MAX_AUTH_PARAM_LONG_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_AUTH_SECTION,
        IFX_TR69_AUTH_SECTION "_" IFX_TR69_AUTH_QOP,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get QOP !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_LONG_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> QOP len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xAuth.qop, sVal,MAX_AUTH_PARAM_LONG_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_AUTH_SECTION,
        IFX_TR69_AUTH_SECTION "_" IFX_TR69_AUTH_NC,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get NC !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_AUTH_PARAM_SHORT_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> NC len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xAuth.nc, sVal,MAX_AUTH_PARAM_SHORT_LEN);

    /* Fill the structure to be returned to the user */
    strlcpy(tr69_auth->realm, xAuth.realm,MAX_AUTH_PARAM_LONG_LEN);
    strlcpy(tr69_auth->nonce, xAuth.nonce,MAX_AUTH_PARAM_LONG_LEN);
    strlcpy(tr69_auth->uri, xAuth.uri,MAX_AUTH_PARAM_LONG_LEN);
    strlcpy(tr69_auth->algo, xAuth.algo,MAX_AUTH_PARAM_SHORT_LEN);
    strlcpy(tr69_auth->cnonce, xAuth.cnonce,MAX_AUTH_PARAM_LONG_LEN);
    strlcpy(tr69_auth->opaque, xAuth.opaque,MAX_AUTH_PARAM_LONG_LEN);
    strlcpy(tr69_auth->qop, xAuth.qop,MAX_AUTH_PARAM_LONG_LEN);
    strlcpy(tr69_auth->nc, xAuth.nc,MAX_AUTH_PARAM_SHORT_LEN);

IFX_Handler:
    return (iRtn);
}

int32 ifx_get_tr69_misc(TR69_MISC *tr69_misc, uint32 flags)
{
    int32       iRtn = IFX_SUCCESS;
    char8       sVal[MAX_FILELINE_LEN];
    uint32      ulOutFlag;
    TR69_MISC   xMisc;

    memset(&xMisc, 0, sizeof(TR69_MISC));

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
        IFX_TR69_MISC_SECTION "_" IFX_TR69_MISC_AUTHACS,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get AuthACS !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xMisc.auth_acs = atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
        IFX_TR69_MISC_SECTION "_" IFX_TR69_MISC_AUTHTYPE,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get AuthType !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_AUTH_TYPE_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> AuthType len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xMisc.auth_type, sVal,MAX_AUTH_TYPE_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
        IFX_TR69_MISC_SECTION "_" IFX_TR69_MISC_EVENTCODE,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get EventCode !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xMisc.event = atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
        IFX_TR69_MISC_SECTION "_" IFX_TR69_MISC_COMMANDKEY,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get CommandKey !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_COMMAND_KEY_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> CommandKey len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xMisc.cmd_key, sVal,MAX_COMMAND_KEY_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
        IFX_TR69_MISC_SECTION "_" IFX_TR69_MISC_INCLUDEXML,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get IncludeXML !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xMisc.inc_xml = atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
        IFX_TR69_MISC_SECTION "_" IFX_TR69_MISC_INCLUDESOAPACTION,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get IncludeSoapAction !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xMisc.inc_soap_action = atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
        IFX_TR69_MISC_SECTION "_" IFX_TR69_MISC_ACSGETRPC,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get ACSGetRPC !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xMisc.acs_get_rpc = atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
        IFX_TR69_MISC_SECTION "_" IFX_TR69_MISC_BOOTSTRAP,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Bootstrap !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xMisc.bootstrap = atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
        IFX_TR69_MISC_SECTION "_" IFX_TR69_MISC_TR69ENABLE,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Bootstrap !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xMisc.tr69_enable = atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
        IFX_TR69_MISC_SECTION "_" IFX_TR69_MISC_TR64ENABLE,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Bootstrap !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xMisc.tr64_enable = atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION,
        IFX_TR69_MISC_SECTION "_" IFX_TR69_MISC_PREVIOUSTIME,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Bootstrap !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xMisc.abs_prev_time = atoi(sVal);



    /* Fill the structure to be returned to the user */
    tr69_misc->auth_acs = xMisc.auth_acs;
    strlcpy(tr69_misc->auth_type, xMisc.auth_type,MAX_AUTH_TYPE_LEN);
    tr69_misc->event = xMisc.event;
    strlcpy(tr69_misc->cmd_key, xMisc.cmd_key,MAX_COMMAND_KEY_LEN);
    tr69_misc->inc_xml = xMisc.inc_xml;
    tr69_misc->inc_soap_action = xMisc.inc_soap_action;
    tr69_misc->acs_get_rpc = xMisc.acs_get_rpc;
    tr69_misc->bootstrap = xMisc.bootstrap;
    tr69_misc->tr69_enable = xMisc.tr69_enable;
    tr69_misc->tr64_enable = xMisc.tr64_enable;
    tr69_misc->abs_prev_time = xMisc.abs_prev_time;
IFX_Handler:
    return (iRtn);
}

int32 ifx_set_dl_auth(int32 operation, DL_AUTH *dl_auth, uint32 flags)
{
    int    count = 0, ret = IFX_SUCCESS;
    uint32 changed_fcount = 0;
    char8    buf[MAX_DATA_LEN];
    IFX_ID    iid;
    IFX_NAME_VALUE_PAIR array_fvp[MAX_FIELD_RANGE], *array_changed_fvp = NULL;

    memset(buf, 0, sizeof(buf));
    memset(&iid, 0, sizeof(iid));
    memset(array_fvp, 0, sizeof(array_fvp));


    /***  PROLOG BLOCK  ***/

    /* Append internal flags */
    if (operation == IFX_OP_DEL)
        flags |= IFX_F_DELETE;
    else if (operation == IFX_OP_MOD)
        flags |= IFX_F_MODIFY;
    else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
         flags |= IFX_F_INT_ADD;

    /********  VALIDATION BLOCK  ***********/
    /* For ops other than DELETE do the verification of input params */
    if (IFX_DELETE_F_NOT_SET(flags))
    {
        /*** Validation Checking Block ***/
        if(IFX_DONT_VALIDATE_F_NOT_SET(flags))
        {
            /* Do simple validation of pointer such as NULL */
            IFX_VALIDATE_PTR(dl_auth)
            /* Do simple validation of flags such as less than 0 */
            IFX_VALIDATE_FLAGS(flags)
        }
    }

    /*******  VALIDATION BLOCK END *********/

    /* Read the iid structure from rc.conf */
    iid = dl_auth->iid;
    if(ifx_get_iid_from_conf(&iid, FILE_RC_CONF, IFX_DL_AUTH_SECTION) != IFX_SUCCESS)
    {
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    /*********** Name Value Formation As Per RC.CONF ****************/
    /* Build the API Specific name value pair */
    sprintf(array_fvp[0].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, "cpeId");
    sprintf(array_fvp[0].value, "%d", iid.cpeId.Id);
    sprintf(array_fvp[1].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, "pcpeId");
    sprintf(array_fvp[1].value, "%d", iid.pcpeId.Id);
    sprintf(array_fvp[2].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, IFX_DL_AUTH_USERNAME);
    sprintf(array_fvp[2].value, "%s", dl_auth->uname);
    sprintf(array_fvp[3].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, IFX_DL_AUTH_PASSWORD);
    sprintf(array_fvp[3].value, "%s", dl_auth->passwd);
    sprintf(array_fvp[4].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, IFX_DL_AUTH_REALM);
    sprintf(array_fvp[4].value, "%s", dl_auth->realm);
    sprintf(array_fvp[5].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, IFX_DL_AUTH_NONCE);
    sprintf(array_fvp[5].value, "%s", dl_auth->nonce);
    sprintf(array_fvp[6].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, IFX_DL_AUTH_URI);
    sprintf(array_fvp[6].value, "%s", dl_auth->uri);
    sprintf(array_fvp[7].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, IFX_DL_AUTH_ALGO);
    sprintf(array_fvp[7].value, "%s", dl_auth->algo);
    sprintf(array_fvp[8].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, IFX_DL_AUTH_CNONCE);
    sprintf(array_fvp[8].value, "%s", dl_auth->cnonce);
    sprintf(array_fvp[9].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, IFX_DL_AUTH_OPAQUE);
    sprintf(array_fvp[9].value, "%s", dl_auth->opaque);
    sprintf(array_fvp[10].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, IFX_DL_AUTH_QOP);
    sprintf(array_fvp[10].value, "%s", dl_auth->qop);
    sprintf(array_fvp[11].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, IFX_DL_AUTH_NC);
    sprintf(array_fvp[11].value, "%s", dl_auth->nc);
    sprintf(array_fvp[12].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, IFX_DL_AUTH_PROCESSCOOKIE);
    sprintf(array_fvp[12].value, "%d", dl_auth->process_cookie);
    sprintf(array_fvp[13].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, IFX_DL_AUTH_FILETYPE);
    sprintf(array_fvp[13].value, "%s", dl_auth->file_type);
    sprintf(array_fvp[14].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, IFX_DL_AUTH_FILENAME);
    sprintf(array_fvp[14].value, "%s", dl_auth->file_name);
    sprintf(array_fvp[15].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, IFX_DL_AUTH_COMMANDKEY);
    sprintf(array_fvp[15].value, "%s", dl_auth->cmd_key);
    sprintf(array_fvp[16].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, IFX_DL_AUTH_STATUS);
    sprintf(array_fvp[16].value, "%d", dl_auth->status);
    sprintf(array_fvp[17].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, IFX_DL_AUTH_STARTTIME);
    sprintf(array_fvp[17].value, "%u", dl_auth->abs_start_time);
    sprintf(array_fvp[18].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, IFX_DL_AUTH_ENDTIME);
    sprintf(array_fvp[18].value, "%u", dl_auth->abs_end_time);
    sprintf(array_fvp[19].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, IFX_DL_AUTH_FUTURETIME);
    sprintf(array_fvp[19].value, "%u", dl_auth->abs_fut_time);
    sprintf(array_fvp[20].fieldname, "%s_%s", IFX_DL_AUTH_SECTION, IFX_DL_AUTH_SIZE);
    sprintf(array_fvp[20].value, "%u", dl_auth->size);
    count = 21;

    /***  PROLOG BLOCK END  ***/

    /**************** ACL CHECK BLOCK *****************/

    CHECK_ACL_RET(iid, count, array_fvp,
        changed_fcount, array_changed_fvp, flags, IFX_Handler)

    /**************** ACL CHECK BLOCK END *****************/

    /********* SYSTEM CONFIG FILE UPDATE BLOCK  **********/

    /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
    if (IFX_MODIFY_F_SET(flags))
    {
        //form_cfgdb_buf(buf, changed_fcount, array_changed_fvp);
        form_cfgdb_buf(buf, count, array_fvp);
    }
    else
    {
        form_cfgdb_buf(buf, count, array_fvp);
    }

    /* Backup rc.conf before proceeding with configuration */
    CHECKPOINT_RET(flags, FILE_RC_CONF, CHKPOINT_FILE, IFX_Handler)

    /* Update rc.conf */
    ret = ifx_SetObjData(FILE_RC_CONF, IFX_DL_AUTH_SECTION, flags, 1, buf);

    /* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
    if(ret != IFX_SUCCESS)
    {
        ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE, flags | IFX_F_INT_DONT_RESTART_SERVICES, IFX_Handler)
    }

    /********* SYSTEM CONFIG FILE UPDATE BLOCK END **********/

    /************ DEVICE CONFIGURATION BLOCK ***********/
    /************ DEVICE CONFIGURATION BLOCK END ***********/

    /**************** NOTIFICATION BLOCK ******************/

    /* Notify the Internal TR69 Stack */
    CHECK_N_SEND_NOTIFICATION (iid, changed_fcount, array_changed_fvp, flags, IFX_Handler)

    /**************** NOTIFICATION BLOCK ******************/

    /***************** EPILOG BLOCK **********************/
    ret = ifx_config_write(FILE_RC_CONF, flags);
    if(ret != IFX_SUCCESS)
    {
        ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE, flags | IFX_F_INT_DONT_RESTART_SERVICES, IFX_Handler)
    }
    /***************** EPILOG BLOCK END **********************/

IFX_Handler:
    IFX_MEM_FREE(array_changed_fvp)
    if(ret != IFX_SUCCESS)
        return ret;
    else
        return IFX_SUCCESS;
}

int32 ifx_set_tr69_auth(int32 operation, TR69_AUTH *tr69_auth, uint32 flags)
{
    int    count = 0, ret = IFX_SUCCESS;
    uint32 changed_fcount = 0;
    char8    buf[MAX_DATA_LEN];
    IFX_ID    iid;
    IFX_NAME_VALUE_PAIR array_fvp[MAX_FIELD_RANGE], *array_changed_fvp = NULL;

    memset(buf, 0, sizeof(buf));
    memset(&iid, 0, sizeof(iid));
    memset(array_fvp, 0, sizeof(array_fvp));


    /***  PROLOG BLOCK  ***/

    /* Append internal flags */
    if (operation == IFX_OP_DEL)
        flags |= IFX_F_DELETE;
    else if (operation == IFX_OP_MOD)
        flags |= IFX_F_MODIFY;
    else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
         flags |= IFX_F_INT_ADD;

    /********  VALIDATION BLOCK  ***********/
    /* For ops other than DELETE do the verification of input params */
    if (IFX_DELETE_F_NOT_SET(flags))
    {
        /*** Validation Checking Block ***/
        if(IFX_DONT_VALIDATE_F_NOT_SET(flags))
        {
            /* Do simple validation of pointer such as NULL */
            IFX_VALIDATE_PTR(tr69_auth)
            /* Do simple validation of flags such as less than 0 */
            IFX_VALIDATE_FLAGS(flags)
        }
    }

    /*******  VALIDATION BLOCK END *********/

    /* Read the iid structure from rc.conf */
    iid = tr69_auth->iid;
    if(ifx_get_iid_from_conf(&iid, FILE_RC_CONF, IFX_TR69_AUTH_SECTION) != IFX_SUCCESS)
    {
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    /*********** Name Value Formation As Per RC.CONF ****************/
    /* Build the API Specific name value pair */
    sprintf(array_fvp[0].fieldname, "%s_%s", IFX_TR69_AUTH_SECTION, "cpeId");
    sprintf(array_fvp[0].value, "%d", iid.cpeId.Id);
    sprintf(array_fvp[1].fieldname, "%s_%s", IFX_TR69_AUTH_SECTION, "pcpeId");
    sprintf(array_fvp[1].value, "%d", iid.pcpeId.Id);
    sprintf(array_fvp[2].fieldname, "%s_%s", IFX_TR69_AUTH_SECTION, IFX_TR69_AUTH_REALM);
    sprintf(array_fvp[2].value, "%s", tr69_auth->realm);
    sprintf(array_fvp[3].fieldname, "%s_%s", IFX_TR69_AUTH_SECTION, IFX_TR69_AUTH_NONCE);
    sprintf(array_fvp[3].value, "%s", tr69_auth->nonce);
    sprintf(array_fvp[4].fieldname, "%s_%s", IFX_TR69_AUTH_SECTION, IFX_TR69_AUTH_URI);
    sprintf(array_fvp[4].value, "%s", tr69_auth->uri);
    sprintf(array_fvp[5].fieldname, "%s_%s", IFX_TR69_AUTH_SECTION, IFX_TR69_AUTH_ALGO);
    sprintf(array_fvp[5].value, "%s", tr69_auth->algo);
    sprintf(array_fvp[6].fieldname, "%s_%s", IFX_TR69_AUTH_SECTION, IFX_TR69_AUTH_CNONCE);
    sprintf(array_fvp[6].value, "%s", tr69_auth->cnonce);
    sprintf(array_fvp[7].fieldname, "%s_%s", IFX_TR69_AUTH_SECTION, IFX_TR69_AUTH_OPAQUE);
    sprintf(array_fvp[7].value, "%s", tr69_auth->opaque);
    sprintf(array_fvp[8].fieldname, "%s_%s", IFX_TR69_AUTH_SECTION, IFX_TR69_AUTH_QOP);
    sprintf(array_fvp[8].value, "%s", tr69_auth->qop);
    sprintf(array_fvp[9].fieldname, "%s_%s", IFX_TR69_AUTH_SECTION, IFX_TR69_AUTH_NC);
    sprintf(array_fvp[9].value, "%s", tr69_auth->nc);
    count = 10;

    /***  PROLOG BLOCK END  ***/

    /**************** ACL CHECK BLOCK *****************/

    CHECK_ACL_RET(iid, count, array_fvp,
        changed_fcount, array_changed_fvp, flags, IFX_Handler)

    /**************** ACL CHECK BLOCK END *****************/

    /********* SYSTEM CONFIG FILE UPDATE BLOCK  **********/

    /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
    if (IFX_MODIFY_F_SET(flags))
    {
        //form_cfgdb_buf(buf, changed_fcount, array_changed_fvp);
        form_cfgdb_buf(buf, count, array_fvp);
    }
    else
    {
        form_cfgdb_buf(buf, count, array_fvp);
    }

    /* Backup rc.conf before proceeding with configuration */
    CHECKPOINT_RET(flags, FILE_RC_CONF, CHKPOINT_FILE, IFX_Handler)

    /* Update rc.conf */
    ret = ifx_SetObjData(FILE_RC_CONF, IFX_TR69_AUTH_SECTION, flags, 1, buf);

    /* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
    if(ret != IFX_SUCCESS)
    {
        ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE, flags | IFX_F_INT_DONT_RESTART_SERVICES, IFX_Handler)
    }

    /********* SYSTEM CONFIG FILE UPDATE BLOCK END **********/

    /************ DEVICE CONFIGURATION BLOCK ***********/
    /************ DEVICE CONFIGURATION BLOCK END ***********/

    /**************** NOTIFICATION BLOCK ******************/

    /* Notify the Internal TR69 Stack */
    CHECK_N_SEND_NOTIFICATION (iid, changed_fcount, array_changed_fvp, flags, IFX_Handler)

    /**************** NOTIFICATION BLOCK ******************/

    /***************** EPILOG BLOCK **********************/
    ret = ifx_config_write(FILE_RC_CONF, flags);
    if(ret != IFX_SUCCESS)
    {
        ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE, flags | IFX_F_INT_DONT_RESTART_SERVICES, IFX_Handler)
    }
    /***************** EPILOG BLOCK END **********************/

IFX_Handler:
    IFX_MEM_FREE(array_changed_fvp)
    if(ret != IFX_SUCCESS)
        return ret;
    else
        return IFX_SUCCESS;
}

int32 ifx_set_tr69_misc(int32 operation, TR69_MISC *tr69_misc, uint32 flags)
{
    int    count = 0, ret = IFX_SUCCESS;
    uint32 changed_fcount = 0;
    char8    buf[MAX_DATA_LEN];
    IFX_ID    iid;
    IFX_NAME_VALUE_PAIR array_fvp[MAX_FIELD_RANGE], *array_changed_fvp = NULL;

    memset(buf, 0, sizeof(buf));
    memset(&iid, 0, sizeof(iid));
    memset(array_fvp, 0, sizeof(array_fvp));


    /***  PROLOG BLOCK  ***/

    /* Append internal flags */
    if (operation == IFX_OP_DEL)
        flags |= IFX_F_DELETE;
    else if (operation == IFX_OP_MOD)
        flags |= IFX_F_MODIFY;
    else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
         flags |= IFX_F_INT_ADD;

    /********  VALIDATION BLOCK  ***********/
    /* For ops other than DELETE do the verification of input params */
    if (IFX_DELETE_F_NOT_SET(flags))
    {
        /*** Validation Checking Block ***/
        if(IFX_DONT_VALIDATE_F_NOT_SET(flags))
        {
            /* Do simple validation of pointer such as NULL */
            IFX_VALIDATE_PTR(tr69_misc)
            /* Do simple validation of flags such as less than 0 */
            IFX_VALIDATE_FLAGS(flags)
        }
    }

    /*******  VALIDATION BLOCK END *********/

    /* Read the iid structure from rc.conf */
    iid = tr69_misc->iid;
    if(ifx_get_iid_from_conf(&iid, FILE_RC_CONF, IFX_TR69_MISC_SECTION) != IFX_SUCCESS)
    {
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    /*********** Name Value Formation As Per RC.CONF ****************/
    /* Build the API Specific name value pair */
    sprintf(array_fvp[0].fieldname, "%s_%s", IFX_TR69_MISC_SECTION, "cpeId");
    sprintf(array_fvp[0].value, "%d", iid.cpeId.Id);
    sprintf(array_fvp[1].fieldname, "%s_%s", IFX_TR69_MISC_SECTION, "pcpeId");
    sprintf(array_fvp[1].value, "%d", iid.pcpeId.Id);
    sprintf(array_fvp[2].fieldname, "%s_%s", IFX_TR69_MISC_SECTION, IFX_TR69_MISC_AUTHACS);
    sprintf(array_fvp[2].value, "%d", tr69_misc->auth_acs);
    sprintf(array_fvp[3].fieldname, "%s_%s", IFX_TR69_MISC_SECTION, IFX_TR69_MISC_AUTHTYPE);
    sprintf(array_fvp[3].value, "%s", tr69_misc->auth_type);
    sprintf(array_fvp[4].fieldname, "%s_%s", IFX_TR69_MISC_SECTION, IFX_TR69_MISC_EVENTCODE);
    sprintf(array_fvp[4].value, "%u", tr69_misc->event);
    sprintf(array_fvp[5].fieldname, "%s_%s", IFX_TR69_MISC_SECTION, IFX_TR69_MISC_COMMANDKEY);
    sprintf(array_fvp[5].value, "%s", tr69_misc->cmd_key);
    sprintf(array_fvp[6].fieldname, "%s_%s", IFX_TR69_MISC_SECTION, IFX_TR69_MISC_INCLUDEXML);
    sprintf(array_fvp[6].value, "%d", tr69_misc->inc_xml);
    sprintf(array_fvp[7].fieldname, "%s_%s", IFX_TR69_MISC_SECTION, IFX_TR69_MISC_INCLUDESOAPACTION);
    sprintf(array_fvp[7].value, "%d", tr69_misc->inc_soap_action);
    sprintf(array_fvp[8].fieldname, "%s_%s", IFX_TR69_MISC_SECTION, IFX_TR69_MISC_ACSGETRPC);
    sprintf(array_fvp[8].value, "%d", tr69_misc->acs_get_rpc);
    sprintf(array_fvp[9].fieldname, "%s_%s", IFX_TR69_MISC_SECTION, IFX_TR69_MISC_BOOTSTRAP);
    sprintf(array_fvp[9].value, "%d", tr69_misc->bootstrap);
    sprintf(array_fvp[10].fieldname, "%s_%s", IFX_TR69_MISC_SECTION, IFX_TR69_MISC_TR69ENABLE);
    sprintf(array_fvp[10].value, "%d", tr69_misc->tr69_enable);
    sprintf(array_fvp[11].fieldname, "%s_%s", IFX_TR69_MISC_SECTION, IFX_TR69_MISC_TR64ENABLE);
    sprintf(array_fvp[11].value, "%d", tr69_misc->tr64_enable);
    sprintf(array_fvp[12].fieldname, "%s_%s", IFX_TR69_MISC_SECTION, IFX_TR69_MISC_PREVIOUSTIME);
    sprintf(array_fvp[12].value, "%d", tr69_misc->abs_prev_time);

    count = 13;

    /***  PROLOG BLOCK END  ***/

    /**************** ACL CHECK BLOCK *****************/

    CHECK_ACL_RET(iid, count, array_fvp,
        changed_fcount, array_changed_fvp, flags, IFX_Handler)

    /**************** ACL CHECK BLOCK END *****************/

    /********* SYSTEM CONFIG FILE UPDATE BLOCK  **********/

    /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
    if (IFX_MODIFY_F_SET(flags))
    {
        //form_cfgdb_buf(buf, changed_fcount, array_changed_fvp);
        form_cfgdb_buf(buf, count, array_fvp);
    }
    else
    {
        form_cfgdb_buf(buf, count, array_fvp);
    }

    /* Backup rc.conf before proceeding with configuration */
    CHECKPOINT_RET(flags, FILE_RC_CONF, CHKPOINT_FILE, IFX_Handler)

    /* Update rc.conf */
    ret = ifx_SetObjData(FILE_RC_CONF, IFX_TR69_MISC_SECTION, flags, 1, buf);

    /* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
    if(ret != IFX_SUCCESS)
    {
        ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE, flags | IFX_F_INT_DONT_RESTART_SERVICES, IFX_Handler)
    }

    /********* SYSTEM CONFIG FILE UPDATE BLOCK END **********/

    /************ DEVICE CONFIGURATION BLOCK ***********/
    /************ DEVICE CONFIGURATION BLOCK END ***********/

    /**************** NOTIFICATION BLOCK ******************/

    /* Notify the Internal TR69 Stack */
    CHECK_N_SEND_NOTIFICATION (iid, changed_fcount, array_changed_fvp, flags, IFX_Handler)

    /**************** NOTIFICATION BLOCK ******************/

    /***************** EPILOG BLOCK **********************/
    ret = ifx_config_write(FILE_RC_CONF, flags);
    if(ret != IFX_SUCCESS)
    {
        ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE, flags | IFX_F_INT_DONT_RESTART_SERVICES, IFX_Handler)
    }
    /***************** EPILOG BLOCK END **********************/

IFX_Handler:
    IFX_MEM_FREE(array_changed_fvp)
    if(ret != IFX_SUCCESS)
        return ret;
    else
        return IFX_SUCCESS;
}

int32 ifx_get_gateway_info(GATEWAY_INFO * gateway_info, uint32 flags)
{
    int32       iRtn = IFX_SUCCESS;
#ifdef DEVICE_SUPPORT
#ifdef DEVICE_ASSO_SUPPORT
    char8       sVal[MAX_FILELINE_LEN];
    uint32      ulOutFlag;
    GATEWAY_INFO xGI;


    memset(&xGI, 0, sizeof(GATEWAY_INFO));

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_GATEWAY_INFO_SECTION,
        IFX_GATEWAY_INFO_SECTION "_" "cpeId",
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Manufacturer OUI !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }

    xGI.iid.cpeId.Id = atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_GATEWAY_INFO_SECTION,
        IFX_GATEWAY_INFO_SECTION "_" "pcpeId",
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Manufacturer OUI !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }

    xGI.iid.pcpeId.Id = atoi(sVal);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_GATEWAY_INFO_SECTION,
        IFX_GATEWAY_INFO_SECTION "_" IFX_GATEWAY_INFO_MANUFACTUREROUI,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Manufacturer OUI !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_OUI_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> Manufacturer OUI len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xGI.oui, sVal,MAX_OUI_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_GATEWAY_INFO_SECTION,
        IFX_GATEWAY_INFO_SECTION "_" IFX_GATEWAY_INFO_PRODUCTCLASS,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Product class !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_PROD_CLASS_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> Product class len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xGI.product_class, sVal,MAX_PROD_CLASS_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_GATEWAY_INFO_SECTION,
        IFX_GATEWAY_INFO_SECTION "_" IFX_DEVICE_INFO_SERIALNUMBER,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Serial Number !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_SERIAL_NUM_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> Serial Number len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xGI.serial_number, sVal,MAX_SERIAL_NUM_LEN);


    gateway_info->iid.cpeId.Id =xGI.iid.cpeId.Id;
    gateway_info->iid.pcpeId.Id =xGI.iid.pcpeId.Id;
    strcpy(gateway_info->oui, xGI.oui);
    strcpy(gateway_info->product_class, xGI.product_class);
    strcpy(gateway_info->serial_number, xGI.serial_number);

    return IFX_SUCCESS;

    IFX_Handler:
#endif
#endif
        return (iRtn);
}

int32 ifx_set_gateway_info(int32 operation, GATEWAY_INFO * gateway_info, uint32 flags)
{
#ifdef DEVICE_SUPPORT
#ifdef DEVICE_ASSO_SUPPORT
    int    count = 0, ret = IFX_SUCCESS;
    uint32 changed_fcount = 0;
    char8    buf[MAX_DATA_LEN];
    IFX_ID    iid;
    IFX_NAME_VALUE_PAIR array_fvp[MAX_FIELD_RANGE], *array_changed_fvp = NULL;

    memset(buf, 0, sizeof(buf));
    memset(&iid, 0, sizeof(iid));
    memset(array_fvp, 0, sizeof(array_fvp));


    /***  PROLOG BLOCK  ***/

    /* Append internal flags */
    if (operation == IFX_OP_DEL)
        flags |= IFX_F_DELETE;
    else if (operation == IFX_OP_MOD)
        flags |= IFX_F_MODIFY;
    else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
         flags |= IFX_F_INT_ADD;

    /********  VALIDATION BLOCK  ***********/
    /* For ops other than DELETE do the verification of input params */
    if (IFX_DELETE_F_NOT_SET(flags))
    {
        /*** Validation Checking Block ***/
        if(IFX_DONT_VALIDATE_F_NOT_SET(flags))
        {
            /* Do simple validation of pointer such as NULL */
            IFX_VALIDATE_PTR(gateway_info)
            /* Do simple validation of flags such as less than 0 */
            IFX_VALIDATE_FLAGS(flags)
        }
    }

    /*******  VALIDATION BLOCK END *********/

    /* Read the iid structure from rc.conf */
    iid = gateway_info->iid;
    if(ifx_get_iid_from_conf(&iid, FILE_RC_CONF, IFX_GATEWAY_INFO_SECTION) != IFX_SUCCESS)
    {
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    /*********** Name Value Formation As Per RC.CONF ****************/
    /* Build the API Specific name value pair */
    sprintf(array_fvp[0].fieldname, "%s_%s", IFX_GATEWAY_INFO_SECTION, "cpeId");
    sprintf(array_fvp[0].value, "%d", iid.cpeId.Id);
    sprintf(array_fvp[1].fieldname, "%s_%s", IFX_GATEWAY_INFO_SECTION, "pcpeId");
    sprintf(array_fvp[1].value, "%d", iid.pcpeId.Id);

    sprintf(array_fvp[2].fieldname, "%s_%s", IFX_GATEWAY_INFO_SECTION, IFX_DEVICE_INFO_MANUFACTUREROUI);
    sprintf(array_fvp[2].value, "%s", gateway_info->oui);
    sprintf(array_fvp[3].fieldname, "%s_%s", IFX_GATEWAY_INFO_SECTION, IFX_DEVICE_INFO_PRODUCTCLASS);
    sprintf(array_fvp[3].value, "%s", gateway_info->product_class);
    sprintf(array_fvp[4].fieldname, "%s_%s", IFX_GATEWAY_INFO_SECTION, IFX_DEVICE_INFO_SERIALNUMBER);
    sprintf(array_fvp[4].value, "%s", gateway_info->serial_number);

    count = 5;

    /***  PROLOG BLOCK END  ***/

    /**************** ACL CHECK BLOCK *****************/

    CHECK_ACL_RET(iid, count, array_fvp,
        changed_fcount, array_changed_fvp, flags, IFX_Handler)

    /**************** ACL CHECK BLOCK END *****************/

    /********* SYSTEM CONFIG FILE UPDATE BLOCK  **********/

    /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
    if (IFX_MODIFY_F_SET(flags))
    {
        //form_cfgdb_buf(buf, changed_fcount, array_changed_fvp);
        form_cfgdb_buf(buf, count, array_fvp);
    }
    else
    {
        form_cfgdb_buf(buf, count, array_fvp);
    }

    /* Backup rc.conf before proceeding with configuration */
    CHECKPOINT_RET(flags, FILE_RC_CONF, CHKPOINT_FILE, IFX_Handler)

    /* Update rc.conf */
    ret = ifx_SetObjData(FILE_RC_CONF, IFX_GATEWAY_INFO_SECTION, flags, 1, buf);

    /* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
    if(ret != IFX_SUCCESS)
    {
        ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE, flags | IFX_F_INT_DONT_RESTART_SERVICES, IFX_Handler)
    }

    /********* SYSTEM CONFIG FILE UPDATE BLOCK END **********/

    /************ DEVICE CONFIGURATION BLOCK ***********/
    /************ DEVICE CONFIGURATION BLOCK END ***********/

    /**************** NOTIFICATION BLOCK ******************/

    /* Notify the Internal TR69 Stack */
    CHECK_N_SEND_NOTIFICATION (iid, changed_fcount, array_changed_fvp, flags, IFX_Handler)

    /**************** NOTIFICATION BLOCK ******************/

    /***************** EPILOG BLOCK **********************/
    ret = ifx_config_write(FILE_RC_CONF, flags);
    if(ret != IFX_SUCCESS)
    {
        ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE, flags | IFX_F_INT_DONT_RESTART_SERVICES, IFX_Handler)
    }
    /***************** EPILOG BLOCK END **********************/

IFX_Handler:
    IFX_MEM_FREE(array_changed_fvp)
    if(ret != IFX_SUCCESS)
        return ret;
    else
#endif
#endif
        return IFX_SUCCESS;

}

int32 ifx_get_all_manageable_devices(int32 * num_entries, MANAGEABLE_DEVICE ** Manageable_device, uint32 flags)
{
#ifndef DEVICE_SUPPORT
#ifdef DEVICE_ASSO_SUPPORT
	 char8   sValue[MAX_FILELINE_LEN];
	 char8   command[MAX_FILELINE_LEN];
	 //char8   temp[MAX_DATA_LEN], *vpi = NULL, *vci = NULL;
	 //char8   line[MAX_FILELINE_LEN];

	 int     i = 0;// found = 0, crc_errors = 0;
	 int     ret = IFX_SUCCESS; //file_vpi = 0, file_vci = 0;
	 char    num;
	 uint32  inflag = flags, outflag = 0;
	 void *pReallocTmp = NULL;
//	 FILE    *in = NULL;

	 memset(sValue,'\0', sizeof(sValue));
	 memset(command,'\0', sizeof(command));

	 /* get the count of vc channels present in rc.conf */
	 if (ifx_GetObjData(FILE_RC_CONF, IFX_MANAGEABLE_DEVICE_SECTION,
	                         "manageable_device_Count", inflag, &outflag, sValue) != IFX_SUCCESS) {
	         IFX_DBG("\n\n Error : In function [%s] --> Failed to get manageable_device_Count from rc.conf !! \n\n",
	                         __FUNCTION__);
	         ret = IFX_FAILURE;
	         goto IFX_Handler;
	 }
	 else {
	         num = atoi(sValue);
	         *num_entries = num;
	 }

	 if (num == 0) {
	         *num_entries = 0;
	         *Manageable_device = NULL;
	         IFX_DBG("\n\n Warn : In function [%s] --> No Manageable Device added !! \n\n", __FUNCTION__);
	         goto IFX_Handler;
	 }

	 /* allocate memory for num_entries of vcchannels in the output array vcc_array */
	 for (i=0; i<num; i++)   {
	
		     pReallocTmp = *Manageable_device;
			
		     *Manageable_device = (MANAGEABLE_DEVICE*)realloc(*Manageable_device,
		                         (i + 1) * sizeof(MANAGEABLE_DEVICE));
		     if(*Manageable_device == NULL){
			IFX_MEM_FREE(pReallocTmp);
		        ret = IFX_FAILURE;
		        goto IFX_Handler;
		     }else{
			  pReallocTmp = NULL;
		     }
			
			    /* get the cpeid for this vc channel index i */
		    MAKE_PARAM_ELEMENT_TAG(IFX_MANAGEABLE_DEVICE_SECTION_PREFIX, i, "cpeId", command);
	 	    memset(sValue,'\0', sizeof(sValue));
		    if ((ifx_GetObjData(FILE_RC_CONF, IFX_MANAGEABLE_DEVICE_SECTION,
		                            command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
		        IFX_DBG("\n\n In Function [%s] : Error--> Not Found [%s] !! \n\n",
		                    __FUNCTION__, command);
		    }
		    else
		        (*Manageable_device+i)->iid.cpeId.Id = atoi(sValue);

		    /* get the parent cpeid for this vc channel index i */
		    MAKE_PARAM_ELEMENT_TAG(IFX_MANAGEABLE_DEVICE_SECTION_PREFIX, i, "pcpeId", command);
	 	    memset(sValue,'\0', sizeof(sValue));
		    if ((ret = ifx_GetObjData(FILE_RC_CONF, IFX_MANAGEABLE_DEVICE_SECTION,
		                            command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
		        IFX_DBG("\n\n In Function [%s] : Error--> Not Found [%s] !! \n\n",
		                    __FUNCTION__, command);
		    }
		    else
		            (*Manageable_device+i)->iid.pcpeId.Id = atoi(sValue);


			    /* get the qos mode for this vcchannel index i */
		    MAKE_PARAM_ELEMENT_TAG(IFX_MANAGEABLE_DEVICE_SECTION_PREFIX, i, IFX_MANAGEABLE_DEVICE_MANUFACTUREROUI, command);
	 	    memset(sValue,'\0', sizeof(sValue));
		    if ((ifx_GetObjData(FILE_RC_CONF, IFX_MANAGEABLE_DEVICE_SECTION,
		                            command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
		        IFX_DBG("\n\n In Function [%s] : Error--> Not Found [%s] !! \n\n",
		                    __FUNCTION__, command);
		    }
		    else
		           strlcpy( (*Manageable_device+i)->oui, sValue,MAX_OUI_LEN);

		    /* get the mbs value for this vcchannel index i */
		    MAKE_PARAM_ELEMENT_TAG(IFX_MANAGEABLE_DEVICE_SECTION_PREFIX, i, IFX_MANAGEABLE_DEVICE_PRODUCTCLASS, command);
	 	    memset(sValue,'\0', sizeof(sValue));
		    if ((ifx_GetObjData(FILE_RC_CONF, IFX_MANAGEABLE_DEVICE_SECTION,
		                            command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
		        IFX_DBG("\n\n In Function [%s] : Error--> Not Found [%s] !! \n\n",
		                    __FUNCTION__, command);
		    }
		    else {
		           strlcpy( (*Manageable_device+i)->product_class, sValue,MAX_PROD_CLASS_LEN);
		    }

		    /* get the max pcr value for this vcchannel index i */
		    MAKE_PARAM_ELEMENT_TAG(IFX_MANAGEABLE_DEVICE_SECTION_PREFIX, i, IFX_MANAGEABLE_DEVICE_SERIALNUMBER, command);
	 	    memset(sValue,'\0', sizeof(sValue));
		    if ((ifx_GetObjData(FILE_RC_CONF, IFX_MANAGEABLE_DEVICE_SECTION,
		                            command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
		        IFX_DBG("\n\n In Function [%s] : Error--> Not Found [%s] !! \n\n",
		                    __FUNCTION__, command);
		    }
		    else {
		         strlcpy( (*Manageable_device+i)->serial_number, sValue,MAX_SERIAL_NUM_LEN);
		    }

		   MAKE_PARAM_ELEMENT_TAG(IFX_MANAGEABLE_DEVICE_SECTION_PREFIX, i, IFX_MANAGEABLE_DEVICE_IPADDR, command);
	 	    memset(sValue,'\0', sizeof(sValue));
		    if ((ifx_GetObjData(FILE_RC_CONF, IFX_MANAGEABLE_DEVICE_SECTION,
		                            command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
		        IFX_DBG("\n\n In Function [%s] : Error--> Not Found [%s] !! \n\n",
		                    __FUNCTION__, command);
		    }
		    else {
			  strncpy( (*Manageable_device+i)->ipaddr, sValue,strlen(sValue));
		    }

	  }

	IFX_Handler:
	  if(ret != IFX_SUCCESS) {
	      *num_entries = 0;
	      IFX_MEM_FREE(*Manageable_device)
	      return ret;
	  }
	  else
#endif
#endif
	          return IFX_SUCCESS;
}

int32 ifx_set_manageable_device(int32 operation, MANAGEABLE_DEVICE * entry, uint32 flags)
{
#ifndef DEVICE_SUPPORT
#ifdef DEVICE_ASSO_SUPPORT
	 char8   sbuf[MAX_FILELINE_LEN], conf_buf[MAX_DATA_LEN], sValue[MAX_NAME_LEN];
	 int32   passed_index = -1, ret = IFX_SUCCESS;
         uint32  count = 0, changed_count = 0;
	 IFX_ID  iid, piid;
	// MGMT_SERVER dev;
	 IFX_NAME_VALUE_PAIR array_fvp[MAX_FIELD_RANGE], *array_changed_fvp = NULL;


	 //memset(&dev, 0x00, sizeof(dev));
	 //memset(&iid, 0x00, sizeof(iid));

	 memset(&iid, 0, sizeof(iid));
	 memset(&piid, 0, sizeof(piid));
	 memset(sbuf, 0, sizeof(sbuf));
	 memset(conf_buf, 0, sizeof(conf_buf));
	 memset(sValue, 0, sizeof(sValue));
	 memset(array_fvp, 0, sizeof(array_fvp));

	 /*************** Prolog Block *********************/
	 /* Based on operation (ADD or DELETE or MODIFY)
	  * append the flag with internal flags */
	 if (operation == IFX_OP_DEL)
	     flags |= IFX_F_DELETE;
	 else if (operation == IFX_OP_ADD) {
	     if( (IFX_MODIFY_F_NOT_SET(flags)))
	         flags |= IFX_F_INT_ADD;
	 }
	 else
	     flags |= IFX_F_MODIFY;


	 /**************** Validation Block *****************/
	 /* For Operations other than DELETE do the verification of input params */
	 if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
	     /* Do simple validation of pointer such as NULL */
	     IFX_VALIDATE_PTR(entry)
	     /* Do simple validation of flags sucha as less than 0 */
	     IFX_VALIDATE_FLAGS(flags)

	 }

	 /**************** ID Allocation Block - Only for ADD Operation **************/
	 sprintf(entry->iid.cpeId.secName, "%s", IFX_MANAGEABLE_DEVICE_SECTION);
	 sprintf(entry->iid.pcpeId.secName, "%s", IFX_MGMT_SERVER_SECTION);
	 entry->iid.pcpeId.Id =1;

	 if (IFX_ADD_F_SET(flags)) {
	     /* before getting iid for this, create a parent instance in wan conn device section
	      * and get the parent cpeid */

	      /* Allocate the IID for this manageable device */
	     if(ifx_get_IID(&entry->iid, IFX_MGMT_SERVER_PARAMETERKEY) != IFX_SUCCESS) {
	         IFX_DBG("\nIn Function [%s] : Failed to get the iid !!\n\n", __FUNCTION__);
	         ret = IFX_FAILURE;
	         goto IFX_Handler;
	     }
	 }

	 /**************** Name Value Formation as per RC.CONF ********************/
	 /* Form the FVP from the given structure for ADD/MODIFY
	  * Operations
	  */
	 count = 0;
	 if(IFX_DELETE_F_NOT_SET(flags)) {

	     sprintf(array_fvp[count].fieldname, "%s", "cpeId");
	     sprintf(array_fvp[count].value, "%d", entry->iid.cpeId.Id);
	     count++;

	     sprintf(array_fvp[count].fieldname, "%s", "pcpeId");
	     sprintf(array_fvp[count].value, "%d", entry->iid.pcpeId.Id);
	     count++;

	     sprintf(array_fvp[count].fieldname, "%s", IFX_MANAGEABLE_DEVICE_MANUFACTUREROUI);
	     sprintf(array_fvp[count].value, "%s", entry->oui);
	     count++;

	     sprintf(array_fvp[count].fieldname, "%s", IFX_MANAGEABLE_DEVICE_PRODUCTCLASS);
	     sprintf(array_fvp[count].value, "%s", entry->product_class);
	     count++;

	     sprintf(array_fvp[count].fieldname, "%s", IFX_MANAGEABLE_DEVICE_SERIALNUMBER);
	     sprintf(array_fvp[count].value, "%s", entry->serial_number);
	     count++;

	     sprintf(array_fvp[count].fieldname, "%s", IFX_MANAGEABLE_DEVICE_IPADDR);
	     snprintf(array_fvp[count].value,MAX_TAG_VALUE_LEN,"%s", entry->ipaddr);
	     //strncpy(array_fvp[count].value, inet_ntoa(entry->ipaddr),	(MAX_IP_ADDR_LEN));
	     count++;

	           passed_index = -1;
	    }
	    else {
	    /* For Delete operation set the count based on the qos mode */
	        count = 6;
	    }

	    /* Get the existing configuration Index in case of modify/delete operations from CPEID */
	    if((IFX_MODIFY_F_SET(flags)) ||
	        (IFX_DELETE_F_SET(flags))) {
	        if(ifx_get_index_from_cpe_id(FILE_RC_CONF, &entry->iid.cpeId,
	                     &passed_index) != IFX_SUCCESS) {
	            IFX_DBG("\n\n In function [%s] : Error--> cpeId [%d] not found in section !! \n\n",
	                    __FUNCTION__, entry->iid.cpeId.Id);
#ifdef DEBUG_STMT
	            system("echo \"failed to get index from cpeid for static route!!\" >> /tmp/error_log");
#endif
	            ret = IFX_FAILURE;
	            goto IFX_Handler;
	        }
	    }

	    /* Determine the new configuration index - for Add
	     * Add/Modify - form the fully qualified Name value pairs from array_fvp
	     * Delete -read the fully qualified Name value pairs from rc.conf
	     * Fill array_fvp[] */
	    if(ifx_get_conf_index_and_nv_pairs(&entry->iid, passed_index, IFX_MANAGEABLE_DEVICE_SECTION_PREFIX,
	                count, array_fvp, flags) != IFX_SUCCESS) {
	            IFX_DBG("\n\n In function [%s] : Error--> Duplicate entry !! \n\n", __FUNCTION__);
#ifdef DEBUG_STMT
	            system("echo \"failed to form fqnv for manageable device!!\" >> /tmp/error_log");
#endif
	            ret = IFX_FAILURE;
	            goto IFX_Handler;
	    }
	    /************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	    if(IFX_ADD_F_NOT_SET(flags)) {
	        CHECK_ACL_RET(entry->iid, count, array_fvp,
	                        changed_count, array_changed_fvp, flags, IFX_Handler)
	    }
#ifdef DEBUG_STMT
	    system("echo \"acl done !!\" >> /tmp/error_log");
#endif


	    /************** System Config File Update Block ****************/
	    snprintf(sbuf, strlen(CHKPOINT_FILE2) + 6, "rm -f %s", CHKPOINT_FILE2);
	    system(sbuf);

	    /* Backup rc.conf before proceeding with configuration */
	    CHECKPOINT_RET(flags, FILE_RC_CONF, CHKPOINT_FILE, IFX_Handler)

	    /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	    form_cfgdb_buf(conf_buf, count, array_fvp);

	    /* RC.CONF Configuration block */
	    ret = ifx_SetObjData(FILE_RC_CONF, IFX_MANAGEABLE_DEVICE_SECTION, flags, 1, conf_buf);

	    /* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
	    if(ret != IFX_SUCCESS) {
	        ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE, flags | IFX_F_INT_DONT_RESTART_SERVICES, IFX_Handler)
#ifdef DEBUG_STMT
	        system("echo \"SetCfgData failed !!\" >> /tmp/error_log");
#endif
	    }

	    /* this will Compact the section and also update the count for both ADD and DELETE */
	    if(IFX_MODIFY_F_NOT_SET(flags))
	        ifx_CompactCfgSection(FILE_RC_CONF, IFX_MANAGEABLE_DEVICE_SECTION, flags);

#ifdef DEBUG_STMT
	    system("echo \"system config done !!\" >> /tmp/error_log");
#endif
	  /*********** Notification Block *************/
	  /* Notify the Internal TR69 Stack in case of MODIFY */

	  /*********** Epilog Block **************/
	  /* Update the IID mappings in the mappings section for ADD/DELETE */
	  if(IFX_MODIFY_F_SET(flags)) {

	      		CHECK_N_SEND_NOTIFICATION(entry->iid, changed_count, array_changed_fvp, flags, IFX_Handler)
	  }
	  else if (IFX_INT_ADD_F_SET(flags)) {

		      /* In case of ADD operation, first update the ID Mappings
		       * and then send the Notification for the attributes
		       */
		      /*********** Epilog Block **************/
		      UPDATE_ID_MAP_N_ATTRIBUTES(&entry->iid, count, array_fvp, flags, IFX_Handler)

		      CHECK_N_SEND_NOTIFICATION(entry->iid, count, array_fvp, flags, IFX_Handler)

		      /* Manipulate nextCpeId only for ADD operations */
		      ifx_increment_next_cpeId(FILE_RC_CONF, IFX_MANAGEABLE_DEVICE_SECTION);

	  }
	  else if (IFX_DELETE_F_SET(flags)) {

		      /* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		       * and then send the Notification for the attributes
		       */
		      /*********** Epilog Block **************/
		      CHECK_N_SEND_NOTIFICATION(entry->iid, count, array_fvp, flags, IFX_Handler)

		      UPDATE_ID_MAP_N_ATTRIBUTES(&entry->iid, count, array_fvp, flags, IFX_Handler)
	  }


	  /* Updating Persistent Storage */
	  ret = ifx_config_write(FILE_RC_CONF, flags);
	  if(ret != IFX_SUCCESS) {
	      ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE, flags | IFX_F_INT_DONT_RESTART_SERVICES, IFX_Handler)
	  }

	IFX_Handler:

	    IFX_MEM_FREE(array_changed_fvp);
	    if(ret != IFX_SUCCESS)
	        return ret;
	    else
#endif
#endif
	        return IFX_SUCCESS;
}

int32 ifx_get_all_dhcp_option(int32 *numEntries, DHCP_OPTION **dhcp_option, uint32 flags)
{
#ifdef DEVICE_SUPPORT
#ifdef IFX_TR69_DEVICE_LAN
        int32   ret = IFX_SUCCESS, nCount = 0, i = 0;
        char8   sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN];
        uint32  outFlag = IFX_F_DEFAULT;

        MAKE_SECTION_COUNT_TAG(TAG_DHCP_OPTION, buf);
        if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_DHCP_OPTION,
                                                        buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                goto IFX_Handler;
        }

        nCount = atoi(sValue);
        if (nCount == 0) {
                *numEntries = 0;
                *dhcp_option = NULL;
                goto IFX_Handler;
        }

        *dhcp_option = NULL;
        IFX_MEM_ALLOC((*dhcp_option), DHCP_OPTION *, nCount, sizeof(DHCP_OPTION))

        for (i=0; i < nCount; i++) {
                /* get the cpeid of this instance */
                sprintf(buf, "%s_%d_cpeId", PREFIX_DHCP_OPTION, i);
                if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_DHCP_OPTION,
                                                buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                        goto IFX_Handler;
                }
                (*dhcp_option + i)->iid.cpeId.Id = atoi(sValue);

                if((ret = ifx_get_dhcp_option((*dhcp_option + i), flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d] failed to get main params for instance dhcp_option%d",
                                                        __FUNCTION__, __LINE__, i);
#endif
                        goto IFX_Handler;
                }
        }
        *numEntries = nCount;

IFX_Handler:
        if(ret != IFX_SUCCESS) {
                IFX_MEM_FREE(*dhcp_option)
                IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
                return ret;
        }
        else
#endif
#endif
                return IFX_SUCCESS;
}


int32 ifx_get_dhcp_option(DHCP_OPTION *dhcp_option, uint32 flags)
{
#ifdef DEVICE_SUPPORT
#ifdef IFX_TR69_DEVICE_LAN
        int32   passed_index = -1, ret = IFX_SUCCESS, count = 0; 
        char8   sBuf[MAX_FILELINE_LEN], *sValue = NULL;
        IFX_NAME_VALUE_PAIR     array_fvp[DHCP_OPTION_PARAM_COUNT + 1];

        sprintf(dhcp_option->iid.cpeId.secName, "%s", TAG_DHCP_OPTION);

        /* get index from cpeid */
        IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, dhcp_option->iid.cpeId, passed_index)

        sprintf(sBuf, "%s_%d_", PREFIX_DHCP_OPTION, passed_index);
        if((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_DHCP_OPTION, sBuf, flags, &sValue)) != IFX_SUCCESS) {
                /*
                if(ret == IFX_E_UNMATCHED_INPUT) {
                        continue;
                }
                 */
#ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                goto IFX_Handler;
        }

        memset(array_fvp, 0x00, sizeof(array_fvp));
        form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);

        dhcp_option->iid.cpeId.Id = atoi(array_fvp[0].value);
        dhcp_option->iid.pcpeId.Id = atoi(array_fvp[1].value);
        dhcp_option->enable = (char8)atoi(array_fvp[2].value);
        dhcp_option->request = (char8)atoi(array_fvp[3].value);
        dhcp_option->tag = (uint8)atoi(array_fvp[4].value);
        strcpy(dhcp_option->value,array_fvp[5].value);

IFX_Handler:
        IFX_MEM_FREE(sValue)
        if(ret != IFX_SUCCESS) {
                IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
                return ret;
        }
        else
#endif
#endif
                return IFX_SUCCESS;
}

int32 ifx_set_dhcp_option(uint32 operation, DHCP_OPTION *dhcp_option, uint32 flags)
{
#ifdef DEVICE_SUPPORT
#ifdef IFX_TR69_DEVICE_LAN
        char8   conf_buf[MAX_DATA_LEN];
        int32   count = 0, changed_count = 0, passed_index = -1, ret = IFX_SUCCESS;
        IFX_NAME_VALUE_PAIR array_fvp[DHCP_OPTION_PARAM_COUNT + 1], *array_changed_fvp = NULL;

    memset(array_fvp, 0, sizeof(array_fvp));
    NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));


        /*************** Prolog Block *********************/
        /* Based on operation (ADD or DELETE or MODIFY)
         * append the flag with internal flags */
        if (operation == IFX_OP_DEL)
                flags |= IFX_F_DELETE;
        else if (operation == IFX_OP_ADD) {
                if( (IFX_MODIFY_F_NOT_SET(flags)))
                        flags |= IFX_F_INT_ADD;
        }
        else
                flags |= IFX_F_MODIFY;

        sprintf(dhcp_option->iid.cpeId.secName, "%s", TAG_DHCP_OPTION);
        sprintf(dhcp_option->iid.pcpeId.secName, "%s", TAG_LAN_MAIN);


        /**************** Validation Block *****************/
        /* For Operations other than DELETE do the verification of input params */
        if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
                /* Do simple validation of pointer such as NULL */
                IFX_VALIDATE_PTR(dhcp_option)
                /* Do simple validation of flags sucha as less than 0 */
                IFX_VALIDATE_FLAGS(flags)
        }


        /**************** ID Allocation Block - Only for ADD Operation **************/
        if (IFX_ADD_F_SET(flags)) {
                if(ifx_get_IID(&dhcp_option->iid, "req") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                        ret = IFX_FAILURE;
                        goto IFX_Handler;
                }
    }

        /**************** Name Value Formation as per RC.CONF ********************/
        /* Form the FVP from the given structure for ADD/MODIFY
         * Operations
         */
        count = 0;
        if(IFX_DELETE_F_NOT_SET(flags)) {
                ifx_fill_ArrayFvp_FName(array_fvp, 0, DHCP_OPTION_PARAM_COUNT, dhcp_opt_params);

                ifx_fill_ArrayFvp_intValues(array_fvp, 0, 2, &dhcp_option->iid.cpeId.Id, &dhcp_option->iid.pcpeId.Id);
                sprintf(array_fvp[2].value, "%d", dhcp_option->enable);
                sprintf(array_fvp[3].value, "%d", dhcp_option->request);
                sprintf(array_fvp[4].value, "%d", dhcp_option->tag);
//                ifx_fill_ArrayFvp_strValues(array_fvp, 5, 1, dhcp_option->value);
                sprintf(array_fvp[5].value, "%s", dhcp_option->value);

                passed_index = -1;
        }

        count = DHCP_OPTION_PARAM_COUNT;

        /* Get Config Index in case of modify/delete operations from CPEID */
        if((IFX_MODIFY_F_SET(flags)) ||
                (IFX_DELETE_F_SET(flags))) {
                IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, dhcp_option->iid.cpeId, passed_index)
        }

        /* Determine the configuration index - for Add, Delete, Modify operations
     * Name is partial since index is not known
     * Fill array_fvp[] */
        if(ifx_get_conf_index_and_nv_pairs(&dhcp_option->iid, passed_index, PREFIX_DHCP_OPTION,
                                count, array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                        ret = IFX_FAILURE;
                        goto IFX_Handler;
        }


        /************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
        if(IFX_ADD_F_NOT_SET(flags)) {
                CHECK_ACL_RET(dhcp_option->iid, count, array_fvp,
                                                changed_count, array_changed_fvp, flags, IFX_Handler)
        }


        /* before config file update, for modify or delete operation stop this  */
        if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
                IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
                (IFX_DELETE_F_SET(flags) || IFX_MODIFY_F_SET(flags))) {

        }


        /************** System Config File Update Block ****************/
        /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
        form_cfgdb_buf(conf_buf, count, array_fvp);

        /* RC.CONF Configuration block */
        ret = ifx_SetObjData(FILE_RC_CONF, TAG_DHCP_OPTION, flags, 1, conf_buf);

        if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                goto IFX_Handler;
        }


        /*********** Device Configuration Block ****************/
        /* Device config thru Scripts/Utilities or Functions */
        /* after config file update, for modify or add operation start all ap/vap */
        if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
                IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
                (IFX_INT_ADD_F_SET(flags) || IFX_MODIFY_F_SET(flags))) {
        }


        /* this will Compact the section and also update the count for both ADD and DELETE */
        if(IFX_MODIFY_F_NOT_SET(flags))
                ifx_CompactCfgSection(FILE_RC_CONF, TAG_DHCP_OPTION, flags);


        /*********** Notification Block *************/
        /* Notify the Internal TR69 Stack in case of MODIFY */

        /*********** Epilog Block **************/
        /* Update the IID mappings in the mappings section for ADD/DELETE */
        if(IFX_MODIFY_F_SET(flags)) {
                CHECK_N_SEND_NOTIFICATION(dhcp_option->iid, changed_count, array_changed_fvp, flags, IFX_Handler)
        }
        else if (IFX_INT_ADD_F_SET(flags)) {
                /* In case of ADD operation, first update the ID Mappings
                 * and then send the Notification for the attributes
                 */
                /*********** Epilog Block **************/
                UPDATE_ID_MAP_N_ATTRIBUTES(&dhcp_option->iid, count, array_fvp, flags, IFX_Handler)

                CHECK_N_SEND_NOTIFICATION(dhcp_option->iid, count, array_fvp, flags, IFX_Handler)

                /* Manipulate nextCpeId only for ADD operations */
                ifx_increment_next_cpeId(FILE_RC_CONF, TAG_DHCP_OPTION);
        }
        else if (IFX_DELETE_F_SET(flags)) {
                /* In case of DELETE operation, first send the notificatioupdate the ID Mappings
                 * and then send the Notification for the attributes
                 */
                /*********** Epilog Block **************/
                CHECK_N_SEND_NOTIFICATION(dhcp_option->iid, count, array_fvp, flags, IFX_Handler)

                UPDATE_ID_MAP_N_ATTRIBUTES(&dhcp_option->iid, count, array_fvp, flags, IFX_Handler)
        }


        /* Updating Persistent Storage */
        ret = ifx_config_write(FILE_RC_CONF, flags);
        if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                goto IFX_Handler;
        }


IFX_Handler:
        IFX_MEM_FREE(array_changed_fvp);
        if(ret != IFX_SUCCESS) {
                IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
                return ret;
        }
        else
#endif
#endif
                return IFX_SUCCESS;
}

int32 ifx_get_dhcp_option_count(uint32 *count)
{
#ifdef DEVICE_SUPPORT
#ifdef IFX_TR69_DEVICE_LAN
        uint32  outFlag = IFX_F_DEFAULT;
        char8   sValue[MAX_FILELINE_LEN];

        sValue[0]='\0';
        *count = 0;
        if(ifx_GetObjData(FILE_RC_CONF, TAG_DHCP_OPTION, "dhcp_opt_Count", IFX_F_GET_ANY, &outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                return IFX_FAILURE;
        }
        *count = atoi(sValue);

#endif
#endif
        return IFX_SUCCESS;
}




