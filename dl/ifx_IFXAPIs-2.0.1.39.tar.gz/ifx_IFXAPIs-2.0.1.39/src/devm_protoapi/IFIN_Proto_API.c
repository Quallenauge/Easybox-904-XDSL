
/* 
** =============================================================================
** FILE NAME     : IFIN_Proto_API.c
** PROJECT       : TR69
** MODULES       : Protocol API
** DATE          : 25-Apr-2006
** AUTHOR        : TR69 team
** DESCRIPTION   : This implements the Protocol API. It interfaces with the
**                 platform specific low level Management API (API to
**                 manipulate rc.conf) and the TR69 task using FIFOs.
** REFERENCES    : DDD-TR69-ProtocolAPI.doc
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author      $Comment
** 25-Apr-2006 TR69 team    Initial Version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "../common/ifx_common.h"
#include "IFIN_Proto_API.h"
#include "ifx_os.h" /* Required for FIFO open/close API */
#include "ifx_ipc.h" /* Required for FIFO send/recv API and FIFO macros */
#include <errno.h>
#include <string.h>

#define IFX_PROTOAPI_CloseFifo(x) if(x!=-1) IFX_OS_CloseFifo(x);

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
/* NOTE: The whole attribute section logic changes if these default values
   change */
#define IFX_ACL_DEFAULT                       IFX_ACL_ALLOWED
#define IFX_NOTIFY_DEFAULT                    IFX_NOTIFY_NOT
#define IFX_CHANGE_FLAG_DEFAULT               IFX_CHANGE_FLAG_CLEAR
#define IFX_PARAM_TYPE_DEFAULT                IFX_PARAM_TYPE_RO
#define IFX_DEVM_INDICATOR_DEFAULT            IFX_DEVM_INDICATOR_CLEAR
#define IFX_PARAM_OID_DEFAULT                 0
#define IFX_PARAM_VALUE_DEFAULT               "" /* NULL String */

#define IFX_TR69_MAP_SECTION_TAG              "tr69_map"
#define IFX_TR69_SECTION_TAG_PREFIX           "tr69"
#define IFX_TR69_SECTIONS_SECTION_TAG         "tr69_sections"
#define IFX_TR69_INSTANCE_SECTION_TAG         "tr69_instances"

#define IFX_DYN_DEVM_SECTION                  "devm"
#define IFX_DEVM_BOOT                         "boot"
#define IFX_DEVM_RESET                        "reset"

#ifndef HOSTENV
#define IFX_DEVM_CONF                         "/etc/tr69/devm.conf"
#else
#define IFX_DEVM_CONF                         "devm.conf"
#endif

#define IFX_DEVM_CONF_SECTION                 "devm_conf"
#define IFX_MAX_GET_PARAM_VAL                 "max_get_param_val"
#define IFX_MAX_GET_ATTR_VAL                  "max_get_attr_val"
#define IFX_MAX_GET_PARAM_NAMES               "max_get_param_names"
#define IFX_RPC_SCHED_INFORM                  "rpc_sched_inform"
#define IFX_RPC_ADD_OBJ                       "rpc add_obj"
#define IFX_RPC_DEL_OBJ                       "rpc_del_obj"
#define IFX_RPC_FACT_RESET                    "rpc_fact_reset"
#define IFX_RPC_UPLOAD                        "rpc_upload"


#define IFX_ATTR_INFO_F_MODIFY_ACL_NOTIFY     IFX_ATTR_INFO_F_MODIFY_ACL | \
                                              IFX_ATTR_INFO_F_MODIFY_NOTIFY
#define IFX_ASCII_FOR_ZERO                    48


// #ifdef IFX_DBG
// #undef IFX_DBG
// #define IFX_DBG(fmt, args...) printf(fmt, ##args)
// #endif

/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/
extern char8 vcOsModId;
extern int   errno;


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/
static int32 fillDefaultAttrInfo(INOUT IFX_AttrInfo *pxAttrInfo);
static int32 extractFillAttrInfo(INOUT IFX_AttrInfo *pxAttrInfo, char8 *pcBuff);
static char8 *getAttrName(INOUT char8 *pcBuff);
static char8 *getAttrValue(INOUT char8 *pcBuff);
static int32 chkNotificationReporting(IN char8 *pcBuff);
static int32 getParamOidFromAttrValue(IN char8 *pcBuff);
static int32 chkNotificationReporting_n_RWTypeStatus(IN char8 *pcBuff,
                                                     OUT int32 *piType);


/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : fillDefaultAttrInfo
**
**   Description      : This function fills the default values of attributes.
**
**   Parameters       : pxAttrInfo - Pointer to the attribute information
**                      structure, the members of which are filled by function.
**                      uiFlags and sParamTag members are not filled. Other
**                      members are filled to default values.
**
**   Return Value     : IFX_SUCCESS - If requested operation is successful.
**                      IFX_FAILURE ( or other error codes) - If requested
**                      operation is not successful.
**
**   Notes            : 
**
** ============================================================================
*/
static int32 fillDefaultAttrInfo(INOUT IFX_AttrInfo *pxAttrInfo)
{
    int32  iRet = IFX_SUCCESS;

    /* Check for validity of input parameters */
    if (!pxAttrInfo)
    {
        IFX_DBG("[%s:%s:%d] [Error] Invalid input parameters\n",
                    __FILE__, __func__, __LINE__);
        iRet = ERR_MAPI_INVAL_INPUT_PARAM;
        goto cleanup;
    }

    pxAttrInfo->ucACL        = IFX_ACL_DEFAULT;
    pxAttrInfo->ucNotify     = IFX_NOTIFY_DEFAULT;
    pxAttrInfo->ucChangeFlag = IFX_CHANGE_FLAG_DEFAULT;
    pxAttrInfo->ucParamType  = IFX_PARAM_TYPE_DEFAULT;
    pxAttrInfo->ucDevMInd    = IFX_DEVM_INDICATOR_DEFAULT;
    pxAttrInfo->iParamOid    = IFX_PARAM_OID_DEFAULT;
    strcpy(pxAttrInfo->sParamVal, IFX_PARAM_VALUE_DEFAULT);

cleanup:
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : extractFillAttrInfo
**
**   Description      : This function parses the buffer and extracts attribute
**                      information and fills the values of members of attribute
**                      information structure with the extracted information.
**
**   Parameters       : pxAttrInfo - Pointer to the attribute information
**                      structure, whose members are to be filled. uiFlags and
**                      sParamTag members are not filled.
**                      pcBuff - Buffer containing attribute information.
**
**   Return Value     : IFX_SUCCESS - If requested operation is successful.
**                      IFX_FAILURE ( or other error codes) - If requested
**                      operation is not successful.
**
**   Notes            : 
**
** ============================================================================
*/
static int32 extractFillAttrInfo(INOUT IFX_AttrInfo *pxAttrInfo, char8 *pcBuff)
{
    int32 iRet = IFX_SUCCESS;
    char8 *pcTmp1;
    char8 *pcTmp2;

    pxAttrInfo->ucACL        = (uint32)atoi(pcBuff + 0);
    pxAttrInfo->ucNotify     = (uint32)atoi(pcBuff + 2);
    pxAttrInfo->ucChangeFlag = (uint32)atoi(pcBuff + 4);
    pxAttrInfo->ucParamType  = (uint32)atoi(pcBuff + 6);
    pxAttrInfo->ucDevMInd    = (uint32)atoi(pcBuff + 8);
    pxAttrInfo->iParamOid    =  atoi(pcBuff + 10);

    /* Check if Param Value is present. The value is present if there is an
       occurance of ',' */
    pcTmp2 = strstr(pcBuff + 10,"\"\n");
    pcTmp1 = strchr(pcBuff + 10,',');

    if ((pcTmp1 < pcTmp2) && (pcTmp1))
    {
        /* Value present, so find the end of the value */
        pcTmp2 = strstr(pcTmp1 + 1,"\"\n");
        /* Position to the start of value */
        pcTmp1++;
        memcpy(pxAttrInfo->sParamVal, pcTmp1, pcTmp2 - pcTmp1);
        *((pxAttrInfo->sParamVal) + (pcTmp2 - pcTmp1)) = '\0';
    }
    else
    {
        /* Value not present, so return Null string */
        strcpy(pxAttrInfo->sParamVal,IFX_PARAM_VALUE_DEFAULT);
    }
 
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : getAttrName
**
**   Description      : This function parses the buffer and extracts attribute
**                      name. It modifies the original buffer.
**
**   Parameters       : pcBuff - Buffer containing attribute information.
**
**   Return Value     : Pointer to the string containing attribute name. 
**
**   Notes            : 
**
** ============================================================================
*/
static char8 *getAttrName(INOUT char8 *pcBuff)
{
    char8 *pcTmp;

    pcTmp = strstr(pcBuff,"=\"");

    /* Replace '=' by '\0' so that a string is returned */
    if(pcTmp != NULL)
        *pcTmp = '\0';
    return (pcBuff);
}

/* 
** =============================================================================
**   Function Name    : getAttrValue
**
**   Description      : This function parses the buffer and extracts string
**                      containing the attribute values. It modifies the original
**                      buffer.
**
**   Parameters       : pcBuff - Buffer containing attribute information.
**
**   Return Value     : Pointer to the string containing attribute values. 
**
**   Notes            : 
**
** ============================================================================
*/
static char8 *getAttrValue(INOUT char8 *pcBuff)
{
    char8 *pcTmp;

    pcTmp = strstr(pcBuff,"\"\n");

    /* Replace '\"' by '\0' so that a string is returned */
    if(pcTmp != NULL)
        *pcTmp = '\0';
    return (pcBuff);
}

/* 
** =============================================================================
**   Function Name    : chkNotificationReporting
**
**   Description      : This function parses the buffer containing attribute
**                      values and checks if notification reporting has to be
**                      done.
**
**   Parameters       : pcBuff - Buffer containing attribute values.
**
**   Return Value     : IFX_SUCCESS - If notification reporting is required.
**                      IFX_FAILURE - If notification reporting is not 
**                      required.
**
**   Notes            : 
**
** ============================================================================
*/
static int32 chkNotificationReporting(IN char8 *pcBuff)
{
    uchar8 ucNotify;
    uchar8 ucChangeFlag;
    uchar8 ucParamType;

    /* Extract the values required to identify if notification reporting is
       required */
    ucNotify     = (uint32)atoi(pcBuff + 2);
    ucChangeFlag = (uint32)atoi(pcBuff + 4);
    ucParamType  = (uint32)atoi(pcBuff + 6);

    /* Process based on Param Type */
    if (ucParamType == IFX_PARAM_TYPE_RW)
    {
        /* Return success(0) only if notification is enabled and
           change flag is set */
        if (((ucNotify == IFX_NOTIFY_PASSIVE) || (ucNotify == IFX_NOTIFY_ACTIVE))
            && (ucChangeFlag == IFX_CHANGE_FLAG_SET))
            return IFX_SUCCESS;
        else
            return IFX_FAILURE;
    }
    else
    {
        /* Return success(0) only if notification is enabled */
        if ((ucNotify == IFX_NOTIFY_PASSIVE) || (ucNotify == IFX_NOTIFY_ACTIVE))
            return IFX_SUCCESS;
        else
            return IFX_FAILURE;
    }
}

/*
** =============================================================================
**   Function Name    : chkNotificationReporting_n_RWTypeStatus
**
**   Description      : This function parses the buffer containing attribute
**                      values and checks if notification reporting has to be
**                      done. Also it tells of the parameter was of type RW
**                      notification enabled and change flag set.
**
**   Parameters       : pcBuff - Buffer containing attribute values.
**                      iType - Will be filled by function to 1 if parameter
**                      is of type RW having notification enabled and
**                      change flag set.
**
**   Return Value     : IFX_SUCCESS - If notification reporting is required
**                      IFX_FAILURE - If notification reporting is not
**                      required.
**
**   Notes            :
**
** ============================================================================
*/
static int32 chkNotificationReporting_n_RWTypeStatus(IN char8 *pcBuff,
                                                     OUT int32 *piType)
{
    uchar8 ucNotify;
    uchar8 ucChangeFlag;
    uchar8 ucParamType;

    /* Extract the values required to identify if notification reporting is
       required */
    ucNotify     = (uint32)atoi(pcBuff + 2);
    ucChangeFlag = (uint32)atoi(pcBuff + 4);
    ucParamType  = (uint32)atoi(pcBuff + 6);

    /* Process based on Param Type */
    if (ucParamType == IFX_PARAM_TYPE_RW)
    {
        /* Return success(0) only if notification is enabled and
           change flag is set */
        if (((ucNotify == IFX_NOTIFY_PASSIVE) ||(ucNotify == IFX_NOTIFY_ACTIVE))
            && (ucChangeFlag == IFX_CHANGE_FLAG_SET))
        {
            *piType = 1;
            return IFX_SUCCESS;
        }
        else
            return IFX_FAILURE;
    }
    else
    {
        /* Return success(0) only if notification is enabled */
        if ((ucNotify == IFX_NOTIFY_PASSIVE) || (ucNotify == IFX_NOTIFY_ACTIVE))
            return IFX_SUCCESS;
        else
            return IFX_FAILURE;
    }
}
/* 
** =============================================================================
**   Function Name    : getParamOidFromAttrValue
**
**   Description      : This function parses the buffer containing attribute
**                      values and extracts the parameter ID.
**
**   Parameters       : pcBuff - Buffer containing attribute values.
**
**   Return Value     : Parameter ID 
**
**   Notes            : 
**
** ============================================================================
*/
static int32 getParamOidFromAttrValue(IN char8 *pcBuff)
{
    int32  iParamOid;

    iParamOid = atoi(pcBuff + 10); 
    return (iParamOid);
}

/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : IFX_AllocTr69Id
**
**   Description      : This function takes the CPE ID of the parent, section
**                      name of the child and subsection name of the child if
**                      available and returns the TR69 ID for the child. It
**                      relies on the TR69 task for giving the TR69 ID for the
**                      child object.
**
**   Parameters       : pxIfxId - The xParentCpeId, sSectionTag of xCpeId and
**                      uiConfigOwner members of IFX_Id structure must be filled
**                      by caller. sTr69Id member of IFX_Id will be filled by
**                      the function.
**                      psChildSubSecTag - The child sub section tag, if present
**                      must be passed by the caller. If not present, it must be
**                      NULL.
**
**   Return Value     : IFX_SUCCESS - If allocation is successful.
**                      IFX_FAILURE ( or other error codes) - If allocation
**                      is not successful.
**
**   Notes            : 
**
** ============================================================================
*/
int32 IFX_AllocTr69Id(INOUT IFX_Id *pxIfxId, IN char8 *psChildSubSecTag)
{
    int32  iRet = IFX_SUCCESS;
    int32  iWrFd = -1;
    int32  iRdFd = -1;
    IFX_Id xIfxId;
    char8  acMsg[IFX_IPC_MAX_MSG_SIZE] = { 0 };
    uint16 uiMsgSize;
    char8  cRet;
    uchar8 ucFrom = 0;
    uchar8 ucTo;
    uint32 uiReserved;
    char8  cErr;
    fd_set xRdFdSet;
    int32  iSelRtn;
    struct timeval xTV;

    /* Check for validity of input parameters */
    if (!pxIfxId)
    {
        iRet = ERR_MAPI_INVAL_INPUT_PARAM;
        IFX_DBG("[%s:%d] [%d] Invalid input parameters\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Form an IFX_Id structure for the parent */
    xIfxId.xCpeId = pxIfxId->xParentCpeId;

    /* Get the parent TR69 ID */
    iRet = IFX_GetTr69IdFromCpeId(&xIfxId);

    /* Check for error */
    if (iRet != IFX_SUCCESS)
    {
        IFX_DBG("[%s:%d] [%d] Error in getting TR69 ID\n",
                    __func__, __LINE__,iRet);
        goto cleanup;
    }

    /* Get the message size */
    if (!psChildSubSecTag)
    {
        uiMsgSize = strlen(xIfxId.sTr69Id) + 1 +
                    strlen(pxIfxId->xCpeId.sSectionTag) + 1;
    }
    else
    {
        uiMsgSize = strlen(xIfxId.sTr69Id) + 1 +
                    strlen(pxIfxId->xCpeId.sSectionTag) + 1 +
                    strlen(psChildSubSecTag) + 1;
    }

    /* Check if the message size is fitting in the buffer */
    if (uiMsgSize > IFX_IPC_MAX_MSG_SIZE)
    {
        IFX_DBG("[%s:%d] [##########Critical] Message is big to be "
                     "handled by FIFO\n",
                    __func__, __LINE__);
        iRet = IFX_FAILURE;
        goto cleanup;
    }

    /* Form the Message */
    if (!psChildSubSecTag)
    {
        strcpy(acMsg,xIfxId.sTr69Id);
        strcpy(acMsg + (strlen(xIfxId.sTr69Id) + 1), pxIfxId->xCpeId.sSectionTag);
    }
    else
    {
        strcpy(acMsg,xIfxId.sTr69Id);
        strcpy(acMsg + (strlen(xIfxId.sTr69Id) + 1), pxIfxId->xCpeId.sSectionTag);
        strcpy(acMsg + (strlen(xIfxId.sTr69Id) + 1 +
               strlen(pxIfxId->xCpeId.sSectionTag) + 1), psChildSubSecTag);
    }

    /* Open a /tmp/nontr FIFO in read mode to receive messages from TR69 task */
    iRdFd = IFX_OS_OpenFifo((uchar8 *)IFX_IPC_PROTO_API_FIFO , O_RDWR); 

    /* Check for error */
    if (iRdFd < 0)
    {
        iRet = ERR_MAPI_FIFO_OPEN;
        IFX_DBG("[%s:%d] [%d] Error in opening the FIFO %s for "
                    "reading\n",__func__, __LINE__, iRet, IFX_IPC_PROTO_API_FIFO);
        goto cleanup;
    }

    /* Open a /tmp/tr FIFO in write mode to send messages to TR69 task */
    iWrFd = IFX_OS_OpenFifo((uchar8 *)IFX_IPC_TR_FIFO , O_RDWR); 

    /* Check for error */
    if (iWrFd < 0)
    {
        iRet = ERR_MAPI_FIFO_OPEN;
        IFX_DBG("[%s:%d] [%d] Error in opening the FIFO %s for "
                 "writing\n",__func__, __LINE__, iRet, IFX_IPC_TR_FIFO);
        goto cleanup;
    }

    /* Post a message to TR69 task */
    cRet = IFX_IPC_SendMsg(iWrFd, (uchar8)IFX_IPC_APP_ID_GET_TR69ID,
                           (uchar8)0, uiMsgSize, pxIfxId->uiConfigOwner, acMsg);

    /* Check for error */
    if (cRet != IFX_IPC_SUCCESS)
    {
        iRet = ERR_MAPI_FIFO_WRITE;
        IFX_DBG("[%s:%d] [%d] Error in Sending Message\n",
                 __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Block for specified timeout for receiving message */
    FD_ZERO(&xRdFdSet);
    FD_SET(iRdFd, &xRdFdSet);
    xTV.tv_sec = IFX_TR69_PROTO_API_TIMEOUT_IN_SEC; 
    xTV.tv_usec = 0;

    /* Wait for specified timeout */
    iSelRtn = select(iRdFd + 1, &xRdFdSet, NULL, NULL, &xTV);

    /* Check for error */
    if (iSelRtn <= 0)
    {
       int iErr;
        iErr = errno;
        iRet = ERR_MAPI_TIMEOUT;
        IFX_DBG("[%s:%d] [%d] Error in Receiving Message. "
                "Sel Rtn Val = %d . Errno = %d\n",
                __func__, __LINE__, iRet, iSelRtn, iErr);
        goto cleanup;
    }

    /* Receive message from TR69 task */
    cRet = IFX_IPC_RecvMsg(iRdFd, &ucFrom, &ucTo, &uiMsgSize,
                           &uiReserved, acMsg, &cErr);

    /* Check for error */
    if (cRet != IFX_IPC_SUCCESS)
    {
        iRet = ERR_MAPI_FIFO_READ;
        IFX_DBG("[%s:%d] [%d] Error in Receiving Message\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    if (ucFrom != IFX_IPC_APP_ID_GET_TR69ID)
    {
        iRet = ERR_MAPI_FIFO_INVAL_MSG;
        IFX_DBG("[%s:%d] [%d] Invalid Message Received\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    if (strlen(acMsg) && (strlen(acMsg) < IFX_MAX_TR69_ID_LEN))
    {
        /* Copy the received child TR69 Id to the allocated area */
        strlcpy(pxIfxId->sTr69Id, acMsg,IFX_MAX_TR69_ID_LEN);
    }
    else
    {
        iRet = IFX_FAILURE;
        IFX_DBG("[%s:%d] [%d] Unable to allocate TR69 ID for child\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    /* Close the FIFO's */
    IFX_PROTOAPI_CloseFifo(iWrFd);
    IFX_PROTOAPI_CloseFifo(iRdFd);
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : IFX_UpdateTr69CpeIdMap
**
**   Description      : This function takes the section name, CPE ID, TR69 ID
**                      and the operation to be performed i.e. add or delete.
**                      Based on the operation it either adds the entry into
**                      section or deletes the entry from section.
**
**   Parameters       : pxIfxId - The xCpeId and sTr69Id members of IFX_ID need
**                      to be filled by the caller.
**                      uiOper - The operation can be either ADD or DELETE.
**
**   Return Value     : IFX_SUCCESS - If requested operation is successful.
**                      IFX_FAILURE ( or other error codes) - If requested
**                      operation is not successful.
**
**   Notes            : 
**
** ============================================================================
*/
int32 IFX_UpdateTr69CpeIdMap(IN IFX_Id *pxIfxId, IN uint32 uiOper)
{
    int32  iRet = IFX_SUCCESS;
    int32  iRtn = IFX_SUCCESS;
    char8  sCpeId[12] = { 0 }; /* Maximum CpeId value */
    uint32 uiLineSize;
    char8  sLine[MAX_FILELINE_LEN] = { 0 };
    uint32 uiActionFlag;

    /* Check for the validity of input parameters */
    if (!pxIfxId) 
    {
        iRet = ERR_MAPI_INVAL_INPUT_PARAM;
        IFX_DBG("[%s:%d] [%d] Invalid input parameters\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the CPE ID in string format */
    sprintf(sCpeId, "%u", pxIfxId->xCpeId.uiId);

    /* Get the size of the line to be written */
    /* NOTE: 1 is added since I am using sprintf */
    uiLineSize = (strlen(pxIfxId->xCpeId.sSectionTag) + strlen("_") + strlen(sCpeId)
                  + strlen("=")
                  + strlen("\"") + strlen(pxIfxId->sTr69Id) + strlen("\"")
                  + strlen("\n") + 1);

    /* Check if the whole line can be written */
    if (uiLineSize > MAX_FILELINE_LEN)
    {
        IFX_DBG("[%s:%d] [##########Critical] Line is big to be stored\n",
                    __func__, __LINE__);
        iRet = IFX_FAILURE;
        goto cleanup;
    } 

    /* Form the line */
    memset(sLine,'\0',sizeof(sLine));
    snprintf(sLine,sizeof(sLine),"%s_%s=\"%s\"\n", pxIfxId->xCpeId.sSectionTag, sCpeId,
            pxIfxId->sTr69Id);

    switch(uiOper)
    {
        case IFX_TR69ID_MAP_TBL_OPER_ADD_ENTRY:
            /* Returns failure if the entry already exists */

            /* Set the flag for adding new entry */
            uiActionFlag = IFX_F_INT_ADD | IFX_F_DONT_ACTIVATE;

            /* Write to database */
            iRtn = ifx_SetObjData(DB_FILE, IFX_TR69_MAP_SECTION_TAG,
                                  uiActionFlag, 1, sLine);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                iRet = IFX_FAILURE;
                IFX_DBG("%s:%d [%d] Unable to add entry to %s '%s'\n",
                        __FUNCTION__,__LINE__, iRet, IFX_TR69_MAP_SECTION_TAG, sLine);
                goto cleanup;
            }
            break;
        case IFX_TR69ID_MAP_TBL_OPER_DEL_ENTRY:
            /* Even if the requested entry is not present, delete
               returns success. */

            /* Set the flag for deleting entry */
            uiActionFlag = IFX_F_DELETE;

            /* Write to database */
            iRtn = ifx_SetObjData(DB_FILE, IFX_TR69_MAP_SECTION_TAG,
                                  uiActionFlag, 1, sLine);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                iRet = IFX_FAILURE;
                IFX_DBG("%s:%d [%d] Unable to delete entry from %s '%s'\n",
                        __FUNCTION__,__LINE__, iRet, IFX_TR69_MAP_SECTION_TAG, sLine);
                goto cleanup;
            }
            break;
        default:
            iRet = ERR_MAPI_INVAL_OPER;
            IFX_DBG("[%s:%d] [%d] Invalid operation requested on %s\n",
                        __func__, __LINE__, iRet, IFX_TR69_MAP_SECTION_TAG);
            break;
    }

cleanup:
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : IFX_GetTr69IdFromCpeId
**
**   Description      : This function takes the CPE ID and returns TR69 ID.
**
**   Parameters       : pxIfxId - The xCpeId member need to be filled by caller.
**                      sTr69Id member will be filled by the function.
**
**   Return Value     : IFX_SUCCESS - If requested operation is successful.
**                      IFX_FAILURE ( or other error codes) - If requested
**                      operation is not successful.
**
**   Notes            : 
**
** ============================================================================
*/
int32 IFX_GetTr69IdFromCpeId(INOUT IFX_Id *pxIfxId)
{
    int32  iRet = IFX_SUCCESS;
    int32  iRtn = IFX_SUCCESS;
    char8  sCpeId[12] = { 0 }; /* Maximum CpeId value */
    char8  sLine[MAX_FILELINE_LEN] = { 0 };
    uint32 uiNameSize;
    char8  sName[MAX_FILELINE_LEN] = { 0 };
    uint32 uiInFlag;
    uint32 uiOutFlag = 0; /* Changed from uint32 to unsigned lont just to remove warning */

    /* Check for the validity of input parameters */
    if (!pxIfxId) 
    {
        iRet = ERR_MAPI_INVAL_INPUT_PARAM;
        IFX_DBG("[%s:%d] [%d] Invalid input parameters\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the CPE ID in string format */
    sprintf(sCpeId, "%u", pxIfxId->xCpeId.uiId);

    /* Get the size of the name */
    /* NOTE: 1 is added since I am using sprintf */
    uiNameSize = (strlen(pxIfxId->xCpeId.sSectionTag) + strlen("_")
                  + strlen(sCpeId) + 1);

    /* Check if name fits in the buffer */
    if (uiNameSize >= MAX_FILELINE_LEN)
    {
        IFX_DBG("[%s:%d] [##########Critical] Name is big to be stored\n",
                    __func__, __LINE__);
        iRet = IFX_FAILURE;
        goto cleanup;
    } 

    /* Form the name */
    sprintf(sName, "%s_%s", pxIfxId->xCpeId.sSectionTag, sCpeId);
    /* Set the flag for getting TR69 ID */
    uiInFlag = IFX_F_GET_DIS;

    /* Get from the database */
    memset(sLine,'\0',sizeof(sLine));
    iRtn = ifx_GetObjData(DB_FILE, IFX_TR69_MAP_SECTION_TAG, sName,
                          uiInFlag, &uiOutFlag, sLine);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        if (iRtn == IFX_E_PARAM_NOT_FOUND)
        {
            iRet = ERR_MAPI_NOT_FOUND;
        }
        else
        {
            iRet = IFX_FAILURE;
        }

        IFX_DBG("[%s:%d] [%d] Unable to get TR69 Id for [%s] from %s\n",
                    __func__, __LINE__, iRet, sName, IFX_TR69_MAP_SECTION_TAG);
        goto cleanup;
    }

    /* Copy the TR69 Id to the allocated area */
    if(sLine !=NULL )
    strlcpy(pxIfxId->sTr69Id, sLine,IFX_MAX_TR69_ID_LEN);
cleanup:
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : IFX_GetCpeIdFromTr69Id
**
**   Description      : Since an object can be divided into multiple sections
**                      and CPE ID is unique across section, this function takes
**                      the TR69 ID and returns a list of CPE IDs.
**
**   Parameters       : sTr69Id - TR69 ID for which list of CPE IDs have to be
**                      fetched.
**                      puiNumCpeId - Indicates the number of entries that
**                      correspond to the TR69 ID. This will be filled by the
**                      function.
**                      ppxCpeIdArray - List of all the CPE IDs that correspond
**                      to the TR69 ID. Allocation will be done by the function
**                      and has to be freed by the caller.
**
**   Return Value     : IFX_SUCCESS - If requested operation is successful.
**                      IFX_FAILURE ( or other error codes) - If requested
**                      operation is not successful.
**
**   Notes            : 
**
** ============================================================================
*/
int32 IFX_GetCpeIdFromTr69Id(IN char8 sTr69Id[IFX_MAX_TR69_ID_LEN],
                              OUT uint32 *puiNumCpeId,
                              OUT IFX_CpeId **ppxCpeIdArray)
{
    int32  iRet                     = IFX_SUCCESS;
    int32  iRtn                     = IFX_SUCCESS;
    char8  *pcObjBuff               = NULL; /* Mandatory */
    char8  *pcTmp1                  = NULL;
    char8  *pcTmp2                  = NULL;
    char8  *pcTmp3                  = NULL;
    char8  *pcTmp4                  = NULL;
    uint32 uiCount                  = 0; /* Mandatory */
    uint32 uiI                      = 0;
    IFX_CpeId *pxCpeIdArray         = NULL; /* Mandatory */
    uint32 uiDataSize;
    char8  sData[MAX_FILELINE_LEN]  = { 0 };
    uint32 uiStateFlag;

    /* Check for the validity of input parameters */
    if (!sTr69Id || !ppxCpeIdArray || !puiNumCpeId) 
    {
        iRet = ERR_MAPI_INVAL_INPUT_PARAM;
        IFX_DBG("[%s:%d] [%d] Invalid input parameters\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Set the flag for getting CPE ID */
    uiStateFlag = IFX_F_GET_DIS;

    /* NOTE: ifxGetCfgObject also returns failure if no entries
       are present in the section. In that case it returns
       pcObjBuff as NULL. */
    /* Get all the values from the database */
    iRtn = ifx_GetCfgObject(DB_FILE, IFX_TR69_MAP_SECTION_TAG, NULL,
                            uiStateFlag, &pcObjBuff);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {
        if (iRtn == IFX_E_SEC_EMPTY)
        {
            iRet = ERR_MAPI_NOT_FOUND;
        }
        else
        {
            iRet = IFX_FAILURE;
        }

        IFX_DBG("[%s:%d] [%d] Unable to get CPE Id for %s from %s\n",
                    __func__, __LINE__, iRet, sTr69Id, IFX_TR69_MAP_SECTION_TAG);

        goto cleanup;
    }

    /* Get the size of the value */
    /* NOTE: 1 is added since I am using sprintf */
    uiDataSize = (strlen("\"") + strlen(sTr69Id) + strlen("\"") +  1);

    /* Check if name fits in the buffer */
    if (uiDataSize >= MAX_FILELINE_LEN)
    {
        IFX_DBG("[%s:%d] [##########Critical] Name is big to be stored\n",
                    __func__, __LINE__);
        iRet = IFX_FAILURE;
        goto cleanup;
    } 

    /* Form the data */
    sprintf(sData, "\"%s\"", sTr69Id);

    /* Get the count of the number of entries in the Object Buffer that have
       same TR69 ID */
    pcTmp1 = pcObjBuff;

    while (pcTmp1)
    {
        pcTmp1 = strstr(pcTmp1, sData);

        if (pcTmp1)
        {
            uiCount++;
            pcTmp1++;
        }
    }

    /* Check if entries exist in the Object Buffer */
    if(!uiCount)
    {
        iRet = ERR_MAPI_NOT_FOUND;
        IFX_DBG("[%s:%d] [%d] Unable to get CPE Id for %s from %s\n",
                    __func__, __LINE__, iRet, sTr69Id, IFX_TR69_MAP_SECTION_TAG);
        goto cleanup;
    }

    /* Allocate for the found entries */
    pxCpeIdArray = (IFX_CpeId *)IFX_MALLOC(sizeof(IFX_CpeId) * uiCount);

    /* Check for error */
    if(!pxCpeIdArray)
    {
        iRet = ERR_MAPI_OUT_OF_MEMORY;
        IFX_DBG("[%s:%d] [%d] Allocation failure for CPE Id Array\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Search for entries in the Object Buffer and fill the allocated
       IFX_CpeId array with the values */
    pcTmp1 = pcObjBuff;

    for (uiI = 0; uiI < uiCount; uiI++)
    {
        pcTmp2 = strstr(pcTmp1, sData);
        if(pcTmp2 == NULL)
        {
		iRet = IFX_FAILURE;
		goto cleanup;
	}
	*(pcTmp2 - 1) = '\0';
        pcTmp3 = strrchr(pcTmp1, '\n');

        if (!pcTmp3)
        {
            pcTmp3 = pcTmp1;
        }
        else
        {
            pcTmp3 = pcTmp3 + 1;
        }

        pcTmp4  = strrchr(pcTmp3, '_');
        if(pcTmp4 != NULL)
            *pcTmp4 = '\0';
        pcTmp4++;
        strcpy(pxCpeIdArray[uiI].sSectionTag, pcTmp3);
        /* Convert the CPE Id from string to integer and return it to
           requested area */
        pxCpeIdArray[uiI].uiId = (uint32)atoi(pcTmp4);
        pcTmp1 = pcTmp2 + 1;
    }

    /* Fill the user requested data */
    *puiNumCpeId   = uiCount;
    *ppxCpeIdArray = pxCpeIdArray;
    pxCpeIdArray   = NULL;
cleanup:
    IFX_FREE(pcObjBuff);
    IFX_FREE(pxCpeIdArray);
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : IFX_ChkACL
**
**   Description      : This function takes the CPE ID and a list of parameters
**                      for which the state of access control attribute is to be
**                      checked whether it is allowed. If all the parameters
**                      have access control attribute set to allowed then this
**                      function returns success.
**
**   Parameters       : pxCpeId - Uniquely helps in identifying object instance.
**                      uiNumNV - Count stating the number of parameters for
**                      which the state of access control is to be checked.
**                      pxNVArray - List of all the parameters whose access
**                      control attribute is to be checked for allowed state.
**
**   Return Value     : IFX_SUCCESS - If access control is allowed for all
**                      the requested parameters.
**                      IFX_FAILURE ( or other error codes) - If access
**                      control is not allowed for atleast one parameter.
**
**   Notes            : 
**
** ============================================================================
*/
int32 IFX_ChkACL(IN IFX_CpeId *pxCpeId, IN uint32 uiNumNV,
                  IN IFX_NameValue *pxNVArray)
{
    int32        iRet             = IFX_SUCCESS;
    IFX_AttrInfo *pxAttrInfoArray = NULL; /* Mandatory */
    uint32       uiI;

    /* Check for the validity of input parameters */
    if (!pxCpeId || !pxNVArray || !uiNumNV) 
    {
        iRet = ERR_MAPI_INVAL_INPUT_PARAM;
        IFX_DBG("[%s:%d] [%d] Invalid input parameters\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Allocate for the IFX_AttrInfo array */
    pxAttrInfoArray = (IFX_AttrInfo *)IFX_MALLOC(sizeof(IFX_AttrInfo) *
                                                       uiNumNV);

    /* Check for error */
    if (!pxAttrInfoArray)
    {
        iRet = ERR_MAPI_OUT_OF_MEMORY;
        IFX_DBG("[%s:%d] [%d] Allocation failure for IFX_AttrInfo\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Fill the IFX_AttrInfo array */
    for (uiI = 0; uiI < uiNumNV; uiI++)
    {
        strcpy(pxAttrInfoArray[uiI].sParamTag, pxNVArray[uiI].sName);
    }

    /* Get the attribute values */
    iRet = IFX_GetAttrInfo(pxCpeId, uiNumNV,  pxAttrInfoArray);

    /* Check for error */
    if (iRet != IFX_SUCCESS)
    {
        IFX_DBG("[%s:%d] [%d] Error in getting Attributes\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Check for ACL */
    for (uiI = 0; uiI < uiNumNV; uiI++)
    {
        if (pxAttrInfoArray[uiI].ucACL != IFX_ACL_ALLOWED)
        {
            iRet = IFX_FAILURE;
            IFX_DBG("[%s:%d] [%d] Acces not allowed for %s\n",
                        __func__, __LINE__, iRet, pxAttrInfoArray[uiI].sParamTag);
            goto cleanup;
        }
    }

cleanup:
    IFX_FREE(pxAttrInfoArray);
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : IFX_SendNotify
**
**   Description      : This function takes the CPE ID of object instance and
**                      operation to be performed on that object instance. If
**                      operation is MODIFY, it also takes a list of parameters
**                      that are modified. If the operation is ADD or DELETE it
**                      notifies TR69 task about addition or deletion of object.
**                      If operation is MODIFY it checks the parameter attribute
**                      section and finds out if any notification is enabled for
**                      those parameters. For all parameters that have active
**                      notification enabled it notifies the TR69 task about
**                      active notification to be sent and also sets the change
**                      flag attribute for those parameters. For all parameters
**                      that have passive notification enabled, it sets change 
**                      flag attribute for those parameters.
**
**   Parameters       : pxIfxId - xCpeId and uiConfigOwner members of IFX_Id
**                      structure must be filled by caller. The CPE ID is that
**                      of object instance that is added, deleted or parameters
**                      of which are modified.
**                      uiNumNV - Number of parameters in the following list of
**                      parameters only if operation is MODIFY. If operation is
**                      ADD or DELETE, this is 0 (actually dont care).
**                      pxNVArray - List of parameters that are modified only if
**                      operation is MODIFY. Only sName member of each element
**                      of array has to be filled by caller. If operation is ADD
**                      or DELETE, this is NULL (actually dont care).
**                      uiOper . Operation to be carried out. The operation can
**                      be ADD, Modify or DELETE.
**
**   Return Value     : IFX_SUCCESS - If notification is successful.
**                      IFX_FAILURE ( or other error codes) - If
**                      notification fails.
**
**   Notes            : 
**
** ============================================================================
*/
int32 IFX_SendNotify(IN IFX_Id *pxIfxId, IN uint32 uiNumNV,
                      IN IFX_NameValue *pxNVArray, IN uint32 uiOper)
{
    int32        iRet                        = IFX_SUCCESS;
    IFX_AttrInfo *pxAttrInfoArray            = NULL; /* Mandatory */
    char8        acMsg[IFX_IPC_MAX_MSG_SIZE] = { 0 };
    uint16       uiMsgSize;
    int32        iRdFd = -1;
    int32        iWrFd = -1;
    char8        cRet;
    IFX_Id       xIfxId;
    uint32       uiI;
    uint32       uiNotifyFlag = 0; /* Mandatory */
    uint32       uiDevMInd = 0; /* Mandatory */
    uchar8       ucFrom;
    uchar8       ucTo;
    uint32       uiReserved;
    char8        cErr;
    fd_set       xRdFdSet;
    int32        iSelRtn;
    struct       timeval xTV;
    char8        sParamOid[12]; /* Maximum Param Oid value */



    /* Check for validity of input parameters */
    if (!pxIfxId || ((uiOper == IFX_NOTIFY_OPER_MODIFY) && ((!pxNVArray) || (!uiNumNV))))
    {
        iRet = ERR_MAPI_INVAL_INPUT_PARAM;
        IFX_DBG("[%s:%d] [%d] Invalid input parameters\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    switch(uiOper)
    {
        case IFX_NOTIFY_OPER_ADD:
        case IFX_NOTIFY_OPER_DEL:

            /* Fill the IFX_Id structure with IFX_CpeId */
            xIfxId.xCpeId = pxIfxId->xCpeId;

            /* Get the TR69 ID for the Object that is added or deleted*/
            iRet = IFX_GetTr69IdFromCpeId(&xIfxId);

            /* Check for error */
            if (iRet != IFX_SUCCESS)
            {
                IFX_DBG("[%s:%d] [%d] Error in getting TR69 ID\n",
                            __func__, __LINE__, iRet);
                goto cleanup;
            }

            /* Get the message size */
            uiMsgSize = strlen(xIfxId.sTr69Id) + 1;

            if (uiMsgSize > IFX_IPC_MAX_MSG_SIZE)
            {
                IFX_DBG("[%s:%d] [##########Critical] Message is big to be "
                            "handled by FIFO\n", __func__, __LINE__);
                iRet = IFX_FAILURE;
                goto cleanup;
            }

            /* Form the Message */
            strcpy(acMsg,xIfxId.sTr69Id);

            /* Open a /tmp/nontr FIFO in read mode to receive messages from TR69 task */
            iRdFd = IFX_OS_OpenFifo((uchar8 *)IFX_IPC_PROTO_API_FIFO , O_RDWR); 

            /* Check for error */
            if (iRdFd < 0)
            {
                iRet = ERR_MAPI_FIFO_OPEN;
                IFX_DBG("[%s:%d] [%d] Error in opening the FIFO %s for "
                            "reading\n",__func__, __LINE__, iRet, IFX_IPC_PROTO_API_FIFO);
                goto cleanup;
            }

            /* Open a /tmp/tr FIFO in write mode to send messages to TR69 task */
            iWrFd = IFX_OS_OpenFifo((uchar8 *)IFX_IPC_TR_FIFO , O_RDWR); 

            /* Check for error */
            if (iWrFd < 0)
            {
                iRet = ERR_MAPI_FIFO_OPEN;
                IFX_DBG("[%s:%d] [%d] Error in opening the FIFO %s for "
                         "writing\n",__func__, __LINE__, iRet, IFX_IPC_TR_FIFO);
                goto cleanup;
            }

            if (uiOper == IFX_NOTIFY_OPER_ADD)
            {
                /* Post a message to TR69 task */
                cRet = IFX_IPC_SendMsg(iWrFd, (uchar8)IFX_IPC_APP_ID_ADD_OBJ,
                                       (uchar8)0, uiMsgSize, pxIfxId->uiConfigOwner, acMsg);
            }
            else
            {
                /* Post a message to TR69 task */
                cRet = IFX_IPC_SendMsg(iWrFd, (uchar8)IFX_IPC_APP_ID_DEL_NOTIFY,
                                       (uchar8)0, uiMsgSize, pxIfxId->uiConfigOwner, acMsg);
            }

            /* Check for error */
            if (cRet != IFX_IPC_SUCCESS)
            {
                iRet = ERR_MAPI_FIFO_WRITE;
                IFX_DBG("[%s:%d] [%d] Error in Sending Message\n",
                         __func__, __LINE__, iRet);
                goto cleanup;
            }


            /* Block for specified timeout for receiving message */
            FD_ZERO(&xRdFdSet);
            FD_SET(iRdFd, &xRdFdSet);
            xTV.tv_sec = IFX_TR69_PROTO_API_TIMEOUT_IN_SEC; 
            xTV.tv_usec = 0;

            /* Wait for specified timeout */
            iSelRtn = select(iRdFd + 1, &xRdFdSet, NULL, NULL, &xTV);

            /* Check for error */
            if (iSelRtn <= 0)
            {
                iRet = ERR_MAPI_TIMEOUT;
                IFX_DBG("[%s:%d] [%d] Error in Receiving Message\n",
                            __func__, __LINE__, iRet);
                goto cleanup;
            }

            /* Receive message from TR69 task */
            cRet = IFX_IPC_RecvMsg(iRdFd, &ucFrom, &ucTo, &uiMsgSize,
                                   &uiReserved, acMsg, &cErr);

            /* Check for error */
            if (cRet != IFX_IPC_SUCCESS)
            {
                iRet = ERR_MAPI_FIFO_READ;
                IFX_DBG("[%s:%d] [%d] Error in Receiving Message\n",
                            __func__, __LINE__, iRet);
                goto cleanup;
            }

            if (uiOper == IFX_NOTIFY_OPER_ADD)
            {
                if (ucFrom != IFX_IPC_APP_ID_ADD_OBJ)
                {
                    iRet = ERR_MAPI_FIFO_INVAL_MSG;
                    IFX_DBG("[%s:%d] [%d] Invalid Message Received\n",
                                __func__, __LINE__, iRet);
                    goto cleanup;
                }

                /* If uiReserved is set to 1, that indicates that deletion is
                   successful */
                if (!uiReserved)
                {
                    iRet = IFX_FAILURE;
                    IFX_DBG("[%s:%d] [%d] Post Add Operations Failed\n",
                                __func__, __LINE__, iRet);
                    goto cleanup;
                }

            }
            else
            {
                if (ucFrom != IFX_IPC_APP_ID_DEL_NOTIFY)
                {
                    iRet = ERR_MAPI_FIFO_INVAL_MSG;
                    IFX_DBG("[%s:%d] [%d] Invalid Message Received\n",
                                __func__, __LINE__, iRet);
                    goto cleanup;
                }

                /* If uiReserved is set to 1, that indicates that deletion is
                   successful */
                if (!uiReserved)
                {
                    iRet = IFX_FAILURE;
                    IFX_DBG("[%s:%d] [%d] Post Delete Operations Failed\n",
                                __func__, __LINE__, iRet);
                    goto cleanup;
                }
           }
            break;
        case IFX_NOTIFY_OPER_MODIFY:
            /* Allocate for the IFX_AttrInfo array */
            pxAttrInfoArray = (IFX_AttrInfo *)
                              IFX_MALLOC(sizeof(IFX_AttrInfo) * uiNumNV);

            /* Check for error */
            if (!pxAttrInfoArray)
            {
                iRet = ERR_MAPI_OUT_OF_MEMORY;
                IFX_DBG("[%s:%d] [%d] Allocation failure for IFX_AttrInfo\n",
                            __func__, __LINE__, iRet);
                goto cleanup;
            }

            /* Fill the IFX_AttrInfo array */
            for (uiI = 0; uiI < uiNumNV; uiI++)
            {
                strcpy(pxAttrInfoArray[uiI].sParamTag, pxNVArray[uiI].sName);
            }

            /* Get the attribute values */
            iRet = IFX_GetAttrInfo(&(pxIfxId->xCpeId), uiNumNV,  pxAttrInfoArray);

            /* Check for error */
            if (iRet != IFX_SUCCESS)
            {
                IFX_DBG("[%s:%d] [%d] Error in getting Attributes\n",
                            __func__, __LINE__, iRet);
                goto cleanup;
            }

            /* Fill the IFX_Id structure with IFX_CpeId */
            xIfxId.xCpeId = pxIfxId->xCpeId;

            /* Get the TR69 ID for the Object to be deleted */
            iRet = IFX_GetTr69IdFromCpeId(&xIfxId);

            /* Check for error */
            if (iRet != IFX_SUCCESS)
            {
                IFX_DBG("[%s:%d] [%d] Error in getting TR69 ID\n",
                            __func__, __LINE__, iRet);
                goto cleanup;
            }

            /* Get the message size */
            uiMsgSize = strlen(xIfxId.sTr69Id) + 1;

            /* Check if the message size is fitting in the buffer */
            if (uiMsgSize > IFX_IPC_MAX_MSG_SIZE)
            {
                IFX_DBG("[%s:%d] [##########Critical] Message is big to be "
                             "handled by FIFO\n", __func__, __LINE__);
                iRet = IFX_FAILURE;
                goto cleanup;
            }

            /* Start forming the Message */
            strcpy(acMsg,xIfxId.sTr69Id);

            /* Check for Notification and perform accordingly. In case of Active
               Notification, set the notification flag and Change flag. In case
               of Passive Notification, set the Change flag. */
            for (uiI = 0; uiI < uiNumNV; uiI++)
            {

                pxAttrInfoArray[uiI].uiFlags =
                                     IFX_ATTR_INFO_F_MODIFY_CHANGE_FLAG;

                switch(pxAttrInfoArray[uiI].ucNotify)
                {
                    case IFX_NOTIFY_ACTIVE:
                        /* Set the notify flag */
                        uiNotifyFlag = 1;
                        pxAttrInfoArray[uiI].ucChangeFlag = IFX_CHANGE_FLAG_SET; 

                        break;
                    case IFX_NOTIFY_PASSIVE:
                        pxAttrInfoArray[uiI].ucChangeFlag = IFX_CHANGE_FLAG_SET; 
                        break;
                    default:
                        /* Nothing to be done */
                        break;
                }

                /* If DevM indicator is set then set the Indicator */
                if (pxAttrInfoArray[uiI].ucDevMInd == IFX_DEVM_INDICATOR_SET)
                {
                        uiDevMInd = 1;

                       /* Form the Param Oid string */
                       sprintf(sParamOid,"%d",pxAttrInfoArray[uiI].iParamOid);

                      /* TBD: Currently any time the message becomes more than
                         the FIFO size, we return error. This can be fixed
                         later by sending multiple messages */
                      /* Get the message size */
                      uiMsgSize += strlen(sParamOid) + 1;

                      /* Check if the message size is fitting in the buffer */
                      if (uiMsgSize > IFX_IPC_MAX_MSG_SIZE)
                      {
                          iRet = IFX_FAILURE;
                          goto cleanup;
                      }

                      /* Append to the Message */
                      strcpy(acMsg + (uiMsgSize - (strlen(sParamOid) + 1)),
                             sParamOid);
                }

            }
            /* Write to the database, so that the change flag is set for
               entries for which Notification is enabled */
            iRet = IFX_UpdateAttrInfo(&(pxIfxId->xCpeId), uiNumNV,pxAttrInfoArray);

            /* Check for error */
            if (iRet != IFX_SUCCESS)
            {
                IFX_DBG("[%s:%d] [%d] Unable to set change flag for "
                            "entries whose Notification is enabled\n",
                            __func__, __LINE__, iRet);
                goto cleanup;
            }

            /* Notify the TR69 task if required */
            if (uiNotifyFlag || uiDevMInd)
            {

                /* Open a /tmp/tr FIFO in write mode to send messages to TR69 task */
                iWrFd = IFX_OS_OpenFifo((uchar8 *)IFX_IPC_TR_FIFO , O_RDWR); 

                /* Check for error */
                if (iWrFd < 0)
                {
                    iRet = ERR_MAPI_FIFO_OPEN;
                    IFX_DBG("[%s:%d] [%d] Error in opening the FIFO %s for "
                             "writing\n",__func__, __LINE__, iRet, IFX_IPC_TR_FIFO);
                    goto cleanup;
                }

                if (uiNotifyFlag && uiDevMInd)
                  /* Post a message to TR69 task */
                  cRet = IFX_IPC_SendMsg(iWrFd, (uchar8)IFX_IPC_APP_ID_NOTIFY_INDICATOR,
                                         (uchar8)0, uiMsgSize, pxIfxId->uiConfigOwner, acMsg);
               else
               {
                 if (uiNotifyFlag)
                  /* Post a message to TR69 task */
                  cRet = IFX_IPC_SendMsg(iWrFd, (uchar8)IFX_IPC_APP_ID_ACTIVE_NOTIFY,
                                         (uchar8)0, uiMsgSize, pxIfxId->uiConfigOwner, acMsg);
                 else
                  /* Post a message to TR69 task */
                  cRet = IFX_IPC_SendMsg(iWrFd, (uchar8)IFX_IPC_APP_ID_DEVM_INDICATOR,
                                         (uchar8)0, uiMsgSize, pxIfxId->uiConfigOwner, acMsg);
               }

                /* Check for error */
                if (cRet != IFX_IPC_SUCCESS)
                {
                    iRet = ERR_MAPI_FIFO_WRITE;
                    IFX_DBG("[%s:%d] [%d] Error in Sending Message\n",
                             __func__, __LINE__, iRet);
                    goto cleanup;
                }
            }

            break;
        default:
            iRet = ERR_MAPI_INVAL_OPER;
            IFX_DBG("[%s:%d] [%d] Invalid operation requested\n",
                        __func__, __LINE__, iRet);
            break;
    }

cleanup:
    /* Close the FIFO's */
    if ((uiOper == IFX_NOTIFY_OPER_DEL) || (uiOper == IFX_NOTIFY_OPER_ADD))
    {
        IFX_PROTOAPI_CloseFifo(iRdFd);
    }
    IFX_PROTOAPI_CloseFifo(iWrFd);
    IFX_FREE(pxAttrInfoArray);
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : IFX_DeleteObj
**
**   Description      : This function takes the CPE ID of object instance to be
**                      deleted and checks for delete dependency. If the object
**                      instance to be deleted has got any static objects below
**                      it, then these objects are deleted if required. It
**                      relies on TR69 task for actually performing dependency
**                      check and deletion of static objects.
**
**   Parameters       : pxIfxId - The xCpeId and uiConfigOwner members of IFX_Id
**                      structure must be filled by caller. The CPE ID is of the
**                      object instance to be deletedi for which dependency
**                      check is performed.
**
**   Return Value     : IFX_SUCCESS - If delete dependency check is
**                      successful.
**                      IFX_FAILURE ( or other error codes) - If delete
**                      dependency check is not successful.
**
**   Notes            : 
**
** ============================================================================
*/
int32 IFX_DeleteObj(IN IFX_Id *pxIfxId)
{
    int32  iRet                        = IFX_SUCCESS;
    int32  iWrFd = -1;
    int32  iRdFd = -1;
    char8  acMsg[IFX_IPC_MAX_MSG_SIZE] = { 0 };
    uint16 uiMsgSize;
    char8  cRet;
    uchar8 ucFrom;
    uchar8 ucTo;
    uint32 uiReserved;
    char8  cErr;
    IFX_Id xIfxId;
    fd_set xRdFdSet;
    int32  iSelRtn;
    struct timeval xTV;


    /* Check for validity of input parameters */
    if (!pxIfxId)
    {
        iRet = ERR_MAPI_INVAL_INPUT_PARAM;
        IFX_DBG("[%s:%d] [%d] Invalid input parameters\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Form the IFX_Id Structure */
    xIfxId.xCpeId = pxIfxId->xCpeId;

    /* Get the TR69 ID for the Object to be deleted */
    iRet = IFX_GetTr69IdFromCpeId(&xIfxId);

    /* Check for error */
    if (iRet != IFX_SUCCESS)
    {
        IFX_DBG("[%s:%d] [%d] Error in getting TR69 ID\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the message size */
    uiMsgSize = strlen(xIfxId.sTr69Id) + 1;

    /* Check if the message size is fitting in the buffer */
    if (uiMsgSize > IFX_IPC_MAX_MSG_SIZE)
    {
        IFX_DBG("[%s:%d] [##########Critical] Message is big to be "
                    "handled by FIFO\n", __func__, __LINE__);
        iRet = IFX_FAILURE;
        goto cleanup;
    }

    /* Form the Message */
    strcpy(acMsg,xIfxId.sTr69Id);

    /* Open a /tmp/nontr FIFO in read mode to receive messages from TR69 task */
    iRdFd = IFX_OS_OpenFifo((uchar8 *)IFX_IPC_PROTO_API_FIFO , O_RDWR); 

    /* Check for error */
    if (iRdFd < 0)
    {
        iRet = ERR_MAPI_FIFO_OPEN;
        IFX_DBG("[%s:%d] [%d] Error in opening the FIFO %s for "
                    "reading\n",__func__, __LINE__, iRet, IFX_IPC_PROTO_API_FIFO);
        goto cleanup;
    }

    /* Open a /tmp/tr FIFO in write mode to send messages to TR69 task */
    iWrFd = IFX_OS_OpenFifo((uchar8 *)IFX_IPC_TR_FIFO , O_RDWR); 

    /* Check for error */
    if (iWrFd < 0)
    {
        iRet = ERR_MAPI_FIFO_OPEN;
        IFX_DBG("[%s:%d] [%d] Error in opening the FIFO %s for "
                 "writing\n",__func__, __LINE__, iRet, IFX_IPC_TR_FIFO);
        goto cleanup;
    }

    /* Post a message to TR69 task */
    cRet = IFX_IPC_SendMsg(iWrFd, (uchar8)IFX_IPC_APP_ID_DEL_OBJ,
                           (uchar8)0, uiMsgSize, pxIfxId->uiConfigOwner, acMsg);

    /* Check for error */
    if (cRet != IFX_IPC_SUCCESS)
    {
        iRet = ERR_MAPI_FIFO_WRITE;
        IFX_DBG("[%s:%d] [%d] Error in Sending Message\n",
                 __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Block for specified timeout for receiving message */
    FD_ZERO(&xRdFdSet);
    FD_SET(iRdFd, &xRdFdSet);
    xTV.tv_sec = IFX_TR69_PROTO_API_TIMEOUT_IN_SEC; 
    xTV.tv_usec = 0;

    /* Wait for specified timeout */
    iSelRtn = select(iRdFd + 1, &xRdFdSet, NULL, NULL, &xTV);

    /* Check for error */
    if (iSelRtn <= 0)
    {
        iRet = ERR_MAPI_TIMEOUT;
        IFX_DBG("[%s:%d] [%d] Error in Receiving Message\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Receive message from TR69 task */
    cRet = IFX_IPC_RecvMsg(iRdFd, &ucFrom, &ucTo, &uiMsgSize,
                           &uiReserved, acMsg, &cErr);

    /* Check for error */
    if (cRet != IFX_IPC_SUCCESS)
    {
        iRet = ERR_MAPI_FIFO_READ;
        IFX_DBG("[%s:%d] [%d] Error in Receiving Message\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    if (ucFrom != IFX_IPC_APP_ID_DEL_OBJ)
    {
        iRet = ERR_MAPI_FIFO_INVAL_MSG;
        IFX_DBG("[%s:%d] [%d] Invalid Message Received\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* If uiReserved is set to 1, that indicates that deletion is
       successful */
    if (!uiReserved)
    {
        iRet = IFX_FAILURE;
        IFX_DBG("[%s:%d] [%d] Delete Permit Not allowed\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    /* Close the FIFO's */
    IFX_PROTOAPI_CloseFifo(iWrFd);
    IFX_PROTOAPI_CloseFifo(iRdFd);
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : IFX_GetAttrInfo
**
**   Description      : This function takes the CPE ID and a list of parameters
**                      whose attributes are required and returns the attributes
**                      of those parameters. If parameter entry is not present
**                      in the section, its default attributes are returned.
**
**   Parameters       : pxCpeId - Uniquely helps in identifying object instance.
**                      uiNumAttrInfo - Count stating the number of parameters
**                      whose attribute information is required.
**                      pxAttrInfoArray - List of parameters whose attribute
**                      information is required. Only sParamTag member of each
**                      element of the array has to be filled by caller. This
**                      function will fill the attribuites of parameters in this
**                      array. uiFlags member of each element in array is not
**                      filled by the function.
**
**   Return Value     : IFX_SUCCESS - If requested operation is successful.
**                      IFX_FAILURE ( or other error codes) - If requested
**                      operation is not successful.
**
**   Notes            : 
**
** ============================================================================
*/
int32 IFX_GetAttrInfo(IN IFX_CpeId *pxCpeId, IN uint32 uiNumAttrInfo,
                       INOUT IFX_AttrInfo *pxAttrInfoArray)
{
    int32  iRet                     = IFX_SUCCESS;
    int32  iRtn                     = IFX_SUCCESS;
    char8  *pcObjBuff               = NULL; /* Mandatory */
    char8  *pcTmp                   = NULL;
    uint32 uiI                      = 0;
    uint32 uiNameSize;
    char8  sName[MAX_FILELINE_LEN] = { 0 };
    uint32 uiStateFlag;
    char8  sCpeId[12] = { 0 }; /* Maximum CpeId value */

    /* Check for validity of input parameters */
    if (!pxCpeId || !pxAttrInfoArray || !uiNumAttrInfo)
    {
        iRet = ERR_MAPI_INVAL_INPUT_PARAM;
        IFX_DBG("[%s:%d] [%d] Invalid input parameters\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Set the flag for getting the entire object */
    uiStateFlag = IFX_F_GET_DIS;

    /* Form the attribute section name */
    /* NOTE: Here I have assumed that length of section tag sName will always
       be less than the MAX_FILELINE_LEN. Actually check needs to be performed
       here since we are forming a string sName whose size can be larger than
       the sName buffer size. */ 
    sprintf(sName, "%s_%s", IFX_TR69_SECTION_TAG_PREFIX, pxCpeId->sSectionTag);

    /* Get all the values from the database */
    /* NOTE: ifxGetCfgObject also returns failure if no entries
       are present in the section. In that case it returns
       pcObjBuff as NULL. */
    /* Get all the values from the database */
    iRtn = ifx_GetCfgObject(DB_FILE, sName, NULL, uiStateFlag, &pcObjBuff);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        if (iRtn != IFX_E_SEC_EMPTY)
        {
            iRet = IFX_FAILURE;
            IFX_DBG("[%s:%d] [%d] Either section tag not found or also "
                        "can be file related errors or memory related errors\n",
                         __func__, __LINE__, iRet);
        }
        else
        {
            /* If no entries are present, fill the default values */
            for (uiI = 0; uiI < uiNumAttrInfo; uiI++)
            {
                fillDefaultAttrInfo(pxAttrInfoArray + uiI);
            }
        }

        goto cleanup;
    }

    /* Get the CPE ID in string format */
    sprintf(sCpeId, "%u", pxCpeId->uiId);

    /* Iterate */
    for (uiI = 0; uiI < uiNumAttrInfo; uiI++)
    {

        /* Get the size of the name */
        /* NOTE: 1 is added since I am using sprintf */
        uiNameSize = (strlen(pxAttrInfoArray[uiI].sParamTag) + strlen("_")
                      + strlen(sCpeId) + 1);

        /* Check if name fits in the buffer */
        if (uiNameSize >= MAX_FILELINE_LEN)
        {
            IFX_DBG("[%s:%d] [##########Critical] Name is big to be "
                        "stored\n", __func__, __LINE__);
            /* NOTE: This case should never happen. Currently I am not returning
               error but filling the default values. */
            fillDefaultAttrInfo(pxAttrInfoArray + uiI);
            continue;
        } 

        /* Form the name */
        sprintf(sName, "%s_%s=\"", pxAttrInfoArray[uiI].sParamTag, sCpeId);

        /* Check if it is the first element in object buffer. If no,
           the next search can start with '\n' prefixed to the name */
        if (!strncmp(sName,pcObjBuff,strlen(sName)))
        {
            extractFillAttrInfo(pxAttrInfoArray + uiI,
                                pcObjBuff + strlen(sName));
        }
        else
        {
            /* The name is not the first element in object buffer */
            /* Form the name */
            sprintf(sName, "\n%s_%s=\"",pxAttrInfoArray[uiI].sParamTag, sCpeId);

            /* Search for the name in the Object Buffer */
            pcTmp = strstr(pcObjBuff, sName);

            /* Check for error */
            if (!pcTmp)
            {
                /* Name is not present in object buffer. So return default
                   value */
                fillDefaultAttrInfo(pxAttrInfoArray + uiI);
            }
            else
            {
                pcTmp += strlen(sName);
                extractFillAttrInfo(pxAttrInfoArray + uiI, pcTmp);
            }
        }
    }

cleanup:
    IFX_FREE(pcObjBuff);
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : IFX_UpdateAttrInfo
**
**   Description      : This function takes the CPE ID and a list of parameters
**                      whose attributes are to be updated and updates the
**                      attributes of those parameters. Based on flag set for
**                      individual element in the array, corresponding attribute
**                      is updated. Flag can be set for modifying access control
**                      attribute, notification attribute, change flag attribute,
**                      devm indicator or parameter value attribute of element in
**                      array. For any parameter access control and notification
**                      attributes can be modified at one go by ORing respective
**                      flags. There is also special delete flag for explicitly
**                      deleting the entry of the parameter from that section.
**
**   Parameters       : pxCpeId - Uniquely helps in identifying object instance.
**                      uiNumAttrInfo - Count stating the number of parameters
**                      whose attribute information is to be updated.
**                      pxAttrInfoArray - List of all the parameters whose
**                      attribute information is to be updated. The function
**                      will update the attribuite information of parameters in
**                      this array based on flag associated with that parameter.
**                      The sParamTag and uiFlags member of each element of
**                      array has to be filled by the caller. The ucParamType and
**                      iParamOid members of each element of array must be filled
**                      by caller if the uiFlags member has a value of either
**                      IFX_ATTR_INFO_F_MODIFY_ACL,IFX_ATTR_INFO_F_MODIFY_NOTIFY,
**                      IFX_ATTR_INFO_F_MODIFY_ACL_NOTIFY or
**                      IFX_ATTR_INFO_F_MODIFY_DEVM_INDICATOR. Also based on
**                      value of uiFlags member other than IFX_ATTR_INFO_F_DEL,
**                      caller should fill other relevant members of the elements
**                      in array ( Ex: if uiFlags == IFX_ATTR_INFO_F_MODIFY_ACL,
**                      then ucACL member must be filled to either
**                      IFX_ACL_NOT_ALLOWED or IFX_ACL_ALLOWED).
**
**   Return Value     : IFX_SUCCESS - If requested operation is successful.
**                      IFX_FAILURE ( or other error codes) - If requested
**                      operation is not successful.
**
**   Notes            : 
**
** ============================================================================
*/
int32 IFX_UpdateAttrInfo(IN IFX_CpeId *pxCpeId, IN uint32 uiNumAttrInfo,
                         IN IFX_AttrInfo *pxAttrInfoArray)
{
    int32  iRet = IFX_SUCCESS;
    int32  iRtn = IFX_SUCCESS;
    char8  sCpeId[12] = { 0 }; /* Maximum CpeId value */
    char8  sName[MAX_FILELINE_LEN] = { 0 };
    uint32 uiLineSize;
    char8  sLine[MAX_FILELINE_LEN] = { 0 };
    uint32 uiActionFlag;
    IFX_AttrInfo *pxTmpAttrInfoArray = NULL; /* Mandatory */
    uint32 uiI;
    uint32 uiDelFlag = 0; /* Mandatory */
    uint32 uiModifyFlag = 0; /* Mandatory */
    char8  sParamOid[12] = { 0 }; /* Maximum Param Oid value */

    /* Check for the validity of input parameters */
    if (!pxCpeId || !pxAttrInfoArray || !uiNumAttrInfo) 
    {
        iRet = ERR_MAPI_INVAL_INPUT_PARAM;
        IFX_DBG("[%s:%d] [%d] Invalid input parameters\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Allocate for IFX_AttrInfoArray */
    pxTmpAttrInfoArray = (IFX_AttrInfo *)IFX_MALLOC(sizeof(IFX_AttrInfo)
                                                          * uiNumAttrInfo);

    if (!pxTmpAttrInfoArray)
    {
        iRet = ERR_MAPI_OUT_OF_MEMORY;
        IFX_DBG("[%s:%d] [%d] Allocation failure for IFX_AttrInfo\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Fill the IFX_AttrInfo array */
    for (uiI = 0; uiI < uiNumAttrInfo; uiI++)
    {
        strcpy(pxTmpAttrInfoArray[uiI].sParamTag,
               pxAttrInfoArray[uiI].sParamTag);
    }

    /* Get the attribute values */
    iRet = IFX_GetAttrInfo(pxCpeId, uiNumAttrInfo,  pxTmpAttrInfoArray);

    /* Check for error */
    if (iRet != IFX_SUCCESS)
    {
        IFX_DBG("[%s:%d] [%d] Error in getting Attributes\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Form the attribute section name */
    /* NOTE: Here I have assumed that length of section tag sName will always
       be less than the MAX_FILELINE_LEN. Actually check needs to be performed
       here since we are forming a string sName whose size can be larger than
       the sName buffer size. */ 
    sprintf(sName, "%s_%s", IFX_TR69_SECTION_TAG_PREFIX, pxCpeId->sSectionTag);

    /* Get the CPE ID in string format */
    sprintf(sCpeId, "%u", pxCpeId->uiId);

    for (uiI = 0; uiI < uiNumAttrInfo; uiI++)
    {

        /* Form the Param Oid string */
        sprintf(sParamOid,"%d",pxAttrInfoArray[uiI].iParamOid);

        /* Initialize the Modify and Delete flags */
        uiDelFlag = 0;
        uiModifyFlag = 0;

        if ((pxTmpAttrInfoArray[uiI].ucACL == IFX_ACL_DEFAULT) &&
            (pxTmpAttrInfoArray[uiI].ucNotify == IFX_NOTIFY_DEFAULT) &&
            (pxTmpAttrInfoArray[uiI].ucDevMInd == IFX_DEVM_INDICATOR_DEFAULT))
        {
            /* Add the entry */

            switch(pxAttrInfoArray[uiI].uiFlags)
            {

                case IFX_ATTR_INFO_F_MODIFY_ACL:
                    if(pxAttrInfoArray[uiI].ucACL == IFX_ACL_DEFAULT)
                    {
                        continue;
                    }
                    pxTmpAttrInfoArray[uiI].ucACL = pxAttrInfoArray[uiI].ucACL;
                    pxTmpAttrInfoArray[uiI].ucParamType =
                                            pxAttrInfoArray[uiI].ucParamType;
                    break;
                case IFX_ATTR_INFO_F_MODIFY_NOTIFY:
                    if(pxAttrInfoArray[uiI].ucNotify == IFX_NOTIFY_DEFAULT)
                    {
                        continue;
                    }
                    pxTmpAttrInfoArray[uiI].ucNotify =
                                            pxAttrInfoArray[uiI].ucNotify;
                    pxTmpAttrInfoArray[uiI].ucParamType =
                                            pxAttrInfoArray[uiI].ucParamType;
                    break;
                case IFX_ATTR_INFO_F_MODIFY_ACL_NOTIFY:
                    if((pxAttrInfoArray[uiI].ucACL == IFX_ACL_DEFAULT)
                      &&(pxAttrInfoArray[uiI].ucNotify == IFX_NOTIFY_DEFAULT))
                    {
                        continue;
                    }
                    pxTmpAttrInfoArray[uiI].ucACL = pxAttrInfoArray[uiI].ucACL;
                    pxTmpAttrInfoArray[uiI].ucNotify =
                                            pxAttrInfoArray[uiI].ucNotify;
                    pxTmpAttrInfoArray[uiI].ucParamType =
                                            pxAttrInfoArray[uiI].ucParamType;
                    break;
                case IFX_ATTR_INFO_F_MODIFY_DEVM_INDICATOR:
                    if(pxAttrInfoArray[uiI].ucDevMInd == IFX_DEVM_INDICATOR_DEFAULT)
                    {
                        continue;
                    }
                    pxTmpAttrInfoArray[uiI].ucDevMInd =
                                            pxAttrInfoArray[uiI].ucDevMInd;
                    pxTmpAttrInfoArray[uiI].ucParamType =
                                            pxAttrInfoArray[uiI].ucParamType;
                    break;

                default:
                    continue;
            }

            /* Get the size of the line to be written */
            /* NOTE: 1 is added since I am using sprintf */
            uiLineSize = (strlen(pxTmpAttrInfoArray[uiI].sParamTag)
                  + strlen("_") + strlen(sCpeId)
                  + strlen("=")
                  + strlen("\"")
                  + ((5 * 2) - 1) /* Storage for "A,N,C,T,I" */
                  + (strlen(sParamOid) + 1) /* Storage for ",O" */
                  + strlen("\"")
                  + strlen("\n") + 1);

            /* Check if the whole line can be written */
            if (uiLineSize > MAX_FILELINE_LEN)
            {
                IFX_DBG("[%s:%d] [##########Critical] Line is big to be stored\n",
                            __func__, __LINE__);
                iRet = IFX_FAILURE;
                goto cleanup;
            } 

            /* Form the line */
            sprintf(sLine, "%s_%s=\"%d,%d,%d,%d,%d,%s\"\n",
                    pxTmpAttrInfoArray[uiI].sParamTag,
                    sCpeId,
                    pxTmpAttrInfoArray[uiI].ucACL,
                    pxTmpAttrInfoArray[uiI].ucNotify,
                    pxTmpAttrInfoArray[uiI].ucChangeFlag,
                    pxTmpAttrInfoArray[uiI].ucParamType,
                    pxTmpAttrInfoArray[uiI].ucDevMInd,
                    sParamOid);

            /* Set the flag for adding new entry */
            uiActionFlag = IFX_F_INT_ADD | IFX_F_DONT_ACTIVATE;

            /* Write to database */
            iRtn = ifx_SetObjData(DB_FILE, sName,
                                  uiActionFlag, 1, sLine);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                iRet = IFX_FAILURE;
                IFX_DBG("[%s:%d] [%d] Unable to add entry %s to %s\n",
                            __func__, __LINE__, iRet, sLine, sName);
                goto cleanup;
            }

        }
        else
        {
            /* Modify the entry */

            switch(pxAttrInfoArray[uiI].uiFlags)
            {

                case IFX_ATTR_INFO_F_MODIFY_ACL:
                    if((pxTmpAttrInfoArray[uiI].ucNotify == IFX_NOTIFY_DEFAULT)
                      &&(pxTmpAttrInfoArray[uiI].ucDevMInd == IFX_DEVM_INDICATOR_DEFAULT)
                      &&(pxAttrInfoArray[uiI].ucACL == IFX_ACL_DEFAULT))
                    {
                        uiDelFlag = 1;
                        break;
                    }

                    if (pxAttrInfoArray[uiI].ucACL != pxTmpAttrInfoArray[uiI].ucACL)
                    {
                        pxTmpAttrInfoArray[uiI].ucACL = pxAttrInfoArray[uiI].ucACL;
                        uiModifyFlag = 1;
                        break;
                    }
                    break;
                case IFX_ATTR_INFO_F_MODIFY_NOTIFY:
                    if((pxTmpAttrInfoArray[uiI].ucACL == IFX_ACL_DEFAULT)
                      &&(pxTmpAttrInfoArray[uiI].ucDevMInd == IFX_DEVM_INDICATOR_DEFAULT)
                      &&(pxAttrInfoArray[uiI].ucNotify == IFX_NOTIFY_DEFAULT))
                    {
                        uiDelFlag = 1;
                        break;
                    }

                    if (pxAttrInfoArray[uiI].ucNotify != pxTmpAttrInfoArray[uiI].ucNotify)
                    {
                        pxTmpAttrInfoArray[uiI].ucNotify = pxAttrInfoArray[uiI].ucNotify;
                        pxTmpAttrInfoArray[uiI].ucChangeFlag = IFX_CHANGE_FLAG_CLEAR; 
                        uiModifyFlag = 1;
                        break;
                    }
                    break;
                case IFX_ATTR_INFO_F_MODIFY_ACL_NOTIFY:
                    if((pxAttrInfoArray[uiI].ucACL == IFX_ACL_DEFAULT)
                      &&(pxAttrInfoArray[uiI].ucNotify == IFX_NOTIFY_DEFAULT)
                      &&(pxTmpAttrInfoArray[uiI].ucDevMInd == IFX_DEVM_INDICATOR_DEFAULT))
                    {
                        uiDelFlag = 1;
                        break;
                    }
                    if ((pxAttrInfoArray[uiI].ucACL != pxTmpAttrInfoArray[uiI].ucACL) &&
                       (pxAttrInfoArray[uiI].ucNotify != pxTmpAttrInfoArray[uiI].ucNotify))
                    {
                        pxTmpAttrInfoArray[uiI].ucACL = pxAttrInfoArray[uiI].ucACL;
                        pxTmpAttrInfoArray[uiI].ucNotify = pxAttrInfoArray[uiI].ucNotify;
                        pxTmpAttrInfoArray[uiI].ucChangeFlag = IFX_CHANGE_FLAG_CLEAR; 
                        uiModifyFlag = 1;
                        break;
                    }
                    if ((pxAttrInfoArray[uiI].ucACL != pxTmpAttrInfoArray[uiI].ucACL) &&
                       (pxAttrInfoArray[uiI].ucNotify == pxTmpAttrInfoArray[uiI].ucNotify))
                    {
                        pxTmpAttrInfoArray[uiI].ucACL = pxAttrInfoArray[uiI].ucACL;
                        uiModifyFlag = 1;
                        break;
                    }
                    if ((pxAttrInfoArray[uiI].ucACL == pxTmpAttrInfoArray[uiI].ucACL) &&
                       (pxAttrInfoArray[uiI].ucNotify != pxTmpAttrInfoArray[uiI].ucNotify))
                    {
                        pxTmpAttrInfoArray[uiI].ucNotify = pxAttrInfoArray[uiI].ucNotify;
                        pxTmpAttrInfoArray[uiI].ucChangeFlag = IFX_CHANGE_FLAG_CLEAR; 
                        uiModifyFlag = 1;
                        break;
                    }
                    break;
                case IFX_ATTR_INFO_F_MODIFY_CHANGE_FLAG:
                    if ((pxAttrInfoArray[uiI].ucChangeFlag != pxTmpAttrInfoArray[uiI].ucChangeFlag) &&
                        ((pxTmpAttrInfoArray[uiI].ucNotify == IFX_NOTIFY_PASSIVE) ||
                         (pxTmpAttrInfoArray[uiI].ucNotify == IFX_NOTIFY_ACTIVE)))
                    {
                        pxTmpAttrInfoArray[uiI].ucChangeFlag = pxAttrInfoArray[uiI].ucChangeFlag;
                        uiModifyFlag = 1;
                        break;
                    }
                    break;
                case IFX_ATTR_INFO_F_MODIFY_PARAM_VALUE:
                    if(pxTmpAttrInfoArray[uiI].ucParamType == IFX_PARAM_TYPE_RO)
                    {
                        if (strcmp(pxAttrInfoArray[uiI].sParamVal, pxTmpAttrInfoArray[uiI].sParamVal))
                        {
                            strcpy(pxTmpAttrInfoArray[uiI].sParamVal, pxAttrInfoArray[uiI].sParamVal);
                            uiModifyFlag = 1;
                            break;
                        }
                    }
                    break;
                case IFX_ATTR_INFO_F_MODIFY_DEVM_INDICATOR:
                    if((pxTmpAttrInfoArray[uiI].ucNotify == IFX_NOTIFY_DEFAULT)
                      &&(pxTmpAttrInfoArray[uiI].ucACL == IFX_ACL_DEFAULT)
                      &&(pxAttrInfoArray[uiI].ucDevMInd == IFX_DEVM_INDICATOR_DEFAULT))
                    {
                        uiDelFlag = 1;
                        break;
                    }

                    if (pxAttrInfoArray[uiI].ucDevMInd != pxTmpAttrInfoArray[uiI].ucDevMInd)
                    {
                        pxTmpAttrInfoArray[uiI].ucDevMInd = pxAttrInfoArray[uiI].ucDevMInd;
                        uiModifyFlag = 1;
                        break;
                    }
                    break;
                case IFX_ATTR_INFO_F_DEL:
                    uiDelFlag = 1;
                    break;
                default:
                    continue;
            }

            /* If no modification or deletion required, go to the next parameter */
            if ((!uiModifyFlag) && (!uiDelFlag))
            {
                continue;
            }

            /* Get the size of the line to be written */
            /* NOTE: 1 is added since I am using sprintf */
            uiLineSize = (strlen(pxTmpAttrInfoArray[uiI].sParamTag)
                  + strlen("_") + strlen(sCpeId)
                  + strlen("=")
                  + strlen("\"")
                  + ((5 * 2) - 1) /* Storage for "A,N,C,T,I" */
                  + (strlen(sParamOid) + 1) /* Storage for ",O" */
                  + strlen("\"")
                  + strlen("\n") + 1);

            /* Add storage for value */
            if (strlen(pxTmpAttrInfoArray[uiI].sParamVal))
            {
                /* Added storage for "A,N,C,T,I,V" */
                uiLineSize += strlen(",") +
                              strlen(pxTmpAttrInfoArray[uiI].sParamVal);
            }

            /* Check if the whole line can be written */
            if (uiLineSize > MAX_FILELINE_LEN)
            {
                IFX_DBG("[%s:%d] [##########Critical] Line is big to be stored\n",
                            __func__, __LINE__);
                iRet = IFX_FAILURE;
                goto cleanup;
            } 

            if (strlen(pxTmpAttrInfoArray[uiI].sParamVal))
            {
                /* Form the line */
		memset(sLine,'\0',sizeof(sLine));
                snprintf(sLine,sizeof(sLine),"%s_%s=\"%d,%d,%d,%d,%d,%s,%s\"\n",
                        pxTmpAttrInfoArray[uiI].sParamTag,
                        sCpeId,
                        pxTmpAttrInfoArray[uiI].ucACL,
                        pxTmpAttrInfoArray[uiI].ucNotify,
                        pxTmpAttrInfoArray[uiI].ucChangeFlag,
                        pxTmpAttrInfoArray[uiI].ucParamType,
                        pxTmpAttrInfoArray[uiI].ucDevMInd,
                        sParamOid,
                        pxTmpAttrInfoArray[uiI].sParamVal);
            }
            else
            {
                /* Form the line */
		memset(sLine,'\0',sizeof(sLine));
                snprintf(sLine,sizeof(sLine),"%s_%s=\"%d,%d,%d,%d,%d,%s\"\n",
                        pxTmpAttrInfoArray[uiI].sParamTag,
                        sCpeId,
                        pxTmpAttrInfoArray[uiI].ucACL,
                        pxTmpAttrInfoArray[uiI].ucNotify,
                        pxTmpAttrInfoArray[uiI].ucChangeFlag,
                        pxTmpAttrInfoArray[uiI].ucParamType,
                        pxTmpAttrInfoArray[uiI].ucDevMInd,
                        sParamOid);
            }

            if (uiDelFlag)
            {
                /* Set the flag for deleting existing entry */
                uiActionFlag = IFX_F_DELETE;
            }
            else
            {
                /* Set the flag for modifying existing entry */
                uiActionFlag = IFX_F_MODIFY | IFX_F_DONT_ACTIVATE;
            }

            /* Write to database */
            iRtn = ifx_SetObjData(DB_FILE, sName,
                                  uiActionFlag, 1, sLine);

            /* Check for error */
            if (iRtn != IFX_SUCCESS)
            {
                iRet = IFX_FAILURE;
                IFX_DBG("[%s:%d] [%d] Unable to add entry %s to %s\n",
                            __func__, __LINE__,iRet, sLine, sName);
                goto cleanup;
            }

        }

    }

cleanup:
    IFX_FREE(pxTmpAttrInfoArray);
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : IFX_GetNotificationInfo
**
**   Description      : This function takes the section name and gives the list
**                      of all parameters of all instances within that section
**                      for which notification attribute is enabled.
**                      In case the parameter is read write, it updates the list
**                      with parameter name only if the change flag attribute
**                      for that parameter is set. In case the parameter is
**                      read only, it simply updates list with parameter name.
**
**   Parameters       : psSectionTag - Section name from which parameters have
**                      to be identified whose notification attribute is
**                      enabled.
**                      puiNumNotificationInfo - Count of number of parameters
**                      in list of notification info. This is filled by function.
**                      ppxNotificationInfoArray - List of all parameters in the
**                      requested section for which notification attribute is
**                      set to passive or active  and either parameter is of type
**                      read write with change flag attribute set or parameter
**                      is of type read only. This list is allocated by the
**                      function and has to be freed by the caller.
**
**   Return Value     : IFX_SUCCESS - If requested operation is successful.
**                      IFX_FAILURE ( or other error codes) - If requested
**                      operation is not successful.
**
**   Notes            : 
**
** ============================================================================
*/
int32 IFX_GetNotificationInfo(IN char8 *psSectionTag,
                              OUT uint32 *puiNumNotificationInfo,
                              OUT IFX_NotificationInfo **ppxNotificationInfoArray)
{
    int32  iRet                     = IFX_SUCCESS;
    int32  iRtn                     = IFX_SUCCESS;
    char8  *pcObjBuff               = NULL; /* Mandatory */
    char8  *pcTmp1                  = NULL;
    char8  *pcTmp2                  = NULL;
    char8  *pcTmp3                  = NULL;
    char8  *pcTmp4                  = NULL;
    char8  sName[MAX_FILELINE_LEN] = { 0 };
    uint32 uiStateFlag;
    char8  sCpeId[12] = { 0 }; /* Maximum CpeId value */
    uint32 uiNotificationCount = 0; /* Mandatory */
    IFX_NotificationInfo *pxNotificationInfoArray = NULL; /* Mandatory */
    IFX_Id xIfxId;
    int32  iParamOid;
    int32  iType = 0; /* Mandatory */
   char8  *pcTmpOld              = NULL;

    /* Check for validity of input parameters */
    if (!psSectionTag || !puiNumNotificationInfo || !ppxNotificationInfoArray)
    {
        iRet = ERR_MAPI_INVAL_INPUT_PARAM;
        IFX_DBG("[%s:%d] [%d] Invalid input parameters\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Set the flag for getting the entire object */
    uiStateFlag = IFX_F_GET_DIS;

    /* Form the attribute section name */
    /* NOTE: Here I have assumed that length of section tag sName will always
       be less than the MAX_FILELINE_LEN. Actually check needs to be performed
       here since we are forming a string sName whose size can be larger than
       the sName buffer size. */ 
    sprintf(sName, "%s_%s", IFX_TR69_SECTION_TAG_PREFIX, psSectionTag);

    /* NOTE: ifxGetCfgObject also returns failure if no entries
       are present in the section. In that case it returns
       pcObjBuff as NULL. */
    /* Get all the values from the database */
    iRtn = ifx_GetCfgObject(DB_FILE, sName, NULL, uiStateFlag, &pcObjBuff);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {

        if (iRtn != IFX_E_SEC_EMPTY)
        {
            iRet = IFX_FAILURE;
            IFX_DBG("[%s:%d] [%d] Either section tag not found or also "
                        "can be file related errors or memory related errors\n",
                         __func__, __LINE__, iRet);
        }
        else
        {
            /* If no entries are present, return success indicating no entries */
            *ppxNotificationInfoArray = NULL;
            *puiNumNotificationInfo   = 0;
        }

        goto cleanup;
    }

    /* Iterare to get the the number of entries for which Notification has to
       be reported */
    pcTmp1 = pcObjBuff;
    while(strlen(pcTmp1))
    {
        pcTmp2 = getAttrName(pcTmp1);
        pcTmp3 = getAttrValue(pcTmp2 + (strlen(pcTmp2) + 2));
        if (chkNotificationReporting(pcTmp3) == IFX_SUCCESS)
        {
            uiNotificationCount++;
        }
        pcTmp1 += strlen(pcTmp2) + 2 + strlen(pcTmp3) + 2;
        *(pcTmp2 + strlen(pcTmp2)) = '=';
        *(pcTmp3 + strlen(pcTmp3)) = '\"';
        pcTmp2 = NULL;
        pcTmp3 = NULL;
    }

    /* Check if entries are present that need to be reported */
    if (!uiNotificationCount)
    {
        /* No entries have to be reoprted, return success indicating no entries */
        *ppxNotificationInfoArray = NULL;
        *puiNumNotificationInfo   = 0;
        goto cleanup;
    }

    /* Allocate for the Notification Info*/
    pxNotificationInfoArray = (IFX_NotificationInfo *)
           IFX_MALLOC(sizeof(IFX_NotificationInfo) * uiNotificationCount);

    /* Check for error */
    if(!pxNotificationInfoArray)
    {
        iRet = ERR_MAPI_OUT_OF_MEMORY;
        IFX_DBG("[%s:%d] [%d] Allocation failure for Notification Info "
                    "Array\n", __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Iterare to fill the Notification information */
    uiNotificationCount = 0; /* mandatory */
    pcTmp1 = pcObjBuff;
    while(strlen(pcTmp1))
    {
        pcTmp2 = getAttrName(pcTmp1);
        pcTmp3 = getAttrValue(pcTmp2 + (strlen(pcTmp2) + 2));
        if (chkNotificationReporting_n_RWTypeStatus(pcTmp3, &iType) == IFX_SUCCESS)
        {
            /* Get the CpeId */
            pcTmp4 = strrchr(pcTmp2,'_');
            strcpy(sCpeId,pcTmp4 + 1);

            /* Fill CPE ID and Section Tag in IFX_Id structure */
            xIfxId.xCpeId.uiId = (uint32)atoi(sCpeId);
            strcpy(xIfxId.xCpeId.sSectionTag, psSectionTag);

            /* get the TR69 ID */
            iRet = IFX_GetTr69IdFromCpeId(&xIfxId);
            /* Check for error */
            if (iRet != IFX_SUCCESS)
            {
                IFX_DBG("[%s:%d] [%d] Error in getting TR69 ID\n",
                            __func__, __LINE__,iRet);
                goto cleanup;
            }

            /* Get the Param Oid */
            iParamOid = getParamOidFromAttrValue(pcTmp3);

            /* Fill the Notification Info */
            strlcpy(pxNotificationInfoArray[uiNotificationCount].sTr69Id, xIfxId.sTr69Id,IFX_MAX_TR69_ID_LEN);
            pxNotificationInfoArray[uiNotificationCount].iParamOid = iParamOid;

            /* Increment the notification Count */
            uiNotificationCount++;
        }
        pcTmpOld = pcTmp1;
        pcTmp1 += strlen(pcTmp2) + 2 + strlen(pcTmp3) + 2;
        *(pcTmp2 + strlen(pcTmp2)) = '=';
        *(pcTmp3 + strlen(pcTmp3)) = '\"';
        pcTmp2 = NULL;
        pcTmp3 = NULL;
   }
    /* Give the Notification Info to the caller */
    *ppxNotificationInfoArray = pxNotificationInfoArray;
    *puiNumNotificationInfo    = uiNotificationCount;
    pxNotificationInfoArray   = NULL;

cleanup:
    IFX_FREE(pcObjBuff);
    IFX_FREE(pxNotificationInfoArray);
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : IFX_GetTr69Instances
**
**   Description      : This function returns a buffer containing all the
**                      available instances of all the objects. The instances
**                      are separated by '/n'. The buffer is terminated by '/0'.
**
**   Parameters       : ppsBuff - The buffer containing all available instances
**                      of all objects. Allocation is done by the function.
**
**   Return Value     : IFX_SUCCESS - If requested operation is successful.
**                      IFX_FAILURE ( or other error codes) - If requested
**                      operation is not successful.
**
**   Notes            : 
**
** ============================================================================
*/

int32 IFX_GetTr69Instances(OUT char8 **ppsBuff)
{
    int32  iRet                     = IFX_SUCCESS;
    int32  iRtn                     = IFX_SUCCESS;
    char8  *pcObjBuff               = NULL; /* Mandatory */
    char8  *pcTmp1                  = NULL;
    char8  *pcTmp2                  = NULL;
    char8  *pcTmp3                  = NULL;
    char8  *pcTmpBuff               = NULL;
    uint32 uiStateFlag;
    char8  *psBuff                  = NULL; /* Mandatory */

    /* Check for the validity of input parameters */
    if (!ppsBuff) 
    {
        iRet = ERR_MAPI_INVAL_INPUT_PARAM;
        IFX_DBG("[%s:%d] [%d] Invalid input parameters\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Set the flag for getting entries in tr69_instances section */
    uiStateFlag = IFX_F_GET_DIS;

    /* ifxGetCfgObject also returns failure if no entries
       are present in the section. In that case it returns
       pcObjBuff as NULL. In that case we will return error */ 
    /* Get all the values from the database */
    iRtn = ifx_GetCfgObject(DB_FILE, IFX_TR69_INSTANCE_SECTION_TAG, NULL,
                            uiStateFlag, &pcObjBuff);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {
        if (iRtn == IFX_E_SEC_EMPTY)
        {
            iRet = ERR_MAPI_NOT_FOUND;
        }
        else
        {
            iRet = IFX_FAILURE;
        }

        IFX_DBG("[%s:%d] [%d] Unable to get entries from %s\n",
                    __func__, __LINE__, iRet, IFX_TR69_INSTANCE_SECTION_TAG);
        goto cleanup;
    }

    /* Allocate the buffer to be returned for the found entries */
    /* Here we allocate a buffer equal to the size of the buffer
       returned by ifx_GetCfgObject, since we are going to strip
       the data and send it back to the caller */
    psBuff = (char8 *)IFX_MALLOC(strlen(pcObjBuff) + 1);

    /* Check for error */
    if(!psBuff)
    {
        iRet = ERR_MAPI_OUT_OF_MEMORY;
        IFX_DBG("[%s:%d] [%d] Allocation failure for Buffer\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Extract and fill the names in the allocated buffer */
    pcTmp1    = pcObjBuff;
    pcTmpBuff = psBuff;
    while(1)
    {
        pcTmp2= strstr(pcTmp1, "=\"");
        pcTmp3= strstr(pcTmp1, "\"\n");
        if (pcTmp2 && pcTmp3)
        {
            memcpy(pcTmpBuff, pcTmp2 + 2, (size_t)(pcTmp3 - (pcTmp2 + 2)));
            pcTmpBuff[(pcTmp3 - (pcTmp2 + 2))] = '\n';
            pcTmpBuff += ((pcTmp3 - (pcTmp2 + 2)) + 1);
            pcTmp1 = pcTmp3 + 2;
        }
        else
        {
            *pcTmpBuff = '\0';
            break;
        }
    }

    /* Give the Session Name Info to the caller */
    *ppsBuff = psBuff;
    psBuff   = NULL;

cleanup:
    IFX_FREE(pcObjBuff);
    IFX_FREE(psBuff);
    return (iRet);
}

/* 
** =============================================================================
**   Function Name    : IFX_SetTr69Instances
**
**   Description      : This function refreshes the list of instances in the
**                      instance section. It gets a buffer containing all the
**                      available instances of all the objects. The instances
**                      are separated by '/n'. The buffer is terminated by '/0'.
**
**   Parameters       : psBuff - The buffer containing all available instances
**                      of all objects.
**
**   Return Value     : IFX_SUCCESS - If requested operation is successful.
**                      IFX_FAILURE ( or other error codes) - If requested
**                      operation is not successful.
**
**   Notes            : 
**
** ============================================================================
*/
int32 IFX_SetTr69Instances(IN char8 *psBuff)
{
    int32  iRet                     = IFX_SUCCESS;
    int32  iRtn                     = IFX_SUCCESS;
    uint32 uiActionFlag;

    /* Check for the validity of input parameters */
    if (!psBuff) 
    {
        iRet = ERR_MAPI_INVAL_INPUT_PARAM;
        IFX_DBG("[%s:%d] [%d] Invalid input parameters\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Set the flag for adding new entry */
    uiActionFlag = 0;

    /* Write to database */
    iRtn = ifx_SetObjData(DB_FILE, IFX_TR69_INSTANCE_SECTION_TAG,
                          uiActionFlag, 1, psBuff);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {
        iRet = IFX_FAILURE;
        IFX_DBG("[%s:%d] [%d] Unable to add entry to %s\n",
                    __func__, __LINE__, iRet, IFX_TR69_INSTANCE_SECTION_TAG);
        goto cleanup;
    }

cleanup:
    return (iRet);
}
/*
** =============================================================================
**   Function Name    : IFX_UpdateTr69Instances
**
**   Description      : This function combines the TR69 instance entries received 
**			in the backup buffer with the current TR69 instance 
**			section entries, rearranges the numerical sequence and adds 
**			back as the entire tr69_instances section
**
**   Parameters       : psBkupBuff - The buffer containing partially backed-up tr69 
**                      instances
**
**   Return Value     : IFX_SUCCESS - If requested operation is successful.
**                      IFX_FAILURE ( or other error codes) - If requested
**                      operation is not successful.
** ============================================================================
*/
int32 IFX_UpdateTr69Instances(IN char8 *psBkupBuff)
{
    int32  iRet                     = IFX_SUCCESS;
    int32  iRtn                     = IFX_SUCCESS;
    char8  *pcObjBuff               = NULL;
    char8  *pcTmp1                  = NULL;
    char8  *pcTmp2                  = NULL;
    char8  *pcTmp3                  = NULL;
    uint32 uiStateFlag;
    char8  *psBuff1                  = NULL;
    int32 iCount                    = 0;
    char8 psBuffEntry[MAX_FILELINE_LEN]={0};
    char8 psTempEntry[MAX_FILELINE_LEN];

    /* Check for the validity of input parameters */
    if (NULL == psBkupBuff) 
    {
        iRet = IFX_FAILURE;
        IFX_DBG("[%d] [%d] Invalid input parameter\n", __LINE__, iRet);
        goto cleanup;
    }

    /* Set the flag for getting entries in tr69_instances section */
    uiStateFlag = IFX_F_GET_ANY;

    /* ifxGetCfgObject also returns failure if no entries
       are present in the section. In that case it returns
       pcObjBuff as NULL. In that case we will return error */ 
    /* Get all the values from the database */
    iRtn = ifx_GetCfgObject("/flash/rc.conf", IFX_TR69_INSTANCE_SECTION_TAG, NULL,
                            uiStateFlag, &pcObjBuff);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {
        if (iRtn == IFX_E_SEC_EMPTY)
        {
            iRet = ERR_MAPI_NOT_FOUND;
        }
        else
        {
            iRet = IFX_FAILURE;
        }

        goto cleanup;
    }

    /* Allocate the buffer to be returned for the found entries */
    /* Here we allocate a buffer equal to the size of the buffer
       returned by ifx_GetCfgObject, since we are going to strip
       the data and send it back to the caller */
    psBuff1 = (char8 *)IFX_MALLOC(strlen(pcObjBuff)+ strlen(psBkupBuff) + 1);

    /* Check for error */
    if(!psBuff1)
    {
        iRet = ERR_MAPI_OUT_OF_MEMORY;
        goto cleanup;
    }

    /* Extract and fill the names in the allocated buffer Buff2*/
    pcTmp1    = pcObjBuff;
    psBuff1[0]='\0';
    while(1)
    {
        pcTmp2= strstr(pcTmp1, "=\"");
        pcTmp3= strstr(pcTmp1, "\"\n");
        if (pcTmp2 && pcTmp3)
        {
	    iCount++;
            memcpy(psBuffEntry, pcTmp2 + 2, (size_t)(pcTmp3 - (pcTmp2 + 2)));
            psBuffEntry[(pcTmp3 - (pcTmp2 + 2))] = '\0';
            sprintf(psTempEntry, "#%d=\"%s\"\n", iCount, psBuffEntry);
            sprintf(psBuff1,"%s%s", psBuff1, psTempEntry);
            pcTmp1 = pcTmp3 + 2;
        }
	else
	{
            break;
	}
    }
    pcTmp1   = psBkupBuff;
    while(1)
    {
        pcTmp2= strstr(pcTmp1, "=\"");
        pcTmp3= strstr(pcTmp1, "\"\n");
        if (pcTmp2 && pcTmp3)
        {
            iCount++;
            memcpy(psBuffEntry, pcTmp2 + 2, (size_t)(pcTmp3 - (pcTmp2 + 2)));
            psBuffEntry[(pcTmp3 - (pcTmp2 + 2))] = '\0';
            sprintf(psTempEntry, "#%d=\"%s\"\n", iCount, psBuffEntry);
            sprintf(psBuff1,"%s%s", psBuff1, psTempEntry);
            pcTmp1 = pcTmp3 + 2;
        }
	else
	{
	    break;
	}
    }
	/* Write to database */
    iRet = ifx_SetObjData("/flash/rc.conf", IFX_TR69_INSTANCE_SECTION_TAG,
                          IFX_F_DEFAULT, 1, psBuff1);

	
cleanup:
    IFX_FREE(pcObjBuff);
    IFX_FREE(psBuff1);
    return (iRet);
}
/* 
** =============================================================================
**   Function Name    : IFX_DeleteAttrInfo
**
**   Description      : This function takes the CPE ID and deletes entries from
**                      attribute section related to the section tag in CPE ID.
**                      Only those entries in that attribure section are deleted
**                      whose CPE ID matches with ID present in CPE ID structure
**
**   Parameters       : pxCpeId - The section tag and ID members of CPE ID 
**                      structure MUST be filled by caller. Section tag helps in
**                      identifying the attribute section. The ID helps in
**                      identifying the entry to be deleted.
**
**   Return Value     : IFX_SUCCESS - If requested operation is successful.
**                      IFX_FAILURE ( or other error codes) - If requested
**                      operation is not successful.
**
**   Notes            : 
**
** ============================================================================
*/

int32 IFX_DeleteAttrInfo(IN IFX_CpeId *pxCpeId)
{
    int32  iRet = IFX_SUCCESS;
    int32  iRtn = IFX_SUCCESS;
    char8  sCpeIdBuff[12+5] = { 0 }; /* Maximum CpeId value + some buufer for processing */
    char8  sName[MAX_FILELINE_LEN] = { 0 };
    uint32 uiActionFlag;
    uint32 uiStateFlag;
    char8  *pcObjBuff               = NULL; /* Mandatory */
    char8  *pcTmp1                  = NULL;
    char8  *pcTmp2                  = NULL;
    char8  *pcTmp3                  = NULL;
    char8  cBkup;

    /* Check for the validity of input parameters */
    if (!pxCpeId) 
    {
        iRet = ERR_MAPI_INVAL_INPUT_PARAM;
        IFX_DBG("[%s:%d] [%d] Invalid input parameters\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the CPE ID in string format */
    sprintf(sCpeIdBuff, "_%u", pxCpeId->uiId);
    sprintf(sName, "%s_%s", IFX_TR69_SECTION_TAG_PREFIX, pxCpeId->sSectionTag);

    /* Set the flag for getting entries in tr69_instances section */
    uiStateFlag = IFX_F_GET_DIS;

    /* ifxGetCfgObject also returns failure if no entries
       are present in the section. In that case it returns
       pcObjBuff as NULL. We neglect this error since it is
       perfectly OK for this section to be empty */
    /* Get all the values from the database */
    iRtn = ifx_GetCfgObject(DB_FILE, sName, NULL,
                            uiStateFlag, &pcObjBuff);

    /* Check for error */
    if (iRtn != IFX_SUCCESS)
    {
        if (iRtn != IFX_E_SEC_EMPTY)
        {
            iRet = IFX_FAILURE;

            IFX_DBG("[%s:%d] [%d] Unable to get entries from %s\n",
                        __func__, __LINE__, iRet, sName);
            goto cleanup;
        }
    }
    else
    {
        /* Set the flag for deleting entry */
        uiActionFlag = IFX_F_DELETE;

        strcat(sCpeIdBuff,"=\"");
        pcTmp1    = pcObjBuff;
        while(1)
        {
            pcTmp2= strstr(pcTmp1, sCpeIdBuff);
            pcTmp3= strstr(pcTmp1, "\"\n");
            if (pcTmp2 && pcTmp3)
            {
                if (pcTmp2 < pcTmp3)
                { 
                    cBkup = *(pcTmp3 + 2);
                    *(pcTmp3 + 2) = '\0';
                    /* Write to database */
                    iRtn = ifx_SetObjData(DB_FILE, sName,
                                           uiActionFlag, 1, pcTmp1);
                     /* Check for error */
                    if (iRtn != IFX_SUCCESS)
                    {
                        iRet = IFX_FAILURE;
                        IFX_DBG("[%s:%d] [%d] Unable to delete entries from %s Section\n",
                                    __func__, __LINE__, iRet, sName);
                        *(pcTmp3 + 2) = cBkup;
                        goto cleanup;
                    }

                    *(pcTmp3 + 2) = cBkup;
                    pcTmp1 = pcTmp3 + 2;
                }
                else
                {
                    pcTmp1 = pcTmp3 + 2;
                }
            }
            else
            {
                break;
            }
        }
    }

cleanup:
    IFX_FREE(pcObjBuff);
    return (iRet);
}


int32 IFX_EventNotify(IN IFX_Id *pxIfxId, IN uint32 uiNumNV,
                      IN IFX_NameValue *pxNVArray, IN int32 iType, IN int32 iState)
{
    int32        iRet                        = IFX_SUCCESS;
    char8        acMsg[IFX_IPC_MAX_MSG_SIZE] = {0};
    uint16       uiMsgSize;
    int32        iWrFd = -1;
    char8        cRet;
    IFX_Id       xIfxId;
#if 0
    int32        iI = 0;
#endif
    char8        *pcTmp = NULL;

    /* Check for validity of input parameters */
    if (!pxIfxId)
    {
        iRet = ERR_MAPI_INVAL_INPUT_PARAM;
        IFX_DBG("[%s:%d] [%d] Invalid input parameters\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Fill the IFX_Id structure with IFX_CpeId */
    xIfxId.xCpeId = pxIfxId->xCpeId;

    /* Get the TR69 ID for the Object */
    iRet = IFX_GetTr69IdFromCpeId(&xIfxId);

    /* Check for error */
    if (iRet != IFX_SUCCESS)
    {
        IFX_DBG("[%s:%d] [%d] Error in getting TR69 ID\n",
                    __func__, __LINE__, iRet);
        goto cleanup;
    }

    /* Get the message size */
    uiMsgSize = strlen(xIfxId.sTr69Id) + 1;
#if 0
    uiMsgSize += sizeof(uiNumNV);
    for (iI = 0; iI < uiNumNV; iI++)
    {
        uiMsgSize += strlen(pxNVArray[iI].sName) + 1;
        uiMsgSize += strlen(pxNVArray[iI].sVal) + 1;
    }
#endif

    /* Check if the message size is fitting in the buffer */
    if (uiMsgSize > IFX_IPC_MAX_MSG_SIZE)
    {
        IFX_DBG("[%s:%d] [##########Critical] Message is big to be "
                     "handled by FIFO\n", __func__, __LINE__);
        iRet = IFX_FAILURE;
        goto cleanup;
    }

    /* Start forming the Message */
    pcTmp = acMsg;
    strcpy(pcTmp,xIfxId.sTr69Id);
    pcTmp += (strlen(xIfxId.sTr69Id) + 1);
#if 0
    memcpy(pcTmp, &uiNumNV, sizeof(uiNumNV)), 
    pcTmp += sizeof(uiNumNV);

    for (iI = 0; iI < uiNumNV; iI++)
    {
        strcpy(pcTmp, pxNVArray[iI].sName);
        pcTmp += strlen(pxNVArray[iI].sName) + 1;
        strcpy(pcTmp, pxNVArray[iI].sVal);
        pcTmp += strlen(pxNVArray[iI].sVal) + 1;
    }
#endif

    /* Open a /tmp/tr FIFO in write mode to send messages to TR69 task */
    iWrFd = IFX_OS_OpenFifo((uchar8 *)IFX_IPC_TR_FIFO , O_RDWR); 

    /* Check for error */
    if (iWrFd < 0)
    {
        iRet = ERR_MAPI_FIFO_OPEN;
        IFX_DBG("[%s:%d] [%d] Error in opening the FIFO %s for "
                 "writing\n",__func__, __LINE__, iRet, IFX_IPC_TR_FIFO);
        goto cleanup;
    }

                /* Post a message to TR69 task */
    cRet = IFX_IPC_SendMsg(iWrFd, (uchar8)IFX_IPC_APP_ID_EVENT,
                           (uchar8)iType, uiMsgSize, iState, acMsg);

                /* Check for error */
    if (cRet != IFX_IPC_SUCCESS)
    {
        iRet = ERR_MAPI_FIFO_WRITE;
        IFX_DBG("[%s:%d] [%d] Error in Sending Message\n",
                 __func__, __LINE__, iRet);
        goto cleanup;
    }

cleanup:
    /* Close the FIFO's */
    IFX_PROTOAPI_CloseFifo(iWrFd);
    return (iRet);
}


int32
ifx_get_devm_dyn(DYN_DEVM * pxDevm, uint32 uiFlags)
{
    int32 iRet = IFX_SUCCESS;
    /* sVal buffer should be large enough to accomodate the biggest string in
       the obj */
    char8 sVal[MAX_IF_NAME] = { 0 };
    uint32 ulInFlag = IFX_F_DEFAULT, ulOutFlag;

    memset(pxDevm, '\0', sizeof(DYN_DEVM));
    memset(sVal,'\0',sizeof(sVal));
    if((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_DYN_DEVM_SECTION,
                              IFX_DYN_DEVM_SECTION "_" IFX_DEVM_BOOT,
                              ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;
    pxDevm->iBoot = atoi(sVal);

    memset(sVal,'\0',sizeof(sVal));
    if((iRet = ifx_GetObjData(IFX_DIAG_FILE, IFX_DYN_DEVM_SECTION,
                              IFX_DYN_DEVM_SECTION "_" IFX_DEVM_RESET,
                              ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;
    pxDevm->iReset = atoi(sVal);

  IFX_Handler:
    return (iRet);
}

int32
ifx_set_devm_dyn(int32 iOper, DYN_DEVM * pxDevm, uint32 uiFlags)
{
    int32 iRet = IFX_SUCCESS;
    /* sVal should always be large enough to accomodate the biggest string in
       the obj */
    char8 *sVal = NULL;

    sVal = (char8 *) malloc(128);

    if(sVal == NULL) {
        IFX_DBG("%s:%d Error--> Failed to Malloc !!\n", __FUNCTION__, __LINE__);
        iRet = IFX_FAILURE;
        goto IFX_Handler;
    }
    memset(sVal,0x00,sizeof(sVal));
    sprintf(sVal, "%s_%s=\"%d\"\n", IFX_DYN_DEVM_SECTION,
            IFX_DEVM_BOOT, pxDevm->iBoot);

    sprintf(sVal, "%s%s_%s=\"%d\"\n", sVal, IFX_DYN_DEVM_SECTION,
            IFX_DEVM_RESET, pxDevm->iReset);

    if((iRet = ifx_SetObjData(IFX_DIAG_FILE, IFX_DYN_DEVM_SECTION,
                              uiFlags, 1, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;

  IFX_Handler:
    free(sVal);
    return iRet;
}

int32
ifx_get_devm_conf(DEVM_CONF * pxDevm, uint32 uiFlags)
{
    int32 iRet = IFX_SUCCESS;
    /* sVal buffer should be large enough to accomodate the biggest string in
       the obj */
    char8 sVal[MAX_IF_NAME] = { 0 };
    uint32 ulInFlag = IFX_F_DEFAULT, ulOutFlag;

    memset(pxDevm, '\0', sizeof(DEVM_CONF));
    memset(sVal,'\0',sizeof(sVal));
    if((iRet = ifx_GetObjData(IFX_DEVM_CONF, IFX_DEVM_CONF_SECTION,
                              IFX_MAX_GET_PARAM_VAL,
                              ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;
    pxDevm->iMaxGetParamVal = atoi(sVal);

    memset(sVal,'\0',sizeof(sVal));
    if((iRet = ifx_GetObjData(IFX_DEVM_CONF, IFX_DEVM_CONF_SECTION,
                              IFX_MAX_GET_ATTR_VAL,
                              ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;
    pxDevm->iMaxGetAttrVal = atoi(sVal);

    memset(sVal,'\0',sizeof(sVal));
    if((iRet = ifx_GetObjData(IFX_DEVM_CONF, IFX_DEVM_CONF_SECTION,
                              IFX_MAX_GET_PARAM_NAMES,
                              ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;
    pxDevm->iMaxGetParamNames = atoi(sVal);

    memset(sVal,'\0',sizeof(sVal));
    if((iRet = ifx_GetObjData(IFX_DEVM_CONF, IFX_DEVM_CONF_SECTION,
                              IFX_RPC_SCHED_INFORM,
                              ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;
    pxDevm->iRPCSchedInform = atoi(sVal);

    memset(sVal,'\0',sizeof(sVal));
    if((iRet = ifx_GetObjData(IFX_DEVM_CONF, IFX_DEVM_CONF_SECTION,
                              IFX_RPC_ADD_OBJ,
                              ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;
    pxDevm->iRPCAddObj = atoi(sVal);

    memset(sVal,'\0',sizeof(sVal));
    if((iRet = ifx_GetObjData(IFX_DEVM_CONF, IFX_DEVM_CONF_SECTION,
                              IFX_RPC_DEL_OBJ,
                              ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;
    pxDevm->iRPCDelObj = atoi(sVal);

    memset(sVal,'\0',sizeof(sVal));
    if((iRet = ifx_GetObjData(IFX_DEVM_CONF, IFX_DEVM_CONF_SECTION,
                              IFX_RPC_FACT_RESET,
                              ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;
    pxDevm->iRPCFactReset = atoi(sVal);

    memset(sVal,'\0',sizeof(sVal));
    if((iRet = ifx_GetObjData(IFX_DEVM_CONF, IFX_DEVM_CONF_SECTION,
                              IFX_RPC_UPLOAD,
                              ulInFlag, &ulOutFlag, sVal)) != IFX_SUCCESS)
        goto IFX_Handler;
    pxDevm->iRPCUpload = atoi(sVal);

  IFX_Handler:
    return (iRet);
}


