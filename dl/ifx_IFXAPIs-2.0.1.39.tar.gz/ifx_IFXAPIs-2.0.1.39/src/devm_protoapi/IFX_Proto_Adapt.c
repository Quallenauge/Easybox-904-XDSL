
/* 
** =============================================================================
** FILE NAME     : IFX_Proto_Adapt.c
** PROJECT       : TR69
** MODULES       : Protocol API Adaptation Layer
** DATE          : 20-Jun-2006
** AUTHOR        : TR69 team
** DESCRIPTION   : Protocol API Adaptation Layer. Invoked by the Management
**                 API. This internally invokes TR69 specific Protocol API.
** REFERENCES    :
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author      $Comment
** 20-Jun-2006 TR69 team    Initial Version
** ============================================================================
*/



/*
** =============================================================================
**
**                                <INCLUDE FILES>
**
** =============================================================================
*/
#include "../common/ifx_common.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ifx_api_include.h"
#ifndef IN
#define IN IFX_IN
#endif
#ifndef OUT
#define OUT IFX_OUT
#endif
#ifndef INOUT
#define INOUT IFX_IN_OUT
#endif
#include "IFIN_Proto_API.h"

// #ifdef IFX_DBG
// #undef IFX_DBG
// #define IFX_DBG(fmt, args...) printf(fmt, ##args)
// #endif

/*
** =============================================================================
**
**                              <LOCAL DEFINITIONS>
**
** =============================================================================
*/
#define IFX_TR69_COMPILED ({uint32 uiI; uiI = TRUE;})

#define IFX_TR69_RUNNING ({uint32 uiI; uiI = TRUE;})


/*
** =============================================================================
**
**                                <LOCAL TYPES>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                                 <LOCAL DATA>
**
** =============================================================================
*/


/*
** =============================================================================
**
**                           <LOCAL FUNCTION PROTOTYPES>
**
** =============================================================================
*/
static
int32 strip_n_convert_param_name(IFX_IN  IFX_NAME_VALUE_PAIR *in_array_fvp,
                                 IFX_IN  uint32              count,
                                 IFX_OUT IFX_NameValue       *out_array_nv);
static
int32 convert_cpeid_owner_of_iid(IFX_ID *in_iid, IFX_Id *out_iid);
static
int32 convert_cpeid_pcpeid_owner_of_iid(IFX_ID *in_iid, IFX_Id *out_iid);
static
int32 convert_cpeid_tr69id_owner_of_iid(IFX_ID *in_iid, IFX_Id *out_iid);
static
int32 convert_param_namevalue(IFX_IN  IFX_NAME_VALUE_PAIR *in_array_fvp,
                              IFX_IN  uint32              count,
                              IFX_OUT IFX_NameValue       *out_array_nv);
/*
** =============================================================================
**
**                               <LOCAL FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : strip_n_convert_param_name
**
**   Description      : This function strips the parameter name from Management
**                      API format and converts it to Protocol API format.
**
**   Parameters       : array_fvp - List of all the parameters in Management API
**                      format. Only fieldname member of each element is
**                      considered.
**                      count - Number of parameters in the Management API
**                      related parameter list or Protocol API related parameter
**                      list. Both have same number.
**                      array_nv - List of all the parameters in Protocol API
**                      format. Only sName member of each element is considered.
**
**   Return Value     : IFX_SUCCESS - If requested operation is is successful.
**                      IFX_FAILURE - If requested operation is not successful.
**
**   Notes            : 
**
** ============================================================================
*/
static
int32 strip_n_convert_param_name(IFX_IN  IFX_NAME_VALUE_PAIR *array_fvp,
                                 IFX_IN  uint32              count,
                                 IFX_OUT IFX_NameValue       *array_nv)
{
    int32  ret       = IFX_SUCCESS;
    uint32 uiI;
    char8  *psTmpBuf;

    for (uiI = 0; uiI < count; uiI++)
    {

        psTmpBuf = strrchr(array_fvp[uiI].fieldname, '_');

        if ((!psTmpBuf) || ((strlen(psTmpBuf) + 1) > IFX_MAX_NAME_LEN))
        {
            IFX_DBG("[%s:%d] Invalid Input\n",__func__, __LINE__);
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }

        strcpy(array_nv[uiI].sName, psTmpBuf + 1);
    }

IFX_Handler:
    return (ret);
}

/* 
** =============================================================================
**   Function Name    : convert_cpeid_owner_of_iid
**
**   Description      : This function converts the CPE ID and owner from
**                      Management API format to Protocol API format
**
**   Parameters       : in_iid - Contains CPE ID and Owner in
**                      Management API format.
**                      out_iid - Contains CPE ID and Owner in
**                      Protocol API format.
**
**   Return Value     : IFX_SUCCESS - If requested operation is is successful.
**                      IFX_FAILURE - If requested operation is not successful.
**
**   Notes            : 
**
** ============================================================================
*/
static
int32 convert_cpeid_owner_of_iid(IFX_ID *in_iid, IFX_Id *out_iid)
{
    int32 ret = IFX_SUCCESS;

    if ((strlen(in_iid->cpeId.secName) + 1) > IFX_MAX_SECTION_TAG_LEN)
    {
        IFX_DBG("[%s:%d] Invalid Input\n",__func__, __LINE__);
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    strcpy(out_iid->xCpeId.sSectionTag, in_iid->cpeId.secName);
    out_iid->xCpeId.uiId       = in_iid->cpeId.Id;
    /* NOTE: Here actually conversion of config_owner contents must be performed
       to macro used by TR69 since uiConfigOwner uses the values in that macro.
       Currently assumed that values in both macros are same */
    out_iid->uiConfigOwner = in_iid->config_owner;

IFX_Handler:
    return (ret);
}

/* 
** =============================================================================
**   Function Name    : convert_cpeid_pcpeid_owner_of_iid
**
**   Description      : This function converts the CPE ID, Parent CPE id and
**                      owner from Management API format to Protocol API format
**
**   Parameters       : in_iid - Contains CPE ID, Parent CPE ID and Owner in
**                      Management API format.
**                      out_iid - Contains CPE ID, Parent CPE ID and Owner in
**                      Protocol API format.
**
**   Return Value     : IFX_SUCCESS - If requested operation is is successful.
**                      IFX_FAILURE - If requested operation is not successful.
**
**   Notes            : 
**
** ============================================================================
*/
static
int32 convert_cpeid_pcpeid_owner_of_iid(IFX_ID *in_iid, IFX_Id *out_iid)
{
    int32 ret = IFX_SUCCESS;

    if (((strlen(in_iid->cpeId.secName) + 1) > IFX_MAX_SECTION_TAG_LEN) ||
        ((strlen(in_iid->pcpeId.secName) + 1) > IFX_MAX_SECTION_TAG_LEN))
     {
        IFX_DBG("[%s:%d] Invalid Input\n",__func__, __LINE__);
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    strcpy(out_iid->xCpeId.sSectionTag, in_iid->cpeId.secName);
    strcpy(out_iid->xParentCpeId.sSectionTag, in_iid->pcpeId.secName);
    out_iid->xCpeId.uiId       = in_iid->cpeId.Id;
    out_iid->xParentCpeId.uiId = in_iid->pcpeId.Id;
    /* NOTE: Here actually conversion of config_owner contents must be performed
       to macro used by TR69 since uiConfigOwner uses the values in that macro.
       Currently assumed that values in both macros are same */
    out_iid->uiConfigOwner = in_iid->config_owner;

IFX_Handler:
    return (ret);
}

/* 
** =============================================================================
**   Function Name    : convert_cpeid_tr69id_owner_of_iid
**
**   Description      : This function converts the CPE ID, Owner and TR69 ID
**                      from Management API format to Protocol API format.
**
**   Parameters       : in_iid - Contains CPE ID, Owner and TR69 ID in
**                      Management API format.
**                      out_iid - Contains CPE ID, Owner and TR69 ID in Protocol
**                      API format.
**
**   Return Value     : IFX_SUCCESS - If requested operation is is successful.
**                      IFX_FAILURE - If requested operation is not successful.
**
**   Notes            : 
**
** ============================================================================
*/
static
int32 convert_cpeid_tr69id_owner_of_iid(IFX_ID *in_iid, IFX_Id *out_iid)
{
    int32 ret = IFX_SUCCESS;

    if (((strlen(in_iid->cpeId.secName) + 1) > IFX_MAX_SECTION_TAG_LEN) ||
        ((strlen(in_iid->tr69Id) + 1) > IFX_MAX_TR69_ID_LEN))
    {
        IFX_DBG("[%s:%d] Invalid Input\n",__func__, __LINE__);
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    strcpy(out_iid->xCpeId.sSectionTag, in_iid->cpeId.secName);
    strcpy(out_iid->sTr69Id, in_iid->tr69Id);
    out_iid->xCpeId.uiId       = in_iid->cpeId.Id;
    /* NOTE: Here actually conversion of config_owner contents must be performed
       to macro used by TR69 since uiConfigOwner uses the values in that macro.
       Currently assumed that values in both macros are same */
    out_iid->uiConfigOwner = in_iid->config_owner;

IFX_Handler:
    return (ret);
}

static
int32 convert_param_namevalue(IFX_IN  IFX_NAME_VALUE_PAIR *array_fvp,
                              IFX_IN  uint32              count,
                              IFX_OUT IFX_NameValue       *array_nv)
{
    int32  ret       = IFX_SUCCESS;
    uint32 uiI;
    char8  *psTmpBuf;

    for (uiI = 0; uiI < count; uiI++)
    {

        psTmpBuf = array_fvp[uiI].fieldname;

        if ((!psTmpBuf) || ((strlen(psTmpBuf) + 1) > IFX_MAX_NAME_LEN) ||
            ((strlen(array_fvp[uiI].value) + 1) > IFX_MAX_VAL_LEN))
        {
            IFX_DBG("[%s:%d] Invalid Input\n",__func__, __LINE__);
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }

        strcpy(array_nv[uiI].sName, psTmpBuf + 1);
        strcpy(array_nv[uiI].sVal, array_fvp[uiI].value);
    }

IFX_Handler:
    return (ret);
}
/*
** =============================================================================
**
**                             <EXPORTED FUNCTIONS> 
**
** =============================================================================
*/


/* 
** =============================================================================
**   Function Name    : ifx_check_n_send_notification
**
**   Description      : This function notifies the TR69 task of ADD, MODIFY and
**                      DELETE operation performed by other tasks under
**                      any of the following conditions when TR69 is compiled.
**                      1. TR69 is running, then Notify
**                      2. TR69 is dormant and operation is ADD/DELETE, then
**                         Notify.
**                         This is required to update the DS and instances. 
**
**   Parameters       : iid - All the related IDs. The config_owner and cpeId
**                      members of this structure must be filled by caller.
**                      count - Indicates the number of parameters that are
**                      present in the following list of modified parameters
**                      only if the operation is MODIFY. For ADD and DELETE,
**                      this is 0 (actually dont care).
**                      array_fvp - List of parameters that are modified only if
**                      operation is MODIFY. Only fieldname member of each
**                      element of array is required to be filled by caller. If
**                      operation is ADD or DELETE, this is NULL (actually dont
**                      care).
**                      flags - Can be ADD, MODIFY or DELETE
**
**   Return Value     : IFX_SUCCESS - If notification is successful.
**                      IFX_FAILURE - If notification fails.
**
**   Notes            : 
**
** ============================================================================
*/

int32 ifx_check_n_send_notification(IFX_IN IFX_ID              *iid,
                                    IFX_IN uint32              count,
                                    IFX_IN IFX_NAME_VALUE_PAIR *array_fvp,
                                    IFX_IN uint32              flags)
{
    int32         ret        = IFX_SUCCESS;
    IFX_NameValue *pxNVArray = NULL;
    int32         iRet       = IFX_SUCCESS;
    IFX_Id        xIfxId;

    //IFX_DBG("owner=%d,secname=%s,id=%d\n",iid->config_owner,iid->cpeId.secName,iid->cpeId.Id);

    /* Check if TR69 is Compiled in. Just returning IFX_SUCCESS if not
       compiled in. */
    if (!IFX_TR69_COMPILED)
    {
        IFX_DBG("[%s:%d] TR69 Is Not Compiled\n",__func__, __LINE__);
        goto IFX_Handler; 
    }

    /* Check if TR69 is Running. Just returning IFX_SUCCESS if TR69 is
       dormant with operation is MODIFY. */
    if ((!IFX_TR69_RUNNING) && (IFX_MODIFY_F_SET(flags)))
    {
        IFX_DBG("[%s:%d] TR69 Is not running and operation is MODIFY. "
                "Just Returning Success.\n ",__func__, __LINE__);
        goto IFX_Handler; 
    }

    /* Check for validity of input parameters */
    if (!iid || ((IFX_MODIFY_F_SET(flags)) && ((!array_fvp) || (!count))))
    {
        IFX_DBG("[%s:%d] Invalid Input parameters\n", __func__, __LINE__);
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    /* Check if owner is not TR69. If owner is TR69, returning IFX_SUCCESS */
    if (iid->config_owner == IFX_TR69)
    {
        IFX_DBG("[%s:%d] Owner is TR69. Just returning Success\n",
                __func__, __LINE__);
        goto IFX_Handler; 
    }

    /* We have reached here. This indicates that the function is called in
       context of task other than TR69. Also, either TR69 is running or
       TR69 is dormant with operation is ADD/DELETE. */

    /* Convert the IFX_ID to IFX_Id */
    ret = convert_cpeid_owner_of_iid(iid, &xIfxId);

    /* Check for error */
    if (ret != IFX_SUCCESS)
    {
        IFX_DBG("[%s:%d] Convertion Failure\n", __func__, __LINE__);
        goto IFX_Handler;
    }

    if (IFX_MODIFY_F_SET(flags))
    {
        /* Allocate for IFX_NAME_VALUE_Pair Array */
        IFX_MEM_ALLOC(pxNVArray, IFX_NameValue *, count, sizeof(IFX_NameValue))

        /* Strip to get just the parameter names and convert to IFX_NameValue */
        ret = strip_n_convert_param_name(array_fvp, count, pxNVArray);

        /* Check for error */
        if (ret != IFX_SUCCESS)
        {
            IFX_DBG("[%s:%d] Convertion Failure\n", __func__, __LINE__);
            goto IFX_Handler;
        }
    }

    /* Perform flag convertions and call the notification function with
       appropriate flags */

    if (IFX_INT_ADD_F_SET(flags))
    {

        /* Check if owner is TR64 or ROOT. If so, returning IFX_SUCCESS */
        if ((iid->config_owner == IFX_TR64) || (iid->config_owner == IFX_ROOT))
        {
            IFX_DBG("[%s:%d] Owner is TR64 or ROOT. Just returning Success\n",
                    __func__, __LINE__);
            goto IFX_Handler; 
        }

        IFX_DBG("Send Notify Invoked. Operation is ADD\n");
        iRet = IFX_SendNotify(&xIfxId, 0, NULL, IFX_NOTIFY_OPER_ADD); 
    }

    if (IFX_DELETE_F_SET(flags))
    {

        /* Check if owner is TR64 or ROOT. If so, returning IFX_SUCCESS */
        if ((iid->config_owner == IFX_TR64) || (iid->config_owner == IFX_ROOT))
        {
            IFX_DBG("[%s:%d] Owner is TR64 or ROOT. Just returning Success\n",
                    __func__, __LINE__);
            goto IFX_Handler; 
        }

        IFX_DBG("Send Notify Invoked. Operation is DELETE\n");
        iRet = IFX_SendNotify(&xIfxId, 0, NULL, IFX_NOTIFY_OPER_DEL); 
    }

    if (IFX_MODIFY_F_SET(flags))
    {
        IFX_DBG("Send Notify Invoked. Operation is MODIFY\n");
        iRet = IFX_SendNotify(&xIfxId, count, pxNVArray,
                              IFX_NOTIFY_OPER_MODIFY); 
    }

    /* Check for error */
    if (iRet != IFX_SUCCESS)
    {
        IFX_DBG("Send Notify Failed\n");
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }
    IFX_DBG("Send Notify Successful\n");

IFX_Handler:
    IFX_MEM_FREE(pxNVArray)
    return (ret);
}

/* 
** =============================================================================
**   Function Name    : ifx_check_acl
**
**   Description      : This function checks access for MODIFY or DELETE
**                      operation performed by tasks other than TR69 is allowed.
**                      If operation is DELETE, it even deletes the object. All
**                      this is performed under any of the following conditions
**                      when TR69 is Compiled in.
**                      1. TR69 is running, check Access Control and perform
**                         delete dependancy check if operation is DELETE.
**                      2. TR69 is dormant and operation is DELETE, do not
**                         perform access control check but perform delete
**                         dependency check.
**
**   Parameters       : iid - All the related IDs. The config_owner and cpeId
**                      members of this structure must be filled by caller.
**                      count - Indicates the number of parameters that are
**                      present in the following list of parameters. 
**                      array_fvp - List of parameters. If the operation is
**                      MODIFY the list will contain only parameters that are to
**                      be modified. If the operation is DELETE the list will
**                      contain all parameters. Only fieldname member of each
**                      element of array is required to be filled by caller.
**                      flags - Can be MODIFY or DELETE
**
**   Return Value     : IFX_SUCCESS - If access control is allowed and delete
**                      dependency check is successful in case of DELETE
**                      operation.
**                      IFX_FAILURE - If failure.
**
**   Notes            : 
**
** ============================================================================
*/
int32 ifx_check_acl(IFX_IN IFX_ID               *iid,
                    IFX_IN uint32               count ,
                    IFX_IN IFX_NAME_VALUE_PAIR *array_fvp,
                    IFX_IN uint32              flags)
{
    int32         ret        = IFX_SUCCESS;
    IFX_NameValue *pxNVArray = NULL;
    int32         iRet       = IFX_SUCCESS;
    IFX_Id        xIfxId;

    //IFX_DBG("owner=%d,secname=%s,id=%d\n",iid->config_owner,iid->cpeId.secName, iid->cpeId.Id);
    /* Check if TR69 is Compiled in. Just returning IFX_SUCCESS if not
       compiled in. */
    if (!IFX_TR69_COMPILED)
    {
        IFX_DBG("[%s:%d] TR69 Is Not Compiled\n",__func__, __LINE__);
        goto IFX_Handler; 
    }

    /* Check if TR69 is Running. Just returning IFX_SUCCESS if TR69 is
       dormant and operation is MODIFY. */
    if ((!IFX_TR69_RUNNING) && (IFX_MODIFY_F_SET(flags)))
    {
        IFX_DBG("[%s:%d] TR69 Is not running and operation is MODIFY. "
                "Just Returning Success.\n ",__func__, __LINE__);
        goto IFX_Handler; 
    }

    /* Check for validity of input parameters */
    if (!iid || !array_fvp || !count)
    {
        IFX_DBG("[%s:%d] Invalid Input parameters\n", __func__, __LINE__);
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    /* Check if owner is not TR69. If owner is TR69, returning IFX_SUCCESS */
    if (iid->config_owner == IFX_TR69)
    {
        IFX_DBG("[%s:%d] Owner is TR69. Just returning Success\n",
                __func__, __LINE__);
        goto IFX_Handler; 
    }

    /* Check if owner is not ROOT. If owner is ROOT, returning IFX_SUCCESS */
    if (iid->config_owner == IFX_ROOT)
    {
        IFX_DBG("[%s:%d] Owner is ROOT. Just returning Success\n",
                __func__, __LINE__);
        goto IFX_Handler; 
    }


    /* We have reached here. This indicates that the function is called in
       context of task other than TR69. Also, either TR69 is running or
       TR69 is dormant with operation is DELETE. */

    /* Convert the IFX_ID to IFX_Id */
    ret = convert_cpeid_owner_of_iid(iid, &xIfxId);
    /* Check for error */
    if (ret != IFX_SUCCESS)
    {
        IFX_DBG("[%s:%d] Convertion Failure\n", __func__, __LINE__);
        goto IFX_Handler;
    }

    /* Allocate for IFX_NAME_VALUE_Pair Array */
    IFX_MEM_ALLOC(pxNVArray, IFX_NameValue *, count, sizeof(IFX_NameValue))

    /* Strip to get just the parameter names and convert to IFX_NameValue */
    ret = strip_n_convert_param_name(array_fvp, count, pxNVArray);

    /* Check for error */
    if (ret != IFX_SUCCESS)
    {
        IFX_DBG("[%s:%d] Convertion Failure\n", __func__, __LINE__);
        goto IFX_Handler;
    }

    /* Check access control if modification */
    if (IFX_MODIFY_F_SET(flags))
    {
        IFX_DBG("Check ACL Invoked. Operation is Modify.\n");
        /* Check Access Control */
        iRet = IFX_ChkACL(&(xIfxId.xCpeId), count, pxNVArray); 

        /* Check for error */
        if (iRet != IFX_SUCCESS)
        {
            IFX_DBG("Check ACL Failed\n");
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }
        IFX_DBG("Check ACL Successful\n");
    }

    /* Check access control if deletion only if TR69 is running.
       Then delete the object */
    if (IFX_DELETE_F_SET(flags))
    {

        if (IFX_TR69_RUNNING)
        {
            IFX_DBG("Check ACL Invoked. Operation is DELETE.\n");
            /* Check Access Control */
            iRet = IFX_ChkACL(&(xIfxId.xCpeId), count, pxNVArray); 

            /* Check for error */
            if (iRet != IFX_SUCCESS)
            {
                IFX_DBG("Check ACL Failed\n");
                ret = IFX_FAILURE;
                goto IFX_Handler;
            }
            IFX_DBG("Check ACL Successful\n");
        }

        /* TBD: We might use PID logic for avoiding multiple posting of msg.
           We might need to release the lock before calling this API. */

        /* Check if owner is not TR64. If owner is TR64, returning IFX_SUCCESS */
        if (iid->config_owner == IFX_TR64)
        {
            IFX_DBG("[%s:%d] Owner is TR64. Just returning Success\n",
                    __func__, __LINE__);
            goto IFX_Handler; 
        }

        IFX_DBG("Delete Dependancy Check Invoked. Operation is DELETE.\n");
        /* Check Delete dependency for the object */
        iRet = IFX_DeleteObj(&xIfxId); 

        /* Check for error */
        if (iRet != IFX_SUCCESS)
        {
            IFX_DBG("[%s:%d] Delete Dependency Check failed\n",
                    __func__, __LINE__);
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }
        IFX_DBG("Delete Dependancy Check Successful.\n");
    }

IFX_Handler:
    IFX_MEM_FREE(pxNVArray)
    return (ret);
}

/* 
** =============================================================================
**   Function Name    : ifx_alloc_tr69id
**
**   Description      : This function takes the CPE ID of the parent, section
**                      name of the child, and subsection name of the child if
**                      available and returns the TR69 ID for the child. All
**                      this is performed for tasks other than TR69, under any 
**                      of following conditions when TR69 is Compiled in.
**                      1. TR69 is running, TR69 ID is allocated
**                      2. TR69 is dormant, TR69 ID is allocated.
**                         This is required since TR69 ID is allocated by DS.
**
**   Parameters       : iid - All related IDs. The config_owner,cpeId and pcpeId
**                      members of this structure must be filled by caller. The
**                      tr69Id member of this structure is filled by function.
**                      distinctSec - If present must be filled by caller, else
**                      must be passed by caller as NULL.
**
**   Return Value     : IFX_SUCCESS - If TR69 ID allocation is successful.
**                      IFX_FAILURE - If TR69 ID allocation is not successful.
**
**   Notes            : 
**
** ============================================================================
*/
int32 ifx_alloc_tr69id(IFX_IN_OUT IFX_ID *iid,
                       IFX_IN     char8  *distinctSec)
{
    int32  ret  = IFX_SUCCESS;
    int32  iRet = IFX_SUCCESS;
    IFX_Id xIfxId;

    //IFX_DBG("owner=%d,parentsecname=%s,parentid=%d,secname=%s,distinctSec=%s\n",iid->config_owner,iid->pcpeId.secName,iid->pcpeId.Id,            iid->cpeId.secName,distinctSec);
    /* Check if TR69 is Compiled in. Just returning IFX_SUCCESS if not
       compiled in. */
    if (!IFX_TR69_COMPILED)
    {
        IFX_DBG("[%s:%d] TR69 Is Not Compiled\n",__func__, __LINE__);
        goto IFX_Handler; 
    }

    /* Check for validity of input parameters */
    if (!iid)
    {
        IFX_DBG("[%s:%d] Invalid Input parameters\n", __func__, __LINE__);
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    /* Check if owner is not TR69. If owner is TR69, returning IFX_SUCCESS */
    if (iid->config_owner == IFX_TR69)
    {
        IFX_DBG("[%s:%d] Owner is TR69. Just returning Success\n",
                __func__, __LINE__);
        goto IFX_Handler; 
    }

    /* Check if owner is ROOT or TR64. If owner is ROOT or TR64, returning IFX_SUCCESS */
    if ((iid->config_owner == IFX_TR64) || (iid->config_owner == IFX_ROOT))
    {
        IFX_DBG("[%s:%d] Owner is TR64. Just returning Success\n",
                __func__, __LINE__);
        goto IFX_Handler; 
    }

    /* We have reached here. This indicates that the function is called in
       context of task other than TR69. Also, either TR69 is running or
       TR69 is dormant. */

    /* Convert the CPE_ID to IFX_CpeId */
    ret = convert_cpeid_pcpeid_owner_of_iid(iid, &xIfxId);

    /* Check for error */
    if (ret != IFX_SUCCESS)
    {
        IFX_DBG("[%s:%d] Convertion Failure\n", __func__, __LINE__);
        goto IFX_Handler;
    }

    IFX_DBG("ALLOC TR69 ID Invoked\n");
    /* Call the Protocol API for allocating TR69 Id for the Child */
    iRet = IFX_AllocTr69Id(&xIfxId, distinctSec); 

    /* Check for error */
    if (iRet != IFX_SUCCESS)
    {
        IFX_DBG("ALLOC TR69 ID Failed\n");
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }
    IFX_DBG("ALLOC TR69 ID Successful\n");

    /* Make the TR69 ID available to caller */
    if ((strlen(xIfxId.sTr69Id) + 1) > MAX_TR69_ID_LEN)
    {
        IFX_DBG("[%s:%d] TR69 ID bigger than buffer\n", __func__, __LINE__);
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }
    strcpy(iid->tr69Id,xIfxId.sTr69Id);
IFX_Handler:
    return (ret);
}

/* 
** =============================================================================
**   Function Name    : ifx_update_map_n_attr
**
**   Description      : This function updates the TR69 mapping section if
**                      operation is ADD or DELETE. It also updates the TR69
**                      Parameter Attribute section if operation is DELETE.
**                      All this is performed for all tasks if TR69 is
**                      compiled in and is either running or dormant. This is
**                      required to keep the TR69 specific sections up-to-date. 
**
**   Parameters       : iid - All related IDs. The cpeId and tr69Id members of
**                      this structure must be filled by caller.
**                      count - Count of all the parameters in the following
**                      list of parameters if the operation is DELETE. If the
**                      operation is ADD, this should be 0 (actually dont care).
**                      array_fvp - List of parameters. If the operation is
**                      DELETE the list will contain all parameters. Only
**                      fieldname member of each element of array is required to
**                      be filled by caller. If operation is ADD, this can be
**                      NULL (actually dont care).
**                      flags - Can be ADD or DELETE
**
**   Return Value     : IFX_SUCCESS - If requested operation is is successful.
**                      IFX_FAILURE - If requested operation is not successful.
**
**   Notes            : 
**
** ============================================================================
*/
int32 ifx_update_map_n_attr(IFX_IN IFX_ID              *iid,
                            IFX_IN uint32              count,
                            IFX_IN IFX_NAME_VALUE_PAIR *array_fvp,
                            IFX_IN uint32              flags)
{
    int32        ret              = IFX_SUCCESS;
    int32        iRet             = IFX_SUCCESS;
    IFX_Id       xIfxId;

    //IFX_DBG("owner=%d,secname=%s,id=%d\n",iid->config_owner,iid->cpeId.secName,iid->cpeId.Id);

    /* Check if TR69 is Compiled in. Just returning IFX_SUCCESS if not
       compiled in. */
    if (!IFX_TR69_COMPILED)
    {
        IFX_DBG("[%s:%d] TR69 Is Not Compiled\n",__func__, __LINE__);
        goto IFX_Handler; 
    }

    /* Check for validity of input parameters */
    if (!iid || ((IFX_DELETE_F_SET(flags)) && ((!array_fvp) || (!count))))
    {
        IFX_DBG("[%s:%d] Invalid Input parameters\n", __func__, __LINE__);
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    /* We have reached here. This indicates that the function is called in
       context of any task. Also, either TR69 is running or TR69 is dormant. */

    /* Convert the CPE_ID to IFX_CpeId */
    ret = convert_cpeid_tr69id_owner_of_iid(iid, &xIfxId);

    /* Check for error */
    if (ret != IFX_SUCCESS)
    {
        IFX_DBG("[%s:%d] Convertion Failure\n", __func__, __LINE__);
        goto IFX_Handler;
    }

    /* Call the Protocol API with appropriate flag to update mapping info */

    if (IFX_INT_ADD_F_SET(flags))
    {
        IFX_DBG("Update Map Section Invoked\n");
        iRet = IFX_UpdateTr69CpeIdMap(&xIfxId,
                                      IFX_TR69ID_MAP_TBL_OPER_ADD_ENTRY); 

        /* Check for error */
        if (iRet != IFX_SUCCESS)
        {
            IFX_DBG("Update Map Section Failed\n");
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }
            IFX_DBG("Update Map Section Successful\n");
    }

    if (IFX_DELETE_F_SET(flags))
    {
        IFX_DBG("Update Map Section Invoked\n");
        iRet = IFX_UpdateTr69CpeIdMap(&xIfxId,
                                      IFX_TR69ID_MAP_TBL_OPER_DEL_ENTRY); 

        /* Check for error */
        if (iRet != IFX_SUCCESS)
        {
            IFX_DBG("Update Map Section Failed\n");
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }
        IFX_DBG("Update Map Section Successful\n");

        IFX_DBG("Update Attribute Section Invoked\n");

       /* Call the Protocol API for allocating TR69 Id for the Child */
        iRet = IFX_DeleteAttrInfo(&(xIfxId.xCpeId));

        /* Check for error */
        if (iRet != IFX_SUCCESS)
        {
            IFX_DBG("Update Attribute Section Failed\n");
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }
        IFX_DBG("Update Attribute Section Successful\n");
    }
IFX_Handler:
    return (ret);
}

/* 
** =============================================================================
**   Function Name    : ifx_free_tr69id
**
**   Description      : This function is just a plcae holder. Nothing is
**                      performed here.
**
**   Parameters       : iid - All related IDs. Currently dont care.
**
**   Return Value     : IFX_SUCCESS - If requested operation is is successful.
**                      IFX_FAILURE - If requested operation is not successful.
**
**   Notes            : 
**
** ============================================================================
*/
int32 ifx_free_tr69id(IFX_IN IFX_ID *iid)
{
    int32 ret = IFX_SUCCESS;

    /* Check if TR69 is Compiled in. Just returning IFX_SUCCESS if not
       compiled in. */
    if (!IFX_TR69_COMPILED)
    {
        IFX_DBG("[%s:%d] TR69 Is Not Compiled\n",__func__, __LINE__);
        goto IFX_Handler; 
    }

IFX_Handler:
    return (ret);
}

int32 ifx_tr69_event_handler(IFX_IN int32 evtType, IFX_IN int32 evtState, IFX_ID *iid,
                             int32 count, IFX_NAME_VALUE_PAIR *array_fvp)
{
    int32         ret        = IFX_SUCCESS;
    IFX_NameValue *pxNVArray = NULL;
    int32         iRet       = IFX_SUCCESS;
    IFX_Id        xIfxId;

    //IFX_DBG("owner=%d,secname=%s,id=%d\n",iid->config_owner,iid->cpeId.secName,iid->cpeId.Id);

    /* Check if TR69 is Compiled in. Just returning IFX_SUCCESS if not
       compiled in. */
    if (!IFX_TR69_COMPILED)
    {
        IFX_DBG("[%s:%d] TR69 Is Not Compiled\n",__func__, __LINE__);
        goto IFX_Handler; 
    }

    /* Check if TR69 is Running. Just returning IFX_SUCCESS if TR69 is
       dormant. */
    if (!IFX_TR69_RUNNING)
    {
        IFX_DBG("[%s:%d] TR69 Is not running."
                "Just Returning Success.\n ",__func__, __LINE__);
        goto IFX_Handler; 
    }

    /* Check for validity of input parameters */
    if (!iid)
    {
        IFX_DBG("[%s:%d] Invalid Input parameters\n", __func__, __LINE__);
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    /* Convert the IFX_ID to IFX_Id */
    ret = convert_cpeid_owner_of_iid(iid, &xIfxId);

    /* Check for error */
    if (ret != IFX_SUCCESS)
    {
        IFX_DBG("[%s:%d] Convertion Failure\n", __func__, __LINE__);
        goto IFX_Handler;
    }

    if (count)
    {
        /* Allocate for IFX_NAME_VALUE_Pair Array */
        IFX_MEM_ALLOC(pxNVArray, IFX_NameValue *, count, sizeof(IFX_NameValue))

        /* Convert parameter name and valueto IFX_NameValue */
        ret = convert_param_namevalue(array_fvp, count, pxNVArray);

        /* Check for error */
        if (ret != IFX_SUCCESS)
        {
            IFX_DBG("[%s:%d] Convertion Failure\n", __func__, __LINE__);
            goto IFX_Handler;
        }
    }

    /* TBD: Temporarily Bypassing all unnecessary Events */
    if (evtType != EVT_TYPE_WAN_IPADDRESS)
    {
        IFX_DBG("Received Event Type %d. Bypassing It.\n", evtType);
        goto IFX_Handler;
    }

    IFX_DBG("Event Notification Invoked.\n");
    iRet = IFX_EventNotify(&xIfxId, count, pxNVArray, evtType, evtState);

    /* Check for error */
    if (iRet != IFX_SUCCESS)
    {
        IFX_DBG("Event Notify Failed\n");
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }
    IFX_DBG("Event Notify Successful\n");
IFX_Handler:
    IFX_MEM_FREE(pxNVArray)
    return (ret);
}


