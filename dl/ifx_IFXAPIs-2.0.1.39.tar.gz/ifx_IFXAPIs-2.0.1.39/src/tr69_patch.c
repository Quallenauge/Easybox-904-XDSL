/* 
** =============================================================================
**   FILE NAME        : tr69_patch.c
**   PROJECT          : AMAZON MAPI
**   DATE             : 01-Jul-2006
**   AUTHOR           : Amazon API Team
**   DESCRIPTION      : This file contains a patch definition to compile
			TR69 Adaptation layer functionality inside IFXAPIs

**   REFERENCES       : 
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/
int viSIPRdFd=0;
