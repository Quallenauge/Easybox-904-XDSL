#include <stdio.h>
#include <stdlib.h>
#include <net/if.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <unistd.h>
//#include "IFX_Util.h"
#include "IFX_Iproxy.h"

static	int		bIgmpEnabled	= 0;

int ifxEnablePhyMulticast
	(
		int		bEnable
	)
{
	char	cmdStr[128];
	int		i 		= 1;
	int		sock	= 0;
	struct ifreq ifreq;

	if( (sock = socket(AF_INET, SOCK_STREAM, 0)) < 0){
		printf("Socket creation error\n");
		return 0;
	}
	
	if( bEnable == 1 ){
		while(1){
			ifreq.ifr_ifindex = i;
			if(ioctl(sock, SIOCGIFNAME, &ifreq) < 0 )
				break;
			if( !strcmp(ifreq.ifr_name, "lo") ){
				i++;
				continue;
			}
			strcpy( cmdStr, "ifconfig ");
			strcat( cmdStr, ifreq.ifr_name);
			strcat( cmdStr, " allmulti");
			system( cmdStr );
			printf("Command: %s is executed\n", cmdStr);
			i++;
		}
	}
	else{
		while(1){
			ifreq.ifr_ifindex = i;
			if(ioctl(sock, SIOCGIFNAME, &ifreq) < 0 )
				break;
			if( !strcmp(ifreq.ifr_name, "lo") ){
				i++;
				continue;
			}
			strcpy( cmdStr, "ifconfig ");
			strcat( cmdStr, ifreq.ifr_name);
			strcat( cmdStr, " -allmulti");
			system( cmdStr );
			printf("Command: %s is executed\n", cmdStr);
			i++;
		}		
	}
	if(sock)
	close(sock);	
	return 1;
}

char* IFX_itoa(int val, int base){
	static char buf[32] = {0};
	int i = 30;
	for(; val && i ; --i, val /= base)
		buf[i] = "0123456789abcdef"[val % base];
	return &buf[i+1];
}

int IFXEnableIgmpProxy
	(
	 	int Mode,
		char	*upstreamIf
	)
{
	char	cmdStr[256];
	char uIf[16];
	char *append = NULL; /*malloc (2 * (sizeof (char)));
	if(append == NULL)
	{
		return 0;
	}
	memset(append,0, sizeof(append));*/
	memset(cmdStr,0, sizeof(cmdStr));
	
	strcpy (uIf, upstreamIf);
	if ((Mode != 1) && ((uIf[0] != 'n') || (uIf[0] != 'p')))
	{
		printf ("Usage: IGMP Proxy runs when mode=1 and uIf=ppp / uIf=nas only !!!\n");
		printf ("Example: #insmod mode=1 uIf=nas0 (when WAN interface is nas)\n");
		printf ("Example: #insmod mode=1 uIf=ppp0 (when WAN interface is PPPoE)\n");
//		free(append);
		return 0;
	}
	
	if( bIgmpEnabled == 1 ) /* Already enabled */
	{
//		free(append);
		return 0;
	}
	
	append = IFX_itoa (Mode, 10); /* for now base=10*/	
	ifxEnablePhyMulticast(1);
	strcpy( cmdStr, "insmod ");
	strcat( cmdStr, IPROXYD_MODULE);
	strcat( cmdStr, " mode=");
	strcat( cmdStr, append);
	strcat( cmdStr, " uIf=");
	strcat( cmdStr, "\"");
	strcat( cmdStr, upstreamIf);
	strcat( cmdStr, "\"");
	system( cmdStr );
	bIgmpEnabled = 1;
//	free(append);

	return 1;
}

int IFXEnableIgmpSnooping
	(
	 	int Mode
	)
{
	char	cmdStr[256];
	char *append = NULL; /*malloc (2 * (sizeof (char)));
	if(append == NULL)
	{
		return 0;
	}
	memset(append,0, sizeof(append));*/
	memset(cmdStr,0, sizeof(cmdStr));
	if ( Mode != 2 )
	{
		printf ("Usage: IGMP Snooping runs when mode=2 only\n");
		printf ("Example: #insmod iproxyd mode=2 \n");
//		free(append);
		return 0;
	}

	if( bIgmpEnabled == 1 ) /* Already enabled */
	{
//		free(append);
		return 0;
	}
	append = IFX_itoa (Mode, 10); /* for now base=10*/	

	ifxEnablePhyMulticast(1);
	strcpy( cmdStr, "insmod ");
	strcat( cmdStr, IPROXYD_MODULE);
	strcat( cmdStr, " mode=");
	strcat( cmdStr, append);

	system( cmdStr );
	bIgmpEnabled = 1;

//	free(append);
	return 1;
}

int IFXDisableIgmpProxyOrSnooping
	(
		void
	)
{
	char	cmdStr[256];

	if( bIgmpEnabled == 0 ) /* Already disabled */
		return 0;

	strcpy( cmdStr, "rmmod ");
	strcat( cmdStr, IPROXYD_MODULE_NAME);
	system( cmdStr );
	bIgmpEnabled = 0;
	ifxEnablePhyMulticast(0);
	
	return 1;
}
