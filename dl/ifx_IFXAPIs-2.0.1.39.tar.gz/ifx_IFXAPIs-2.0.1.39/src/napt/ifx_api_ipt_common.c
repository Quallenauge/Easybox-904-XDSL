/* ============================================================================
 * Copyright (C) 2004 - Infineon Technologies.
 *
 * All rights reserved.
 * ============================================================================
 *
 * ============================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ============================================================================
 *
 * Revision History:
 *      - 2004/07/20, TC Chen
 *         init version
 *      - 2005/10/25, Sumedh ::[ 510251:sumedh Support for DoS Attacks, ALGs, QoS, Policy based Routing ] 
 *	- 2006/04/04, Sumedh ::[ 604041:sumedh Parental Control feature added (Modified MAC Filter)
 *
 * ============================================================================
 */

#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <ifx_api_ipt_common_private.h>
#include <ifx_api_ipt_common.h>
 
 /*
 * ============================================================================
 *                            LOCAL FUNCTIONS
 * ============================================================================
 */

 
 /*
 * ============================================================================
 *                           EXPORTED FUNCTIONS
 * ============================================================================
 */
 
bool
mac_strtoint(char *mac_string, char *mac_int)
{
        unsigned int i = 0;

        if (strlen(mac_string) != ETH_ALEN*3-1)
                return 1;

        for (i = 0; i < ETH_ALEN; i++) {
                long number;
                char *end;

                number = strtol(mac_string + i*3, &end, 16);

                if (end == mac_string + i*3 + 2
                    && number >= 0
                    && number <= 255)
                        mac_int[i] = number;
                else
                    return 1;
                        
        }
        return 0;
}

 
bool IFX_IPT_FLUSH_CHAIN(int type , char *ChainName)
{
    char command[256];
    switch (type)
    {
        case FIREWALL:
            sprintf(command,"%s %s %s", "/usr/sbin/iptables", "-F", ChainName);
            break;
        case NAPT:
            sprintf(command,"%s %s %s %s", "/usr/sbin/iptables", "-t nat", "-F", ChainName);
            break;
	//510251:sumedh start
        case MANGLE:
            sprintf(command,"%s %s %s %s", "/usr/sbin/iptables", "-t mangle", "-F", ChainName);
            break;
	//510251:sumedh end
        default :
            return 1;
    }
    
    ifx_run_command(command);
    return 0;
}
 
bool IFX_IPT_CREATE_SINGLE_CHAIN(int type , char *ChainName)
{
    char command[256];
    switch (type)
    {
        case FIREWALL:
            sprintf(command,"%s %s %s", "/usr/sbin/iptables", "-N", ChainName);
            break;
        case NAPT:
            sprintf(command,"%s %s %s %s", "/usr/sbin/iptables", "-t nat", "-N", ChainName);
            break;
	    //510251:sumedh start
	case MANGLE:
            sprintf(command,"%s %s %s %s", "/usr/sbin/iptables", "-t mangle", "-N", ChainName);
	    break;	
	    //510251:sumedh end

        default :
            return 1;
    }
    
    ifx_run_command(command);
        
    return 0;
}

bool IFX_IPT_SET_SINGLE_RULE(int type, int operation ,char *ChainName, P_IFX_IPT_RULE rule,int target)
{
    char command[256];
    char buffer[256];
    struct in_addr tmp_ip;
    char chan_type[32];
    
    
    memset(command,'\0',256);
    memset(buffer,'\0',256);
    memset(chan_type,'\0',32);
    
    if (strlen(ChainName)<=0)
        return 1;
    if (rule == NULL)
        return 1;

    if (type == NAPT)
    {
        sprintf(chan_type,"-t nat");
    }         
    else if (type == MANGLE) //510251:sumedh
    {
        sprintf(chan_type,"-t mangle");
    }         
    
    snprintf(command,sizeof(command),"%s %s", "/usr/sbin/iptables",chan_type);
    switch ( operation)
    {   
        case ADD:
        strlcat(command," -A ",sizeof(command));
        break;
        case INSERT:
        strlcat(command," -I ",sizeof(command));
        break;
        case DELETE:
        strlcat(command," -D ",sizeof(command));
        break;
        default:
        return 1;
    }
    
    strlcat(command,ChainName,sizeof(command));
    memset(buffer,'\0',256);
    
    if (memcmp(rule->MAC,buffer,6)!=0)
    {
        int i=0;
        snprintf(buffer,sizeof(buffer)," -m mac --mac-source %02X", rule->MAC[0]);
        strlcat(command,buffer,sizeof(command));
        for (i = 1; i < ETH_ALEN; i++)
        {
                snprintf(buffer,sizeof(buffer),":%02X", rule->MAC[i]);
                strlcat(command,buffer,sizeof(command));
        }
    }
    
    switch (rule->protocol)
    {
        case PROTO_ALL:
        strlcat(command," -p all",sizeof(command));
        break;
        case PROTO_ICMP:
        strlcat(command," -p icmp",sizeof(command));
        break;
        case PROTO_TCP:
        strlcat(command," -p tcp",sizeof(command));
        break;    
        case PROTO_UDP:
        strlcat(command," -p udp",sizeof(command));
        break;
        case PROTO_ESP:
        strlcat(command," -p esp",sizeof(command));
        break;
        case PROTO_AH:
        strlcat(command," -p ah",sizeof(command));
        break;
        default:
        break;   
    }
    
    if (rule->srcip)
	{
			tmp_ip.s_addr=rule->srcip;
			if (rule->srcip_mask>0 && rule->srcip_mask<32)
			{
					snprintf(buffer,sizeof(buffer)," -s %s/%d",inet_ntoa(tmp_ip),rule->srcip_mask);
			}else
			{
					snprintf(buffer,sizeof(buffer)," -s %s",inet_ntoa(tmp_ip));
			}
			strlcat(command,buffer,sizeof(command));

	}
    
    if (rule->srcport_start)
    {
        memset(buffer,'\0',256);
        
        if (rule->srcport_end)
        {
            snprintf(buffer,sizeof(buffer)," --sport %d:%d",ntohs(rule->srcport_start),ntohs(rule->srcport_end));
            
        }else
        {
            snprintf(buffer,sizeof(buffer)," --sport %d",ntohs(rule->srcport_start));            
        }        
        strlcat(command,buffer,sizeof(command));
    }
    
    if (strlen(rule->inif)>0)
    {
        snprintf(buffer,sizeof(buffer)," -i %s",rule->inif);
        strlcat(command,buffer,sizeof(command));
    }
    
    if (rule->dstip)
    {
        tmp_ip.s_addr=rule->dstip;
	if (rule->dstip_mask>0 && rule->dstip_mask<32)
	{
       	    snprintf(buffer,sizeof(buffer)," -d %s/%d",inet_ntoa(tmp_ip),rule->dstip_mask);
	}else
	{
            snprintf(buffer,sizeof(buffer)," -d %s",inet_ntoa(tmp_ip));
	}
        strlcat(command,buffer,sizeof(command));
    }
    
    if (rule->dstport_start)
    {
        memset(buffer,'\0',256);
        if (rule->dstport_end)
        {
            sprintf(buffer," --dport %d:%d",ntohs(rule->dstport_start),ntohs(rule->dstport_end));
        }else
        {
            sprintf(buffer," --dport %d",ntohs(rule->dstport_start));
        }
        strcat(command,buffer);
    }
    
    //510251:sumedh start
    if (strlen(rule->outif)>0)
    {
        snprintf(buffer,sizeof(buffer)," -o %s",rule->outif);
        strcat(command,buffer);
    }
    
    if(strlen(rule->diffserv)>0)
    {
	    snprintf(buffer,sizeof(buffer)," -m dscp --dscp %s",rule->diffserv);
	    strcat(command,buffer);
    }	
    //510251:sumedh end

	//604041:Sumedh Parental Control (Modified MAC Filter)
	if(strlen(rule->TIMESTART)>0 && strlen(rule->TIMEEND)>0 && strlen(rule->DAY)>0)
	{
		char continued='0';
		snprintf(buffer,sizeof(buffer)," -m time --timestart %s --timestop %s", rule->TIMESTART, rule->TIMEEND);
		strcat(command, buffer);
		sprintf(buffer," --weekdays ");
		if(rule->DAY[0]=='1')
		{
			strcat(buffer,"Mon");
			continued='1';
		}
		if(rule->DAY[1]=='1')
		{
			if(continued=='1')
				strcat(buffer,",Tue");
			else
				strcat(buffer,"Tue");
			continued='1';
		}
		if(rule->DAY[2]=='1')
		{
			if(continued=='1')
				strcat(buffer,",Wed");
			else
				strcat(buffer,"Wed");
			continued='1';
		}
		if(rule->DAY[3]=='1')
		{
			if(continued=='1')
				strcat(buffer,",Thu");
			else
				strcat(buffer,"Thu");
			continued='1';
		}
		if(rule->DAY[4]=='1')
		{
			if(continued=='1')
				strcat(buffer,",Fri");
			else
				strcat(buffer,"Fri");
			continued='1';
		}
		if(rule->DAY[5]=='1')
		{
			if(continued=='1')
				strcat(buffer,",Sat");
			else
				strcat(buffer,"Sat");
			continued='1';
		}
		if(rule->DAY[6]=='1')
		{
			if(continued=='1')
				strcat(buffer,",Sun");
			else
				strcat(buffer,"Sun");
			continued='1';
		}
		strcat(command, buffer);
	}
	//604041:Sumedh Parental Control (Modified MAC Filter) ends
	
    switch (target)
    {
        case ACCEPT:
            strcat(command," -j ACCEPT");
        break;
        case DROP:
            strcat(command," -j DROP");
            break;
        case SNAT:
            strcat(command," -j SNAT");
            break;
        case DNAT:
            strcat(command," -j DNAT");
            break;
        case MASQUERADE:
            strcat(command," -j MASQUERADE");
            break;
        case RETURN:
            strcat(command," -j RETURN");
        break;    
        case REDIRECT:
            strcat(command," -j REDIRECT");
        break;    
        case IFX_NAPT_SNAT:
            strcat(command," -j IFX_NAPT_SNAT");
        break;    
        case IFX_FW_DENY_LAN_IF_INPUT:   
	    strcat(command," -j IFX_FW_DENY_LAN_IF_INPUT");
        break;    
        case IFX_FW_DENY_WAN_IP_INPUT:   
	    strcat(command," -j IFX_FW_DENY_WAN_IP_INPUT");
        break;    
        case IFX_NAPT_TO_LAN:
            strcat(command," -j IFX_NAPT_TO_LAN");
        break;    
        case IFX_FW_ACCEPT_WAN_IP_INPUT:
            strcat(command," -j IFX_FW_ACCEPT_WAN_IP_INPUT");
        break;    
        case IFX_FW_ACCEPT_LAN_IP_INPUT:
            strcat(command," -j IFX_FW_ACCEPT_LAN_IP_INPUT");
        break;    
        case IFX_FW_ACCEPT_LAN_IP_OUTPUT:
            strcat(command," -j IFX_FW_ACCEPT_LAN_IP_OUTPUT");
        break;    
        case IFX_FW_SERVICES_ACL:
            strcat(command," -j IFX_FW_SERVICES_ACL");
        break;    
	case NAPT_ROUTE:	//510251:sumedh
	    strcat(command," -j NAPT_ROUTE");
	    break; 
	default:
	    return -1;
    }
    
//510251:sumedh start
    if(strlen(rule->route_oif))
    {
	    sprintf(buffer," --oif %s",rule->route_oif);
	    strcat(command, buffer);
    }
    if(rule->route_continue)
    {
	    strcat(command," --continue");
    }
//510251:sumedh end

    if (rule->targetip)
    {
        tmp_ip.s_addr=rule->targetip;
        sprintf(buffer," --to %s",inet_ntoa(tmp_ip));
        strcat(command,buffer);
        if (rule->targetport_start)
        {
            sprintf(buffer,":%d",ntohs(rule->targetport_start));
            strcat(command,buffer);
            if (rule->targetport_end)
            {
                sprintf(buffer,"-%d",ntohs(rule->targetport_end));
            	strcat(command,buffer);
            }
        }        
    }else if (rule->targetport_start)
    {
        sprintf(buffer," --to %d",ntohs(rule->targetport_start));
        strcat(command,buffer);
    }
    //printf("command=%s\n",command);
    return ifx_run_command(command);
}

bool IFX_IPT_SET_RULE2(int type, int operation, char *ChainName, char *proto, char *cmdstr1, char *cmdstr2, char *target)
{
	static char table[3][50] = {
		"",
		"-t nat",
		"-t mangle"
	};
	char command[STR_COMMAND], tmp[1024];
	char protostr[32];

	if (type > (sizeof(table) / sizeof(table[0]) -1)) {
		return -1;
	}

	if (proto != NULL && proto[0] != '\0') {
		strcpy(protostr, "-p ");
		strcat(protostr, proto);
	} else {
		*protostr='\0';
	}
	memset(tmp, 0x00, sizeof(tmp));
	switch (operation) {
		case ADD:
		case INSERT:
			sprintf(command, "%s %s -%c %s %s %s %s -j %s",  "/usr/sbin/iptables", table[type], operation==ADD?'A':'I', ChainName, protostr, cmdstr1, cmdstr2, target);
			ifx_run_command(command);
			break;
		case DELETE:
			sprintf(command, "%s %s -D %s %s %s %s -j %s", "/usr/sbin/iptables", table[type], ChainName, protostr, cmdstr1, cmdstr2, target);
			ifx_run_command(command);
			break;
		case POLICY:
			sprintf(command, "%s -P %s %s", "/usr/sbin/iptables", ChainName, target);
			ifx_run_command(command);
			break;
	}
	//printf("(%s) %s", __FUNCTION__, command);
	return 0;
}
//vipul start
bool IFX_IPT_SET_RULES(int type, int operation, char *ChainName, P_IFX_IPT_RULE pCfg, int *piEnteriesSize,int target)
{
    bool bEnable=0;
    int ret=0;
    int index=0;
    
    switch (operation)
    {
        case ADD:
	case INSERT:
            for (index=0;index<*piEnteriesSize;index++)
            {
                
		ret = IFX_IPT_GET_RULE_STATUS(type, GET_SINGLE_RULE_STATUS,ChainName,&bEnable, &pCfg[index],target);
                if (bEnable==0)
                {

					//printf("\nNO matching rule exists: setting single rule in %s, target=%d\n", ChainName, target);
                    IFX_IPT_SET_SINGLE_RULE(type, operation,ChainName,&pCfg[index],target);
                }
            }
        break;
        case DELETE:
            for (index=0;index<*piEnteriesSize;index++)
            {
		bEnable = 1;
              //  ret = IFX_IPT_GET_RULE_STATUS(type, GET_SINGLE_RULE_STATUS,ChainName,&bEnable, &pCfg[index],target);
                if (bEnable==1)
                {
	               IFX_IPT_SET_SINGLE_RULE(type, DELETE,ChainName,&pCfg[index],target);
                }
            }
        break;
        case DELETE_ALL:
            ret = IFX_IPT_SET_CHAIN_ENABLE(type, GET,ChainName,&bEnable);
            //ret = IFXSetFirewallMacFilterEnable(GET,&bEnable);
            IFX_IPT_FLUSH_CHAIN(type,ChainName);
            //IFXSetFirewallMacFilterEnable(SET,&bEnable);           
            ret = IFX_IPT_SET_CHAIN_ENABLE(type, SET,ChainName,&bEnable);
        break;
        default:
            return -1;
    }
    return 0;
}
//vipul end
/*
Chain IFX_NAPT_DNAT_VS (1 references)
num   pkts bytes target     prot opt in     out     source               destination
1        0     0 DNAT       udp  --  *      *       20.20.20.20          10.10.10.10         udp spts:341:350 dpts:241:250 to:124.124.123.123:500
*/
bool IFX_IPT_GET_SINGLE_RULE_FROM_BUFFER(char *command, P_IFX_IPT_RULE rule, int *target)
{
    char *delim="\t ";
    char *p;
    char *ip_p;
    char *tmp_p;
    char ip_buffer[32];
    
    //num
    p = strtok(command,delim);
    
    //pkts
    p = strtok(NULL,delim);
    
    //bytes
    p = strtok(NULL,delim);
    
    //target
    p = strtok(NULL,delim);
    if(p == NULL)
	return 0;
    if (!strcmp("ACCEPT",p))
    {
        *target = ACCEPT;
    }else if (!strcmp("DROP",p))
    {
        *target = DROP;
    }else if (!strcmp("RETURN",p))
    {
        *target = RETURN;
    }
    else if (!strcmp("SNAT",p))
    {
        *target = SNAT;
    }
    else if (!strcmp("DNAT",p))
    {
        *target = DNAT;
    }
    else if (!strcmp("MASQUERADE",p))
    {
        *target = MASQUERADE;
    }
    else if (!strcmp("REDIRECT",p))
    {
        *target = REDIRECT;
    }
    else if (!strcmp("IFX_NAPT_SNAT",p))
    {
        *target = IFX_NAPT_SNAT;
    }
    else if (!strcmp("IFX_FW_DENY_LAN_IF_INPUT",p))
    {
        *target = IFX_FW_DENY_LAN_IF_INPUT;
    }
    else if (!strcmp("IFX_FW_DENY_WAN_IP_INPUT",p))
    {
        *target = IFX_FW_DENY_WAN_IP_INPUT;
    }
    else if (!strcmp("IFX_NAPT_TO_LAN",p))
    {
        *target = IFX_NAPT_TO_LAN;
    }
    else if (!strcmp("IFX_FW_ACCEPT_WAN_IP_INPUT",p))
    {
        *target = IFX_FW_ACCEPT_WAN_IP_INPUT;
    }
    else if (!strcmp("IFX_FW_ACCEPT_LAN_IP_INPUT",p))
    {
        *target = IFX_FW_ACCEPT_LAN_IP_INPUT;
    }
    else if (!strcmp("IFX_FW_ACCEPT_LAN_IP_OUTPUT",p))
    {
        *target = IFX_FW_ACCEPT_LAN_IP_OUTPUT;
    }
    else if (!strcmp("IFX_FW_SERVICES_ACL",p))
    {
        *target = IFX_FW_SERVICES_ACL;
    }
    else
    {
	   return 1;
    }
    
    // prot                
    p = strtok(NULL,delim);
    if(p == NULL)
	return 1;

    if (!strcmp("all",p))
    {
        rule->protocol=PROTO_ALL;
    }else if (!strcmp("icmp",p))
    {
        rule->protocol=PROTO_ICMP;
    }else if (!strcmp("tcp",p))
    {
        rule->protocol=PROTO_TCP;
    }else if (!strcmp("udp",p))
    {
        rule->protocol=PROTO_UDP;
    }else if (!strcmp("ah",p))
    {
        rule->protocol=PROTO_AH;
    }else if (!strcmp("esp",p))
    {
        rule->protocol=PROTO_ESP;
    }
       
    // opt                
    p = strtok(NULL,delim);
    
    // in                
    p = strtok(NULL,delim);
    if(p == NULL)
	return 1;
    if (*p!='*')
    {
        strcpy(rule->inif,p);
    }
    
    // out                
    p = strtok(NULL,delim);
    if(p == NULL)
	return 1;
    if (*p!='*')
    {
        strcpy(rule->outif,p);
    }
    
    // source                
    p = strtok(NULL,delim);
    if(p == NULL)
	return 1;
    if (strcmp("0.0.0.0/0",p)!=0)
    {
	ip_p = strchr(p,'/');
	if (ip_p)
	{
	    ip_p[0]='\0';
	    strcpy(ip_buffer,p);
	    rule->srcip = inet_addr(ip_buffer);
       	    rule->srcip_mask = atoi(ip_p+1);
	}else
	{
            rule->srcip = inet_addr(p);
	}
    }
    
    // destination                
    p = strtok(NULL,delim);
    if(p == NULL)
	return 1;
    
    if (strcmp("0.0.0.0/0",p)!=0)
    {
	ip_p = strchr(p,'/');
	if (ip_p)
	{
	    ip_p[0]='\0';
            strcpy(ip_buffer,p);
	    //strncpy(ip_buffer,p,ip_p-p);
            rule->dstip = inet_addr(ip_buffer);
            rule->dstip_mask = atoi(ip_p+1);
	}else
	{
            rule->dstip = inet_addr(p);
	}
    }
        
    // options                
    p = strtok(NULL,"\n");
    if(p == NULL)
	return 1;
    while(*p==' ')
        p++;
    
    if ( (tmp_p = strstr(p,"spt:"))!=NULL)
    {
        char *end_p;
        char buffer[256];
        memset(buffer,0,256);
        tmp_p+=4;
        end_p = strchr(tmp_p,' ');
    	if(end_p == NULL)
		return 1;
        memcpy(buffer,tmp_p,end_p-tmp_p);
        rule->srcport_start = atoi(buffer);
    }
    if ( (tmp_p = strstr(p,"spts:"))!=NULL)
    {
        char *end_p;
        char buffer[256];
        
        memset(buffer,0,256);
        tmp_p+=5;
        end_p = strchr(tmp_p,':');
    	if(end_p == NULL)
		return 1;
        memcpy(buffer,tmp_p,end_p-tmp_p);
        rule->srcport_start = atoi(buffer);
        memset(buffer,0,256);
        tmp_p=end_p+1;
        end_p = strchr(tmp_p,' ');
    	if(end_p == NULL)
		return 1;
        memcpy(buffer,tmp_p,end_p-tmp_p);
        rule->srcport_end = atoi(buffer);
    }
    
    if ( (tmp_p = strstr(p,"dpt:"))!=NULL)
    {
        char *end_p;
        char buffer[256];
        
        memset(buffer,0,256);
        tmp_p+=4;
        end_p = strchr(tmp_p,' ');
    	if(end_p == NULL)
		return 1;
        memcpy(buffer,tmp_p,end_p-tmp_p);
        rule->dstport_start = atoi(buffer);
    }
    if ( (tmp_p = strstr(p,"dpts:"))!=NULL)
    {
        char *end_p;
        char buffer[256];
        
        memset(buffer,0,256);
        tmp_p+=5;
        end_p = strchr(tmp_p,':');
    	if(end_p == NULL)
		return 1;
        memcpy(buffer,tmp_p,end_p-tmp_p);
        rule->dstport_start = atoi(buffer);
        memset(buffer,0,256);
        tmp_p=end_p+1;
        end_p = strchr(tmp_p,' ');
    	if(end_p == NULL)
		return 1;
        memcpy(buffer,tmp_p,end_p-tmp_p);
        rule->dstport_end = atoi(buffer);
    }
    
    if ( (tmp_p = strstr(p,"MAC "))!=NULL)
    {
        char *end_p;
        char buffer[256];
        
        memset(buffer,0,256);
        tmp_p+=4;
        end_p = strchr(tmp_p,' ');
    	if(end_p == NULL)
		return 1;
        memcpy(buffer,tmp_p,end_p-tmp_p);
	buffer[end_p-tmp_p] = '\0';
        mac_strtoint(buffer,(char *)rule->MAC);
    }
    
    if ( (tmp_p = strstr(p,"to:"))!=NULL)
    {
        char *space_p,*colon_p;
        char buffer[256];
    
        memset(buffer,0,256);
        tmp_p+=3;
        space_p = strchr(tmp_p,' ');
    	if(space_p == NULL)
		return 1;
        colon_p = strchr(tmp_p,':');
        if (colon_p && space_p > colon_p)
        {
            char *dash_p;
            dash_p = strchr(tmp_p,'-');
            if (dash_p && space_p > dash_p)
            {
                memcpy(buffer,dash_p+1,space_p - dash_p);
                rule->targetport_end = atoi(buffer);
                space_p = dash_p;
                memset(buffer,0,256);
            }
            memcpy(buffer,colon_p+1,space_p - colon_p);
            rule->targetport_start = atoi(buffer);
            
            memset(buffer,0,256);
            space_p = colon_p;
        }
        memcpy(buffer,tmp_p,space_p-tmp_p);
	buffer[space_p-tmp_p] = '\0';
        rule->targetip = inet_addr(buffer);
    }
    if ( (tmp_p = strstr(p,"redir ports"))!=NULL)
    {
        char *end_p;
        char buffer[256];
        
        memset(buffer,0,256);
        tmp_p+=12;
        end_p = strchr(tmp_p,' ');
    	if(end_p == NULL)
		return 1;
        memcpy(buffer,tmp_p,end_p-tmp_p);
        rule->targetport_start = atoi(buffer);

    }
  if ( (tmp_p = strstr(p,"redir ports"))!=NULL)
    {
        char *end_p;
        char buffer[256];

        memset(buffer,0,256);
        tmp_p+=5;
        end_p = strchr(tmp_p,'-');
    	if(end_p == NULL)
		return 1;
        memcpy(buffer,tmp_p,end_p-tmp_p);
        rule->targetport_start = atoi(buffer);
        memset(buffer,0,256);
        tmp_p=end_p+1;
        end_p = strchr(tmp_p,' ');
    	if(end_p == NULL)
		return 1;
        memcpy(buffer,tmp_p,end_p-tmp_p);
        rule->targetport_end = atoi(buffer);
    }
    
    return 0;
}


bool IFX_IPT_GET_RULES(int type, char *ChainName, char *pBuffer,int size, int *pRetSize,int target)
{
    FILE *fp;
    int loop=0;
    int ret=0;
    char command[256];
    int rule_target;
    *pRetSize = 0;
    char chan_type[32];
    
    P_IFX_IPT_RULE prule=(P_IFX_IPT_RULE)pBuffer;
    
    if ( strlen(ChainName) == 0 )
        return 1;
        
    remove(IPT_TMP_FILE);
    
    memset(chan_type,0,32);
    if (type == NAPT)
    {
        sprintf(chan_type,"-t nat");
    }
    
    sprintf(command,"%s %s -L %s -v --line-numbers -n > %s ","/usr/sbin/iptables", chan_type,ChainName, IPT_TMP_FILE);
    ifx_run_command(command);
    
    if ( (fp = fopen(IPT_TMP_FILE,"r")) == NULL)
    {
        return 1;
    }
    
    // skip unwant data
    for (loop=0;loop<2;loop++)
    {
        if ( fgets(command,256,fp) == NULL )
        {
            ret = 1;
            goto FUNCTION_EXIT;
        }
    }
    
    while( fgets(command,256,fp) != NULL )
    {
        if (( (*pRetSize+1) * sizeof(P_IFX_IPT_RULE))>=size)
        {
            ret = 1;
            goto FUNCTION_EXIT;
        }
        
        memset(prule,0,sizeof(P_IFX_IPT_RULE));            
        if ( !IFX_IPT_GET_SINGLE_RULE_FROM_BUFFER(command,prule,&rule_target))
        {
            if (target == rule_target)
            {
                (*pRetSize)++;
                prule++;
            }
        }
    }
    
FUNCTION_EXIT:    
    fclose(fp);
    remove(IPT_TMP_FILE);
    return 1;
}


bool IFX_IPT_GET_RULE_STATUS(int type, int operation, char *ChainName, bool *pbEnable,P_IFX_IPT_RULE rule, int target)
{
    char command[256];
    FILE *fp;
    int loop=0;
    int ret=0;
    int rule_target;
    IFX_IPT_RULE dev_rule;
    char chan_type[32];
    
    if ( strlen(ChainName) == 0 )
        return 1;
        
    remove(IPT_TMP_FILE);
    
    memset(chan_type,0,32);
    if (type == NAPT)
    {
        sprintf(chan_type,"-t nat");
    }
    else if(type ==MANGLE)
    {
	sprintf(chan_type,"-t mangle");
    }
    
    sprintf(command,"%s %s -L %s -v --line-numbers -n > %s ","/usr/sbin/iptables", chan_type, ChainName, IPT_TMP_FILE);
    ifx_run_command(command);
    
    if ( (fp = fopen(IPT_TMP_FILE,"r")) == NULL)
    {
        return 1;
    }
    
    // skip unwant data
    for (loop=0;loop<2;loop++)
    {
        if ( fgets(command,256,fp) == NULL )
        {
            ret = 1;
            goto FUNCTION_EXIT;
        }
    }
    
    switch (operation)
    {
        case GET_CHAIN_STATUS:
            if ( fgets(command,256,fp) == NULL )
            {
                *pbEnable = FALSE;
                goto FUNCTION_EXIT;
            }else
            {
                *pbEnable = TRUE;
                goto FUNCTION_EXIT;
            }
        break;
        case GET_SINGLE_RULE_STATUS:
            while( fgets(command,256,fp) != NULL )
            {
                memset(&dev_rule,0,sizeof(IFX_IPT_RULE));
                if ( !IFX_IPT_GET_SINGLE_RULE_FROM_BUFFER(command,&dev_rule,&rule_target))
                {
			

/*		      IFX_API_LOG("\nproto:%d:%d\n srcip:%u:%u\nsrcmask:%u:%u\nsportstart:%d:%d\n" \
				     "sportend:%d:%d\ninif%s:%s\ndip:%u:%u\ndstmask:%u:%u\n" \
                                     "dportstart:%d:%d\ndportend:%d:%d\noutif%s:%s\n",
                                     dev_rule.protocol,rule->protocol,
                                     (unsigned int)dev_rule.srcip,(unsigned int)rule->srcip,
				     dev_rule.srcip_mask,rule->srcip_mask,
                                     dev_rule.srcport_start,rule->srcport_start,
                                     dev_rule.srcport_end,rule->srcport_end,
				     dev_rule.inif,rule->inif,
                                     (unsigned int)dev_rule.dstip,(unsigned int)rule->dstip,
                                     dev_rule.dstip_mask,rule->dstip_mask,
				     dev_rule.dstport_start,rule->dstport_start,
				     dev_rule.dstport_end,rule->dstport_end,
                                     dev_rule.outif,rule->outif); */
		   if (rule_target == target && !memcmp(rule,&dev_rule,sizeof(IFX_IPT_RULE)))
                    {
                        *pbEnable = TRUE;
                        goto FUNCTION_EXIT;
                    }
                }
            }
            *pbEnable = FALSE;
            goto FUNCTION_EXIT;
        break;
        default:
            ret = 1;
            goto FUNCTION_EXIT;
        break;
    }
    
FUNCTION_EXIT:    
    fclose(fp);
    remove(IPT_TMP_FILE);
    
    return ret;       
}


bool IFX_IPT_SET_CHAIN_ENABLE(int type ,int operation,char *ChainName, bool *pbEnable)
{
    /* char command[256]; */
    int ret;
    IFX_IPT_RULE query_rule;
    bool bEnable;
    char chan_type[32];
    
    memset(chan_type,0,32);
    memset(&query_rule,0,sizeof(IFX_IPT_RULE));
    
    if (type == NAPT)
    {
        sprintf(chan_type,"-t nat");
        
    }
    switch (operation)
    {
        case GET:
            query_rule.protocol=PROTO_ALL;
            
	    if (!strcmp(ChainName,"PREROUTING") || !strcmp(ChainName,"IFX_FW_SERVICES_ACL"))
	    {
            	ret = IFX_IPT_GET_RULE_STATUS(type, GET_SINGLE_RULE_STATUS,ChainName,&bEnable, &query_rule,ACCEPT);
	    }else
	    {
            ret = IFX_IPT_GET_RULE_STATUS(type, GET_SINGLE_RULE_STATUS,ChainName,&bEnable, &query_rule,RETURN);
	    }
            
            if (bEnable)
                *pbEnable=0;
            else
                *pbEnable=1;
            
        break;             
        case SET:
            switch (*pbEnable)
            {
                case FALSE:
                    ret = IFX_IPT_SET_CHAIN_ENABLE(type , GET,ChainName,&bEnable);
                    if (bEnable==1)
					{
						if (!strcmp(ChainName,"PREROUTING") || !strcmp(ChainName,"IFX_FW_SERVICES_ACL"))
						{
			#if 0 /* [ 23122006, Ritesh */
							sprintf(command,"/usr/sbin/iptables %s -I %s -p ALL -j ACCEPT", chan_type, ChainName);
	                        ifx_run_command(command);
			#else /* ][ */
							IFX_IPT_SET_RULE2(type, INSERT, ChainName, "ALL", "", "", "ACCEPT");
			#endif /* ] */
						} else {
#if 0 /* [ 23122006, Ritesh */
    	                    sprintf(command,"/usr/sbin/iptables %s -I %s -p ALL -j RETURN", chan_type, ChainName);
        	                ifx_run_command(command);
#else /* ][ */
							IFX_IPT_SET_RULE2(type, INSERT, ChainName, "ALL", "", "", "RETURN");
#endif /* ] */
						}
                    }
                    break;
                case TRUE:
                    ret = IFX_IPT_SET_CHAIN_ENABLE(type , GET,ChainName,&bEnable);
                    if (bEnable==0)
					{
						if (!strcmp(ChainName,"PREROUTING") || !strcmp(ChainName,"IFX_FW_SERVICES_ACL"))
						{
#if 0 /* [ 23122006, Ritesh */
							sprintf(command,"/usr/sbin/iptables %s -D %s -p ALL -j ACCEPT", chan_type, ChainName);
							ifx_run_command(command);
#else /* ][ */
							IFX_IPT_SET_RULE2(type, DELETE, ChainName, "ALL", "", "", "ACCEPT");
#endif /* ] */
						}else
						{
#if 0 /* [ 23122006, Ritesh */
							sprintf(command,"/usr/sbin/iptables %s -D %s -p ALL -j RETURN", chan_type, ChainName);
							ifx_run_command(command);
#else /* ][ */
							IFX_IPT_SET_RULE2(type, DELETE, ChainName, "ALL", "", "", "RETURN");
#endif /* ] */
						}
					}
                    break;;
                default :
                    return 1;
            }
        break;
    }
    
    return 0;
}

