#ifndef __IFX_COMMON_H
#define __IFX_COMMON_H

#define BUF_SIZE_50K                    32768 //604181: Sumedh - change size of buffer to account for increased size of rc.conf
#define BUF_SIZE_1K                     1024
#define MAX_DATA_LEN                    128 /* 64 */
#define MAX_FILELINE_LEN                256
#define MAX_FILENAME_LEN                256
#define MAX_TAG_LEN                     64
#define MAX_NAME_LEN                    96
#define	FALSE				0
#define TRUE				1
#define FILE_UPDATE_TMP                    "/tmp/update.tmp"


enum {
    ATM_QOS_UBR = 0,
    ATM_QOS_CBR,
    ATM_QOS_NRT_VBR,
    ATM_QOS_RT_VBR,
};

extern int ifx_run_command(char *command);

extern int ifx_create_pid_file(char *file_prefix);

extern int ifx_get_process_pid(char *file_prefix);

extern int ifx_rm_pid_file(char *file_prefix);

extern void ifx_rm_pid_file_atexit(void);

extern int ifx_validate_pid(pid_t pid, char *cmd_arg);

extern char *ifx_GetCfgDatafromString(char *pString, char *pSymbol);

extern void ifx_web_convert_string(char *p);

extern int ifx_GetCfgData(char *pFileName, char *pTag, char *pData, char *pRetValue);

extern int ifx_dhcp_renew(char * itf_name);

extern int ifx_dhcp_release(char * itf_name);

extern int ifx_flash_write(void);

extern char *ifx_get_atm_qos_name_by_id(int id);

extern int ifx_change_system_username_password(char *name, char *pasword);

extern char *ifx_strstr(const char *origin, const char *substr);

extern int ifx_SetCfgData(const char* pFileName, const char* pTag, int nDataCount, const char* pData, ...);

#endif /* ] ! __IFX_COMMON_H */
