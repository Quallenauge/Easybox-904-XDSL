/*****************************************************************************
** FILE NAME     : ifx_common_defs.h
** PROJECT       : TR69
** MODULES       : Common libs
** SRC VERSION   : V1.0
** DATE          : 14-01-2004
** AUTHOR        : TR69 Team
** DESCRIPTION   :
** REFERENCE     : 
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author      $Comment
*****************************************************************************/
#ifndef		__IFX_COMMON_DEFS_H__
#define		__IFX_COMMON_DEFS_H__


#define	PUBLIC
#define	EXTERN			extern
#define	STATIC			static

#define	PRINT			printf

#define	IN
#define	OUT
#define	IN_OUT

/* updated by shweta */
#define nullptr(Type)	(Type *)NULL

typedef char               char8;
typedef unsigned char      uchar8;
typedef char               int8;
typedef unsigned char      uint8;
typedef short int	         int16;
typedef unsigned short int	uint16;
typedef int                int32;
typedef unsigned int	      uint32;

/* updated by radvajesh*/
typedef long long int      int64;
typedef unsigned long long int	uint64;

typedef float              float32;
typedef double             float64;
typedef float              double32;
typedef double             double64;
typedef long               long32;
typedef unsigned long      ulong32;
typedef char               bool;
typedef char               boolean;


#endif	/* __IFX_COMMON_DEFS_H__ */
