/******************************************************************************
** SRC_FILE      : IFX_TLIB_Import.h
** PROJECT       : TR69
** MODULES       : Common Libs
** SRC VERSION   : V1.0
** DATE          : 11-02-2003
** AUTHOR        : Bharathraj Shetty
** DESCRIPTION   :
** REFERENCE     : Coding guide lines.
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author      $Comment
******************************************************************************/



#ifndef _IFIN_TLIB_IMPORT_H_
# define _IFIN_TLIB_IMPORT_H_

#define IFIN_TLIB_ONE_TIME_TIMER 0
#define IFIN_TLIB_PERIODIC_TIMER 1

#define IFIN_TLIB_FAIL 0 
#define IFIN_TLIB_SUCCESS 1
#define IFIN_TLIB_INVALID_TIMER_ID 2

typedef void (* pfnVoidFunctPtr)(void *);

int8 IFIN_TLIB_TimersInit(uint16 unNumOfTimers);

int8 IFIN_TLIB_StartTimer(uint16 *punTimerId,uint32 uiTimerValue,
		uint8 ucTimerType, pfnVoidFunctPtr pfn_IFIN_TLIB_CallBackfn,
	  void *pCallBackFnParm);

int32 IFIN_TLIB_StopTimer(uint16 unTimerId);

int8 IFIN_TLIB_TimersDelete(void);

#endif
