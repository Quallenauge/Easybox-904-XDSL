/**************************************************************************
** FILE NAME     : IFX_OSInterface.h
** PROJECT       : TR69
** MODULES       : Common Libs.
** SRC VERSION   : V2.0 
** DATE          : 15-12-2004 
** AUTHOR        : TR69 Team
** DESCRIPTION   : Function prototypes for OS dependent functions.
** REFERENCE     : Coding guide lines.
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author      $Comment
***********************************************************************/
#ifndef __IFIN_TR69_OSINTERFACE_H__
#define __IFIN_TR69_OSINTERFACE_H__

int32
IFIN_TR69_CreateFifo(char8* szPathName,
    int32 iMode);

int32
IFIN_TR69_OpenFifo(char8* szPathName,
    int32 iOFlag,
    int32* piReadFd);

int32
IFIN_TR69_OpenUdpSocket(int32* psocRtpFd,
    int16 nLocalPort);

int32
IFIN_TR69_SendTo(int32 socFd,
    char8* pszMsgBuffer,
    int32 iMsgLen,
    char8* pszRemoteIp,
    int16 nRemotePort);

int32
IFIN_TR69_RecvFrom(int32 socFd,
    char8* pszMsgBuffer,
    char8* pszRemoteIp,
    int16 nRemotePort);

void
IFIN_TR69_Close(int32 isocFd);

void
IFIN_TR69_DeleteFifo(int32 iFifoFd,
    char8* szPathName);

int
IFIN_TR69_Get_MAC_Address(unsigned char* pauc_MAC_Address);

int32
IFIN_TR69_Generate_GUID(uchar8* pus_guid);

e_IFIN_TR69_Return
IFIN_TR69_GetHostInfo(char8* pc_Hostip);

#endif /*__IFIN_TR69_OSINTERFACE_H__*/
