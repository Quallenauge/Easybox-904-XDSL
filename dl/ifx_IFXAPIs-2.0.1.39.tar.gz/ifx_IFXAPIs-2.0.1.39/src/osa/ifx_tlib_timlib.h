/******************************************************************************
** SRC_FILE      : IFX_TLIB_Timelib.h
** PROJECT       : TR69
** MODULES       : Common Libs
** SRC VERSION   : V1.0
** DATE          : 11-02-2003
** AUTHOR        : Bharathraj Shetty
** DESCRIPTION   :  
** REFERENCE     : Coding guide lines.
** COPYRIGHT     : Copyright (c) 2006
**                 Infineon Technologies AG,
**                 Am Campeon 1-12, 85579 Neubiberg, Germany
**
** Any use of this software is subject to the conclusion of a respective
** License agreement. Without such a License agreement no rights to the
** software are granted
**
** HISTORY       :
** $Date       $Author      $Comment
 *****************************************************************************/

#ifndef _IFIN_TLIB_TIMLIB_H_
# define _IFIN_TLIB_TIMLIB_H_

#define IFIN_TLIB_ONE_TIME_TIMER 0
#define IFIN_TLIB_PERIODIC_TIMER 1

#define IFIN_TLIB_FAIL 0
#define IFIN_TLIB_SUCCESS 1
#define IFIN_TLIB_INVALID_TIMER_ID 2


#define TRUE 1
#define FALSE 0

typedef void (* pfnVoidFunctPtr)(void *);

typedef struct  {
	
					uint8 ucFree;
					uint16 unTimerIndex;
					uint32 uiTimerValue;
					uint32 uiTimerTick;
					uint8 ucTimerType;
					pfnVoidFunctPtr pfn_IFIN_TLIB_CallBackfn;
					void *pCallBackFnParm;
					uint16 unPrevIndex;
					uint16 unNextIndex;
				 }x_IFIN_TLIB_TimerInfo;
						  
x_IFIN_TLIB_TimerInfo *pxTimerList;
	
					
struct x_IFIN_TLIB_TimMgtInfo{
				x_IFIN_TLIB_TimerInfo *pxTimerList;
				uint16 unActTimLstHeadIndex;
				uint16 unFreeTimLstHeadIndex;
				uint16 unFreeTimLstTailIndex;
				uint16 unMaxNumOfTimer;
			 }vx_IFIN_TLIB_TimMgtInfo;


int8 IFIN_TLIB_TimersInit(uint16 unNumOfTimers);

int8 IFIN_TLIB_StartTimer(uint16 *punTimerId,uint32 uiTimerValue,
		uint8 ucTimerType, pfnVoidFunctPtr pfn_IFIN_TLIB_CallBackfn,
	  void *pCallBackFnParm);

int32 IFIN_TLIB_StopTimer(uint16 unTimerId);

int8 IFIN_TLIB_TimersDelete(void);						

void IFIN_TLIB_InitializeTimerList(uint16 unNumOfTimers);

void IFIN_TLIB_InsertTimerIntoActList(x_IFIN_TLIB_TimerInfo *pxTempNode,
		uint32 uiTimerValue,uint8 ucTimerType,
		pfnVoidFunctPtr pfn_IFIN_TLIB_CallBackfn, void *pCallBackFnParm);

int8 IFIN_TLIB_GetTimerNode(x_IFIN_TLIB_TimerInfo **pxTimerNode);

void IFIN_TLIB_InitializeTimerNode(x_IFIN_TLIB_TimerInfo *pxTimerNode,
		uint32 uiTimerValue,uint8 ucTimerType,
		pfnVoidFunctPtr pfn_IFIN_TLIB_CallBackfn, void *pCallBackFnParm);

void IFIN_TLIB_SetTimer(uint32 uiUsec);

void IFIN_TLIB_FreeListHandler(x_IFIN_TLIB_TimerInfo *pxTempNode);

void IFIN_TLIB_CurrTimerExpiry(int signo);

uint32 IFIN_TLIB_GetCurrTime(void);

int8 IFIN_TLIB_CheckForEqualTimer(uint32 uiCurrTime);

#endif
