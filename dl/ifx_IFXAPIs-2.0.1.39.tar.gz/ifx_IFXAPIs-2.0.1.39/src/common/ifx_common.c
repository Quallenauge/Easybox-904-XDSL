
/* 
** =============================================================================
**   FILE NAME        : ifx_common.c
**   PROJECT          : AMAZON MAPI
**   DATE             : 19-Jun-2006
**   AUTHOR           : Amazon API Team
**   DESCRIPTION      : This file contains the functions related to Amazon
                       Database(rc.conf) Management

**   REFERENCES       : 
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/
/*
000002:tc.chen 2005/06/10 add get_adsl_rate and ifx_makeCMV api
*/

//303002:JackLee 2005/06/16 Fix_webUI_firmware_upgrading_causes_webpage_error_issue
//508101:tc.chen 2005/08/10 fix ifxCfgData can not get data if the tag name is at the beginning of the file.
/* 512151:jelly lin:2005/12/15:add new feature "firmware upgrade" */ 
// 608291:jelly 2006/8/29 fix rootfs.img upgrade bug
//6090602:hsumc change default libcrypt-0.9.26.so to libcrypt-0.9.27.so
#define _GNU_SOURCE
#include <stdio.h>
#include <syslog.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/wait.h>
/* 000002:Nirav start */
/* file locks & versioning */
#include <sys/time.h>
#include <sys/file.h>
/* 000002:Nirav end */
#include "ifx_common.h"
#if defined(IFX_SMALL_FOOTPRINT) && defined(IFX_DLOAD_LIBCRYPT)
//6090602:hsumc change default libcrypt-0.9.26.so to libcrypt.so
#define LIBCRYPT	"libcrypt.so.0"
#include <dlfcn.h>
#else
#include "crypt.h"
#endif

/* 000002:Nirav start */
#include <fcntl.h>
//#define uint32_t		unsigned int
//#define uint8_t			unsigned char
#ifndef HOSTENV
#include "image.h"
#endif
#include "crc32.h"
/* 000002:Nirav end */
//000002:tc.chen start
#ifndef DONT_USE_IFX_BASIC_TYPES_H
#include <sys/types.h>
#endif // DONT_USE_IFX_BASIC_TYPES_H

#include <sys/stat.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <linux/ioctl.h>
#include <linux/sockios.h>

#if 0 /* defined in u-boot/..../types.h */
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
#if (_MIPS_SZLONG == 64)
typedef unsigned long u64;
#elif defined(__GNUC__) && !defined(__STRICT_ANSI__)
typedef unsigned long long u64;
#endif
#endif // 0


//#include <linux/ethtool.h>

#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
// #include <drv_dsl_cpe_api_config.h>
#include <drv_dsl_cpe_api.h>
#include <drv_dsl_cpe_api_ioctl.h>

#define ADSL_DEV	"/dev/dsl_cpe_api"
#endif /* CONFIG_PACKAGE_IFX_DSL_CPE_API */


//000002:tc.chen end
//7112801: santosh
#ifdef CONFIG_FEATURE_IFX_ADM6996_UTILITY
#include "admioctl.h"
#endif

#define IFX_MAX_PID_FILENAME	100
#define IFX_PID_FILE_PATH		"/var/run"
#include "ifx_cfg.h"

#undef DHCLIENT
#define UDHCPC

#ifdef DHCLIENT
	#define DHCP_COMMAND "dhclient"
#endif

#ifdef UDHCPC
	#define DHCP_COMMAND "udhcpc -i"
#endif


#ifdef IFX_LOG_DEBUG
#ifndef IFX_DBG
	#define IFX_DBG(fmt, args...)	printf("(%s)" fmt, __func__, ##args)
#endif

#endif
static char ifx_command_buff[200] = {'\0'};

int ifx_run_command(char *command)
{
    int status =0,ret = 0; 

    status = system(command);
    if(status != -1)
    {
        waitpid(-1,&status,0);
        if (WIFEXITED(status))     
        {
            ret = WEXITSTATUS(status);
#ifdef IFX_LOG_DEBUG
        // IFX_DBG("\n Command status is %d\n", ret);
#endif
        } 
        else
        {
#ifdef IFX_LOG_DEBUG
    IFX_DBG("\n ERROR : system command not exited properly \n");
#endif
            exit(0);
        }
    }
    return ret;
}

int ifx_dhcp_renew(char * itf_name)
{
    sprintf(ifx_command_buff,"%s %s",DHCP_COMMAND,itf_name);
#ifdef IFX_LOG_DEBUG
    IFX_DBG("\n Now Command is %s\n",ifx_command_buff);
#endif
    return ifx_run_command(ifx_command_buff);
}

int ifx_dhcp_release(char * itf_name)
{
    sprintf(ifx_command_buff,"%s -r %s",DHCP_COMMAND,itf_name);
#ifdef IFX_LOG_DEBUG
    IFX_DBG("\n Now Command is %s\n",ifx_command_buff);
#endif
    return ifx_run_command(ifx_command_buff);
}

/*****************************************************************************
* Function Name: ifx_flash_write
* Description  : save configuration data 
* Input Value  : 
* Output Value :
* Return Value : 0:Fail 1: Success
* Notes :
*****************************************************************************/
int ifx_flash_write(void)
{
  ifx_run_command("/etc/rc.d/backup");
  return 1;
}

// 000020:jelly:start:7/28
int ifx_flash_write_voip_config(void)
{
  ifx_run_command("/etc/rc.d/backup_voip");
  return 1;
}
// 000020:jelly:end

char *ifx_get_atm_qos_name_by_id(int id)
{
    switch (id)
    {
    case ATM_QOS_CBR:
        return "CBR";
    case ATM_QOS_RT_VBR:
        return "RT-VBR";
    case ATM_QOS_NRT_VBR:
        return "NRT-VBR";
    case ATM_QOS_UBR_PLUS:    /* 507121:linmars */
        return "UBR+";
    case ATM_QOS_UBR:
    default:
        break;
    }
    return "UBR";
}

#ifndef HOSTENV
int ifx_change_system_username_password(char *name, char *password)
{
#if 0 /* FIXME: it will overwrite system user configuration */
    const char *fname = "/ramdisk/flash/passwd";
    FILE *fp = NULL;
    char *cp = NULL;
#if defined(IFX_SMALL_FOOTPRINT) && defined(IFX_DLOAD_LIBCRYPT)
    char *(*crypt_ptr)(char *,char *) = NULL;
    void *dlHandle = NULL;
    char *error = NULL;
#endif

    if ((fp = fopen(fname, "w+")) == NULL)
    {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\nCan't open/create file %s\n", fname);
#endif
        return -1;
    }
#if defined(IFX_SMALL_FOOTPRINT) && defined(IFX_DLOAD_LIBCRYPT)
    dlHandle = dlopen(LIBCRYPT,RTLD_LAZY);
    if(dlHandle) {
        crypt_ptr = dlsym(dlHandle,"crypt");
        if((error = dlerror()) != NULL) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG( "could not find function crypt in libcrypt. Error : %s\n",error);
#endif
	}
	if (crypt_ptr != NULL)
		cp = (char *)(*crypt_ptr)(password, "$1$");
	dlclose(dlHandle);
    } else {
#ifdef IFX_LOG_DEBUG
    IFX_DBG( "could not open library %s",LIBCRYPT);
#endif
    }
#else
    cp = (char *)crypt(password, "$1$");
#endif
    fprintf(fp, "admin:%s:0:0:root:/root:/bin/sh\n", cp);
		fprintf(fp, "root:%s:0:0:root:/root:/bin/sh\n", cp);
    fflush(fp);
    fclose(fp);
#endif
    char sCommand[MAX_FILELINE_LEN];
    int ret = 0;
#ifdef CONFIG_FEATURE_SAMBA
    sprintf(sCommand, "/usr/sbin/update_user.sh mod root %s;/usr/sbin/update_user.sh mod admin %s", password, password);
    ret = system(sCommand);
#else /* CONFIG_FEATURE_SAMBA */
    sprintf(sCommand, "(sleep 1; echo \"%s\"; sleep 1; echo \"%s\") | passwd %s > /dev/null 2>&1", password, password, name);
    ret = system(sCommand);
#endif /* !CONFIG_FEATURE_SAMBA */
    return ret;
}
#endif // HOSTENV

/* 000002:Nirav start */
#define TEMP_BUF	4096
#define	RESTART_PROCESS_FILE	"/tmp/restart_porcess.sh"

int ifx_chkImage(char *name,char *errorMsg,char *img_type,int *iExapndDir)
{
	char buf[TEMP_BUF];
	int fd_img;
	int len;
	image_header_t img_header;
	unsigned int crc;
	int retval = 0;

	fd_img = open(name,O_RDONLY);
	if(fd_img <= 0)
	{
		sprintf(errorMsg,"Could not open image %s\n",name);
		retval = 1;
		goto abort;
	}
	read(fd_img,&img_header,sizeof(image_header_t));
	if(img_header.ih_magic != IH_MAGIC)
	{
		//sprintf(errorMsg,"The image %s does not contain valid header\n",name);
		sprintf(errorMsg,"%s","Firmware Upgrade failed as the image does not contain valid header.\nRestoring the previous image.. Please wait for Reboot to complete.\n");
		retval = 1;
		goto abort;
	}

	crc = 0x00000000 ^ 0xffffffff;
	len = 0;
	buf[0]='\0';
	while((len = read(fd_img,buf,sizeof(buf) - 1)) > 0)
	{
		crc = crc32(crc,buf,len);
		buf[0]='\0';
	}
	crc ^= 0xffffffff;

	if(crc != img_header.ih_dcrc)
	{
		//sprintf(errorMsg,"The image %s does not contain valid checksum",name);
		sprintf(errorMsg,"%s","Firmware Upgrade failed as the image does not contain valid checksum.\nRestoring the previous image.. Please wait for Reboot to complete.\n");
		retval = 1;
		goto abort;
	}

	img_type[0]='\0';
	if(strstr((const char *)img_header.ih_name,"linux") || strstr((const char *)img_header.ih_name,"Linux") || img_header.ih_type == IH_TYPE_KERNEL)
	{
		strcpy(img_type,"kernel");
		*iExapndDir = 1;

// 608291:jelly start
	//} else if(strstr(img_header.ih_name,"rootfs") || strstr(img_header.ih_name,"Rootfs") )
	} else if(strstr((const char *)img_header.ih_name,"rootfs") || strstr((const char *)img_header.ih_name,"Rootfs") || strstr((const char *)img_header.ih_name,"RootFS"))
// 608291:jelly end
	{
		strcpy(img_type,"rootfs");
		*iExapndDir = 0;
	} else if(strstr((const char *)img_header.ih_name,"firmware") || strstr((const char *)img_header.ih_name,"Firmware") || img_header.ih_type == IH_TYPE_FIRMWARE)
	{
		strcpy(img_type,"firmware");
		*iExapndDir = 0;
	} else if(strstr((const char *)img_header.ih_name,"sysconfig") || strstr((const char *)img_header.ih_name,"Sysconfig"))
	{
		strcpy(img_type,"sysconfig");
		*iExapndDir = 0;
	} else if(strstr((const char *)img_header.ih_name,"ubootconfig") || strstr((const char *)img_header.ih_name,"Ubootconfig")) 
	{
		strcpy(img_type,"ubootconfig");
		*iExapndDir = 0;
	} else if(strstr((const char *)img_header.ih_name,"fullimage") || strstr((const char *)img_header.ih_name,"Fullimage")) 
	{
		strcpy(img_type,"fullimage");
		*iExapndDir = 0;
	} else if(strstr((const char *)img_header.ih_name,"totalimage") || strstr((const char *)img_header.ih_name,"Totalimage")) 
	{
		strcpy(img_type,"totalimage");
		*iExapndDir = 0;
	} else 
	{
		sprintf(errorMsg,"Uploaded image type = %d and name [%s] are unknown. The name could be one of [L|l]inux, [R|r]ootfs, [F|f]irmware, [S|s]ysconfig, [U|u]bootconfig only.\n",img_header.ih_type,img_header.ih_name);
		retval = 1;
	}
abort:
	if(retval) {
		char command[128];
		sprintf(command,"%s &",RESTART_PROCESS_FILE);
		system(command);
		unlink(RESTART_PROCESS_FILE);
	}
	close(fd_img);
	return retval;
}

int ifx_chkSysConf(char *psFileName)
{
    int32 iRet = 0, iLen = 0;
    char8 caTmp[64] = { 0 }, *psBuf = NULL;
    FILE *xpFP = NULL;
    struct stat xStat;
    size_t newLen = 0;
    memset(&xStat, '\0', sizeof(xStat));
    /* if filesize is > 16K, then it is sysconf.gz */
	
    if(stat(psFileName, &xStat) == 0) {
        if(xStat.st_size <= IFX_CFG_FLASH_SYSTEM_CFG_SIZE) {
            sprintf(caTmp, "mv %s //tmp//sysconf.gz", psFileName);
            system(caTmp);
            system("gunzip //tmp//sysconf.gz");
        }
        else {
            sprintf(caTmp, "mv %s //tmp//sysconf", psFileName);
            system(caTmp);
        }
    }
    else {
        syslog(LOG_INFO, "stat on %s failed\n", psFileName);
    }
    
    xpFP = fopen("//tmp//sysconf", "r");
    if(xpFP == '\0') {
        iRet = -1;
        goto cleanup;
    }
    fseek(xpFP, 0, SEEK_END);
    iLen = ftell(xpFP);
    psBuf = (char8 *)malloc(iLen + 1);
    if(psBuf != NULL)
        *psBuf = '\0';
    else {
        iRet = -1;
        goto cleanup;
    }

    fclose(xpFP);
    xpFP = fopen("/tmp/sysconf", "r");
    if(xpFP == '\0') {
        iRet = -1;
        goto cleanup;
    }
    newLen = fread(psBuf, iLen, 1, xpFP);
    psBuf[newLen] = '\0';
    fclose(xpFP);
    xpFP = NULL;

    if(((strstr(psBuf, "#<<") == NULL)) || (strstr(psBuf, "#>>") == NULL)) {
        iRet = -1;
        goto cleanup;
    }

  cleanup:
    free(psBuf);
    if(xpFP != NULL)
        fclose(xpFP);
    return iRet;
}

int ifx_invokeUpgd(char *fName,char *img_type,int iExapndDir)
{
    char command[256];

    command[0]='\0';
    //303002:JackLee
    sprintf(command,"/etc/rc.d/invoke_upgrade.sh %s %s %d 1 reboot", fName, img_type, iExapndDir);
   system(command);
   return 0;
}

#if 0
int ifx_chkImageMem(char *buf)
{
    image_header_t *pimg_header;
    char command[128];

    pimg_header = (image_header_t *)buf;
    if(pimg_header->ih_magic != IH_MAGIC) {
        return 1;
    }
    sprintf(command,"/etc/rc.d/free_memory.sh");
    system(command);
    return 0;
}
#endif
// 512151:jelly:start
int ifx_chkImageMem(char *buf,char *appname)
{
    image_header_t *pimg_header;
    char command[128];

    pimg_header = (image_header_t *)buf;
    if(pimg_header->ih_magic != IH_MAGIC) {
        return 1;
    }
    sprintf(command,"/etc/rc.d/free_memory.sh %s",appname);
    system(command);
    return 0;
}
//512151:jelly:end
/* 000002:Nirav end */

#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
int adsl_get_rate(int type, unsigned long *rate, unsigned long *rate_remainder)
{
    int fd = 0, ret = -1;
    DSL_G997_ChannelStatus_t channelStatus;

    fd=open(ADSL_DEV, O_RDWR);
    memset(&channelStatus, 0x00, sizeof(DSL_G997_ChannelStatus_t));

    if (type ==  0)
        channelStatus.nDirection = DSL_UPSTREAM;
    else if (type ==  1)
        channelStatus.nDirection = DSL_DOWNSTREAM;
    else
    {    ret = -1;
        goto err_exit;
    }

    ret = ioctl(fd, DSL_FIO_G997_CHANNEL_STATUS_GET, &channelStatus);
    if (ret == 0)
        ret = channelStatus.data.ActualDataRate;
    else
        ret = -1;
err_exit:
    close(fd);
    return ret;
}
#endif /* CONFIG_PACKAGE_IFX_DSL_CPE_API */



#if 0
//7112801: santosh
#ifdef CONFIG_FEATURE_IFX_ADM6996_UTILITY
void ADM6996_RWReg(int rwmode, int addr, int *value, int fd)
{
  PREGRW uREGRW;
  
  uREGRW = (PREGRW)malloc(sizeof(REGRW));
  
  uREGRW->addr = addr;
  uREGRW->mode = rwmode;
  if (rwmode) /* write */
  {
     uREGRW->value = *value;
  
     if( ioctl(fd, ADM_IOCTL_REGRW, uREGRW) )
     {
       printf("IOCTL write ERROR!\n");
       return;
     }

  }else     /* read */
  {
     if( ioctl(fd, ADM_IOCTL_REGRW, uREGRW) )
     {
       printf("ioctl error\n");
       return;
     }
  
     *value = uREGRW->value;
  }

  free(uREGRW);
}

void ADM6996_RWSWReg(int rwmode, int addr, int *value, int fd)
{
  PREGRW uREGRW;
  
  uREGRW = (PREGRW)malloc(sizeof(REGRW));
  
  uREGRW->addr = addr;
  uREGRW->mode = rwmode;
  if (rwmode) /* write */
  {
     uREGRW->value = *value;
  
     if( ioctl(fd, ADM_SW_IOCTL_REGRW, uREGRW) )
     {
       printf("IOCTL write ERROR!\n");
       return;
     }

  }else     /* read */
  {
     if( ioctl(fd, ADM_SW_IOCTL_REGRW, uREGRW) )
     {
       printf("ioctl error\n");
       return;
     }
  
     *value = uREGRW->value;
  }


  free(uREGRW);

}

int ifx_get_phyport_info(int num, struct ifx_phyport_info *buf)
{
	int	fd;
	int	value = 0;
	int	mode = -1;

	fd = open("/dev/adm6996", O_RDWR, 0);
	if( fd <= 0){ //509211:fchang
		printf("Failed to open dev:adm6996, please check if the node is getting created!\n");
		return -1; //509211:fchang
	}

	//509211:fchang Added.Start
	ADM6996_RWSWReg(0, 0xa0, &value, fd);
	if ( (value&0xfff0) == 0x1020 ) {
		syslog(LOG_INFO, "ifx_get_phyport_info: 6996I/M mode!!\n");
		mode = 1; //6996I mode
	}
	ADM6996_RWSWReg(0, 0x200, &value, fd);
	if ( (value&0xffffff00) == 0x71000 ) {
		syslog(LOG_INFO, "ifx_get_phyport_info: 6996LC mode!!\n");
		mode = 2; //6996LC mode
	}
	if( mode == -1 ){
		syslog(LOG_INFO, "Unknown mode of xxternal switch to fetch status\n");
		close(fd);
		return -1;
	}
	//509211:fchang Added.End

	switch (num) {
	case 0:
		if( mode == 1)
			ADM6996_RWSWReg(0, 0xa2, &value, fd);
		else
			ADM6996_RWSWReg(0, 0x201, &value, fd); //509211:fchang
	
		buf->link = value & 0x0001;
		buf->speed = value & 0x0002;
		buf->duplex = value & 0x0004;
		syslog(LOG_INFO, " mode:[%d], line:[%d], [0xa2]:[%x], [link]:[%x], [speed]:[%x], [duplex]:[%x]\n",                                                                     mode, __LINE__, value, buf->link, buf->speed, buf->duplex);

		break;
	case 1:
		if( mode == 1 ){
			ADM6996_RWSWReg(0, 0xa2, &value, fd);
        	        buf->link = value & 0x0100; //605301:fchang.modified for 6996I version 3
                	buf->speed = value & 0x0200; //605301:fchang.modified
	                buf->duplex = value & 0x0400; //605301:fchang.modified
		}
		else{
			ADM6996_RWSWReg(0, 0x201, &value, fd); //509211:fchang
			buf->link = value & 0x0100; //509211:fchang
			buf->speed = value & 0x0200; //509211:fchang
			buf->duplex = value & 0x0400; //509211:fchang
		}
		syslog(LOG_INFO, " mode:[%d], line:[%d], [0xa2]:[%x], [link]:[%x], [speed]:[%x], [duplex]:[%x]\n",                                                                      mode, __LINE__, value, buf->link, buf->speed, buf->duplex);

		break;
	case 2:
		if( mode == 1 ){
			ADM6996_RWSWReg(0, 0xa3, &value, fd);
	                buf->link = value & 0x0001;
	                buf->speed = value & 0x0002;
	                buf->duplex = value & 0x0004;
		}
		else{
			ADM6996_RWSWReg(0, 0x201, &value, fd); //509211:fchang
                	buf->link = value & 0x10000; //509211:fchang
	                buf->speed = value & 0x20000; //509211:fchang
	                buf->duplex = value & 0x40000; //509211:fchang
		}
		syslog(LOG_INFO, " mode:[%d], line:[%d], [0xa3]:[%x], [link]:[%x], [speed]:[%x], [duplex]:[%x]\n",                                                                      mode, __LINE__, value, buf->link, buf->speed, buf->duplex);

		break;
	case 3:
		if( mode == 1 ){
			ADM6996_RWSWReg(0, 0xa3, &value, fd);
	                buf->link = value & 0x0100;
	                buf->speed = value & 0x0200;
	                buf->duplex = value & 0x0400;
		}
		else{
			ADM6996_RWSWReg(0, 0x201, &value, fd); //509211:fchang
	                buf->link = value & 0x1000000; //509211:fchang
	                buf->speed = value & 0x2000000; //509211:fchang
	                buf->duplex = value & 0x4000000; //509211:fchang
		}
		syslog(LOG_INFO, " mode:[%d], line:[%d], [0xa3]:[%x], [link]:[%x], [speed]:[%x], [duplex]:[%x]\n",                                                                     mode, __LINE__, value, buf->link, buf->speed, buf->duplex);

		break;
	case 4:
		if( mode == 1 ){
			ADM6996_RWSWReg(0, 0xa3, &value, fd);
	                buf->link = value & 0x1000;
	                buf->speed = value & 0x2000;
	                buf->duplex = value & 0x4000;
		}
		else{
			ADM6996_RWSWReg(0, 0x201, &value, fd); //509211:fchang
	                buf->link = value & 0x10000000; //509211:fchang
	                buf->speed = value & 0x20000000; //509211:fchang
	                buf->duplex = value & 0x40000000; //509211:fchang
		}
		syslog(LOG_INFO, " mode:[%d], line:[%d], [0xa3]:[%x], [link]:[%x], [speed]:[%x], [duplex]:[%x]\n",                                                                     mode, __LINE__, value, buf->link, buf->speed, buf->duplex);

		break;
	default:
		close(fd);
		return -1;
	}
	close(fd);
	return 0;
}

int ifx_get_phyportstats_info(int num, struct ifx_phyportstats_info *buf)
{
	int	fd;
	int	value;
	int	mode = -1;
	int	value_low;
	int	value_high;

	fd = open("/dev/adm6996", O_RDWR, 0);
	if( fd <= 0){ //509211:fchang
		printf("Failed to open dev:adm6996, please check if the node is getting created!\n");
		return -1; //509211:fchang
	}

	//509211:fchang Added.Start
	ADM6996_RWSWReg(0, 0xa0, &value, fd);
	if ( (value&0xfff0) == 0x1020 ) {
		syslog(LOG_INFO, "ifx_get_phyport_info: 6996I/M mode!!\n");
		mode = 1; //6996I mode
	}
	ADM6996_RWSWReg(0, 0x200, &value, fd);
	if ( (value&0xffffff00) == 0x71000 ) {
		syslog(LOG_INFO, "ifx_get_phyport_info: 6996LC mode!!\n");
		mode = 2; //6996LC mode
	}
	if( mode == -1 ){
		syslog(LOG_INFO, "Unknown mode of xxternal switch to fetch status\n");
		close(fd);
		return -1;
	}
	//509211:fchang Added.End

        //TBD: Code to be enhanced for mode=2 also */
	switch (num) {
	case 0:
		ADM6996_RWSWReg(0, 0xa8, &value_low, fd);
		ADM6996_RWSWReg(0, 0xa9, &value_high, fd);
		buf->rxPktCnt = (value_high << 16) | value_low;
		ADM6996_RWSWReg(0, 0xba, &value_low, fd);
		ADM6996_RWSWReg(0, 0xbb, &value_high, fd);
		buf->rxByteCnt = (value_high << 16) | value_low;
		ADM6996_RWSWReg(0, 0xcc, &value_low, fd);
		ADM6996_RWSWReg(0, 0xcd, &value_high, fd);
		buf->txPktCnt = (value_high << 16) | value_low;
		ADM6996_RWSWReg(0, 0xde, &value_low, fd);
		ADM6996_RWSWReg(0, 0xdf, &value_high, fd);
		buf->txByteCnt = (value_high << 16) | value_low;
                
		break;
	case 1:
		ADM6996_RWSWReg(0, 0xac, &value_low, fd);
		ADM6996_RWSWReg(0, 0xad, &value_high, fd);
		buf->rxPktCnt = (value_high << 16) | value_low;
		ADM6996_RWSWReg(0, 0xbe, &value_low, fd);
		ADM6996_RWSWReg(0, 0xbf, &value_high, fd);
		buf->rxByteCnt = (value_high << 16) | value_low;
		ADM6996_RWSWReg(0, 0xd0, &value_low, fd);
		ADM6996_RWSWReg(0, 0xd1, &value_high, fd);
		buf->txPktCnt = (value_high << 16) | value_low;
		ADM6996_RWSWReg(0, 0xe2, &value_low, fd);
		ADM6996_RWSWReg(0, 0xe3, &value_high, fd);
		buf->txByteCnt = (value_high << 16) | value_low;
                
		break;
	case 2:
		ADM6996_RWSWReg(0, 0xb0, &value_low, fd);
		ADM6996_RWSWReg(0, 0xb1, &value_high, fd);
		buf->rxPktCnt = (value_high << 16) | value_low;
		ADM6996_RWSWReg(0, 0xc2, &value_low, fd);
		ADM6996_RWSWReg(0, 0xc3, &value_high, fd);
		buf->rxByteCnt = (value_high << 16) | value_low;
		ADM6996_RWSWReg(0, 0xd4, &value_low, fd);
		ADM6996_RWSWReg(0, 0xd5, &value_high, fd);
		buf->txPktCnt = (value_high << 16) | value_low;
		ADM6996_RWSWReg(0, 0xe6, &value_low, fd);
		ADM6996_RWSWReg(0, 0xe7, &value_high, fd);
		buf->txByteCnt = (value_high << 16) | value_low;
                
		break;
	case 3:
		ADM6996_RWSWReg(0, 0xb4, &value_low, fd);
		ADM6996_RWSWReg(0, 0xb5, &value_high, fd);
		buf->rxPktCnt = (value_high << 16) | value_low;
		ADM6996_RWSWReg(0, 0xc6, &value_low, fd);
		ADM6996_RWSWReg(0, 0xc7, &value_high, fd);
		buf->rxByteCnt = (value_high << 16) | value_low;
		ADM6996_RWSWReg(0, 0xd8, &value_low, fd);
		ADM6996_RWSWReg(0, 0xd9, &value_high, fd);
		buf->txPktCnt = (value_high << 16) | value_low;
		ADM6996_RWSWReg(0, 0xea, &value_low, fd);
		ADM6996_RWSWReg(0, 0xeb, &value_high, fd);
		buf->txByteCnt = (value_high << 16) | value_low;
                
		break;
	case 4:
		ADM6996_RWSWReg(0, 0xb6, &value_low, fd);
		ADM6996_RWSWReg(0, 0xb7, &value_high, fd);
		buf->rxPktCnt = (value_high << 16) | value_low;
		ADM6996_RWSWReg(0, 0xc8, &value_low, fd);
		ADM6996_RWSWReg(0, 0xc9, &value_high, fd);
		buf->rxByteCnt = (value_high << 16) | value_low;
		ADM6996_RWSWReg(0, 0xda, &value_low, fd);
		ADM6996_RWSWReg(0, 0xdb, &value_high, fd);
		buf->txPktCnt = (value_high << 16) | value_low;
		ADM6996_RWSWReg(0, 0xec, &value_low, fd);
		ADM6996_RWSWReg(0, 0xed, &value_high, fd);
		buf->txByteCnt = (value_high << 16) | value_low;
                
		break;
	default:
		close(fd);
		return -1;
	}
	close(fd);
	return 0;
}

#else
int ifx_get_phyport_info(int num, struct ifx_phyport_info *buf) {
    struct ifreq ifr;
    int skfd;
    struct ethtool_cmd edata;
//    struct ethtool_value estatus;
    
    skfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (skfd < 0) {
        syslog(LOG_INFO, "ifx_get_phyport_info: Unable to open socket!!\n");
        goto err_exit;
    }

    memset(&edata, 0, sizeof(struct ethtool_cmd));
//    memset(&estatus, 0, sizeof(struct ethtool_value));
    memset(&ifr, 0, sizeof(ifr));

    strcpy(ifr.ifr_name, "eth0");
#if 0
    estatus.cmd = ETHTOOL_GLINK;
    ifr.ifr_data = (char *) &estatus;
    if (ioctl(skfd, SIOCETHTOOL, &ifr) < 0) {
        goto err_exit;
    }
    buf->link = (estatus.data ? 1 : 0);
#endif
    edata.cmd = ETHTOOL_GSET; 
    ifr.ifr_data = (char *) &edata;
    if (ioctl(skfd, SIOCETHTOOL, &ifr) < 0) {
        //syslog(LOG_INFO, "ifx_get_phyport_info: ioctl failed!!\n");
        goto err_exit;
    }
    //syslog(LOG_INFO, "edata.speed=%d, edata.duplex=%d\n", edata.speed, edata.duplex);

    if(edata.reserved[0] == 0) {        //0 means link down, 1 means link up!!
        buf->link = 0;
        buf->speed = 1;
        buf->duplex = 1;
    } else if(edata.reserved[0] == 1){    //link up!!
        buf->link = 1;
        buf->speed = (edata.speed == SPEED_10 ? 0 : 1);
        buf->duplex = (edata.duplex == DUPLEX_HALF ? 0 : 1);
    } else {                //unkown status!!
        goto err_exit;
    }

    close(skfd);
    return 0;

err_exit:
    //syslog(LOG_INFO, "Getting interface eth0 information error!!\n");
    buf->link = 0;
    buf->speed = 1;
    buf->duplex = 1;
    close(skfd);
    return -1;
}
#endif
#endif
