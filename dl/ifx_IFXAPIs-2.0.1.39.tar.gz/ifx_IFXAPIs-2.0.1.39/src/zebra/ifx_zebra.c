/* ============================================================================
 * Copyright (C) 2004 - Infineon Technologies.
 *
 * All rights reserved.
 * ============================================================================
 *
 * ============================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ============================================================================
 *
 * Revision History:
 *      - 2004/07/13, MarsLin
 *         init version
 *
 * ============================================================================
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>

#include "ifx_definition.h"
#include "ifx_structure_list.h"
#include "ifx_common.h"
#include "ifx_zebra.h"

#define IFX_ZMALLOC     malloc
#define IFX_ZFREE       free
#define IFX_ZALLOC      alloc
#define IFX_ZMEMSET     memset
#define IFX_ZMEMCPY     memcpy
#define IFX_ZSTRLEN     strlen
#define IFX_ZSTRCPY     strcpy

void *ifx_zebra_create_handle(int flag, PIFX_ZEBRA_CONFIG pOrigCfg, void *reserved)
{
    PIFX_ZEBRA_CONFIG   pCfg = pOrigCfg;

    if (flag == IFX_COMPAPI_FLAG_NO_CMPD)
        pCfg = IFX_ZMALLOC(sizeof(IFX_ZEBRA_CONFIG));
    else
    {    if (pCfg != NULL)
        {    if ( (flag != IFX_COMPAPI_FLAG_CMPD_INIT) && (flag != IFX_COMPAPI_FLAG_CMPD_RESTORE) )
                return NULL;
        }
    }

    if (pCfg != NULL)
    {   if (flag != IFX_COMPAPI_FLAG_CMPD_RESTORE)
        {   /* for nocfgd and init, setup default value */
            IFX_ZMEMSET(pCfg, 0x00, sizeof(IFX_ZEBRA_CONFIG));
            IFX_SINGLE_LIST_INIT(&(pCfg->rip.if_list));
        }
    }
    return pCfg;
}

int ifx_zebra_rip_add_interface_by_ifindex(void *hHandle, int ifindex)
{
    PIFX_ZEBRA_CONFIG   pCfg = (PIFX_ZEBRA_CONFIG)hHandle;

    if (pCfg != NULL)
    {   P_IFX_SINGLE_LIST   pNode = IFX_SINGLE_LIST_GET_FIRST(&(pCfg->rip.if_list));

        for ( ; pNode != NULL; pNode = pNode->next)
        {    PIFX_ZEBRA_RIP_IF_INFO pIfInfo = (PIFX_ZEBRA_RIP_IF_INFO)pNode;
            if (pIfInfo->ifindex == ifindex)
            {   /* already have! */
                return IFX_RET_OK;
            }
        }
        if (pNode == NULL)
        {    /* add a new node */
            PIFX_ZEBRA_RIP_IF_INFO  pNewInfo = IFX_ZMALLOC(sizeof(IFX_ZEBRA_RIP_IF_INFO));
            if (pNewInfo != NULL)
            {   IFX_ZMEMSET(pNewInfo, 0x00, sizeof(IFX_ZEBRA_RIP_IF_INFO));

                IFX_SINGLE_LIST_INIT(&(pNewInfo->list));
                pNewInfo->ifindex           = ifindex;
                pNewInfo->enable            = FALSE;
                pNewInfo->ver_send          = IFX_ZEBRA_RIP_VERSION_BOTH;
                pNewInfo->ver_recv          = IFX_ZEBRA_RIP_VERSION_BOTH;
                pNewInfo->rip2_auth.enable  = FALSE;
                pNewInfo->rip2_auth.type    = IFX_ZEBRA_RIP_AUTH_UNSET;

                IFX_SINGLE_LIST_ADD_BACK(&(pCfg->rip.if_list), &(pNewInfo->list));
                return IFX_RET_OK;
            }
        }
    }
    return IFX_RET_ERR;
}

int ifx_zebra_rip_remove_interface_by_ifindex(void *hHandle, int ifindex)
{
    PIFX_ZEBRA_CONFIG   pCfg = (PIFX_ZEBRA_CONFIG)hHandle;

    if (pCfg != NULL)
    {
        P_IFX_SINGLE_LIST   pNode = IFX_SINGLE_LIST_GET_FIRST(&(pCfg->rip.if_list));

        for ( ; pNode != NULL; pNode = pNode->next)
        {   PIFX_ZEBRA_RIP_IF_INFO  pIfInfo = (PIFX_ZEBRA_RIP_IF_INFO)pNode;
            if (pIfInfo->ifindex == ifindex)
            {   IFX_SINGLE_LIST_REMOVE_NODE(&(pCfg->rip.if_list), pNode);
                IFX_ZFREE(pIfInfo);
                break;
            }
        }
        /* either (pNode == NULL) and (pNode != NULL) are success */
        return IFX_RET_OK;
    }
    return IFX_RET_ERR;
}

int ifx_zebra_rip_start(void *hHandle)
{
    PIFX_ZEBRA_CONFIG   pCfg = (PIFX_ZEBRA_CONFIG)hHandle;

    if (pCfg != NULL)
    {
    }
    return IFX_RET_ERR;
}

int ifx_zebra_rip_stop(void *hHandle)
{
    PIFX_ZEBRA_CONFIG   pCfg = (PIFX_ZEBRA_CONFIG)hHandle;

    if (pCfg != NULL)
    {
    }
    return IFX_RET_ERR;
}

int ifx_zebra_set_rip_enable_by_ifindex(void *hHandle, int ifindex, bool bEnable)
{
    PIFX_ZEBRA_CONFIG   pCfg = (PIFX_ZEBRA_CONFIG)hHandle;

    if (pCfg != NULL)
    {
        P_IFX_SINGLE_LIST   pNode = IFX_SINGLE_LIST_GET_FIRST(&(pCfg->rip.if_list));

        for ( ; pNode != NULL; pNode = pNode->next)
        {    PIFX_ZEBRA_RIP_IF_INFO    pIfInfo = (PIFX_ZEBRA_RIP_IF_INFO)pNode;
            if (pIfInfo->ifindex == ifindex)
            {   pIfInfo->enable = bEnable;
                return IFX_RET_OK;
            }
        }
    }
    return IFX_RET_ERR;
}

int ifx_zebra_get_rip_enable_by_ifindex(void *hHandle, int ifindex, bool *pbEnable)
{
    PIFX_ZEBRA_CONFIG   pCfg = (PIFX_ZEBRA_CONFIG)hHandle;

    if (pCfg != NULL)
    {
        P_IFX_SINGLE_LIST   pNode = IFX_SINGLE_LIST_GET_FIRST(&(pCfg->rip.if_list));

        for ( ; pNode != NULL; pNode = pNode->next)
        {   PIFX_ZEBRA_RIP_IF_INFO  pIfInfo = (PIFX_ZEBRA_RIP_IF_INFO)pNode;
            if (pIfInfo->ifindex == ifindex)
            {   *pbEnable = pIfInfo->enable;
                return IFX_RET_OK;
            }
        }
    }
    return IFX_RET_ERR;
}

int ifx_zebra_set_rip_send_version_by_ifindex(void *hHandle, int ifindex, int iVersion)
{
    PIFX_ZEBRA_CONFIG   pCfg = (PIFX_ZEBRA_CONFIG)hHandle;

    if (pCfg != NULL)
    {
        P_IFX_SINGLE_LIST   pNode = IFX_SINGLE_LIST_GET_FIRST(&(pCfg->rip.if_list));

        for ( ; pNode != NULL; pNode = pNode->next)
        {   PIFX_ZEBRA_RIP_IF_INFO  pIfInfo = (PIFX_ZEBRA_RIP_IF_INFO)pNode;
            if (pIfInfo->ifindex == ifindex)
            {   pIfInfo->ver_send = iVersion;
                return IFX_RET_OK;
            }
        }
    }
    return IFX_RET_ERR;
}

int ifx_zebra_get_rip_send_version_by_ifindex(void *hHandle, int ifindex, int *piVersion)
{
    PIFX_ZEBRA_CONFIG   pCfg = (PIFX_ZEBRA_CONFIG)hHandle;

    if (pCfg != NULL)
    {
        P_IFX_SINGLE_LIST   pNode = IFX_SINGLE_LIST_GET_FIRST(&(pCfg->rip.if_list));

        for ( ; pNode != NULL; pNode = pNode->next)
        {   PIFX_ZEBRA_RIP_IF_INFO  pIfInfo = (PIFX_ZEBRA_RIP_IF_INFO)pNode;
            if (pIfInfo->ifindex == ifindex)
            {   *piVersion = pIfInfo->ver_send;
                return IFX_RET_OK;
            }
        }
    }
    return IFX_RET_ERR;
}

int ifx_zebra_set_rip_recv_version_by_ifindex(void *hHandle, int ifindex, int iVersion)
{
    PIFX_ZEBRA_CONFIG   pCfg = (PIFX_ZEBRA_CONFIG)hHandle;

    if (pCfg != NULL)
    {   P_IFX_SINGLE_LIST   pNode = IFX_SINGLE_LIST_GET_FIRST(&(pCfg->rip.if_list));

        for ( ; pNode != NULL; pNode = pNode->next)
        {   PIFX_ZEBRA_RIP_IF_INFO  pIfInfo = (PIFX_ZEBRA_RIP_IF_INFO)pNode;
            if (pIfInfo->ifindex == ifindex)
            {   pIfInfo->ver_recv = iVersion;
                return IFX_RET_OK;
            }
        }
    }
    return IFX_RET_ERR;
}

int ifx_zebra_get_rip_recv_version_by_ifindex(void *hHandle, int ifindex, int *piVersion)
{
    PIFX_ZEBRA_CONFIG   pCfg = (PIFX_ZEBRA_CONFIG)hHandle;

    if (pCfg != NULL)
    {
        P_IFX_SINGLE_LIST   pNode = IFX_SINGLE_LIST_GET_FIRST(&(pCfg->rip.if_list));

        for ( ; pNode != NULL; pNode = pNode->next)
        {   PIFX_ZEBRA_RIP_IF_INFO  pIfInfo = (PIFX_ZEBRA_RIP_IF_INFO)pNode;
            if (pIfInfo->ifindex == ifindex)
            {   *piVersion = pIfInfo->ver_recv;
                return IFX_RET_OK;
            }
        }
    }
    return IFX_RET_ERR;
}

int ifx_zebra_set_rip_enable_rip2_auth_by_ifindex(void *hHandle, int ifindex, bool bEnable)
{
    PIFX_ZEBRA_CONFIG   pCfg = (PIFX_ZEBRA_CONFIG)hHandle;

    if (pCfg != NULL)
    {   P_IFX_SINGLE_LIST   pNode = IFX_SINGLE_LIST_GET_FIRST(&(pCfg->rip.if_list));

        for ( ; pNode != NULL; pNode = pNode->next)
        {   PIFX_ZEBRA_RIP_IF_INFO  pIfInfo = (PIFX_ZEBRA_RIP_IF_INFO)pNode;
            if (pIfInfo->ifindex == ifindex)
            {   pIfInfo->rip2_auth.enable = bEnable;
                return IFX_RET_OK;
            }
        }
    }
    return IFX_RET_ERR;
}

int ifx_zebra_get_rip_enable_rip2_auth_by_ifindex(void *hHandle, int ifindex, bool *pbEnable)
{
    PIFX_ZEBRA_CONFIG   pCfg = (PIFX_ZEBRA_CONFIG)hHandle;

    if (pCfg != NULL)
    {   P_IFX_SINGLE_LIST   pNode = IFX_SINGLE_LIST_GET_FIRST(&(pCfg->rip.if_list));

        for ( ; pNode != NULL; pNode = pNode->next)
        {   PIFX_ZEBRA_RIP_IF_INFO  pIfInfo = (PIFX_ZEBRA_RIP_IF_INFO)pNode;
            if (pIfInfo->ifindex == ifindex)
            {       *pbEnable = pIfInfo->rip2_auth.enable;
                    return IFX_RET_OK;
            }
        }
    }
    return IFX_RET_ERR;
}

int ifx_zebra_set_rip_auth_type_and_key_by_ifindex(void *hHandle, int ifindex, int iType, char *pKey)
{
    PIFX_ZEBRA_CONFIG   pCfg = (PIFX_ZEBRA_CONFIG)hHandle;

    if (pCfg != NULL)
    {   P_IFX_SINGLE_LIST   pNode = IFX_SINGLE_LIST_GET_FIRST(&(pCfg->rip.if_list));

        for ( ; pNode != NULL; pNode = pNode->next)
        {   PIFX_ZEBRA_RIP_IF_INFO  pIfInfo = (PIFX_ZEBRA_RIP_IF_INFO)pNode;
            if (pIfInfo->ifindex == ifindex)
            {   int length = IFX_ZSTRLEN(pKey);
                if (length > IFX_ZEBRA_RIP2_LENGTH_KEY)
                return IFX_RET_ERR;
                pIfInfo->rip2_auth.type = iType;
                IFX_ZMEMSET(pIfInfo->rip2_auth.key, 0x00, IFX_ZEBRA_RIP2_LENGTH_KEY+1);
                IFX_ZSTRCPY(pIfInfo->rip2_auth.key, pKey);
                return IFX_RET_OK;
            }
        }
    }
    return IFX_RET_ERR;
}

int ifx_zebra_get_rip_auth_type_and_key_by_ifindex(void *hHandle, int ifindex, int *piType, char *pKeyBuf)
{
    PIFX_ZEBRA_CONFIG   pCfg = (PIFX_ZEBRA_CONFIG)hHandle;

    if (pCfg != NULL)
    {   P_IFX_SINGLE_LIST   pNode = IFX_SINGLE_LIST_GET_FIRST(&(pCfg->rip.if_list));

        for ( ; pNode != NULL; pNode = pNode->next)
        {   PIFX_ZEBRA_RIP_IF_INFO  pIfInfo = (PIFX_ZEBRA_RIP_IF_INFO)pNode;
            if (pIfInfo->ifindex == ifindex)
            {   *piType = pIfInfo->rip2_auth.type;
                IFX_ZSTRCPY(pKeyBuf, pIfInfo->rip2_auth.key);
                return IFX_RET_OK;
            }
        }
    }
    return IFX_RET_ERR;
}

int ifx_zebra_get_dynamic_routing_table(void *hHandle, PIFX_ZEBRA_ROUTE_ENTRY pEntryBuf, int *iEntries)
{
    PIFX_ZEBRA_CONFIG   pCfg = (PIFX_ZEBRA_CONFIG)hHandle;

    if (pCfg != NULL)
    {
        /* FIXME HERE!! */
    }
    return IFX_RET_ERR;
}
