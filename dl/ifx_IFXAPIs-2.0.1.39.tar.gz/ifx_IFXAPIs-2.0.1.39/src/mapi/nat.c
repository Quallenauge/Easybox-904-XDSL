
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <arpa/inet.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"

/* Included for PortMap */
#include "ifx_api_ipt_common.h"
#include <ifx_api_ipt_common_private.h>

#define _AMAZON_ADSL_APP
#ifndef AMAZON_MEI_MIB_RFC3440
 #define AMAZON_MEI_MIB_RFC3440
#endif // AMAZON_MEI_MIB_RFC3440

#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
// #include <drv_dsl_cpe_api_config.h>
#include <drv_dsl_cpe_api.h>
#include <drv_dsl_cpe_api_ioctl.h>
#endif /*!CONFIG_PACKAGE_IFX_DSL_CPE_API */


bool IFX_SET_NAPT_DNAT_VIRTUALSERVER_Entry(int operation, P_IFX_IPT_RULE pCfg, int piEnteriesSize);


char8 *nat_virtualser_param_names[] = {"cpeId", "pcpeId", "privateIp", "remoteIp", "wanConnIf", "desc", "spport", "epport", "ptype", "spuport", "epuport", "upqosEnable", "upminBW", "upmaxBW", "dnqosEnable", "dnminBW", "dnmaxBW", "fEnable", "lease"};

//////////////////////////////////////////////////////////
//vipul start


char8 *nat_port_trigger_param_names[] = {"cpeId", "pcpeId", "Application", "protocol", "fEnable", "tsPort", "tePort", "esPort", "eePort", "oprotocol"};

#define NAT_PORT_TRIGGER_PARAM_COUNT 10


//vipul end
/////////////////////////////////////////////////////////

/* SET APIs */


/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_nat_status_on_if(...)
*		wan_index	==> 	The wan device index for which the NAT Status has to be modified
*		iid			==>		The cpeId of thw wan device for which the NAT Status has to be modified
*		enable		==>		Value of NAT Status flag which needs to be set or reset for this wan connection
*    	flags		==>   	flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
					The api modifies the NAT Enable filed for the wan device. The wan device can be specified
					either by giving the wan index or the cpeId. The api will either set or reset the NAT Enable
					based on the value of enable.
*//////////////////////////////////////////////////////////////////////////////
#ifdef CONFIG_FEATURE_NAPT
int32 ifx_set_nat_status_on_if(int32 wan_index, IFX_ID *iid, int32 enable, uint32 flags)
{
	int32	ret = IFX_SUCCESS, count = 0, changed_fcount = 0;
	int32	wanIdx = -1;
	char8	sValue[MAX_NAME_SIZE], buf[MAX_FILELINE_LEN], *retStr = NULL;
	IFX_NAME_VALUE_PAIR array_fvp[2], *array_changed_fvp = NULL;
	int32 outflag = IFX_F_DEFAULT;
	char8 secName[MAX_FILELINE_LEN],wanIface[MAX_FILELINE_LEN], ipAddr[MAX_IP_ADDR_LEN];

    NULL_TERMINATE(buf, 0, sizeof(buf));
	NULL_TERMINATE(secName, 0x00, sizeof(secName));
	NULL_TERMINATE(wanIface, 0x00, sizeof(wanIface));

    memset(array_fvp, 0, sizeof(array_fvp));

	/************* Prolog Block **************/
	/* Based on operation (ADD or DEL or MOD) 
	 * append the flag with internal flags */
	flags |= IFX_F_MODIFY;


	/************* Validation Block ************/
	/* Do simple validation of flags sucha as less than 0 */
	if(IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		if ((IFX_INT_ADD_F_SET(flags)) || 
			(IFX_DELETE_F_SET(flags)) ) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		else if ((enable != IFX_ENABLED) || (enable !=IFX_DISABLED)) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		IFX_VALIDATE_FLAGS(flags)
	}


	/************* Name Value Formation as per RC.CONF *************/
	if(wan_index < 0) { // from TR69
		sprintf(buf, "%d", iid->cpeId.Id);
		/* get wan index from distinct cpeid=value combination */
		if (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_MAIN, "cpeId", 
					buf, &retStr) != IFX_SUCCESS) {
			/* cpeid not found or is distinct in wan_main */
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wanIdx = atoi(strrchr(retStr, '_') + 1);
	}
	else { // from Web
		wanIdx = wan_index;

		/* get the cpeid and pcpeid from rc.conf */
		sprintf(buf, "wan_%d_cpeId", wanIdx);
		if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, IFX_F_GET_ANY, 
				(IFX_OUT uint32 *)&outflag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		iid->cpeId.Id = atoi(sValue);

		sprintf(buf, "wan_%d_pcpeId", wanIdx);
		if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, IFX_F_GET_ANY, 
				(IFX_OUT uint32 *)&outflag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		iid->pcpeId.Id = atoi(sValue);
	}
	
	sprintf(buf, "wan_%d_connName", wanIdx);
	if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, IFX_F_GET_ANY, (IFX_OUT uint32 *)&outflag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	else {
		if(ifx_get_wan_ifname_from_connName(sValue, wanIface) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	sprintf(secName, "Wan%d_IF_Info", wanIdx);
	if(ifx_GetObjData(FILE_SYSTEM_STATUS, secName, "IP", IFX_F_GET_ANY, (IFX_OUT uint32 *)&outflag, ipAddr) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	sprintf(array_fvp[0].fieldname, "wan_%d_NATEnable", wanIdx);
	sprintf(array_fvp[0].value, "%d", enable);
	count = 1;


	/**************** ACL Checking Block *****************/
	CHECK_ACL_RET(*iid, count, array_fvp,
		changed_fcount, array_changed_fvp, flags, IFX_Handler)


	/********* System Config File Update Block  **********/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(buf, count, array_fvp);

	/* Backup rc.conf before proceeding with configuration */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_MAIN, flags, 1, buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	
	/**************** Device Configuration Block ******************/
	if(IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		NULL_TERMINATE(buf,0x00, sizeof(buf));
		if (enable) {
			snprintf(buf,sizeof(buf),"/usr/sbin/naptcfg --ADDWANIF %s", wanIface);
			if(system(buf))
				ret = IFX_SUCCESS;
			sprintf(buf,"/usr/sbin/naptcfg --ADDWANIP %s", ipAddr);
			if(system(buf))
				ret = IFX_SUCCESS;
		}
		else {
			snprintf(buf,sizeof(buf),"/usr/sbin/naptcfg --DELWANIF %s", wanIface);
			if(system(buf))
				ret = IFX_SUCCESS;
			sprintf(buf,"/usr/sbin/naptcfg --DELWANIP %s", ipAddr);
			if(system(buf))
				ret = IFX_SUCCESS;
		}
	} // IFX_DONT_ACTIVATE_F_NOT_SET


	/**************** Notification Block ******************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if(IFX_MODIFY_F_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION ((*iid), changed_fcount, array_changed_fvp, flags, IFX_Handler)
	}


	/***************** Epilog Block **********************/
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}


IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	IFX_MEM_FREE(retStr)
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}








////////////////////////////////////////////////////////////////////////////
//vipul start

int32 ifx_set_port_trigger_info(int32 operation, PORT_TRIGGER *entry, uint32 flags)
{
	IFX_DBG("**Vipul**:Enter in set function of mapi");
	uint32 outflag = IFX_F_DEFAULT;
	 char8   conf_buf[MAX_DATA_LEN],sbuf[MAX_FILELINE_LEN],sValue[MAX_FILELINE_LEN],sCommand[MAX_FILELINE_LEN];
	 int32   count = 0, passed_index = -1, ret = IFX_SUCCESS,older_enable=0;
       //  int32 changed_count = 0;
        IFX_NAME_VALUE_PAIR array_fvp[10], *array_changed_fvp = NULL;
        NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
	NULL_TERMINATE(sbuf, 0x00, sizeof(sbuf));
	NULL_TERMINATE(sValue, 0x00, sizeof(sValue));
	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));

        memset(array_fvp, 0x00, sizeof(array_fvp));
	 /*************** Prolog Block *********************/
         /* Based on operation (ADD or DELETE or MODIFY)
          * append the flag with internal flags */
        if (operation == IFX_OP_DEL)
                flags |= IFX_F_DELETE;
        else if (operation == IFX_OP_ADD) {
                if( (IFX_MODIFY_F_NOT_SET(flags)))
                        flags |= IFX_F_INT_ADD;
        }
        else
                flags |= IFX_F_MODIFY;

	 /**************** Validation Block *****************/
        /* For Operations other than DELETE do the verification of input params */
        if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
                /* Do simple validation of pointer such as NULL */
                IFX_VALIDATE_PTR(entry)
                /* Do simple validation of flags such as less than 0 */
                IFX_VALIDATE_FLAGS(flags)

        }
	   /*************** Prolog Block Continued *********************/
	 sprintf(entry->iid.cpeId.secName, "%s", TAG_NAT_PORT_TRIGGER);
         sprintf(entry->iid.pcpeId.secName, "%s", TAG_WAN_MAIN);
	 entry->iid.pcpeId.Id = 1;
	
	  /**************** ID Allocation Block - Only for ADD Operation **************/
        if (IFX_ADD_F_SET(flags)) {
                /* Allocate the IID for this route instance
                 * Set the parent SectionName and parent IID values
                 * to NULL as there is no parent for Route Entity
                */
                if(ifx_get_IID_Without_TR69(&entry->iid, "hostIp") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                        ret = IFX_FAILURE;
                        goto IFX_Handler;
                }
    }

	   /**************** Name Value Formation as per RC.CONF ********************/
        /* Form the FVP from the given structure for ADD/MODIFY
         * Operations
         */
	    if(IFX_DELETE_F_NOT_SET(flags)) {

                ifx_fill_ArrayFvp_FName(array_fvp, 0, 10, nat_port_trigger_param_names);

                sprintf(array_fvp[0].value, "%d", entry->iid.cpeId.Id);
                sprintf(array_fvp[1].value, "%d", entry->iid.pcpeId.Id);

		sprintf(array_fvp[2].value, "%s", entry->Application_Name);
		count = 3;
		
		sprintf(array_fvp[count++].value, "%d", (entry->protocol == NAT_VS_PROTOCOL_TCP || entry->protocol == NAT_VS_PROTOCOL_UDP)?entry->protocol:0);
                 sprintf(array_fvp[count++].value, "%d", (entry->f_enable ==1)?entry->f_enable:0);
		 sprintf(array_fvp[count++].value, "%d", (entry->trigger_start_port)?entry->trigger_start_port:0);
		 sprintf(array_fvp[count++].value, "%d", (entry->trigger_end_port)?entry->trigger_end_port:0);
		 sprintf(array_fvp[count++].value, "%d", (entry->external_start_port)?entry->external_start_port:0);
		 sprintf(array_fvp[count++].value, "%d", (entry->external_end_port)?entry->external_end_port:0);
		 sprintf(array_fvp[count++].value, "%d", (entry->open_protocol == NAT_VS_PROTOCOL_TCP || entry->open_protocol == NAT_VS_PROTOCOL_UDP)?entry->open_protocol:0);

	         passed_index = -1;
	}
	count = 10;
   /* Get Config Index in case of modify/delete operations from CPEID */
        if((IFX_MODIFY_F_SET(flags)) ||
                (IFX_DELETE_F_SET(flags))) {
                IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, entry->iid.cpeId, passed_index)

		sprintf(sbuf,"porttrigger_%d_fEnable",passed_index);
          if((ifx_GetObjData(FILE_RC_CONF, TAG_NAT_PORT_TRIGGER, sbuf, IFX_F_GET_ANY, &outflag, sValue)) != IFX_SUCCESS) {
		IFX_DBG("**Vipul**:failed to get fenable value from rc.conf");
#ifdef IFX_LOG_DEBUG
              IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
              ret = IFX_FAILURE;
              goto IFX_Handler;
           }
	  older_enable = atoi(sValue);
      }
		
	/* Determine the configuration index - for Add, Delete, Modify operations
      	 * Name is partial since index is not known
         * Fill array_fvp[] */
	  if(ifx_get_conf_index_and_nv_pairs(&entry->iid, passed_index, PREFIX_NAT_PORT_TRIGGER,
                                count, array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                        ret = IFX_FAILURE;
                        goto IFX_Handler;
        }


	  /************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	  if(IFX_ADD_F_NOT_SET(flags)) {
         //       CHECK_ACL_RET(entry->iid, count, array_fvp,
           //                                     changed_count, array_changed_fvp, flags, IFX_Handler)
        }

	/* Delete iptables rules if delete and modify */
	 if((IFX_MODIFY_F_SET(flags)) ||
                (IFX_DELETE_F_SET(flags))) {
				if(older_enable == 1)
				{
					 sprintf(sCommand, "/etc/rc.d/init.d/port_trigger_delete %d", passed_index);
			                 system(sCommand);

				}
		}
        /************** System Config File Update Block ****************/

        /* Backup rc.conf before proceeding with configuration */
        /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	  form_cfgdb_buf(conf_buf, count, array_fvp);

	  /* RC.CONF Configuration block */
        ret = ifx_SetObjData(FILE_RC_CONF, TAG_NAT_PORT_TRIGGER, flags, 1, conf_buf);
	
	  /* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
	  if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] for conf_buf [%s] ret [%d]", __FUNCTION__, __LINE__, conf_buf, ret);
#endif
                goto IFX_Handler;
        }

	  /* This will Compact the section and also update the count for both ADD and DELETE */
	 if(IFX_MODIFY_F_NOT_SET(flags)) {
                ifx_CompactCfgSection(FILE_RC_CONF, TAG_NAT_PORT_TRIGGER, flags);
        }
	
	/* Add iptable rules if ADD and MODIFY */
	 if((IFX_MODIFY_F_SET(flags)) ||
                (IFX_ADD_F_SET(flags))) {
				if(IFX_ADD_F_SET(flags))
				  IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, entry->iid.cpeId, passed_index)
                                if(entry->f_enable == 1)
                                {
                                         sprintf(sCommand, "/etc/rc.d/init.d/port_trigger_add %d", passed_index);
                                         system(sCommand);

                                }
                }


	



	   /*********** Notification Block *************/
        /* Notify the Internal TR69 Stack in case of MODIFY */
	  if(IFX_MODIFY_F_SET(flags)) {
             //   CHECK_N_SEND_NOTIFICATION(entry->iid, changed_count, array_changed_fvp, flags, IFX_Handler)
        }
        else if (IFX_INT_ADD_F_SET(flags)) {
	 /* In case of ADD operation, first update the ID Mappings
          * and then send the Notification for the attributes
          */
//	   UPDATE_ID_MAP_N_ATTRIBUTES(&entry->iid, count, array_fvp, flags, IFX_Handler)

  //         CHECK_N_SEND_NOTIFICATION(entry->iid, count, array_fvp, flags, IFX_Handler)
	  /* Manipulate nextCpeId only for ADD operations */
	   ifx_increment_next_cpeId(FILE_RC_CONF, TAG_NAT_PORT_TRIGGER);
        }
        else if (IFX_DELETE_F_SET(flags)) {
	 /* In case of DELETE operation, first send the notificatioupdate the ID Mappings
          * and then send the Notification for the attributes
          */
         /*********** Epilog Block **************/
//	 CHECK_N_SEND_NOTIFICATION(entry->iid, count, array_fvp, flags, IFX_Handler)

  //       UPDATE_ID_MAP_N_ATTRIBUTES(&entry->iid, count, array_fvp, flags, IFX_Handler)
        }

  /* Updating Persistent Storage */
 	ret = ifx_config_write(FILE_RC_CONF, flags);
        if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                goto IFX_Handler;
        }


IFX_Handler:
        IFX_MEM_FREE(array_changed_fvp)
        if(ret != IFX_SUCCESS) {
                IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
                return ret;
        }
        else
                return IFX_SUCCESS;
}

	


int32 ifx_get_port_trigger_info(PORT_TRIGGER *port_trigger);
int32 ifx_get_port_trigger_info(PORT_TRIGGER *port_trigger)
{

#ifdef CONFIG_FEATURE_NAPT

	char8   buf[MAX_FILELINE_LEN];
        char8   sValue[MAX_FILELINE_LEN];
        int32   ret = IFX_SUCCESS;
        int32   i = 0, outFlag = IFX_F_DEFAULT;
        uint32 flags= IFX_F_GET_ANY;
        int32 passed_index=-1;
	IFX_ID iid;
        iid.cpeId.Id=port_trigger->iid.cpeId.Id;
        sprintf(iid.cpeId.secName, "%s", TAG_NAT_PORT_TRIGGER);
        sprintf(port_trigger->iid.cpeId.secName,"%s",TAG_NAT_PORT_TRIGGER);
     /* get index from cpeid */
     IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, port_trigger->iid.cpeId, passed_index)
	
	i=passed_index;
	
	   //get the cpeid for this virtual server index i
	     sprintf(buf, "porttrigger_%d_cpeId", i);
              if((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_PORT_TRIGGER, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {

#ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                ret = IFX_FAILURE;
                goto IFX_Handler;

		}
		else
	        {
                        port_trigger->iid.cpeId.Id = atoi(sValue);
                }
		 
		// get the cpeid for this port trigger index i
		 sprintf(buf, "porttrigger_%d_pcpeId", i);
                if((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_PORT_TRIGGER, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue)) == IFX_SUCCESS) {
                        port_trigger->iid.pcpeId.Id = atoi(sValue);
                }
		 sprintf(buf, "porttrigger_%d_Application",i);
		 if((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_PORT_TRIGGER, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue)) == IFX_SUCCESS) {
                        strncpy(port_trigger->Application_Name,sValue,sizeof(port_trigger->Application_Name)-1);
                }

		 sprintf(buf, "porttrigger_%d_protocol", i);
                if ( (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_PORT_TRIGGER, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue) == IFX_SUCCESS) &&
                         !strcmp(sValue, "1") ) {
                        port_trigger -> protocol = 1;
                }
                else if(!strcmp(sValue, "2"))   {
                        port_trigger -> protocol = 2;
                }
		else
			port_trigger -> protocol = 0;

		 // get the enable status for this port trigger index i
		  sprintf(buf, "porttrigger_%d_fEnable", i);
                if ( (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_PORT_TRIGGER,
                                buf, flags, (IFX_OUT uint32 *)&outFlag, sValue) == IFX_SUCCESS)  )        {
                        if(!strcmp(sValue,"1"))
                                port_trigger -> f_enable = 1;
                        else
                                port_trigger -> f_enable = 0;
                }

		
		 // get the trigger port number for this port trigger index i
         	  sprintf(buf, "porttrigger_%d_tsPort", i);
                if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_PORT_TRIGGER, buf,
                                flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)       {
                        port_trigger ->trigger_start_port = atoi(sValue);
                }
		 sprintf(buf, "porttrigger_%d_tePort", i);
                if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_PORT_TRIGGER, buf,
                                flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)       {
                        port_trigger ->trigger_end_port = atoi(sValue);
                }
		 sprintf(buf, "porttrigger_%d_esPort", i);
                if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_PORT_TRIGGER, buf,
                                flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)       {
                        port_trigger ->external_start_port = atoi(sValue);
                }
		 sprintf(buf, "porttrigger_%d_eePort", i);
                if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_PORT_TRIGGER, buf,
                                flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)       {
                        port_trigger ->external_end_port = atoi(sValue);
                }


		 sprintf(buf, "porttrigger_%d_oprotocol", i);
                if ( (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_PORT_TRIGGER, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue) == IFX_SUCCESS) &&
                         !strcmp(sValue, "1") ) {
                        port_trigger -> open_protocol = 1;
                }
		 else if(!strcmp(sValue, "2"))   {
			port_trigger -> open_protocol = 2;
		}
                else    {
                        port_trigger -> open_protocol = 0;
                }
	
		IFX_Handler:

        if(ret != IFX_SUCCESS) {

                IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
                return ret;
        }
        else
                return IFX_SUCCESS;
#else
        IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
        return IFX_FAILURE;
#endif
}



int32 ifx_get_all_port_trigger_info(int32 *num_entries, PORT_TRIGGER **port_trigger, uint32 flags);
int32 ifx_get_all_port_trigger_info(int32 *num_entries, PORT_TRIGGER **port_trigger, uint32 flags)
{

#ifdef CONFIG_FEATURE_NAPT
IFX_DBG("**Vipul**:Enter in get all function of mapi");
        char8   buf[MAX_FILELINE_LEN];
        char8   sValue[MAX_FILELINE_LEN];
        int32   ret = IFX_SUCCESS, count = 0;
        int32   i = 0, outFlag = IFX_F_DEFAULT, t_num_entries = 0;

        *num_entries = 0;

	  /* get the number of virtual server entries */
        if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_NAT_PORT_TRIGGER, "nat_port_trigger_Count", flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                return IFX_FAILURE;
        }

        count = atoi(sValue);
	  if(count < 1 || count > 32767) {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                return IFX_SUCCESS;
        }

	   /* allocate memory for count port trigger in output array port trigger */
        *port_trigger = NULL;
        IFX_MEM_ALLOC((*port_trigger), PORT_TRIGGER *, count, sizeof(PORT_TRIGGER))

	  /* for each port trigger entry read the values from rc.conf and store
          * them as an array element in port trigger */
        for (i = 1; i <= count; i++) { /* ???? index i - 1 to i */

                /* get the cpeid for this port trigger index i - 1 */
                sprintf(buf, "porttrigger_%d_cpeId", i - 1);
                if((ifx_GetObjData(FILE_RC_CONF, TAG_NAT_PORT_TRIGGER, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS){
                        continue;
                }
                else {
                        (*port_trigger + t_num_entries)->iid.cpeId.Id = atoi(sValue);
                }
                ret = ifx_get_port_trigger_info(*port_trigger + t_num_entries);
    	      
	       t_num_entries++;
        
	}
	  *num_entries  = t_num_entries;


IFX_Handler:
        if(ret != IFX_SUCCESS) {
                IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
                return ret;
        }
        else
                return IFX_SUCCESS;
#else
        IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
        return IFX_FAILURE;
#endif
}
	
		


//vipul end
//////////////////////////////////////////////////////////////////////////////





int32 ifx_set_virtual_server_info_Without_TR69(int32 operation, VIRTUAL_SERVER *entry, uint32 flags)
{
	char8	conf_buf[MAX_DATA_LEN], remote_ip[MAX_IP_ADDR_LEN];
	char8	sValue[MAX_FILELINE_LEN], private_ip[MAX_IP_ADDR_LEN];
	int32	count = 0, passed_index = -1, ret = IFX_SUCCESS;
	#if 0
	int32	changed_count = 0;
	#endif
	IFX_NAME_VALUE_PAIR array_fvp[19], *array_changed_fvp = NULL;
	int32 wanIndx = 0, outflag = IFX_F_DEFAULT;
	char8 *retStr = NULL, buf[MAX_FILELINE_LEN];	

	int num_entries = 0, entry_size = 0, i = 0, rule_exists = 0;
	VIRTUAL_SERVER *virtual_servers = NULL;
	char ifName[IFNAMSIZE]; 
	IFX_IPT_RULE old_query_rule, new_query_rule;
	IFX_IPT_RULE snat_old_query_rule, snat_new_query_rule;

	memset(&old_query_rule, 0x00, sizeof(old_query_rule));
	memset(&new_query_rule, 0x00, sizeof(new_query_rule));

	memset(&snat_old_query_rule, 0x00, sizeof(snat_old_query_rule));
	memset(&snat_new_query_rule, 0x00, sizeof(snat_new_query_rule));

	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
	NULL_TERMINATE(ifName, 0x00, sizeof(ifName));
	memset(array_fvp, 0x00, sizeof(array_fvp));

	/*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY) 
	 * append the flag with internal flags */
	if (operation == IFX_OP_DEL) 
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if( (IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	}
	else
		flags |= IFX_F_MODIFY;


	/**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(entry)
		/* Do simple validation of flags such as less than 0 */
		IFX_VALIDATE_FLAGS(flags)

		/* The combination of remote ip, public port and protocol must be unique
		 * validation check is provided for this */
		IFX_VALIDATE_VS_ENTRY(entry, flags)
		if (entry->private_sport == 0) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		/* Free the Virtual Servers returned from within the macro */
		IFX_MEM_FREE(virtual_servers)
	}


	/*************** Prolog Block Continued *********************/
	/* Determine the PortMap's parent Section & Connection Name 
	 * The configuration agent could specify either the WANConnName
	 * or the parent CPEId under which the PortMapping needs to be
	 * created. In case of WEB, the port Map can be applied to "ALL"
	 * existing WAN Connection. This is currently not being handled in
	 * this API */
	sprintf(entry->iid.cpeId.secName, "%s", TAG_NAT_VIRTUALSER);

	if (entry->iid.pcpeId.Id == 0) {
		/* Then WAN Connection name MUST HAVE been specified 
		 * Use this ConnectionName to extract the parent Section
		 * and the parent's cpeID */

		/* ??? From WEB we get a case of ALL as Connection Name
		 * How to handle this case ???
		 * Currently we don't deal with this case */

		/* Extract the WAN Connection Name for which PortMap needs to be created */
		if (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_MAIN, "connName", 
							entry->wan_conn_if, &retStr) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		else {
			/* Now we would have got "wan_x" in the retStr 
			 * Using this retStr extract out the wanIndx
			 * For this wanIndx there should be either a WANIP
			 * or WANPPP Connection */
			wanIndx = atoi(strrchr(retStr, '_') + 1);
			sprintf(buf, "%s_%d_%s", PREFIX_WAN_IP, wanIndx, "cpeId");
			if((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, IFX_F_GET_ANY, 
							(IFX_OUT uint32 *)&outflag, sValue)) != IFX_SUCCESS) {
				/* In WANIP we couldn't find the parent for this PortMap
				 * Now Check in WANPPP Section for the same */

				sprintf(buf, "%s_%d_%s", PREFIX_WAN_PPP, wanIndx, "cpeId");
				if((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, IFX_F_GET_ANY, 
										(IFX_OUT uint32 *)&outflag, sValue)) != IFX_SUCCESS) {
					/* Here it could be that it belongs to "ALL" category
					 * How do we handle it ?? For now we ignore adding it!
					 * Return an Error!! */

#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
				else {
					/* Populate the pcpeId for PortMap entry */

					/* Update the Parent's cpeID and Section Name in piid
				 	 * This would be required only for ADD operation */
					entry->iid.pcpeId.Id = atoi(sValue);
					sprintf(entry->iid.pcpeId.secName, "%s", TAG_WAN_PPP);
				}
			}
			else {

				/* Populate the pcpeId for PortMap entry */

				/* Update the Parent's cpeID and Section Name in piid
				 * This would be required only for ADD operation */
				entry->iid.pcpeId.Id = atoi(sValue);
				sprintf(entry->iid.pcpeId.secName, "%s", TAG_WAN_IP);
			}
		}
	}
	else {
		/* Parent's cpeId is specified, now get the corresponding parent's
		 * section - which is either WANIP or WANPPP */
		sprintf(conf_buf, "%d", entry->iid.pcpeId.Id);
		if (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_IP, "cpeId", 
							conf_buf, &retStr) != IFX_SUCCESS) {
			/* In WANIP we couldn't find the parent for this PortMap
			 * Now Check in WANPPP Section for the same */
						
			if (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_PPP, "cpeId", 
							conf_buf, &retStr) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			else {
				sprintf(entry->iid.pcpeId.secName, "%s", TAG_WAN_PPP);
			}
		}
		else {
			sprintf(entry->iid.pcpeId.secName, "%s", TAG_WAN_IP);
		}
	

		/* Update the Parent's cpeID and Section Name in piid
		 * This would be required only for ADD operation */
	
		/* Update the WAN ConnName in the PortMap entry structure */
		wanIndx = atoi(strrchr(retStr, '_') + 1);
		sprintf(buf, "%s_%d_%s", PREFIX_WAN_MAIN, wanIndx, "connName");
		if((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, IFX_F_GET_ANY, 
					(IFX_OUT uint32 *)&outflag, sValue)) != IFX_SUCCESS) {
		
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		else {
			snprintf(entry->wan_conn_if,MAX_CONN_NAME_LEN,"%s", sValue);
		}
	}


	/**************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
		/* Allocate the IID for this route instance
		 * Set the parent SectionName and parent IID values 
		 * to NULL as there is no parent for Route Entity 
		 */
		if(ifx_get_IID_Without_TR69(&entry->iid, "remoteIp") != IFX_SUCCESS) {
		//if(ifx_get_IID(&entry->iid, "remoteIp") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
    } 


	/**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY
	 * Operations 
	 */
	if(IFX_DELETE_F_NOT_SET(flags)) {

		ifx_fill_ArrayFvp_FName(array_fvp, 0, 19, nat_virtualser_param_names);

		sprintf(array_fvp[0].value, "%d", entry->iid.cpeId.Id);
		sprintf(array_fvp[1].value, "%d", entry->iid.pcpeId.Id);

		/* NOTE : adaptation has take care of not passing ip address in format other than below,
			1. 0.0.0.0
			2. 255.255.255.255
			3. x.x.x.x where 0 <= x and x <= 255
		 */
		if (!(strcmp(inet_ntoa(entry->private_ip), "255.255.255.255"))) {
			sprintf(private_ip, "%s", "255.255.255.255");
		}
		else if (inet_ntoa(entry->private_ip)) {
			sprintf(private_ip, "%s", inet_ntoa(entry->private_ip));
		}
		else  {
				/* This PortMapping must not be OPERATIONAL */
				sprintf(private_ip, "%s", "\0");
		}

		/* NOTE : adaptation has take care of not passing ip address in format other than below,
			1. 0.0.0.0
			2. 255.255.255.255
			3. x.x.x.x where 0 <= x and x <= 255
		 */
		if (!(strcmp(inet_ntoa(entry->remote_ip), "255.255.255.255"))) {
			sprintf(remote_ip, "%s", "*");
		}
		else if (inet_ntoa(entry->remote_ip)) {
			sprintf(remote_ip, "%s", inet_ntoa(entry->remote_ip));
		}
		else {
			sprintf(remote_ip, "%s", "*");
		}

		ifx_fill_ArrayFvp_strValues(array_fvp, 2, 4, private_ip, remote_ip, entry->wan_conn_if, entry->vs_desc);

		count = 6;
//vipul start
		sprintf(array_fvp[count++].value, "%d", (entry->private_sport)?entry->private_sport:0);
		sprintf(array_fvp[count++].value, "%d", (entry->private_eport)?entry->private_eport:0);
		sprintf(array_fvp[count++].value, "%d", (entry->protocol == NAT_VS_PROTOCOL_TCP || entry->protocol == NAT_VS_PROTOCOL_UDP  || entry->protocol == NAT_VS_PROTOCOL_TCP_UDP)?entry->protocol:0);
		sprintf(array_fvp[count++].value, "%d", (entry->public_sport)?entry->public_sport:0);
		sprintf(array_fvp[count++].value, "%d", (entry->public_eport)?entry->public_eport:0);
//vipul end
		sprintf(array_fvp[count++].value, "%d", (entry->up_qos.qos_enabled)?1:0);
		sprintf(array_fvp[count++].value, "%d", (entry->up_qos.min_bw)?entry->up_qos.min_bw:0);
		sprintf(array_fvp[count++].value, "%d", (entry->up_qos.max_bw)?entry->up_qos.max_bw:0);
		sprintf(array_fvp[count++].value, "%d", (entry->dn_qos.qos_enabled)?1:0);
		sprintf(array_fvp[count++].value, "%d", (entry->dn_qos.min_bw)?entry->dn_qos.min_bw:0);
		sprintf(array_fvp[count++].value, "%d", (entry->dn_qos.max_bw)?entry->dn_qos.max_bw:0);
		sprintf(array_fvp[count++].value, "%d", (entry->f_enable ==1)?entry->f_enable:0);
		sprintf(array_fvp[count++].value,"%d", entry->lease_duration);

		passed_index = -1;
	}

	count = 19;

	/* Get Config Index in case of modify/delete operations from CPEID */
	if((IFX_MODIFY_F_SET(flags)) ||
		(IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, entry->iid.cpeId, passed_index)
		
		/* Now inoder to modify or delete the entry, we should be deleting 
		 * the portmap entry from the IPTABLE Chains */
		num_entries = 0;
		if (ifx_get_virtual_server_info(&num_entries, &virtual_servers, 
				IFX_F_GET_ANY) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		else {
			/* Match the cpeId with the virtual server entries and fill in the 
			 * corresponding matched values for the Rule to be Modified/Deleted */
			 if (num_entries > 0) {
				for (i=0; i<num_entries; i++) {
					if ((virtual_servers + i)->iid.cpeId.Id == entry->iid.cpeId.Id) {
						/* This is the intended PortMap entry
						 * Now populate the IPTABLE RULE structure */
							/* Set the rule_exists flag depending on the
							 * f_enable field in the Virtual entry structure
							 * This will signify whether the entry existed in the 
							 * system (f_enable = 1) or not (f_enable = 0) */
							rule_exists = (virtual_servers + i)->f_enable;
							old_query_rule.targetip = (virtual_servers + i)->private_ip.s_addr;
							old_query_rule.srcip =  (virtual_servers + i)->remote_ip.s_addr;
							old_query_rule.targetport_start = (virtual_servers + i)->private_sport;
							old_query_rule.targetport_end = (virtual_servers + i)->private_eport;
							if ((virtual_servers + i)->protocol == NAT_VS_PROTOCOL_TCP)
								old_query_rule.protocol = PROTO_TCP;
							else if ((virtual_servers + i)->protocol == NAT_VS_PROTOCOL_UDP)
								old_query_rule.protocol = PROTO_UDP;
			else if ((virtual_servers + i)->protocol == NAT_VS_PROTOCOL_TCP_UDP)
				old_query_rule.protocol =   NAT_VS_PROTOCOL_TCP_UDP; //To be set UDP for 2nd rule later.
							else
								old_query_rule.protocol = PROTO_ALL;
							old_query_rule.dstport_start = (virtual_servers + i)->public_sport;
							old_query_rule.dstport_end = (virtual_servers + i)->public_eport;
							if (strlen((virtual_servers + i)->wan_conn_if) > 0) {
								/* This should be called only for an Enabled PortMap entry
								 * It is possible to have Invalid Connection Name for any
								 * Disabled entry */
								if ((virtual_servers + i)->f_enable) { 
									if(ifx_get_wan_ifname_from_connName((virtual_servers + i)->wan_conn_if, ifName) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
										ret = IFX_FAILURE;
										goto IFX_Handler;
									}
								}
								STRNCPY(old_query_rule.inif, ifName, strlen(ifName));
							}
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
						break;
					} // Virtual Server Entry Matched

				} // End For
			 } // Virtual Server > 0
			 else {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			}
		}
	}


	/* Determine the configuration index - for Add, Delete, Modify operations 
     * Name is partial since index is not known 
     * Fill array_fvp[] */
	if(ifx_get_conf_index_and_nv_pairs(&entry->iid, passed_index, TAG_NAT_VIRTUALSER, 
				count, array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
	}


	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	#if 0
	if(IFX_ADD_F_NOT_SET(flags)) {
		CHECK_ACL_RET(entry->iid, count, array_fvp,
						changed_count, array_changed_fvp, flags, IFX_Handler)
	}
	#endif

	/************** System Config File Update Block ****************/

	/* Backup rc.conf before proceeding with configuration */
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

	/* In case of Delete/Modify Operation, first Delete the entry */
	if(IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		if (IFX_INT_ADD_F_NOT_SET(flags)) {
			entry_size = 1;

#ifdef NEEDS_MORE_THINKING
			/* Delete the DNAT matched rule corresponding to the input */
			IFX_IPT_SET_SINGLE_RULE(NAPT, DELETE,"IFX_NAPT_DNAT_VS",
							&old_query_rule, DNAT);
			/* Delete the SNAT matched rule corresponding to the input */
			snat_old_query_rule.srcip = old_query_rule.targetip;
			snat_old_query_rule.srcport_start = old_query_rule.targetport_start;
			snat_old_query_rule.srcport_end = old_query_rule.targetport_end;
			snat_old_query_rule.dstport_start = old_query_rule.dstport_start;
			snat_old_query_rule.dstport_end = old_query_rule.dstport_end;
			strcpy(snat_old_query_rule.outif, old_query_rule.inif);
			snat_old_query_rule.protocol = old_query_rule.protocol;				
			IFX_IPT_SET_SINGLE_RULE(NAPT, DELETE,"IFX_NAPT_SNAT_VS",
							&snat_old_query_rule, SNAT);
#endif
			/* Don't unnecessarily call the DELETE function if the entry was not there in
			 * the IPTABLES itself. It is possible to perform MODIFY operation on a disabled
			 * entry */
			if (rule_exists) {
				if (old_query_rule.protocol == NAT_VS_PROTOCOL_TCP_UDP) {
                                	 old_query_rule.protocol = PROTO_TCP; //To be set later for UDP.
		if (IFX_SET_NAPT_DNAT_VIRTUALSERVER_Entry(DELETE, &old_query_rule, entry_size) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		}
                          old_query_rule.protocol = NAT_VS_PROTOCOL_TCP_UDP;
               }
			if (old_query_rule.protocol == NAT_VS_PROTOCOL_TCP_UDP) {
				old_query_rule.protocol = PROTO_UDP; 
                       
			}
				if (IFX_SET_NAPT_DNAT_VIRTUALSERVER_Entry(DELETE, &old_query_rule, entry_size) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				}
			
			}
		}
	}

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, flags, 1, conf_buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] for conf_buf [%s] ret [%d]", __FUNCTION__, __LINE__, conf_buf, ret);
#endif
		goto IFX_Handler;
	}

	/* This will Compact the section and also update the count for both ADD and DELETE */
	if(IFX_MODIFY_F_NOT_SET(flags)) {
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_NAT_VIRTUALSER, flags);
	}


	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* System call to Add/Delete/Modify PortMap Entry */
	if(IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {

		/* In case of ADD/MODIFY operations just ADD the new PortMap entry */
		if (IFX_DELETE_F_NOT_SET(flags)) {

			/* Populate the Rule for DNAT Table /
		 	* Now populate the IPTABLE RULE structure */
			new_query_rule.targetip = entry->private_ip.s_addr;
			new_query_rule.srcip =  entry->remote_ip.s_addr;
			new_query_rule.targetport_start = entry->private_sport;
			new_query_rule.targetport_end = entry->private_eport;

			if (entry->protocol == NAT_VS_PROTOCOL_TCP)
				new_query_rule.protocol = PROTO_TCP;
			else if (entry->protocol == NAT_VS_PROTOCOL_UDP)
				new_query_rule.protocol = PROTO_UDP;
			else if (entry->protocol == NAT_VS_PROTOCOL_TCP_UDP)
				new_query_rule.protocol = PROTO_TCP; //To be set UDP for 2nd rule later.
			else
				new_query_rule.protocol = PROTO_ALL;
			new_query_rule.dstport_start = entry->public_sport;
			new_query_rule.dstport_end = entry->public_eport;

			if (strlen(entry->wan_conn_if) > 0) {
				if(ifx_get_wan_ifname_from_connName(entry->wan_conn_if, ifName) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
				STRNCPY(new_query_rule.inif, ifName, strlen(ifName));
			}
			entry_size = 1;

#ifdef NEEDS_MORE_THINKING
			/* Add the DNAT matched rule corresponding to the input */
			IFX_IPT_SET_SINGLE_RULE(NAPT, ADD,"IFX_NAPT_DNAT_VS",
							&new_query_rule, DNAT);
                     
			/* Add the SNAT matched rule corresponding to the input */
			snat_new_query_rule.srcip = new_query_rule.targetip;
			snat_new_query_rule.srcport_start = new_query_rule.targetport_start;
			snat_new_query_rule.srcport_end = new_query_rule.targetport_end;
			snat_new_query_rule.dstport_start = new_query_rule.dstport_start;
			 snat_new_query_rule.dstport_end = new_query_rule.dstport_end;
			strcpy(snat_new_query_rule.outif, new_query_rule.inif);
			snat_new_query_rule.protocol = new_query_rule.protocol;				
			IFX_IPT_SET_SINGLE_RULE(NAPT, ADD,"IFX_NAPT_SNAT_VS",
							&snat_new_query_rule, SNAT);
#endif
			/* Add the entry back to system only if it is ENABLED */
			if (entry->f_enable) {
	
		if (IFX_SET_NAPT_DNAT_VIRTUALSERVER_Entry(ADD, &new_query_rule, entry_size) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		}

		if (entry->protocol == NAT_VS_PROTOCOL_TCP_UDP) {
			new_query_rule.protocol = PROTO_UDP; //To be set for UDP.
			if (IFX_SET_NAPT_DNAT_VIRTUALSERVER_Entry(ADD, &new_query_rule, entry_size) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			}
                }
	}
	
		}

		if(system(SERVICE_QOS_RESTART))
			ret = IFX_SUCCESS;

		/* checks if ret is not IFX_SUCCESS then restores the rc.conf with CHKPOINT_FILE */
		if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

	} // IFX_DONT_ACTIVATE_F_NOT_SET


	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if(IFX_MODIFY_F_SET(flags)) {
		#if 0
		CHECK_N_SEND_NOTIFICATION(entry->iid, changed_count, array_changed_fvp, flags, IFX_Handler)
		#endif
	}
	else if (IFX_INT_ADD_F_SET(flags)) {
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */
		#if 0	
		UPDATE_ID_MAP_N_ATTRIBUTES(&entry->iid, count, array_fvp, flags, IFX_Handler)

		CHECK_N_SEND_NOTIFICATION(entry->iid, count, array_fvp, flags, IFX_Handler)
		#endif

		/* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_NAT_VIRTUALSER);
	}
	else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
		#if 0	
		CHECK_N_SEND_NOTIFICATION(entry->iid, count, array_fvp, flags, IFX_Handler)

		UPDATE_ID_MAP_N_ATTRIBUTES(&entry->iid, count, array_fvp, flags, IFX_Handler)
		#endif
	}	

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

IFX_Handler:
	IFX_MEM_FREE(retStr)
	IFX_MEM_FREE(virtual_servers)
	IFX_MEM_FREE(array_changed_fvp)
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}









/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_virtual_server_info(...)
*		operation	==> 	specifies the operation to be done for the ipaddree - interface 
*							combination passed such as ADD, DELETE
*		entry		==>		pointer to VIRTUAL_SERVER which will store the virtual server information to be configured
*    	flags		==>		flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
					The api either adds, deletes or modifies a virtual server portmap entry.
					It will configure the virtual server entry based on the ipaddress and wan connection.
					Source address can be zero indicating a wild card which the api takes care of.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_virtual_server_info(int32 operation, VIRTUAL_SERVER *entry, uint32 flags)
{
	char8	conf_buf[MAX_DATA_LEN], remote_ip[MAX_IP_ADDR_LEN];
	char8	sValue[MAX_FILELINE_LEN], private_ip[MAX_IP_ADDR_LEN];
	int32	count = 0, changed_count = 0, passed_index = -1, ret = IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR array_fvp[19], *array_changed_fvp = NULL;
	int32 wanIndx = 0, outflag = IFX_F_DEFAULT;
	char8 *retStr = NULL, buf[MAX_FILELINE_LEN];	

	int num_entries = 0, entry_size = 0, i = 0, rule_exists = 0;
	VIRTUAL_SERVER *virtual_servers = NULL;
	char ifName[IFNAMSIZE]; 
#if 0
	IFX_IPT_RULE old_query_rule, new_query_rule;
	IFX_IPT_RULE snat_old_query_rule, snat_new_query_rule;

	memset(&old_query_rule, 0x00, sizeof(old_query_rule));
	memset(&new_query_rule, 0x00, sizeof(new_query_rule));

	memset(&snat_old_query_rule, 0x00, sizeof(snat_old_query_rule));
	memset(&snat_new_query_rule, 0x00, sizeof(snat_new_query_rule));
#else
	P_IFX_IPT_RULE old_query_rule, new_query_rule;
	P_IFX_IPT_RULE snat_old_query_rule, snat_new_query_rule;

	IFX_MEM_ALLOC(old_query_rule, P_IFX_IPT_RULE, 1, sizeof(IFX_IPT_RULE))
	IFX_MEM_ALLOC(new_query_rule, P_IFX_IPT_RULE, 1, sizeof(IFX_IPT_RULE))
	IFX_MEM_ALLOC(snat_old_query_rule, P_IFX_IPT_RULE, 1, sizeof(IFX_IPT_RULE))
	IFX_MEM_ALLOC(snat_new_query_rule, P_IFX_IPT_RULE, 1, sizeof(IFX_IPT_RULE))
#endif // 0

	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
	NULL_TERMINATE(ifName, 0x00, sizeof(ifName));
	memset(array_fvp, 0x00, sizeof(array_fvp));

	/*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY) 
	 * append the flag with internal flags */
	if (operation == IFX_OP_DEL) 
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if( (IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	}
	else
		flags |= IFX_F_MODIFY;


	/**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(entry)
		/* Do simple validation of flags such as less than 0 */
		IFX_VALIDATE_FLAGS(flags)

		/* The combination of remote ip, public port and protocol must be unique
		 * validation check is provided for this */
		IFX_VALIDATE_VS_ENTRY(entry, flags)
		if (entry->private_sport == 0) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		/* Free the Virtual Servers returned from within the macro */
		IFX_MEM_FREE(virtual_servers)
	}


	/*************** Prolog Block Continued *********************/
	/* Determine the PortMap's parent Section & Connection Name 
	 * The configuration agent could specify either the WANConnName
	 * or the parent CPEId under which the PortMapping needs to be
	 * created. In case of WEB, the port Map can be applied to "ALL"
	 * existing WAN Connection. This is currently not being handled in
	 * this API */
	sprintf(entry->iid.cpeId.secName, "%s", TAG_NAT_VIRTUALSER);

	if (entry->iid.pcpeId.Id == 0) {
		/* Then WAN Connection name MUST HAVE been specified 
		 * Use this ConnectionName to extract the parent Section
		 * and the parent's cpeID */

		/* ??? From WEB we get a case of ALL as Connection Name
		 * How to handle this case ???
		 * Currently we don't deal with this case */

		/* Extract the WAN Connection Name for which PortMap needs to be created */
		if (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_MAIN, "connName", 
							entry->wan_conn_if, &retStr) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		else {
			/* Now we would have got "wan_x" in the retStr 
			 * Using this retStr extract out the wanIndx
			 * For this wanIndx there should be either a WANIP
			 * or WANPPP Connection */
			wanIndx = atoi(strrchr(retStr, '_') + 1);
			sprintf(buf, "%s_%d_%s", PREFIX_WAN_IP, wanIndx, "cpeId");
			if((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, IFX_F_GET_ANY, 
							(IFX_OUT uint32 *)&outflag, sValue)) != IFX_SUCCESS) {
				/* In WANIP we couldn't find the parent for this PortMap
				 * Now Check in WANPPP Section for the same */

				sprintf(buf, "%s_%d_%s", PREFIX_WAN_PPP, wanIndx, "cpeId");
				if((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, IFX_F_GET_ANY, 
										(IFX_OUT uint32 *)&outflag, sValue)) != IFX_SUCCESS) {
					/* Here it could be that it belongs to "ALL" category
					 * How do we handle it ?? For now we ignore adding it!
					 * Return an Error!! */

#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
				else {
					/* Populate the pcpeId for PortMap entry */

					/* Update the Parent's cpeID and Section Name in piid
				 	 * This would be required only for ADD operation */
					entry->iid.pcpeId.Id = atoi(sValue);
					sprintf(entry->iid.pcpeId.secName, "%s", TAG_WAN_PPP);
				}
			}
			else {

				/* Populate the pcpeId for PortMap entry */

				/* Update the Parent's cpeID and Section Name in piid
				 * This would be required only for ADD operation */
				entry->iid.pcpeId.Id = atoi(sValue);
				sprintf(entry->iid.pcpeId.secName, "%s", TAG_WAN_IP);
			}
		}
	}
	else {
		/* Parent's cpeId is specified, now get the corresponding parent's
		 * section - which is either WANIP or WANPPP */
		sprintf(conf_buf, "%d", entry->iid.pcpeId.Id);
		if (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_IP, "cpeId", 
							conf_buf, &retStr) != IFX_SUCCESS) {
			/* In WANIP we couldn't find the parent for this PortMap
			 * Now Check in WANPPP Section for the same */
		  IFX_MEM_FREE(retStr);				
			if (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_PPP, "cpeId", 
							conf_buf, &retStr) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			else {
				sprintf(entry->iid.pcpeId.secName, "%s", TAG_WAN_PPP);
			}
		}
		else {
			sprintf(entry->iid.pcpeId.secName, "%s", TAG_WAN_IP);
		}
	

		/* Update the Parent's cpeID and Section Name in piid
		 * This would be required only for ADD operation */
	
		/* Update the WAN ConnName in the PortMap entry structure */
		wanIndx = atoi(strrchr(retStr, '_') + 1);
		sprintf(buf, "%s_%d_%s", PREFIX_WAN_MAIN, wanIndx, "connName");
		if((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, IFX_F_GET_ANY, 
					(IFX_OUT uint32 *)&outflag, sValue)) != IFX_SUCCESS) {
		
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		else {
			snprintf(entry->wan_conn_if,MAX_CONN_NAME_LEN,"%s", sValue);
		}
	}


	/**************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
		/* Allocate the IID for this route instance
		 * Set the parent SectionName and parent IID values 
		 * to NULL as there is no parent for Route Entity 
		 */
		if(ifx_get_IID(&entry->iid, "remoteIp") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
    } 


	/**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY
	 * Operations 
	 */
	if(IFX_DELETE_F_NOT_SET(flags)) {

		ifx_fill_ArrayFvp_FName(array_fvp, 0, 19, nat_virtualser_param_names);

		sprintf(array_fvp[0].value, "%d", entry->iid.cpeId.Id);
		sprintf(array_fvp[1].value, "%d", entry->iid.pcpeId.Id);

		/* NOTE : adaptation has take care of not passing ip address in format other than below,
			1. 0.0.0.0
			2. 255.255.255.255
			3. x.x.x.x where 0 <= x and x <= 255
		 */
		if (!(strcmp(inet_ntoa(entry->private_ip), "255.255.255.255"))) {
			sprintf(private_ip, "%s", "255.255.255.255");
		}
		else if (inet_ntoa(entry->private_ip)) {
			sprintf(private_ip, "%s", inet_ntoa(entry->private_ip));
		}
		else  {
				/* This PortMapping must not be OPERATIONAL */
				sprintf(private_ip, "%s", "\0");
		}

		/* NOTE : adaptation has take care of not passing ip address in format other than below,
			1. 0.0.0.0
			2. 255.255.255.255
			3. x.x.x.x where 0 <= x and x <= 255
		 */
		if (!(strcmp(inet_ntoa(entry->remote_ip), "255.255.255.255"))) {
			sprintf(remote_ip, "%s", "*");
		}
		else if (inet_ntoa(entry->remote_ip)) {
			sprintf(remote_ip, "%s", inet_ntoa(entry->remote_ip));
		}
		else {
			sprintf(remote_ip, "%s", "*");
		}

		ifx_fill_ArrayFvp_strValues(array_fvp, 2, 4, private_ip, remote_ip, entry->wan_conn_if, entry->vs_desc);

		count = 6;
//vipul start
		snprintf(array_fvp[count++].value,MAX_TAG_VALUE_LEN,"%d", (entry->private_sport)?entry->private_sport:0);
		snprintf(array_fvp[count++].value,MAX_TAG_VALUE_LEN,"%d", (entry->private_eport)?entry->private_eport:0);
		snprintf(array_fvp[count++].value,MAX_TAG_VALUE_LEN,"%d", (entry->protocol == NAT_VS_PROTOCOL_TCP || entry->protocol == NAT_VS_PROTOCOL_UDP  || entry->protocol == NAT_VS_PROTOCOL_TCP_UDP)?entry->protocol:0);
		snprintf(array_fvp[count++].value,MAX_TAG_VALUE_LEN,"%d", (entry->public_sport)?entry->public_sport:0);
		snprintf(array_fvp[count++].value,MAX_TAG_VALUE_LEN,"%d", (entry->public_eport)?entry->public_eport:0);
//vipul end
		snprintf(array_fvp[count++].value,MAX_TAG_VALUE_LEN,"%d", (entry->up_qos.qos_enabled)?1:0);
		snprintf(array_fvp[count++].value,MAX_TAG_VALUE_LEN,"%d", (entry->up_qos.min_bw)?entry->up_qos.min_bw:0);
		snprintf(array_fvp[count++].value,MAX_TAG_VALUE_LEN,"%d", (entry->up_qos.max_bw)?entry->up_qos.max_bw:0);
		snprintf(array_fvp[count++].value,MAX_TAG_VALUE_LEN,"%d", (entry->dn_qos.qos_enabled)?1:0);
		snprintf(array_fvp[count++].value,MAX_TAG_VALUE_LEN,"%d", (entry->dn_qos.min_bw)?entry->dn_qos.min_bw:0);
		snprintf(array_fvp[count++].value,MAX_TAG_VALUE_LEN,"%d", (entry->dn_qos.max_bw)?entry->dn_qos.max_bw:0);
		snprintf(array_fvp[count++].value,MAX_TAG_VALUE_LEN,"%d", (entry->f_enable ==1)?entry->f_enable:0);
		snprintf(array_fvp[count++].value,MAX_TAG_VALUE_LEN-1,"%d", entry->lease_duration);

		passed_index = -1;
	}

	count = 19;

	/* Get Config Index in case of modify/delete operations from CPEID */
	if((IFX_MODIFY_F_SET(flags)) ||
		(IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, entry->iid.cpeId, passed_index)
		
		/* Now inoder to modify or delete the entry, we should be deleting 
		 * the portmap entry from the IPTABLE Chains */
		num_entries = 0;
		if (ifx_get_virtual_server_info(&num_entries, &virtual_servers, 
				IFX_F_GET_ANY) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		else {
			/* Match the cpeId with the virtual server entries and fill in the 
			 * corresponding matched values for the Rule to be Modified/Deleted */
			 if (num_entries > 0) {
				for (i=0; i<num_entries; i++) {
					if ((virtual_servers + i)->iid.cpeId.Id == entry->iid.cpeId.Id) {
						/* This is the intended PortMap entry
						 * Now populate the IPTABLE RULE structure */
							/* Set the rule_exists flag depending on the
							 * f_enable field in the Virtual entry structure
							 * This will signify whether the entry existed in the 
							 * system (f_enable = 1) or not (f_enable = 0) */
							rule_exists = (virtual_servers + i)->f_enable;
							old_query_rule->targetip = (virtual_servers + i)->private_ip.s_addr;
							old_query_rule->srcip =  (virtual_servers + i)->remote_ip.s_addr;
							old_query_rule->targetport_start = (virtual_servers + i)->private_sport;
							old_query_rule->targetport_end = (virtual_servers + i)->private_eport;
							if ((virtual_servers + i)->protocol == NAT_VS_PROTOCOL_TCP)
								old_query_rule->protocol = PROTO_TCP;
							else if ((virtual_servers + i)->protocol == NAT_VS_PROTOCOL_UDP)
								old_query_rule->protocol = PROTO_UDP;
			else if ((virtual_servers + i)->protocol == NAT_VS_PROTOCOL_TCP_UDP)
				old_query_rule->protocol =   NAT_VS_PROTOCOL_TCP_UDP; //To be set UDP for 2nd rule later.
							else
								old_query_rule->protocol = PROTO_ALL;
							old_query_rule->dstport_start = (virtual_servers + i)->public_sport;
							old_query_rule->dstport_end = (virtual_servers + i)->public_eport;
							if (strlen((virtual_servers + i)->wan_conn_if) > 0) {
								/* This should be called only for an Enabled PortMap entry
								 * It is possible to have Invalid Connection Name for any
								 * Disabled entry */
								if ((virtual_servers + i)->f_enable) { 
									if(ifx_get_wan_ifname_from_connName((virtual_servers + i)->wan_conn_if, ifName) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
										ret = IFX_FAILURE;
										goto IFX_Handler;
									}
								}
								STRNCPY(old_query_rule->inif, ifName, strlen(ifName));
							}
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
						break;
					} // Virtual Server Entry Matched

				} // End For
			 } // Virtual Server > 0
			 else {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			}
		}
	}


	/* Determine the configuration index - for Add, Delete, Modify operations 
     * Name is partial since index is not known 
     * Fill array_fvp[] */
	if(ifx_get_conf_index_and_nv_pairs(&entry->iid, passed_index, TAG_NAT_VIRTUALSER, 
				count, array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
	}


	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	if(IFX_ADD_F_NOT_SET(flags)) {
		CHECK_ACL_RET(entry->iid, count, array_fvp,
						changed_count, array_changed_fvp, flags, IFX_Handler)
	}


	/************** System Config File Update Block ****************/

	/* Backup rc.conf before proceeding with configuration */
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

	/* In case of Delete/Modify Operation, first Delete the entry */
	if(IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		if (IFX_INT_ADD_F_NOT_SET(flags)) {
			entry_size = 1;

#ifdef NEEDS_MORE_THINKING
			/* Delete the DNAT matched rule corresponding to the input */
			IFX_IPT_SET_SINGLE_RULE(NAPT, DELETE,"IFX_NAPT_DNAT_VS",
							&old_query_rule, DNAT);
			/* Delete the SNAT matched rule corresponding to the input */
			snat_old_query_rule->srcip = old_query_rule->targetip;
			snat_old_query_rule->srcport_start = old_query_rule->targetport_start;
			snat_old_query_rule->srcport_end = old_query_rule->targetport_end;
			snat_old_query_rule->dstport_start = old_query_rule->dstport_start;
			snat_old_query_rule->dstport_end = old_query_rule->dstport_end;
			strcpy(snat_old_query_rule->outif, old_query_rule->inif);
			snat_old_query_rule->protocol = old_query_rule->protocol;				
			IFX_IPT_SET_SINGLE_RULE(NAPT, DELETE,"IFX_NAPT_SNAT_VS",
							&snat_old_query_rule, SNAT);
#endif
			/* Don't unnecessarily call the DELETE function if the entry was not there in
			 * the IPTABLES itself. It is possible to perform MODIFY operation on a disabled
			 * entry */
			if (rule_exists) {
				if (old_query_rule->protocol == NAT_VS_PROTOCOL_TCP_UDP) {
                                	 old_query_rule->protocol = PROTO_TCP; //To be set later for UDP.
		if (IFX_SET_NAPT_DNAT_VIRTUALSERVER_Entry(DELETE, old_query_rule, entry_size) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		}
                          old_query_rule->protocol = NAT_VS_PROTOCOL_TCP_UDP;
               }
			if (old_query_rule->protocol == NAT_VS_PROTOCOL_TCP_UDP) {
				old_query_rule->protocol = PROTO_UDP; 
                       
			}
				if (IFX_SET_NAPT_DNAT_VIRTUALSERVER_Entry(DELETE, old_query_rule, entry_size) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				}
			
			}
		}
	}

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, flags, 1, conf_buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] for conf_buf [%s] ret [%d]", __FUNCTION__, __LINE__, conf_buf, ret);
#endif
		goto IFX_Handler;
	}

	/* This will Compact the section and also update the count for both ADD and DELETE */
	if(IFX_MODIFY_F_NOT_SET(flags)) {
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_NAT_VIRTUALSER, flags);
	}


	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* System call to Add/Delete/Modify PortMap Entry */
	if(IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {

		/* In case of ADD/MODIFY operations just ADD the new PortMap entry */
		if (IFX_DELETE_F_NOT_SET(flags)) {

			/* Populate the Rule for DNAT Table /
		 	* Now populate the IPTABLE RULE structure */
			new_query_rule->targetip = entry->private_ip.s_addr;
			new_query_rule->srcip =  entry->remote_ip.s_addr;
			new_query_rule->targetport_start = entry->private_sport;
			new_query_rule->targetport_end = entry->private_eport;

			if (entry->protocol == NAT_VS_PROTOCOL_TCP)
				new_query_rule->protocol = PROTO_TCP;
			else if (entry->protocol == NAT_VS_PROTOCOL_UDP)
				new_query_rule->protocol = PROTO_UDP;
			else if (entry->protocol == NAT_VS_PROTOCOL_TCP_UDP)
				new_query_rule->protocol = PROTO_TCP; //To be set UDP for 2nd rule later.
			else
				new_query_rule->protocol = PROTO_ALL;
			new_query_rule->dstport_start = entry->public_sport;
			new_query_rule->dstport_end = entry->public_eport;

			if (strlen(entry->wan_conn_if) > 0) {
				if(ifx_get_wan_ifname_from_connName(entry->wan_conn_if, ifName) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
				//STRNCPY(new_query_rule->inif, ifName, strlen(ifName));
				sprintf(new_query_rule->inif, "%s", ifName);
			}
			entry_size = 1;

#ifdef NEEDS_MORE_THINKING
			/* Add the DNAT matched rule corresponding to the input */
			IFX_IPT_SET_SINGLE_RULE(NAPT, ADD,"IFX_NAPT_DNAT_VS",
							&new_query_rule, DNAT);
                     
			/* Add the SNAT matched rule corresponding to the input */
			snat_new_query_rule->srcip = new_query_rule->targetip;
			snat_new_query_rule->srcport_start = new_query_rule->targetport_start;
			snat_new_query_rule->srcport_end = new_query_rule->targetport_end;
			snat_new_query_rule->dstport_start = new_query_rule->dstport_start;
			 snat_new_query_rule->dstport_end = new_query_rule->dstport_end;
			strcpy(snat_new_query_rule->outif, new_query_rule->inif);
			snat_new_query_rule->protocol = new_query_rule->protocol;				
			IFX_IPT_SET_SINGLE_RULE(NAPT, ADD,"IFX_NAPT_SNAT_VS",
							&snat_new_query_rule, SNAT);
#endif
			/* Add the entry back to system only if it is ENABLED */
			if (entry->f_enable) {
	
		if (IFX_SET_NAPT_DNAT_VIRTUALSERVER_Entry(ADD, new_query_rule, entry_size) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		}

		if (entry->protocol == NAT_VS_PROTOCOL_TCP_UDP) {
			new_query_rule->protocol = PROTO_UDP; //To be set for UDP.
			if (IFX_SET_NAPT_DNAT_VIRTUALSERVER_Entry(ADD, new_query_rule, entry_size) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			}
                }
	}
	
		}

		if(system(SERVICE_QOS_RESTART))
			ret = IFX_SUCCESS;

		/* checks if ret is not IFX_SUCCESS then restores the rc.conf with CHKPOINT_FILE */
		if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

	} // IFX_DONT_ACTIVATE_F_NOT_SET


	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if(IFX_MODIFY_F_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION(entry->iid, changed_count, array_changed_fvp, flags, IFX_Handler)
	}
	else if (IFX_INT_ADD_F_SET(flags)) {
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		UPDATE_ID_MAP_N_ATTRIBUTES(&entry->iid, count, array_fvp, flags, IFX_Handler)

		CHECK_N_SEND_NOTIFICATION(entry->iid, count, array_fvp, flags, IFX_Handler)

		/* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_NAT_VIRTUALSER);
	}
	else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
		CHECK_N_SEND_NOTIFICATION(entry->iid, count, array_fvp, flags, IFX_Handler)

		UPDATE_ID_MAP_N_ATTRIBUTES(&entry->iid, count, array_fvp, flags, IFX_Handler)
	}	

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

IFX_Handler:
	IFX_MEM_FREE(retStr)
	IFX_MEM_FREE(virtual_servers)
	IFX_MEM_FREE(array_changed_fvp)
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_global_nat(...)
*		status		==>		Flag value which tells if the Global Nat status has to be set or reset
*    	flags		==>		flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
					The api sets or resets the Global Nat Status based on the input ststua value.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_global_nat(int32 status, uint32 flags)
{
	char8	buf[MAX_FILELINE_LEN], sCommand[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	int32	bNAPTEnable = 0, ret = IFX_SUCCESS, outFlag = IFX_SUCCESS;

    NULL_TERMINATE(buf, 0, sizeof(buf));
    NULL_TERMINATE(sCommand, 0, sizeof(sCommand));

	if(status == 1) {
		sprintf(buf, "ipnat_enable=\"1\"\n");
		sprintf(sCommand,"%s --NAPT 1\n",NAPTCFG);
		bNAPTEnable = 1;
	}
	else {
		sprintf(buf, "ipnat_enable=\"0\"\n");
		sprintf(sCommand,"%s --NAPT 0\n",NAPTCFG);
		bNAPTEnable = 0;
	}

	if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_NAT_MAIN, "ipnat_enable", IFX_F_GET_ANY, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	if((ret = ifx_SetObjData(FILE_RC_CONF, TAG_NAT_MAIN, flags, 1, buf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	//Runtime Change
	if(system(sCommand))
		ret = IFX_SUCCESS;

#ifdef CONFIG_FEATURE_ALGS
	if (bNAPTEnable && atoi(sValue)==0) {
		system(SERVICE_ALGS_START);
	}
	else if (bNAPTEnable==0 && atoi(sValue)==1) {
		system(SERVICE_ALGS_STOP);
	}
#endif //CONFIG_FEATURE_ALGS

	// save setting
	if (ifx_config_write(FILE_RC_CONF, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
	}

IFX_Handler:
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}
#endif



/* GET APIs */


/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_nat_status_on_if(...)
*	wan_index	==>	the input wan index for which the nat enable status has to be returned 
*	iid		==>	output pointer to IFX_ID structure which will have the cpeid and
				parent cpeid of the wan connection with index wan_index
*	flags		==>	
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads the cpeid and pcpeid field for the 
			wan index specified from rc.conf and returns them in iid structure.
			Also the nat enable status will be returned as return value of the function.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_nat_status_on_if(int32 wan_index, IFX_ID *iid, uint32 flags)
{
#ifdef CONFIG_FEATURE_NAPT
	char8	*retStr = NULL, sCommand[MAX_FILELINE_LEN], sValue[MAX_NAME_SIZE], *str = NULL;
	int32	ret = IFX_SUCCESS, wanIdx = -1, outFlag = IFX_F_DEFAULT, delim = '_';

	if(wan_index < 0) { // from TR69
		sprintf(sCommand, "%d", iid->cpeId.Id);
		/* get wan index from distinct cpeid=value combination */
		ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_MAIN, "cpeId", sCommand, &retStr);
		if(ret != IFX_SUCCESS) {
			/* cpeid not found or is distinct in wan_main */
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		str = strrchr(retStr, delim) + 1;
		if(str != NULL)
			wanIdx = atoi(str);
	}
	else { // from Web
		wanIdx = wan_index;
		IFX_MEM_ALLOC(retStr, char8 *, 1, MAX_NAME_SIZE * sizeof(char8))
		sprintf(retStr, "wan_%d", wanIdx);
		/* iid not given, fill in the iid here */
		sprintf(sCommand, "%s_cpeId", retStr);
		if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, sCommand, IFX_F_GET_ANY, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		iid->cpeId.Id = atoi(sValue);
		snprintf(iid->cpeId.secName, strlen(TAG_WAN_MAIN), TAG_WAN_MAIN);

		sprintf(sCommand, "%s_pcpeId", retStr);
		if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, sCommand, IFX_F_GET_ANY, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		iid->pcpeId.Id = atoi(sValue);
		snprintf(iid->pcpeId.secName, strlen(TAG_WAN_CONN_DEVICE), TAG_WAN_CONN_DEVICE);
	}

	/* get the nat enable status for this wan connection with index wan_index */
	sprintf(sCommand, "%s_NATEnable", retStr);
	if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, sCommand, IFX_F_GET_ANY, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

IFX_Handler:
	IFX_MEM_FREE(retStr)
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
		return IFX_FAILURE;
	}
	else
		return atoi(sValue);
#else
	IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
	return IFX_FAILURE;
#endif
}
////////////////////////////////////////////////////////////////////////////////////////
//function  : ifx_get_one_virtual_server_info
//arguments : VIRTUAL_SERVER virtual_servers that is output pointer to virtual server
//return    : IFX_SUCCESS if successful
//	      IFX_FAIL otherwise
////////////////////////////////////////////////////////////////////////////////////////
int32 ifx_get_one_virtual_server_info(VIRTUAL_SERVER *virtual_servers)
{
#ifdef CONFIG_FEATURE_NAPT
	char8   buf[MAX_FILELINE_LEN];
        char8   sValue[MAX_FILELINE_LEN];
        int32   ret = IFX_SUCCESS;
        int32   i = 0 , diffserv_vs_enable = 0, outFlag = IFX_F_DEFAULT;
	uint32 flags= IFX_F_GET_ANY;
      	int32 vserver_index=-1;
	
	memset(sValue,'\0',sizeof(sValue)); 
	IFX_ID iid;
	iid.cpeId.Id=virtual_servers->iid.cpeId.Id;
	//printf("virtusl server values assigned\n");
        // get the enable status of qos, if enabled get the enable status of diffserv
        // this diffserv status if set then the qos parameters of the virtaul server
        //  entry will also be read from rc.conf and returned in the output array 
        if (ifx_GetObjData(FILE_RC_CONF, TAG_QOS_CONFIG,
                        "QOS_ENABLE", IFX_F_GET_ANY, (IFX_OUT uint32 *)&outFlag, sValue) == IFX_SUCCESS) {
                if (!strcmp(sValue, "1"))       {
                        if (ifx_GetObjData(FILE_RC_CONF, TAG_QOS_DIFFSERV_CONFIG,
                                        "DIFFSERV_VIRTUAL_SERVER", flags, (IFX_OUT uint32 *)&outFlag, sValue) == IFX_SUCCESS)     {
                                if (!strcmp(sValue, "1"))       {
                                        diffserv_vs_enable = 1;
                                }
                        }
                }
        }
	sprintf(iid.cpeId.secName, "%s", TAG_NAT_VIRTUALSER);
	sprintf(virtual_servers->iid.cpeId.secName,"%s",TAG_NAT_VIRTUALSER);
	if(ifx_get_index_from_cpe_id(FILE_RC_CONF, &iid.cpeId, &vserver_index) != IFX_SUCCESS)
        {
                  #ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
                   #endif
			printf("ifx_get_index_from_cpe_id failed in nat.c\n");
                        ret = IFX_FAILURE;
                        goto IFX_Handler;
        }
        i=vserver_index;

	/* initialize the cache for this instance */
	sprintf(buf, "%s_%d_", PREFIX_NAT_VS, vserver_index);
	if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf, IFX_F_INT_CACHE_INIT | IFX_F_GET_ANY, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	//get the cpeid for this virtual server index i 
                sprintf(buf, "nat_virtualser_%d_cpeId", i);
		memset(sValue,'\0',sizeof(sValue)); 
              if((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
		//continue;
               }
                else {
                        virtual_servers->iid.cpeId.Id = atoi(sValue);
                }

                // get the cpeid for this virtual server index i 
                sprintf(buf, "nat_virtualser_%d_pcpeId", i);
                memset(sValue,'\0',sizeof(sValue));
                if((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue)) == IFX_SUCCESS) {
                        virtual_servers->iid.pcpeId.Id = atoi(sValue);
                }

                // get the local ip address for this virtual server index i 
                sprintf(buf, "nat_virtualser_%d_privateIp", i);
		memset(sValue,'\0',sizeof(sValue)); 
                if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,
                                flags, (IFX_OUT uint32 *)&outFlag,  sValue)) != IFX_SUCCESS) {
			//continue;
                }
                else if (strlen(sValue) > 0)  {
                        virtual_servers-> private_ip.s_addr = inet_addr(sValue);
                }
                else
                        virtual_servers-> private_ip.s_addr = 0;

                // get the public ip address for this virtual server index i 
		sprintf(buf, "nat_virtualser_%d_remoteIp", i);
		memset(sValue,'\0',sizeof(sValue)); 
                if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,
                                flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)       {
                        if (strcmp(sValue, "*"))
                                virtual_servers -> remote_ip.s_addr = inet_addr(sValue);
                        else
                                virtual_servers -> remote_ip.s_addr = 0;
                }

                // get the local port number for this virtual server index i 
                sprintf(buf, "nat_virtualser_%d_spport", i);
		memset(sValue,'\0',sizeof(sValue)); 
                if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,
                                flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)       {
                        virtual_servers -> private_sport = atoi(sValue);
                }
		sprintf(buf, "nat_virtualser_%d_epport", i);
		memset(sValue,'\0',sizeof(sValue)); 
                if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,
                                flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)       {
                        virtual_servers -> private_eport = atoi(sValue);
                }

                // get the protocol type for this virtual server index i 
                sprintf(buf, "nat_virtualser_%d_ptype", i);
		memset(sValue,'\0',sizeof(sValue)); 
         	if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue) == IFX_SUCCESS) {
                        if( !strcmp(sValue, "1") ) {
                        	virtual_servers -> protocol = 1;
                	}
                        else if( !strcmp(sValue, "2") ) {
                        	virtual_servers -> protocol = 2;
                	}
                	else{
                        	virtual_servers -> protocol = 3;
                	}
		}
                // get the public port number for this virtual server index i 
                sprintf(buf, "nat_virtualser_%d_spuport", i);
		memset(sValue,'\0',sizeof(sValue)); 
                if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,
                                flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS) {
                        virtual_servers -> public_sport = atoi(sValue);
                }
		sprintf(buf, "nat_virtualser_%d_epuport", i);
		memset(sValue,'\0',sizeof(sValue)); 
                if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,
                                flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS) {
                        virtual_servers -> public_eport = atoi(sValue);
                }

                // if diffserv status is enable then read the qos parameters for this
                 // virtual server index i //
		if (diffserv_vs_enable) {
                        sprintf(buf, "nat_virtualser_%d_upqosEnable", i);
		        memset(sValue,'\0',sizeof(sValue)); 
                        if ( (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER,
                                        buf, flags, (IFX_OUT uint32 *)&outFlag, sValue) == IFX_SUCCESS) ) {
                                if(!strcmp(sValue,"1"))
                                        virtual_servers -> up_qos.qos_enabled = 1;
                                else
                                        virtual_servers -> up_qos.qos_enabled = 0;
                        }

                        sprintf(buf, "nat_virtualser_%d_upmaxBW", i);
		        memset(sValue,'\0',sizeof(sValue)); 
                        if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,
                                        flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)       {
                                virtual_servers -> up_qos.max_bw = atoi(sValue);
                        }

                        sprintf(buf, "nat_virtualser_%d_upminBW", i);
		        memset(sValue,'\0',sizeof(sValue)); 
                        if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,
                                        flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)       {
                                virtual_servers -> up_qos.min_bw = atoi(sValue);
                        }

                        sprintf(buf, "nat_virtualser_%d_dnqosEnable", i);
		        memset(sValue,'\0',sizeof(sValue)); 
                        if ( (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER,
                                        buf, flags, (IFX_OUT uint32 *)&outFlag, sValue) == IFX_SUCCESS) ) {
                                if(!strcmp(sValue,"1"))
                                        virtual_servers -> dn_qos.qos_enabled = 1;
                                else
                                        virtual_servers -> dn_qos.qos_enabled = 0;
                        }

                        sprintf(buf, "nat_virtualser_%d_dnmaxBW", i);
		        memset(sValue,'\0',sizeof(sValue)); 
                        if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,
                                        flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)       {
                                virtual_servers -> dn_qos.max_bw = atoi(sValue);
                        }

                        sprintf(buf, "nat_virtualser_%d_dnminBW", i);
		        memset(sValue,'\0',sizeof(sValue)); 
                        if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,
                                        flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)       {
                                virtual_servers -> dn_qos.min_bw = atoi(sValue);
                        }
                }
		// get the Wan Connection Name for this virtual server index i 
                sprintf(buf, "nat_virtualser_%d_wanConnIf", i);
		memset(sValue,'\0',sizeof(sValue)); 
                if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,
                                                                flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)       {
                                strlcpy(virtual_servers -> wan_conn_if, sValue,MAX_CONN_NAME_LEN);
                }

                // get the lease duration for this virtual server index i 
                sprintf(buf, "nat_virtualser_%d_lease", i);
		memset(sValue,'\0',sizeof(sValue)); 
                if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,
                                                                flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)       {
                                virtual_servers -> lease_duration = atoi(sValue);
                }

                // get the enable status for this virtual server index i 
                sprintf(buf, "nat_virtualser_%d_fEnable", i);
		memset(sValue,'\0',sizeof(sValue)); 
                if ( (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER,
                                buf, flags, (IFX_OUT uint32 *)&outFlag, sValue) == IFX_SUCCESS)  )        {
                        if(!strcmp(sValue,"1"))
                                virtual_servers -> f_enable = 1;
                        else
                                virtual_servers -> f_enable = 0;
                }

                // get the portmap description for this virtual server index i
		memset(sValue,'\0',sizeof(sValue)); 
                sprintf(buf, "nat_virtualser_%d_desc", i);
                if ( (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER,
                                buf, flags, (IFX_OUT uint32 *)&outFlag, sValue) == IFX_SUCCESS)  )        {
                        strlcpy(virtual_servers -> vs_desc, sValue,MAX_VS_DESC_LEN);
                }
                else {
                        virtual_servers -> vs_desc[0]='\0';
                }
	//printf("get virtual server complete\n");
IFX_Handler:
	/* destroy the cache for this instance */
	sprintf(buf, "%s_%d_", PREFIX_NAT_VS, vserver_index);
	if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf, IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to destroy cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

        if(ret != IFX_SUCCESS) {
                IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
                return ret;
        }
        else
                return IFX_SUCCESS;
#else
        IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
        return IFX_FAILURE;
#endif
}
/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_virtual_server_info(...)
*	num_entries	==>	output number of virtual server entries in rc.conf
*	virtual_servers	==>	output pointer to array of VIRTUAL_SERVER
*	flags		==>	
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads the virtual server entries from rc.conf and
			returns them in the array virtual_servers. Also the count of virtual
			servers read will be returned in num_entries.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_virtual_server_info(int32 *num_entries, VIRTUAL_SERVER **virtual_servers, uint32 flags)
{
#ifdef CONFIG_FEATURE_NAPT
	char8	buf[MAX_FILELINE_LEN];
	char8	sValue[MAX_FILELINE_LEN];
	int32	ret = IFX_SUCCESS, iVsCount = 0;
	int32	i = 0, diffserv_vs_enable = 0, outFlag = IFX_F_DEFAULT, t_num_entries = 0;

	*num_entries = 0;

	/* get the enable status of qos, if enabled get the enable status of diffserv
	 * this diffserv status if set then the qos parameters of the virtaul server
	 * entry will also be read from rc.conf and returned in the output array */
	if (ifx_GetObjData(FILE_RC_CONF, TAG_QOS_CONFIG, 
			"QOS_ENABLE", flags, (IFX_OUT uint32 *)&outFlag, sValue) == IFX_SUCCESS) {
		if (!strcmp(sValue, "1"))	{
			if (ifx_GetObjData(FILE_RC_CONF, TAG_QOS_DIFFSERV_CONFIG, 
					"DIFFSERV_VIRTUAL_SERVER", flags, (IFX_OUT uint32 *)&outFlag, sValue) == IFX_SUCCESS)	{
				if (!strcmp(sValue, "1"))	{
					diffserv_vs_enable = 1;
				}
			}
		}
	}

	/* get the number of virtual server entries */
	if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, "nat_virtualser_Count", flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
	}

	iVsCount = atoi(sValue);
	if(iVsCount < 1 || iVsCount > 32767) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_SUCCESS;
	}

	/* allocate memory for iVsCount virtual servers in output array virtual_servers */
	*virtual_servers = NULL;
	IFX_MEM_ALLOC((*virtual_servers), VIRTUAL_SERVER *, iVsCount, sizeof(VIRTUAL_SERVER))

	/* for each virtual server entry read the values from rc.conf and store
	 * them as an array element in virtual_servers */
	for (i = 1; i <= iVsCount; i++) { /* ???? index i - 1 to i */

		/* get the cpeid for this virtual server index i - 1 */
		sprintf(buf, "nat_virtualser_%d_cpeId", i - 1);
		if((ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS){
			continue;
		}
		else {
			(*virtual_servers + t_num_entries)->iid.cpeId.Id = atoi(sValue);
		}

#if 1
		ret = ifx_get_one_virtual_server_info(*virtual_servers + t_num_entries);
#else
		/* get the cpeid for this virtual server index i - 1 */
		sprintf(buf, "nat_virtualser_%d_pcpeId", i - 1);
		if((ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue)) == IFX_SUCCESS) {
			(*virtual_servers + t_num_entries)->iid.pcpeId.Id = atoi(sValue);
		}

		/* get the local ip address for this virtual server index i - 1 */
		sprintf(buf, "nat_virtualser_%d_privateIp", i-1);
		if ((ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,  
				flags, (IFX_OUT uint32 *)&outFlag,  sValue)) != IFX_SUCCESS)	{
			continue;
		}
		else if (strlen(sValue) > 0)  {
			(*virtual_servers + t_num_entries) -> private_ip.s_addr = inet_addr(sValue);
		}
		else
			(*virtual_servers + t_num_entries) -> private_ip.s_addr = 0;

		/* get the public ip address for this virtual server index i - 1 */
		sprintf(buf, "nat_virtualser_%d_remoteIp", i-1);
		if (ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,  
				flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)	{
			if (strcmp(sValue, "*"))
				(*virtual_servers + t_num_entries) -> remote_ip.s_addr = inet_addr(sValue);
			else
				(*virtual_servers + t_num_entries) -> remote_ip.s_addr = 0;
		}
	  
		/* get the local port number for this virtual server index i - 1 */
		sprintf(buf, "nat_virtualser_%d_spport", i-1);
		if (ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,  
				flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)	{
			(*virtual_servers + t_num_entries) -> private_sport = atoi(sValue);
		}
		 sprintf(buf, "nat_virtualser_%d_epport", i-1);
                if (ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,
                                flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)       {
                        (*virtual_servers + t_num_entries) -> private_eport = atoi(sValue);
                }

		/* get the protocol type for this virtual server index i - 1 */
		sprintf(buf, "nat_virtualser_%d_ptype", i-1);
		if  (ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue) == IFX_SUCCESS){
			if(! strcmp(sValue, "1")){
				(*virtual_servers + t_num_entries) -> protocol = 1;
			}
        		else  if(!strcmp(sValue, "2"))	{
				(*virtual_servers + t_num_entries) -> protocol = 2;
			}
			else	{
				(*virtual_servers + t_num_entries) -> protocol = 3;
			}
		}
		/* get the public port number for this virtual server index i - 1 */
		sprintf(buf, "nat_virtualser_%d_spuport", i-1);
		if (ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,  
				flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS) {
			(*virtual_servers + t_num_entries) -> public_sport = atoi(sValue);
		}
		 sprintf(buf, "nat_virtualser_%d_epuport", i-1);
                if (ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,
                                flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS) {
                        (*virtual_servers + t_num_entries) -> public_eport = atoi(sValue);
                }

		/* if diffserv status is enable then read the qos parameters for this
		 * virtual server index i - 1 */
		if (diffserv_vs_enable)	{
			sprintf(buf, "nat_virtualser_%d_upqosEnable", i-1);
			if ( (ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, 
					buf, flags, (IFX_OUT uint32 *)&outFlag, sValue) == IFX_SUCCESS) )	{
				if(!strcmp(sValue,"1"))
					(*virtual_servers + t_num_entries) -> up_qos.qos_enabled = 1;
				else
					(*virtual_servers + t_num_entries) -> up_qos.qos_enabled = 0;
			}

			sprintf(buf, "nat_virtualser_%d_upmaxBW", i-1);
			if (ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,  
					flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)	{
				(*virtual_servers + t_num_entries) -> up_qos.max_bw = atoi(sValue);
			}
		
			sprintf(buf, "nat_virtualser_%d_upminBW", i-1);
			if (ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,  
					flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)	{
				(*virtual_servers + t_num_entries) -> up_qos.min_bw = atoi(sValue);
			}

			sprintf(buf, "nat_virtualser_%d_dnqosEnable", i-1);
			if ( (ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, 
					buf, flags, (IFX_OUT uint32 *)&outFlag, sValue) == IFX_SUCCESS) )	{
				if(!strcmp(sValue,"1"))
					(*virtual_servers + t_num_entries) -> dn_qos.qos_enabled = 1;
				else
					(*virtual_servers + t_num_entries) -> dn_qos.qos_enabled = 0;
			}

			sprintf(buf, "nat_virtualser_%d_dnmaxBW", i-1);
			if (ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,  
					flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)	{
				(*virtual_servers + t_num_entries) -> dn_qos.max_bw = atoi(sValue);
			}
		
			sprintf(buf, "nat_virtualser_%d_dnminBW", i-1);
			if (ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,  
					flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)	{
				(*virtual_servers + t_num_entries) -> dn_qos.min_bw = atoi(sValue);
			}
		}

		/* get the Wan Connection Name for this virtual server index i - 1 */
		sprintf(buf, "nat_virtualser_%d_wanConnIf", i-1);
		if (ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,  
								flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)	{
				strcpy((*virtual_servers + t_num_entries) -> wan_conn_if, sValue);
		}
	
		/* get the lease duration for this virtual server index i - 1 */
		sprintf(buf, "nat_virtualser_%d_lease", i-1);
		if (ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf,  
								flags, (IFX_OUT uint32 *)&outFlag,  sValue) == IFX_SUCCESS)	{
				(*virtual_servers + t_num_entries) -> lease_duration = atoi(sValue);
		}
	
		/* get the enable status for this virtual server index i - 1 */
		sprintf(buf, "nat_virtualser_%d_fEnable", i-1);
		if ( (ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, 
				buf, flags, (IFX_OUT uint32 *)&outFlag, sValue) == IFX_SUCCESS)  )	{
			if(!strcmp(sValue,"1"))
				(*virtual_servers + t_num_entries) -> f_enable = 1;
			else
				(*virtual_servers + t_num_entries) -> f_enable = 0;
		}

		/* get the portmap description for this virtual server index i - 1 */
		sprintf(buf, "nat_virtualser_%d_desc", i-1);
		if ( (ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, 
				buf, flags, &outFlag, sValue) == IFX_SUCCESS)  )	{
			strncpy((*virtual_servers + t_num_entries) -> vs_desc, sValue, strlen(sValue));
			(*virtual_servers + t_num_entries) -> vs_desc[strlen(sValue)] = '\0';
		}
		else {
			(*virtual_servers + t_num_entries) -> vs_desc[0]='\0';
		}
#endif // 1

		t_num_entries++;
	}
	*num_entries  = t_num_entries;
	

IFX_Handler:
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
		if(*virtual_servers != NULL)
			IFX_MEM_FREE(*virtual_servers);
		return ret;
	}
	else
		return IFX_SUCCESS;
#else
	IFX_API_LOG("[%s] returned failure!", __FUNCTION__);
	return IFX_FAILURE;
#endif
}


#ifdef CONFIG_FEATURE_NAPT
/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_global_nat(...)
*	flags		==>	
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function returns the global nat status.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_global_nat(uint32 flags)
{
	int32	ret = IFX_SUCCESS, outFlag = IFX_F_DEFAULT;
	char8	sValue[MAX_FILELINE_LEN];

	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_NAT_MAIN, "ipnat_enable", flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return ret;
	}
	else {
		return atoi(sValue);
	}
}
#endif


#ifdef CONFIG_FEATURE_NAPT
int32 ifx_mapi_set_all_virtual_server_delete()
{
	IFX_NAME_VALUE_PAIR array_fvp[1];
        int32 ret = IFX_FAILURE,  operation=0;
        uint32  flags = IFX_F_DEFAULT;
        uint32   i = 0;
        char8   buf[MAX_FILELINE_LEN];
        char8   wan_conn_name[MAX_NAME_SIZE];
        wan_conn_name[0]='\0';
        VIRTUAL_SERVER virtual_serv;
        memset(&virtual_serv, 0x00, sizeof(virtual_serv));
	char8   sValue[MAX_FILELINE_LEN];
	int32 outFlag = IFX_F_DEFAULT, iVsCount = 0;
	
	int32 count = 0;
	memset(array_fvp, 0x00, sizeof(array_fvp));

        if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, "nat_virtualser_Count", flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                return IFX_FAILURE;
        }

        iVsCount = atoi(sValue);
        if(iVsCount < 1) {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
        }



        for (i = 0; i < iVsCount; i++)
        {
		   /* get the cpeid for this virtual server index i - 1 */
                sprintf(buf, "nat_virtualser_%d_cpeId", i);
                if((ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS){
                        continue;
                }
                else {
                        virtual_serv.iid.cpeId.Id = atoi(sValue);
                }
                        operation = IFX_OP_DEL;
                        flags = IFX_F_DELETE;
                        //virtual_serv.iid.cpeId.Id = (virtual+j)->iid.cpeId.Id;
                        sprintf(virtual_serv.iid.cpeId.secName, "%s", TAG_NAT_VIRTUALSER);
			virtual_serv.iid.config_owner = IFX_WEB;
			count=1;
		UPDATE_ID_MAP_N_ATTRIBUTES(&virtual_serv.iid, count, array_fvp, flags, IFX_Handler)
	}
	
	sprintf(buf, "%s_Count=\"0\"\n", TAG_NAT_VIRTUALSER);
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, IFX_F_DEFAULT, 1, buf);


IFX_Handler:
	return IFX_SUCCESS;
}
#endif


