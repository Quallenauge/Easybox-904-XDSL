/******************************************************************************

                               Copyright (c) 2008
                            Infineon Technologies AG
                     Am Campeon 1-12; 81726 Munich, Germany

  THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED NON-EXCLUSIVE,
  WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE AND SUBLICENSE THIS
  SOFTWARE IS FREE OF CHARGE.

  THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY DISCLAIMS
  ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR IMPLIED, INCLUDING
  WITHOUT LIMITATION, WARRANTIES OR REPRESENTATIONS OF WORKMANSHIP,
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, DURABILITY, THAT THE
  OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR FREE OR FREE OF ANY THIRD
  PARTY CLAIMS, INCLUDING WITHOUT LIMITATION CLAIMS OF THIRD PARTY INTELLECTUAL
  PROPERTY INFRINGEMENT.

  EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND EXCEPT
  FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE FOR ANY CLAIM
  OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
  ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
  DEALINGS IN THE SOFTWARE.

******************************************************************************/

/**
   \file ifx_mapi_wlan_wps.c
*/

#if defined (CONFIG_FEATURE_IFX_WIRELESS) && defined (IFX_MAPI_WLAN_WPS)
/* ========================================================================== */
/*                                 Includes                                   */
/* ========================================================================== */
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"

/* included for definition of bool */
#include "ifx_api_ipt_common.h"
/* ========================================================================== */
/*                             Macro definitions                              */
/* ========================================================================== */
#include <sys/time.h>
#if 0
#define IFX_MAPI_DEBUG(fd, file, text, args...)   \
do {  \
      FILE  *fd = NULL; \
      if((fd = fopen(file, "a")) == NULL) \
         system("echo \"debug file could not be opened in "file"!!\" >> /tmp/httpd_error");  \
      fprintf(fd, "[%s:%s:%d]: "text"\n\r", __FILE__, __FUNCTION__, __LINE__, ##args);   \
      fclose(fd); \
   } while (0)
#else
#define IFX_MAPI_DEBUG(fd, file, text, args...)
#endif /* #if 1 */


#define WLAN_WPS_PARAM_COUNT              10
#define WLAN_WPS_REGISTRAR_PARAM_COUNT    4
/* ========================================================================== */
/*                             Type definitions                               */
/* ========================================================================== */

/* ========================================================================== */
/*                             Global variables                               */
/* ========================================================================== */
char8 *wlan_wps_params[] = {"cpeId", "pcpeId", "enable", "enrolleeEna", "proxyEna",
                            "intRegsEna", "apDevName", "apPIN", "cfgMthds",
                            "setupLock"};

char8 *wlan_wps_regs_params[] = {"cpeId", "pcpeId", "enable", "regDevName"};

/* ========================================================================== */
/*                           Function prototypes                              */
/* ========================================================================== */

/* ========================================================================== */
/*                         Function implementation                            */
/* ========================================================================== */

/**
   This api reads wlan wps parameters from rc.conf and returns them in wlWps

   \param   wlWps - pointer to IFX_MAPI_WLAN_WPS_Cfg structure

   \param   flags - 

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_wps_config (
                              IFX_MAPI_WLAN_WPS_Cfg *wlWps,
                              uint32 flags)
{
   int32    ret = IFX_SUCCESS, apIdx = -1, count, i;
   char8   buf[MAX_DATA_LEN], *sValue = NULL;
   IFX_NAME_VALUE_PAIR  array_fvp[WLAN_WPS_PARAM_COUNT + 1];
#ifndef CONFIG_FEATURE_IFX_WIRELESS_WAVE300
   char8    sWpsDynInfo[MAX_DATA_LEN], sWpsDynTmp[MAX_DATA_LEN];
   char8   *pTmpStr = NULL, *pTmpStr2;
#endif /*CONFIG_FEATURE_IFX_WIRELESS_WAVE300*/
   struct timeval tv;	

   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);

   sprintf(wlWps->iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
   sprintf(wlWps->iid.cpeId.secName, "%s", TAG_WLAN_WPS);
   wlWps->iid.cpeId.Id = wlWps->iid.pcpeId.Id;
   /*
      get index from pcpeid, we need the index of the AP, i.e. the configuration
      index of the parent object (wlan_main), therefore we use the pcpeId here
   */
   IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlWps->iid.pcpeId, apIdx)
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "apIdx: %d", apIdx);

   /* get wps object from rc.conf */
   sprintf(buf, "%s%d_0_", PREFIX_WLAN_WPS, wlWps->iid.pcpeId.Id);
   if((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_WPS, buf, flags, &sValue)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "buf: %s", buf);
      goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "buf: %s, sValue: %s",
                  buf, sValue);

   /* form an array of field value pairs for easier access to parameters */
   memset(array_fvp, 0x00, sizeof(array_fvp));
   form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "count: %d", count);
   for (i = 0; i < count; i++)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "%s:%s", array_fvp[i].fieldname, array_fvp[i].value);

   wlWps->iid.cpeId.Id     = atoi(array_fvp[0].value);
   wlWps->iid.pcpeId.Id    = atoi(array_fvp[1].value);
   wlWps->enable           = atoi(array_fvp[2].value);
   wlWps->enrolleeEna      = atoi(array_fvp[3].value);
   wlWps->proxyEna         = atoi(array_fvp[4].value);
   wlWps->intRegEna        = atoi(array_fvp[5].value);

	if (strlen(array_fvp[6].value) <= IFX_MAPI_WPS_DEV_NAME_LEN - 1) {
		sprintf(wlWps->apWpsName, "%s",  array_fvp[6].value);
	}
	else {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig",
			   "WPS name too long: %d", strlen(array_fvp[6].value));
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
#ifdef CONFIG_FEATURE_IFX_WIRELESS_WAVE300
   wlWps->apWpsPin         = atoi(array_fvp[7].value);
   //ToDo values are not read from rc.conf need to fix this
   //wlWps->enaCfgMethods    = atoi(array_fvp[8].value);
   wlWps->setupLock        = atoi(array_fvp[9].value);
#else
   /*
      get the dynamic information if wps is enabled:
      - UUID
      - WPS version
      - Setup Locked Stated
      - Config State
      - last config error
   */
   if (wlWps->enable == TRUE)
   {
      NULL_TERMINATE(buf, 0x00, sizeof(buf));
      memset(sWpsDynInfo, 0x00, sizeof(sWpsDynInfo));
      sprintf(buf, "%s %d", SERVICE_WLAN_GET_WPS_DYN_INFO, apIdx);

      /* get dynamic WPS information */
      if (ifx_GetCfgData((char8*)buf, NULL, "-1", sWpsDynInfo) == 0)
      {
         ret = IFX_FAILURE;
         goto IFX_Handler;
      }
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "sWpsDynInfo: %s", sWpsDynInfo);

      /* save buffer in sWpsDynTmp */
      strcpy(sWpsDynTmp, sWpsDynInfo);

      /* get status information */
      if((pTmpStr = strstr(sWpsDynInfo,"configState=")) != NULL)
      {
         pTmpStr2 = strtok(pTmpStr, "\"");
         if(pTmpStr2 != NULL)
         {
             pTmpStr2 = strtok(NULL, "\"");
	     if(pTmpStr2 == NULL)
	     {
	         ret = IFX_FAILURE;
	         goto IFX_Handler;
	     }
	     wlWps->cfgState = atoi(pTmpStr2);
	     IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "status: %d", wlWps->cfgState);
         }
      }
      else
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "sWpsDynInfo: %s",sWpsDynInfo);

      /* restore sValue buffer from sValueTmp */
      strcpy(sWpsDynInfo, sWpsDynTmp);

      /* get UUID information */
      if((pTmpStr = strstr(sWpsDynInfo,"UUID=")) != NULL)
      {
         pTmpStr2 = strtok(pTmpStr, "\"");
         if(pTmpStr2 != NULL)
         {
             pTmpStr2 = strtok(NULL, "\"");
	     if(pTmpStr2 == NULL)
	     {
	         ret = IFX_FAILURE;
	         goto IFX_Handler;
	     }

             strcpy(wlWps->uuidAp, pTmpStr2);
             IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "uuidAp: %s", wlWps->uuidAp);
         }
      }
      else
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "sWpsDynInfo: %s",sWpsDynInfo);

      /* restore sValue buffer from sValueTmp */
      strcpy(sWpsDynInfo, sWpsDynTmp);

      /* get Setup Locked State information */
      if((pTmpStr = strstr(sWpsDynInfo,"setupLockedState=")) != NULL)
      {
         pTmpStr2 = strtok(pTmpStr, "\"");
         if(pTmpStr2 != NULL)
         {
             pTmpStr2 = strtok(NULL, "\"");
	     if(pTmpStr2 == NULL)
	     {
	         ret = IFX_FAILURE;
	         goto IFX_Handler;
	     }
             wlWps->setupLockedState = atoi(pTmpStr2);
             IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "setupLockedState: %d", wlWps->setupLockedState);
         }
      }
      else
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "sWpsDynInfo: %s",sWpsDynInfo);

      /* restore sValue buffer from sValueTmp */
      strcpy(sWpsDynInfo, sWpsDynTmp);

      /* get Last Config Error information */
      if((pTmpStr = strstr(sWpsDynInfo,"lastConfigError=")) != NULL)
      {
         pTmpStr2 = strtok(pTmpStr, "\"");
         if(pTmpStr2 != NULL)
         {
             pTmpStr2 = strtok(NULL, "\"");
	     if(pTmpStr2 == NULL)
	     {
	         ret = IFX_FAILURE;
	         goto IFX_Handler;
	     }
             wlWps->lastConfigError = atoi(pTmpStr2);
             IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "lastConfigError: %d", wlWps->lastConfigError);
         }
      }
      else
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "sWpsDynInfo: %s",sWpsDynInfo);
   }
   else
   {
	   wlWps->cfgState = IFX_MAPI_WPS_NOT_CONFIGURED;
   }
   /*
      \todo
      - WPS version
      - get dynamic info of registrar
   */

   /* get AP pin */
   NULL_TERMINATE(buf, 0x00, sizeof(buf));
   memset(sWpsDynInfo, 0x00, sizeof(sWpsDynInfo));
   sprintf(buf, "%s %d", SERVICE_WLAN_GET_WPS_PIN, apIdx);

   /* get WPS AP information */
   if (ifx_GetCfgData((char8*)buf, NULL, "-1", sWpsDynInfo) == 0)
   {
      ret = IFX_FAILURE;
      goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "sWpsDynInfo: %s", sWpsDynInfo);

   /* get status information */
   if((pTmpStr = strstr(sWpsDynInfo,"PIN=")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 != NULL)
      {
          pTmpStr2 = strtok(NULL, "\"");
	  if(pTmpStr2 == NULL)
	  {
	      ret = IFX_FAILURE;
	      goto IFX_Handler;
	  }
          wlWps->apWpsPin = atoi(pTmpStr2);
          IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "PIN: %d", wlWps->apWpsPin);
      }
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "sWpsDynInfo: %s",sWpsDynInfo);
#endif /*CONFIG_FEATURE_IFX_WIRELESS_WAVE300*/

   /*
      AP has been configured through WPS (cfgState), but this is not yet
      reflected in setupLock parameter of wlan_wps object => write back this
      configuration now
   */
   if ((wlWps->enable == TRUE) &&
       (wlWps->cfgState == IFX_MAPI_WPS_CONFIGURED) &&
       (wlWps->setupLock == FALSE))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "");
      wlWps->setupLock = TRUE;
      if((ret = ifx_mapi_set_wlan_wps_config(
                  IFX_OP_MOD, wlWps, IFX_F_INT_DONT_CONFIGURE)) != IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig",
                            "Setting setupLock failed");
         goto IFX_Handler;
      }
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "");
   }
IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "ret: %d", ret);
   /* free buffer allocated in ifx_GetCfgObject */
   IFX_MEM_FREE(sValue);
   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsConfig", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
   return ret;
}

/**
   This api gets the confiuration of a wlan wps registrar of one AP/VAP and
   returns the information in wlWpsRegs.

   \param   mainCpeId

   \param   numEntries

   \param   wlWpsRegs - pointer to IFX_MAPI_WLAN_WPS_Regs_Cfg structure

   \param   flags - 

   \return
      IFX_SUCCESS or IFX_FAILURE

   \todo check if numEntries can be removed
*/
int32 ifx_mapi_get_wlan_wps_registrar_config (
                              IFX_MAPI_WLAN_WPS_Regs_Cfg *wlWpsRegs,
                              uint32 flags)
{
   int32                ret = IFX_SUCCESS, passed_index = -1, count, i;
   char8	               buf[MAX_DATA_LEN], *sValue = NULL;
   IFX_NAME_VALUE_PAIR  array_fvp[WLAN_WPS_REGISTRAR_PARAM_COUNT + 1];
   char8                sWpsDynInfo[MAX_DATA_LEN], *pTmpStr = NULL, *pTmpStr2 = NULL;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig", "");

   sprintf(wlWpsRegs->iid.pcpeId.secName, "%s", TAG_WLAN_WPS);
   sprintf(wlWpsRegs->iid.cpeId.secName, "%s", TAG_WLAN_WPS_REGISTRAR);
   
   /* get index from pcpeid first */
   IFX_GET_INDEX_FROM_PCPEID(FILE_RC_CONF, wlWpsRegs->iid.pcpeId, passed_index)
   if (passed_index < 0) {
	   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig",
			   "passed_index: %d", passed_index);
	   ret = IFX_FAILURE;
	   goto IFX_Handler;
   }

   /*
      first get the dynamic information:
      - UUID
   */
   NULL_TERMINATE(buf, 0x00, sizeof(buf));
   memset(sWpsDynInfo, 0x00, sizeof(sWpsDynInfo));
   sprintf(buf, "%s %d", SERVICE_WLAN_GET_WPS_REGS_DYN_INFO, passed_index);

   /* get dynamic WPS registrar information */
   if (ifx_GetCfgData((char8*)buf, NULL, "-1", sWpsDynInfo) == 0)
   {
      ret = IFX_FAILURE;
      goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig", "sWpsDynInfo: %s", sWpsDynInfo);

   /* get UUID */
   if((pTmpStr = strstr(sWpsDynInfo,"UUID=")) != NULL)
   {
	  pTmpStr2 = strtok(pTmpStr, "\"");
	  if(pTmpStr2 == NULL)
	  {
	      ret = IFX_FAILURE;
	      goto IFX_Handler;
	  }
	  pTmpStr2 = strtok(NULL, "\"");
	  if(pTmpStr2 == NULL)
	  {
	      ret = IFX_FAILURE;
	      goto IFX_Handler;
	  }
	  strcpy(wlWpsRegs->uuidRegs, pTmpStr2);
	  IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig",
                         "uuidRegs: %s", wlWpsRegs->uuidRegs);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig",
                         "sWpsDynInfo: %s",sWpsDynInfo);

   /*
      the format for wlan_wps_regs object is wlwpsRegs<pCpeId>_<Index>_param
      for this purpose we are defining the used prefix wlWps<pCpeId> here
   */
   sprintf(buf, "%s%d_0_", PREFIX_WLAN_WPS_REGS, wlWpsRegs->iid.pcpeId.Id);
   if((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_WPS_REGISTRAR,
                              buf, flags, &sValue)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig", "buf: %s", buf);
      goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig",
                      "buf: %s, passed_index: %d, sValue: %s",
                      buf, passed_index, sValue);

   /* form an array of field value pairs for easier access to parameters */
   memset(array_fvp, 0x00, sizeof(array_fvp));
   form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig", "count: %d", count);
   for (i = 0; i < count; i++)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig", "%s:%s",
                     array_fvp[i].fieldname, array_fvp[i].value);

   wlWpsRegs->iid.cpeId.Id     = atoi(array_fvp[0].value);
   wlWpsRegs->iid.pcpeId.Id    = atoi(array_fvp[1].value);
   wlWpsRegs->enable           = atoi(array_fvp[2].value);

	if (strlen(array_fvp[3].value) <= IFX_MAPI_WPS_DEV_NAME_LEN - 1) {
		sprintf(wlWpsRegs->regsWpsName, "%s",  array_fvp[3].value);
	}
	else {
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig",
			   "WPS registrar name length: %d", strlen(array_fvp[3].value));
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWpsRegsConfig", "ret: %d", ret);
   /* free buffer allocated in ifx_GetCfgObject */
   IFX_MEM_FREE(sValue);
   if(ret != IFX_SUCCESS) {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return IFX_FAILURE;
   }
   else
      return IFX_SUCCESS;
}

/**
   This api gets the configuration of all wlan wps registrar of one AP/VAP and
   returns the information in wlWpsRegs.

   \param   mainCpeId

   \param   numEntries

   \param   wlWpsRegs - pointer to array of IFX_MAPI_WLAN_WPS_Regs_Cfg structures

   \param   flags - 

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_all_wlan_wps_registrar_config (
                              uint32 mainCpeId,
                              uint32 *numEntries,
                              IFX_MAPI_WLAN_WPS_Regs_Cfg **wlWpsRegs,
                              uint32 flags)
{
   return(IFX_SUCCESS);
}

/**
   This api sets wlan wps parameters available in wlWps

   \param oper

   \param   wlWps - pointer to IFX_MAPI_WLAN_WPS_Cfg structure

   \param flags

   \return
   - IFX_SUCCESS
   - IFX_FAILURE

   \remarks - This API differs a little from the usual set APIs. The format for
              storage in rc.conf is prefix{pcpeid}_<Inst>_param which
              is against conventional prefix_0_param. Therefore the usage
              of the utility functions must be done carefully
*/
int32 ifx_mapi_set_wlan_wps_config (
                              uint32 operation,
                              IFX_MAPI_WLAN_WPS_Cfg *wlWps,
                              uint32 flags)
{
   CPE_ID               pCpeId;
   int32                ret = IFX_SUCCESS, count = 0, changed_count = 0;
   char8	            conf_buf[MAX_DATA_LEN], prefix[MAX_FILELINE_LEN];
   int32	            objConfigIdx = -1, apIdx = -1, i;
   uint32				tmpFlags = 0;
   IFX_NAME_VALUE_PAIR  array_fvp[WLAN_WPS_PARAM_COUNT + 1];
   IFX_NAME_VALUE_PAIR  *array_changed_fvp = NULL;
   IFX_MAPI_WLAN_MainCfg wlan_main;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");

   /*
      initalize buffer conf_buf which is used for two purposes:
      - holding the configuration for wlWps to be written to rc.conf
      - holding the commands for system calls
   */
   memset(conf_buf, 0x00, sizeof(conf_buf));
   memset(&wlan_main, 0x00, sizeof(IFX_MAPI_WLAN_MainCfg));
   /*
      initalize buffer array_fvp which is used for storing the new configuration
      of wlWps in field-value format
   */
   memset(array_fvp, 0x00, sizeof(array_fvp));

   /*************** Validation Block *****************/
   /*
      for operations other than DELETE do the verification of input params
   */
   if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags))
   {
      /* Do simple validation of pointer (such as is NULL) */
      IFX_VALIDATE_PTR(wlWps)
      /* Do simple validation of flags such as less than 0 */
      IFX_VALIDATE_FLAGS(flags)
   }

   wlan_main.iid.cpeId.Id =  wlWps->iid.pcpeId.Id;  

    if((ret = ifx_mapi_get_wlan_main_config(&wlan_main, IFX_F_DEFAULT)) != IFX_SUCCESS) {
    	IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig",
    			"failed to get main params for instance wlan");
    	goto IFX_Handler;
    }

    wlan_main.WPSena = wlWps->enable;

    /* make sure no deactivation/activation here */
    tmpFlags = flags | IFX_F_INT_DONT_CONFIGURE;
    if (( ret = ifx_mapi_set_wlan_main_config(IFX_OP_MOD, &wlan_main, tmpFlags)) != IFX_SUCCESS)
    {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
         goto IFX_Handler;
    }   

   /*************** Prolog Block *********************/
   /*
      based on the operation (ADD or DELETE or MODIFY), the flags variable
      is appended with internal flags
   */

   if (operation == IFX_OP_DEL) 
      flags |= IFX_F_DELETE;
   else if (operation == IFX_OP_ADD)
   {
      if( (IFX_MODIFY_F_NOT_SET(flags)))
         flags |= IFX_F_INT_ADD;
   }
   else
      flags |= IFX_F_MODIFY;
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");

   /* section name of this object is TAG_WLAN_WPS */
   sprintf(wlWps->iid.cpeId.secName, "%s", TAG_WLAN_WPS);
   /* section name of parent object is TAG_WLAN_MAIN */
   sprintf(wlWps->iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);

   /*************** ID Allocation Block - Only for ADD Operation **************/
   if (IFX_ADD_F_SET(flags))
   {
      /*
         get the next cpe id for the section wlWps from the next_cpe_id
         section in rc.conf and store it as cpeId; the distinct parameter
         enable is provided for TR69
      */
      if(ifx_get_IID(&wlWps->iid, "enable") != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
         ret = IFX_FAILURE;
         goto IFX_Handler;
      }
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "tr69Id: %s",
                     wlWps->iid.tr69Id);
#if 0
      /* workaround for changing the tr69id to 1 for all wps objects */
      tmp = NULL;
      tmp = strrchr(wlWps->iid.tr69Id,'.');

      if(tmp)
         *tmp='\0';

      tmp = strrchr(wlWps->iid.tr69Id,'.'); 

      if(tmp!=NULL)
	      strcpy(tmp+1,buf);
#endif /* #if 0 */
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "tr69Id: %s",
                     wlWps->iid.tr69Id);
   } 

   /*
      the format for wlWps object is wlwps<pCpeId>_<Index>_param
      for this purpose we are defining the used prefix wlWps<pCpeId> here
   */
   sprintf(prefix, "%s%d", PREFIX_WLAN_WPS, wlWps->iid.pcpeId.Id);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "prefix: %s", prefix);

   /**************** Name Value Formation as per RC.CONF ********************/
   /*
      form the field-value pairs(FVP) from the given structure for ADD/MODIFY
      Operations 
   */
   count = 0;
   if(IFX_DELETE_F_NOT_SET(flags))
   {
      /*
         the buffer array_fvp is filled in a first step with the field names
         of wlan_sta_wmm object
      */
      ifx_fill_ArrayFvp_FName(array_fvp, count, WLAN_WPS_PARAM_COUNT,
                              wlan_wps_params);

      sprintf(array_fvp[0].value, "%d", wlWps->iid.cpeId.Id);
      sprintf(array_fvp[1].value, "%d", wlWps->iid.pcpeId.Id);
      sprintf(array_fvp[2].value, "%d", wlWps->enable);
      sprintf(array_fvp[3].value, "%d", wlWps->enrolleeEna);
      sprintf(array_fvp[4].value, "%d", wlWps->proxyEna);
      sprintf(array_fvp[5].value, "%d", wlWps->intRegEna);
      sprintf(array_fvp[6].value, "%s", wlWps->apWpsName);
      sprintf(array_fvp[7].value, "%d", wlWps->apWpsPin);
#if 0
      /*
         \todo
      */
      sprintf(array_fvp[8].value, "%d", wlWps->enaCfgMethods);
#endif /* #if 0 */

   /* leave setupLock unchanged */
#if 0
      /* make sure wlWps->setupLock is reset to unlocked if WPS is disabled */
      if (wlWps->enable == TRUE)
         sprintf(array_fvp[9].value, "%d", wlWps->setupLock);
      else
         sprintf(array_fvp[9].value, "%d", 0);
#else
      sprintf(array_fvp[9].value, "%d", wlWps->setupLock);
#endif /* #if 0 */
   }

   /* store number of parameters for wlan_sta_wmm object in count */
   count = WLAN_WPS_PARAM_COUNT;

   /*
      configuration index = 0 for all instances - for Add, Delete, Modify
      operations; instead pcpeId is appended in prefix name; example:
      wlWps<pcpeId>_0_param
   */
   objConfigIdx = 0;
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "objConfigIdx: %d",
                  objConfigIdx);
   if(ifx_get_conf_index_and_nv_pairs(&wlWps->iid, objConfigIdx, prefix, 
                                      count, array_fvp, flags) != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif /* #ifdef IFX_LOG_DEBUG */
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
         ret = IFX_FAILURE;
         goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "objConfigIdx: %d",
                  objConfigIdx);

   for (i = 0; i < WLAN_WPS_PARAM_COUNT; i++)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "name: %s, value: %s",
                     array_fvp[i].fieldname, array_fvp[i].value);

   /********* ACL Checking block - MUST for MODIFY/DELETE operations **********/
   if(IFX_ADD_F_NOT_SET(flags) )
   {
      /*
         for modify operations only an array for changed parameters is saved
         in array_changed_fvp;
         for modify and delete operation also a TR69 plugin is called for access
         control check
      */
      CHECK_ACL_RET(wlWps->iid, count, array_fvp,
                    changed_count, array_changed_fvp, flags, IFX_Handler)
   }

   for (i = 0; i < WLAN_WPS_PARAM_COUNT; i++)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "name: %s, value: %s",
                     array_fvp[i].fieldname, array_fvp[i].value);
   /*
      before updating the config file:
      stop the AP/VAP in case of delete operation only
   */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) && 
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags) &&
      IFX_DELETE_F_SET(flags))
   {
      /* use the parent cpeid to get index of the parent instance */
      pCpeId.Id = wlWps->iid.pcpeId.Id;
      sprintf(pCpeId.secName, "%s", TAG_WLAN_MAIN);
      /*
         for stopping the correct AP/VAP we need to get the index of the AP;
         this is not the index of the wlan_sta_wmm object, but the index of
         the correspondig parent (wlan_main object); therefore we pass the
         pCpeId (cpeId of wlan_main) to this macro; the retrieved index is
         saved in apIdx
      */
      IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, pCpeId, apIdx)
      sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, apIdx);
      system(conf_buf);
   }

   /*************** System Config File Update Block ****************/
   /*
      convert the name value pair in array_fvp into string format expected by
      rc.conf file
   */
   if ((ret = form_cfgdb_buf(conf_buf, count, array_fvp)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
      goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "conf_buf: %s", conf_buf);

   /* RC.CONF Configuration block */
   ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_WPS, flags, 1, conf_buf);
   if(ret != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
      goto IFX_Handler;
   }

   /**************** Device Configuration Block *********************/
   /*
      Device config thru Scripts/Utilities or Functions
      after config file update, for modify operation start script for applying
      the changes
   */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) && 
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags))
   {
      if (operation == IFX_OP_MOD)
      {
         /* use the parent cpeid to get index of the parent instance */
         pCpeId.Id = wlWps->iid.pcpeId.Id;
         sprintf(pCpeId.secName, "%s", TAG_WLAN_MAIN);
         /*
            for stopping the correct AP/VAP we need to get the index of the AP;
            this is not the index of the wlan_sta_wmm object, but the index of
            the correspondig parent (wlan_main object); therefore we pass the
            pCpeId (cpeId of wlan_main) to this macro; the retrieved index is
            saved in apIdx
         */
         IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, pCpeId, apIdx)
         sprintf(conf_buf, "%s %d", SERVICE_WLAN_WPS_CONFIG, apIdx);
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "apIdx: %d, conf_buf: %s",
                        apIdx, conf_buf);
         system(conf_buf);
      }
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");

   /*
      \todo check if this block is required
   */
#if 1
   /* this will Compact the section and also update the count for both ADD and DELETE */
   if(IFX_MODIFY_F_NOT_SET(flags))
   {
      ret = ifx_UpdateCountInSection(FILE_RC_CONF, TAG_WLAN_WPS, flags);
      if(ret != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "ret: %d", ret);
         goto IFX_Handler;
      }
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
   }
#endif /* #if 1 */

   /*********** Notification Block *************/
   /* Notify the Internal TR69 Stack in case of MODIFY */
   /*
      \todo
      is something missing here?
   */


   /*********** Epilog Block **************/
   /* Update the IID mappings in the mappings section for ADD/DELETE */
   if(IFX_MODIFY_F_SET(flags))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
      CHECK_N_SEND_NOTIFICATION(wlWps->iid, changed_count, array_changed_fvp,
                                flags, IFX_Handler)
   }
   else if (IFX_INT_ADD_F_SET(flags))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
      /*
         in case of ADD operation update the ID Mappings, then send notification
      */	
      /*********** Epilog Block **************/
      UPDATE_ID_MAP_N_ATTRIBUTES(&wlWps->iid, count, array_fvp, flags,
                                 IFX_Handler)
         CHECK_N_SEND_NOTIFICATION(wlWps->iid, count, array_fvp, flags,
                                   IFX_Handler)

      /* Manipulate nextCpeId only for ADD operations */
      ret = ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_WPS);
      if(ret != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "ret: %d", ret);
         goto IFX_Handler;
      }
   }
   else if (IFX_DELETE_F_SET(flags))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");
      /*
         in case of DELETE operation send notification, then update the ID Mappings
      */	
         CHECK_N_SEND_NOTIFICATION(wlWps->iid, count, array_fvp, flags,
                                   IFX_Handler)
      /*
         The TR69 mapping section is updated. Also the TR69 parameter
         Attribute section is updated.
         This is required to keep the TR69 specific sections up-to-date.
      */
      UPDATE_ID_MAP_N_ATTRIBUTES(&wlWps->iid, count, array_fvp, flags,
                                 IFX_Handler)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "ret: %d", ret);

   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "");

   /* Updating Persistent Storage */
   ret = ifx_config_write(FILE_RC_CONF, flags);
   if(ret != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "ret: %d", ret);
      goto IFX_Handler;
   }

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "ret: %d", ret);
   IFX_MEM_FREE(array_changed_fvp);
   if(ret != IFX_SUCCESS) {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return ret;
   }
   else
      return IFX_SUCCESS;
}

/**
   This api sets wlan wps registrar parameters available in wlWpsRegs

   \param oper

   \param   wlWpsRegs - pointer to IFX_MAPI_WLAN_WPS_Regs_Cfg structure

   \param flags

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int32 ifx_mapi_set_wlan_wps_registrar_config (
                              uint32 operation,
                              IFX_MAPI_WLAN_WPS_Regs_Cfg *wlWpsRegs,
                              uint32 flags)
{
   CPE_ID               pCpeId;
   int32                ret = IFX_SUCCESS, count = 0, changed_count = 0;
   char8	               conf_buf[MAX_DATA_LEN], prefix[MAX_FILELINE_LEN];
   int32	               objConfigIdx = -1, apIdx = -1, i;
   IFX_NAME_VALUE_PAIR  array_fvp[WLAN_WPS_REGISTRAR_PARAM_COUNT + 1];
   IFX_NAME_VALUE_PAIR  *array_changed_fvp = NULL;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");

   /*
      initalize buffer conf_buf which is used for two purposes:
      - holding the configuration for wlWpsRegs to be written to rc.conf
      - holding the commands for system calls
   */
   memset(conf_buf, 0x00, sizeof(conf_buf));

   /*
      initalize buffer array_fvp which is used for storing the new configuration
      of wlWpsRegs in field-value format
   */
   memset(array_fvp, 0x00, sizeof(array_fvp));

   /*************** Prolog Block *********************/
   /*
      based on the operation (ADD or DELETE or MODIFY), the flags variable
      is appended with internal flags
   */
   if (operation == IFX_OP_DEL) 
      flags |= IFX_F_DELETE;
   else if (operation == IFX_OP_ADD)
   {
      if( (IFX_MODIFY_F_NOT_SET(flags)))
         flags |= IFX_F_INT_ADD;
   }
   else
      flags |= IFX_F_MODIFY;
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");

   /*************** Validation Block *****************/
   /*
      for operations other than DELETE do the verification of input params
   */
   if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags))
   {
      /* Do simple validation of pointer (such as is NULL) */
      IFX_VALIDATE_PTR(wlWpsRegs)
      /* Do simple validation of flags such as less than 0 */
      IFX_VALIDATE_FLAGS(flags)
   }
   /* section name of this object is TAG_WLAN_WPS_REGISTRAR */
   sprintf(wlWpsRegs->iid.cpeId.secName, "%s", TAG_WLAN_WPS_REGISTRAR);
   /* section name of parent object is TAG_WLAN_MAIN */
   sprintf(wlWpsRegs->iid.pcpeId.secName, "%s", TAG_WLAN_WPS);

   /*************** ID Allocation Block - Only for ADD Operation **************/
   if (IFX_ADD_F_SET(flags))
   {
      /*
         get the next cpe id for the section wlWpsRegs from the next_cpe_id
         section in rc.conf and store it as cpeId; the distinct parameter
         enable is provided for TR69
      */
      if(ifx_get_IID(&wlWpsRegs->iid, "enable") != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");
         ret = IFX_FAILURE;
         goto IFX_Handler;
      }

      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "tr69Id: %s",
                     wlWpsRegs->iid.tr69Id);
   } 

   /*
      the format for wlWpsRegs object is wlwpsregs_<pCpeId>_<Index>_param
      for this purpose we are defining the used prefix wlWps<pcpeId> here
   */
   sprintf(prefix, "%s%d", PREFIX_WLAN_WPS_REGS, wlWpsRegs->iid.pcpeId.Id);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "prefix: %s", prefix);

   /**************** Name Value Formation as per RC.CONF ********************/
   /*
      form the field-value pairs(FVP) from the given structure for ADD/MODIFY
      Operations 
   */
   count = 0;
   if(IFX_DELETE_F_NOT_SET(flags))
   {
      /*
         the buffer array_fvp is filled in a first step with the field names
         of wlan_wps_regs object
      */
      ifx_fill_ArrayFvp_FName(array_fvp, count, WLAN_WPS_REGISTRAR_PARAM_COUNT,
                              wlan_wps_regs_params);

      sprintf(array_fvp[0].value, "%d", wlWpsRegs->iid.cpeId.Id);
      sprintf(array_fvp[1].value, "%d", wlWpsRegs->iid.pcpeId.Id);
      sprintf(array_fvp[2].value, "%d", wlWpsRegs->enable);
      sprintf(array_fvp[3].value, "%s", wlWpsRegs->regsWpsName);
      objConfigIdx = -1;
   }

   /* store number of parameters for wlan_wps_regs object in count */
   count = WLAN_WPS_REGISTRAR_PARAM_COUNT;

   /*
      configuration index = 0 for all instances - for Add, Delete, Modify
      operations; instead pcpeId is appended in prefix name; example:
      wlWps<pcpeId>_0_param
   */
   objConfigIdx = 0;
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsConfig", "objConfigIdx: %d",
                  objConfigIdx);
   if(ifx_get_conf_index_and_nv_pairs(&wlWpsRegs->iid, objConfigIdx, prefix, 
                                      count, array_fvp, flags) != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif /* #ifdef IFX_LOG_DEBUG */
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");
         ret = IFX_FAILURE;
         goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "objConfigIdx: %d",
                  objConfigIdx);

   /********* ACL Checking block - MUST for MODIFY/DELETE operations **********/
   if(IFX_ADD_F_NOT_SET(flags) )
   {
      /*
         for modify operations only an array of changed parameters is saved
         in array_changed_fvp;
         for modify and delete operation also a TR69 plugin is called for access
         control check
      */
      CHECK_ACL_RET(wlWpsRegs->iid, count, array_fvp,
                    changed_count, array_changed_fvp, flags, IFX_Handler)
   }

   for (i = 0; i < WLAN_WPS_REGISTRAR_PARAM_COUNT; i++)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "name: %s, value: %s",
                     array_fvp[i].fieldname, array_fvp[i].value);
   /*
      before updating the config file:
      stop the AP/VAP in case of delete operation only
   */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) && 
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags) &&
      IFX_DELETE_F_SET(flags))
   {
      /* use the parent cpeid to get index of the parent instance */
      pCpeId.Id = wlWpsRegs->iid.pcpeId.Id;
      sprintf(pCpeId.secName, "%s", TAG_WLAN_MAIN);
      /*
         for stopping the correct AP/VAP we need to get the index of the AP;
         this is not the index of the wlan_sta_wmm object, but the index of
         the correspondig parent (wlan_main object); therefore we pass the
         pCpeId (cpeId of wlan_main) to this macro; the retrieved index is
         saved in apIdx
      */
      IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, pCpeId, apIdx)
      sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, apIdx);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig",
                     "conf_buf: %s", conf_buf);
      system(conf_buf);
   }

   /*************** System Config File Update Block ****************/
   /*
      convert the name value pair in array_fvp into string format expected by
      rc.conf file
   */
   if ((ret = form_cfgdb_buf(conf_buf, count, array_fvp)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");
      goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "conf_buf: %s", conf_buf);

   /* RC.CONF Configuration block */
   ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_WPS_REGISTRAR, flags, 1, conf_buf);
   if(ret != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");
      goto IFX_Handler;
   }

   /**************** Device Configuration Block *********************/
   /*
      Device config thru Scripts/Utilities or Functions
      after config file update, for modify operation start script for applying
      the changes
   */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) && 
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags))
   {
      if (operation == IFX_OP_MOD)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");
         /* use the parent cpeid to get index of the parent instance */
         pCpeId.Id = wlWpsRegs->iid.pcpeId.Id;
         sprintf(pCpeId.secName, "%s", TAG_WLAN_MAIN);
         /*
            for stopping the correct AP/VAP we need to get the index of the AP;
            this is not the index of the wlan_sta_wmm object, but the index of
            the correspondig parent (wlan_main object); therefore we pass the
            pCpeId (cpeId of wlan_main) to this macro; the retrieved index is
            saved in apIdx
         */
         IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, pCpeId, apIdx)
         sprintf(conf_buf, "%s %d &", SERVICE_WLAN_WPS_CONFIG, apIdx);
         system(conf_buf);
      }
   }

   /* this will Compact the section and also update the count for both ADD and DELETE */
   if(IFX_MODIFY_F_NOT_SET(flags))
   {
      ret = ifx_UpdateCountInSection(FILE_RC_CONF, TAG_WLAN_WPS_REGISTRAR, flags);
      if(ret != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "ret: %d", ret);
         goto IFX_Handler;
      }
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");
   }

   /*********** Notification Block *************/
   /* Notify the Internal TR69 Stack in case of MODIFY */
   /*
      \todo
      is something missing here?
   */


   /*********** Epilog Block **************/
   /* Update the IID mappings in the mappings section for ADD/DELETE */
   if(IFX_MODIFY_F_SET(flags))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");
      CHECK_N_SEND_NOTIFICATION(wlWpsRegs->iid, changed_count, array_changed_fvp,
                                flags, IFX_Handler)
   }
   else if (IFX_INT_ADD_F_SET(flags))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");
      /*
         in case of ADD operation update the ID Mappings, then send notification
      */	
      /*********** Epilog Block **************/
      UPDATE_ID_MAP_N_ATTRIBUTES(&wlWpsRegs->iid, count, array_fvp, flags,
                                 IFX_Handler)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");
         CHECK_N_SEND_NOTIFICATION(wlWpsRegs->iid, count, array_fvp, flags,
                                   IFX_Handler)
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");
      }
      /* Manipulate nextCpeId only for ADD operations */
      ret = ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_WPS_REGISTRAR);
      if(ret != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "ret: %d", ret);
         goto IFX_Handler;
      }
   }
   else if (IFX_DELETE_F_SET(flags))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");
      /*
         in case of DELETE operation send notification, then update the ID Mappings
      */	
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");
         CHECK_N_SEND_NOTIFICATION(wlWpsRegs->iid, count, array_fvp, flags,
                                   IFX_Handler)
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");
      }
      /*
         The TR69 mapping section is updated. Also the TR69 parameter
         Attribute section is updated.
         This is required to keep the TR69 specific sections up-to-date.
      */
      UPDATE_ID_MAP_N_ATTRIBUTES(&wlWpsRegs->iid, count, array_fvp, flags,
                                 IFX_Handler)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "ret: %d", ret);
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "");

   /* Updating Persistent Storage */
   ret = ifx_config_write(FILE_RC_CONF, flags);
   if(ret != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "ret: %d", ret);
      goto IFX_Handler;
   }

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWpsRegistrarConfig", "ret: %d", ret);
   IFX_MEM_FREE(array_changed_fvp);
   if(ret != IFX_SUCCESS) {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
   return ret;
   }
   else
      return IFX_SUCCESS;
}

/**
   This api triggers the WPS push button control method on the wlan

   \param wlMnCpeId -   mainCpeID of AP/VAP the WPS PBC method shall be started for

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int32 ifx_mapi_trigger_wps_pbc (uint32 wlMnCpeId)
{
   int32    ret = IFX_SUCCESS, passed_index = -1;
   CPE_ID   mainCpeId;
   char8	   conf_buf[MAX_DATA_LEN];

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiTriggerWpsPbc", "");

   /*
      initalize buffer conf_buf which is used for holding the commands for
      system calls
   */
   memset(conf_buf, 0x00, sizeof(conf_buf));

   sprintf(mainCpeId.secName, "%s", TAG_WLAN_MAIN);
   mainCpeId.Id = wlMnCpeId;
   /*
      get configuration index from CPEID and save it in passed_index
   */
   IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, mainCpeId, passed_index)
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiTriggerWpsPbc", "passed_index: %d",
                  passed_index);

#ifdef CONFIG_FEATURE_LTQ_WIRELESS_VB
   /* call system script to remove temp file */
   sprintf(conf_buf, "rm /tmp/wps_2web_status");
   system(conf_buf);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiTriggerWpsPbc", "conf_buf: %s", conf_buf);
#endif

   /* call system script to initiate pbc based pairing */
   sprintf(conf_buf, "%s %d &", SERVICE_WLAN_WPS_PBC_PAIRING, passed_index);
   system(conf_buf);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiTriggerWpsPbc", "conf_buf: %s",
                  conf_buf);

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiTriggerWpsPbc", "ret: %d", ret);
   return ret;
}

/**
   This api triggers the WPS PIN method on the wlan

   \param wlMnCpeId -   mainCpeID of AP/VAP the WPS PBC method shall be started for

   \param clientPIN -   PIN entered on the Web page that must be given to wlan

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int32 ifx_mapi_trigger_wps_pin (uint32 wlMnCpeId, uint32 clientPIN)
{
   int32    ret = IFX_SUCCESS, passed_index = -1;
   CPE_ID   mainCpeId;
   char8	   conf_buf[MAX_DATA_LEN];

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiTriggerWpsPin", "");

   /*
      initalize buffer conf_buf which is used for holding the commands for
      system calls
   */
   memset(conf_buf, 0x00, sizeof(conf_buf));

   sprintf(mainCpeId.secName, "%s", TAG_WLAN_MAIN);
   mainCpeId.Id = wlMnCpeId;
   /*
      get configuration index from CPEID and save it in passed_index
   */
   IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, mainCpeId, passed_index)
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiTriggerWpsPin", "passed_index: %d",
                  passed_index);

#ifdef CONFIG_FEATURE_LTQ_WIRELESS_VB
   /* call system script to remove temp file */
   sprintf(conf_buf, "rm /tmp/wps_2web_status");
   system(conf_buf);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiTriggerWpsPin", "conf_buf: %s", conf_buf);
#endif

   /* call system script to initiate pin based pairing */
   sprintf(conf_buf, "%s %d %d &", SERVICE_WLAN_WPS_PIN_PAIRING, passed_index, clientPIN);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiTriggerWpsPin", "conf_buf: %s", conf_buf);
   system(conf_buf);

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiTriggerWpsPin", "ret: %d", ret);
   return ret;
}

/**
   This api restores the WPS pin to default.

   \param wlMnCpeId -   mainCpeID of AP/VAP

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int32 ifx_mapi_restore_wps_pin (uint32 wlMnCpeId)
{
   int32    ret = IFX_SUCCESS, passed_index = -1;
   CPE_ID   mainCpeId;
   char8	   conf_buf[MAX_DATA_LEN];

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiRestoreWpsPin", "");

   /*
      initalize buffer conf_buf which is used for holding the commands for
      system calls
   */
   memset(conf_buf, 0x00, sizeof(conf_buf));

   sprintf(mainCpeId.secName, "%s", TAG_WLAN_MAIN);
   mainCpeId.Id = wlMnCpeId;
   /*
      get configuration index from CPEID and save it in passed_index
   */
   IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, mainCpeId, passed_index)
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiRestoreWpsPin", "passed_index: %d",
                  passed_index);

   /* call system script to restore default AP pin */
   sprintf(conf_buf, "%s %d &", SERVICE_WLAN_RESTORE_WPS_PIN, passed_index);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiRestoreWpsPin", "conf_buf: %s", conf_buf);
   system(conf_buf);

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiRestoreWpsPin", "ret: %d", ret);
   return ret;
}

/**
   This api generates a new WPS pin for the AP/VAP.

   \param wlMnCpeId -   mainCpeID of AP/VAP

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int32 ifx_mapi_generate_wps_pin (uint32 wlMnCpeId)
{
   int32    ret = IFX_SUCCESS, passed_index = -1;
   CPE_ID   mainCpeId;
   char8	   conf_buf[MAX_DATA_LEN];

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGenerateWpsPin", "");

   /*
      initalize buffer conf_buf which is used for holding the commands for
      system calls
   */
   memset(conf_buf, 0x00, sizeof(conf_buf));

   sprintf(mainCpeId.secName, "%s", TAG_WLAN_MAIN);
   mainCpeId.Id = wlMnCpeId;
   /*
      get configuration index from CPEID and save it in passed_index
   */
   IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, mainCpeId, passed_index)
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGenerateWpsPin", "passed_index: %d",
                  passed_index);

   /* call system script to generate new AP pin */
   sprintf(conf_buf, "%s %d &", SERVICE_WLAN_GENERATE_WPS_PIN, passed_index);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGenerateWpsPin", "conf_buf: %s", conf_buf);
   system(conf_buf);

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGenerateWpsPin", "ret: %d", ret);
   return ret;
}

/**
   This api resets the WPS to out-of-box configuration.

   \param wlMnCpeId -   mainCpeID of AP/VAP

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
int32 ifx_mapi_reset_wps (uint32 wlMnCpeId)
{
   int32                   ret = IFX_SUCCESS, passed_index = -1;
   CPE_ID                  mainCpeId;
   char8	                  conf_buf[MAX_DATA_LEN];
   IFX_MAPI_WLAN_WPS_Cfg   wlWps;
	IFX_MAPI_WLAN_MainCfg   wlMain;
	IFX_MAPI_WLAN_SecCfg    wlSec;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "");

   /*
      initalize buffer conf_buf which is used for holding the commands for
      system calls
   */
   memset(conf_buf, 0x00, sizeof(conf_buf));

   sprintf(mainCpeId.secName, "%s", TAG_WLAN_MAIN);
   mainCpeId.Id = wlMnCpeId;
   /*
      get configuration index from CPEID and save it in passed_index
   */
   IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, mainCpeId, passed_index)
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "passed_index: %d",
                  passed_index);

   /* call system script to restore default AP pin */
   sprintf(conf_buf, "%s %d %s %s &", SERVICE_WLAN_RESET_WPS, passed_index,
            "SSID_AFTER_WPS_RESET", "PASSPHRASE_AFTER_WPS_RESET");
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "conf_buf: %s", conf_buf);
   system(conf_buf);
   
	memset(&wlWps, 0x00, sizeof(IFX_MAPI_WLAN_WPS_Cfg));
   /* get WPS information */
   wlWps.iid.config_owner = IFX_WEB;
	sprintf(wlWps.iid.cpeId.secName, "%s", TAG_WLAN_WPS);
	sprintf(wlWps.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
   /* parent cpeid of wps object, is cpeID of main object */
   wlWps.iid.pcpeId.Id  = wlMnCpeId;

   if ( ( ret = ifx_mapi_get_wlan_wps_config(&wlWps, IFX_F_DEFAULT)) != IFX_SUCCESS )
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "conf_buf: %s", conf_buf);
      goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "setupLock: %d", wlWps.setupLock);

   if (wlWps.setupLock == TRUE)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "setupLock: %d", wlWps.setupLock);
      /*
         re-set setupLock to FALSE
      */
      wlWps.setupLock = FALSE;
      if((ret = ifx_mapi_set_wlan_wps_config(
                  IFX_OP_MOD, &wlWps, IFX_F_INT_DONT_CONFIGURE)) != IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "conf_buf: %s", conf_buf);
         goto IFX_Handler;
      }
   }

	memset (&wlMain, 0, sizeof(IFX_MAPI_WLAN_MainCfg));
   wlMain.iid.cpeId.Id = wlMnCpeId;
	sprintf(wlMain.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
	sprintf(wlMain.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
	if (( ret = ifx_mapi_get_wlan_main_config(&wlMain, IFX_F_DEFAULT)) != IFX_SUCCESS)
	{
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps",
                         "cpeId: %s, %d",
                         wlMain.iid.cpeId.secName, wlMain.iid.cpeId.Id);
      goto IFX_Handler;
	}
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "SSID: %s",
                      wlMain.ssid);

   memset (&wlSec, 0, sizeof(IFX_MAPI_WLAN_SecCfg));
	sprintf(wlSec.iid.cpeId.secName, "%s", TAG_WLAN_SEC);
	sprintf(wlSec.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
   wlSec.iid.cpeId.Id = wlMnCpeId;

   if ((ret = ifx_mapi_get_wlan_security_config(&wlSec, IFX_F_DEFAULT)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "");
      goto IFX_Handler;
   }

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiResetWps", "ret: %d", ret);
   return ret;
}
#endif /* #if defined (CONFIG_FEATURE_IFX_WIRELESS) && defined (IFX_MAPI_WLAN_WPS) */
