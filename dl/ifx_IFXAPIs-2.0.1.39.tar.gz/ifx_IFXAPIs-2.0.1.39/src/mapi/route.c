
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"


char8 *route_param_names[] = {"cpeId", "pcpeId", "isPR", "srcIp", "srcMask", "srcStartPort", "srcEndPort", "dstIp", "dstMask", "dstStartPort", "dstEndPort", "gw", "routeIf", "routeProto", "diffserv", "metric", "fEnable", "mtuSize", "type"};

char8 *rip_param_names[] = {"route_dynamic_cpeId","route_dynamic_pcpeId", "route_dynamic_fEnable", "route_dynamic_supplyMode", "route_dynamic_listenMode"};

#define IFX_VALIDATE_ROUTE_ENTRY(entry, flags) { \
			if(entry->iid.config_owner == IFX_WEB) { \
				if(IFX_ADD_F_SET(flags) || IFX_MODIFY_F_SET(flags)) { \
					if(!strcmp(inet_ntoa(entry->ip_dst.ip), "0.0.0.0") || !strcmp(inet_ntoa(entry->ip_dst.mask), "0.0.0.0") || !strcmp(inet_ntoa(entry->gw), "0.0.0.0")) {\
						ret = IFX_FAILURE; \
						goto IFX_Handler; \
					} \
				} \
			} \
			else if(entry->iid.config_owner == IFX_TR69) {\
				if(IFX_MODIFY_F_SET(flags) && IFX_DONT_ACTIVATE_F_NOT_SET(flags) && IFX_DEACTIVATE_F_NOT_SET(flags) && IFX_INCOMPLETE_F_NOT_SET(flags)) { \
					if(!strcmp(inet_ntoa(entry->ip_dst.ip), "0.0.0.0") || !strcmp(inet_ntoa(entry->ip_dst.mask), "0.0.0.0")) {\
						ret = IFX_FAILURE; \
						goto IFX_Handler; \
					} \
				} \
			} \
		}

#define IFX_VALIDATE_POLICY_ROUTE_ENTRY(route, flags)  { }


#define IS_WILD_CARD(val) ((!strcmp(val, "*"))?1:0)

#define IFX_VALIDATE_DUPLICATE_ROUTE_ENTRY(entry, flags) { \
    	int32     num; \
    	int32     ret = IFX_SUCCESS, i; \
    	uint32	Flags = IFX_F_DEFAULT; \
    	ROUTE_ENTRY *route = NULL; \
    	ret = ifx_get_all_static_route_entries(&num, &route, Flags); \
	if(ret == IFX_SUCCESS)	{ \
		for (i=0; i<num; i++)	{ \
			if ( (((route+i)->ip_dst.ip.s_addr) == entry->ip_dst.ip.s_addr) \
			  && (((route+i)->ip_dst.mask.s_addr) == entry->ip_dst.mask.s_addr) \
			  && (((route+i)->gw.s_addr) == entry->gw.s_addr) \
			  && ((route+i)->iid.cpeId.Id != entry->iid.cpeId.Id) ) { \
				IFX_MEM_FREE(route); \
				return IFX_DUPLICATE_ENTRY; \
			} \
		} \
	} \
	IFX_MEM_FREE(route); \
}

/* SET APIs */


int32 ifx_set_route(int32 operation, ANY_ROUTE_ENTRY *route, int32 flags)
{
	int32	ret = IFX_SUCCESS, passed_index = -1, inp_isPR = 0;
	uint32	outFlag = IFX_F_DEFAULT;
	char8	buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];

	NULL_TERMINATE(buf, 0x00, sizeof(buf));

	inp_isPR = (strlen(inet_ntoa(route->ROUTE.policy_route.ip_src.ip)) && strcmp(inet_ntoa(route->ROUTE.policy_route.ip_src.ip), "0.0.0.0"))?1:0;

	if(operation == IFX_OP_ADD) {
		/* Determine route type and call the policy or static route set api */
		if(inp_isPR) {
			ret = ifx_set_policy_route(operation, &(route->ROUTE.policy_route), flags);
		}
		else {
			ret = ifx_set_static_route(operation, &(route->ROUTE.route), flags);
		}
	}
	else if(operation == IFX_OP_DEL) {
		/* Determine route type and call the policy or static route set api */
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, route->ROUTE.policy_route.iid.cpeId, passed_index)
		sprintf(buf, "%s_%d_isPR", PREFIX_ROUTING, passed_index);
		if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_ROUTING, buf, IFX_F_DEFAULT, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		if(atoi(sValue)) {
			ret = ifx_set_policy_route(operation, &(route->ROUTE.policy_route), flags);
		}
		else {
			ret = ifx_set_static_route(operation, &(route->ROUTE.route), flags);
		}
	}
	else if(operation == IFX_OP_MOD) {
		/* Determine the previous route type, compare with the current route type
			if they dont match
				call the corresponding api with delete
				and followed by add by preserving the cpeid and tr69id
					ensure that cpeid is not incremented here through a state flag
			else
				call the corresponding api with modify */
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, route->ROUTE.policy_route.iid.cpeId, passed_index)

		/* Determine the previous state of the Route - Policy/Static */
		sprintf(buf, "%s_%d_isPR", PREFIX_ROUTING, passed_index);
		if(ifx_GetObjData(FILE_RC_CONF, TAG_ROUTING, buf, IFX_F_DEFAULT, &outFlag, sValue) != IFX_SUCCESS) {
			/* Call modify based on the current route type */
			if(inp_isPR) { /* is a policy route */
				ret = ifx_set_policy_route(operation, &(route->ROUTE.policy_route), flags);
			}
			else { /* is a static route */
				ret = ifx_set_static_route(operation, &(route->ROUTE.route), flags);
			}
		}
		else {
			/* check if previous route type and current route type match */
			if(atoi(sValue) == inp_isPR) {
				if(atoi(sValue)) { /* is a policy route */
					ret = ifx_set_policy_route(operation, &(route->ROUTE.policy_route), flags);
				}
				else { /* is a static route */
					ret = ifx_set_static_route(operation, &(route->ROUTE.route), flags);
				}
			}
			else {
				/* route types don't match */
				/* based on previous route type call respective api with delete */
				if(atoi(sValue)) {
					/* policy route */
					ret = ifx_set_policy_route(IFX_OP_DEL, &(route->ROUTE.policy_route), IFX_F_DELETE);
				}
				else {
					/* static route */
					ret = ifx_set_static_route(IFX_OP_DEL, &(route->ROUTE.route), IFX_F_DELETE);
				}

				/* based on current route type call respective api with add */
				if(inp_isPR) {
					/* policy route */
					ret = ifx_set_policy_route(IFX_OP_ADD, &(route->ROUTE.policy_route), IFX_F_INT_ADD);
				}
				else {
					/* static route */
					ret = ifx_set_static_route(IFX_OP_ADD, &(route->ROUTE.route), IFX_F_INT_ADD);
				}
			}
		}
	}

IFX_Handler:
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}


int32 ifx_form_route_fvp(int32 oper, ANY_ROUTE_ENTRY route, int32 route_flags, IFX_NAME_VALUE_PAIR *arrayFvp,
						int32 *route_count)
{
	char8 dstIp[MAX_IP_ADDR_LEN], dstMask[MAX_IP_ADDR_LEN], gw_addr[MAX_IP_ADDR_LEN];

	sprintf(dstIp, "%s", (char8 *)inet_ntoa(route.ROUTE.route.ip_dst.ip));
	sprintf(dstMask, "%s", (char8 *)inet_ntoa(route.ROUTE.route.ip_dst.mask));
	sprintf(gw_addr, "%s", (char8 *)inet_ntoa(route.ROUTE.route.gw));

	ifx_fill_ArrayFvp_FName(arrayFvp, 0, 19, route_param_names);

	if(route.f_policy_route == '1') { /* Policy Route */
		sprintf(arrayFvp[0].value, "%d", route.ROUTE.policy_route.iid.cpeId.Id);
		sprintf(arrayFvp[1].value, "%d", route.ROUTE.policy_route.iid.pcpeId.Id);
		sprintf(arrayFvp[2].value, "%d", 1);

		if(!inet_ntoa(route.ROUTE.policy_route.ip_src.ip) || !strcmp((char8 *)inet_ntoa(route.ROUTE.policy_route.ip_src.ip), "0.0.0.0"))
			sprintf(arrayFvp[3].value, "%s", "*");
		else
			sprintf(arrayFvp[3].value, "%s", (char8 *)inet_ntoa(route.ROUTE.policy_route.ip_src.ip));
		if(!inet_ntoa(route.ROUTE.policy_route.ip_src.mask) || !strcmp((char8 *)inet_ntoa(route.ROUTE.policy_route.ip_src.mask), "0.0.0.0"))
			sprintf(arrayFvp[4].value, "%s", "*");
		else
			sprintf(arrayFvp[4].value, "%s", (char8 *)inet_ntoa(route.ROUTE.policy_route.ip_src.mask));

		if(route.ROUTE.policy_route.src_ports.start_port == 0)
			sprintf(arrayFvp[5].value, "%s", "*");
		else
			sprintf(arrayFvp[5].value, "%d", route.ROUTE.policy_route.src_ports.start_port);

		if(route.ROUTE.policy_route.src_ports.end_port == 0)
			sprintf(arrayFvp[6].value, "%s", "*");
		else
			sprintf(arrayFvp[6].value, "%d", route.ROUTE.policy_route.src_ports.end_port);

		if(!inet_ntoa(route.ROUTE.policy_route.ip_dst.ip) || !strcmp((char8 *)inet_ntoa(route.ROUTE.policy_route.ip_dst.ip), "0.0.0.0"))
			sprintf(arrayFvp[7].value, "%s", "*");
		else
			sprintf(arrayFvp[7].value, "%s", (char8 *)inet_ntoa(route.ROUTE.policy_route.ip_dst.ip));

		if(!inet_ntoa(route.ROUTE.policy_route.ip_dst.mask) || !strcmp((char8 *)inet_ntoa(route.ROUTE.policy_route.ip_dst.mask), "0.0.0.0"))
			sprintf(arrayFvp[8].value, "%s", "*");
		else
			sprintf(arrayFvp[8].value, "%s", (char8 *)inet_ntoa(route.ROUTE.policy_route.ip_dst.mask));

		if(route.ROUTE.policy_route.dst_ports.start_port == 0)
			sprintf(arrayFvp[9].value, "%s", "*");
		else
			sprintf(arrayFvp[9].value, "%d", route.ROUTE.policy_route.dst_ports.start_port);

		if(route.ROUTE.policy_route.dst_ports.end_port == 0)
			sprintf(arrayFvp[10].value, "%s", "*");
		else
			sprintf(arrayFvp[10].value, "%d", route.ROUTE.policy_route.dst_ports.end_port);

		sprintf(arrayFvp[11].value, "%s", (char8 *)inet_ntoa(route.ROUTE.policy_route.gw));

		if(strlen(route.ROUTE.policy_route.route_if))
			sprintf(arrayFvp[12].value, "%s", route.ROUTE.policy_route.route_if);
		else
			sprintf(arrayFvp[12].value, "%s", "*");

		if(route.ROUTE.policy_route.rt_protocol == 0)
			sprintf(arrayFvp[13].value, "%s", "*");
		else
			sprintf(arrayFvp[13].value, "%d", route.ROUTE.policy_route.rt_protocol);

		if(route.ROUTE.policy_route.tos == 0)
			sprintf(arrayFvp[14].value, "%s", "*");
		else
			sprintf(arrayFvp[14].value, "%d", route.ROUTE.policy_route.tos);

		/* Determine the Route Type based on the IP address or Netmask */
		if(route.ROUTE.policy_route.type == 0) {
			if(!strcmp((char8 *)inet_ntoa(route.ROUTE.policy_route.ip_dst.mask), "255.255.255.255"))
					route.ROUTE.policy_route.type = ROUTE_TYPE_HOST;
			else if(!strcmp((char8 *)inet_ntoa(route.ROUTE.policy_route.ip_dst.mask), "0.0.0.0"))
				route.ROUTE.policy_route.type = ROUTE_TYPE_DEFAULT;
			else
				route.ROUTE.policy_route.type = ROUTE_TYPE_NET;
		}

		ifx_fill_ArrayFvp_intValues(arrayFvp, 15, 4, &route.ROUTE.policy_route.metric, &route.ROUTE.policy_route.f_enable, &route.ROUTE.policy_route.mtuSize, &route.ROUTE.policy_route.type);
	}
	else { /* Static Route */
		sprintf(arrayFvp[0].value, "%d", route.ROUTE.route.iid.cpeId.Id);
		sprintf(arrayFvp[1].value, "%d", route.ROUTE.route.iid.pcpeId.Id);
		sprintf(arrayFvp[2].value, "%d", 0);

		ifx_fill_ArrayFvp_strValues(arrayFvp, 3, 12, "*", "*", "*", "*", dstIp, dstMask, "*", "*", gw_addr, route.ROUTE.route.route_if, "*", "*");

		sprintf(arrayFvp[15].value, "%d", route.ROUTE.route.metric);
		sprintf(arrayFvp[16].value, "%d", route.ROUTE.route.f_enable);
		sprintf(arrayFvp[17].value, "%s", "*");
		/* Determine the Route Type based on the IP address or Netmask */
		if(route.ROUTE.route.type == 0) {
			if(!strcmp((char8 *)inet_ntoa(route.ROUTE.route.ip_dst.mask), "255.255.255.255"))
				route.ROUTE.route.type = ROUTE_TYPE_HOST;
			else if(!strcmp((char8 *)inet_ntoa(route.ROUTE.route.ip_dst.mask), "0.0.0.0"))
				route.ROUTE.route.type = ROUTE_TYPE_DEFAULT;
			else
				route.ROUTE.route.type = ROUTE_TYPE_NET;
		}
		sprintf(arrayFvp[18].value, "%d", route.ROUTE.route.type);
	}
	*route_count = 19;
	return IFX_SUCCESS;
}


/* Support for input interface (ingress interface) still not supported in this api */
int32 ifx_set_policy_route(int32 operation, POLICY_ROUTE *route, uint32 flags)
{
	char8	sbuf[MAX_FILELINE_LEN];
	int		count = 0, changed_count = 0;
	int		ret = IFX_SUCCESS, passed_index = -1;
	IFX_ID	iid;
    IFX_NAME_VALUE_PAIR  array_fvp[20];
    IFX_NAME_VALUE_PAIR  *array_changed_fvp = NULL;
	ANY_ROUTE_ENTRY route_entry;
	char8	conf_buf[MAX_DATA_LEN], sCommand[MAX_FILELINE_LEN];

	NULL_TERMINATE(sbuf, 0x00, sizeof(sbuf));
	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	memset(&route_entry, 0x00, sizeof(route_entry));
	memset(array_fvp, 0x00, sizeof(array_fvp));
	memset(&iid, 0x00, sizeof(iid));

	/*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY) 
	 * append the flag with internal flags */
	if (operation == IFX_OP_DEL) 
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if( (IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	}
	else
		flags |= IFX_F_MODIFY;


	/**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(route)
		/* Do simple validation of flags sucha as less than 0 */
		IFX_VALIDATE_FLAGS(flags)
		/* Check if netmask or ip address is null */
		IFX_VALIDATE_POLICY_ROUTE_ENTRY(route, flags)
	}


	/**************** ID Allocation Block - Only for ADD Operation **************/
	sprintf(route->iid.cpeId.secName, "%s", TAG_ROUTING);
	sprintf(route->iid.pcpeId.secName, "%s", TAG_DEFAULT_WAN);
	route->iid.pcpeId.Id = 1;

	/* subnet mask should come from the adaptation ??
	determine the subnet mask if its 0.0.0.0 in which case route type should be specified
	if(!strcmp((char8 *)inet_ntoa(route->ip_dst.mask), "0.0.0.0")) {
		if(route->type == 0) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		switch(route->type) {
			case ROUTE_TYPE_DEFAULT:
						route->ip_dst.mask.s_addr = inet_addr("0.0.0.0");
						break;
			case ROUTE_TYPE_NET:
						route->ip_dst.mask.s_addr = inet_addr("");
						break;
			case ROUTE_TYPE_HOST:
						route->ip_dst.mask.s_addr = inet_addr("255.255.255.255");
						break;
		}
	}
	 */

	if (IFX_ADD_F_SET(flags)) {
		/* Allocate the IID for this route instance
		 * Set the parent SectionName and parent IID values 
		 * to NULL as there is no parent for Route Entity 
		 */
		if(ifx_get_IID(&route->iid, "srcIp") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
    } 

	/* Fill in the CPEID for MODIFY Operation */
	if(IFX_MODIFY_F_SET(flags) || IFX_DELETE_F_SET(flags)) {
		iid = route->iid;
		sprintf(route->iid.cpeId.secName, "%s", TAG_ROUTING);
	}


	/**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY
	 * Operations 
	 */
	if(IFX_DELETE_F_NOT_SET(flags)) {
		route_entry.f_policy_route = '1';
		memcpy(&route_entry.ROUTE.policy_route, route, sizeof(POLICY_ROUTE));
		ifx_form_route_fvp(operation, route_entry, flags, array_fvp, &count);
		passed_index = -1;
	}
	else {
		count = 19;
	}

	/* Get Config Index in case of modify/delete operations from CPEID */
	if((IFX_MODIFY_F_SET(flags)) ||
		(IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, route->iid.cpeId, passed_index)
	}

	/* Determine the configuration index - for Add, Delete, Modify operations 
     * Name is partial since index is not known 
     * Fill array_fvp[] */
	if(ifx_get_conf_index_and_nv_pairs(&route->iid, passed_index, PREFIX_ROUTING, 
				count, array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
	}


	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	if(IFX_ADD_F_NOT_SET(flags)) {
		CHECK_ACL_RET(route->iid, count, array_fvp,
						changed_count, array_changed_fvp, flags, IFX_Handler)
	}


	/* Stop the service on this index for Modify operation */
	if(IFX_MODIFY_F_SET(flags) || IFX_DELETE_F_SET(flags)) {
		/* Get the index for this route entry in order to call the script */
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, route->iid.cpeId, passed_index)
		sprintf(sCommand, "%s %d", SERVICE_POLICY_ROUTING_STOP, passed_index);
		if(system(sCommand))
			ret = IFX_SUCCESS;
	}
	

	/************** System Config File Update Block ****************/
	/* Backup rc.conf before proceeding with configuration */
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_ROUTING, flags, 1, conf_buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* this will Compact the section and also update the count for both ADD and DELETE */
	if(IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_ROUTING, flags);


	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* System call to Add/Delete/Modify Route */
	if(IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		if(IFX_ADD_F_SET(flags) || IFX_MODIFY_F_SET(flags)) {
			IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, route->iid.cpeId, passed_index)
			sprintf(sCommand, "%s %d", SERVICE_POLICY_ROUTING_START, passed_index);
			if(system(sCommand))
				ret = IFX_SUCCESS;
		}
	} // IFX_DONT_ACTIVATE_F_NOT_SET


	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if(IFX_MODIFY_F_SET(flags))
		CHECK_N_SEND_NOTIFICATION(route->iid, changed_count, array_changed_fvp, flags, IFX_Handler)

	else if (IFX_INT_ADD_F_SET(flags)) {
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
		UPDATE_ID_MAP_N_ATTRIBUTES(&route->iid, count, array_fvp, flags, IFX_Handler)

		CHECK_N_SEND_NOTIFICATION(route->iid, count, array_fvp, flags, IFX_Handler)

		/* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_ROUTING);
	}
	else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
		CHECK_N_SEND_NOTIFICATION(route->iid, count, array_fvp, flags, IFX_Handler)

		UPDATE_ID_MAP_N_ATTRIBUTES(&route->iid, count, array_fvp, flags, IFX_Handler)
	}


	/*********** Epilog Block **************/
	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}


IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_static_route(...)
*		operation	==>   the operation to be performed for this route entry, can be ADD, DELETE or MODIFY
*    	entry		==>   pointer to ROUTE_ENTRY structure that has the route details
*    	flags		==>   flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			The API will either ADD, DELETE or MODIFY a route entry. It takes the route details such as 
			destination ip address, netmask, interface ....	from the ROUTE_ENTRY structure and either
			adds, deletes or modifies this route based on the value of operation paramter.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_static_route(int32 operation, ROUTE_ENTRY *entry, uint32 flags)
{
	char8	sbuf[MAX_FILELINE_LEN];
	int		count = 0, changed_count = 0;
	int		ret = IFX_SUCCESS, passed_index = -1;
	IFX_ID	iid;
    IFX_NAME_VALUE_PAIR  array_fvp[20];
    IFX_NAME_VALUE_PAIR  *array_changed_fvp = NULL;
	ANY_ROUTE_ENTRY route_entry;
	uint32	outflag = flags;
	char8	conf_buf[MAX_DATA_LEN], sCommand[MAX_FILELINE_LEN], sCommand1[MAX_FILELINE_LEN];
	char8	new_ip[MAX_IP_ADDR_LEN], new_mask[MAX_IP_ADDR_LEN], new_gw[MAX_IP_ADDR_LEN];
	char8	old_ip[MAX_IP_ADDR_LEN], old_mask[MAX_IP_ADDR_LEN], old_gw[MAX_IP_ADDR_LEN];
	char8	old_route_if[IFNAMSIZE], old_metric[MAX_NAME_SIZE];

    memset(sbuf,'\0', sizeof(sbuf));
    memset(conf_buf,'\0', sizeof(conf_buf));
    memset(sCommand,'\0', sizeof(sCommand));
    memset(sCommand1,'\0', sizeof(sCommand1));
    memset(new_ip,'\0', sizeof(new_ip));
    memset(new_mask,'\0', sizeof(new_mask));
    memset(new_gw,'\0', sizeof(new_gw));
    memset(old_ip,'\0', sizeof(old_ip));
    memset(old_mask,'\0', sizeof(old_mask));
    memset(old_gw,'\0', sizeof(old_gw));
    memset(old_route_if,'\0', sizeof(old_route_if));
    memset(old_metric,'\0', sizeof(old_metric));
	

	memset(&iid, 0x00, sizeof(iid));
    memset(array_fvp, 0, sizeof(array_fvp));
	memset(&route_entry, 0x00, sizeof(route_entry));

	/*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY) 
	 * append the flag with internal flags */
	if (operation == IFX_OP_DEL) 
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if( (IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	}
	else
		flags |= IFX_F_MODIFY;


	/**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(entry)
		/* Do simple validation of flags sucha as less than 0 */
		IFX_VALIDATE_FLAGS(flags)
		/* Check if netmask or ip address is null */
		IFX_VALIDATE_ROUTE_ENTRY(entry, flags)
		/* check for duplicate entry */
		IFX_VALIDATE_DUPLICATE_ROUTE_ENTRY(entry, flags)
	}


	/**************** ID Allocation Block - Only for ADD Operation **************/
	sprintf(entry->iid.cpeId.secName, "%s", TAG_ROUTING);
	sprintf(entry->iid.pcpeId.secName, "%s", TAG_DEFAULT_WAN);
	entry->iid.pcpeId.Id = 1;

	if (IFX_ADD_F_SET(flags)) {
		/* Allocate the IID for this route instance
		 * Set the parent SectionName and parent IID values 
		 * to NULL as there is no parent for Route Entity 
		 */
		if(ifx_get_IID(&entry->iid, "dstIp") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
    } 

	/* Fill in the CPEID for MODIFY Operation */
	if(IFX_MODIFY_F_SET(flags) || IFX_DELETE_F_SET(flags)) {
		iid = entry->iid;
		sprintf(entry->iid.cpeId.secName, "%s", TAG_ROUTING);
	}


	/**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY
	 * Operations 
	 */
	if(IFX_DELETE_F_NOT_SET(flags)) {

                if( entry->f_enable==1 && entry->ip_dst.mask.s_addr && ((entry->ip_dst.ip.s_addr & entry->ip_dst.mask.s_addr) != entry->ip_dst.ip.s_addr))
                {
#ifdef IFX_LOG_DEBUG
                        IFX_API_LOG("Invalid Ipaddress or mask!\n[%s] : returned failure!", __FUNCTION__);
#endif
                        ret = IFX_FAILURE;
                        goto IFX_Handler;
			
                }

		route_entry.f_policy_route = '0';
		memcpy(&route_entry.ROUTE.route, entry, sizeof(ROUTE_ENTRY));
		ifx_form_route_fvp(operation, route_entry, flags, array_fvp, &count);
		passed_index = -1;

		strlcpy(new_ip, array_fvp[7].value,sizeof(new_ip));
		strlcpy(new_mask, array_fvp[8].value,sizeof(new_mask));
		strlcpy(new_gw, array_fvp[11].value,sizeof(new_gw));
	}
	else {
		count = 19;
	}

	/* Get Config Index in case of modify/delete operations from CPEID */
	if((IFX_MODIFY_F_SET(flags)) ||
		(IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, entry->iid.cpeId, passed_index)
	}

	/* Determine the configuration index - for Add, Delete, Modify operations 
     * Name is partial since index is not known 
     * Fill array_fvp[] */
	if(ifx_get_conf_index_and_nv_pairs(&entry->iid, passed_index, PREFIX_ROUTING, 
				count, array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
	}

	/* Pramod : Dirty Hack !!
		for DELETE operation TR-069 will not send any parameters except IID
		but the API checks for fEnable parameter value while doing system configuration
		to fix this, for new we will copy fEnable from array_fvp (which is read from rc.conf)
	 */
	if(entry->iid.config_owner != IFX_WEB && IFX_DELETE_F_SET(flags)) {
		entry->f_enable = atoi(array_fvp[16].value);
	}

	/* Get the old ipaddress, netmask, gateway, metric and interface from RC.CONF */
	if(IFX_MODIFY_F_SET(flags) || IFX_DELETE_F_SET(flags)) {
		sprintf(sbuf, "%s_%d_dstIp", PREFIX_ROUTING, passed_index);
		if ((ret  = ifx_GetObjData(FILE_RC_CONF, TAG_ROUTING, sbuf, 
						IFX_F_GET_ANY, &outflag, old_ip)) != IFX_SUCCESS)    {
			goto IFX_Handler;
		}

		sprintf(sbuf, "%s_%d_dstMask", PREFIX_ROUTING, passed_index);
		if ((ret  = ifx_GetObjData(FILE_RC_CONF, TAG_ROUTING, sbuf, 
						IFX_F_GET_ANY, &outflag, old_mask)) != IFX_SUCCESS)    {
			goto IFX_Handler;
		}

		sprintf(sbuf, "%s_%d_gw", PREFIX_ROUTING, passed_index);
		if ((ret  = ifx_GetObjData(FILE_RC_CONF, TAG_ROUTING, sbuf, 
						IFX_F_GET_ANY, &outflag, old_gw)) != IFX_SUCCESS)    {
			goto IFX_Handler;
		}

		sprintf(sbuf, "%s_%d_routeIf", PREFIX_ROUTING, passed_index);
		if ((ret  = ifx_GetObjData(FILE_RC_CONF, TAG_ROUTING, sbuf, 
						IFX_F_GET_ANY, &outflag, old_route_if)) != IFX_SUCCESS)    {
			goto IFX_Handler;
		}

		sprintf(sbuf, "%s_%d_metric", PREFIX_ROUTING, passed_index);
		if ((ret  = ifx_GetObjData(FILE_RC_CONF, TAG_ROUTING, sbuf, 
						IFX_F_GET_ANY, &outflag, old_metric)) != IFX_SUCCESS)    {
			goto IFX_Handler;
		}
	}


	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	if(IFX_ADD_F_NOT_SET(flags)) {
		CHECK_ACL_RET(entry->iid, count, array_fvp,
						changed_count, array_changed_fvp, flags, IFX_Handler)
	}


	/************** System Config File Update Block ****************/
	/* Backup rc.conf before proceeding with configuration */
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_ROUTING, flags, 1, conf_buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* this will Compact the section and also update the count for both ADD and DELETE */
	if(IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_ROUTING, flags);


	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* System call to Add/Delete/Modify Route */
	if(IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		if(IFX_ADD_F_SET(flags)) {
			if(build_route_command(new_ip, new_mask, new_gw,
						entry->route_if, entry->metric, entry->type, sCommand, "add") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
		else if(IFX_DELETE_F_SET(flags)) {
			if(build_route_command(old_ip, old_mask, old_gw, 
						old_route_if, atoi(old_metric), entry->type, sCommand, "del") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] command to del [%s]", __FUNCTION__, __LINE__, sCommand);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
		else if(IFX_MODIFY_F_SET(flags)) {
			if(build_route_command(old_ip, old_mask, old_gw, 
					old_route_if, atoi(old_metric), entry->type, sCommand, "del") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}

			if(build_route_command(new_ip, new_mask, new_gw,
						entry->route_if, entry->metric, entry->type, sCommand1, "add") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}


		if ( ((IFX_DELETE_F_SET(flags) || IFX_ADD_F_SET(flags)) && entry->f_enable) 
				|| (IFX_MODIFY_F_SET(flags)) ) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			if(system(sCommand))
				ret = IFX_SUCCESS;
		}

		/* checks if ret is not IFX_SUCCESS then restores the rc.conf with CHKPOINT_FILE */
		if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		if(IFX_MODIFY_F_SET(flags)) {
			if(system(sCommand1))
				ret = IFX_SUCCESS;

			/* checks if ret is not IFX_SUCCESS then restores the rc.conf with CHKPOINT_FILE */
			if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}
		}
		/*  Route status has to be stored for each route in system_status file based on
			the	return value of the route command (for add, delete or modify).
			As of now its always putting UP for add, modify and DOWN for delete.

			Also this logic has to be put for policy route set api. Currently status get and set
			is not handled for policy routes
		 */
		if(IFX_ADD_F_SET(flags)) {
			sprintf(sCommand, "sh /etc/rc.d/rc.staticRoutes add %d", entry->iid.cpeId.Id);
		}
		else if(IFX_DELETE_F_SET(flags)) {
			sprintf(sCommand, "sh /etc/rc.d/rc.staticRoutes delete %d", entry->iid.cpeId.Id);
		}
		else if(IFX_MODIFY_F_SET(flags)) {
			sprintf(sCommand, "sh /etc/rc.d/rc.staticRoutes modify %d %d", entry->iid.cpeId.Id, entry->iid.cpeId.Id);
		}


		if(system(sCommand))
			ret = IFX_SUCCESS;

		/* checks if ret is not IFX_SUCCESS then restores the rc.conf with CHKPOINT_FILE */
		if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

	} // IFX_DONT_ACTIVATE_F_NOT_SET


	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if(IFX_MODIFY_F_SET(flags))
		CHECK_N_SEND_NOTIFICATION(entry->iid, changed_count, array_changed_fvp, flags, IFX_Handler)

	else if (IFX_INT_ADD_F_SET(flags)) {
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
		UPDATE_ID_MAP_N_ATTRIBUTES(&entry->iid, count, array_fvp, flags, IFX_Handler)

		CHECK_N_SEND_NOTIFICATION(entry->iid, count, array_fvp, flags, IFX_Handler)

		/* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_ROUTING);
	}
	else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
		CHECK_N_SEND_NOTIFICATION(entry->iid, count, array_fvp, flags, IFX_Handler)

		UPDATE_ID_MAP_N_ATTRIBUTES(&entry->iid, count, array_fvp, flags, IFX_Handler)
	}


	/*********** Epilog Block **************/
	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}


IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_rip(...)
*		cfg			==> 	pointer to RIP_CFG which will store the rip configuration values 
*    	flags		==>   flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			The api will modify the existing RIP configuration parameters with the new
			values specified in the structure pointer
*//////////////////////////////////////////////////////////////////////////////
#ifdef CONFIG_FEATURE_RIP
int32 ifx_set_rip(RIP_CFG *cfg, uint32 flags)
{
	int		count = 0, ret = IFX_SUCCESS;
	uint32	outflag = IFX_F_DEFAULT;
	char8	buf[MAX_FILELINE_LEN], sCommand[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	char8	sSupplyMode[MAX_FILELINE_LEN], sListenMode[MAX_FILELINE_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[6], *array_changed_fvp = NULL;


    NULL_TERMINATE(buf, 0, sizeof(buf));
    NULL_TERMINATE(sCommand, 0, sizeof(sCommand));
    NULL_TERMINATE(sSupplyMode, 0, sizeof(sSupplyMode));
    NULL_TERMINATE(sListenMode, 0, sizeof(sListenMode));
    memset(array_fvp, 0, sizeof(array_fvp));
	

	/**************** Prolog Block ****************/
	/* Based on operation (ADD or DEL or MOD) 
	append the flag with internal flags */
	flags |= IFX_F_MODIFY;


    /************* Validation Block ***************/
	if(IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(cfg)
		/* Do simple validation of flags sucha as less than 0 */
		IFX_VALIDATE_FLAGS(flags)
	}


	/* Read the iid structure from rc.conf */
	if (ifx_get_iid_from_conf(&cfg->iid, FILE_RC_CONF, TAG_ROUTE_DYNAMIC) != IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}


	/*********** Name Value Formation As Per RC.CONF ****************/
	/* Build the API Specific name value pair */
	ifx_fill_ArrayFvp_FName(array_fvp, 0, 5, rip_param_names);

	ifx_fill_ArrayFvp_intValues(array_fvp, 0, 5, (int32 *)&cfg->iid.cpeId.Id, &cfg->iid.pcpeId.Id, &cfg->f_enable,
										&cfg->supply_mode, &cfg->listen_mode);

	count = 5;
	
	/* Currently ACL Checking has issues - so ignore this check for time being */
#if 0
	/**************** ACL Checking Block *****************/
	CHECK_ACL_RET(cfg->iid, count, array_fvp,
		changed_fcount, array_changed_fvp, flags, IFX_Handler)
#endif

	/********* System Config File Update Block  **********/
	/* Stop the ripd with the current configuration before modification of rc.conf */
	sprintf(buf, "%s", "route_dynamic_fEnable");
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_ROUTE_DYNAMIC, 
			buf, IFX_F_GET_ENA, &outflag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	if (atoi(sValue) == IFX_ENABLED) {
		system(SERVICE_RIPD_STOP);
	}

	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	/* Common part for both modes - enable and disable */
	form_cfgdb_buf(buf, count, array_fvp);

	/* Backup rc.conf before proceeding with configuration */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_ROUTE_DYNAMIC, flags, 1, buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* Now RIP Configuration creation is taken up from script - create_rip_config */
#if 0
	/* Determine which version of ripd config file has to be copied to ripd.conf based on supply mode */
	if( cfg->f_enable == IFX_ENABLED ) {  //Enable
		switch (cfg->supply_mode) {
			case RIP1:
				sprintf(sCommand, "%s", "cat /ramdisk_copy/etc/ripd.v1.conf > /etc/ripd.conf 2> /tmp/cmd_errors");
				sprintf(sSupplyMode, "%s", "ip rip send version 1\n");
				break;

			case RIP2:
				sprintf(sCommand, "%s", "cat /ramdisk_copy/etc/ripd.v2.conf > /etc/ripd.conf 2> /tmp/cmd_errors");
				sprintf(sSupplyMode, "%s", "ip rip send version 2\n");
				break;

			case RIP1_RIP2:
				sprintf(sCommand, "%s", "cat /ramdisk_copy/etc/ripd.v2.conf > /etc/ripd.conf 2> /tmp/cmd_errors");
				sprintf(sSupplyMode, "%s", "ip rip send version 1 2\n");
				break;

			default:
				sprintf(sCommand, "%s", "cat /ramdisk_copy/etc/ripd.v2.conf > /etc/ripd.conf 2> /tmp/cmd_errors");
				sprintf(sSupplyMode, "%s", "#ip rip send version 1 2\n");
				break;
		}

		/* determine the listen mode */
		switch (cfg->listen_mode) {
			case RIP1:
				sprintf(sListenMode, "%s", "ip rip receive version 1\n");
				break;
			case RIP2:
				sprintf(sListenMode, "%s", "ip rip receive version 2\n");
				break;
			case RIP1_RIP2:
				sprintf(sListenMode, "%s", "ip rip receive version 1 2\n");
				break;
			default:
				sprintf(sListenMode, "%s", "#ip rip receive version 1 2\n");
				break;
		}

		/* Copy the required version of ripd configuration file to ripd.conf */
		if(system(sCommand))
			ret = IFX_SUCCESS;

		/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
		if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		/* Check if ret is not IFX_SUCCESS then restore the rc.conf with CHKPOINT_FILE */
		if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		/* Update the listen and supply mode in the new ripd.conf file */
		ret = ifx_SetObjData(FILE_RIPD_CONF, TAG_ROUTE_DYNAMIC, flags, 2, sSupplyMode, sListenMode);

		if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
		}

		/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
		if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
	}

#endif 

	/************ Device Configuration Block ***********/
	if (IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		if(cfg->f_enable == IFX_ENABLED) {
			/* Start the ripd with the new configuration */
			//if(system(SERVICE_RIPD_START))
			system(SERVICE_RIPD_START);
				// ret = IFX_FAILURE;
				ret = IFX_SUCCESS;

			/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
			if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}

			/* Check if ret is not IFX_SUCCESS then restore the rc.conf with CHKPOINT_FILE,
			 * stop the services and start the services with CHKPOINT_FILE */
			if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}
		}
	} // IFX_DONT_ACTIVATE_F_NOT_SET


	/**************** Notification Block ******************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
#ifdef RIP_SUPPORTED_BY_TR69
	if(IFX_ADD_F_NOT_SET(flags) && IFX_DELETE_F_NOT_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION (cfg->iid, changed_fcount, array_changed_fvp, flags, IFX_Handler)
	}
#endif // RIP_SUPPORTED_BY_TR69


	/***************** Epilog Block **********************/
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}


IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}


/* This function sets the WAN interface Rx Route Protocol
 * based on the Global RIP Listen Status on the Router
 * We assume that the Route Rx Protocol is set to RIPv2 if
 * the Global Listen Mode is set to RIPv1 & RIPv2 Modes 
 */
int32 ifx_set_wanif_route_proto(int wan_Idx, WAN_COMMON_CFG *wan_common_cfg)
{
	int ret = IFX_SUCCESS;
	uint32	outflag = IFX_F_DEFAULT;
	char8	buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	memset(buf, 0, sizeof(buf));
	memset(sValue, 0, sizeof(sValue));

	/* Check if the Global RIP is enabled */
	sprintf(buf, "%s", "route_dynamic_fEnable");
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_ROUTE_DYNAMIC,
					buf, IFX_F_GET_ENA, &outflag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* If disabled then Set Rx protocol to OFF */
	if (atoi(sValue) == IFX_DISABLED) {
		wan_common_cfg->route_rx = ROUTE_PROTO_RX_OFF;
	}
	else {
		/* Set the Rx Route Protocol Mode to the
		 * Global Listen Mode. If Listen Mode is
		 * both RIPv1 and RIPv2, then set the Rx Proto
		 * on the interface to RIPv2 */
		memset(buf, 0, sizeof(buf));
		memset(sValue, 0, sizeof(sValue));
		sprintf(buf, "%s", "route_dynamic_listenMode");
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_ROUTE_DYNAMIC,
						buf, IFX_F_GET_ENA, &outflag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		if ((atoi(sValue) == RIP1_RIP2) || (atoi(sValue) == RIP2))
			wan_common_cfg->route_rx = ROUTE_PROTO_RX_RIP_V2;
		else if (atoi(sValue) == RIP1)
			wan_common_cfg->route_rx = ROUTE_PROTO_RX_RIP_V1;
		else
			wan_common_cfg->route_rx = ROUTE_PROTO_RX_OFF;
	}

IFX_Handler:
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}

#endif

/* GET APIs */


/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_all_policy_route_entries(...)
*    	num_entries	==>  outut number of policy routes
*    	route_entries	==>  output pointer to an array of policy routes
*	flags		==>  
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This Function reads the policy routes in rc.conf file, 
			and stores eah route in the array route_entries. This 
			also determines the status of each policy route by
			reading the status from running config file.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_all_policy_route_entries(int32 *num_routes, POLICY_ROUTE **route_entries, uint32 flags)
{
	int32   nCount=0, nIndex=0;
	int32	ret = IFX_SUCCESS, routes_count = 0, count = 0;
	uint32	outFlag = IFX_F_DEFAULT;
	char8	*sValue = NULL;
	char8	sIP[MAX_IP_ADDR_LEN], sNetmask[MAX_IP_ADDR_LEN], sGateway[MAX_IP_ADDR_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[19];
	char8 	sCommand[MAX_FILELINE_LEN];
	char8	sBuf[MAX_FILELINE_LEN];
	POLICY_ROUTE *t_ptr = NULL;

	NULL_TERMINATE(sIP, 0x00, sizeof(sIP));
	NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
	NULL_TERMINATE(sNetmask, 0x00, sizeof(sNetmask));
	NULL_TERMINATE(sGateway, 0x00, sizeof(sGateway));
	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));

	MAKE_SECTION_COUNT_TAG(TAG_ROUTING, sCommand);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_ROUTING, 
							sCommand, flags, &outFlag, sBuf)) != IFX_SUCCESS)	{
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
	}

	nCount = atoi(sBuf);
	if (nCount < 1 || nCount > 32767) {
			*num_routes = 0;
			*route_entries = NULL;
			goto IFX_Handler;
	}
	*route_entries = NULL;

		t_ptr = (POLICY_ROUTE *)IFX_MALLOC(nCount * sizeof(POLICY_ROUTE));

			if(t_ptr == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}

			*route_entries = t_ptr;


	for (nIndex=0; nIndex < nCount; nIndex++)	{
	
	/* initialize the cache for this instance */
	sprintf(sBuf, "%s_%d_", PREFIX_ROUTING, nIndex);
	if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ROUTING, sBuf, IFX_F_INT_CACHE_INIT | flags, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

		/* get each of the route instance from the rc.conf file and convert
		 * it to field value pair array to copy to output array of static routes */
		sprintf(sBuf, "%s_%d_", PREFIX_ROUTING, nIndex);
		if((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_ROUTING, sBuf, flags, &sValue)) != IFX_SUCCESS) {
			if(ret == IFX_E_UNMATCHED_INPUT) {
				continue;
			}
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		memset(array_fvp, 0x00, sizeof(array_fvp));
		form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);
		
		/* copy the route read into the structure */
		if(atoi(array_fvp[2].value) == 1) {
	/*
			t_ptr = (POLICY_ROUTE *)realloc(*route_entries, 
									(routes_count + 1) * sizeof(POLICY_ROUTE));

			if(t_ptr == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}

			*route_entries = t_ptr;

			// ZERO the realloced buffer 
			memset((*route_entries + routes_count), 0x00, sizeof(POLICY_ROUTE));
	*/
			(*route_entries + routes_count)->iid.cpeId.Id = atoi(array_fvp[0].value);
			(*route_entries + routes_count)->iid.pcpeId.Id = atoi(array_fvp[1].value);

			if(!IS_WILD_CARD(array_fvp[3].value))
					(*route_entries + routes_count)->ip_src.ip.s_addr = inet_addr(array_fvp[3].value);

			if(!IS_WILD_CARD(array_fvp[4].value))
					(*route_entries + routes_count)->ip_src.mask.s_addr = inet_addr(array_fvp[4].value);

			if(!IS_WILD_CARD(array_fvp[5].value))
					(*route_entries + routes_count)->src_ports.start_port = atoi(array_fvp[5].value);

			if(!IS_WILD_CARD(array_fvp[6].value))
					(*route_entries + routes_count)->src_ports.end_port = atoi(array_fvp[6].value);

			if(!IS_WILD_CARD(array_fvp[7].value))
					(*route_entries + routes_count)->ip_dst.ip.s_addr = inet_addr(array_fvp[7].value);

			if(!IS_WILD_CARD(array_fvp[8].value))
					(*route_entries + routes_count)->ip_dst.mask.s_addr = inet_addr(array_fvp[8].value);

			if(!IS_WILD_CARD(array_fvp[9].value))
					(*route_entries + routes_count)->dst_ports.start_port = atoi(array_fvp[9].value);

			if(!IS_WILD_CARD(array_fvp[10].value))
					(*route_entries + routes_count)->dst_ports.end_port = atoi(array_fvp[10].value);

			(*route_entries + routes_count)->gw.s_addr = inet_addr(array_fvp[11].value);
			snprintf((*route_entries + routes_count)->route_if,IFNAMSIZE,"%s", array_fvp[12].value);

			if(!IS_WILD_CARD(array_fvp[13].value))
					(*route_entries + routes_count)->rt_protocol = atoi(array_fvp[13].value);

			if(!IS_WILD_CARD(array_fvp[14].value))
					(*route_entries + routes_count)->tos = atoi(array_fvp[14].value);

			(*route_entries + routes_count)->metric = atoi(array_fvp[15].value);
			(*route_entries + routes_count)->f_enable = atoi(array_fvp[16].value);
			(*route_entries + routes_count)->mtuSize = atoi(array_fvp[17].value);
			(*route_entries + routes_count)->type = atoi(array_fvp[18].value);
			if((*route_entries + routes_count)->f_enable == 0)
					(*route_entries+routes_count)->status = ROUTE_STATUS_DISABLED;
			else {
			}
			routes_count++;
		}
		IFX_MEM_FREE(sValue)

	/* initialize the cache for this instance */
	sprintf(sBuf, "%s_%d_", PREFIX_ROUTING, nIndex);
	if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ROUTING, sBuf, IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	}
	*num_routes = routes_count;

IFX_Handler:
	if(ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*route_entries)
		*num_routes = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;

}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_all_static_route_entries(...)
*    	num_entries	==>  outut number of static routes
*    	route_entries	==>  output pointer to an array of static routes
*	flags		==>  
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This Function reads the static routes in rc.conf file, 
			and stores eah route in the array route_entries. This 
			also determines the status of each static route by
			reading the status from running config file.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_all_static_route_entries(int32 *num_routes, ROUTE_ENTRY **route_entries, uint32 flags)
{
	// FILE	*fd = NULL;
	int     nCount=0, nIndex=0;
	int		ret = IFX_SUCCESS, routes_count = 0, count = 0;
	uint32	outFlag = IFX_F_DEFAULT;
	char  *sValue = NULL, temp_buf[MAX_NAME_SIZE];
	char8	sIP[MAX_IP_ADDR_LEN], sNetmask[MAX_IP_ADDR_LEN], sGateway[MAX_IP_ADDR_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[19];
	char8 	sCommand[MAX_FILELINE_LEN];
	char8 sBuf[MAX_FILELINE_LEN];
	ROUTE_ENTRY *t_ptr = NULL;

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(sIP, 0x00, sizeof(sIP));
	NULL_TERMINATE(sNetmask, 0x00, sizeof(sNetmask));
	NULL_TERMINATE(sGateway, 0x00, sizeof(sGateway));
	NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

	/* first, get the number of static routes from rc.conf */
	MAKE_SECTION_COUNT_TAG(TAG_ROUTING, sCommand);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_ROUTING, 
							sCommand, flags, &outFlag, sBuf)) != IFX_SUCCESS)	{
			goto IFX_Handler;
	}

	nCount = atoi(sBuf);
	if (nCount < 1 || nCount > 32767) {
			*num_routes = 0;
			*route_entries = NULL;
			goto IFX_Handler;
	}
	*route_entries = NULL;
	t_ptr = (ROUTE_ENTRY *)IFX_MALLOC(nCount * sizeof(ROUTE_ENTRY));

	            if(t_ptr == NULL) {
    	            ret = IFX_FAILURE;
        	        goto IFX_Handler;
            	}

	            *route_entries = t_ptr;

	for (nIndex=0; nIndex < nCount; nIndex++)	{
	
	/* initialize the cache for this instance */
	sprintf(sBuf, "%s_%d_", PREFIX_ROUTING, nIndex);
	if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ROUTING, sBuf, IFX_F_INT_CACHE_INIT | flags, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

		/* get each of the route instance from the rc.conf file and convert
		 * it to field value pair array to copy to output array of static routes */
		sprintf(sBuf, "%s_%d_", PREFIX_ROUTING, nIndex);
		if((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_ROUTING, sBuf, flags, &sValue)) != IFX_SUCCESS) {
			if(ret == IFX_E_UNMATCHED_INPUT) {
				continue;
			}
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		memset(array_fvp, 0x00, sizeof(array_fvp));
		form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);
		
		if(atoi(array_fvp[2].value) == 0) {
	/*	
			t_ptr = (ROUTE_ENTRY *)realloc(*route_entries, 
										(routes_count + 1) * sizeof(ROUTE_ENTRY));

	            if(t_ptr == NULL) {
    	            ret = IFX_FAILURE;
        	        goto IFX_Handler;
            	}

	            *route_entries = t_ptr;

				// ZERO the realloced buffer
				memset((*route_entries + routes_count), 0x00, sizeof(ROUTE_ENTRY));
	*/
				/* copy the route read into the structure */
				(*route_entries + routes_count)->iid.cpeId.Id = atoi(array_fvp[0].value);
				(*route_entries + routes_count)->iid.pcpeId.Id = atoi(array_fvp[1].value);
				(*route_entries + routes_count)->ip_dst.ip.s_addr = inet_addr(array_fvp[7].value);
				(*route_entries + routes_count)->ip_dst.mask.s_addr = inet_addr(array_fvp[8].value);
				(*route_entries + routes_count)->gw.s_addr = inet_addr(array_fvp[11].value);
				snprintf((*route_entries + routes_count)->route_if,IFNAMSIZE,"%s", array_fvp[12].value);
				(*route_entries + routes_count)->metric = atoi(array_fvp[15].value);
				(*route_entries + routes_count)->f_enable = atoi(array_fvp[16].value);
				(*route_entries + routes_count)->type = atoi(array_fvp[18].value);
				if((*route_entries + routes_count)->f_enable == 0)
						(*route_entries+routes_count)->status = ROUTE_STATUS_DISABLED;
				else  {
					memset(temp_buf, 0x00, sizeof(temp_buf));
                    /* Search this route on cpeId in the running config file */
                    sprintf(sBuf, "route_%d_status", (*route_entries + routes_count)->iid.cpeId.Id);
					sprintf(sCommand, "route_%d", (*route_entries + routes_count)->iid.cpeId.Id);
                    /* In case the file doesn't exist or entry missing just have
                     * the route status as ERROR */
					if(ifx_GetObjData(FILE_SYSTEM_STATUS, sCommand, sBuf, flags, NULL, temp_buf) != IFX_SUCCESS) {
						(*route_entries+routes_count)->status = ROUTE_STATUS_ERROR;
						routes_count++;
						IFX_MEM_FREE(sValue)
						continue;
					}
					else {
					 	if(!strcmp(temp_buf, "DOWN"))
					 		/* If cpeId is not found in the file, status is Disabled */
					 		(*route_entries+routes_count)->status = ROUTE_STATUS_DISABLED;
					 	else if(!strcmp(temp_buf, "UP"))
					 		/* If cpeId is found in the file, status is Enabled */
					 		(*route_entries+routes_count)->status = ROUTE_STATUS_ENABLED;
					 	else
					 		(*route_entries+routes_count)->status = ROUTE_STATUS_ERROR;
					}
				}
				routes_count++;
		}
		IFX_MEM_FREE(sValue)

	/* initialize the cache for this instance */
	sprintf(sBuf, "%s_%d_", PREFIX_ROUTING, nIndex);
	if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ROUTING, sBuf, IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	}
	*num_routes = routes_count;

IFX_Handler:
	if(ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*route_entries)
		*num_routes = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
	
}



/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_sys_routes(...)
*    	num_entries	==>  outut number of routes configured in the kernel
*    	route_entries	==>  output pointer to an array of system routes
*	flags		==>  
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This Function reads the routes from the kernel (by executing route -n) 
			command and stores each route in the array route_entries.
			For each route the route type will also be determined. The routes include
			static routes, policy routes and dynamic routes.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_sys_routes(int32 *num_routes, ANY_ROUTE_ENTRY **route_entries, uint32 flags)
{
	char8 ip[32],buf[200],nm[32],gw[32],metric[16],ifname[16],buf1[16],buf2[16],buf3[16];
	int32 ret = IFX_SUCCESS;
	int32 i=0,num=0, ch;
	FILE *fp = NULL,*f = NULL;

	f = popen("route -n","r");
	if(f == NULL) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* get the number of routes from route -n command as the number of newline characters */
	while((ch = fgetc(f))!=EOF)	{
		if(ch == '\n')	{
			num++;
		}
	}
	pclose(f);

	num = num-2;	
	*num_routes = num;

	/* allocate memory for the array route_entries for num routes */
	IFX_MEM_ALLOC((*route_entries), ANY_ROUTE_ENTRY *, num, sizeof(ANY_ROUTE_ENTRY))

	fp = popen("route -n","r");
	if (fp == NULL) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	/* skip first line --> Kernel IP routing table */
	fgets(buf,200,fp);
	/* skip second line ---> Destination Gateway Genmask Flags Metric Ref Use Iface */
	fgets(buf,200,fp);

	/* read each of the route and copy it into the output array */
	for( i=0; i<num; i++)	{

		memset(ip,'\0',sizeof(ip));
		memset(nm,'\0',sizeof(nm));
		memset(gw,'\0',sizeof(gw));
		memset(metric,'\0',sizeof(metric));
		memset(ifname,'\0',sizeof(ifname));

		fscanf(fp,"%[^ ] %[^ ] %[^ ] %[^ ] %[^ ] %[^ ] %[^ ] %[^\n]\n",
						ip,gw,nm,buf1,metric,buf2,buf3,ifname);

		(*route_entries+i)->f_policy_route='0';
		(*route_entries+i)->ROUTE.route.ip_dst.ip.s_addr = inet_addr(ip);
		(*route_entries+i)->ROUTE.route.ip_dst.mask.s_addr = inet_addr(nm);
		(*route_entries+i)->ROUTE.route.gw.s_addr = inet_addr(gw);
		(*route_entries+i)->ROUTE.route.metric = atoi(metric);
		strlcpy((*route_entries+i)->ROUTE.route.route_if, ifname,IFNAMSIZE);
		(*route_entries+i)->ROUTE.route.status = ROUTE_STATUS_ENABLED;
		(*route_entries+i)->ROUTE.route.f_enable = 1;
		if(!strcmp(nm, "255.255.255.255"))
			(*route_entries+i)->ROUTE.route.type = ROUTE_TYPE_HOST;
		else if(!strcmp(ip, "0.0.0.0"))
			(*route_entries+i)->ROUTE.route.type = ROUTE_TYPE_DEFAULT;
		else
			(*route_entries+i)->ROUTE.route.type = ROUTE_TYPE_NET;
	}

IFX_Handler:
	if (fp)
		pclose(fp);
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_all_route_entries(...)
*    	num_entries	==>  outut number of routes configured in the kernel
*    	route_entries	==>  output pointer to an array of routes configured in the kernel
*	flags		==>  
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function returns all the routes configured in the system.
			The difference between this api and the previous one being that if the
			route read from the kernel is a static route then its status and type
			will be read from the running config file.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_all_route_entries(int32 *num_routes, ANY_ROUTE_ENTRY **route_entries, uint32 flags)
{
    int32		num = 0, tmp_routes = 0;
	int32		ret = IFX_SUCCESS, i = 0, static_idx = -1;
	char8		ip[MAX_IP_ADDR_LEN], mask[MAX_IP_ADDR_LEN], gw[MAX_IP_ADDR_LEN];
    ROUTE_ENTRY *st_routes = NULL;
	POLICY_ROUTE *pr_routes = NULL;
	ANY_ROUTE_ENTRY *sys_routes = NULL, *t_ptr = NULL;
	
	*num_routes = 0;

	/* Get all static routes */
    ret = ifx_get_all_static_route_entries(&num, &st_routes, flags);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}


	/* Copy all the Static Routes into the output array route_entries */
	if(num > 0) {
		IFX_MEM_ALLOC(*route_entries, ANY_ROUTE_ENTRY *, num, sizeof(ANY_ROUTE_ENTRY))

		for(i=0; i<num; i++) {
			(*route_entries + i)->f_policy_route = '0';
			(*route_entries + i)->ROUTE.route.iid.cpeId.Id = (st_routes + i)->iid.cpeId.Id;
			strncpy((*route_entries + i)->ROUTE.route.iid.cpeId.secName, TAG_ROUTING, strlen(TAG_ROUTING));
			(*route_entries + i)->ROUTE.route.iid.pcpeId.Id = (st_routes + i)->iid.pcpeId.Id;
			strncpy((*route_entries + i)->ROUTE.route.iid.pcpeId.secName, "l3f", strlen("l3f"));
			(*route_entries + i)->ROUTE.route.ip_dst.ip = (st_routes + i)->ip_dst.ip;
			(*route_entries + i)->ROUTE.route.ip_dst.mask = (st_routes + i)->ip_dst.mask;
			(*route_entries + i)->ROUTE.route.gw = (st_routes + i)->gw;
			(*route_entries + i)->ROUTE.route.metric = (st_routes + i)->metric;
			sprintf((*route_entries + i)->ROUTE.route.route_if, "%s", (st_routes + i)->route_if);
			(*route_entries + i)->ROUTE.route.f_enable = (st_routes + i)->f_enable;
			(*route_entries + i)->ROUTE.route.status = (st_routes + i)->status;
			(*route_entries + i)->ROUTE.route.type = (st_routes + i)->type;
		}
		tmp_routes = num;
	}


	t_ptr = NULL;
	/* Get all policy based routes */
	/* copy them to route_entries */
	num = 0;
    ret = ifx_get_all_policy_route_entries(&num, &pr_routes, flags);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* Copy all the Static Routes into the output array route_entries */
	if(num > 0) {
		t_ptr = (ANY_ROUTE_ENTRY *)realloc(*route_entries, (tmp_routes + num) * sizeof(ANY_ROUTE_ENTRY));

        if(t_ptr == NULL) {
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }

        *route_entries = t_ptr;

		/* ZERO the realloced buffer */
		memset((*route_entries + tmp_routes), 0x00, num * sizeof(ANY_ROUTE_ENTRY));

		for(i=0; i<num; i++) {
			(*route_entries + tmp_routes)->f_policy_route = '1';
			(*route_entries + tmp_routes)->ROUTE.policy_route.iid.cpeId.Id = (pr_routes + i)->iid.cpeId.Id;
			strncpy((*route_entries + tmp_routes)->ROUTE.policy_route.iid.cpeId.secName, TAG_ROUTING, strlen(TAG_ROUTING));
			(*route_entries + tmp_routes)->ROUTE.policy_route.iid.pcpeId.Id = (pr_routes + i)->iid.pcpeId.Id;
			strncpy((*route_entries + tmp_routes)->ROUTE.policy_route.iid.pcpeId.secName, "l3f", strlen("l3f"));
			(*route_entries + tmp_routes)->ROUTE.policy_route.ip_src.ip = (pr_routes + i)->ip_src.ip;
			(*route_entries + tmp_routes)->ROUTE.policy_route.ip_src.mask = (pr_routes + i)->ip_src.mask;
			(*route_entries + tmp_routes)->ROUTE.policy_route.src_ports = (pr_routes + i)->src_ports;
			(*route_entries + tmp_routes)->ROUTE.policy_route.ip_dst.ip = (pr_routes + i)->ip_dst.ip;
			(*route_entries + tmp_routes)->ROUTE.policy_route.ip_dst.mask = (pr_routes + i)->ip_dst.mask;
			(*route_entries + tmp_routes)->ROUTE.policy_route.dst_ports = (pr_routes + i)->dst_ports;
			(*route_entries + tmp_routes)->ROUTE.policy_route.gw = (pr_routes + i)->gw;
			(*route_entries + tmp_routes)->ROUTE.policy_route.rt_protocol = (pr_routes + i)->rt_protocol;
			(*route_entries + tmp_routes)->ROUTE.policy_route.tos = (pr_routes + i)->tos;
			sprintf((*route_entries + tmp_routes)->ROUTE.policy_route.route_if, "%s", (pr_routes + i)->route_if);
			(*route_entries + tmp_routes)->ROUTE.policy_route.metric = (pr_routes + i)->metric;
			(*route_entries + tmp_routes)->ROUTE.policy_route.f_enable = (pr_routes + i)->f_enable;
			(*route_entries + tmp_routes)->ROUTE.policy_route.type = (pr_routes + i)->type;
			(*route_entries + tmp_routes)->ROUTE.policy_route.mtuSize = (pr_routes + i)->mtuSize;
			(*route_entries + tmp_routes)->ROUTE.policy_route.status = (pr_routes + i)->status;
			tmp_routes++;
		}
	}

	/* Get all system routes */
	num = 0;
	ret = ifx_get_sys_routes(&num, &sys_routes, flags);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* Process for each system route */
	for(i=0; i<num; i++) {
		static_idx = -1;
		sprintf(ip, "%s", inet_ntoa((sys_routes + i)->ROUTE.route.ip_dst.ip));
		sprintf(mask, "%s", inet_ntoa((sys_routes + i)->ROUTE.route.ip_dst.mask));
		sprintf(gw, "%s", inet_ntoa((sys_routes + i)->ROUTE.route.gw));
		/* check if the combination of ip, mask and gw forms a static route which
		 * is already read from ifx_get_all_static_route_entries */
		static_idx = ifx_check_if_static_route(ip, mask, gw, *route_entries, tmp_routes);
#ifdef IFX_LOG_DEBUG
		IFX_DBG("static_idx is [%d]\n", static_idx);
#endif
		if(static_idx > -1) {
			/* this is a static route, so skip */
			/* before that copy the interface name from sys_route */
			sprintf((*route_entries + static_idx)->ROUTE.route.route_if, "%s", (sys_routes + i)->ROUTE.route.route_if);
#ifdef IFX_LOG_DEBUG
			IFX_DBG("copying ifname [%s]\n", (*route_entries + static_idx)->ROUTE.route.route_if);
#endif
			continue;
		}

		/* this is not a static route */
		/* copy this route to output array route_entries */
		t_ptr = (ANY_ROUTE_ENTRY *)realloc(*route_entries, (tmp_routes + 1) * sizeof(ANY_ROUTE_ENTRY));

        if(t_ptr == NULL) {
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }

        *route_entries = t_ptr;

		if(*route_entries == NULL) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			IFX_MEM_FREE(route_entries)
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		/* ZERO the realloced buffer */
		memset((*route_entries + tmp_routes), 0x00, sizeof(ANY_ROUTE_ENTRY));

		(*route_entries + tmp_routes)->f_policy_route = '0';
		(*route_entries + tmp_routes)->ROUTE.route.iid.cpeId.Id = 0;
		(*route_entries + tmp_routes)->ROUTE.route.iid.pcpeId.Id = 0;
		strncpy((*route_entries + tmp_routes)->ROUTE.route.iid.pcpeId.secName, "l3f", strlen("l3f"));
		(*route_entries + tmp_routes)->ROUTE.route.ip_dst.ip = (sys_routes + i)->ROUTE.route.ip_dst.ip;
		(*route_entries + tmp_routes)->ROUTE.route.ip_dst.mask = (sys_routes + i)->ROUTE.route.ip_dst.mask;
		(*route_entries + tmp_routes)->ROUTE.route.gw = (sys_routes + i)->ROUTE.route.gw;
		(*route_entries + tmp_routes)->ROUTE.route.metric = (sys_routes + i)->ROUTE.route.metric;
		sprintf((*route_entries + tmp_routes)->ROUTE.route.route_if, "%s", (sys_routes + i)->ROUTE.route.route_if);
		(*route_entries + tmp_routes)->ROUTE.route.f_enable = (sys_routes + i)->ROUTE.route.f_enable;
		(*route_entries + tmp_routes)->ROUTE.route.status = (sys_routes + i)->ROUTE.route.status;
		(*route_entries + tmp_routes)->ROUTE.route.type = (sys_routes + i)->ROUTE.route.type;

		tmp_routes++;
	} // for

	*num_routes = tmp_routes;

IFX_Handler:
	/* Static Routes */
	IFX_MEM_FREE(st_routes) 
	/* Dynamic Routes */
	IFX_MEM_FREE(sys_routes)
	/* Policy Routes */
	IFX_MEM_FREE(pr_routes)
	if(ret != IFX_SUCCESS) {
		*num_routes = 0;
		IFX_MEM_FREE(*route_entries)
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}



/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_rip_cfg(...)
*    	rip_cfg		==>  outut pointer to the structre RIP_CFG
*	flags		==>  
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads the rip configuration from rc.conf and returns
			as a pointer to the structre RIP_CFG.
*//////////////////////////////////////////////////////////////////////////////
#ifdef CONFIG_FEATURE_RIP
int32 ifx_get_rip_cfg(RIP_CFG *rip_cfg, uint32 flags)
{
	char8	sValue[MAX_FILELINE_LEN];
	int32	ret = IFX_SUCCESS;
	uint32	outFlag = IFX_F_DEFAULT;
	
	/* get the enable status of rip */
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_ROUTE_DYNAMIC, 
				"route_dynamic_fEnable", flags, &outFlag, sValue)) != IFX_SUCCESS)	{
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	else {

		if (atoi(sValue) == IFX_ENABLED)  { //Enable 
			rip_cfg->f_enable = IFX_ENABLED;
		}
		else if	(atoi(sValue) == IFX_DISABLED) {	//Disable
			rip_cfg->f_enable = IFX_DISABLED;
		}
		else {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	/* get the listen mode if rip */
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_ROUTE_DYNAMIC, 
					"route_dynamic_listenMode", flags, &outFlag, sValue)) != IFX_SUCCESS)	{
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	else {
		if (atoi(sValue) != None)
			rip_cfg->listen_mode = atoi(sValue);
		else if (atoi(sValue) == None)
			rip_cfg->listen_mode = None;
		else {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	/* get the supply mode if rip */
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_ROUTE_DYNAMIC, 
					"route_dynamic_supplyMode", flags, &outFlag, sValue)) != IFX_SUCCESS)	{
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	else {
		if (atoi(sValue) != None)
			rip_cfg->supply_mode = atoi(sValue);
		else if (atoi(sValue) == None)
			rip_cfg->supply_mode = None;
		else {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

IFX_Handler:
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}
#endif

