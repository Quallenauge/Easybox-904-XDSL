#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"
#include <unistd.h>
#if 0
#define IFX_LOG_DEBUG

#ifdef IFX_LOG_DEBUG
#ifndef IFX_DBG
	#define IFX_DBG(fmt, args...)	printf("(%s)" fmt, __func__, ##args)
#endif
#endif/*IFX_LOG_DEBUG*/
#define PRINTF IFX_DBG("----%d\n",__LINE__);
#endif

#ifdef CONFIG_FEATURE_SELECTIVE_BACKUP_RESTORE
#include <IFIN_Proto_API.h>

char8 * web_ui_backup_list[] =
{"LAN",
#ifdef CONFIG_FEATURE_IFX_WIRELESS
"WLAN", 
#endif
"ROUTING",
"TIME", 
"QOS",
"SYSTEM_LOG",
"FIREWALL"
};
#endif


#ifdef CONFIG_FEATURE_SELECTIVE_BACKUP_RESTORE
#ifdef CONFIG_PACKAGE_IFX_DEVM 
int ifx_RestoreTR69_Instances()
{
	char8 * pTR69_Inst_Buff = NULL;
	int32 RetValue = IFX_SUCCESS;
	if(IFX_SUCCESS == ifx_GetCfgObject(FILE_SYSCONF,"tr69_instances", NULL, IFX_F_GET_ANY, &pTR69_Inst_Buff))
   	{
		if(IFX_SUCCESS != IFX_UpdateTr69Instances(pTR69_Inst_Buff))
		{
			#ifdef IFX_LOG_DEBUG
            IFX_DBG("Error! Unable to update TR69 instance entries\n");
            #endif
            RetValue = IFX_FAILURE;
		}
	}
	IFX_MEM_FREE(pTR69_Inst_Buff);
	return RetValue;
}
/*****************************************************************************
* Function    : ifx_ModifyTR69Instances() 
* Description : This function finds the appropriate tr69_instances entry for
*				for a particular tr69_map entry and copies it to/deletes from
*				the file specified
* Parameters  : ptr69map_entry :- the tr69_map entry, pInstBuff :- the 
				buffer containing the tr69_instances entries to be searched,
*				iAction :- Add or delete, pFileName :- the file to be modified
*****************************************************************************/
int ifx_ModifyTR69Instances(char8 *ptr69map_entry, char8 *pInstBuff, int iAction, char8 *pFileName)
{
	char8 * ptr69inst_start,*ptr69inst_pos;
	char8 * ptr69inst_pos1 = NULL,* ptr69inst_pos2 = NULL;
	char8 ptr69inst_entry[MAX_FILELINE_LEN];
	char8 ptr69inst_entry_RHS[MAX_FILELINE_LEN];
	char8 ptr69inst_RHS[MAX_FILELINE_LEN], ptr69inst_TmpRHS[MAX_FILELINE_LEN];
	int RetValue = 0;
	char * pTmp1 = NULL, *pTmp2 = NULL;
	char lastnum[8] = {0};
	int getInstance = 0;

	//Parse entry to get RHS which will be TR69 ID.
	if(NULL != (ptr69inst_pos1 = strchr(ptr69map_entry,'=')))
	{
	    ptr69inst_pos1++;//at "
	    if(NULL != (ptr69inst_pos2 = strchr(ptr69map_entry,'\n')))
	    {
			strncpy(ptr69inst_TmpRHS, ptr69inst_pos1, (ptr69inst_pos2 - ptr69inst_pos1));
		}
		else
		{
			//Error
			RetValue = -1;
		    goto end;
		}
		//contains "to"
		ptr69inst_TmpRHS[(ptr69inst_pos2 - ptr69inst_pos1)] = '\0';

		//Go ahead only if last number is positive
		pTmp1 = strchr(ptr69inst_TmpRHS, '"');
		pTmp1++;
		pTmp1 = strchr(pTmp1, '"');
		if(pTmp1)
		{
			while(*(pTmp1) != '.')
				pTmp1--;						
						
			if(*pTmp1 == '.')
			{
	       		pTmp2 = pTmp1-1;
				while(*(pTmp2) != '.')
					pTmp2--;
				if(*pTmp2 == '.')
				{
					pTmp2++;
					strncpy(lastnum, pTmp2, (pTmp1 - pTmp2));
					lastnum[(pTmp1 - pTmp2)] = '\0';
					if (atoi(lastnum) > 0)
						getInstance = 1;
				}
			}
		}

		if(getInstance == 0)
		{
			RetValue = 0;
			goto end;
		}
		//Copy total TR69ID only into ptr69inst_RHS
		pTmp1 = strchr(ptr69inst_TmpRHS, '"');
		if(pTmp1)
		{
			pTmp1++;
        	pTmp2 = strchr(pTmp1, '"');
			if(pTmp2)
			{
				strncpy(ptr69inst_RHS, pTmp1, (pTmp2 - pTmp1));
                ptr69inst_RHS[(pTmp2 - pTmp1)] = '\0';
			}
			else
			{
				RetValue = -1;
				goto end;
				//Error case. return error
			}
		}
		//Look up this TR69ID (on the RHS) under TR69_INSTANCES section in /tmp/sysconf
		if(pInstBuff != NULL)
		{
			ptr69inst_start = pInstBuff;
			//read line by line 
			while(NULL != (ptr69inst_pos = strchr(ptr69inst_start,'\n')))
			{
			    ptr69inst_pos++;
			    strncpy(ptr69inst_entry, ptr69inst_start, (ptr69inst_pos - ptr69inst_start));
		   		ptr69inst_entry[(ptr69inst_pos - ptr69inst_start)] = '\0';
				//contains LHS="RHS"\n
				//look for instance
				if((pTmp1 = strchr(ptr69inst_entry, '=')) != NULL)
				{
					pTmp1 +=2;
					if((pTmp2 = strchr(pTmp1, '#')) != NULL)
						strncpy(ptr69inst_entry_RHS, pTmp1 , (pTmp2 - pTmp1));	
					else if((pTmp2 = strchr(pTmp1,'"')) != NULL)
						strncpy(ptr69inst_entry_RHS, pTmp1 , (pTmp2 - pTmp1));	
				          
					ptr69inst_entry_RHS[(pTmp2 - pTmp1)]='\0';
				}
			    if(!strcmp(ptr69inst_entry_RHS, ptr69inst_RHS))
			    {
					if(iAction == IFX_ACTION_ADD)
					{
						//Backup this entry under TR69_INSTANCES section in /flash/rc.conf
						if(IFX_SUCCESS != ifx_SetObjData(pFileName,"tr69_instances", IFX_F_INT_ADD, 1, ptr69inst_entry))
						{
							#ifdef IFX_LOG_DEBUG
						    IFX_DBG("Error! Unable to add TR69 instance entry '%s'\n",ptr69inst_entry);
							#endif
            	    	  	//RetValue = -1;
		        	    	//goto end;
						}
						else{IFX_DBG("added TR69 instance entry [%s]\n",ptr69inst_entry);}
						break;
					}
					else if (iAction == IFX_ACTION_DELETE)
                    {
                        //Backup this entry under TR69_INSTANCES section in /flash/rc.conf
                        if(IFX_SUCCESS != ifx_SetObjData(pFileName,"tr69_instances", IFX_F_DELETE, 1, ptr69inst_entry))
                        {
                            #ifdef IFX_LOG_DEBUG
                            IFX_DBG("Error! Unable to delete TR69 instance entry '%s'\n",ptr69inst_entry);
                            #endif
                            RetValue = -1;
                            goto end;
                        }
						else{IFX_DBG("Deleted TR69 instance entry [%s]\n",ptr69inst_entry);}
                        break;
                    }

				}
			  
				if('\0' == ptr69inst_pos)
				{
				        break;
				}
			    ptr69inst_start = ptr69inst_pos;
			}//End of while
		} // End of if
	} //End of parse entry to get TR69 RHS
end:
	return RetValue;
}
/*********************************************************************
* Function   :  ifx_GetTR69MAPEntries()
* Description:  This function gets the matched tr69_map entries from 
*				rc.conf according to Section name
* Parameters :  pSecName :- Section name, pSecBuf :- Output buffer, 
				pFileName :- the file to search
* Return     :  IFX_SUCCESS :- Success
				IFX_FAILURE :- Failure
*********************************************************************/


int ifx_GetTR69MAPEntries(char8 * pSecName,char8 **pSecBuf, char8 * pFileName)
{
	char8 * pFullSecBuf = NULL;
	char8 * pRetSecBuff = NULL;
	char8 * ptr69map_start,*ptr69map_pos, *ptr69map_matchpos;
	char8 ptr69map_entry[MAX_FILELINE_LEN], pMatchString[32];
	int RetValue = 0;
	int n = 0;

	//Based on section name, get all the sectionname_* entries from tr69_map section in pFileName
	if(IFX_SUCCESS == ifx_GetCfgObject(pFileName,"tr69_map", NULL, IFX_F_GET_ANY, &pFullSecBuf))
	{	
		pRetSecBuff = (char8 *) malloc(strlen(pFullSecBuf) + 1);
		if(NULL == pRetSecBuff)
		{
		    #ifdef IFX_LOG_DEBUG
            	    IFX_DBG("Error![%s] Malloc Fail:[%d]",__FUNCTION__, __LINE__);
		    #endif
		    RetValue =  -1;
		    goto end;
		}
		pRetSecBuff[0] = '\0';
		sprintf(pMatchString, "%s_",pSecName);

		ptr69map_start = pFullSecBuf;
		while(NULL != (ptr69map_pos = strchr(ptr69map_start,'\n')))
		{
			ptr69map_pos++;
			strncpy(ptr69map_entry, ptr69map_start, (ptr69map_pos - ptr69map_start));
		   	ptr69map_entry[(ptr69map_pos - ptr69map_start)] = '\0';		
			
			if(NULL != (ptr69map_matchpos = strstr(ptr69map_entry, pMatchString)))
			{

				//check if matching string is at the beginning of line and 
				//after matched part is the cpe ID
				if(ptr69map_entry[0] == '#')
				{
				    if(ptr69map_entry[1] == '?')
				    {
						n=2;
				    }
				    else
				    {
						n=1;
				    }
		        }
			    if(ptr69map_matchpos == &ptr69map_entry[n])
				{
					if(isdigit(*(ptr69map_matchpos+strlen(pMatchString))))
					{
						sprintf(pRetSecBuff,"%s%s",pRetSecBuff,ptr69map_entry);
					}
				}
			}
			if(ptr69map_pos == '\0')
			{
				break;
			}
			ptr69map_start = ptr69map_pos;
		}//End while
		*pSecBuf = pRetSecBuff;
	}//End of GetCfgObject
	else
	{
		#ifdef IFX_LOG_DEBUG
        //IFX_DBG("Error! No section info [%s]", pSecName);
        #endif
        IFX_DBG("Error! No section info [%s]", pSecName);
        RetValue = -1;
		goto end;
	}
end:
	IFX_MEM_FREE(pFullSecBuf);

	return RetValue;
}

int ifx_ModifyTR69MAP_Instances(char8 * pSecName,char8 *pSrcFile, char8 * pDestFile, int iAction)
{

	char8 * pSrcBuff = NULL;
	char8 * pDestBuff = NULL;
	char8 * pTR69InstSrcBuf = NULL, * pTR69InstDestBuf = NULL;
	char8 * ptr69map_start, * ptr69map_pos = NULL;
	char8 ptr69map_entry[MAX_FILELINE_LEN];
	int RetValue = 0;

	ifx_GetCfgObject(pSrcFile, "tr69_instances", NULL, IFX_F_GET_ANY, &pTR69InstSrcBuf);
   	ifx_GetCfgObject(pDestFile, "tr69_instances", NULL, IFX_F_GET_ANY, &pTR69InstDestBuf);
	IFX_DBG(" [%s] called", __FUNCTION__);
	//Call API to get corresponding <section_name>_*(wildcard search, to eventually get all 
	//<section_name>_<CPEID>) entries from tr69_map section from /tmp/sysconf
	if(IFX_SUCCESS == ifx_GetTR69MAPEntries(pSecName,&pSrcBuff,pSrcFile))
	{
		if(pSrcBuff != NULL)
	    {
			//(Action restore) --> For restore first delete entries and then add.
			//For backup just add to destination file
			if(IFX_ACTION_RESTORE == iAction)
			{
				if(IFX_SUCCESS == ifx_GetTR69MAPEntries(pSecName, &pDestBuff, pDestFile ))
				{ 
				    ptr69map_start = pDestBuff;
				    while(NULL != (ptr69map_pos = strchr(ptr69map_start,'\n')))
				    {
						/*Get each line*/
						ptr69map_pos++;
						strncpy(ptr69map_entry, ptr69map_start, (ptr69map_pos - ptr69map_start));
					   	ptr69map_entry[(ptr69map_pos - ptr69map_start)] = '\0';		
	
						//Delete from tr69_map section in /flash/rc.conf
						if(IFX_SUCCESS != ifx_SetObjData(pDestFile, "tr69_map", IFX_F_DELETE, 1, ptr69map_entry))
						{
						    #ifdef IFX_LOG_DEBUG
    	    		        IFX_DBG("Error! Unable to delete MAPentry from rc.conf '%s'\n",ptr69map_entry);
	    	        		#endif
						    RetValue = -1;
						    goto end;
						}

						/*Delete entries from tr69_instances*/
						if(IFX_SUCCESS != ifx_ModifyTR69Instances(ptr69map_entry, pTR69InstDestBuf, IFX_ACTION_DELETE, pDestFile))
    	                {
        	            	#ifdef IFX_LOG_DEBUG
	        	            IFX_DBG("Error! Unable to modify  TR69 instance entry for '%s'\n",ptr69map_entry);
    	        	        #endif
        	        	    RetValue = -1;
            	        	goto end;
	                    }
		
						if('\0' == ptr69map_pos)
						{
						    break;
						}
						ptr69map_start = ptr69map_pos;
					}
				    IFX_MEM_FREE(pDestBuff);
				} // End of ifx_GetTR69MAPEntries(pDestFile)

			}//End (Action restore) --> For restore first delete entries and then add

			/* Restore from Backup to DestFile*/
			//Backup from flash to Dest
			ptr69map_start = pSrcBuff;
			while(NULL != (ptr69map_pos = strchr(ptr69map_start,'\n')))
			{
				ptr69map_pos++;
				strncpy(ptr69map_entry, ptr69map_start, (ptr69map_pos - ptr69map_start));
				//LHS="RHS"\n
				ptr69map_entry[(ptr69map_pos - ptr69map_start)] = '\0';
				
				if(IFX_SUCCESS != ifx_SetObjData(pDestFile,"tr69_map", IFX_F_INT_ADD, 1, ptr69map_entry))
				{
				    #ifdef IFX_LOG_DEBUG
			    	IFX_DBG("Error! Unable to restore TR69 MAP entry '%s'\n",ptr69map_entry);
				    #endif
				    RetValue = -1;
		    	    goto end;
				}
				/*If action is restore, after replacing map entries from source to dest, 
				the instance entries have to be rearranged in a numerical sequence and 
				then restored to destination. So we do that seperately.*/
				if(iAction == IFX_ACTION_BACKUP)
				{
					/*If backup, then directly add the mapped instance entries into destination/backup file*/
					if(IFX_SUCCESS != ifx_ModifyTR69Instances(ptr69map_entry, pTR69InstSrcBuf, IFX_ACTION_ADD, pDestFile))	
					{
						#ifdef IFX_LOG_DEBUG
        	            IFX_DBG("Error! Unable to backup TR69 instance entry for '%s'\n",ptr69map_entry);
            	        #endif
                	    RetValue = -1;
                    	goto end;
					}			
				}
				if('\0' == ptr69map_pos)
				{
			    	break;
				}

				ptr69map_start = ptr69map_pos;
		    }//end of while(ptr69map_pos = strchr(ptr69map_start, '\n'))
			IFX_MEM_FREE(pSrcBuff);
		}//End if(pSrcBuff != NULL)
	}//end of if IFX_SUCCESSS == ifx_GetTR69MAPEntries()
end:
IFX_MEM_FREE(pSrcBuff);
IFX_MEM_FREE(pDestBuff);
IFX_MEM_FREE(pTR69InstSrcBuf);
IFX_MEM_FREE(pTR69InstDestBuf);

return RetValue;

} //End of ifx_ModifyTR69MAP_Instances()

#endif //CONFIG_PACKAGE_IFX_DEVM
#endif //CONFIG_FEATURE_SELECTIVE_BACKUP_RESTORE

/**************************************************************************
*Function Name: ifx_mapi_backup_config
*Arguments: int flags --> For future use
*Description: This function, if Partial backup feature is enabled,
* will backup certain sections of the rc.conf file that are specified to be
* backedup. If this feature is not enabled, the function does a normal full
* rc.conf file backup.
***************************************************************************/
int ifx_mapi_backup_config(int flags)
{

	int RetValue = 0;
#ifdef CONFIG_FEATURE_SELECTIVE_BACKUP_RESTORE
	int loop;
	char8 * feature_name;
	char8    *pObjBuf = NULL;
	char8    *pSecBuf = NULL;
	char8 pSecName[32];
	char8 * pSecNameStart=NULL, *pPos = NULL;

	char8  pCommand[32];
	char8 pNextCPEID[MAX_FILELINE_LEN];
	int fp;
	char8 sValue[MAX_TAG_LEN];
	uint32 outFlag = IFX_F_DEFAULT;

	#ifdef CONFIG_PACKAGE_IFX_DEVM 
	char8 pTR69_SecName[MAX_TAG_LEN];
	int retval = 0;
	#endif


	//We need to create a file /tmp/rc.conf.gz which contains the partial config. To do that:
	//Loop through web_ui_backup_list[]
	//For each feature name
	sprintf(pCommand, "rm -f %s",FILE_TEMP_RC_CONF);
	system(pCommand);
	fp = open(FILE_TEMP_RC_CONF,O_RDWR|O_CREAT);
	if(-1 == fp)
	{
		close(fp);
                return -1;
	}
	close(fp);
	
	for (loop = 0; loop < (sizeof(web_ui_backup_list)/sizeof(char8*)); loop++)
	{
	    //Get contents of <feature_name> section from DBFile into a buffer. 
	    feature_name = web_ui_backup_list[loop];
	    if(ifx_GetCfgObject(DBFILE_PARTIAL_BKUP_RSTR,feature_name, NULL, IFX_F_GET_ANY, &pObjBuf) == IFX_SUCCESS)
	    {
		/*If successful, for each line(contains feature-related section name) in buffer: */
		pSecNameStart = pObjBuf;

		while(NULL != (pPos = strchr(pSecNameStart, '\n')))
		{
		    strncpy(pSecName, pSecNameStart, (pPos - pSecNameStart));
		    pSecName[(pPos - pSecNameStart)] = '\0';		
		    /*get <section> from /flash/rc.conf and if successful backup to /tmp/rc.conf.tmp*/
		    if(ifx_GetCfgObject(FILE_RC_CONF, pSecName, NULL, IFX_F_GET_ANY, &pSecBuf) == IFX_SUCCESS)
            {
				if(IFX_SUCCESS != ifx_SetObjData(FILE_TEMP_RC_CONF,pSecName,IFX_F_DEFAULT,1,pSecBuf))
				{
			    	#ifdef IFX_LOG_DEBUG
				    IFX_DBG("Error! Unable to copy section '%s'\n",pSecName);
				    #endif
				    RetValue = -1;
				    goto end;
				}
				IFX_MEM_FREE(pSecBuf);
		    }
		    
			/*backup Next CPEID entry*/
		    sprintf(pNextCPEID,"%s_%s",pSecName,NEXT_CPEID_SUFFIX);

		    if(IFX_SUCCESS == ifx_GetObjData(FILE_RC_CONF, NEXT_CPEID_SECTION, pNextCPEID, IFX_F_GET_ANY,&outFlag, sValue))
		    {
				sprintf(pNextCPEID,"%s=\"%s\"\n", pNextCPEID, sValue);
				if(IFX_SUCCESS != ifx_SetObjData(FILE_TEMP_RC_CONF, NEXT_CPEID_SECTION, IFX_F_INT_ADD, 1, pNextCPEID))
				{
        	        //Do what?
                    #ifdef IFX_LOG_DEBUG
                    IFX_DBG("Error! Unable to backup next CPEID entry '%s'\n",pNextCPEID);
                    #endif
			    	RetValue = -1;
				    goto end;
				}
		    }
 
			/*TR69 related sections/attributes*/
		    #ifdef CONFIG_PACKAGE_IFX_DEVM
		    sprintf(pTR69_SecName,"tr69_%s",pSecName);
		    
			/*get TR69_<section> from /flash/rc.conf and if successful backup to /tmp/rc.conf.tmp*/
			if((retval = ifx_GetCfgObject(FILE_RC_CONF, pTR69_SecName, NULL, IFX_F_GET_ANY, &pSecBuf)) == IFX_SUCCESS)
            {
            	if(IFX_SUCCESS != ifx_SetObjData(FILE_TEMP_RC_CONF, pTR69_SecName, IFX_F_DEFAULT, 1, pSecBuf))
				{
    	            //Do what?
                    #ifdef IFX_LOG_DEBUG
        	        IFX_DBG("Error! Unable to backup TR69 section '%s'\n",pTR69_SecName);
                    #endif
			    	RetValue = -1;
				    goto end;
				}
                IFX_MEM_FREE(pSecBuf);
			}
		    else
		    {
				if(IFX_E_SEC_EMPTY ==  retval)
				{
				    /*Set empty buffer for the section*/
				    if(IFX_SUCCESS != ifx_SetObjData(FILE_TEMP_RC_CONF, pTR69_SecName, IFX_F_DEFAULT, 1, ""))
			    	{
						#ifdef IFX_LOG_DEBUG
						IFX_DBG("Error! Unable to backup TR69 section '%s'\n",pTR69_SecName);
						#endif
						RetValue = -1;
						goto end;
			    	}
				}
		    }

				//Call API to get corresponding <section_name>_*(wildcard search, to eventually get all 
			    //<section_name>_<CPEID>) entries from tr69_map section from /flash/rc.conf.
			    if(IFX_SUCCESS != ifx_ModifyTR69MAP_Instances(pSecName,FILE_RC_CONF, FILE_TEMP_RC_CONF, IFX_ACTION_BACKUP))
		    	{
                            #ifdef IFX_LOG_DEBUG
                            IFX_DBG("Error! Unable to backup TR69 MAP and Instances [%s] \n",pSecName);
                            #endif
                            RetValue = -1;
                            goto end;
			    }
			    #endif//CONFIG_PACKAGE_IFX_DEVM
                    
			    /*Next section*/
		    	pSecNameStart = pPos+1;
			}
			IFX_MEM_FREE(pObjBuf);
		}//End of 'Get contents of <feature_name> section from DBFile'
	    /*Next feature*/
	}//End of loop through web_ui_backup_list

	// /tmp/rc.conf.tmp now contains the partial backup conf file.
	// Move it to /tmp/rc.conf.gz
	system("gzip -c /tmp/rc.conf.tmp > /tmp/rc.conf.gz");
  
	#else

	system("/usr/sbin/read_img sysconfig /tmp/rc.conf.gz");
	
	#endif //CONFIG_FEATURE_SELECTIVE_BACKUP_RESTORE

#ifdef CONFIG_FEATURE_SELECTIVE_BACKUP_RESTORE
end:
	IFX_MEM_FREE(pObjBuf);
	IFX_MEM_FREE(pSecBuf);
#endif
	return RetValue;
} //backup_config


/**************************************************************************
*Function Name: ifx_mapi_restore_config
*Arguments: int flags --> For future use
*Description: This function, if Partial backup/restore feature is enabled,
* will restore all sections specified in web_ui_backup_list[], from the uploaded
* file(from user's PC) (which is copied into /tmp/sysconf by the caller function)
* into /flash/rc.conf
* If this feature is not enabled, the function does a normal full
* rc.conf file backup.
***************************************************************************/

int ifx_mapi_restore_config(int flags)
{

	int RetValue=0;
#ifdef CONFIG_FEATURE_SELECTIVE_BACKUP_RESTORE
	int loop;
	char8 * feature_name;
	char8    *pObjBuf = NULL;
    char8    *pSecBuf = NULL;
    char8 pSecName[32];
    char8 * pSecNameStart=NULL, *pPos = NULL;
	char8 * pTempValue = NULL;
    uint32 outFlag = IFX_F_DEFAULT;
	char8 pNextCPEID[MAX_FILELINE_LEN], pTempNextCPEID[MAX_FILELINE_LEN];
	char8 pNextCPEID_Entry[MAX_FILELINE_LEN];
	char8 sValue[MAX_TAG_LEN], sTempValue[MAX_TAG_LEN];
        
	#ifdef CONFIG_PACKAGE_IFX_DEVM 
    char8 pTR69_SecName[MAX_TAG_LEN];
	int retval = 0;
	#endif

	for (loop = 0; loop < (sizeof(web_ui_backup_list)/sizeof(char8*)); loop++)
	{
		//Get contents of <feature_name> section from DBFile into a buffer. 
	    feature_name = web_ui_backup_list[loop];
	    if(ifx_GetCfgObject(DBFILE_PARTIAL_BKUP_RSTR, feature_name, NULL, IFX_F_GET_ANY, &pObjBuf) == IFX_SUCCESS)
	    {
			/*If successful, for each line(contains feature-related section name) in buffer: */
			pSecNameStart = pObjBuf;
			while(NULL != (pPos = strchr(pSecNameStart, '\n')))
			{
		    	strncpy(pSecName,pSecNameStart,(pPos-pSecNameStart));
			    pSecName[(pPos - pSecNameStart)] = '\0';
		
			    /*get <section> from /tmp/sysconf and if successful backup to /flash/rc.conf*/
		    	if(ifx_GetCfgObject(FILE_SYSCONF, pSecName, NULL, IFX_F_GET_ANY, &pSecBuf) == IFX_SUCCESS)
                {
					if(IFX_SUCCESS != ifx_SetObjData(FILE_RC_CONF,pSecName,IFX_F_DEFAULT,1,pSecBuf))
					{
					    //Do what?
					    #ifdef IFX_LOG_DEBUG
					    IFX_DBG("Error! Unable to restore section '%s'\n",pSecName);
					    #endif
					    RetValue = -1;
					    goto end;
					}

					IFX_MEM_FREE(pSecBuf);
			    }

			    /*Restore Next CPEID entry*/
			    sprintf(pNextCPEID,"%s_%s",pSecName,NEXT_CPEID_SUFFIX);

		    	if(IFX_SUCCESS == ifx_GetObjData(FILE_SYSCONF, NEXT_CPEID_SECTION, pNextCPEID, IFX_F_GET_ANY, &outFlag, sValue))
			    {
                    sprintf(pNextCPEID_Entry,"%s=\"%s\"\n", pNextCPEID, sValue);

					/*check present already in rc.conf?*/
			    	if(IFX_SUCCESS == ifx_GetObjData(FILE_RC_CONF, NEXT_CPEID_SECTION, pNextCPEID, IFX_F_GET_ANY, &outFlag, sTempValue))
					{
        	            sprintf(pTempNextCPEID,"%s=\"%s\"\n", pNextCPEID, sTempValue);

					    //Delete
					    if(IFX_SUCCESS != ifx_SetObjData(FILE_RC_CONF, NEXT_CPEID_SECTION, IFX_F_DELETE, 1, pTempNextCPEID))
			    		{
                        	//Do what?
                            #ifdef IFX_LOG_DEBUG
                            IFX_DBG("Error! Unable to delete CPEID entry from rc.conf '%s'\n", pTempNextCPEID);
                            #endif
                            RetValue = -1;
                            goto end;
					    }
					}
			
					if(IFX_SUCCESS != ifx_SetObjData(FILE_RC_CONF, NEXT_CPEID_SECTION, IFX_F_INT_ADD, 1, pNextCPEID_Entry))
					{
                		//Do what?
                        #ifdef IFX_LOG_DEBUG
                        IFX_DBG("Error! Unable to add back next CPEID entry '%s'\n",pNextCPEID_Entry);
                        #endif
                        RetValue = -1;
                        goto end;
					}
			    }//End of Next CPE ID

			    /*TR69 related sections/attributes*/
			    #ifdef CONFIG_PACKAGE_IFX_DEVM 
			    sprintf(pTR69_SecName,"tr69_%s",pSecName);
			    
				/*get TR69_<section> from /tmp/sysconf and if successful backup to /flash/rc.conf*/
                if((retval = ifx_GetCfgObject(FILE_SYSCONF, pTR69_SecName, NULL, IFX_F_GET_ANY, &pSecBuf)) == IFX_SUCCESS)
                {
					if(IFX_SUCCESS != ifx_SetObjData(FILE_RC_CONF,pTR69_SecName,IFX_F_DEFAULT,1,pSecBuf))
					{
						#ifdef IFX_LOG_DEBUG
                        IFX_DBG("Error! Unable to restore TR69 section '%s'\n",pSecBuf);
                        #endif
                        RetValue = -1;
                        goto end;
					}
                    IFX_MEM_FREE(pSecBuf);
				}
			    else
			    {
					if(IFX_E_SEC_EMPTY ==  retval)
                    {
						/*Set empty buffer for the section*/
                        if(IFX_SUCCESS != ifx_SetObjData(FILE_RC_CONF, pTR69_SecName, IFX_F_DEFAULT, 1, ""))
                        {
                            #ifdef IFX_LOG_DEBUG
                            IFX_DBG("Error! Unable to restore TR69 section '%s'\n",pTR69_SecName);
                            #endif
                            IFX_DBG("[%d]Error! Unable to restore TR69 section '%s'\n",__LINE__,pTR69_SecName);
                            RetValue = -1;
                            goto end;
						}
                    }
			    }
			    //Call API restore the TR69 MAP entries. Instance entries are replaced seperately
				IFX_DBG("Call API restore the TR69 MAP entries.");
			    if(IFX_SUCCESS != ifx_ModifyTR69MAP_Instances(pSecName,FILE_SYSCONF,FILE_RC_CONF,IFX_ACTION_RESTORE))
                {
            	    //Do what?
                	#ifdef IFX_LOG_DEBUG
                    IFX_DBG("Error! Unable to restore TR69 MAP and Instances [%s] \n",pSecName);
                    #endif
                    RetValue = -1;
                    goto end;
                }

				IFX_DBG("Now back to mapi_restore_config");
		    	#endif //CONFIG_PACKAGE_IFX_DEVM
		    
			    /*Next section*/
			    pSecNameStart = pPos+1;
			}

			IFX_MEM_FREE(pObjBuf);
		}//End of 'Get contents of <feature_name> section from DBFile'
	    /*Next feature*/
	}//End of loop through web_ui_backup_list
	/* The tr69 instances from current rc.conf have been deleted. Now append the backedup instances to the now existing
	instance entries, rearrange the numerical sequence and replace in /flash/rc.conf*/
	#ifdef CONFIG_PACKAGE_IFX_DEVM
	if(IFX_SUCCESS != ifx_RestoreTR69_Instances())
	{
		#ifdef IFX_LOG_DEBUG
        IFX_DBG("Error! [%d] Unable to restore TR69 instances \n", __LINE__);
        #endif
        RetValue = -1;
		goto end;
	}
	#endif //CONFIG_PACKAGE_IFX_DEVM

#else
	if(rename("/tmp/sysconf","/flash/rc.conf"))
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("Error! Unable to restore to /flash/rc.conf \n");
		#endif
		RetValue = -1;
	}
#endif //CONFIG_FEATURE_SELECTIVE_BACKUP_RESTORE

#ifdef CONFIG_FEATURE_SELECTIVE_BACKUP_RESTORE
end:
	IFX_MEM_FREE(pObjBuf);
	IFX_MEM_FREE(pSecBuf);
	IFX_MEM_FREE(pTempValue);
#endif //CONFIG_FEATURE_SELECTIVE_BACKUP_RESTORE

	return RetValue;
} //restore_config
