#include <stdio.h>
#include <ctype.h>
#include <fcntl.h>
#include <string.h>
#include <syslog.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <sys/sysinfo.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"

#ifdef IFX_DBG
#undef IFX_DBG
#define IFX_DBG(fmt, args...)
#endif

int getVer(char **sw_ver, char **fw_ver)
{
    int ret = 0;
    int fd = -1;
    char *ptr = NULL, *psTmp = NULL;
    char buff[96] = {0};
    char *sw  = NULL;
    char *fw  = NULL;
    size_t newLen = 0;
    //system("rm /tmp/version");
    system("version.sh > /dev/null");
    ret = system("cat /tmp/version | grep Software > /tmp/swver");
    fd = open("/tmp/swver", O_RDONLY);
    if (fd < 0)
    {
        IFX_DBG("failed to open /tmp/swver\n");
	ret = -1;
	goto ifx_handler;
    }
    
    newLen = read(fd,buff,sizeof(buff));
    buff[newLen] = '\0';
    ptr = buff+strlen("Software:");
    if (ptr == NULL)
    {
        IFX_DBG("Unable to parse version /tmp/fwver\n");
	ret = -1;	
	goto ifx_handler;
    }
    if(( psTmp = strchr(ptr, '\n')) != NULL)
	*psTmp = '\0';
    sw = (char *)malloc(strlen(ptr)+1);
    if(sw == NULL)
    {
	ret = -1;
	goto ifx_handler;
    }
    memset(sw,0,strlen(ptr)+1);
    strcpy(sw,ptr);
    close(fd);
    *sw_ver = sw;
    sw = NULL;

    ret = system("cat /tmp/version | grep Firmware > /tmp/fwver");
    fd = open("/tmp/fwver", O_RDONLY);
    if (fd < 0)
    {
        IFX_DBG("failed to open /tmp/fwver\n");
	ret = -1;
	goto ifx_handler;
    }
    memset(buff, '\0', sizeof(buff));
    newLen = read(fd,buff,sizeof(buff));
    buff[newLen] = '\0';
    ptr = strstr(buff,": ");
    if (ptr == NULL)
    {
        IFX_DBG("Unable to parse version /tmp/fwver\n");
	ret = -1;
	goto ifx_handler;
    }
    
    if(( psTmp = strchr(ptr, '\n')) != NULL)
    	*psTmp = '\0';
    
    ptr = ptr + 2;
    
    fw = (char *)malloc(strlen(ptr)+1);
    if(fw == NULL)
    {
	ret = -1;
	goto ifx_handler;
    }
    memset(fw,0,strlen(ptr)+1);
    strcpy(fw,ptr);
    close(fd);
    *fw_ver = fw;
    fw = NULL;

ifx_handler:
    if(fd >= 0)
	close(fd);
	if(ret == -1) {
		if(sw)
			free(sw);
		if(fw)
			free(fw);
	}
    return ret;
}

int32
ifx_get_version_info(struct ifx_version_info *st)
{
    char8 a[LINE_LEN],*s=a,*p, *pTmp;
    FILE *fp;
    int len;

    fp=fopen("/tmp/version","r");
    if(fp==NULL)
    {
        IFX_DBG ("/tmp/version File does not exit\n");
        system("version.sh");
        fp=fopen("/tmp/version","r");
        if(fp==NULL)
        {
            IFX_DBG ("/tmp/version File does not exit\n:");
            //return IFX_FAILURE;
            goto errorHandler;
        }
    }
    while(fgets(s,LINE_LEN,fp))
    {
        if(strstr(s,"BOOTLoader"))
        {

            p=strchr(s,':');
            if(p!=NULL)
            {
                if(strlen(p+1)<VALUE_MAX_LEN)
                {
                    strcpy(st->BOOTLoader,p+1);
                    if(st->BOOTLoader[strlen(st->BOOTLoader) - 1] == '\n') {
                        st->BOOTLoader[strlen(st->BOOTLoader) - 1] = '\0';
                    }
                }
                else
                    printf("Can't Copy\n");
            }
        }
        else if(strstr(s,"CPU"))
        {
            p=strchr(s,':');
            if(p!=NULL)
            {
                if(strlen(p+1)<VALUE_MAX_LEN)
                {
                    strcpy(st->CPU,p+1);
                    if(st->CPU[strlen(st->CPU) - 1] == '\n') {
                        st->CPU[strlen(st->CPU) - 1] = '\0';
                    }
                }
                else
                    printf("Can't Copy\n");
            }
        }
        else if(strstr(s,"BSP"))
        {
            p=strchr(s,':');
            if(p!=NULL)
            {
                if(strlen(p+1)<VALUE_MAX_LEN)
                {
                    strcpy(st->BSP,p+1);
                    if(st->BSP[strlen(st->BSP) - 1] == '\n') {
                        st->BSP[strlen(st->BSP) - 1] = '\0';
                    }
                }
                else
                    printf("Can't Copy\n");
            }
        }
        else if(strstr(s,"Software"))
        {
            p=strchr(s,':');
            if(p!=NULL)
            {
                if(strlen(p+1)<VALUE_MAX_LEN)
                {
                    strcpy(st->Software,p+1);
                    if(st->Software[strlen(st->Software) - 1] == '\n') {
                        st->Software[strlen(st->Software) - 1] = '\0';
                    }
                }
                else
                    printf("Can't Copy\n");
            }
        }
        else if(strstr(s,"Tool Chain"))
        {
            p=strchr(s,':');
            if(p!=NULL)
            {
                if(strlen(p+1)<VALUE_MAX_LEN)
                {
                    strcpy(st->Tool_Chain,p+1);
                    if(st->Tool_Chain[strlen(st->Tool_Chain) - 1] == '\n') {
                        st->Tool_Chain[strlen(st->Tool_Chain) - 1] = '\0';
                    }
                }
                else
                    printf("Can't Copy\n");
            }
        }
        else if(strstr(s,"DSL"))
        {
			p=strstr(s,"FW");
    	    pTmp=strstr(s,"DRIVER");
    	    len = pTmp - p - 5;
    	    strncpy(st->Firmware, p+3, len+1);
			if(st->Firmware[len] == ',')
	        {
        	    st->Firmware[len] = '\0';
	        }	
/*
            p=strchr(s,':');
            if(p!=NULL)
            {
                if(strlen(p+1)<VALUE_MAX_LEN)
                {
                    strcpy(st->Firmware,p+1);
                    if(st->Firmware[strlen(st->Firmware) - 1] == '\n') {
                        st->Firmware[strlen(st->Firmware) - 1] = '\0';
                    }
                }
                else
                    printf("Can't Copy\n");
            }
*/
        }
#ifdef CONFIG_FEATURE_IFX_WIRELESS_WAVE300
        else if(strstr(s,"Wave wlan version"))
        {
            p=strchr(s,':');
            if(p!=NULL)
            {
                if(strlen(p+1)<VALUE_MAX_LEN)
                {
                    strcpy(st->WAVE300_CV,p+1);
                    if(st->WAVE300_CV[strlen(st->WAVE300_CV) - 1] == '\n') {
                        st->WAVE300_CV[strlen(st->WAVE300_CV) - 1] = '\0';
                    }
                }
                else
                    printf("Can't Copy\n");
            }
        }
#endif /* #ifdef CONFIG_FEATURE_IFX_WIRELESS_WAVE300 */

        memset(s,0x00, LINE_LEN);
    }

    fclose(fp);
    return IFX_SUCCESS;

errorHandler:
    return IFX_FAILURE;

}


int32 ifx_get_device_info(DEVICE_INFO *dev_info, uint32 flags)
{
    int32       iRtn = IFX_SUCCESS;
    char8       sVal[MAX_FILELINE_LEN];
    uint32      ulOutFlag;
    double      uptime;
    int32       iI = 0;
    FILE        *fp;
    size_t newLen = 0;
    DEVICE_INFO xDI;
    //char *sw_ver = NULL, caBuff[32] = { 0 };
#ifndef HOSTENV
    int32       iFD = -1;
    char8 caBuff[32] = { 0 };
    //char *fw_ver = NULL, *psTmp = NULL;
    char8 *psTmp = NULL;
    struct ifx_version_info ver_st;
#endif
#ifndef HOSTENV
    int ret;
    memset(&ver_st,0x00,sizeof(ver_st));
    ret = ifx_get_version_info(&ver_st);
    //ret = getVer(&sw_ver,&fw_ver);
    if (ret == -1)
    {
        iRtn = IFX_FAILURE;
        goto IFX_Handler;
    }
#endif

    memset(&xDI, 0, sizeof(DEVICE_INFO));

#ifndef HOSTENV
    memset(sVal,'\0' , sizeof(sVal));
    if ((iRtn = ifx_GetObjData(IFX_SYS_CONF, IFX_DEVICE_INFO_SECTION,
        IFX_DEVICE_INFO_SECTION "_" IFX_DEVICE_INFO_MANUFACTURER,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Manufacturer !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_MANUFACTURER_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> Manufacturer len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xDI.manufacturer, sVal,MAX_MANUFACTURER_LEN);
#else
    strlcpy(xDI.manufacturer, "Infineon Technologies",MAX_MANUFACTURER_LEN);
#endif

#ifndef HOSTENV
    memset(sVal,'\0', sizeof(sVal));
    iFD = open("/tmp/macget", O_RDONLY);
    if(iFD < 0)
    {
        system("upgrade mac_get 2 >/tmp/macget");
        iFD = open("/tmp/macget", O_RDONLY);
        if(iFD < 0)
        {
            IFX_DBG("failed to open /tmp/macget\n");
            return -1;
        }
    }
    newLen = read(iFD, caBuff, sizeof(caBuff));
    caBuff[newLen] = '\0';

    psTmp = strtok(caBuff, ":");
    if(psTmp == NULL)
    {
        IFX_DBG("Unable to parse /tmp/macget\n");
	close(iFD);
        return -1;
    }
    strlcpy(sVal, psTmp,sizeof(sVal));
    psTmp = strtok(NULL, ":");
    if(psTmp != NULL)
    strlcat(sVal, psTmp,sizeof(sVal));
    psTmp = strtok(NULL, ":");
    if(psTmp != NULL)
    strlcat(sVal, psTmp,sizeof(sVal));
    close(iFD);
    //system("rm /tmp/macget");

    if ((strlen(sVal) + 1) > MAX_OUI_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> ManufacturerOUI len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xDI.oui, sVal,MAX_OUI_LEN);
#else
    strlcpy(xDI.oui, "000319",MAX_OUI_LEN);
#endif

#ifndef HOSTENV
    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(IFX_SYS_CONF, IFX_DEVICE_INFO_SECTION,
        IFX_DEVICE_INFO_SECTION "_" IFX_DEVICE_INFO_MODELNAME,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get ModelName !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_MODEL_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> ModelName len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xDI.model_name, sVal,MAX_MODEL_LEN);
#else
    strlcpy(xDI.model_name, "Amazon-SE",MAX_MODEL_LEN);
#endif

#ifndef HOSTENV
    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(IFX_SYS_CONF, IFX_DEVICE_INFO_SECTION,
        IFX_DEVICE_INFO_SECTION "_" IFX_DEVICE_INFO_DESCRIPTION,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get Description !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_DESCRIPTION_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> Description len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xDI.description, sVal,MAX_DESCRIPTION_LEN);
#else
    strlcpy(xDI.description, "Amazon ADSL Router",MAX_DESCRIPTION_LEN);
#endif

#ifndef HOSTENV
    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(IFX_SYS_CONF, IFX_DEVICE_INFO_SECTION,
        IFX_DEVICE_INFO_SECTION "_" IFX_DEVICE_INFO_PRODUCTCLASS,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get ProductClass !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_PROD_CLASS_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> ProductClass len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xDI.product_class, sVal,MAX_PROD_CLASS_LEN);
#else
    strlcpy(xDI.product_class, "CPE",MAX_PROD_CLASS_LEN);
#endif

#ifndef HOSTENV
    memset(sVal,'\0', sizeof(sVal));
    memset(caBuff, 0x00, sizeof(caBuff));
    iFD = open("/tmp/sernumget", O_RDONLY);
    if(iFD < 0)
    {
        system("upgrade mac_get 2 >/tmp/sernumget");
        iFD = open("/tmp/sernumget", O_RDWR);
        if(iFD < 0)
        {
            IFX_DBG("failed to open /tmp/sernumget\n");
            return -1;
        }

	newLen = read(iFD, caBuff, sizeof(caBuff));
        caBuff[newLen] = '\0';
	psTmp = sVal;

	for(iI = 0; iI<= 16; iI++){
		if( *(caBuff + iI) != ':'){
			*psTmp = *(caBuff + iI);
			psTmp++;
		}
	}

	//write back the correct serial number
	if( lseek(iFD, 0, SEEK_SET) >= 0)
		write(iFD, sVal, sizeof(sVal)); 

    }else{
	    newLen = read(iFD, caBuff, sizeof(caBuff));
	    caBuff[newLen] = '\0';
	    strcpy(sVal, caBuff);
    }

    close(iFD);

    // system("rm /tmp/sernumget");

    if ((strlen(sVal) + 1) > MAX_SERIAL_NUM_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> SerialNumber len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strcpy(xDI.serial_number, sVal);

/*
    if ((iRtn = ifx_GetObjData(IFX_SYS_CONF, IFX_DEVICE_INFO_SECTION,
        IFX_DEVICE_INFO_SECTION "_" IFX_DEVICE_INFO_SERIALNUMBER,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get SerialNumber !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_SERIAL_NUM_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> SerialNumber len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strcpy(xDI.serial_number, sVal);*/
#else
    strcpy(xDI.serial_number, "DMA66");
#endif

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DEVICE_INFO_SECTION,
        IFX_DEVICE_INFO_SECTION "_" IFX_DEVICE_INFO_HARDWAREVERSION,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get HardwareVersion !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_VER_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> HardwareVersion len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xDI.hw_ver, sVal,MAX_VER_LEN);


#ifndef HOSTENV
    if ((strlen(ver_st.Software) + 1) > MAX_VER_LEN)
    {
        iRtn = IFX_FAILURE; goto IFX_Handler;
    }
    strlcpy(xDI.sw_ver, ver_st.Software,MAX_VER_LEN);
#else
    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DEVICE_INFO_SECTION,
        IFX_DEVICE_INFO_SECTION "_" IFX_DEVICE_INFO_SOFTWAREVERSION,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get SoftwareVersion !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_VER_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> SoftwareVersion len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xDI.sw_ver, sVal,MAX_VER_LEN);
#endif

#ifndef HOSTENV
    if ((strlen(ver_st.Firmware) + 1) > MAX_VER_LEN)
    {
        iRtn = IFX_FAILURE; goto IFX_Handler;
    }
    strlcpy(xDI.fw_ver, ver_st.Firmware,MAX_VER_LEN);
#else
    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DEVICE_INFO_SECTION,
        IFX_DEVICE_INFO_SECTION "_" IFX_DEVICE_INFO_MODEMFIRMWAREVERSION,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get ModemFirmwareVersion !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_VER_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> ModemFirmwareVersion len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xDI.fw_ver, sVal,MAX_VER_LEN);
#endif

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DEVICE_INFO_SECTION,
                               IFX_DEVICE_INFO_SECTION "_" IFX_DEVICE_INFO_SYSCONTACT,
                               flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get SysContact !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_SYS_CONTACT_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> SysContact len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xDI.sysContact, sVal,MAX_SYS_CONTACT_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DEVICE_INFO_SECTION,
                               IFX_DEVICE_INFO_SECTION "_" IFX_DEVICE_INFO_SYSNAME,
                               flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get SysName !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_SYS_NAME_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> SysName len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xDI.sysName, sVal,MAX_SYS_NAME_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DEVICE_INFO_SECTION,
                               IFX_DEVICE_INFO_SECTION "_" IFX_DEVICE_INFO_SYSLOCATION,
                               flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get SysLocation !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_SYS_LOCATION_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> SysLocation len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xDI.sysLocation, sVal,MAX_SYS_LOCATION_LEN);


    memset(sVal,'\0', sizeof(sVal));

    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DEVICE_INFO_SECTION,
                               IFX_DEVICE_INFO_SECTION "_" IFX_DEVICE_INFO_SYSOBJECT_ID,
                               flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get SysObjectId !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }

    if ( (strlen(sVal) + 1) > MAX_SYS_OBJID_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> SysObjectId len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xDI.sysObjId, sVal,MAX_SYS_OBJID_LEN);

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DEVICE_INFO_SECTION,
                               IFX_DEVICE_INFO_SECTION "_" IFX_DEVICE_INFO_SYSSERVICES,
                               flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get SysServices!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    xDI.sysServices = atoi(sVal);

#ifndef HOSTENV
    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(IFX_SYS_CONF, IFX_DEVICE_INFO_SECTION,
        IFX_DEVICE_INFO_SECTION "_" IFX_DEVICE_INFO_SPECVERSION,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get SpecVersion !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > SPEC_VER_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> SpecVersion len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xDI.igd_spec_ver, sVal,SPEC_VER_LEN);
#else
    strlcpy(xDI.igd_spec_ver, "1.0",MAX_VER_LEN);
#endif

    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(FILE_RC_CONF, IFX_DEVICE_INFO_SECTION,
        IFX_DEVICE_INFO_SECTION "_" IFX_DEVICE_INFO_PROVISIONINGCODE,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get ProvisioningCode !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_PROVISION_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> ProvisioningCode len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xDI.provisioning_info, sVal,MAX_PROVISION_LEN);

    fp = fopen("/proc/uptime", "r");

    if (!fp)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> Unable to open /proc/uptime!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }

    fscanf(fp, "%lf", &uptime);
    fclose(fp);

    sprintf(sVal, "%lf", uptime);
    for (iI = 0; iI < strlen(sVal); iI++)
    {
        if (sVal[iI] == '.')
        {
            sVal[iI] = '\0';
            break;
        }
    }

    xDI.uptime = atoi(sVal);

#ifndef HOSTENV
    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(IFX_SYS_CONF, IFX_DEVICE_INFO_SECTION,
        IFX_DEVICE_INFO_SECTION "_" IFX_DEVICE_INFO_MODELNUMBER,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get ModelNumber !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_MODEL_NUM_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> ModelNumber len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xDI.model_number, sVal,MAX_MODEL_NUM_LEN);
#else
    strlcpy(xDI.model_number, "1.0",MAX_MODEL_NUM_LEN);
#endif

#ifndef HOSTENV
    memset(sVal,'\0', sizeof(sVal));
    if ((iRtn = ifx_GetObjData(IFX_SYS_CONF, IFX_DEVICE_INFO_SECTION,
        IFX_DEVICE_INFO_SECTION "_" IFX_DEVICE_INFO_TR64URL,
        flags, &ulOutFlag, sVal)) != IFX_SUCCESS)
    {
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get TR-064 URL !!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    if ((strlen(sVal) + 1) > MAX_TR64_URL_LEN)
    {
        iRtn = IFX_FAILURE;
        IFX_DBG("\n\n In Function [%s] : Error--> TR-064 URL len not fitting in buffer!!\n\n", __FUNCTION__);
        goto IFX_Handler;
    }
    strlcpy(xDI.tr64_url, sVal,MAX_TR64_URL_LEN);
#else
    strlcpy(xDI.tr64_url, "http://www.infineon.com",MAX_TR64_URL_LEN);
#endif


    /* Fill the structure to be returned to the user */
    strlcpy(dev_info->manufacturer, xDI.manufacturer,MAX_MANUFACTURER_LEN);
    strlcpy(dev_info->oui, xDI.oui,MAX_OUI_LEN);
    strlcpy(dev_info->model_name, xDI.model_name,MAX_MODEL_LEN);
    strlcpy(dev_info->description, xDI.description,MAX_DESCRIPTION_LEN);
    strlcpy(dev_info->product_class, xDI.product_class,MAX_PROD_CLASS_LEN);
    strlcpy(dev_info->serial_number, xDI.serial_number,MAX_SERIAL_NUM_LEN);
    strlcpy(dev_info->hw_ver, xDI.hw_ver,MAX_VER_LEN);
    strlcpy(dev_info->sw_ver, xDI.sw_ver,MAX_VER_LEN);
    strlcpy(dev_info->fw_ver, xDI.fw_ver,MAX_VER_LEN);
    strlcpy(dev_info->sysContact, xDI.sysContact,MAX_SYS_CONTACT_LEN);
    strlcpy(dev_info->sysName, xDI.sysName,MAX_SYS_NAME_LEN);
    strlcpy(dev_info->sysLocation, xDI.sysLocation,MAX_SYS_LOCATION_LEN);
    strlcpy(dev_info->sysObjId, xDI.sysObjId,MAX_SYS_OBJID_LEN);
    dev_info->sysServices = xDI.sysServices;
    strlcpy(dev_info->igd_spec_ver, xDI.igd_spec_ver,SPEC_VER_LEN);
    strlcpy(dev_info->provisioning_info, xDI.provisioning_info,MAX_PROVISION_LEN);
    dev_info->uptime = xDI.uptime;
    strlcpy(dev_info->model_number, xDI.model_number,MAX_MODEL_NUM_LEN);
    strlcpy(dev_info->tr64_url, xDI.tr64_url,MAX_TR64_URL_LEN);

IFX_Handler:
    //if(sw_ver) {free(sw_ver);sw_ver = NULL;}
    //if(fw_ver) {free(fw_ver);fw_ver = NULL;}
    return (iRtn);
}


int32 ifx_set_device_info(int32 operation, DEVICE_INFO *dev_info, uint32 flags)
{
    int    count = 0, ret = IFX_SUCCESS, iI = 0;
    uint32 changed_fcount = 0;
    char8    buf[MAX_DATA_LEN];
    IFX_ID    iid;
    IFX_NAME_VALUE_PAIR array_fvp[MAX_FIELD_RANGE], *array_changed_fvp = NULL;

    memset(buf, 0, sizeof(buf));
    memset(&iid, 0, sizeof(iid));
    memset(array_fvp, 0, sizeof(array_fvp));


    /***  PROLOG BLOCK  ***/

    /* Append internal flags */
    if (operation == IFX_OP_DEL)
        flags |= IFX_F_DELETE;
    else if (operation == IFX_OP_MOD)
        flags |= IFX_F_MODIFY;
    else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
         flags |= IFX_F_INT_ADD;

    /********  VALIDATION BLOCK  ***********/
    /* For ops other than DELETE do the verification of input params */
    if (IFX_DELETE_F_NOT_SET(flags))
    {
        /*** Validation Checking Block ***/
        if(IFX_DONT_VALIDATE_F_NOT_SET(flags))
        {
            /* Do simple validation of pointer such as NULL */
            IFX_VALIDATE_PTR(dev_info)
            /* Do simple validation of flags such as less than 0 */
            IFX_VALIDATE_FLAGS(flags)
        }
    }

    /*******  VALIDATION BLOCK END *********/

    /* Read the iid structure from rc.conf */
    iid = dev_info->iid;
    if(ifx_get_iid_from_conf(&iid, FILE_RC_CONF, IFX_DEVICE_INFO_SECTION) != IFX_SUCCESS)
    {
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    /*********** Name Value Formation As Per RC.CONF ****************/
    /* Build the API Specific name value pair */
    sprintf(array_fvp[iI].fieldname, "%s_%s", IFX_DEVICE_INFO_SECTION, "cpeId");
    sprintf(array_fvp[iI++].value, "%d", iid.cpeId.Id);
    sprintf(array_fvp[iI].fieldname, "%s_%s", IFX_DEVICE_INFO_SECTION, "pcpeId");
    sprintf(array_fvp[iI++].value, "%d", iid.pcpeId.Id);
    sprintf(array_fvp[iI].fieldname, "%s_%s", IFX_DEVICE_INFO_SECTION, IFX_DEVICE_INFO_HARDWAREVERSION);
    sprintf(array_fvp[iI++].value, "%s", dev_info->hw_ver);
    sprintf(array_fvp[iI].fieldname, "%s_%s", IFX_DEVICE_INFO_SECTION, IFX_DEVICE_INFO_SOFTWAREVERSION);
    sprintf(array_fvp[iI++].value, "%s", dev_info->sw_ver);
    sprintf(array_fvp[iI].fieldname, "%s_%s", IFX_DEVICE_INFO_SECTION, IFX_DEVICE_INFO_MODEMFIRMWAREVERSION);
    sprintf(array_fvp[iI++].value, "%s", dev_info->fw_ver);
    sprintf(array_fvp[iI].fieldname, "%s_%s", IFX_DEVICE_INFO_SECTION, IFX_DEVICE_INFO_PROVISIONINGCODE);
    sprintf(array_fvp[iI++].value, "%s", dev_info->provisioning_info);

    sprintf(array_fvp[iI].fieldname, "%s_%s", IFX_DEVICE_INFO_SECTION, IFX_DEVICE_INFO_SYSCONTACT);
    sprintf(array_fvp[iI++].value, "%s", dev_info->sysContact);
    sprintf(array_fvp[iI].fieldname, "%s_%s", IFX_DEVICE_INFO_SECTION, IFX_DEVICE_INFO_SYSNAME);
    sprintf(array_fvp[iI++].value, "%s", dev_info->sysName);
    sprintf(array_fvp[iI].fieldname, "%s_%s", IFX_DEVICE_INFO_SECTION, IFX_DEVICE_INFO_SYSLOCATION);
    sprintf(array_fvp[iI++].value, "%s", dev_info->sysLocation);
    sprintf(array_fvp[iI].fieldname, "%s_%s", IFX_DEVICE_INFO_SECTION, IFX_DEVICE_INFO_SYSSERVICES);
    sprintf(array_fvp[iI++].value, "%d", dev_info->sysServices);

    count = iI;

    /***  PROLOG BLOCK END  ***/

    /**************** ACL CHECK BLOCK *****************/

    CHECK_ACL_RET(iid, count, array_fvp,
        changed_fcount, array_changed_fvp, flags, IFX_Handler)

    /**************** ACL CHECK BLOCK END *****************/

    /********* SYSTEM CONFIG FILE UPDATE BLOCK  **********/

    /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
    if (IFX_MODIFY_F_SET(flags))
    {
        //form_cfgdb_buf(buf, changed_fcount, array_changed_fvp);
        form_cfgdb_buf(buf, count, array_fvp);
    }
    else
    {
        form_cfgdb_buf(buf, count, array_fvp);
    }

    /* Backup rc.conf before proceeding with configuration */
    CHECKPOINT_RET(flags, FILE_RC_CONF, CHKPOINT_FILE, IFX_Handler)

    /* Update rc.conf */
    ret = ifx_SetObjData(FILE_RC_CONF, IFX_DEVICE_INFO_SECTION, flags, 1, buf);

    /* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
    if(ret != IFX_SUCCESS)
    {
        ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE, flags | IFX_F_INT_DONT_RESTART_SERVICES, IFX_Handler)
    }

    /********* SYSTEM CONFIG FILE UPDATE BLOCK END **********/

    /************ DEVICE CONFIGURATION BLOCK ***********/
    /************ DEVICE CONFIGURATION BLOCK END ***********/

    /**************** NOTIFICATION BLOCK ******************/

    /* Notify the Internal TR69 Stack */
    CHECK_N_SEND_NOTIFICATION (iid, changed_fcount, array_changed_fvp, flags, IFX_Handler)

    /**************** NOTIFICATION BLOCK ******************/

    /***************** EPILOG BLOCK **********************/
    ret = ifx_config_write(FILE_RC_CONF, flags);
    if(ret != IFX_SUCCESS)
    {
        ROLLBACK_CFG_DB_RET(FILE_RC_CONF, CHKPOINT_FILE, flags | IFX_F_INT_DONT_RESTART_SERVICES, IFX_Handler)
    }
    /***************** EPILOG BLOCK END **********************/

IFX_Handler:
    IFX_MEM_FREE(array_changed_fvp)
    if(ret != IFX_SUCCESS)
        return ret;
    else
        return IFX_SUCCESS;
}
