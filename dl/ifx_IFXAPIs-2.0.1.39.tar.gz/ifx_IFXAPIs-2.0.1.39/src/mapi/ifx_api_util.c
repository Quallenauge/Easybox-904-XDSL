/* 
** =============================================================================
**   FILE NAME        : ifx_api_util.c
**   PROJECT          : AMAZON MAPI
**   DATE             : 19-Jun-2006
**   AUTHOR           : Amazon API Team
**   DESCRIPTION      : This file contains the Utility Routines required to support
			the MAPI framework

**   REFERENCES       : 
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <fcntl.h>
#include <ifx_config.h>
#include <ifx_common.h>
#include <ifx_amazon_cfg.h>
#include "ifx_emf.h"
#include "ifx_config.h"
#include "ifx_api_include.h"

char *stritoa(int n, char *string, int width)
{
	char	*cp, *lim, *s;
	char	buf[16];						/* Just temp to hold number */
	int		next, minus;

	a_assert(string && width > 0);

	if (string == NULL) {
		if (width == 0) {
			width = 10;
		}
		if ((string = malloc(width + 1)) == NULL) {
			return NULL;
		}
	}
	if (n < 0) {
		minus = 1;
		n = -n;
		width--;
	} else {
		minus = 0;
	}

	cp = buf;
	lim = &buf[width - 1];
	while (n > 9 && cp < lim) {
		next = n;
		n /= 10;
		*cp++ = (char) (next - n * 10 + '0');
	}
	if (cp < lim) {
		*cp++ = (char) (n + '0');
	}

	s = string;
	if (minus) {
		*s++ = '-';
	}

	while (cp > buf) {
		*s++ = *--cp;
	}

	*s++ = '\0';
	return string;
}


/******************************************************************************/
/*
 *	Trace log. Customize this function to log trace output
 */

void trace(int level, char *fmt, ...)
{
	va_list 	args;

	va_start(args, fmt);
	va_end(args);
}


int32 ifx_get_runtime_gw(char8 *sGW)
{
	char8	sCommand[MAX_FILELINE_LEN];

	sprintf(sCommand, "%s", "route -n | grep '^0.0.0.0' | tr -s \"\\n\" \" \" | cut -d ' ' -f 2");

	if(ifx_GetObjData(sCommand, NULL, "1", IFX_F_GET_ANY, NULL, sGW) != IFX_SUCCESS)
		return IFX_FAILURE;

	return IFX_SUCCESS;
}


int32 ifx_get_runtime_dns(char8 *sDNS, char8 *nLine)
{
	FILE *fp = fopen("/etc/resolv.conf", "r");

	if(fp == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
	}

	fscanf(fp, "nameserver %s\n", sDNS);
	if(nLine[0] == '2')
		fscanf(fp, "nameserver %s", sDNS);

	if(fp)
		fclose(fp);
	return IFX_SUCCESS;
}


int32 ifx_get_runtime_dnsv6(char8 *sDNSv6, char8 *nLine)
{
        FILE *fp = fopen("/var/resolv6.conf", "r");

        if(fp == NULL) {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                return IFX_FAILURE;
        }

        fscanf(fp, "nameserver %s\n", sDNSv6);
        if(nLine[0] == '2')
                fscanf(fp, "nameserver %s", sDNSv6);

        if(fp)
                fclose(fp);
        return IFX_SUCCESS;
}

int32 GetLanIface(int32 index,char8 *name)
{
#ifdef CONFIG_FEATURE_IFX_WIRELESS_ATH
    char8    sValue[MAX_DATA_LEN];
	int		ret = IFX_SUCCESS;
    memset(sValue,'\0',sizeof(sValue));
    if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_STATUS, "wlan_enable", 0, NULL, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			return ret;
	}
    else {
        if (!strcmp(sValue,"1")) {
            sprintf(name,"%s",IFX_BRIDGE_IF);
    	}
        else {
            sprintf(name,"%s",IFX_BRIDGE_IF);
        }
    }
#endif
     sprintf(name,"%s",IFX_BRIDGE_IF);
     return 0;
}


/* Pramod - shud b written on lines of websGetWanMode */
int32 GetWanMode(int32 nWAN_IDX)
{
	uint32	outFlag = IFX_F_DEFAULT;
	char8	sCFG_NAME[MAX_FILELINE_LEN], sAtmProto[MAX_FILELINE_LEN], sAddrType[MAX_FILELINE_LEN];

	sprintf(sCFG_NAME, "wan_%d_linkType", nWAN_IDX);
	if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, sCFG_NAME, IFX_F_DEFAULT, &outFlag, sAtmProto) != IFX_SUCCESS) {
		return IFX_FAILURE;
	}
	else {
		if ((atoi(sAtmProto) == LINK_TYPE_EOATM) ||
						(atoi(sAtmProto) == LINK_TYPE_IPOATM)) {

			sprintf(sCFG_NAME, "wanip_%d_addrType", nWAN_IDX);
			if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, sCFG_NAME, IFX_F_DEFAULT, &outFlag, sAddrType) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("\n\n In Function [%s] : Error--> Trying to get [%s] in [%s] !!\n\n",
									__FUNCTION__, sCFG_NAME, FILE_RC_CONF);
#endif
					return IFX_FAILURE;
			}
			if(atoi(sAddrType) == IP_TYPE_STATIC) // wan type is static
				return IP_BOOT_FIXED;
			else if(atoi(sAddrType) == IP_TYPE_DHCP) // wan type is dynamic
				return IP_BOOT_DHCPC;
			else if(atoi(sAddrType) == IP_TYPE_AUTO) // wan type is bridged
				return IP_BOOT_BRIDGE;
		}
		else if (atoi(sAtmProto) == LINK_TYPE_CLIP) {
			return IP_BOOT_FIXED;
		}
		else if (atoi(sAtmProto) == LINK_TYPE_PPPOE) {
			return IP_BOOT_PPPOE;
		}
		else if (atoi(sAtmProto) == LINK_TYPE_PPPOATM) {
			return IP_BOOT_PPPOA;
		}
    else if (atoi(sAtmProto) == LINK_TYPE_ETH) {
      return IP_BOOT_ETH;
    }  
    else if (atoi(sAtmProto) == LINK_TYPE_PTM) {
      return IP_BOOT_PTM;
    }  
		else {
			return IP_BOOT_UNKNOWN;
		}
	}
	return IP_BOOT_UNKNOWN;
}


int32 GetWanIface(int32 nWAN_IDX, char8 *IFName)
{
	int32	ret = IFX_SUCCESS;
	uint32	outFlag = IFX_F_DEFAULT;
    char8	sConnName[MAX_NAME_LEN];
    char8	sCFG_NAME[MAX_FILELINE_LEN];

	sConnName[0]='\0';
	sCFG_NAME[0]='\0';

	sprintf(sCFG_NAME, "wan_%d_connName", nWAN_IDX);
	if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, sCFG_NAME, IFX_F_GET_ANY, &outFlag, sConnName)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	if((ret = ifx_get_wan_ifname_from_connName(sConnName, IFName)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

IFX_Handler:
	if(ret != IFX_SUCCESS) {
		sprintf(IFName, "%s", "\0");
		return ret;
	}
	else
		return IFX_SUCCESS;
}


int32 ifx_get_sec_instance_count(char8 *sec_name, uint32 *count)
{
	uint32	outFlag = IFX_F_DEFAULT;
	char8	sValue[MAX_FILELINE_LEN]={0};
        char8   sCountStr[MAX_FILELINE_LEN]={0};
        memset(sValue,'\0',sizeof(sValue));

	*count = 0;

        if (!sec_name)
        {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
        }

        sprintf(sCountStr,"%s_%s",sec_name,"Count");
	if(ifx_GetObjData(FILE_RC_CONF, sec_name, sCountStr, IFX_F_GET_ENA, &outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
	}
	*count = atoi(sValue);

	return IFX_SUCCESS;
}

int32 ifx_get_wan_conn_device_count(uint32 *count)
{
	uint32	outFlag = IFX_F_DEFAULT;
	char8	sValue[MAX_FILELINE_LEN];

        memset(sValue,'\0',sizeof(sValue));
	*count = 0;
	if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_CONN_DEVICE, "wan_conndev_Count", IFX_F_GET_ENA, &outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
	}
	*count = atoi(sValue);

	return IFX_SUCCESS;
}


int32 ifx_get_IID(IFX_ID *passed_iid, char8 *distinct_param)
{
	int32	ret = IFX_SUCCESS;
	IFX_ID	iid, piid;

	memset(&iid, 0x00, sizeof(iid));
	memset(&piid, 0x00, sizeof(piid));

    IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
	/* it is mandatory for the caller to pass the parent cpeid of this vcc which is the wan connection device instance
	 * otherwise there is no means for this api to find the parent cpeid from the vcc */
	iid.config_owner = passed_iid->config_owner;
	sprintf(iid.tr69Id, "%s", passed_iid->tr69Id);
	sprintf(iid.cpeId.secName, "%s", passed_iid->cpeId.secName);
	sprintf(iid.pcpeId.secName, "%s", passed_iid->pcpeId.secName);

	piid.cpeId.Id = passed_iid->pcpeId.Id;
	sprintf(piid.cpeId.secName, "%s", passed_iid->pcpeId.secName);

	if (ifx_get_iid(iid.cpeId.secName, piid.cpeId.secName, &piid, &iid) != IFX_SUCCESS) {
    IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
#if 0
	if(ifx_alloc_tr69id(&iid, distinct_param) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
#endif // 0
	IFX_ALLOC_TR69ID(iid, distinct_param, IFX_Handler);
	passed_iid->cpeId.Id = iid.cpeId.Id;
	sprintf(passed_iid->tr69Id, "%s", iid.tr69Id);

IFX_Handler:
	if(ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}


int32 ifx_get_IID_Without_TR69(IFX_ID *passed_iid, char8 *distinct_param)
{
	int32	ret = IFX_SUCCESS;
	IFX_ID	iid, piid;

	memset(&iid, 0x00, sizeof(iid));
	memset(&piid, 0x00, sizeof(piid));

	/* it is mandatory for the caller to pass the parent cpeid of this vcc which is the wan connection device instance
	 * otherwise there is no means for this api to find the parent cpeid from the vcc */
	iid.config_owner = passed_iid->config_owner;
	sprintf(iid.tr69Id, "%s", passed_iid->tr69Id);
	sprintf(iid.cpeId.secName, "%s", passed_iid->cpeId.secName);
	sprintf(iid.pcpeId.secName, "%s", passed_iid->pcpeId.secName);

	piid.cpeId.Id = passed_iid->pcpeId.Id;
	sprintf(piid.cpeId.secName, "%s", passed_iid->pcpeId.secName);

	if (ifx_get_iid(iid.cpeId.secName, piid.cpeId.secName, &piid, &iid) != IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
#if 0
	if(ifx_alloc_tr69id(&iid, distinct_param) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
#endif // 0
//	IFX_ALLOC_TR69ID(iid, distinct_param, IFX_Handler);
	passed_iid->cpeId.Id = iid.cpeId.Id;
//	sprintf(passed_iid->tr69Id, "%s", iid.tr69Id);

IFX_Handler:
	if(ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* build_route_add_command(...)
*		ipaddr		==>   IP Address in String Format 
*    	netmask		==>   Natmask in String Format
*    	gw			==>   Gatway in String Format
*		iface		==>	  Interface Name
*		metric		==>   Metric
*		sCommand	==>	  the route add command for the given params
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function takes the arguments required to build an Add command for a Route,
			and returns the command built
*//////////////////////////////////////////////////////////////////////////////
int32 build_route_command(char8 *ipaddr, char8 *netmask, char8 *gw, char8 *iface,
				int32 metric, int32 type, char8 *sCommand, char8 *operation)
{
	char8	sbuf1[MAX_FILELINE_LEN], sbuf2[MAX_FILELINE_LEN], ip[MAX_IP_ADDR_LEN];
	int32	ret = IFX_SUCCESS;

	sbuf1[0]='\0';
	sbuf2[0]='\0';
	ip[0]='\0';

	/* Route is default if IP Address is 0.0.0.0 or not specified */
	if( type == ROUTE_TYPE_DEFAULT ) {
		if(strlen(iface))
			sprintf(sbuf2, "default dev %s", iface);
		else if( strlen(gw) || strcmp(gw, "0.0.0.0") )
			sprintf(sbuf2, "default gw %s", gw);
	}
	/* Route can be either host or net */
	else {
		sprintf(ip, "%s", ipaddr);
#if 0
	irrespective of route type use the netmask passed by the caller
	host route can be added with -net option also
		if( type == ROUTE_TYPE_HOST ) {
			sprintf(sbuf2, "%s", ip);
		}
		else {
			ipaddr1 = strtok(ipaddr, ".");
			ipaddr1 = strtok(NULL, ".");
			ipaddr1 = strtok(NULL, ".");
			ipaddr1 = strtok(NULL, ".");
			if(!strcmp(ipaddr1, "0")) {
				sprintf(sbuf2, "-net %s netmask %s", ip, netmask);
			}
			else {
				sprintf(sbuf2, "%s", ip);
			}
		}
#endif

		sprintf(sbuf2, "-net %s netmask %s", ip, netmask);

		if( strlen(gw) > 0 && strcmp(gw, "0.0.0.0"))
			snprintf(sbuf1,sizeof(sbuf1), " gw %s ", gw);
		else if( strlen(iface) > 0 )
			snprintf(sbuf1,sizeof(sbuf1), " dev %s", iface);

		strlcat(sbuf2, sbuf1,sizeof(sbuf2));
	}

	if( metric > 0 ) {
		sprintf(sbuf1, " metric %d", metric);
		strcat(sbuf2, sbuf1);
	}

	if(!strcmp(operation, "add"))
		sprintf(sCommand, "route add %s 2> /dev/null", sbuf2);
	else if(!strcmp(operation, "del"))
		sprintf(sCommand, "route del %s 2> /dev/null", sbuf2);

	return ret;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_maxLeases(...)
*		ipaddr		==>   IP Address in String Format 
*    	netmask		==>   Natmask in String Format
*    	gw			==>   Gatway in String Format
*		iface		==>	  Interface Name
*		metric		==>   Metric
*		sCommand	==>	  the route del command for the given params
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function takes the arguments required to build an Delete command for a Route,
			and returns the command built
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_maxLeases(struct in_addr start_ip, struct in_addr end_ip, int *maxLeases)
{
	char8	*s_ip = NULL, *e_ip = NULL, *temp_ip1 = NULL;
	char8	*temp_ip2 = NULL, *sValue1 = NULL, *sValue2 = NULL;
    int32	nStart = 0, nEnd = 0;

    s_ip = (char8 *)inet_ntoa(start_ip);

	/* Get the last octet of start ip address in nStart */
    temp_ip1 = strstr(s_ip, ".");
    while(temp_ip1 != NULL) {
            sValue1 = temp_ip1 + 1;
            temp_ip1 = strstr(temp_ip1 + 1, ".");
    }
    if(sValue1 != NULL)
        nStart = atoi(sValue1);

	/* Get the last octet of end ip address in nEnd */
    e_ip = (char8 *)inet_ntoa(end_ip);
    temp_ip2 = strstr(e_ip, ".");
    while(temp_ip2 != NULL) {
            sValue2 = temp_ip2 + 1;
            temp_ip2 = strstr(temp_ip2 + 1, ".");
    }
    if(sValue2 != NULL)
    nEnd = atoi(sValue2);

    *maxLeases = (nEnd - nStart) +1;

    return IFX_SUCCESS;

}


/*//////////////////////////////////////////////////////////////////////////////
* get_wan_indices(...)
*    	wan_index	==>  input wan indices sring each seperated by ","
*    	count		==>  count of the wan indices in the input wan_index
*		idx_array			==>  output array in which each array element is a wan index
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
	Description:
		This function takes the input string wan_index, parses them based on the 
		character "," and stores each such index in the ouput integer array idx_array
*//////////////////////////////////////////////////////////////////////////////
int32 get_wan_indices(char8 *wan_index, int32 *count, int32 **idx_array)
{
	int32	t_count = 0;
	char8	*sIdx = NULL, sIndexes[256];
	int32	*t_array = NULL, *t_ptr = NULL, ret = IFX_SUCCESS;

	/* copy the input wan_index string into local string for tokenizing */
	t_count = 0;
	sprintf(sIndexes, "%s", wan_index);
 	sIdx = strtok(sIndexes, ",");

	*idx_array = NULL;

	/* copy each of the token in the wan_index string into the local array */
	while(sIdx != NULL) {
		t_ptr = (int32 *)realloc(t_array, (t_count + 1) * sizeof(int32));

		if(t_ptr == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}

		t_array = t_ptr;

		*(t_array + t_count) = atoi(sIdx);
		t_count++;
	 	sIdx = strtok(NULL, ",");
	}

	/* copy the local count and array of wan indices to the output arguments */
	*count = t_count;
	*idx_array = t_array;

IFX_Handler:
	if(ret != IFX_SUCCESS) {
		*count = 0;
		IFX_MEM_FREE(t_array)
		return ret;
	}
	else
		return IFX_SUCCESS;
}


#if 0
/* ???? */
/*//////////////////////////////////////////////////////////////////////////////
* cfg_default_rollback_fn(...)
*	rollback_reason		==>		
*	stop_conf			==>		
*	start_conf			==>		
*	flags				==>
* 
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
*////////////////////////////////////////////////////////////////////////////////
int32 cfg_default_rollback_fn(char8 *rollback_reason, char8 *stop_conf, 
	char8 *start_conf, uint32 flags) 
{
	if (rollback_reason) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	/* Restore from checkpointed file */
	if(stop_conf)
		ifx_config_write(stop_conf, flags |IFX_F_DONT_WRITE_TO_FLASH |
					IFX_F_INT_RESTORE);

	/* Call stop services as required. A special script may also be made
	 * here*/
	if (IFX_INT_DONT_RESTART_SERVICES_F_NOT_SET(flags)) {
		/* service stop command to go here */
	}

	/* Restore from checkpointed file */
	if(start_conf)
		ifx_config_write(start_conf, flags |IFX_F_DONT_WRITE_TO_FLASH |IFX_F_INT_RESTORE);

	/* XXX: We may not need to start services if caller passed
	 * DONT_CHECKPOINT */
	/* Start service back again. A special script may also be made
	 * here */
	if (IFX_INT_DONT_RESTART_SERVICES_F_NOT_SET(flags)) {
		/* service start command to go here */
	}

	return IFX_SUCCESS;
}


/* ???? */
/*//////////////////////////////////////////////////////////////////////////////
* rollback_configuration(...)
*	fptr		==>		
*	data		==>		
*	stop_conf	==>
*	start_conf	==>
*	func		==>
*	flags		==>
* 
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
*////////////////////////////////////////////////////////////////////////////////
int32 rollback_configuration(ROLLBACK_FN fptr, void *data, char8 *stop_conf, char8 *start_conf, char8 *func, uint32 flags)
{
	int32 ret = 0;

	if (IFX_DONT_CHECKPOINT_F_SET(flags)) {  //DONT_CHECKPOINT Flag set
		return (IFX_SUCCESS); /* Skip */

	}
	if (fptr == NULL) {
		fptr = (ROLLBACK_FN) cfg_default_rollback_fn;
	}

	ret =  (fptr(data, stop_conf, start_conf, flags));
	
	if (ret == IFX_FAILURE) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	} else {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}

	return (ret);
}
#endif // 0


/*//////////////////////////////////////////////////////////////////////////////
* form_cfgdb_buf(...)
*    	array_fvp	==>  Array of fvps
*    	count		==>  count of the fvps in array_fvp
*		buf			==>  Buffer to which the fvps seperated by \n are stored
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function takes the fvps from the array array_fvp and builds a buffer
			of the form fname1=fvalue1\nfname2=fvalue2\n....
*//////////////////////////////////////////////////////////////////////////////
int32 form_cfgdb_buf(char8 *buf, int32 count, IFX_NAME_VALUE_PAIR array_fvp[])
{
	int32	ret = IFX_SUCCESS, i;
	char8	buf_line[MAX_DATA_LEN];
	char8	*t_buf = NULL;

	IFX_MEM_ALLOC(t_buf, char *, 1, (MAX_DATA_LEN * MAX_FILELINE_LEN * sizeof(char)))

	for(i=0; i<count; i++) {
		buf_line[0]='\0';
		sprintf(buf_line, "%s=\"%s\"\n", array_fvp[i].fieldname, array_fvp[i].value);
		strcat(t_buf, buf_line); 
	}
	sprintf(buf, "%s", t_buf);

IFX_Handler:
	IFX_MEM_FREE(t_buf)
	if(ret != IFX_SUCCESS)
		return IFX_FAILURE;
	else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* form_array_fvp_from_cfgdb_buf(...)
*		buf_org		==>  Buffer having the fvp seperated by \n
*    	filecount	==>  Count of fvp in buf_org 
*    	file_array_fvp   ==>  Array of fvp built out of buf_org
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function takes the buffer having multiple fvp seperated by \n
			parses the buffer to store fieldname and fieldvalue in file_array_fvp
			also returns the count of fvp converted in file_array_fvp
*//////////////////////////////////////////////////////////////////////////////
int32 form_array_fvp_from_cfgdb_buf(char8 *orig_buf, int32 *filecount, IFX_NAME_VALUE_PAIR *file_array_fvp)
{

	/* parse the buf (n1=v1\nn2=v2\n....) into file_array_fvp */
	char	*buf_part, t_buf[MAX_DATA_LEN], *value = NULL;
	char8  *buf = orig_buf;
	int	i = 0, ret = IFX_SUCCESS;

	buf_part = strstr(buf, "\n") + 1;
	t_buf[0]='\0';

	i = 0;
	while(buf_part != NULL) {

		//*file_array_fvp = (IFX_NAME_VALUE_PAIR **)realloc(*file_array_fvp, sizeof(IFX_NAME_VALUE_PAIR));
		// NOT REQUIRED - memset(t_buf, 0x00, sizeof(t_buf));
		memset(t_buf, 0x00, sizeof(t_buf));
		STRNCPY(t_buf, buf, strlen(buf) - strlen(buf_part));
		value = strtok(t_buf, "=\"");
		sprintf((file_array_fvp+i)->fieldname, "%s", value);
		
		value = strtok(NULL, "=\"");
		//sprintf((*file_array_fvp+i)->value, "%s", value);
		if( (value != NULL ) && strcmp(value, "\n") && value[0] != ' '
				&& value[0])
			sprintf(file_array_fvp[i].value, "%s", value);
		i++;
		buf = buf_part;
		if(buf[0]) {
			buf_part = strstr(buf, "\n");
			if (buf_part)
				buf_part = buf_part + 1;
			
		} else {
			buf_part = NULL;
		}

	}

	*filecount = i;

	if(ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_cmp_and_return_changed_fvp(...)
*		fcount   		==>  Count of the number of fields
*    	old_array_fvp 	==>  Array of Old field name values from rc.conf
*    	new_array_fvp  	==>  Array of New field name values from the API structure
*		changed_fcount	==>	 Count of the changed FV pairs
*		changed_array_fvp ==> Array of field name values modified from the API
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function compares the RC.CONF field value pairs(fvp) with the 
			API fvp and returns the number of fvp modified by the API and the 
			set of modified fvp in an array
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_cmp_and_return_changed_fvp(char8 *secName, int32 fcount, IFX_NAME_VALUE_PAIR old_array_fvp[],
					int32 *changed_fcount, IFX_NAME_VALUE_PAIR **changed_array_fvp)
{

	int		i;
	int		tmp_count = 0;
	int		ret = IFX_SUCCESS, outflag = IFX_F_DEFAULT;
	char	buf[MAX_DATA_LEN], sValue[MAX_FILELINE_LEN];
	IFX_NAME_VALUE_PAIR *t_ptr = NULL;

	buf[0]='\0';
        memset(sValue,'\0',sizeof(sValue));
	
	*changed_array_fvp = NULL;

	for(i=0; i<fcount; i++) {
		/* Compare the field name - if same then check on the values */
		if(strstr(old_array_fvp[i].fieldname, "_pcpeId")){
			/* Parent cpeid is not taken into account for comparison */
		}
		else {
			if((ret = ifx_GetObjData(FILE_RC_CONF, secName, old_array_fvp[i].fieldname, IFX_F_GET_ANY, (IFX_OUT uint32 *)&outflag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				return IFX_FAILURE;
			}
			if (strcmp(old_array_fvp[i].value, sValue)) {
				t_ptr = (IFX_NAME_VALUE_PAIR *)realloc(*changed_array_fvp,
											(tmp_count + 1) * sizeof(IFX_NAME_VALUE_PAIR));

				if(t_ptr == NULL) {
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}

				*changed_array_fvp = t_ptr;

				sprintf((*changed_array_fvp+tmp_count)->fieldname, "%s", old_array_fvp[i].fieldname);
				sprintf((*changed_array_fvp+tmp_count)->value, "%s", old_array_fvp[i].value);
				tmp_count++;
			}
		}
	}

	*changed_fcount = tmp_count;
IFX_Handler:
	if(ret != IFX_SUCCESS) {
		*changed_fcount = 0;
		IFX_MEM_FREE(*changed_array_fvp)
		return ret;
	}
	else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_index_from_sec_count(...)
*		filename   ==>    File Name
*    	sectionName	==>  Section Tag in File  
*    	ret_index   ==>  Return index
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function returns the index to be associated with any
			new entry which needs to be added into rc.conf. 
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_index_from_sec_count(char8 *filename, char8 *sectionName, int32 *ret_index, uint32 flags)
{

	char	buf[MAX_FILELINE_LEN], sValue[MAX_NAME_SIZE];
	uint32	outflag = 0, inflag = flags;

	buf[0]='\0';
        memset(sValue,'\0',sizeof(sValue));
	
	MAKE_SECTION_COUNT_TAG(sectionName, buf)

	if (ifx_GetObjData(filename, sectionName, buf, inflag, (IFX_OUT uint32 *)&outflag, sValue) == IFX_SUCCESS) {
		*ret_index = atoi(sValue);
		return IFX_SUCCESS;
	}

	*ret_index = -1;

#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	return IFX_FAILURE;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_index_from_cpe_id(...)
*		filename   ==>    File Name
*    	sectionName	==>  Section Tag in File  
*    	ret_index   ==>  Return index
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function returns the index to be associated with any
			new entry which needs to be added into rc.conf. 
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_index_from_cpe_id(char8 *filename, 
					CPE_ID *cpe_id, int32 *ret_index)
{

	char	*buf=NULL;
	char	sub[MAX_FILELINE_LEN];
	char	*ret_pos, dst[MAX_SECTION_DATA_LEN];
	int	ch = '_';
	int32	ret = IFX_SUCCESS;

	sub[0]='\0';
	dst[0]='\0';
	
	sprintf(sub, "_cpeId=\"%d\"\n", cpe_id->Id);

	if((ret = ifx_GetCfgObject(filename, cpe_id->secName, NULL, IFX_F_GET_ANY, &buf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] return value [%d] secName [%s]", __FUNCTION__, __LINE__, ret, cpe_id->secName);
#endif
		return IFX_FAILURE;
	}
	
	ret_pos = strstr(buf, sub);
	if(ret_pos != NULL) {
		STRNCPY(dst, buf, strlen(buf) - strlen(ret_pos));
		*ret_index = atoi(strrchr(dst, ch) + 1);
        IFX_MEM_FREE(buf);
        return IFX_SUCCESS;
	}

	/* Failed to find the CPEID in buf */
	*ret_index = -1;
    IFX_MEM_FREE(buf);
			IFX_DBG("[%s:%d] return failure", __FUNCTION__, __LINE__);
    return IFX_FAILURE;
}
/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_index_from_pcpe_id(...)
*		filename   ==>    File Name
*    	sectionName	==>  Section Tag in File  
*    	ret_index   ==>  Return index
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function returns the index to be associated with any
			new entry which needs to be added into rc.conf. 
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_index_from_pcpe_id(char8 *filename, CPE_ID *pcpe_id, int32 *ret_index)
{

	char	*buf = NULL;
	char	sub[MAX_FILELINE_LEN];
	char	*ret_pos, dst[MAX_SECTION_DATA_LEN];
	int	ch = '_';
	int32	ret = IFX_SUCCESS;

	sub[0]='\0';
	dst[0]='\0';

   /* we will try to find the pcpeId in the parent object, i.e. cpeID */
	sprintf(sub, "_cpeId=\"%d\"\n", pcpe_id->Id);

   /* get the parent object */
	if((ret = ifx_GetCfgObject(filename, pcpe_id->secName, NULL, IFX_F_GET_ANY, &buf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] return value [%d]", __FUNCTION__, __LINE__, ret);
#endif /* #ifdef IFX_LOG_DEBUG */
		return IFX_FAILURE;
	}

	ret_pos = strstr(buf, sub);
	if(ret_pos != NULL) {
		STRNCPY(dst, buf, strlen(buf) - strlen(ret_pos));
		*ret_index = atoi(strrchr(dst, ch) + 1);
      IFX_MEM_FREE(buf);
      return IFX_SUCCESS;
	}

	/* Failed to find the CPEID in buf */
   *ret_index = -1;
   IFX_MEM_FREE(buf);
   return IFX_FAILURE;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_conf_index_and_nv_pairs(...)
*    	iid			==>  IID strcture with cpeId set
*    	passed_index	==> the index of this obejct within the section 
*		field_prefix	==>	field prefix of this object in rc.conf
*		count			==>	Count of fvps
*		array_fvp		==>	Actual array formed out of the structure in case of add and modify, 
*							formed out of rc.conf in case of delete. This array has fully qualified
*							fieldname, value pairs
*		flags			==>	Flags
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
				This function needs to be invoked for sections that have multiple instances (indexes).
				It returns the rc.conf index and the fully qualified field value pairs 
				(i.e fieldprefix_index_fieldname) in array_fvp itself
				Ex. StaticRoute_0_dst
				array_fvp will have only fieldnames when called i.e dst 
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_conf_index_and_nv_pairs(IFX_ID *iid, int32 passed_index, 
		char8 *field_prefix, int32 count, IFX_NAME_VALUE_PAIR *array_fvp, 
		uint32 flags) 
{
	char	*retString = NULL, *indexStr = NULL;
	char	buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN], cpeIdStr[MAX_FILELINE_LEN];
	char	*delbuf = NULL;
	int		i = 0, ret = IFX_SUCCESS;
	uint32	inflag = IFX_F_GET_ANY, outflag = 0;

	buf[0]='\0';
        memset(sValue,'\0',sizeof(sValue));
	cpeIdStr[0]='\0';

	/** Caller of this function may or may not pass the 
          passed_index. The function handles both cases */
	 if (passed_index < 0) {
		if (IFX_INT_ADD_F_SET(flags)) {

			/* Get index value from Section Count if it exists */
			if ((ret = (ifx_get_index_from_sec_count(FILE_RC_CONF, iid->cpeId.secName, 
							&passed_index, flags))) != IFX_SUCCESS)
				return ret;
		}
		else if ((IFX_DELETE_F_SET(flags)) || (IFX_MODIFY_F_SET(flags))) {
			/* Using the cpeID field, get the index value from rc.conf */
			sprintf(cpeIdStr, "%d", iid->cpeId.Id);
			if (ifx_ret_substr_from_distfield(FILE_RC_CONF, iid->cpeId.secName, "cpeId",
							cpeIdStr, &retString) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] cpe id not found [%s]", __FUNCTION__, __LINE__, cpeIdStr);
#endif
				IFX_MEM_FREE(retString);
				return IFX_FAILURE;
			}
			else {
				/* Update the passed index */
				indexStr = strrchr(retString,'_') + 1;
				if(indexStr != NULL)
					passed_index = atoi(indexStr);
			}
			
		}
	}
	else {
		/* Index is passed */
		if ((IFX_DELETE_F_SET(flags)) || (IFX_MODIFY_F_SET(flags))) {
				/* Check the index match against the passed CPEID */
			if (iid->cpeId.Id != 0) { 
				FORM_CFG_TAG(buf, field_prefix, passed_index, "cpeId")

				if ((ret = ifx_GetObjData(FILE_RC_CONF, iid->cpeId.secName,
							buf, inflag, &outflag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] tag [%s] not found in [%s]", __FUNCTION__, __LINE__, buf, iid->cpeId.secName);
#endif
					return ret;
				}

				/*if cpeID read from config file dont match with passed */
				if (iid->cpeId.Id !=  atoi(sValue)) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] cpeid [%d] cpeid [%d]", __FUNCTION__, __LINE__, iid->cpeId.Id, atoi(sValue));
#endif
				return IFX_FAILURE;
				}
			}
		}
	}

	if (IFX_DELETE_F_SET(flags)) {
		/* Get the data to be deleted */
		buf[0]='\0';
		FORM_CFG_TAG(buf, field_prefix, passed_index, "\0") 
	
		if ((ret = (ifx_GetCfgObject(FILE_RC_CONF, iid->cpeId.secName,	buf, 
				IFX_F_GET_ANY, &delbuf))) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] object [%s] not found in [%s]", __FUNCTION__, __LINE__, buf, iid->cpeId.secName);
#endif
			IFX_MEM_FREE(retString)
			return ret;
		}
		else
			form_array_fvp_from_cfgdb_buf(delbuf, &count, array_fvp);
	}
	else {
		/* Form the array of Fully Qualified Name Value pairs */
	    for (i=0; i<count; i++) {
		  strcpy(buf, array_fvp[i].fieldname);
	
		  snprintf(array_fvp[i].fieldname,MAX_TAG_NAME_LEN,"%s_%d_%s",
                         field_prefix, passed_index, buf);
		}
	}

	IFX_MEM_FREE(delbuf)
	IFX_MEM_FREE(retString)
	return IFX_SUCCESS;
}


/* ???? */
/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_obj_instances_count(...)
*	pFilename		==>		input file name of configuration file
*	pTag			==>		
*	flag			==>
*	retNum			==>
* 
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
*////////////////////////////////////////////////////////////////////////////////
int32 ifx_get_obj_instances_count(IFX_IN  char8*   pFileName,
                                IFX_IN  char8*   pTag,
                                IFX_IN  uint32   flag,
                                IFX_OUT int32    *retNum)
{
   char8     *secBuf, *pStr, *pString, *pString1;
   char8      instBuf[BUF_SIZE_1K]; //Instance buffer enough to hold one full instance.
   int32      count=0;
 
 
 
   if (!pTag)
      return IFX_E_INVALID_INPUT; //Could return even IFX_FAILURE.
 
   /* First Read the whole section in secBuf for the given tag */
   if (!(ifx_GetCfgObject(pFileName, pTag, NULL, IFX_F_GET_ANY, &secBuf)))
   {
       pString = secBuf;
 
       while ((pString1 = strstr(pString, "_cpeId")) != NULL)
       {
			instBuf[0]='\0';
            memcpy(instBuf, pString, pString1-pString+1);
            instBuf[pString1-pString+1] = '\0';
            if ((pStr = strrchr(instBuf,'\n')) != NULL) {
                   if (*(pStr + 1) == '#')  {
                     if (*(pStr + 2) == '$')  {
                        if ((flag == IFX_F_GET_INCOMP) || (flag == IFX_F_GET_ANY))
                           count++;
                     }
                     else {
                        if ((flag == IFX_F_DEFAULT) ||
                                (flag == IFX_F_GET_DIS) ||
                                         (flag == IFX_F_GET_ANY))
                           count++;
                     }
                  }
                 else {
                    if ((flag == IFX_F_DEFAULT) ||
                            (flag == IFX_F_GET_ENA) ||
                                   (flag == IFX_F_GET_ANY))
                          count++;
                }
             }
             pString = strchr(pString1,'\n');
	    if(pString == NULL) 
		break;
      } /* while */
      *retNum = count;
 
		IFX_MEM_FREE(secBuf)
      return IFX_SUCCESS;
  }
 
  return IFX_FAILURE;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_increment_next_cpeId(...)
*	filename		==>		input file name of configuration file
*	SectionName		==>		input section name for which the nextCpeId has to be incremented
* 
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function increments the nextCpeId for the input SectionName under the next_cpe_id
			section in filename. This function should be used only after successful addition of
			object instance for the sections that support multiple object instances.
*////////////////////////////////////////////////////////////////////////////////
int32 ifx_increment_next_cpeId(char8 *filename, char8 *SectionName)
{
        char  sCommand[MAX_FILELINE_LEN], sValue[MAX_NAME_SIZE];
        int     ret = IFX_SUCCESS, cpeID = 0;
		int32 outflags = IFX_F_DEFAULT;

	memset(sCommand,'\0',sizeof(sCommand));
	memset(sValue,'\0',sizeof(sValue));

        sprintf(sCommand, "%s_nextCpeId", SectionName);
        if ( (ret = ifx_GetObjData(filename, TAG_NEXT_CPEID, sCommand, IFX_F_DEFAULT, (IFX_OUT uint32 *)&outflags, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                return ret;
        }
        cpeID = atoi(sValue);
	if(cpeID < 1 || cpeID > 32767)
		return IFX_FAILURE;
        sprintf(sCommand, "%s_nextCpeId=\"%d\"\n", SectionName, cpeID + 1);
        ret = ifx_SetObjData(filename, TAG_NEXT_CPEID, IFX_F_MODIFY, 1, sCommand);
        if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                return ret; 
        }

        return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_iid(...)
*	mySectionName	==>		input section name of the object instance for which the
*							IFX_ID has to retrieved
*	pSectionName	==>		input parent section name of this object instance
*	parent_iid		==>		input parent IFX_ID of this object instance
*	my_id			==>		output IFX_IF of the object instance
* 
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function gets the next cpe id for the section mySectionName in the next_cpe_id
			section in rc.conf and stores it as cpeId for my_id. If both pSectionName and 
			parent_id are specified, the cpeId of parent_id will be copied as pcpeId of my_id. 
*////////////////////////////////////////////////////////////////////////////////
int32 ifx_get_iid(char8 *mySectionName, char8 *pSectionName, IFX_ID *parent_id, IFX_ID *my_id)
{
    char  sCommand[MAX_FILELINE_LEN], sValue[MAX_NAME_SIZE];
	int32 outflags = IFX_F_DEFAULT;
	int     ret = IFX_SUCCESS;

	if (mySectionName == NULL) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
	}

	sCommand[0]='\0';
        memset(sValue,'\0',sizeof(sValue));

	/* Pramod : if cpeid is not greater than zero then 
	 * get new cpeid, otherwise use the input iid itself
	 */
	if(my_id->cpeId.Id <= 0) {
		sprintf(sCommand, "%s_nextCpeId", mySectionName);
		if ( (ret = ifx_GetObjData(FILE_RC_CONF, TAG_NEXT_CPEID, sCommand, 
				IFX_F_DEFAULT, (IFX_OUT uint32 *)&outflags, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			return ret;
		}

		my_id->cpeId.Id = atoi(sValue);
	}

  if (my_id->cpeId.secName != mySectionName)
  {
	    STRNCPY(my_id->cpeId.secName, mySectionName, strlen(mySectionName));
	    my_id->cpeId.secName[strlen(mySectionName)] = '\0';
  }
	if ((pSectionName != NULL) && (parent_id != NULL)) {
		my_id->pcpeId.Id = parent_id->cpeId.Id;
		STRNCPY(my_id->pcpeId.secName, pSectionName, strlen(pSectionName));
		my_id->pcpeId.secName[strlen(pSectionName)] = '\0';
	}
	else {
		my_id->pcpeId.Id = 0;
	}

	return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_ret_substr_from_distfield(...)
*		filename	==>	File name which we need to search for distfield
*		SectionName	==>	 Section Name of this object in rc.conf
*		pDistField	==>	Unique field name of an object in rc.conf
*		pdistVal	==> Unique value for the field name in rc.conf 
*		retString	==> Substring in rc.conf matching the DistField with distVal
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
				This function searches the rc.conf for the given DistField with distValue
				and returns the subString that matches the given set of values
				Ex. wan_Conndev_1_vcc="1/32" will return the substring wan_Conndev_1
				for DistField "vcc" and distVal "1/32". This function will be useful
				in determining the pcpeId and instance index given a unique field in 
				the object.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_ret_substr_from_distfield(char8 *filename, char8 *pSectionName, char8 *pDistField, 
						char8 *distVal,	char8 **retString)
{
	char *buf = NULL, *substr = NULL, *teststr = NULL;
	char *ret_pos = NULL, *dst = NULL;
	char dist_str[MAX_FILELINE_LEN];
	int     ret = IFX_SUCCESS;

	/* Initialize the retString to NULL */
	*retString = NULL;

	if ((pSectionName == NULL) ||
		(pDistField == NULL)) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
	}


	/* Get the whole of Section Data */
	if(ifx_GetCfgObject(filename, pSectionName, NULL, IFX_F_GET_ANY, &buf) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		 ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* Form the distinct parameter string to search for in SectionName */
	dist_str[0]='\0';
	sprintf(dist_str, "_%s=\"%s\"\n", pDistField, distVal);

	/* Search for the distinct string inside the buffer */
	ret_pos = strstr(buf, dist_str);
	if(ret_pos != NULL) {

		/* Alloc memory for retString */
		IFX_MEM_ALLOC(*retString, char *, 1, MAX_FILELINE_LEN * sizeof(char))

		/* Now we would have a substring buffer containing the distinct string */
		IFX_MEM_ALLOC(substr, char *, 1, MAX_SECTION_DATA_LEN * sizeof(char))
		strncpy(substr, buf, strlen(buf) - strlen(ret_pos));
		

		/* In case this is the first string in the section so there'll be no 
		 * "\n". Just check this condition else we get a SIGSEGV error!! */
		IFX_MEM_ALLOC(teststr, char *, 1, MAX_SECTION_DATA_LEN * sizeof(char))
		strncpy(teststr, substr, strlen(substr));
		if (strchr(teststr, '\n') != NULL) {

				/* The previous distinct string would be terminated with a '\n' 
				 * Take the string after '\n' -- which gives the exact match string */
				dst = strrchr(substr, '\n') + 1;
				if (dst != NULL) {
						strncpy(*retString, dst, strlen(dst));
				}
		}
		else {
			/* Substring is the string to be returned! */
			strncpy(*retString, substr, strlen(substr));
		}
	}
	else {
		/* There is no distinct string matching DistField */
		IFX_MEM_FREE(*retString)
		ret = IFX_FAILURE;
	}

IFX_Handler:
	IFX_MEM_FREE(buf)
	IFX_MEM_FREE(substr)
	IFX_MEM_FREE(teststr)
	if(ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}


int32 ifx_ret_substr_from_distfield_with_state(char8 *filename, char8 *pSectionName, char8 *pDistField, 
						char8 *distVal,	char8 **retString, uint32 flags)
{
	char *buf = NULL, *substr = NULL, *teststr = NULL;
	char *ret_pos = NULL, *dst = NULL;
	char dist_str[MAX_FILELINE_LEN];
	int     ret = IFX_SUCCESS;

	/* Initialize the retString to NULL */
	*retString = NULL;

	if ((pSectionName == NULL) ||
		(pDistField == NULL)) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
	}


	/* Get the whole of Section Data */
	if(ifx_GetCfgObject(filename, pSectionName, NULL, flags, &buf) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		 ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* Form the distinct parameter string to search for in SectionName */
	dist_str[0]='\0';
	sprintf(dist_str, "_%s=\"%s\"\n", pDistField, distVal);

	/* Search for the distinct string inside the buffer */
	ret_pos = strstr(buf, dist_str);
	if(ret_pos != NULL) {

		/* Alloc memory for retString */
		IFX_MEM_ALLOC(*retString, char *, 1, MAX_FILELINE_LEN * sizeof(char))

		/* Now we would have a substring buffer containing the distinct string */
		IFX_MEM_ALLOC(substr, char *, 1, MAX_SECTION_DATA_LEN * sizeof(char))
		strncpy(substr, buf, strlen(buf) - strlen(ret_pos));
		

		/* In case this is the first string in the section so there'll be no 
		 * "\n". Just check this condition else we get a SIGSEGV error!! */
		IFX_MEM_ALLOC(teststr, char *, 1, MAX_SECTION_DATA_LEN * sizeof(char))
		strncpy(teststr, substr, strlen(substr));
		if (strchr(teststr, '\n') != NULL) {

				/* The previous distinct string would be terminated with a '\n' 
				 * Take the string after '\n' -- which gives the exact match string */
				dst = strrchr(substr, '\n') + 1;
				if (dst != NULL) {
						strncpy(*retString, dst, strlen(dst));
				}
		}
		else {
			/* Substring is the string to be returned! */
			strncpy(*retString, substr, strlen(substr));
		}
	}
	else {
		/* There is no distinct string matching DistField */
		IFX_MEM_FREE(*retString)
		ret = IFX_FAILURE;
	}

IFX_Handler:
	IFX_MEM_FREE(buf)
	IFX_MEM_FREE(substr)
	IFX_MEM_FREE(teststr)
	if(ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* copy_from_flash(...)
*	filename	==>		input destination file name
* 
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function copies the contents of current flash copy of rc.conf into
			the filename specified.
*////////////////////////////////////////////////////////////////////////////////
void copy_from_flash(char8 *filename)
{
	char sCommand[MAX_DATA_LEN];
	sprintf(sCommand, "copy /flash/rc.conf %s", filename);
	system(sCommand);
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_copy_file(...)
*	src_file	==>		input source file name
*	dst_file	==>		input destination file name
* 
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function copies the contents of src_file into dst_file specified.
*////////////////////////////////////////////////////////////////////////////////
int32 ifx_copy_file(char8 *src_file, char8 *dst_file)
{
	char8	sCommand[MAX_FILELINE_LEN];
	
	sCommand[0]='\0';

	sprintf(sCommand, "cp %s %s", src_file, dst_file);
	system(sCommand);

	return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_config_write(...)
*	file	==>		input file name
*	flags	==>		
* 
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
*////////////////////////////////////////////////////////////////////////////////
int32 ifx_config_write(char8 *file, uint32 flags)
{
	int32	ret = IFX_SUCCESS;

	if (IFX_INT_RESTORE_FROM_FLASH_F_SET(flags)) {  //Restore from flash
		copy_from_flash(FILE_RC_CONF);
	}
	
	if (IFX_DONT_CHECKPOINT_F_NOT_SET(flags)) {   //Checkpoint
		if (file) {
			if((ret = ifx_copy_file(file, FILE_RC_CONF) != IFX_SUCCESS))
				return ret;
		}
	}
	if (IFX_INT_RESTORE_F_SET(flags)) {
		if (file) {
			if((ret = ifx_copy_file(FILE_RC_CONF, file)) != IFX_SUCCESS)
				return ret;
		}
	}

	/* Update FILE_RC_CONF to FLASH */
	if (IFX_DONT_WRITE_TO_FLASH_F_NOT_SET(flags)) {
		ifx_flash_write();
	}

	return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_iid_from_conf(...)
*	iid		==>	output ifx_id structure
*	filename	==>	input file name in which the ifx_id has to be retrieved
*	SectionName	==>	input section name for which the ifx_id has to be retrieved
* 
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function returns the cpeid and parent cpeid for the SectionName specified.
			For those sections which do not support object instances this function when called
			with the section name will return the cpeid and parent cpeid stored at the
			section level.
*////////////////////////////////////////////////////////////////////////////////
int32 ifx_get_iid_from_conf(IFX_ID *iid, char8 *filename, char8 *SectionName)
{
	char 	sCommand[MAX_FILELINE_LEN], sValue[MAX_NAME_SIZE];
	int	ret = IFX_SUCCESS, outFlag = IFX_F_DEFAULT;

	sCommand[0]='\0';
        memset(sValue,'\0',sizeof(sValue));

	sprintf(sCommand, "%s_cpeId", SectionName);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, SectionName, 
			sCommand, IFX_F_GET_ANY, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS)
			return ret;
	iid->cpeId.Id = atoi(sValue);

	sprintf(sCommand, "%s_pcpeId", SectionName);
        memset(sValue,'\0',sizeof(sValue));
	if ((ret = ifx_GetObjData(FILE_RC_CONF, SectionName, 
			sCommand, IFX_F_GET_ANY, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS)
			return ret;
	iid->pcpeId.Id = atoi(sValue);

	sprintf(iid->cpeId.secName, "%s",SectionName);

	return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_check_acl_n_form_chgd_array(...)
*	iid		==>	input ifx_if structure
*	numFvp	==>	number of field value pairs in the array array_fvp
*	array_fvp	==>	input array of field value pairs
*	changed_count	==>	output number of field value pairs which are modified
*	array_changed_fvp	==>	output array of changed field value pairs
* 
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			If the flags is set to Modify then, this function calls one more utility function
			ifx_cmp_and_return_changed_fvp which takes fully qualified fvps
			in array_fvp and compares the values for these fields corresponding from the
			rc.conf. If the value dont match the field value pair is added to the
			array_changed_fvp. Excepting the parent cpeid, which is not expected to change,
			remaining fields will be compared. It also returns the count of changed
			field value pairs in changed_count. It then calls the TR69 function ifx_check_acl
			with changed_count and array_changed_fvp for access control check.
			If the flags is set to Delete then the TR69 function ifx_check_acl will be
			called with numFvp and array_fvp. The return value of ifx_check_acl will be the
			return value of this function also.
*////////////////////////////////////////////////////////////////////////////////
int32 ifx_check_acl_n_form_chgd_array(IFX_IN   IFX_ID        *iid,
                IFX_IN   uint32              numFvp,
                IFX_IN   IFX_NAME_VALUE_PAIR array_fvp[],
                IFX_OUT  uint32              *changed_count, 
                IFX_OUT  IFX_NAME_VALUE_PAIR **array_changed_fvp, 
                IFX_IN   uint32              flags) 
{
	int32	 ret = IFX_SUCCESS;

	if(IFX_MODIFY_F_SET(flags)) {
		/* compare fvp array from structure with fvp array from file and build changed fvp */
		if(ifx_cmp_and_return_changed_fvp(iid->cpeId.secName, numFvp, array_fvp, 
						(int32 *)changed_count, array_changed_fvp) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		        return IFX_FAILURE;
		}
	}

	/* Call TR-69 Plugin function for ACL Checking */
	if(IFX_MODIFY_F_SET(flags)) {
			if(*changed_count > 0) {
			#if 0
					if(ifx_check_acl(iid, *changed_count, *array_changed_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
							ret = IFX_FAILURE;
							goto IFX_Handler;
					}
			#endif // 0
				IFX_CHECK_ACL(iid, *changed_count, *array_changed_fvp, flags, IFX_Handler)
            if (ret != IFX_SUCCESS)
               goto IFX_Handler;
			}
	}
	else if(IFX_DELETE_F_SET(flags)) {
		if(numFvp > 0) {
			#if 0
				if(ifx_check_acl(iid, numFvp, array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
						ret = IFX_FAILURE;
						goto IFX_Handler;
				}
			#endif // 0
			IFX_CHECK_ACL(iid, numFvp, array_fvp, flags, IFX_Handler)
		}
	}

IFX_Handler:
	if(ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
#if 0
	return ret;
#endif
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_form_fqnv_pairs(...)
*	array_fvp	==>	input array of partially qualified field value pairs
*	count		==>	number of field value pairs in the array array_fvp
*	field_prefix	==>	input field prefix of the particular section
*	conf_index	==>	the index of the object instance for which array_fvp is passed
* 
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function takes the partially qualified fvps of the format
			field=value and converts them into the format 
			{field_prefix}_{conf_index}_field1=value1 and stores them back to 
			the input array_fvp.
*////////////////////////////////////////////////////////////////////////////////
int32 ifx_form_fqnv_pairs(IFX_NAME_VALUE_PAIR *array_fvp, int count, char *field_prefix, int conf_index)
{
    int     i = 0;
    char  buf[MAX_DATA_LEN];

	buf[0]='\0';

    for(i=0; i<count; i++) {
        strlcpy(buf, array_fvp[i].fieldname,MAX_DATA_LEN);
        snprintf(array_fvp[i].fieldname,MAX_TAG_NAME_LEN,"%s_%d_%s", field_prefix, conf_index, buf);
    }

    return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_ValidateInputFlags(...)
*	flags		==>	Input flags
* 
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function checks if multiple operation flags are set in input
			flags, if invalid optional flags are set in input flags.
*////////////////////////////////////////////////////////////////////////////////
int32 ifx_ValidateInputFlags(uint32 flags)
{
	if((IFX_MODIFY_F_SET(flags) && IFX_DELETE_F_SET(flags)) ||
	  (IFX_MODIFY_F_SET(flags) && IFX_INT_ADD_F_SET(flags)) ||
	  (IFX_DELETE_F_SET(flags) && IFX_INT_ADD_F_SET(flags)) ) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
	}

	if(IFX_INT_ADD_F_SET(flags) && IFX_DEACTIVATE_F_SET(flags)) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
	}	

	return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_check_if_static_route(...)
*		ip		==>	input ip address
*		nm		==>	input netmask address
*		gw		==>	input gateway address
* 
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function checks for the distinct pair of input ip, netmask and
			gateway under static routes section in rc.conf and returns the index of
			the matched static route if found or 0 otherwise.
*////////////////////////////////////////////////////////////////////////////////
//int32 ifx_check_if_static_route(char8 *ip, char8 *nm, char8 *gw)
int32 ifx_check_if_static_route(char8 *ip, char8 *nm, char8 *gw, ANY_ROUTE_ENTRY *route_entries, int32 num_routes)
{
	char8	buf[MAX_FILELINE_LEN], sCommand[MAX_FILELINE_LEN];
	char8 	file_ip[MAX_IP_ADDR_LEN], file_nm[MAX_IP_ADDR_LEN], file_gw[MAX_IP_ADDR_LEN];
	int32	nFound = -1, i = 0;
	//int32 ret = IFX_SUCCESS;
	//uint32	flags = IFX_F_GET_ENA, outFlag = IFX_F_GET_ANY;
	//int32 count = 0;

	buf[0]='\0';
	sCommand[0]='\0';
	file_ip[0]='\0';
	file_nm[0]='\0';

#if 0
	MAKE_SECTION_COUNT_TAG(TAG_ROUTING, sCommand)
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_ROUTING, 
								sCommand, flags, &outFlag, buf)) != IFX_SUCCESS)	{
				return 0;
	}
	count = atoi(buf);

	/* Read each route from static route section */
	for(i=0; i<count; i++) {
		sprintf(sCommand, "%s_%d_dstIp", PREFIX_ROUTING, i);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_ROUTING, 
										sCommand, flags, &outFlag, file_ip)) != IFX_SUCCESS)	{
				return 0;
		}

		sprintf(sCommand, "%s_%d_dstMask", PREFIX_ROUTING, i);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_ROUTING, 
										sCommand, flags, &outFlag, file_nm)) != IFX_SUCCESS)	{
				return 0;
		}

		sprintf(sCommand, "%s_%d_gw", PREFIX_ROUTING, i);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_ROUTING, 
										sCommand, flags, &outFlag, file_gw)) != IFX_SUCCESS)	{
				return 0;
		}

		/* compare with the passed params */
		if(!strcmp(ip, file_ip) && !strcmp(nm, file_nm) && !strcmp(gw, file_gw)) {
			nFound = 1;
			break;
		}
	}
#endif // 0
	for(i=0; i<num_routes; i++) {
		sprintf(file_ip, "%s", inet_ntoa((route_entries + i)->ROUTE.route.ip_dst.ip));

		sprintf(file_nm, "%s", inet_ntoa((route_entries + i)->ROUTE.route.ip_dst.mask));

		sprintf(file_gw, "%s", inet_ntoa((route_entries + i)->ROUTE.route.gw));

		/* compare with the passed params */
		if(!strcmp(ip, file_ip) && !strcmp(nm, file_nm) && !strcmp(gw, file_gw)) {
			nFound = i;
			break;
		}
	}

	return nFound;
}


/* By SUBBI */
/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_available_distinct_index(...)
*		filename	==>	input file name
*		pSectionName	==>	input section name under which the next wan index
					has to be retrieved
*		pDistField	==>	Distinct field name under the section pSectionName
*		minIndx		==>	Minimum value of the index
*		maxIndx		==>	Maximum value of the index
*		dist_index	==>	Return value of the next available wan index
* 
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			 
*////////////////////////////////////////////////////////////////////////////////
int32 ifx_get_available_distinct_index(char8 *filename, char8 *pSectionName, char8 *pDistField, 
			uint32 minIndx,	uint32 maxIndx, int32 *dist_index)
{
	int i=0;
	char8 pRetValue[MAX_FILELINE_LEN];
	char8 pData[MAX_FILELINE_LEN], indxPattern[MAX_FILELINE_LEN];
	uint32 inflags, outflags;
	int32 ret = IFX_FAILURE;

	inflags = outflags = IFX_F_GET_ANY;

	pData[0]='\0';
	sprintf(pData, "%s_%s", pSectionName, pDistField);

	pRetValue[0]='\0';
	ret = ifx_GetObjData(filename, pSectionName, pData, inflags, &outflags, pRetValue);
	if (ret != IFX_SUCCESS) {
		printf("Unable to find distField [%s]\n", pDistField);
		return IFX_FAILURE;
	}
	else {
	 	/* Get the unused index from the above retValue */
		for (i=minIndx; i<=maxIndx; i++) {
			indxPattern[0]='\0';
			sprintf(indxPattern, "%d,", i);
			if (strstr(pRetValue, indxPattern) == NULL) {
				/* The indxPattern didn't macth with the given index
				 * so return this index */
				*dist_index = i;
				return IFX_SUCCESS;
			}
		}
		
	}
	*dist_index = -1;
	return IFX_FAILURE;
}


int32 ifx_get_lan_connName_from_ifname(char8 *lan_connName, char8 *lan_ifName)
{
	int32 ret = IFX_SUCCESS;
	char8 *retStr = NULL;
	char8 sCommand[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];

	sCommand[0]='\0';
	sValue[0]='\0';

	if(lan_ifName== NULL) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

    /* currently connName is not a parameter inside lan object
     * and since there is only one lan instance we hard code the connection name
     */
    sprintf(lan_connName, "%s", "LAN0");


IFX_Handler:
	IFX_MEM_FREE(retStr)
	if(ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_wan_ifname_from_connName(...)
*		wan_ifName	==>	input wan interface name 
*		wan_connName	==>	output wan connection name configured for
					the input wan interface name
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			The function reads the wan connection name for the given wan interface
			and returns in wan_connName. It determines the interface type and gets 
			the wan index from the wan corresponding section.
*////////////////////////////////////////////////////////////////////////////////
int32 ifx_get_wan_connName_from_ifname(char8 *wan_connName, char8 *wan_ifName)
{
	char8	ifType[MAX_FILELINE_LEN], tag[MAX_FILELINE_LEN], *retStr = NULL;
	int32	wan_index = -1, ret = IFX_SUCCESS, bFlag = 0;

	ifType[0]='\0';
	tag[0]='\0';
	if(wan_connName == NULL)
	{
		return IFX_FAILURE;
	}
	if(wan_ifName == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		wan_connName[0] = '\0';
		return IFX_FAILURE;
	}

	/* get the first 3 letters of wan_ifName which tells the ifType
	 * which denotes - "nas", "atm" or "ppp" */
	STRNCPY(ifType, wan_ifName, 3);
#if 0
	if(STRNCPY(ifType, wan_ifName, 3) == NULL) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
	}
#endif

	/* form distinct if(type)=wan_ifName and call ifx_ret_substr_from_distfield */
	if( (!strncmp(ifType, "nas", strlen("nas"))) || (!strncmp(ifType, "ptm", strlen("ptm"))) || (!strncmp(ifType, "eth", strlen("eth"))) ) {
        bFlag = 1;
		ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_MAIN, "iface", wan_ifName, &retStr);
    }
	if(!strncmp(ifType, "atm", strlen("atm"))) {
        bFlag = 1;
		IFX_MEM_FREE(retStr);
		ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_IP, "ifatm", wan_ifName, &retStr);
    }
	if(!strncmp(ifType, "ppp", strlen("ppp"))) {
        bFlag = 1;
		IFX_MEM_FREE(retStr);
		ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_PPP, "ifppp", wan_ifName, &retStr);
    }
    if(!bFlag)
        ret = IFX_FAILURE;

	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		IFX_MEM_FREE(retStr)
		return ret;
	}

	/* from the prefix tag get the wan index, form wan_(index)_connName 
	 * and get the value in wan_main */
	wan_index = atoi(strrchr(retStr, '_') + 1);
	sprintf(tag, "wan_%d_connName", wan_index);
	if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, tag, IFX_F_GET_ANY, NULL, wan_connName)) != IFX_SUCCESS) {
		wan_connName[0] = '\0';
		IFX_MEM_FREE(retStr)
		return ret;
	}
	
	/* if no name is configured for this wan connection, return default WAN{wan_index} */
	if(strlen(wan_connName) == 0)
	{
		sprintf(wan_connName, "WAN%d", wan_index);
	}

	IFX_MEM_FREE(retStr)
    return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_lan_ifname_from_connName(...)
*		wan_connName	==>	input lan connection name
*		wan_ifName	==>	output lan interface name configured for
					the input lan connection name
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
*////////////////////////////////////////////////////////////////////////////////
int32 ifx_get_lan_ifname_from_connName(char8 *lan_connName, char8 *lan_ifName)
{
	int32 ret = IFX_SUCCESS;
	char8 *retStr = NULL;
	char8 sCommand[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	uint32 outflag = IFX_F_DEFAULT;

	sCommand[0]='\0';
        memset(sValue,'\0',sizeof(sValue));

	if(lan_connName == NULL) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

    /* currently connName is not a parameter inside lan object
     * and since there is only one lan instance we hard code the interface name
     */
	sprintf(sCommand, "%s_%d_interface", TAG_LAN_MAIN, 0);
	if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, sCommand, IFX_F_GET_ANY, &outflag, lan_ifName)) != IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
#if 0
    /* find out prefix_{inst} for lan object that matches lan_connName */
	ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_LAN_MAIN, "connName", lan_connName, &retStr);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	sprintf(sCommand, "%s_interface", retStr);
	if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, sCommand, IFX_F_GET_ANY, &outflag, lan_ifName)) != IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
#endif // 0


IFX_Handler:
	IFX_MEM_FREE(retStr)
	if(ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_wan_ifname_from_connName(...)
*		wan_connName	==>	input wan connection name
*		wan_ifName	==>	output wan interface name configured for
					the input wan connection name
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			The function reads the wan connection type for the given wan connection
			name and based on the type navigates either to the wan_ip or
			wan_ppp section and returns the wan interface name which can be
			of the type "nas" or "atm" or "ppp"
*////////////////////////////////////////////////////////////////////////////////
int32 ifx_get_wan_ifname_from_connName(char8 *wan_connName, char8 *wan_ifName)
{
	int32 ret = IFX_SUCCESS, wan_index = -1;
	char8 *retStr = NULL, strIfType[IFNAMSIZE];
	char8 sCommand[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	uint32 outflag = IFX_F_DEFAULT;

	strIfType[0]='\0';
	sCommand[0]='\0';
        memset(sValue,'\0',sizeof(sValue));

	if(wan_connName == NULL) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] [%s]", __FUNCTION__, __LINE__, wan_connName);
#endif

	/* get the conn_name and form the distinct connName=value pair */
	ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_MAIN, "connName", wan_connName, &retStr);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] %s %s", __FUNCTION__, __LINE__, wan_connName, retStr);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* This would result in  wan_{index} tag */
	sprintf(strIfType, "%s_ifType", retStr);
	sValue[0]='\0';
	if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, strIfType, IFX_F_GET_ANY, &outflag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] %s", __FUNCTION__, __LINE__, strIfType);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}


	sCommand[0]='\0';

#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] ifType[%s]", __FUNCTION__, __LINE__, sValue);
#endif

#if 0
	/* If value is "nas" form the wan_2_ifnas tag and get the value 
	 * for this n this is default iface */
	if(!strcmp(sValue, "nas")) {
		sprintf(sCommand, "%s_iface", retStr);
		if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, sCommand, IFX_F_GET_ANY, &outflag, sValue)) != IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}


  else if(!strcmp(sValue, "eth")) {
    sprintf(sCommand, "%s_iface", retStr);
    if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, sCommand, IFX_F_GET_ANY, &outflag, sValue)) != IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      ret = IFX_FAILURE;
      goto IFX_Handler;
    }
  }



  else if(!strcmp(sValue, "ptm")) {
    sprintf(sCommand, "%s_iface", retStr);
    if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, sCommand, IFX_F_GET_ANY, &outflag, sValue)) != IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
      ret = IFX_FAILURE;
      goto IFX_Handler;
    }
  }
#endif

        if( (!strcmp(sValue, "nas")) || (!strcmp(sValue, "eth")) || (!strcmp(sValue, "ptm")) ) {
                sprintf(sCommand, "%s_iface", retStr);
                memset(sValue,'\0',sizeof(sValue));
                if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, sCommand, IFX_F_GET_ANY, &outflag, sValue)) != IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                        ret = IFX_FAILURE;
                        goto IFX_Handler;
                }
        }


	/* if value is "atm" go to wan ip section, form the tag wan_2_ifatm and get the value 
	 * for this n this is default iface */
	else if(!strcmp(sValue, "atm")) {
		wan_index = atoi(strrchr(retStr, '_') + 1);
		sprintf(sCommand, "%s_%d_ifatm", PREFIX_WAN_IP, wan_index);
                memset(sValue,'\0',sizeof(sValue));
		if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, sCommand, IFX_F_GET_ANY, &outflag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}
	/* If value is "ppp" go to wan ppp section, form the tag wan_2_ifppp and get the value 
	 * for this n this is default iface */
	else if(!strcmp(sValue, "ppp")) {
		wan_index = atoi(strrchr(retStr, '_') + 1);
		sprintf(sCommand, "%s_%d_ifppp", PREFIX_WAN_PPP, wan_index);
                memset(sValue,'\0',sizeof(sValue));
		if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, sCommand, IFX_F_GET_ANY, &outflag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}
	else {
		sprintf(wan_ifName, "%s", "\0");
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	sprintf(wan_ifName, "%s", sValue);

IFX_Handler:
	IFX_MEM_FREE(retStr)
	if(ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_wan_ifname_from_conf_connName(...)
*		wan_connName	==>	input wan conf connection name
*		wan_ifName	==>	output wan interface name configured for
					the input wan connection name
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			The function reads the wan connection type for the given wan connection
			name and based on the type navigates either to the wan_ip or
			wan_ppp section and returns the wan interface name which can be
			of the type "nas" or "atm" or "ppp"
*////////////////////////////////////////////////////////////////////////////////
int32 ifx_get_wan_ifname_from_conf_connName(char8 *wan_connName, char8 *wan_ifName)
{
	int32 ret = IFX_SUCCESS, wan_index = -1;
	char8 *retStr = NULL, strIfType[IFNAMSIZE];
	char8 sCommand[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	uint32 outflag = IFX_F_DEFAULT;

	strIfType[0]='\0';
	sCommand[0]='\0';
        memset(sValue,'\0',sizeof(sValue));

	if(wan_connName == NULL) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* get the conn_name and form the distinct connName=value pair */
	ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_MAIN, "conf_connName", wan_connName, &retStr);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* This would result in  wan_{index} tag */
	sprintf(strIfType, "%s_ifType", retStr);
        memset(sValue,'\0',sizeof(sValue));
	if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, strIfType, IFX_F_GET_ANY, &outflag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}


	sCommand[0]='\0';

	/* If value is "nas" form the wan_2_ifnas tag and get the value 
	 * for this n this is default iface */
	if(!strcmp(sValue, "nas")) {
		sprintf(sCommand, "%s_iface", retStr);
                memset(sValue,'\0',sizeof(sValue));
		if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, sCommand, IFX_F_GET_ANY, &outflag, sValue)) != IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	/* if value is "atm" go to wan ip section, form the tag wan_2_ifatm and get the value 
	 * for this n this is default iface */
	else if(!strcmp(sValue, "atm")) {
		wan_index = atoi(strrchr(retStr, '_') + 1);
		sprintf(sCommand, "%s_%d_ifatm", PREFIX_WAN_IP, wan_index);
                memset(sValue,'\0',sizeof(sValue));
		if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, sCommand, IFX_F_GET_ANY, &outflag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}
	/* If value is "ppp" go to wan ppp section, form the tag wan_2_ifppp and get the value 
	 * for this n this is default iface */
	else if(!strcmp(sValue, "ppp")) {
		wan_index = atoi(strrchr(retStr, '_') + 1);
		sprintf(sCommand, "%s_%d_ifppp", PREFIX_WAN_PPP, wan_index);
                memset(sValue,'\0',sizeof(sValue));
		if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, sCommand, IFX_F_GET_ANY, &outflag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}
	else {
		sprintf(wan_ifName, "%s", "\0");
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	sprintf(wan_ifName, "%s", sValue);

IFX_Handler:
	IFX_MEM_FREE(retStr)
	if(ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}



/*//////////////////////////////////////////////////////////////////////////////
* ifx_manipulate_wan_indexs(...)
*		filename	==>	File name which we need to search for indexFieldName  
*		SectionTag	==>	 Section Name for this indexFieldName in file
*		indexFieldName	==>	Field name of the object in file
*		indxVal	==> index value for the field name in file 
*		flags	==> flag value denoting the operation
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
				This function searches the file for the given indexFieldName for the specified
				indxVal. Depeding on the flags, this indxVal is either appended to the string of
				indexs or removed from the string.
*////////////////////////////////////////////////////////////////////////////////
int32 ifx_manipulate_wan_indexs(char8 *filename, char8 *SectionTag, char8 *indexFieldName, uint32 indxVal,
				uint32 flags)

{
	char8 IndxStr[MAX_FILELINE_LEN];	
	char8 bufIndxStr[MAX_FILELINE_LEN];
	char8 buf[MAX_FILELINE_LEN];
	char8 searchIndxStr[10];
	char8 *ptr_indxMatchStr = NULL;

	if ((filename == NULL) || (SectionTag == NULL) ||
		(indexFieldName == NULL)) {
	
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;	
	}


	/* Initialze all buffers */
	memset(IndxStr,'\0',sizeof(IndxStr));
	memset(bufIndxStr,'\0',sizeof(bufIndxStr));
	buf[0]='\0';

	/* Read the index string values from file */
	if(ifx_GetObjData(filename, SectionTag,
				indexFieldName, 0, NULL, IndxStr) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
	}

	if (IFX_INT_ADD_F_SET(flags)) {
		
		/* Concatenate the new Index and append it to the already
		 * existing list of IndxStr */
		snprintf(bufIndxStr,sizeof(bufIndxStr),"%s=\"%s%d,\"\n", indexFieldName, IndxStr, indxVal);
	}
	else if (IFX_DELETE_F_SET(flags)) {
		searchIndxStr[0]='\0';
		snprintf(searchIndxStr,sizeof(searchIndxStr),"%d,", indxVal);
		/* Search for the given index in index string */
		ptr_indxMatchStr = strstr(IndxStr, searchIndxStr);
		if (ptr_indxMatchStr != NULL) {
			STRNCPY(buf, IndxStr, strlen(IndxStr) - strlen(ptr_indxMatchStr));
			ptr_indxMatchStr += strlen(searchIndxStr);
			snprintf(bufIndxStr,sizeof(bufIndxStr),T("%s=\"%s%s\"\n"), indexFieldName, buf, ptr_indxMatchStr);
		}
		else {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			return IFX_FAILURE;
		}
	}

	/* Write the index strings back to file */
	if (ifx_SetObjData(filename, SectionTag, 
				IFX_F_MODIFY, 1, bufIndxStr) != IFX_SUCCESS) {
	
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
	}

	return IFX_SUCCESS;
}


int32 ifx_check_wan_configuration_dependency(WAN_CONN_CFG *wan_cfg)
{
    char8   buf[MAX_FILELINE_LEN], command[MAX_FILELINE_LEN], cur_linkType[MAX_FILELINE_LEN], *retStr = NULL;
	char8	sValue[MAX_FILELINE_LEN];
    uint32  outflag = IFX_F_DEFAULT;
	int32	act_state = IFX_ENABLED;
	int32 iRet = IFX_SUCCESS;

	command[0]='\0';
	cur_linkType[0]='\0';
        memset(sValue,'\0',sizeof(sValue));
	buf[0]='\0';

    if(wan_cfg->wan_index == 0)
	{
            sprintf(buf, "%d", wan_cfg->iid.cpeId.Id);
            if (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_MAIN, "cpeId",
                            buf, &retStr) != IFX_SUCCESS)
			{
   				iRet = IFX_FAILURE;
				goto ifx_handler;
        	}
	        sprintf(command, "%s_linkType", retStr);
            if((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, command, IFX_F_GET_ANY,
                        &outflag, cur_linkType)) != IFX_SUCCESS)
			{
   				iRet = IFX_FAILURE;
				goto ifx_handler;
       		}
			sprintf(command, "%s_fEnable", retStr);
            memset(sValue,'\0',sizeof(sValue));
            if((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, command, IFX_F_GET_ANY,
                        &outflag, sValue)) != IFX_SUCCESS)
			{
   				iRet = IFX_FAILURE;
				goto ifx_handler;
        	}
			act_state = atoi(sValue);
    }
    else
	{
        sprintf(command, "wan_%d_linkType", wan_cfg->wan_index);
        memset(cur_linkType,'\0',sizeof(cur_linkType));
        if((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, command, IFX_F_GET_ANY,
                        &outflag, cur_linkType)) != IFX_SUCCESS)
		{
   				iRet = IFX_FAILURE;
				goto ifx_handler;
        }
		sprintf(command, "wan_%d_fEnable", wan_cfg->wan_index);
        memset(sValue,'\0',sizeof(sValue));
        if((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, command, IFX_F_GET_ANY,
                        &outflag, sValue)) != IFX_SUCCESS)
		{
   				iRet = IFX_FAILURE;
				goto ifx_handler;
        }
		act_state = atoi(sValue);
    }

    if (wan_cfg->type == WAN_LINK_TYPE_CLIP)
	{
        if(wan_cfg->iid.config_owner == IFX_TR69)
		{
            /* check if the current state is disabled with link type EoA - then allow it */
            if (atoi(cur_linkType) == WAN_LINK_TYPE_EOATM)
			{
                if(act_state == IFX_DISABLED)
				{
   					iRet = IFX_SUCCESS;
					goto ifx_handler;
                }
                else
   				{
					iRet = IFX_FAILURE;
					goto ifx_handler;
				}
            }
            if (atoi(cur_linkType) == WAN_LINK_TYPE_IPOATM)
			{
   				iRet = IFX_FAILURE;
				goto ifx_handler;
            }
        }
        else
		{
            if (atoi(cur_linkType) == WAN_LINK_TYPE_EOATM || atoi(cur_linkType) == WAN_LINK_TYPE_IPOATM)
			{
   				iRet = IFX_FAILURE;
				goto ifx_handler;
            }
        }
    }
    if (wan_cfg->type == WAN_LINK_TYPE_EOATM || wan_cfg->type == WAN_LINK_TYPE_IPOATM)
	{
        if (atoi(cur_linkType) == WAN_LINK_TYPE_CLIP)
		{
   				iRet = IFX_FAILURE;
				goto ifx_handler;
        }
    }
ifx_handler:
	if(retStr != NULL)
		free(retStr);
    return iRet;
}


int32 ifx_fill_ArrayFvp_FName(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, char8 *pData[])
{
	int32	i = 0;
	sprintf(arrayFvp[start_index++].fieldname, "%s", pData[i++]);

	while(--nDataCount > 0) {
		sprintf(arrayFvp[start_index++].fieldname, "%s", pData[i++]);
	}

	return IFX_SUCCESS;
}


int32 ifx_fill_ArrayFvp_strValues(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, char8 *pData, ...)
{
	va_list    args;
	va_start(args, pData);
	sprintf(arrayFvp[start_index++].value, "%s", pData);

	while(--nDataCount)
	{
		pData = va_arg(args, char8 *);
		sprintf(arrayFvp[start_index++].value, "%s", pData);
	}
	va_end(args);

	return IFX_SUCCESS;
}

int32 ifx_fill_strValues_ArrayFvp(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, char8 *pData, ...)
{
	va_list    args;
	va_start(args, pData);
	sprintf(pData, "%s", arrayFvp[start_index++].value);

	while(--nDataCount)
	{
		pData = va_arg(args, char8 *);
	        sprintf(pData, "%s", arrayFvp[start_index++].value);
	}
	va_end(args);

	return IFX_SUCCESS;
}
int32 ifx_fill_ArrayFvp_intValues(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, int32 *pData, ...)
{
	va_list    args;
	va_start(args, pData);
	sprintf(arrayFvp[start_index++].value, "%d", *pData);

	while(--nDataCount)
	{
		pData = va_arg(args, int32 *);
		sprintf(arrayFvp[start_index++].value, "%d", *pData);
	}
	va_end(args);

	return IFX_SUCCESS;
}

int32 ifx_fill_intValues_ArrayFvp(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, int32 *pData, ...)
{
	va_list    args;
	va_start(args, pData);

        *pData = atoi(arrayFvp[start_index++].value);

	while(--nDataCount)
	{
		pData = va_arg(args, int32 *);
                *pData = atoi(arrayFvp[start_index++].value);
	}
	va_end(args);

	return IFX_SUCCESS;
}

int32 ifx_fill_ArrayFvp_uintValues(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, uint32 *pData, ...)
{
	va_list    args;
	va_start(args, pData);
	sprintf(arrayFvp[start_index++].value, "%u", *pData);

	while(--nDataCount)
	{
		pData = va_arg(args, uint32 *);
		sprintf(arrayFvp[start_index++].value, "%u", *pData);
	}
	va_end(args);

	return IFX_SUCCESS;
}

int32 ifx_fill_uintValues_ArrayFvp(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, uint32 *pData, ...)
{
	va_list    args;
	va_start(args, pData);
        *pData = atoi(arrayFvp[start_index++].value);

	while(--nDataCount)
	{
		pData = va_arg(args, uint32 *);
                *pData = atoi(arrayFvp[start_index++].value);
	}
	va_end(args);

	return IFX_SUCCESS;
}

int32 ifx_fill_ArrayFvp_boolValues(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, uchar8 *pData, ...)
{
	va_list    args;
	va_start(args, pData);
	sprintf(arrayFvp[start_index++].value, "%c", (*pData)+48);

	while(--nDataCount)
	{
		pData = va_arg(args, uchar8 *);
		sprintf(arrayFvp[start_index++].value, "%c", (*pData)+48);
	}
	va_end(args);

	return IFX_SUCCESS;
}

int32 ifx_fill_boolValues_ArrayFvp(IFX_NAME_VALUE_PAIR arrayFvp[], int32 start_index, int32 nDataCount, uchar8 *pData, ...)
{
	va_list    args;
	va_start(args, pData);
        *pData = atoi(arrayFvp[start_index++].value);

	while(--nDataCount)
	{
		pData = va_arg(args, uchar8 *);
                *pData = atoi(arrayFvp[start_index++].value);
	}
	va_end(args);

	return IFX_SUCCESS;
}

/* This function will search for the pattern _ssid=input_ssid in wlan_main section
	and return the cpeid and pcpeid of the found instance */
int32 ifx_get_iid_from_ssid(char8 ssid[], IFX_ID *iid)
{
	int32	ret = IFX_SUCCESS;
	uint32	outFlag = IFX_F_DEFAULT;
	char8	*retString = NULL, buf[MAX_FILELINE_LEN], sValue[10];

	if (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WLAN_MAIN, "ssid",
				ssid, &retString) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	sprintf(buf, "%s_cpeId", retString);
        memset(sValue,'\0',sizeof(sValue));
	if((ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAIN, buf, IFX_F_GET_ANY,
			&outFlag, sValue)) != IFX_SUCCESS){
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	iid->cpeId.Id = atoi(sValue);

	sprintf(buf, "%s_pcpeId", retString);
        memset(sValue,'\0',sizeof(sValue));
	if((ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAIN, buf, IFX_F_GET_ANY,
			&outFlag, sValue)) != IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	iid->pcpeId.Id = atoi(sValue);

IFX_Handler:
	if(retString != NULL)
	{
		IFX_MEM_FREE(retString)
	}
	return ret;
}

/* This function will search for the pattern _ap_name=input_ap_name in wlan_main section
	and return the cpeid and pcpeid of the found instance */
int32 ifx_get_iid_from_ap_name(char8 ap_name[], IFX_ID *iid)
{
	int32	ret = IFX_SUCCESS;
	uint32	outFlag = IFX_F_DEFAULT;
	char8	*retString = NULL, buf[MAX_FILELINE_LEN], sValue[10];

	if (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WLAN_MAIN, "apName",
				ap_name, &retString) != IFX_SUCCESS)
	{
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	sprintf(buf, "%s_cpeId", retString);
        memset(sValue,'\0',sizeof(sValue));
	if((ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAIN, buf, IFX_F_GET_ANY,
			&outFlag, sValue)) != IFX_SUCCESS){
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	iid->cpeId.Id = atoi(sValue);

	sprintf(buf, "%s_pcpeId", retString);
        memset(sValue,'\0',sizeof(sValue));
	if((ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAIN, buf, IFX_F_GET_ANY,
			&outFlag, sValue)) != IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	iid->pcpeId.Id = atoi(sValue);

IFX_Handler:
	if(retString != NULL)
	{
		IFX_MEM_FREE(retString)
	}
	return ret;
}

int32 ifx_convert_strToHexByte(char8 *strByte, uint8 *pHexVal)
{
    int32	ret = IFX_SUCCESS;
    unsigned long longVal = 0;

    errno = 0;
    longVal = strtoul(strByte, NULL, 16);

    /* Check conversion */
    if (errno != 0) {
#ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] cli_cmn_strToHexByte: %s\n", __FUNCTION__, __LINE__, strerror(errno));
#endif
        ret = IFX_FAILURE;
		goto IFX_Handler;
    }

    /* Check value */
    if ((longVal > 0xFF)) {
        ret = IFX_FAILURE;
		goto IFX_Handler;
    }
    else {
        *pHexVal = (uint8) longVal;
    }

IFX_Handler:
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}


int32 ifx_convert_string_to_hex(char8 macAddr[], uint8 address[])
{
    int32	ret = IFX_SUCCESS;
    /* index */
    uint8 i = 0;
    /* array length */
    uint8 arrayLength = 0;
    /* string used for conversion */
    char strByte[3], *ptr = NULL, sub[3];
    /* long variable for conversion */
    //uint8 byteVal;

    /* Check the length: 6 bytes + 5 ':' */
    if (strlen(macAddr) != 17) {
        /* Invalid length */
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
    }

    /* Byte must be null terminated for printing */
    strByte[2] = '\0';

    /* Convert byte by byte */
	/*
    while ((ret == IFX_SUCCESS) && (arrayLength < 6)) {
        // Copy the byte
        strncpy(strByte, &macAddr[i], 2);
        // Convert
        ret = ifx_convert_strToHexByte(strByte, &byteVal);
        if (ret == IFX_SUCCESS)
            address[arrayLength] = (uint8) byteVal;
		else
			goto IFX_Handler;
        // Move index and counter
        i = i + 3;
        arrayLength = arrayLength + 1;

    }
	*/
	ptr = macAddr;
	while(i<6) {
		memset(strByte, 0x00, sizeof(strByte));
		strncpy(strByte, ptr, 2);
		address[arrayLength] = (uint8) strtol(sub, NULL, 16);
		arrayLength++;
		ptr += 3;
		i++;
	}


IFX_Handler:
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}


void ifx_convert_ascii_to_hex(char8 *ascii_str, char8 *hex_str)
{
	int32	i = 0;
	char8	temp[MAX_FILELINE_LEN];

	memset(hex_str, 0x00, sizeof(hex_str));

	for(i=0; i<strlen(ascii_str); i++) {
		sprintf(temp, "%x", ascii_str[i]);
		strcat(hex_str, temp);
	}
}


void ifx_convert_hex_to_ascii(char8 *hex_str, char8 *ascii_str)
{
	int32	a1 = 0, a2 = 0, i = 0, count = strlen(hex_str) / 2;
	char8	*ptr = hex_str;

	for(i=0; i<count; i++, ptr+=2) {
		if (ptr[0] >= 'A' && ptr[0] <= 'F') {
			a1 = 10 + ptr[0] - 'A';
		}
		else if (ptr[0] >= 'a' && ptr[0] <= 'f') {
			a1 = 10 + ptr[0] - 'a';
		}
		else {
			a1 = ptr[0]-'0';
		}

		if (ptr[1] >= 'A' && ptr[1] <= 'F') {
			a2 = 10 + ptr[1] - 'A';
		}
		else if (ptr[1] >= 'a' && ptr[1] <= 'f') {
			a2 = 10 + ptr[1] - 'a';
		}
		else {
			a2 = ptr[1]-'0';
		}

		ascii_str[i] = (a1 * 16) + a2;
	}
}


void ifx_make_canonical_key(char8 *key)
{
	int32	i = 0, j = 0;

	while(key[i] != '\0') {
		key[i] = toupper(key[j]);
        i++; j++;    
    }
}


int32 get_pcr_val_for_wan_idx(int32 wan_idx, int32 *pcr_val)
{
	char8	buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN], sVCC[10], *retString = NULL;
	int32	ret = IFX_SUCCESS;
	uint32	outFlag = IFX_F_DEFAULT, flags = IFX_F_GET_ENA;

        memset(sValue,'\0',sizeof(sValue));
	/* Get the VCC in ENABLED State Only */
	sprintf(buf, "%s_%d_vcc", PREFIX_WAN_MAIN, wan_idx);
	if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, &outFlag, sVCC)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* asking the function to match this vcc only if vc object is enabled */
	if (ifx_ret_substr_from_distfield_with_state(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, "vcc",
					sValue, &retString, IFX_F_GET_ENA) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		IFX_MEM_FREE(retString);
		goto IFX_Handler;
	}

	sprintf(buf, "%s_maxpcr", retString);
        memset(sValue,'\0',sizeof(sValue));
	if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	*pcr_val = atoi(sValue);

IFX_Handler:
	IFX_MEM_FREE(retString)
	if(ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}


#if 0
int32 get_pcr_val_for_vcc(IFX_ID iid, int32 *pcr_val)
#else
int32 get_pcr_val_for_vcc(char8 sVCC[], int32 *pcr_val)
#endif
{
	char8	buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN], *retString = NULL;
	//char8 sVCCpId[MAX_FILELINE_LEN];
	int32	ret = IFX_SUCCESS;
	uint32	outFlag = IFX_F_DEFAULT, flags = IFX_F_DEFAULT;

#if 0
	sprintf(sVCCpId, "%d", iid.pcpeId.Id);
	if (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, "pcpeId",
					sVCCpId, &retString) != IFX_SUCCESS) {
#else
	/* asking the function to match this vcc only if vc object is enabled */
	if (ifx_ret_substr_from_distfield_with_state(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, "vcc",
					sVCC, &retString, IFX_F_GET_ENA) != IFX_SUCCESS) {
#endif
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		IFX_MEM_FREE(retString);
		goto IFX_Handler;
	}

	IFX_DBG("[%s:%d] i/p vc [%s]", __FUNCTION__, __LINE__, sVCC);
	sprintf(buf, "%s_qos", retString);
        memset(sValue,'\0',sizeof(sValue));
	if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] requesting [%s] in [%s]", __FUNCTION__, __LINE__, buf, TAG_ADSL_VCCHANNEL);
#endif
		goto IFX_Handler;
	}

	if(atoi(sValue) != ATM_UBR) {
		sprintf(buf, "%s_maxpcr", retString);
                memset(sValue,'\0',sizeof(sValue));
		if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		*pcr_val = atoi(sValue);
	}
	else {
		*pcr_val = 0;
	}

IFX_Handler:
	IFX_MEM_FREE(retString)
	if(ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}


int32 get_qos_mode_for_vcc(char8 sVCC[], int32 *qos_mode)
{
	char8	buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN], *retString = NULL;
	//char8 sVCCpId[MAX_FILELINE_LEN];
	int32	ret = IFX_SUCCESS;
	uint32	outFlag = IFX_F_DEFAULT, flags = IFX_F_DEFAULT;

#if 0
	sprintf(sVCCpId, "%d", iid.pcpeId.Id);
	if (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, "pcpeId",
					sVCCpId, &retString) != IFX_SUCCESS) {
#else
	/* asking the function to match this vcc only if vc object is enabled */
	if (ifx_ret_substr_from_distfield_with_state(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, "vcc",
					sVCC, &retString, IFX_F_GET_ENA) != IFX_SUCCESS) {
#endif
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		IFX_MEM_FREE(retString);
		goto IFX_Handler;
	}

	sprintf(buf, "%s_qos", retString);
        memset(sValue,'\0',sizeof(sValue));
	if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	*qos_mode = atoi(sValue);

IFX_Handler:
	IFX_MEM_FREE(retString)
	if(ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}


/* Get all configured wan connections and sum up their allocated pcr
	check if the new pcr + the sum computed > max. bandwidth supported
	if so return IFX_FAILURE else return IFX_SUCCESS */
int32 ifx_check_for_available_bandwidth(IFX_ID iid, int32 pcr, int32 qos_mode)
{
	uint32	outFlag = IFX_F_DEFAULT, flags = IFX_F_DEFAULT;
	char8	buf[MAX_FILELINE_LEN], sIndexes[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN], sVCC[10];
	char8	cpeId[20];
	int32	ret = IFX_SUCCESS, idx_count = 0, *idx_array = NULL, i =0, pcr_val = 0, total_pcr = 0;

	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	NULL_TERMINATE(sIndexes, 0x00, sizeof(sIndexes));

	if(qos_mode == ATM_UBR) {
		ret = IFX_SUCCESS;
		goto IFX_Handler;
	}

	sprintf(buf, "%s", "wan_main_index");
	memset(sIndexes,'\0',sizeof(sIndexes));
	if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, &outFlag, sIndexes)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	get_wan_indices(sIndexes, &idx_count, &idx_array);
	for(i=0; i<idx_count; i++) {
		pcr_val = 0;
		sprintf(buf, "%s_%d_fEnable", PREFIX_WAN_MAIN, *(idx_array + i));
                memset(sValue,'\0',sizeof(sValue));
	
		if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		sprintf(buf, "%s_%d_vcc", PREFIX_WAN_MAIN, *(idx_array + i));
		memset(sVCC,'\0',sizeof(sVCC));
		if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, &outFlag, sVCC)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		sprintf(buf, "%s_%d_cpeId", PREFIX_WAN_MAIN, *(idx_array + i));
		memset(cpeId,'\0',sizeof(cpeId));
		if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, &outFlag, cpeId)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		if(atoi(sValue) == IFX_ENABLED) {
//			total_pcr += get_pcr_val_for_wan_idx(*(idx_array + i), &pcr_val);
			if(get_pcr_val_for_vcc(sVCC, &pcr_val) == IFX_SUCCESS && atoi(cpeId) != iid.cpeId.Id)
				total_pcr += pcr_val;
		}
	}

	sprintf(buf, "%s", "max_us_bw");
	memset(sValue,'\0',sizeof(sValue));
	if((ret = ifx_GetObjData(FILE_SYSTEM_STATUS, "BW_INFO", buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	if((pcr + total_pcr) > atoi(sValue)) {
		IFX_DBG("\nConfigured PCR exceeds max. allowed bandwidth -> Connection creation Failed!\n");
		ret = IFX_FAILURE;
		goto IFX_Handler;

	}

IFX_Handler:
	IFX_MEM_FREE(idx_array);
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}

#ifdef CONFIG_FEATURE_IFX_IPQOS
#if 0
int32 ifx_check_queue_name(char8 *qname, IFX_ID *iid, int32 operation)
{
   char8    sBuf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
   int32    i = 0, count = 0;
   uint32   inflag = IFX_F_GET_ENA, outflag = IFX_F_DEFAULT;

   MAKE_SECTION_COUNT_TAG(TAG_IPQOS_QUEUE, sBuf)

	if (ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUE, sBuf, inflag, &outflag, sValue) != IFX_SUCCESS) {
		return IFX_FAILURE;
	}

   count = atoi(sValue);
   for(i=0; i<count; i++) {
      sprintf(sBuf, "%s_%d_qName", PREFIX_IPQOS_QUEUE, i);
	  if (ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUE, sBuf, inflag, &outflag, sValue) == IFX_SUCCESS) {

         /* check if qname matches with any of configured queue's name */
         if(!strcmp(sValue, qname)) {

            if(operation == IFX_OP_ADD)
               return IFX_FAILURE;
            else if(operation == IFX_OP_MOD) {
               sprintf(sBuf, "%s_%d_cpeId", PREFIX_IPQOS_QUEUE, i);
	           if (ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUE, sBuf, inflag, &outflag, sValue) == IFX_SUCCESS) {

                  /* check if the matched queue is not THIS queue */
                  if(iid->cpeId.Id != atoi(sValue))
                     return IFX_FAILURE;
               }
            }
         }
      }
   }

   return IFX_SUCCESS;
}

/* This function can use ifx_ret_substr_from_distfield */
int32 ifx_get_iid_from_qname(char8 *qname, IFX_ID *iid)
{
   char8    sBuf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
   int32    i = 0, count = 0;
   uint32   inflag = IFX_F_GET_ENA, outflag = IFX_F_DEFAULT;

   MAKE_SECTION_COUNT_TAG(TAG_IPQOS_QUEUE, sBuf)

   NULL_TERMINATE(sValue, 0x00, sizeof(sValue));
   if (ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUE, sBuf, inflag, &outflag, sValue) != IFX_SUCCESS) {
      return IFX_FAILURE;
   }

   count = atoi(sValue);
   for(i=0; i<count; i++) {
      sprintf(sBuf, "%s_%d_qName", PREFIX_IPQOS_QUEUE, i);
	  if (ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUE, sBuf, inflag, &outflag, sValue) == IFX_SUCCESS) {
         if(!strcmp(sValue, qname)) {
            NULL_TERMINATE(sValue, 0x00, sizeof(sValue));
            sprintf(sBuf, "%s_%d_cpeId", PREFIX_IPQOS_QUEUE, i);
            if (ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUE, sBuf, inflag, &outflag, sValue) == IFX_SUCCESS) {
               iid->cpeId.Id = atoi(sValue);
            }
            NULL_TERMINATE(sValue, 0x00, sizeof(sValue));
            sprintf(sBuf, "%s_%d_pcpeId", PREFIX_IPQOS_QUEUE, i);
            if (ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QUEUE, sBuf, inflag, &outflag, sValue) == IFX_SUCCESS) {
               iid->pcpeId.Id = atoi(sValue);
            }
            return IFX_SUCCESS;
         }
      }
   }

   return IFX_FAILURE;
}
#endif // 0
#endif // CONFIG_FEATURE_IFX_IPQOS

#if 0
int32 ifx_get_iid_from_dist_fvp(char8 *secName, char8 *fName, char8 *fValue, IFX_ID *iid, uint32 flags)
{
   char8    sBuf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
   int32    i = 0, count = 0;
   uint32   inflag = IFX_F_GET_ENA, outflag = IFX_F_DEFAULT;

   if (ifx_ret_substr_from_distfield_with_state(FILE_RC_CONF, secName, fName,
					fValue, &retString, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      return IFX_FAILURE;
   }

   NULL_TERMINATE(sValue, 0x00, sizeof(sValue));
   sprintf(sBuf, "%s_cpeId", retString);
   if (ifx_GetObjData(FILE_RC_CONF, secName, sBuf, flags, &outflag, sValue) != IFX_SUCCESS) {
      return IFX_FAILURE;
   }
   iid->cpeId.Id = atoi(sValue);

   NULL_TERMINATE(sValue, 0x00, sizeof(sValue));
   sprintf(sBuf, "%s_pcpeId", retString);
   if (ifx_GetObjData(FILE_RC_CONF, secName, sBuf, flags, &outflag, sValue) != IFX_SUCCESS) {
      return IFX_FAILURE;
   }
   iid->pcpeId.Id = atoi(sValue);

   IFX_MEM_FREE(retString)
   return IFX_SUCCESS;
}
#endif // 0

int32 ifx_get_instance_count_from_dist_fvps(char8 *secName, char8 *prefix, char8 *fName1, char8 *fValue1, char8 *fName2, char8 *fValue2, uint32 flags)
{
   uint32   outflag = IFX_F_DEFAULT;
   int32    i = 0, count = 0, match_count = 0;
   char8    sBuf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];

   MAKE_SECTION_COUNT_TAG(secName, sBuf)
   memset(sValue,'\0', sizeof(sValue));
   if (ifx_GetObjData(FILE_RC_CONF, secName, sBuf, flags, &outflag, sValue) != IFX_SUCCESS) {
      return IFX_FAILURE;
   }
   count = atoi(sValue);
	 if (count < 0 || count > 32767)
			 return IFX_FAILURE;
	 for(i=0; i<count; i++) {
      sprintf(sBuf, "%s_%d_%s", prefix, i, fName1);      
      memset(sValue,'\0', sizeof(sValue));
      if (ifx_GetObjData(FILE_RC_CONF, secName, sBuf, flags, &outflag, sValue) == IFX_SUCCESS) {
         if(!gstrcmp(sValue, fValue1)) {

            sprintf(sBuf, "%s_%d_%s", prefix, i, fName2);      
            memset(sValue,'\0', sizeof(sValue));
            if (ifx_GetObjData(FILE_RC_CONF, secName, sBuf, flags, &outflag, sValue) == IFX_SUCCESS) {
               if(!gstrcmp(sValue, fValue2)) {
                  match_count++;
               }
            }

         }
      }
   }

   return match_count;
}

int32 ifx_get_instance_count_from_dist_fvp(char8 *secName, char8 *prefix, char8 *fName, char8 *fValue, uint32 flags)
{
   uint32   outflag = IFX_F_DEFAULT;
   int32    i = 0, count = 0, match_count = 0;
   char8    sBuf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];

   MAKE_SECTION_COUNT_TAG(secName, sBuf)
   memset(sValue,'\0', sizeof(sValue));
   if (ifx_GetObjData(FILE_RC_CONF, secName, sBuf, flags, &outflag, sValue) != IFX_SUCCESS) {
      return IFX_FAILURE;
   }
	 count = atoi(sValue);
	 if (count < 0 || count > 32767)
			 return IFX_FAILURE;	
	 for(i=0; i<count; i++) {
      sprintf(sBuf, "%s_%d_%s", prefix, i, fName);      
      memset(sValue,'\0', sizeof(sValue));
      if (ifx_GetObjData(FILE_RC_CONF, secName, sBuf, flags, &outflag, sValue) == IFX_SUCCESS) {
         if(!gstrcmp(sValue, fValue)) {
            match_count++;
         }
      }
   }

   return match_count;
}

int32 ifx_get_another_fvp_from_dist_fvp(char8 *secName, char8 *fName, char8 *fValue, char8 *fRetName, char8 *fRetValue, uint32 flags)
{
   uint32   outflag = IFX_F_DEFAULT;
   char8    sBuf[MAX_FILELINE_LEN], *retString = NULL;

	if (ifx_ret_substr_from_distfield_with_state(FILE_RC_CONF, secName, fName,
					fValue, &retString, flags) != IFX_SUCCESS) {
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		#endif
   		IFX_MEM_FREE(retString)
		return IFX_FAILURE;
	}

	sprintf(sBuf, "%s_%s", retString, fRetName);
	if (ifx_GetObjData(FILE_RC_CONF, secName, sBuf, flags, &outflag, fRetValue) != IFX_SUCCESS)
	{
   		IFX_MEM_FREE(retString)
		return IFX_FAILURE;
	}

   IFX_MEM_FREE(retString)
   return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_modify_n_reorder_fvp(...)
*	secName         ==>		input section name of the object instance for which the
*						   re-ordering has to done
*	prefix          ==>		input prefix name of this object instance
*	fName           ==>		input field name
*	oldValue        ==>		input old value of fName
*	newValue        ==>		input new value of fName
*	flags           ==>		input flags
* 
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
                        This function modifies the value of field fName, of the instance matching oldValue, to newValue.
                        Since the values of field fName are unique within the section secName, the function also
                        modifies values of fName for other entries greater than or equal to the lower of the old and new values,
                        and less than the larger of the old and new values.
                        This function supports only DELETE and MODIFY operations.
*////////////////////////////////////////////////////////////////////////////////
int32 ifx_modify_n_reorder_fvp(char8 *secName, char8 *prefix, char8 *fName, char8 *oldValue, char8 *newValue, uint32 flags)
{
        int32   i = 0, ret = IFX_SUCCESS, found = 0, count = 0;
        uint32  inflag = IFX_F_GET_ANY, outflag = IFX_F_DEFAULT;
        char8   sValue[20], sLine[MAX_FILELINE_LEN];

        MAKE_SECTION_COUNT_TAG(secName, sLine)
        memset(sValue,'\0', sizeof(sValue));

                if ((ret = ifx_GetObjData(FILE_RC_CONF, secName, sLine, inflag, &outflag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                        return ret;
                }

         if(IFX_MODIFY_F_SET(flags)) {
            if(atoi(oldValue) == atoi(newValue))
               return IFX_SUCCESS;
         }
         else if(IFX_INT_ADD_F_SET(flags)) {
            if(atoi(newValue) > atoi(sValue))
               return IFX_SUCCESS;
         }

        if(IFX_MODIFY_F_SET(flags) || IFX_DELETE_F_SET(flags))
            count = atoi(sValue);
         else
            count = atoi(sValue) + 1;

		if(IFX_MODIFY_F_SET(flags) || IFX_INT_ADD_F_SET(flags)) {
			if(atoi(oldValue) < atoi(newValue)) {
	                /* move up */
							if(count < 0 || count > 32767)
									return IFX_FAILURE;
							for(i=0; i<count; i++) {
	
	                        outflag = IFX_F_DEFAULT;
	                        sprintf(sLine, "%s_%d_%s", prefix, i, fName);
                                memset(sValue,'\0', sizeof(sValue));
	                        if ((ret = ifx_GetObjData(FILE_RC_CONF, secName, sLine, inflag, &outflag, sValue)) != IFX_SUCCESS) {
	#ifdef IFX_LOG_DEBUG
	                                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	#endif
	                                continue;
	                        }
	
	                                if(atoi(sValue) == atoi(oldValue)) {
											if(!found) {
												found = 1;
		                                        sprintf(sLine, "%s_%d_%s=\"%s\"\n", prefix, i, fName, newValue);
	    	                                    ret = ifx_SetObjData(FILE_RC_CONF, secName, IFX_F_MODIFY | outflag, 1, sLine);
	        	                                if(ret != IFX_SUCCESS) {
	
		                                        }
												continue;
											}
	                                }
	
	                        if((atoi(sValue) > atoi(oldValue) && atoi(sValue) < atoi(newValue)) || 
								(atoi(sValue) == atoi(newValue))) {
	                               	sprintf(sLine, "%s_%d_%s=\"%d\"\n", prefix, i, fName, atoi(sValue) - 1);
	                                ret = ifx_SetObjData(FILE_RC_CONF, secName, IFX_F_MODIFY | outflag, 1, sLine);
	                                if(ret != IFX_SUCCESS) {
	
	                                }
	                        }
	
	                }
			}
			else if(atoi(oldValue) > atoi(newValue)) {
	                /* move up */
							if(count < 0 || count > 32767)
									return IFX_FAILURE;
							for(i=0; i<count; i++) {
	
	                        outflag = IFX_F_DEFAULT;
	                        sprintf(sLine, "%s_%d_%s", prefix, i, fName);
                                memset(sValue,'\0', sizeof(sValue));
	                        if ((ret = ifx_GetObjData(FILE_RC_CONF, secName, sLine, inflag, &outflag, sValue)) != IFX_SUCCESS) {
	#ifdef IFX_LOG_DEBUG
	                                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	#endif
	                                continue;
	                        }
	
	                                if(atoi(sValue) == atoi(oldValue)) {
											if(!found) {
												found = 1;
		                                        sprintf(sLine, "%s_%d_%s=\"%s\"\n", prefix, i, fName, newValue);
	    	                                    ret = ifx_SetObjData(FILE_RC_CONF, secName, IFX_F_MODIFY | outflag, 1, sLine);
	        	                                if(ret != IFX_SUCCESS) {
	
		                                        }
												continue;
											}
	                                }
	
	                        if((atoi(sValue) > atoi(newValue) && atoi(sValue) < atoi(oldValue)) || 
								(atoi(sValue) == atoi(newValue))) {
	                               	sprintf(sLine, "%s_%d_%s=\"%d\"\n", prefix, i, fName, atoi(sValue) + 1);
	                                ret = ifx_SetObjData(FILE_RC_CONF, secName, IFX_F_MODIFY | outflag, 1, sLine);
	                                if(ret != IFX_SUCCESS) {
	
	                                }
	                        }
	
	                }
			}
		}
		else if(IFX_DELETE_F_SET(flags)) {

                for(i=0; i<count; i++) {

                        outflag = IFX_F_DEFAULT;
                        sprintf(sLine, "%s_%d_%s", prefix, i, fName);
                        memset(sValue,'\0', sizeof(sValue));
                        if (ifx_GetObjData(FILE_RC_CONF, secName, sLine, inflag, &outflag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
                                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                                continue;
                        }

						if(atoi(sValue) > atoi(oldValue)) {
							  sprintf(sLine, "%s_%d_%s=\"%d\"\n", prefix, i, fName, atoi(sValue) - 1);
	                          ret = ifx_SetObjData(FILE_RC_CONF, secName, IFX_F_MODIFY | outflag, 1, sLine);
	                          if(ret != IFX_SUCCESS) {
                                 goto IFX_Handler;
	                          }

						}
				}

		}

IFX_Handler:
                if(ret != IFX_SUCCESS)
                        return ret;
                else
                        return IFX_SUCCESS;
}

int32 ifx_modify_n_reorder_fvp_queue(char8 *secName, char8 *prefix, char8 *fName, char8 *oldValue, char8 *newValue, uint32 flags,IFX_MAPI_QoS_Interface_Type qIfType)
{
        int32   i = 0, ret = IFX_SUCCESS, found = 0, count = 0;
        uint32  inflag = IFX_F_GET_ANY, outflag = IFX_F_DEFAULT;
        char8   sValue[20], sValue1[20], sValue2[20], sLine[MAX_FILELINE_LEN];

		IFX_API_LOG("[%s:%d] qIfType = %d! old=%s,new=%s", __FUNCTION__,__LINE__,qIfType,oldValue,newValue);
        MAKE_SECTION_COUNT_TAG(secName, sLine)
		IFX_API_LOG("[%s:%d] qIfType = %d! old=%s,new=%s", __FUNCTION__,__LINE__,qIfType,oldValue,newValue);
                memset(sValue,'\0', sizeof(sValue));
                if ((ret = ifx_GetObjData(FILE_RC_CONF, secName, sLine, inflag, &outflag, sValue)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] sValue = %s", __FUNCTION__,__LINE__,sValue);
#ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                        return ret;
                }
		IFX_API_LOG("[%s:%d] Total classifiers = %s", __FUNCTION__,__LINE__,sValue);

         if(IFX_MODIFY_F_SET(flags)) {
            if(atoi(oldValue) == atoi(newValue))
		{
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
               return IFX_SUCCESS;
		}
         }
#if 0 
/* Never happen, since reorder function will not be invoked for this case in case of add. If atall you need to uncomment this, i mean put this check also, then instead of sValue you need to pass the actual iface count value. */
         else if(IFX_INT_ADD_F_SET(flags)) {
            if(atoi(newValue) > atoi(sValue))
{
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
               return IFX_SUCCESS;
}
         }
#endif

         if(IFX_MODIFY_F_SET(flags) || IFX_DELETE_F_SET(flags))
            count = atoi(sValue);
         else
         {
           if (!atoi(oldValue)) //Dummy Add for handling MODIFY of 802.1p/DSCP -> MFC
           {
    IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
             count = atoi(sValue);
						 if(count < 0 || count > 32767)
								 return IFX_FAILURE;
						 for(i=0; i<count; i++)
             {
	                        sprintf(sLine, "%s_%d_%s", prefix, i, fName);
                                memset(sValue,'\0', sizeof(sValue));
	                        if ((ret = ifx_GetObjData(FILE_RC_CONF, secName, sLine, inflag, &outflag, sValue)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
	#ifdef IFX_LOG_DEBUG
	                                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	#endif
	                                continue;
	                        }
    IFX_API_LOG("[%s:%d]%s=%s ", __FUNCTION__,__LINE__,sLine,sValue);

	                        sprintf(sLine, "%s_%d_%s", prefix, i, "cpeId");
                                memset(sValue1,'\0', sizeof(sValue1));
	                        if ((ret = ifx_GetObjData(FILE_RC_CONF, secName, sLine, inflag, &outflag, sValue1)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
	#ifdef IFX_LOG_DEBUG
	                                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	#endif
	                                continue;
	                        }
    IFX_API_LOG("[%s:%d]%s=%s ", __FUNCTION__,__LINE__,sLine,sValue1);

	                        sprintf(sLine, "%s_%d_%s", prefix, i, "type");
                                memset(sValue2,'\0', sizeof(sValue2));
	                        if ((ret = ifx_GetObjData(FILE_RC_CONF, secName, sLine, inflag, &outflag, sValue2)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
	#ifdef IFX_LOG_DEBUG
	                                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	#endif
	                                continue;
	                        }
    IFX_API_LOG("[%s:%d]%s=%s ", __FUNCTION__,__LINE__,sLine,sValue2);
													if ((qIfType != ifx_mapi_get_class_iface(sValue1) ||
                              (atoi(sValue2)!= IFX_MAPI_QoS_Multi_Field))) continue;
	
	                        if(atoi(sValue) >= atoi(newValue) ) {
	                               	sprintf(sLine, "%s_%d_%s=\"%d\"\n", prefix, i, fName, atoi(sValue) + 1);
	                                ret = ifx_SetObjData(FILE_RC_CONF, secName, IFX_F_MODIFY | outflag, 1, sLine);
	                                if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
	
	                                }
	                        }

             }
             goto IFX_Handler;
           }
           else 
           {
    IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
             count = atoi(sValue) + 1;
           }
         }
		IFX_API_LOG("[%s:%d] count=%d ", __FUNCTION__,__LINE__,count);

		if(IFX_MODIFY_F_SET(flags) || IFX_INT_ADD_F_SET(flags)) {
			if(atoi(oldValue) < atoi(newValue)) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
	                /* move up */
									if(count < 0 || count > 32767)
											goto IFX_Handler;
	                for(i=0; i<count; i++) {
	
	                        outflag = IFX_F_DEFAULT;
	                        sprintf(sLine, "%s_%d_%s", prefix, i, fName);
                                memset(sValue,'\0', sizeof(sValue));
	                        if ((ret = ifx_GetObjData(FILE_RC_CONF, secName, sLine, inflag, &outflag, sValue)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
	#ifdef IFX_LOG_DEBUG
	                                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	#endif
	                                continue;
	                        }
    IFX_API_LOG("[%s:%d]%s=%s ", __FUNCTION__,__LINE__,sLine,sValue);

	                        sprintf(sLine, "%s_%d_%s", prefix, i, "cpeId");
                                memset(sValue1,'\0', sizeof(sValue1));
	                        if ((ret = ifx_GetObjData(FILE_RC_CONF, secName, sLine, inflag, &outflag, sValue1)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
	#ifdef IFX_LOG_DEBUG
	                                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	#endif
	                                continue;
	                        }
    IFX_API_LOG("[%s:%d]%s=%s ", __FUNCTION__,__LINE__,sLine,sValue1);

	                        sprintf(sLine, "%s_%d_%s", prefix, i, "type");
                                memset(sValue2,'\0', sizeof(sValue2));
	                        if ((ret = ifx_GetObjData(FILE_RC_CONF, secName, sLine, inflag, &outflag, sValue2)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
	#ifdef IFX_LOG_DEBUG
	                                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	#endif
	                                continue;
	                        }
    IFX_API_LOG("[%s:%d]%s=%s ", __FUNCTION__,__LINE__,sLine,sValue2);
													if ((qIfType != ifx_mapi_get_class_iface(sValue1) ||
                              (atoi(sValue2)!= IFX_MAPI_QoS_Multi_Field))) continue;
	
	                                if(atoi(sValue) == atoi(oldValue)) {
											if(!found) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
												found = 1;
		                                        sprintf(sLine, "%s_%d_%s=\"%s\"\n", prefix, i, fName, newValue);
	    	                                    ret = ifx_SetObjData(FILE_RC_CONF, secName, IFX_F_MODIFY | outflag, 1, sLine);
	        	                                if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
	
		                                        }
												continue;
											}
	                                }
	
	                        if((atoi(sValue) > atoi(oldValue) && atoi(sValue) < atoi(newValue)) || 
								(atoi(sValue) == atoi(newValue))) {
	                               	sprintf(sLine, "%s_%d_%s=\"%d\"\n", prefix, i, fName, atoi(sValue) - 1);
	                                ret = ifx_SetObjData(FILE_RC_CONF, secName, IFX_F_MODIFY | outflag, 1, sLine);
	                                if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
	
	                                }
	                        }
	
	                }
			}
			else if(atoi(oldValue) > atoi(newValue)) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
	                /* move up */
									if(count < 0 || count > 32767)
											goto IFX_Handler;
	                for(i=0; i<count; i++) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
	
	                        outflag = IFX_F_DEFAULT;
	                        sprintf(sLine, "%s_%d_%s", prefix, i, fName);
                                memset(sValue,'\0', sizeof(sValue));
	                        if ((ret = ifx_GetObjData(FILE_RC_CONF, secName, sLine, inflag, &outflag, sValue)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
	#ifdef IFX_LOG_DEBUG
	                                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	#endif
	                                continue;
	                        }

    IFX_API_LOG("[%s:%d]%s=%s ", __FUNCTION__,__LINE__,sLine,sValue);
	                        sprintf(sLine, "%s_%d_%s", prefix, i, "cpeId");
                                memset(sValue1,'\0', sizeof(sValue1));
	                        if ((ret = ifx_GetObjData(FILE_RC_CONF, secName, sLine, inflag, &outflag, sValue1)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
	#ifdef IFX_LOG_DEBUG
	                                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	#endif
	                                continue;
	                        }
    IFX_API_LOG("[%s:%d]%s=%s ", __FUNCTION__,__LINE__,sLine,sValue1);
	                        sprintf(sLine, "%s_%d_%s", prefix, i, "type");
                                memset(sValue2,'\0', sizeof(sValue2));
	                        if ((ret = ifx_GetObjData(FILE_RC_CONF, secName, sLine, inflag, &outflag, sValue2)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
	#ifdef IFX_LOG_DEBUG
	                                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	#endif
	                                continue;
	                        }
    IFX_API_LOG("[%s:%d]%s=%s ", __FUNCTION__,__LINE__,sLine,sValue2);
													if ((qIfType != ifx_mapi_get_class_iface(sValue1) ||
                              (atoi(sValue2)!= IFX_MAPI_QoS_Multi_Field))) continue;
	
	                                if(atoi(sValue) == atoi(oldValue)) {
											if(!found) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
												found = 1;
		                                        sprintf(sLine, "%s_%d_%s=\"%s\"\n", prefix, i, fName, newValue);
	    	                                    ret = ifx_SetObjData(FILE_RC_CONF, secName, IFX_F_MODIFY | outflag, 1, sLine);
	        	                                if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
	
		                                        }
												continue;
											}
	                                }
	
	                        if((atoi(sValue) > atoi(newValue) && atoi(sValue) < atoi(oldValue)) || 
								(atoi(sValue) == atoi(newValue))) {
	                               	sprintf(sLine, "%s_%d_%s=\"%d\"\n", prefix, i, fName, atoi(sValue) + 1);
	                                ret = ifx_SetObjData(FILE_RC_CONF, secName, IFX_F_MODIFY | outflag, 1, sLine);
	                                if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
	
	                                }
	                        }
	
	                }
			}
		}
		else if(IFX_DELETE_F_SET(flags)) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
									if(count < 0 || count > 32767)
											goto IFX_Handler;

                for(i=0; i<count; i++) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);

                        outflag = IFX_F_DEFAULT;
                        sprintf(sLine, "%s_%d_%s", prefix, i, fName);
                        memset(sValue,'\0', sizeof(sValue));
                        if (ifx_GetObjData(FILE_RC_CONF, secName, sLine, inflag, &outflag, sValue) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
#ifdef IFX_LOG_DEBUG
                                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                                continue;
                        }
    IFX_API_LOG("[%s:%d]%s=%s ", __FUNCTION__,__LINE__,sLine,sValue);
	                        sprintf(sLine, "%s_%d_%s", prefix, i, "cpeId");
                                memset(sValue1,'\0', sizeof(sValue1));
	                        if ((ret = ifx_GetObjData(FILE_RC_CONF, secName, sLine, inflag, &outflag, sValue1)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
	#ifdef IFX_LOG_DEBUG
	                                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	#endif
	                                continue;
	                        }
    IFX_API_LOG("[%s:%d]%s=%s ", __FUNCTION__,__LINE__,sLine,sValue1);
	                        sprintf(sLine, "%s_%d_%s", prefix, i, "type");
                                memset(sValue2,'\0', sizeof(sValue2));
	                        if ((ret = ifx_GetObjData(FILE_RC_CONF, secName, sLine, inflag, &outflag, sValue2)) != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
	#ifdef IFX_LOG_DEBUG
	                                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	#endif
	                                continue;
	                        }
    IFX_API_LOG("[%s:%d]%s=%s ", __FUNCTION__,__LINE__,sLine,sValue2);
													if ((qIfType != ifx_mapi_get_class_iface(sValue1) ||
                              (atoi(sValue2)!= IFX_MAPI_QoS_Multi_Field))) continue;

						if(atoi(sValue) > atoi(oldValue)) {
							  sprintf(sLine, "%s_%d_%s=\"%d\"\n", prefix, i, fName, atoi(sValue) - 1);
	                          ret = ifx_SetObjData(FILE_RC_CONF, secName, IFX_F_MODIFY | outflag, 1, sLine);
	                          if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s:%d] ", __FUNCTION__,__LINE__);
                                 goto IFX_Handler;
	                          }

						}
				}

		}

IFX_Handler:
                if(ret != IFX_SUCCESS)
                {  
		                   IFX_API_LOG("[%s:%d] return failure ", __FUNCTION__,__LINE__);
                        return ret;
                }
                else
                        return IFX_SUCCESS;
}

int32 ifx_convert_strIp_to_intArray(char8 *ip, int32 ip_arr[])
{
	int32	idx = 0;
	char8	*ptr = NULL, *tptr = NULL, temp_ip[MAX_IP_ADDR_LEN];

	sprintf(temp_ip, "%s", ip);

	ptr = strtok_r(temp_ip, ".", &tptr);
	while(ptr != NULL) {
		ip_arr[idx++] = atoi(ptr);
		ptr = strtok_r(NULL, ".", &tptr);
	}

	return IFX_SUCCESS;
}

/* this function assumes that the ipaddresses passed are validated before hand.. such as missing octets, invalid format.. */
int32 ifx_compare_ip_addr(char8 *strIp1, char8 *strIp2)
{
	int32 intIp1[4], intIp2[4], i = 0;

	if(ifx_convert_strIp_to_intArray(strIp1, intIp1) != IFX_SUCCESS) {
		return IFX_FAILURE;
	}

	if(ifx_convert_strIp_to_intArray(strIp2, intIp2) != IFX_SUCCESS) {
		return IFX_FAILURE;
	}

	for(i=0; i<3; i++) {
		if(intIp1[i] > intIp2[i]) {
			return 1;
		}
		if(intIp1[i] < intIp2[i]) {
			return -2;
		}
	}

	if(intIp1[i] == intIp2[i])
		return 0;
	else if(intIp1[i] > intIp2[i])
		return 1;
	else
		return -2;
}

int32 ifx_get_wanip_conn_type(IP_TYPE *type, int32 wan_idx)
{
	uint32	outFlag = IFX_F_DEFAULT;
	char8	sCFG_NAME[MAX_FILELINE_LEN], sValue[4];

        memset(sValue,'\0', sizeof(sValue));
//	sprintf(sCFG_NAME, "wanip_%d_connType",wan_idx);
	sprintf(sCFG_NAME, "wanip_%d_addrType",wan_idx);
	if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, sCFG_NAME, IFX_F_DEFAULT, &outFlag, sValue) != IFX_SUCCESS) {
		return IFX_FAILURE;
	}
	else
		*type = atoi(sValue);

	return IFX_SUCCESS;
}

int32 ifx_modify_default_wan_interface()
{
	uint32 i;
	WAN_PHY_CFG pstWanPhy;
	ifx_get_wan_phy_cfg(&pstWanPhy);
        WAN_CONN_CFG wan_cfg;
        memset(&wan_cfg, 0x00, sizeof(wan_cfg));
        for (i=1;i<=MAX_VCCs;i++) 
	{
//fetch WAN instance info
        	if (ifx_mapi_get_wan_config(i, &wan_cfg, IFX_F_DEFAULT) != IFX_SUCCESS) 
		{
        		IFX_DBG("\n\n In Function [%s][%d] : ifx_mapi_get_wan_config failed !!\n\n", __FUNCTION__,__LINE__);
                	goto IFX_Handler;
		}
//check if WAN connection is of current phymode and tc
		if(
(pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2 &&  pstWanPhy.wan_tc == WAN_TC_PTM && wan_cfg.wan_mode.mode == WAN_MODE_PTM) ||
(pstWanPhy.phy_mode == WAN_PHY_MODE_ADSL2 &&  pstWanPhy.wan_tc == WAN_TC_ATM && wan_cfg.wan_mode.mode == WAN_MODE_ATM) ||
(pstWanPhy.phy_mode == WAN_PHY_MODE_VDSL2 &&  pstWanPhy.wan_tc == WAN_TC_PTM && wan_cfg.wan_mode.mode == WAN_MODE_VDSL_PTM))
		{
			if(ifx_set_default_wan_if(&wan_cfg.iid, wan_cfg.wan_index, IFX_F_MODIFY) != IFX_SUCCESS) 
			{
            			IFX_DBG("\n\n [%s][%d] : ifx_set_default_wan_if failed!!\n\n", __FUNCTION__,__LINE__);
                  		goto IFX_Handler;
			}
#ifdef CONFIG_FEATURE_IFX_VOIP
                        if (ifx_set_voip_interface(i, IFX_F_MODIFY) != IFX_SUCCESS) 
			{
            			IFX_DBG("\n\n [%s][%d] : ifx_set_voip_interface failed!!\n\n", __FUNCTION__,__LINE__);
                  		goto IFX_Handler;
                        }
#endif
			return 0;
		
		}
	}
IFX_Handler:
	return -1;
}
