
#include "ifx_common.h"

#ifdef TR69_DEFINED
int32 ifx_set_mgmt_server_wrapper(int32 operation, MGMT_SERVER *mgmt_server, uint32 flags)
{
    return(ifx_set_mgmt_server(operation, mgmt_server, flags));
}

int32 ifx_set_device_info_wrapper(int32 operation, DEVICE_INFO *dev_info, uint32 flags)
{
    return(ifx_set_device_info(operation, dev_info, flags));
}

int32 ifx_set_ipping_diag_wrapper(int32 operation, IPPING_DIAG * ipping_diag, uint32 flags)
{
    return(ifx_set_ipping_diag(operation, ipping_diag, flags));
}

int32 ifx_set_dl_auth_wrapper(int32 operation, DL_AUTH *dl_auth, uint32 flags)
{
    return(ifx_set_dl_auth(operation, dl_auth, flags));
}

int32 ifx_set_tr69_auth_wrapper(int32 operation, TR69_AUTH *tr69_auth, uint32 flags)
{
    return(ifx_set_tr69_auth(operation, tr69_auth, flags));
}

int32 ifx_set_tr69_misc_wrapper(int32 operation, TR69_MISC *tr69_misc, uint32 flags)
{
    return(ifx_set_tr69_misc(operation, tr69_misc, flags));
}

int32 ifx_get_device_info_wrapper(DEVICE_INFO *dev_info, uint32 flags)
{
    return(ifx_get_device_info(dev_info, flags));
}

int32 ifx_get_ipping_diag_wrapper(IPPING_DIAG * ipping_diag, uint32 flags)
{
    return(ifx_get_ipping_diag(ipping_diag, flags));
}

int32 ifx_get_mgmt_server_wrapper(MGMT_SERVER *mgmt_server, uint32 flags)
{
    return(ifx_get_mgmt_server(mgmt_server, flags));
}

int32 ifx_get_dl_auth_wrapper(DL_AUTH *dl_auth, uint32 flags)
{
    return(ifx_get_dl_auth(dl_auth, flags));
}

int32 ifx_get_tr69_auth_wrapper(TR69_AUTH *tr69_auth, uint32 flags)
{
    return(ifx_get_tr69_auth(tr69_auth, flags));
}

int32 ifx_get_tr69_misc_wrapper(TR69_MISC *tr69_misc, uint32 flags)
{
    return(ifx_get_tr69_misc(tr69_misc, flags));
}

#endif // TR69_DEFINED

