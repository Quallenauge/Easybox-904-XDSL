#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"

char8 *ipsec_tunnel_info_params[] = {"cpeId", "pcpeId", "tunnelname", "ikemode", "wanConnIf", "leftsubnet", "rightip", "rightsubnet", "psksecret", "espcipher", "esphash", "ikecipher", "ikehash", "ikedh", "kmpprfalg", "lifetime", "retry", "fEnable"};

#define IFX_VALIDATE_IPSEC_TUNNEL_ENTRY(p_ipsec_tunnel_info, flags) { }
#define IFX_IPSEC_TUNNEL_INFO_PARAM_COUNT 18

int32 ifx_set_ipsec_tunnel_entry(int32 operation, IFX_IPSEC_TUNNEL *p_ipsec_tunnel_info, uint32 flags)
{
	int32	count = 0, passed_index = -1, ret = IFX_SUCCESS,older_enable=0;
	char8	conf_buf[MAX_DATA_LEN];
  char8 sValue[MAX_FILELINE_LEN],sbuf[MAX_FILELINE_LEN],sCommand[MAX_FILELINE_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[IFX_IPSEC_TUNNEL_INFO_PARAM_COUNT], *array_changed_fvp = NULL;
	int32 wanIndx = 0, outflag = IFX_F_DEFAULT;
	char8 *retStr = NULL, buf[MAX_FILELINE_LEN];	

    NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));
	NULL_TERMINATE(sbuf, 0x00, sizeof(sbuf));
	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
    memset(array_fvp, 0, sizeof(array_fvp));

	/*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY) 
	 * append the flag with internal flags */
	if (operation == IFX_OP_DEL) 
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if( (IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	}
	else
		flags |= IFX_F_MODIFY;

	/**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(p_ipsec_tunnel_info)
		/* Do simple validation of flags sucha as less than 0 */
		IFX_VALIDATE_FLAGS(flags)
	}


	sprintf(p_ipsec_tunnel_info->iid.cpeId.secName, "%s", TAG_IPSEC_TUNNEL);
	if (p_ipsec_tunnel_info->iid.pcpeId.Id == 0) {
		/* Then WAN Connection name MUST HAVE been specified 
		 * Use this ConnectionName to extract the parent Section
		 * and the parent's cpeID */

		/* ??? From WEB we get a case of ALL as Connection Name
		 * How to handle this case ???
		 * Currently we don't deal with this case */

		/* Extract the WAN Connection Name for which PortMap needs to be created */
		if (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_MAIN, "connName", 
							p_ipsec_tunnel_info->wan_conn_if, &retStr) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		else {
			/* Now we would have got "wan_x" in the retStr 
			 * Using this retStr extract out the wanIndx
			 * For this wanIndx there should be either a WANIP
			 * or WANPPP Connection */
			wanIndx = atoi(strrchr(retStr, '_') + 1);
			sprintf(buf, "%s_%d_%s", PREFIX_WAN_IP, wanIndx, "cpeId");
			if((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, IFX_F_GET_ANY, 
							(IFX_OUT uint32 *)&outflag, sValue)) != IFX_SUCCESS) {
				/* In WANIP we couldn't find the parent for this PortMap
				 * Now Check in WANPPP Section for the same */

				sprintf(buf, "%s_%d_%s", PREFIX_WAN_PPP, wanIndx, "cpeId");
				if((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP, buf, IFX_F_GET_ANY, 
										(IFX_OUT uint32 *)&outflag, sValue)) != IFX_SUCCESS) {
					/* Here it could be that it belongs to "ALL" category
					 * How do we handle it ?? For now we ignore adding it!
					 * Return an Error!! */

#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
				else {
					/* Populate the pcpeId for PortMap p_ipsec_tunnel_info */

					/* Update the Parent's cpeID and Section Name in piid
				 	 * This would be required only for ADD operation */
					p_ipsec_tunnel_info->iid.pcpeId.Id = atoi(sValue);
					sprintf(p_ipsec_tunnel_info->iid.pcpeId.secName, "%s", TAG_WAN_PPP);
				}
			}
			else {

				/* Populate the pcpeId for PortMap p_ipsec_tunnel_info */

				/* Update the Parent's cpeID and Section Name in piid
				 * This would be required only for ADD operation */
				p_ipsec_tunnel_info->iid.pcpeId.Id = atoi(sValue);
				sprintf(p_ipsec_tunnel_info->iid.pcpeId.secName, "%s", TAG_WAN_IP);
			}
		}
	}
	else {
		/* Parent's cpeId is specified, now get the corresponding parent's
		 * section - which is either WANIP or WANPPP */
		sprintf(conf_buf, "%d", p_ipsec_tunnel_info->iid.pcpeId.Id);
			IFX_DBG("[%d here]",p_ipsec_tunnel_info->iid.pcpeId.Id);
		if (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_IP, "cpeId", 
							conf_buf, &retStr) != IFX_SUCCESS) {
			/* In WANIP we couldn't find the parent for this PortMap
			 * Now Check in WANPPP Section for the same */
						
			if (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_PPP, "cpeId", 
							conf_buf, &retStr) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			else {
				sprintf(p_ipsec_tunnel_info->iid.pcpeId.secName, "%s", TAG_WAN_PPP);
			}
		}
		else {
			sprintf(p_ipsec_tunnel_info->iid.pcpeId.secName, "%s", TAG_WAN_IP);
		}
	

		/* Update the Parent's cpeID and Section Name in piid
		 * This would be required only for ADD operation */
	
		/* Update the WAN ConnName in the PortMap p_ipsec_tunnel_info structure */
		wanIndx = atoi(strrchr(retStr, '_') + 1);
		sprintf(buf, "%s_%d_%s", PREFIX_WAN_MAIN, wanIndx, "connName");
		if((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, IFX_F_GET_ANY, 
					(IFX_OUT uint32 *)&outflag, sValue)) != IFX_SUCCESS) {
		
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		else {
			sprintf(p_ipsec_tunnel_info->wan_conn_if, "%s", sValue);
		}
	}

//    p_ipsec_tunnel_info->iid.pcpeId.Id = 1; /* TODO */

#if 0
	/* currently we allow only 8 tunnels to be configured */
	MAKE_SECTION_COUNT_TAG(TAG_IPSEC_TUNNEL, conf_buf);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPSEC_TUNNEL,
	    	    conf_buf, flags, &outflag, sValue)) != IFX_SUCCESS){
	   		goto IFX_Handler;
		}
		if((atoi(sValue) == 8) && IFX_INT_ADD_F_SET(flags)) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
#endif 
#if 0
	/**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		      /* Check if the Minimum and Maximum Address matches with already existing
       * Pool and if it is not THIS pool */
		IFX_VALIDATE_IPSEC_TUNNEL_ENTRY(p_ipsec_tunnel_info, flags)
	}
#endif

	/**************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
         /* Allocate the IID for this vcc */
//		if(ifx_get_IID(&p_ipsec_tunnel_info->iid, "ikehash") != IFX_SUCCESS) {
		if(ifx_get_IID_Without_TR69(&p_ipsec_tunnel_info->iid, "ikehash") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
    }

	/**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY
	 * Operations 
	 */
	count = 0;
    IFX_DBG(" [%s:%d] before just setting entry %d", __FUNCTION__, __LINE__,p_ipsec_tunnel_info->f_enable);
	if(IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, 0, IFX_IPSEC_TUNNEL_INFO_PARAM_COUNT, ipsec_tunnel_info_params);

		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 2, (int32 *)&p_ipsec_tunnel_info->iid.cpeId.Id, &p_ipsec_tunnel_info->iid.pcpeId.Id);

		ifx_fill_ArrayFvp_strValues(array_fvp, 2, 13,p_ipsec_tunnel_info->TunnelName,
                        &p_ipsec_tunnel_info->ike_mode,
						&p_ipsec_tunnel_info->wan_conn_if,
						&p_ipsec_tunnel_info->LeftSubnet,
						&p_ipsec_tunnel_info->RightIP,
						&p_ipsec_tunnel_info->RightSubnet,
						&p_ipsec_tunnel_info->psksecret,
						&p_ipsec_tunnel_info->esp_cipher,
						&p_ipsec_tunnel_info->esp_hash,
						&p_ipsec_tunnel_info->ike_cipher,
						&p_ipsec_tunnel_info->ike_hash,
						&p_ipsec_tunnel_info->ike_dh,
						&p_ipsec_tunnel_info->kmpprfalg);
		ifx_fill_ArrayFvp_intValues(array_fvp, 15, 2, (int32 *)&p_ipsec_tunnel_info->lifetime,(int32 *)&p_ipsec_tunnel_info->retry);

        sprintf(array_fvp[17].value, "%d", p_ipsec_tunnel_info->f_enable?1:0);
		//ifx_fill_ArrayFvp_intValues(array_fvp, 16, 1, strcmp( p_ipsec_tunnel_info->f_enable,"1")?1:0);
		passed_index = -1;
	}

	count = IFX_IPSEC_TUNNEL_INFO_PARAM_COUNT;

	/* Get Config Index in case of modify/delete operations from CPEID */
	if((IFX_MODIFY_F_SET(flags)) ||
		(IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, p_ipsec_tunnel_info->iid.cpeId, passed_index)
		sprintf(sbuf,"ipsec_tunnel_%d_fEnable",passed_index);
          if((ifx_GetObjData(FILE_RC_CONF, TAG_IPSEC_TUNNEL, sbuf, IFX_F_GET_ANY, (IFX_OUT uint32 *)&outflag, sValue)) != IFX_SUCCESS) {
		IFX_DBG("Failed to get fenable value from rc.conf");
#ifdef IFX_LOG_DEBUG
              IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
              ret = IFX_FAILURE;
              goto IFX_Handler;
           }
	  older_enable = atoi(sValue);
	}

	/* Determine the configuration index - for Add, Delete, Modify operations 
     * Name is partial since index is not known 
     * Fill array_fvp[] */
	if(ifx_get_conf_index_and_nv_pairs(&p_ipsec_tunnel_info->iid, passed_index, PREFIX_IPSEC_TUNNEL_INFO,
				count, array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
	}


	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	if(IFX_ADD_F_NOT_SET(flags)) {
//		CHECK_ACL_RET(p_ipsec_tunnel_info->iid, count, array_fvp,
//						changed_count, array_changed_fvp, flags, IFX_Handler)
	}


    /* In case of Modify or Delete operation, call script to restart iked and spmd */

    //if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) && IFX_INT_ADD_F_NOT_SET(flags)) {
    //}
	/* Delete ipsec rules if delete and modify */
	 if((IFX_MODIFY_F_SET(flags)) ||
                (IFX_DELETE_F_SET(flags))) {
				if(older_enable == 1)
				{
					 sprintf(sCommand, "/etc/rc.d/init.d/ipsec_delete %d %s", passed_index, p_ipsec_tunnel_info->wan_conn_if);
			                 system(sCommand);

				}
		}

	/************** System Config File Update Block ****************/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_IPSEC_TUNNEL, flags, 1, conf_buf);

	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* this will Compact the section and also update the count for both ADD and DELETE */
	if(IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_IPSEC_TUNNEL, flags);


	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	/* System call to Add/Delete/Modify */
	/* Add ipsec rules if ADD and MODIFY */
	 if((IFX_MODIFY_F_SET(flags)) ||
                (IFX_ADD_F_SET(flags))) {
				if(IFX_ADD_F_SET(flags))
				  IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF,p_ipsec_tunnel_info->iid.cpeId, passed_index)
                                if(p_ipsec_tunnel_info->f_enable)
                                {
                                         sprintf(sCommand, "/etc/rc.d/init.d/ipsec_add %d %s", passed_index,p_ipsec_tunnel_info->wan_conn_if);
                                         system(sCommand);

                                }
                }

	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

	/*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if(IFX_MODIFY_F_SET(flags)) {
//		CHECK_N_SEND_NOTIFICATION(p_ipsec_tunnel_info->iid, changed_count, array_changed_fvp, flags, IFX_Handler)
	}
	else if (IFX_INT_ADD_F_SET(flags)) {
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
//		UPDATE_ID_MAP_N_ATTRIBUTES(&p_ipsec_tunnel_info->iid, count, array_fvp, flags, IFX_Handler)

//		CHECK_N_SEND_NOTIFICATION(p_ipsec_tunnel_info->iid, count, array_fvp, flags, IFX_Handler)

		/* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_IPSEC_TUNNEL);

	}
	else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
//		CHECK_N_SEND_NOTIFICATION(p_ipsec_tunnel_info->iid, count, array_fvp, flags, IFX_Handler)

//		UPDATE_ID_MAP_N_ATTRIBUTES(&p_ipsec_tunnel_info->iid, count, array_fvp, flags, IFX_Handler)
	}

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if (IFX_DELETE_F_SET(flags)) {
		if(older_enable != 1) {
		       sprintf(sCommand, "/etc/rc.d/init.d/ipsec_delete %d %s", passed_index,p_ipsec_tunnel_info->wan_conn_if);
		       system(sCommand);
		}
	}
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

IFX_Handler:
	IFX_MEM_FREE(retStr)
//	IFX_MEM_FREE(p_ipsec_tunnel_info)
	IFX_MEM_FREE(array_changed_fvp);
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else {
		return IFX_SUCCESS;
    }
}

int32 ifx_get_ipsec_tunnel_entry(IFX_IPSEC_TUNNEL *pp_ipsec_tunnel_info, uint32 flags)
{
	char8	sBuf[MAX_FILELINE_LEN], *sValue=NULL;
	char8	buf[MAX_FILELINE_LEN];
	int32  passed_index = -1, count = 0, outFlag = IFX_F_DEFAULT;
	// uint32 outflag = IFX_F_DEFAULT;
	int		ret = IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR array_fvp[IFX_IPSEC_TUNNEL_INFO_PARAM_COUNT + 1];

     /* Fill the section tag */
    sprintf(pp_ipsec_tunnel_info->iid.cpeId.secName, "%s", TAG_IPSEC_INFO);

     /* get index from cpeid */
     IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, pp_ipsec_tunnel_info->iid.cpeId, passed_index)
     sprintf(sBuf, "%s_%d_", PREFIX_IPSEC_TUNNEL_INFO, passed_index);
     if((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_IPSEC_INFO,
	              sBuf, flags, &sValue)) != IFX_SUCCESS){							
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
     memset(array_fvp, 0x00, sizeof(array_fvp));

     form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);


    /* copy the pp_ipsec_tunnel_info entries into the structure */
		ifx_fill_intValues_ArrayFvp(array_fvp, 0, 2,
                                            (int32 *)&pp_ipsec_tunnel_info->iid.cpeId.Id,
                                            &pp_ipsec_tunnel_info->iid.pcpeId.Id);

		ifx_fill_strValues_ArrayFvp(array_fvp, 2, 13,pp_ipsec_tunnel_info->TunnelName,
                        &pp_ipsec_tunnel_info->ike_mode,
						&pp_ipsec_tunnel_info->wan_conn_if,
						&pp_ipsec_tunnel_info->LeftSubnet,
						&pp_ipsec_tunnel_info->RightIP,
						&pp_ipsec_tunnel_info->RightSubnet,
						&pp_ipsec_tunnel_info->psksecret,
						&pp_ipsec_tunnel_info->esp_cipher,
						&pp_ipsec_tunnel_info->esp_hash,
						&pp_ipsec_tunnel_info->ike_cipher,
						&pp_ipsec_tunnel_info->ike_hash,
						&pp_ipsec_tunnel_info->ike_dh,
						&pp_ipsec_tunnel_info->kmpprfalg);
		ifx_fill_intValues_ArrayFvp(array_fvp, 15, 2,(int32 *) &pp_ipsec_tunnel_info->lifetime,(int32 *) &pp_ipsec_tunnel_info->retry);
#if 1
		sprintf(buf, "ipsec_tunnel_%d_fEnable",passed_index);
                IFX_DBG("\n\n passed index is ipsec_tunnel_%d_fEnable  %s", passed_index,buf);
		if ( (ifx_GetObjData(FILE_RC_CONF, TAG_IPSEC_TUNNEL, 
				buf, flags, (IFX_OUT uint32 *)&outFlag, sValue) == IFX_SUCCESS)  )	{
			if(!strcmp(sValue,"1"))
				pp_ipsec_tunnel_info->f_enable = 1;
			else
				pp_ipsec_tunnel_info->f_enable = 0;
                IFX_DBG("\n\n passed index enable %d", pp_ipsec_tunnel_info->f_enable);
		}
#endif
//		ifx_fill_intValues_ArrayFvp(array_fvp, 16, 1, (int32 *)&pp_ipsec_tunnel_info->f_enable);

IFX_Handler:
   IFX_MEM_FREE(sValue);
   if(ret != IFX_SUCCESS){
     IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
     return ret;
   }
else {
}
	return IFX_SUCCESS;
}
int32 ifx_get_all_ipsec_tunnel_entries(int32 *num_entries, IFX_IPSEC_TUNNEL **pp_ipsec_tunnel_info, uint32 flags)
{
	int32   nCount=0, nIndex=0;
    int32   ret = IFX_SUCCESS, ipsec_tunnel_count = 0;
	char8   sCommand[MAX_FILELINE_LEN], sBuf[MAX_FILELINE_LEN];
	uint32  outFlag = IFX_F_DEFAULT;

	IFX_IPSEC_TUNNEL *t_ptr = NULL;
	
	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
    NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

	/* first, get the number of conditional entries from rc.conf */
	MAKE_SECTION_COUNT_TAG(TAG_IPSEC_INFO, sCommand);
			    
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPSEC_INFO,
	        sCommand, flags, &outFlag, sBuf)) != IFX_SUCCESS){
	   goto IFX_Handler;
	}
    nCount = atoi(sBuf);
	if (nCount == 0) {
	  *num_entries = 0;
	  *pp_ipsec_tunnel_info = NULL;
	   goto IFX_Handler;
	}
	*pp_ipsec_tunnel_info = NULL;
	t_ptr = (IFX_IPSEC_TUNNEL *)IFX_MALLOC(nCount *
    sizeof(IFX_IPSEC_TUNNEL));
	if(t_ptr == NULL){
		ret = IFX_FAILURE;
	    goto IFX_Handler;
	}
   *pp_ipsec_tunnel_info = t_ptr;

   for (nIndex=0; nIndex < nCount; nIndex++){

      NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
      sprintf(sCommand, "%s_%d_cpeId", PREFIX_IPSEC_TUNNEL_INFO, nIndex);
      if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_IPSEC_INFO,
	        sCommand, flags, &outFlag, sBuf)) != IFX_SUCCESS){
	      goto IFX_Handler;
   	}

      (*pp_ipsec_tunnel_info + ipsec_tunnel_count)->iid.cpeId.Id = atoi(sBuf);

      if((ret = ifx_get_ipsec_tunnel_entry((*pp_ipsec_tunnel_info + ipsec_tunnel_count), flags) !=
      IFX_SUCCESS)) {
         goto IFX_Handler;
      }


	ipsec_tunnel_count++;
 IFX_DBG("[%s:%d] reaced here",__FUNCTION__,__LINE__); 
 }

 IFX_DBG("[%s:%d] reaced here",__FUNCTION__,__LINE__); 
 *num_entries = ipsec_tunnel_count;
 
 IFX_DBG("[%s:%d] reaced here",__FUNCTION__,__LINE__); 
 IFX_Handler:
 if(ret != IFX_SUCCESS) {
 IFX_DBG("[%s:%d] reaced here",__FUNCTION__,__LINE__); 
    IFX_MEM_FREE(*pp_ipsec_tunnel_info)
 IFX_DBG("[%s:%d] reaced here",__FUNCTION__,__LINE__); 
    *num_entries = 0;
 IFX_DBG("[%s:%d] reaced here",__FUNCTION__,__LINE__); 
    IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
    return ret;
  }
else {
return IFX_SUCCESS;
}
}

