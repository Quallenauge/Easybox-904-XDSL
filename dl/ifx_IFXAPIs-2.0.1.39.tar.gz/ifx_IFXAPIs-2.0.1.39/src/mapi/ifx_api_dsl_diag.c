/* 
** =============================================================================
**   FILE NAME        : ifx_api_dsl_diag.c
**   PROJECT          : AMAZON MAPI
**   DATE             : 11-May-2007
**   AUTHOR           : Amazon API Team
**   DESCRIPTION      : This file contains the GET/SET functions supported by the MAPI
			framework 

**   REFERENCES       : 
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/

#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <time.h>
#include <string.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <sys/sysinfo.h>
#include <sys/ioctl.h>
#include <ifx_config.h>
#include <ifx_common.h>
#include <ifx_amazon_cfg.h>
#include "ifx_emf.h"
#include "ifx_snmpdefs.h"
#include "ifx_api_util.h"
//#include "ifx_api_dsl_include.h"

#define WRITE_DSL_DIAG_TO_FILE(conf_buf, flags, _ret, _handler) { \
		_ret = ifx_SetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, flags, 1, conf_buf); \
		/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */ \
		if(_ret != IFX_SUCCESS) { \
			sprintf(conf_buf, "%s_diagnosticState=\"%d\"\n", PREFIX_DSL_DIAG, WAN_DIAG_ERROR_EXT); \
			if(ifx_SetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, flags, 1, conf_buf) != IFX_SUCCESS) { \
				_ret = IFX_FAILURE; \
				goto _handler; \
			} \
		} \
	}


#define BRINGDOWN_SERVICES(owner) { \
		if(owner == IFX_TR69) { \
			system("/etc/rc.d/free_memory.sh diag"); \
		} \
		system("/etc/rc.d/rc.bringup_wan stop"); \
		system("/etc/rc.d/killproc inetd"); \
		system("killall -9 oamd syslogd"); \
	}

#ifdef CONFIG_FEATURE_CLIP
	#define	CLIP_SERVICE	{ \
		if(CONFIG_FEATURE_CLIP) \
		{ \
				system("/usr/sbin/atmarpd -b -l /dev/null 2> /dev/null"); \
		} \
	}
#else
	#define CLIP_SERVICE {}
#endif

#define BRINGUP_SERVICES { \
		/* oam will be restarted when the link comes up, so no need to start manually */ \
		/* system("/etc/rc.d/syslogd start"); start syslogd \ */ \
		system("/sbin/syslogd -s 25 -b 2"); /* since syslogd script is not present */ \
		system("/sbin/klogd &"); \
		system("/etc/rc.d/rc.bringup_lan restart"); /* to start udhcpd or udhcpr */ \
		CLIP_SERVICE; \
		system("/etc/rc.d/init.d/dns_relay start"); \
		system("/etc/rc.d/rc.bringup_services start"); \
		system("/etc/rc.d/rc.bringup_wan start &"); \
	}


int32 ifx_cpe_api_set_dsl_diagnostics(int32 operation, WAN_DSL_DIAGNOSTICS *Wan_Dsl_Diag, uint32 flags)
{
	// char8 buf[MAX_FILELINE_LEN];
	char8	conf_buf[2 * MAX_DATA_LEN];
	int32	count = 0, ret = IFX_SUCCESS, cmd = 0;
	IFX_NAME_VALUE_PAIR array_fvp[20];

	memset(array_fvp, 0x00, sizeof(array_fvp));

	/*************** Prolog Block ****************/
	/* Based on operation (ADD or DEL or MOD) 
	 * append the flag with internal flags. For other ops, 
	 * the flag denotes the action */
	if(operation == IFX_OP_MOD)
		flags |= IFX_F_MODIFY;


	// Check if f_enable is set to enabled
	// and diagnostic_state is WAN_DSL_START_DIAGNOSING
	if((Wan_Dsl_Diag->f_enable == IFX_ENABLED) &&
					(Wan_Dsl_Diag->diagnostic_state == WAN_DIAG_START_DIAGNOSING)) {


		// Test Modes 
		DSL_G997_LineActivate_t lineActivateData;
		DSL_AutobootControl_t autobootControl;
		DSL_LineState_t lineState;
		DSL_G997_DeltFreeResources_t DeltFreeResources;
/*
		// DSL Event Status
		DSL_EventStatus_t eventStatus;


		//ACTATP - Actual Aggregrate Transmitted Power 
		DSL_uint32_t DownStreamACTATP;
		DSL_uint32_t UpStreamACTATP;

		//ACTPSD - Actual Power Spectral Density 
		DSL_uint32_t DownStreamACTPS;
		DSL_uint32_t UpStreamACTPS;

		//HLINSC - Linear Representation Scale
		DSL_uint16_t DownStreamDeltHlinScaleData;

		//HLINps - Linear Channel Characteristics
		DSL_G997_ComplexNumber_t DownStreamHLINCmplxData[DSL_MAX_NSC];

		//QLNps - Quiet Line Noise per SubCarrier
		DSL_uint8_t DownStreamQLNNSCData[DSL_MAX_NSC];

		//SNRps - Signal-to-Noise Ratio per SubCarrier
		DSL_uint8_t DownStreamSNRNSCData[DSL_MAX_NSC];

		//BITSps - BIT Allocation per SubCarrier
		DSL_uint8_t DownStreamBITNSCData[DSL_MAX_NSC];

		//GAINSps - GAIN Allocation per SubCarrier
		DSL_uint16_t DownStreamGAINNSCData[DSL_MAX_NSC];
*/

		/*  before starting the diagnostics, kill all the services to free up some space
			because adsl link going down and dsl diagnostics need contiguous memory space
			and once the diagnostics is complete restore the system state by restarting all
			the services that were stopped at the beginning */
		BRINGDOWN_SERVICES(Wan_Dsl_Diag->iid.config_owner)

		/*  using ioctl  reset the dsl parameter values in dsl_api data structure before
			starting the diagnostics */

		// STEP 0: Free the DELT Resources if it is already allocated
	    memset(&DeltFreeResources, 0x00, sizeof(DSL_G997_DeltFreeResources_t));			
        cmd  = DSL_FIO_G997_DELT_FREE_RESOURCES;
		ret = ifx_cpe_api_device_set_operation(cmd, (void *) &DeltFreeResources, flags);
		if (ret < 0) {
#ifdef IFX_LOG_DEBUG                                                    
			IFX_DBG ("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__, __LINE__);
#endif 
			Wan_Dsl_Diag->diagnostic_state = WAN_DIAG_ERROR_EXT;
			goto IFX_Handler;
		}   
		else {
#ifdef IFX_LOG_DEBUG                                                    
			IFX_DBG ("\n\n In %s: ioctl  passed at line:%d!\n", __FUNCTION__, __LINE__);
#endif 
		}


		// STEP 1: Configure Line State to Loop-Diagnostic Mode
		memset(&lineActivateData, 0x00, sizeof(DSL_G997_LineActivate_t));             
		cmd = DSL_FIO_G997_LINE_ACTIVATE_CONFIG_SET;
		lineActivateData.data.nLDSF = DSL_G997_AUTO_LDSF;
		ret = ifx_cpe_api_device_set_operation(cmd, (void *) &lineActivateData, flags);
		if (ret < 0) {
#ifdef IFX_LOG_DEBUG                                                    
				IFX_DBG ("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__, __LINE__);
#endif 
				Wan_Dsl_Diag->diagnostic_state = WAN_DIAG_ERROR_EXT;
				goto IFX_Handler;
		}   
		else {
#ifdef IFX_LOG_DEBUG                                                    
				IFX_DBG ("\n\n In %s: ioctl  passed at line:%d!\n", __FUNCTION__, __LINE__);
#endif 
		}


		// STEP 2: Restart Auto-boot daemon thread
		memset(&autobootControl, 0x00, sizeof(DSL_AutobootControl_t));             
		cmd = DSL_FIO_AUTOBOOT_CONTROL_SET;
		autobootControl.data.nCommand = DSL_AUTOBOOT_CTRL_RESTART;
		ret = ifx_cpe_api_device_set_operation(cmd, (void *) &autobootControl, flags);
		if (ret < 0) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG ("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__, __LINE__);
#endif
				Wan_Dsl_Diag->diagnostic_state = WAN_DIAG_ERROR_EXT;
				goto IFX_Handler;
		}
		else {
#ifdef IFX_LOG_DEBUG
				IFX_DBG ("\n\n In %s: ioctl  passed at line:%d!\n", __FUNCTION__, __LINE__);
#endif
		}

		/* wait for some time till autoboot daemon restarts */
		sleep(3);

		// STEP 3: Check for the Event DSL_LOOP_DIAGNOSTIC_COMPLETE
		memset(&lineState, 0x00, sizeof(DSL_LineState_t));
		cmd = DSL_FIO_LINE_STATE_GET;
		ret = ifx_cpe_api_device_get_operation(cmd, (void *) &lineState, flags); 
		if (ret < 0) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG ("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__, __LINE__);
#endif
				Wan_Dsl_Diag->diagnostic_state = WAN_DIAG_ERROR_EXT;
				//goto IFX_Handler;
		}
		else {
#ifdef IFX_LOG_DEBUG
				IFX_DBG ("\n\n In %s: ioctl  passed at line:%d!\n", __FUNCTION__, __LINE__);
#endif
		}


		/* Loop till the Event Type is LINE_STATE & Status is DSL_LINESTATE_LOOPDIAGNOSTIC_COMPLETE */
		while (1) {
			if((lineState.data.nLineState == DSL_LINESTATE_LOOPDIAGNOSTIC_COMPLETE) ||
			   (lineState.data.nLineState == DSL_LINESTATE_SHOWTIME_TC_SYNC)) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				break;
			}

			/* - check if line state is exception then update the state to error
			   - dsl api should return an error it does not delt measurement in a specific mode
			     eg : g.dmt

			   - dsl api should return exception if link goes down while the diagnostics test is running
			   - if dslam is not supporting loopback or running an old firmware, then diagnostics
				 wont succeed and cpe will come back to showtime. then also dsl api should return exception
			 */
//			if((count == 32766) || 
		
			/* Subramani -  This error state is not clear 
		                we break this loop after 250 secs 
				TRAIN = 60, DIAG=120, TRAIN=60 	
			*/
					
			if(count < 250) 
			  {
				sleep(1);
			  } else {
				break;
			  }	

			/*
			if((lineState.data.nLineState == DSL_LINESTATE_EXCEPTION) ||
			   (lineState.data.nLineState == DSL_LINESTATE_SHOWTIME_TC_SYNC)) {
				sprintf(conf_buf, "%s_diagnosticState=\"%d\"\n", PREFIX_DSL_DIAG, WAN_DIAG_ERROR_EXT);
				Wan_Dsl_Diag->diagnostic_state = WAN_DIAG_ERROR_EXT;
				WRITE_DSL_DIAG_TO_FILE(conf_buf, flags, ret, IFX_Handler)
				ret = IFX_FAILURE;
				goto IFX_Handler;
			} */


			memset(&lineState, 0x00, sizeof(DSL_LineState_t));
			cmd = DSL_FIO_LINE_STATE_GET;
			ret = ifx_cpe_api_device_get_operation(cmd, (void *) &lineState, flags); 
			if (ret < 0) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG ("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__, __LINE__);
#endif
				Wan_Dsl_Diag->diagnostic_state = WAN_DIAG_ERROR_EXT;
				//goto IFX_Handler;
			}
			else {
#ifdef IFX_LOG_DEBUG
				IFX_DBG ("\n\n In %s: ioctl  passed at line:%d!\n", __FUNCTION__, __LINE__);
#endif
			}

			count++;
		}


		/* STEP 4: Read the Required Diagnostic Data from the driver
		 *		   ACTPSDds, ACTPSDus, ACTATPds, ACTATPus, HLINSCdse,
		 *		   HLINpsds, QLNpsds, SNRpsds, BITSpsds, GAINSpsds
		 */

		count = 0;
		Wan_Dsl_Diag->diagnostic_state = WAN_DIAG_COMEPLETE; 
		sprintf(Wan_Dsl_Diag->iid.cpeId.secName, "%s", TAG_DSL_DIAG);
		sprintf(Wan_Dsl_Diag->iid.cpeId.secName, "%s", TAG_WAN_DEVICE);

		/* Fill fieldname and values into array_fvp */
		sprintf(array_fvp[count++].fieldname, "%s_cpeId", PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].fieldname, "%s_pcpeId", PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].fieldname, "%s_fEnable", PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].fieldname, "%s_diagnosticState", PREFIX_DSL_DIAG);
		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 4, (int32 *)&Wan_Dsl_Diag->iid.cpeId.Id, 
						&Wan_Dsl_Diag->iid.pcpeId.Id,
						&Wan_Dsl_Diag->f_enable, &Wan_Dsl_Diag->diagnostic_state);

		count = 4;
		//ACTATPds - DownStream Actual Aggregrate Transmitted Power 
		//ACTPSDds - DownStream Actual Power Spectral Density 
		/* [ start */
		memset(&Wan_Dsl_Diag->dsLineStatus, 0x00, sizeof(DSL_G997_LineStatus_t));             
		Wan_Dsl_Diag->dsLineStatus.nDirection = DSL_DOWNSTREAM;                               
		cmd = DSL_FIO_G997_LINE_STATUS_GET;                                 
		ret = ifx_cpe_api_device_get_operation(cmd, (void *) &(Wan_Dsl_Diag->dsLineStatus), flags);
		if (ret < 0) {
#ifdef IFX_LOG_DEBUG                                                    
				IFX_DBG ("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__, __LINE__);
#endif  
				//goto IFX_Handler;
		}   
		else {
#ifdef IFX_LOG_DEBUG                                                    
				IFX_DBG ("\n\n In %s: ioctl  passed at line:%d!\n", __FUNCTION__, __LINE__);
#endif  
		}

		//DownStreamACTATP = Wan_Dsl_Diag->dsLineStatus.data.ACTATP;                            
		sprintf(array_fvp[count].fieldname, "%s_ACTATPds", PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].value, "%d", Wan_Dsl_Diag->dsLineStatus.data.ACTATP);
	
		//DownStreamACTPS = Wan_Dsl_Diag->dsLineStatus.data.ACTPS;                            
		sprintf(array_fvp[count].fieldname, "%s_ACTPSDds", PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].value, "%d", Wan_Dsl_Diag->dsLineStatus.data.ACTPS);


		memset(&Wan_Dsl_Diag->usLineStatus, 0x00, sizeof(DSL_G997_LineStatus_t));             
		Wan_Dsl_Diag->usLineStatus.nDirection = DSL_UPSTREAM;
		cmd = DSL_FIO_G997_LINE_STATUS_GET;                                 
		ret = ifx_cpe_api_device_get_operation(cmd, (void *) &(Wan_Dsl_Diag->usLineStatus), flags); 
		if (ret < 0) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG ("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__, __LINE__);
#endif
				//goto IFX_Handler;
		} 
		else {
#ifdef IFX_LOG_DEBUG
				IFX_DBG ("\n\n In %s: ioctl  passed at line:%d!\n", __FUNCTION__, __LINE__);
#endif
		} 

		//ACTATPus - UpStream Actual Aggregrate Transmitted Power 
		//ACTPSDus - UpStream Actual Power Spectral Density 
		//UpStreamACTATP = Wan_Dsl_Diag->usLineStatus.data.ACTATP;
		sprintf(array_fvp[count].fieldname, "%s_ACTATPus", PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].value, "%d", Wan_Dsl_Diag->usLineStatus.data.ACTATP); 
		
		//UpStreamACTPS = Wan_Dsl_Diag->usLineStatus.data.ACTPS;
		sprintf(array_fvp[count].fieldname, "%s_ACTPSDus", PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].value, "%d", Wan_Dsl_Diag->dsLineStatus.data.ACTPS);
		/* end ] */


		//HLINSCds - DownStream Linear Representation Scale
		memset(&Wan_Dsl_Diag->hlinScale, 0x00, sizeof(DSL_G997_DeltHlinScale_t));
		Wan_Dsl_Diag->hlinScale.nDirection = DSL_DOWNSTREAM;                               
		cmd = DSL_FIO_G997_DELT_HLIN_SCALE_GET;                                 
		ret = ifx_cpe_api_device_get_operation(cmd, (void *) &(Wan_Dsl_Diag->hlinScale), flags);
		if (ret < 0) {
#ifdef IFX_LOG_DEBUG                                                    
				IFX_DBG ("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__, __LINE__);
#endif  
				//goto IFX_Handler;
		}   
		else {
#ifdef IFX_LOG_DEBUG                                                    
				IFX_DBG ("\n\n In %s: ioctl  passed at line:%d!\n", __FUNCTION__, __LINE__);
#endif  
		}
		//DownStreamDeltHlinScaleData = Wan_Dsl_Diag->hlinScale.data.nDeltHlinScale;
		sprintf(array_fvp[count].fieldname, "%s_HLINSCds", PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].value, "%d", Wan_Dsl_Diag->hlinScale.data.nDeltHlinScale);

		// STEP 5: Update the above parameters to a DSL Statics file
		/********* System Config File Update Block  **********/
		/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
		
		memset(conf_buf, 0x00, sizeof(conf_buf));
		form_cfgdb_buf(conf_buf, count, array_fvp);

		WRITE_DSL_DIAG_TO_FILE(conf_buf, flags, ret, IFX_Handler)
	}
	else {
		sprintf(Wan_Dsl_Diag->iid.cpeId.secName, "%s", TAG_DSL_DIAG);
		sprintf(Wan_Dsl_Diag->iid.cpeId.secName, "%s", TAG_WAN_DEVICE);

		count = 0;
		memset(array_fvp, 0x00, sizeof(array_fvp));

		/* Fill fieldname and values into array_fvp */
		sprintf(array_fvp[count++].fieldname, "%s_cpeId", PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].fieldname, "%s_pcpeId", PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].fieldname, "%s_fEnable", PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].fieldname, "%s_diagnosticState", PREFIX_DSL_DIAG);
		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 4, (int32 *)&Wan_Dsl_Diag->iid.cpeId.Id, &Wan_Dsl_Diag->iid.pcpeId.Id,
										&Wan_Dsl_Diag->f_enable, &Wan_Dsl_Diag->diagnostic_state);

		count = 4;

		/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
		memset(conf_buf, 0x00, sizeof(conf_buf));
		form_cfgdb_buf(conf_buf, count, array_fvp);

		WRITE_DSL_DIAG_TO_FILE(conf_buf, flags, ret, IFX_Handler)
	}

IFX_Handler:
		if((Wan_Dsl_Diag->f_enable == IFX_ENABLED) &&
					(Wan_Dsl_Diag->diagnostic_state == WAN_DIAG_COMEPLETE || 
					Wan_Dsl_Diag->diagnostic_state == WAN_DIAG_ERROR_EXT)) {
			BRINGUP_SERVICES
		}

		if(ret != IFX_SUCCESS) {
			IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
			return ret;
		}
		else
				return IFX_SUCCESS;
}


/* This function is to intialize the sections required by the dynamic objects in a /tmp/xxxx file
   Otherwise a get on a dynamic object which does not exist may result in failure */
int32 ifx_dynamic_object_init(IFX_ID *iid)
{
	int32	ret = IFX_SUCCESS, flags = IFX_F_INT_ADD;

	/* Initialize dsl diagnostics object in FILE_DYN_INFO */
	if(!strcmp(iid->cpeId.secName, TAG_DSL_DIAG)) {
		char8	conf_buf[2 * MAX_DATA_LEN];
		int32	i = 0, count = 0;
		IFX_NAME_VALUE_PAIR array_fvp[20];

		memset(array_fvp, 0x00, sizeof(array_fvp));

		/* Fill fieldname and values into array_fvp */
		sprintf(array_fvp[count].fieldname, "%s_cpeId", PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].value, "%d", 1);
		sprintf(array_fvp[count].fieldname, "%s_pcpeId", PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].value, "%d", 1);
		sprintf(array_fvp[count].fieldname, "%s_fEnable", PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].value, "%d", 1);
		sprintf(array_fvp[count].fieldname, "%s_diagnosticState", PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].value, "%d", 0);

		sprintf(array_fvp[count++].fieldname, "%s_ACTATPds", PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].fieldname, "%s_ACTATPus", PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].fieldname, "%s_ACTPSDds", PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].fieldname, "%s_ACTPSDus", PREFIX_DSL_DIAG);
		sprintf(array_fvp[count++].fieldname, "%s_HLINSCds", PREFIX_DSL_DIAG);

		/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
		memset(conf_buf, 0x00, sizeof(conf_buf));
		form_cfgdb_buf(conf_buf, count, array_fvp);

		WRITE_DSL_DIAG_TO_FILE(conf_buf, flags, ret, IFX_Handler)

		count = 0;
		memset(array_fvp, 0x00, sizeof(array_fvp));

		for (i = 0; i < 16; i++) { /* 16 = 512 (DSL_MAX_NSC) / 32 (comma seperated list of data) */
			sprintf(array_fvp[count++].fieldname, "%s_HLINpsds_%d", PREFIX_DSL_DIAG, i);
		}

		/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
		memset(conf_buf, 0x00, sizeof(conf_buf));
		form_cfgdb_buf(conf_buf, count, array_fvp);

		WRITE_DSL_DIAG_TO_FILE(conf_buf, flags, ret, IFX_Handler)
#if 0
		count = 0;
		memset(array_fvp, 0x00, sizeof(array_fvp));

		for (i = 0; i < 16; i++) { /* 16 = 512 (DSL_MAX_NSC) / 32 (comma seperated list of data) */
			sprintf(array_fvp[count++].fieldname, "%s_QLNpsds_%d", PREFIX_DSL_DIAG, i);
		}

		/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
		memset(conf_buf, 0x00, sizeof(conf_buf));
		form_cfgdb_buf(conf_buf, count, array_fvp);

		WRITE_DSL_DIAG_TO_FILE(conf_buf, flags, ret, IFX_Handler)

		count = 0;
		memset(array_fvp, 0x00, sizeof(array_fvp));

		for (i = 0; i < 16; i++) { /* 16 = 512 (DSL_MAX_NSC) / 32 (comma seperated list of data) */
			sprintf(array_fvp[count++].fieldname, "%s_SNRpsds_%d", PREFIX_DSL_DIAG, i);
		}

		/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
		memset(conf_buf, 0x00, sizeof(conf_buf));
		form_cfgdb_buf(conf_buf, count, array_fvp);

		WRITE_DSL_DIAG_TO_FILE(conf_buf, flags, ret, IFX_Handler)

		count = 0;
		memset(array_fvp, 0x00, sizeof(array_fvp));

		for (i = 0; i < 16; i++) { /* 16 = 512 (DSL_MAX_NSC) / 32 (comma seperated list of data) */
			sprintf(array_fvp[count++].fieldname, "%s_BITSpsds_%d", PREFIX_DSL_DIAG, i);
		}

		/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
		memset(conf_buf, 0x00, sizeof(conf_buf));
		form_cfgdb_buf(conf_buf, count, array_fvp);

		WRITE_DSL_DIAG_TO_FILE(conf_buf, flags, ret, IFX_Handler)

		count = 0;
		memset(array_fvp, 0x00, sizeof(array_fvp));

		for (i = 0; i < 16; i++) { /* 16 = 512 (DSL_MAX_NSC) / 32 (comma seperated list of data) */
			sprintf(array_fvp[count++].fieldname, "%s_GAINSpsds_%d", PREFIX_DSL_DIAG, i);
		}

		/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
		memset(conf_buf, 0x00, sizeof(conf_buf));
		form_cfgdb_buf(conf_buf, count, array_fvp);

		WRITE_DSL_DIAG_TO_FILE(conf_buf, flags, ret, IFX_Handler)
#endif
	}


IFX_Handler:
	if(ret != IFX_SUCCESS)
		return ret;
	else
		return IFX_SUCCESS;
}


int32 ifx_cpe_api_get_dsl_diagnostics(WAN_DSL_DIAGNOSTICS *Wan_Dsl_Diag, uint32 flags)
{
	int32	cmd=0, ret = IFX_SUCCESS;
	uint32	outFlag = IFX_F_DEFAULT;
	char8	buf[MAX_FILELINE_LEN], sValue[MAX_DATA_LEN];

	sprintf(buf, "%s_cpeId", PREFIX_DSL_DIAG);
	if ((ret = ifx_GetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->iid.cpeId.Id = atoi(sValue);

	sprintf(buf, "%s_pcpeId", PREFIX_DSL_DIAG);
	if ((ret = ifx_GetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->iid.pcpeId.Id = atoi(sValue);

	sprintf(Wan_Dsl_Diag->iid.cpeId.secName, "%s", TAG_DSL_DIAG);
	sprintf(Wan_Dsl_Diag->iid.cpeId.secName, "%s", TAG_WAN_DEVICE);

	sprintf(buf, "%s_fEnable", PREFIX_DSL_DIAG);
	if ((ret = ifx_GetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->f_enable = atoi(sValue);

	sprintf(buf, "%s_diagnosticState", PREFIX_DSL_DIAG);
	if ((ret = ifx_GetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->diagnostic_state = atoi(sValue);

	sprintf(buf, "%s_ACTATPds", PREFIX_DSL_DIAG);
	if ((ret = ifx_GetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->dsLineStatus.data.ACTATP = atoi(sValue); // ACTATP should be filled with ACTATPds or ACTATPus

	sprintf(buf, "%s_ACTATPus", PREFIX_DSL_DIAG);
	if ((ret = ifx_GetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->usLineStatus.data.ACTATP = atoi(sValue); // ACTATP should be filled with ACTATPds or ACTATPus

	sprintf(buf, "%s_ACTPSDds", PREFIX_DSL_DIAG);
	if ((ret = ifx_GetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->dsLineStatus.data.ACTPS = atoi(sValue); // ACTPS should be filled with ACTPSDds or ACTPSDus

	sprintf(buf, "%s_ACTPSDus", PREFIX_DSL_DIAG);
	if ((ret = ifx_GetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->usLineStatus.data.ACTPS = atoi(sValue); // ACTPS should be filled with ACTPSDds or ACTPSDus

	//HLINSCds
	sprintf(buf, "%s_HLINSCds", PREFIX_DSL_DIAG);
	if ((ret = ifx_GetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	Wan_Dsl_Diag->hlinScale.data.nDeltHlinScale = atoi(sValue);

	//HLINSCus
	memset(&Wan_Dsl_Diag->hlinScaleus, 0x00, sizeof(DSL_G997_DeltHlinScale_t));
	Wan_Dsl_Diag->hlinScaleus.nDirection = DSL_UPSTREAM;                               
	Wan_Dsl_Diag->hlinScaleus.nDeltDataType = DSL_DELT_DATA_DIAGNOSTICS;
	cmd =  DSL_FIO_G997_DELT_HLIN_SCALE_GET;
	ret = ifx_cpe_api_device_get_operation(cmd, (void *) &(Wan_Dsl_Diag->hlinScaleus), flags);
	
	//HLINpsds - DownStream Linear Channel Characteristics
	Wan_Dsl_Diag->hlin.nDirection = DSL_DOWNSTREAM; 
	Wan_Dsl_Diag->hlin.nDeltDataType = DSL_DELT_DATA_DIAGNOSTICS;
	cmd =  DSL_FIO_G997_DELT_HLIN_GET;
	ret = ifx_cpe_api_device_get_operation(cmd, (void *) &(Wan_Dsl_Diag->hlin), flags);
	if (ret < 0)
	{
		#ifdef IFX_LOG_DEBUG                             
		IFX_DBG ("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__, __LINE__);
		#endif 
	}   

	//HLINpsus - UpStream Linear Channel Characteristics
	Wan_Dsl_Diag->hlinus.nDirection = DSL_UPSTREAM;          
	Wan_Dsl_Diag->hlinus.nDeltDataType = DSL_DELT_DATA_DIAGNOSTICS;
	cmd =  DSL_FIO_G997_DELT_HLIN_GET;
	ret = ifx_cpe_api_device_get_operation(cmd, (void *) &(Wan_Dsl_Diag->hlinus), flags);
	if (ret < 0)
	{
		#ifdef IFX_LOG_DEBUG     
		IFX_DBG ("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__, __LINE__);
		#endif
	}   

	//HLOG - Upstream
	Wan_Dsl_Diag->hlogus.nDirection = DSL_UPSTREAM;          
	Wan_Dsl_Diag->hlogus.nDeltDataType = DSL_DELT_DATA_DIAGNOSTICS;
	cmd =  DSL_FIO_G997_DELT_HLOG_GET;
	ret = ifx_cpe_api_device_get_operation(cmd, (void *) &(Wan_Dsl_Diag->hlogus), flags);
	if (ret < 0)
	{
		#ifdef IFX_LOG_DEBUG     
		IFX_DBG ("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__, __LINE__);
		#endif
	}

	//HLOG - Downstream
	Wan_Dsl_Diag->hlogds.nDirection = DSL_DOWNSTREAM;          
	Wan_Dsl_Diag->hlogds.nDeltDataType = DSL_DELT_DATA_DIAGNOSTICS;
	cmd =  DSL_FIO_G997_DELT_HLOG_GET;
	ret = ifx_cpe_api_device_get_operation(cmd, (void *) &(Wan_Dsl_Diag->hlogds), flags);
	if (ret < 0)
	{
		#ifdef IFX_LOG_DEBUG     
		IFX_DBG ("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__, __LINE__);
		#endif
	}

	//QLN - DownStream
	Wan_Dsl_Diag->qln.nDirection = DSL_DOWNSTREAM;
	Wan_Dsl_Diag->qln.nDeltDataType = DSL_DELT_DATA_DIAGNOSTICS;
	cmd = DSL_FIO_G997_DELT_QLN_GET;
	ret = ifx_cpe_api_device_get_operation(cmd, (void *)&(Wan_Dsl_Diag->qln), flags);
	if (ret < 0)
	{
		#ifdef IFX_LOG_DEBUG                                                    
		IFX_DBG ("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__, __LINE__);
		#endif  
	}   

	//QLN - UpStream
	Wan_Dsl_Diag->qlnus.nDirection = DSL_UPSTREAM;
	Wan_Dsl_Diag->qlnus.nDeltDataType = DSL_DELT_DATA_DIAGNOSTICS;
	cmd = DSL_FIO_G997_DELT_QLN_GET;
	ret = ifx_cpe_api_device_get_operation(cmd, (void *)&(Wan_Dsl_Diag->qlnus), flags);
	if (ret < 0)
	{
		#ifdef IFX_LOG_DEBUG                                                    
		IFX_DBG ("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__, __LINE__);
		#endif  
	}

	//SNR - DownStream Signal-to-Noise
	Wan_Dsl_Diag->snrds.nDirection = DSL_DOWNSTREAM;
	Wan_Dsl_Diag->snrds.nDeltDataType = DSL_DELT_DATA_DIAGNOSTICS;
	cmd = DSL_FIO_G997_DELT_SNR_GET;
	ret = ifx_cpe_api_device_get_operation(cmd, (void *) &(Wan_Dsl_Diag->snrds), flags);
	if (ret < 0)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG ("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__, __LINE__);
		#endif
	}

	//SNR - UpStream Signal-to-Noise
	Wan_Dsl_Diag->snrus.nDirection = DSL_UPSTREAM;
	Wan_Dsl_Diag->snrus.nDeltDataType = DSL_DELT_DATA_DIAGNOSTICS;
	cmd = DSL_FIO_G997_DELT_SNR_GET;
	ret = ifx_cpe_api_device_get_operation(cmd, (void *) &(Wan_Dsl_Diag->snrus), flags);
	if (ret < 0)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG ("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__, __LINE__);
		#endif
	}

	//SNRpsds - DownStream Signal-to-Noise Ratio per SubCarrier
	Wan_Dsl_Diag->snr.nDirection = DSL_DOWNSTREAM;
	cmd = DSL_FIO_G997_DELT_SNR_GET;
	ret = ifx_cpe_api_device_get_operation(cmd, (void *) &(Wan_Dsl_Diag->snr), flags);
	if (ret < 0)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG ("\n\n In %s: ioctl  failed at line:%d!\n", __FUNCTION__, __LINE__);
		#endif
	}   
	else
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG ("\n\n In %s: ioctl  passed at line:%d!\n", __FUNCTION__, __LINE__);
		#endif
	}

IFX_Handler:
	return IFX_SUCCESS;
}


int32 ifx_cpe_api_device_get_operation(int32 cmd, void *data, uint32 flags)
{
 	int32   fd  = 0;
	int32	ret = IFX_SUCCESS;
	
	if ((fd = open (DSL_DEVICE, O_RDWR)) < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG ("\n [%s] : Open DSL device (%s) failed!!\n", __FUNCTION__, DSL_DEVICE);
#endif
	    return fd;

	}
	
	if ((ret = ioctl (fd, cmd, data)) < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG ("\n\n [%s] : Ioctl operation failed!\n", __FUNCTION__);
#endif
	}
    close (fd);
	return ret;

}

int32  ifx_cpe_api_get_line_activate(IFX_ID *iid, DSL_G997_LineActivate_t *lineActivate, uint32 flags)
{
	int32 cmd, ret 	= IFX_SUCCESS;

	cmd = DSL_FIO_G997_LINE_ACTIVATE_CONFIG_GET;
	if ((ifx_cpe_api_device_get_operation(cmd, (void *) &(lineActivate) , flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n [%s] : failed!\n", __FUNCTION__);
#endif
		ret = IFX_FAILURE;
	}
	return ret;
}


int32 ifx_cpe_api_device_set_operation(int32 cmd, void *data, uint32 flags)
{
 	int32   fd  = 0;
	int32	ret = IFX_SUCCESS;
	
	if ((fd = open (DSL_DEVICE, O_RDWR)) < 0) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG ("\n [%s] : Open DSL device (%s) failed!!\n", __FUNCTION__, DSL_DEVICE);
#endif
		ret = IFX_ERR_FILE_OPEN;
	    return ret;

	}
	
	if (ioctl (fd, cmd, data) < 0)	{
#ifdef IFX_LOG_DEBUG
		IFX_DBG ("\n [%s] : Ioctl failed!\n", __FUNCTION__);
#endif
		ret = IFX_ERR_IOCTL;
	}
    close (fd);
	return ret;

}

#if 0
int32 ifx_cpe_api_set_line_activate(IFX_ID *iid, DSL_G997_LineActivate_t *lineActivate, uint32 flags)
{
    time_t  currTs 		 = 0;
	int32 	cmd, ret	 = IFX_SUCCESS;
	char8 	acl_buf[10]  = "owner";	
	char8	buf[MAX_FILELINE_LEN];

	/* proceed only if ACL permits */
	if ((IFX_CHECK_ACL (iid, 1, &acl_buf[0], flags, IFX_Handler)) != IFX_SUCCESS) {
		IFX_DBG("\n [%s] : ACL failed!\n", __FUNCTION__);
		goto IFX_Handler;
	}

	cmd = DSL_FIO_G997_LINE_ACTIVATE_CONFIG_SET;
	if ((ifx_cpe_api_device_set_operation( cmd, (void *) &(lineActivate), flags )) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n [%s] : Ioctl failed \n\n", __FUNCTION__);
#endif
		goto IFX_Handler;
	}
	
	(void) time (&currTs);

	sprintf(buf, "owner=\"%d\"\nstate=\"%s\"\ntimestamp=\"%ld\"\n",iid->config_owner, IFX_DSL_STATE_DIAG, (unsigned long int) currTs);
	if((ret = ifx_SetObjData(FILE_DYN_INFO, TAG_DSL_DIAG, IFX_F_DEFAULT, 1, buf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n [%s] : DSL info update failed !! \n", __FUNCTION__);
#endif
		goto IFX_Handler;
	}

IFX_Handler:
	if (ret != IFX_SUCCESS) {
		IFX_DBG("\n [%s] : returned failure!\n", __FUNCTION__);
		return IFX_FAILURE;
	}
	else
		return IFX_SUCCESS;
}
#endif

#endif // CONFIG_PACKAGE_IFX_DSL_CPE_API
/* 705031:Santosh: new dsl diagnostics api */
