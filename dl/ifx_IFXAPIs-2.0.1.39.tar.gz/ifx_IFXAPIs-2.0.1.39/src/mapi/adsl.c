
#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <arpa/inet.h>
#include "ifx_common.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"

#ifndef HOSTENV
char8 *adsl_vc_params[] = {"cpeId", "pcpeId","VccNAME","fEnable", "linkType", "aal", "fcs",
                        "encap", "qos", "maxpcr", "minpcr", "scr", "mbs", "cdv", "vcc",};
#else
char8 *adsl_vc_params[] = {"cpeId", "pcpeId","VccNAME","fEnable", "linkType", "aal", "fcs",
                        "encap", "qos", "maxpcr", "minpcr", "vcc",};
#endif

char8 * eth_ch_params[] = {"cpeId", "pcpeId", "fEnable", "ethChName", "mac", "macOverride","vlanId"};

char8 * ptm_ch_params[] = {"cpeId", "pcpeId", "fEnable", "ptmChName", "mac", "macOverride","vlanId", "preempt"};

char8 *wan_conn_dev_params[] = {"cpeId", "pcpeId", "vcc"};

#define IFX_VALIDATE_VCC_INFO(entry, flags) {\
				if(IFX_INT_ADD_F_SET(flags)) { \
					/* check for duplicate vc entry */ \
					if((ret = ifx_duplicate_vpivci(entry->iid.cpeId, entry->vc.pvc)) != IFX_SUCCESS) {\
						goto IFX_Handler; \
					} \
				} \
				if(IFX_MODIFY_F_SET(flags)) { \
					/* check for duplicate vc entry */ \
					if((ret = ifx_duplicate_vpivci(entry->iid.cpeId, entry->vc.pvc)) != IFX_SUCCESS) {\
						goto IFX_Handler; \
					} \
				} \
			}

#define IFX_VALIDATE_WAN_CONN_DEV(entry, flags) { \
				if(IFX_INT_ADD_F_SET(flags)) { \
					/* check for duplicate vc entry */ \
					if((ret = ifx_duplicate_vpivci(entry->iid.cpeId, entry->vc.pvc)) != IFX_SUCCESS) {\
						goto IFX_Handler; \
					} \
				} \
				if(IFX_MODIFY_F_SET(flags)) { \
					/* check for duplicate vc entry */ \
					if((ret = ifx_duplicate_vpivci(entry->iid.cpeId, entry->vc.pvc)) != IFX_SUCCESS) {\
						goto IFX_Handler; \
					} \
				} \
			}


/*//////////////////////////////////////////////////////////////////////////////
 * ifx_validate_link_type(....)
 *	cpeId		==>	Input cpeid of the VC Channel
 *	link_type	==>	Link Type to modify
 * 	wan_secName	==>	rc.conf section name of wan main
		Return Value : IFX_SUCCESS or IFX_FAILURE
		Description :
			This function takes the input vpi and vci, checks if any wan connection is configured on this vcc
			If so, then gets the link type for this vcc from rc.conf and compares with the input link type
			If they do not match it returns an IFX_FAILURE otherwise IFX_SUCCESS.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_validate_link_type(CPE_ID cpeId, int32 link_type, char8 *wan_secName)
{
	int32	ret = IFX_FAILURE, outFlag = IFX_F_DEFAULT;
	char8	sCommand[MAX_FILELINE_LEN]={'\0'};
	char8	sValue[MAX_FILELINE_LEN]={'\0'};
	char8   *retStr = NULL;

	sprintf(sCommand, "%d", cpeId.Id);
	ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, cpeId.secName, "cpeId", sCommand, &retStr);
	if(ret != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}

	/* Get the old link type */
	sprintf(sCommand, "%s_vcc", retStr);
        memset(sValue,'\0',sizeof(sValue));
	if((ret = ifx_GetObjData(FILE_RC_CONF, cpeId.secName, sCommand, IFX_F_GET_ANY, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	IFX_MEM_FREE(retStr)

	/* Get the wan connection with this vc */
	ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, wan_secName, "vcc", sValue, &retStr);
	if(ret != IFX_SUCCESS) {
		ret = IFX_SUCCESS;
		goto IFX_Handler;
	}

	sprintf(sCommand, "%s_fEnable", retStr);
	memset(sValue,'\0',sizeof(sValue));
	ifx_GetObjData(FILE_RC_CONF, wan_secName, sCommand, IFX_F_GET_ENA, (IFX_OUT uint32 *)&outFlag, sValue);
	if(outFlag == IFX_F_GET_ENA && atoi(sValue) == IFX_ENABLED)
	{
        	/* if wan connection is enabled.. */
	        sprintf(sCommand, "%s_linkType", retStr);
                memset(sValue,'\0',sizeof(sValue));
        	ifx_GetObjData(FILE_RC_CONF, wan_secName, sCommand, IFX_F_GET_ENA, (IFX_OUT uint32 *)&outFlag, sValue);
	        if(outFlag == IFX_F_GET_ENA)
		{
			if(atoi(sValue) != link_type)
			{
				/* if link types dont match */
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			else
				ret = IFX_SUCCESS;
		}
	}
	else
		ret = IFX_SUCCESS;

IFX_Handler:
	IFX_MEM_FREE(retStr)
	if(ret != IFX_SUCCESS)
	{
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
 * ifx_duplicate_vpivci(....)
 *	cpeId		==>	Input cpeid of the VC Channel
 * 	vc			==>	Input VC (vpi/vci) of the VC Channel
		Return Value : IFX_SUCCESS or IFX_FAILURE
		Description :
			This function takes the input vpi vci and checks if there is any other
			vc channel with same vpi vci then it returns IFX_SUCCESS otherwise IFX_FAILURE
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_duplicate_vpivci(CPE_ID cpeId, PVC vc)
{
	int32	ret = IFX_SUCCESS, num_entries = 0, i = 0;
	char8	sValue[MAX_FILELINE_LEN], f_vc[10];
	ATM_VCC_INFO	*vcc_array = NULL;
        memset(sValue,'\0',sizeof(sValue));

	sprintf(sValue, "%d/%d", vc.vpi, vc.vci);
#if 0
	ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, cpeId.secName, "vcc", sValue, &vc_retStr);
	if(ret != IFX_SUCCESS)
		ret = IFX_SUCCESS;
	else {
		sprintf(command, "%s_vcc", vc_retStr);
		ifx_GetObjData(FILE_RC_CONF, cpeId.secName, command, IFX_F_GET_ENA, &outFlag, sValue);
		if(outFlag == IFX_F_GET_ENA) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] for vc[%d/%d] in [%s]", __FUNCTION__, __LINE__, vc.vpi, vc.vpi, cpeId.secName);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}
#endif

	if(ifx_get_all_vcc_info(&num_entries, &vcc_array, IFX_F_GET_ANY) != IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	for(i=0;i<num_entries;i++)
	{
		snprintf(f_vc,sizeof(f_vc), "%d/%d", (vcc_array+i)->vc.pvc.vpi, (vcc_array+i)->vc.pvc.vci);
		/* Check :- If input vc matches with vc channel entry(if the vc channel is enabled)
			and if input cpeid doesnt match with vc channel entry cpeid, then return error.
			caller is trying to modify vc which will clash with already existing vc channel */
		if((vcc_array+i)->f_enable && (!strcmp(f_vc, sValue)))
		{
			/*Modifying VC Channel section. So compare the cpeId*/
			if((strcmp(cpeId.secName, TAG_ADSL_VCCHANNEL) == 0) && ((vcc_array+i)->iid.cpeId.Id != cpeId.Id))
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] duplicate vc found !!%s %s %d",
					__FUNCTION__, __LINE__, f_vc, sValue,(vcc_array+i)->iid.cpeId.Id);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			else if((strcmp(cpeId.secName, TAG_WAN_CONN_DEVICE) == 0) && ((vcc_array+i)->iid.pcpeId.Id != cpeId.Id))
			{
				/*Modifying WAN Conn Dev section. So compare the parent cpe id of VC Ch entry with 
					cpeId of WCDev section*/
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] duplicate vc found !!%s %s %d",
					__FUNCTION__, __LINE__, f_vc, sValue,(vcc_array+i)->iid.pcpeId.Id);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
	}
	ret = IFX_SUCCESS;

IFX_Handler:
//	IFX_MEM_FREE(vc_retStr)
	IFX_MEM_FREE(vcc_array)
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
 * ifx_validate_vpivci(....)
 *	cpeId		==>	Input cpeid of the VC Channel
 * 	vc			==>	Input VC (vpi/vci) of the VC Channel
 *	depSecName	==>	Name of section which is depending on this VC
		Return Value : IFX_SUCCESS or IFX_FAILURE
		Description :
			This function takes the input cpeid and gets the corresponding vcc from rc.conf and
			then checks if there is any wan connection with the same vcc and its not 0/0.
			If they match (for a Modify operation) it returns an IFX_FAILURE otherwise IFX_SUCCESS
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_validate_vpivci(CPE_ID cpeId, PVC vc, char8 depSecName[])
{
	int32	ret = IFX_SUCCESS, outFlag = IFX_F_DEFAULT, num_entries = 0, i = 0;
	char8	sValue[MAX_FILELINE_LEN];
	char8	in_vpivci[10], fi_vpivci[10], wan_vpivci[10];
    char8	*vc_retStr = NULL, *wan_retStr = NULL;
	WAN_CONN_CFG	*wan_array = NULL;
        memset(sValue,'\0',sizeof(sValue));

	snprintf(in_vpivci,sizeof(in_vpivci),"%d/%d", vc.vpi, vc.vci);

	/* Get the VC Channel prefix */
	sprintf(sValue, "%d", cpeId.Id);
	ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, cpeId.secName, "cpeId", sValue, &vc_retStr);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* Get the VC of this VC Channel */
	sprintf(sValue, "%s_vcc", vc_retStr);
        memset(fi_vpivci,'\0',sizeof(fi_vpivci));
	if((ret = ifx_GetObjData(FILE_RC_CONF, cpeId.secName, sValue, IFX_F_GET_ANY, (IFX_OUT uint32 *)&outFlag, fi_vpivci)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* if no change in vpi vci return success */
	if(!strcmp(fi_vpivci, in_vpivci)) {
		ret = IFX_SUCCESS;
		goto IFX_Handler;
	}

#if 0
	/* Pramod : check if there is any object in section (depSecName) with this vpivci.. if so deny change */
	ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, depSecName, "vcc", fi_vpivci, &wan_retStr);
	if(ret != IFX_SUCCESS) {
		ret = IFX_SUCCESS;
		goto IFX_Handler;
	}

	sprintf(command, "%s_fEnable", wan_retStr);
	if(ifx_GetObjData(FILE_RC_CONF, depSecName, command, IFX_F_GET_ENA, &outFlag, sValue) == IFX_SUCCESS) {
		if(outFlag == IFX_F_GET_ENA && atoi(sValue) == 1) {
			/* wan connection is enabled !! */
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}
#endif

	if(ifx_get_all_wan_atm_vcc_config(&num_entries, &wan_array, IFX_F_GET_ANY) != IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	for(i=0;i<num_entries;i++) {
		snprintf(wan_vpivci,sizeof(wan_vpivci), "%d/%d", (wan_array+i)->vc.pvc.vpi, (wan_array+i)->vc.pvc.vci);
		if((wan_array+i)->wancfg.ip.wan_cfg.f_enable && (!strcmp(fi_vpivci, wan_vpivci))) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] active wan connection found on [%s] cannot modify vcc !!", __FUNCTION__, __LINE__, wan_vpivci);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}
	ret = IFX_SUCCESS;

IFX_Handler:
	IFX_MEM_FREE(vc_retStr)
	IFX_MEM_FREE(wan_array)
	IFX_MEM_FREE(wan_retStr)
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_wan_conn_dev(...)
*		operation	==> 	specifies the operation to be done for the ipaddree - interface 
*							combination passed such as ADD, DELETE
*		dev_entry	==>		pointer to WAN_CONN_DEV which will store the vcc information
*    	flags		==>   flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
					The api creates an object in the the wan connection device section for the specified vcc.
					And returns the cpeId allocated to the wan connection device created.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_wan_conn_dev(int32 operation, WAN_CONN_DEV *dev_entry, uint32 flags)
{
	int32	ret = IFX_SUCCESS, passed_index = -1, count = 0, changed_fcount = 0;
        char8   conf_buf[MAX_FILELINE_LEN], *retStr = NULL, tempBuf[MAX_FILELINE_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[4], *array_changed_fvp = NULL;
        uint32 inflag = flags, outflag = 0;
        uint32 retval = 0;
        char8 sValue[MAX_FILELINE_LEN];

	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
        NULL_TERMINATE(tempBuf, 0x00, sizeof(tempBuf));
        memset(sValue,'\0', sizeof(sValue));
	memset(array_fvp, 0x00, sizeof(array_fvp));
	if( dev_entry->iid.pcpeId.Id == 0){
        sprintf(tempBuf, "%s_phymode", PREFIX_WAN_PHY_CFG);
        if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, tempBuf, inflag, &outflag, sValue) != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d]Couldn't get wan mode. using default value", __FUNCTION__, __LINE__);
            #endif
            /*Default value*/
            dev_entry->iid.pcpeId.Id = 1;
        }
        else
        {
                retval=atoi(sValue);
                if(retval == WAN_PHY_MODE_ADSL2)
                {
                    dev_entry->iid.pcpeId.Id = 1;
                }
                else if(retval == WAN_PHY_MODE_ETH_MII0)
                {
                    dev_entry->iid.pcpeId.Id = 2;
                }
                else if(retval == WAN_PHY_MODE_ETH_MII1)
                {
                    dev_entry->iid.pcpeId.Id = 3;
                }
                else if(retval == WAN_PHY_MODE_VDSL2)
                {
                    dev_entry->iid.pcpeId.Id = 1;
                }
                else
                {
                    /*Default value*/
                    dev_entry->iid.pcpeId.Id = 1;
                }
        }
	}
	sprintf(dev_entry->iid.cpeId.secName, "%s", TAG_WAN_CONN_DEVICE);
	sprintf(dev_entry->iid.pcpeId.secName, "%s", TAG_WAN_DEVICE);

	if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		if( dev_entry->iid.pcpeId.Id == 1 )
		IFX_VALIDATE_WAN_CONN_DEV(dev_entry, flags)
	}

	if(operation == IFX_OP_ADD) {
		flags |= IFX_F_INT_ADD;
		if (ifx_get_IID(&dev_entry->iid, "WanIPNoOfEntries") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}
	else if(operation == IFX_OP_DEL) {
		flags |= IFX_F_DELETE;
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, dev_entry->iid.cpeId, passed_index)
	}
	else if(operation == IFX_OP_MOD) {
		flags |= IFX_F_MODIFY;
	}


	/*********************** Name Value Formation as per RC.CONF **********************/
	if(IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, 0, 3, wan_conn_dev_params);

		sprintf(array_fvp[0].value, "%d", dev_entry->iid.cpeId.Id);
		sprintf(array_fvp[1].value, "%d", dev_entry->iid.pcpeId.Id);
		sprintf(array_fvp[2].value, "%d/%d", dev_entry->vc.pvc.vpi, dev_entry->vc.pvc.vci);
		passed_index = -1;
	}
	count = 3;

	if(ifx_get_conf_index_and_nv_pairs(&dev_entry->iid, passed_index, PREFIX_WAN_CONN_DEV, 
				count, array_fvp, flags) != IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* Check ACL in case of Delete - as notification must be sent to TR69 Stack
	 * TR69 does a delete from CHECK_ACL_RET function 
	 * Here the changed array consists of the whole parameter set for DELETE */
	if (IFX_DELETE_F_SET(flags)) {
		CHECK_ACL_RET(dev_entry->iid, count, array_fvp,
					changed_fcount, array_changed_fvp, flags, IFX_Handler)
	}

	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_CONN_DEVICE, flags, 1, conf_buf);

	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* this will Compact the section and also update the count for both ADD and DELETE */
	if(IFX_MODIFY_F_NOT_SET(flags)) {
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_WAN_CONN_DEVICE, flags);
	}


	/*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_INT_ADD_F_SET(flags)) {
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		UPDATE_ID_MAP_N_ATTRIBUTES(&dev_entry->iid, count, array_fvp, flags, IFX_Handler)

		CHECK_N_SEND_NOTIFICATION(dev_entry->iid, count, array_fvp, flags, IFX_Handler)
		/* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WAN_CONN_DEVICE);
	}
	else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
		CHECK_N_SEND_NOTIFICATION(dev_entry->iid, count, array_fvp, flags, IFX_Handler)

		UPDATE_ID_MAP_N_ATTRIBUTES(&dev_entry->iid, count, array_fvp, flags, IFX_Handler)
	}	


	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}


IFX_Handler:
	IFX_MEM_FREE(retStr)
	IFX_MEM_FREE(array_changed_fvp);
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_wan_conn_dev_Without_TR69(...)
*		operation	==> 	specifies the operation to be done for the ipaddree - interface 
*							combination passed such as ADD, DELETE
*		dev_entry	==>		pointer to WAN_CONN_DEV which will store the vcc information
*    	flags		==>   flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
					The api creates an object in the the wan connection device section for the specified vcc.
					And returns the cpeId allocated to the wan connection device created.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_wan_conn_dev_Without_TR69(int32 operation, WAN_CONN_DEV *dev_entry, uint32 flags)
{
	int32	ret = IFX_SUCCESS, passed_index = -1, count = 0;
	#if 0
	int32   changed_fcount = 0;
	#endif
        char8   conf_buf[MAX_FILELINE_LEN], *retStr = NULL, tempBuf[MAX_FILELINE_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[4], *array_changed_fvp = NULL;
        uint32 inflag = flags, outflag = 0;
        uint32 retval = 0;
        char8 sValue[MAX_FILELINE_LEN];

	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
        NULL_TERMINATE(tempBuf, 0x00, sizeof(tempBuf));
        memset(sValue,'\0', sizeof(sValue));
	memset(array_fvp, 0x00, sizeof(array_fvp));
	if( dev_entry->iid.pcpeId.Id == 0){
        sprintf(tempBuf, "%s_phymode", PREFIX_WAN_PHY_CFG);
        if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, tempBuf, inflag, &outflag, sValue) != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d]Couldn't get wan mode. using default value", __FUNCTION__, __LINE__);
            #endif
            /*Default value*/
            dev_entry->iid.pcpeId.Id = 1;
        }
        else
        {
                retval=atoi(sValue);
                if(retval == WAN_PHY_MODE_ADSL2)
                {
                    dev_entry->iid.pcpeId.Id = 1;
                }
                else if(retval == WAN_PHY_MODE_ETH_MII0)
                {
                    dev_entry->iid.pcpeId.Id = 2;
                }
                else if(retval == WAN_PHY_MODE_ETH_MII1)
                {
                    dev_entry->iid.pcpeId.Id = 3;
                }
                else if(retval == WAN_PHY_MODE_VDSL2)
                {
                    dev_entry->iid.pcpeId.Id = 4;
                }
                else
                {
                    /*Default value*/
                    dev_entry->iid.pcpeId.Id = 1;
                }
        }
	}
	sprintf(dev_entry->iid.cpeId.secName, "%s", TAG_WAN_CONN_DEVICE);
	sprintf(dev_entry->iid.pcpeId.secName, "%s", TAG_WAN_DEVICE);

	if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		if( dev_entry->iid.pcpeId.Id == 1 )
		IFX_VALIDATE_WAN_CONN_DEV(dev_entry, flags)
	}

	if(operation == IFX_OP_ADD) {
		flags |= IFX_F_INT_ADD;
		if (ifx_get_IID_Without_TR69(&dev_entry->iid, "WanIPNoOfEntries") != IFX_SUCCESS) {
		//if (ifx_get_IID(&dev_entry->iid, "WanIPNoOfEntries") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}
	else if(operation == IFX_OP_DEL) {
		flags |= IFX_F_DELETE;
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, dev_entry->iid.cpeId, passed_index)
	}
	else if(operation == IFX_OP_MOD) {
		flags |= IFX_F_MODIFY;
	}


	/*********************** Name Value Formation as per RC.CONF **********************/
	if(IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, 0, 3, wan_conn_dev_params);

		sprintf(array_fvp[0].value, "%d", dev_entry->iid.cpeId.Id);
		sprintf(array_fvp[1].value, "%d", dev_entry->iid.pcpeId.Id);
		sprintf(array_fvp[2].value, "%d/%d", dev_entry->vc.pvc.vpi, dev_entry->vc.pvc.vci);
		passed_index = -1;
	}
	count = 3;

	if(ifx_get_conf_index_and_nv_pairs(&dev_entry->iid, passed_index, PREFIX_WAN_CONN_DEV, 
				count, array_fvp, flags) != IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* Check ACL in case of Delete - as notification must be sent to TR69 Stack
	 * TR69 does a delete from CHECK_ACL_RET function 
	 * Here the changed array consists of the whole parameter set for DELETE */
/*This has been commented out for the time being since PTM WAN is not supported from TR69*/
	#if 0
	if (IFX_DELETE_F_SET(flags)) {
		CHECK_ACL_RET(dev_entry->iid, count, array_fvp,
					changed_fcount, array_changed_fvp, flags, IFX_Handler)
	}
	#endif
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_CONN_DEVICE, flags, 1, conf_buf);

	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* this will Compact the section and also update the count for both ADD and DELETE */
	if(IFX_MODIFY_F_NOT_SET(flags)) {
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_WAN_CONN_DEVICE, flags);
	}


	/*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if (IFX_INT_ADD_F_SET(flags)) {
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */	
/*This has been commented out for the time being since PTM WAN is not supported from TR69*/
	#if 0
		UPDATE_ID_MAP_N_ATTRIBUTES(&dev_entry->iid, count, array_fvp, flags, IFX_Handler)

		CHECK_N_SEND_NOTIFICATION(dev_entry->iid, count, array_fvp, flags, IFX_Handler)
	#endif
		/* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WAN_CONN_DEVICE);
	}
	else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
/*This has been commented out for the time being since PTM WAN is not supported from TR69*/
	#if 0
		CHECK_N_SEND_NOTIFICATION(dev_entry->iid, count, array_fvp, flags, IFX_Handler)

		UPDATE_ID_MAP_N_ATTRIBUTES(&dev_entry->iid, count, array_fvp, flags, IFX_Handler)
	#endif
	}	


	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}


IFX_Handler:
	IFX_MEM_FREE(retStr)
	IFX_MEM_FREE(array_changed_fvp);
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_vcc_cfg(...)
*		operation	==> 	specifies the operation to be done such as ADD, DELETE or MODIFY
*		dev_entry	==>		pointer to ATM_VCC_INFO which will store the DSL Link Config information to be configured
*    	flags		==>		flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
					The api takes the structure entry which will have the values filled in to be configured.
					Based on the operation, it will either add, delete or modify a vcc connection.
					For Modify and Delete Validations are put to check for an existing Wan Connection on this vcc
					It will return IFX_SUCCESS or IFX_FAILURE
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_vcc_cfg(int32 operation, ATM_VCC_INFO *entry, uint32 flags)
{
    char8	conf_buf[MAX_DATA_LEN];
    int32	count = 0, changed_count = 0, passed_index = -1, ret = IFX_SUCCESS;
    WAN_CONN_DEV dev;
    IFX_NAME_VALUE_PAIR array_fvp[18], *array_changed_fvp = NULL;

    memset(&dev, 0x00, sizeof(dev));

    NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));
    memset(array_fvp, 0, sizeof(array_fvp));

	/*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY) 
	 * append the flag with internal flags */
	if (operation == IFX_OP_DEL) 
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if( (IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	}
	else
		flags |= IFX_F_MODIFY;

	sprintf(entry->iid.cpeId.secName, "%s", TAG_ADSL_VCCHANNEL);
	sprintf(entry->iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);

	/**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(entry)
		/* Do simple validation of flags sucha as less than 0 */
		IFX_VALIDATE_FLAGS(flags)
		/* in case of modify, only qos params can be modified
		 * also, vcc can't be modified
		 * link type can't be modified until a wan connection is present on this vcc */
		IFX_VALIDATE_VCC_INFO(entry, flags)
	}


	/**************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
         /* Allocate the IID for this vcc */
		if(ifx_get_IID(&entry->iid, "vcc") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
    } 

	/**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY
	 * Operations 
	 */
	count = 0;
	if(IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, 0, 15, adsl_vc_params);
		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 2, (int32 *)&entry->iid.cpeId.Id, &entry->iid.pcpeId.Id);
                sprintf(array_fvp[2].value, "%s", entry->vcc_ch_name);
               ifx_fill_ArrayFvp_intValues(array_fvp,3,5, &entry->f_enable, &entry->type, &entry->aal, &entry->fcs_preserved, &entry->encap);
	sprintf(array_fvp[8].value, "%d", entry->txtp.traffic_class);

#ifndef HOSTENV
		
		ifx_fill_ArrayFvp_intValues(array_fvp, 9, 5, &entry->txtp.max_pcr, &entry->txtp.min_pcr, &entry->txtp.scr, &entry->txtp.mbs, &entry->txtp.cdv);
		sprintf(array_fvp[14].value, "%d/%d", entry->vc.pvc.vpi, entry->vc.pvc.vci);
               // sprintf(array_fvp[14].value, "%s", entry->vcc_ch_name);

#else
                ifx_fill_ArrayFvp_intValues(array_fvp, 9, 2, &entry->txtp.max_pcr, &entry->txtp.min_pcr);
		sprintf(array_fvp[11].value, "%d/%d", entry->vc.pvc.vpi, entry->vc.pvc.vci);
               // sprintf(array_fvp[11].value, "%s", entry->vcc_ch_name);
#endif

		passed_index = -1;
	}

#ifndef HOSTENV
	count = 15;
#else
	count = 12;
#endif
	
     /* Get Config Index in case of modify/delete operations from CPEID */
	if((IFX_MODIFY_F_SET(flags)) ||
		(IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, entry->iid.cpeId, passed_index)
	}

	/* Determine the configuration index - for Add, Delete, Modify operations 
     * Name is partial since index is not known 
     * Fill array_fvp[] */
	if(ifx_get_conf_index_and_nv_pairs(&entry->iid, passed_index, PREFIX_ADSL_VCCHANNEL, 
				count, array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
	}


	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	if(IFX_ADD_F_NOT_SET(flags)) {
		CHECK_ACL_RET(entry->iid, count, array_fvp,
						changed_count, array_changed_fvp, flags, IFX_Handler)
	}


	/************** System Config File Update Block ****************/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, flags, 1, conf_buf);

	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* this will Compact the section and also update the count for both ADD and DELETE */
	if(IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, flags);


	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

	/*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if(IFX_MODIFY_F_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION(entry->iid, changed_count, array_changed_fvp, flags, IFX_Handler)
	}
	else if (IFX_INT_ADD_F_SET(flags)) {
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
		UPDATE_ID_MAP_N_ATTRIBUTES(&entry->iid, count, array_fvp, flags, IFX_Handler)

		CHECK_N_SEND_NOTIFICATION(entry->iid, count, array_fvp, flags, IFX_Handler)

		/* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_ADSL_VCCHANNEL);

	}
	else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notification update the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
		CHECK_N_SEND_NOTIFICATION(entry->iid, count, array_fvp, flags, IFX_Handler)

		UPDATE_ID_MAP_N_ATTRIBUTES(&entry->iid, count, array_fvp, flags, IFX_Handler)
	}


	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if(ret != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Update Persistent Storage fail", __FUNCTION__, __LINE__);
            #endif
            goto IFX_Handler;
	}


IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp);
	if(ret != IFX_SUCCESS)
        {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_eth_ch_cfg(...)
*		operation	==> 	specifies the operation to be done such as ADD, DELETE or MODIFY
*		dev_entry	==>		pointer to ETH_CH_CFG which will store the Ethernet Link Config information to be configured
*    	flags		==>		flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
*		Description:
*					The api takes the structure entry which will have the values filled in to be configured.
*					Based on the operation, it will either add, delete or modify an ethernet channel connection.
*					For Modify and Delete Validations are put to check for an existing Wan Connection on this vcc
*					It will return IFX_SUCCESS or IFX_FAILURE
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_eth_ch_cfg(int32 operation, ETH_CH_CFG *entry, uint32 flags)
{
#ifdef CONFIG_FEATURE_ETH_WAN_SUPPORT
    char8	conf_buf[MAX_DATA_LEN];
    int32	count = 0, changed_count = 0, passed_index = -1, ret = IFX_SUCCESS;
    IFX_NAME_VALUE_PAIR array_fvp[16], *array_changed_fvp = NULL;
    char8    stVlanId[8];
    char8    stNameBuff[32];
    char8    *ret_vlanIdStr = NULL;
    uint32 outflag = 0;
    char8 sValue[MAX_FILELINE_LEN];
    uint32 pcpeId = 0;

    NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));
    NULL_TERMINATE(stVlanId, 0, sizeof(stVlanId));
    NULL_TERMINATE(stNameBuff, 0, sizeof(stNameBuff));
    memset(array_fvp, 0, sizeof(array_fvp));

    /*************** Prolog Block *********************/
    /* Based on operation (ADD or DELETE or MODIFY) 
     * append the flag with internal flags */
    if (operation == IFX_OP_DEL) 
        flags |= IFX_F_DELETE;
    else if (operation == IFX_OP_ADD)
    {
	if((IFX_MODIFY_F_NOT_SET(flags)))
            flags |= IFX_F_INT_ADD;
    }
    else
        flags |= IFX_F_MODIFY;

    /**************** Validation Block *****************/
    if(IFX_DONT_VALIDATE_F_NOT_SET(flags))
    {
        /* Do simple validation of pointer such as NULL */
	IFX_VALIDATE_PTR(entry)
	/* Do simple validation of flags such as less than 0 */
	IFX_VALIDATE_FLAGS(flags)

        if(entry->iid.pcpeId.Id == 0)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Invalid pCpeId", __FUNCTION__, __LINE__);
            #endif
            ret = IFX_FAILURE;
	    goto IFX_Handler;
        }

        /* Check if Vlan ID exists in eth_channel section. VlanID should be unique for new addition*/
        if(IFX_DELETE_F_NOT_SET(flags))
	{	
	    snprintf(stVlanId,sizeof(stVlanId), "%d", entry->vlanId);
            if(ifx_ret_substr_from_distfield_with_state(FILE_RC_CONF, TAG_ETH_CHANNEL,
                                   "vlanId",stVlanId, &ret_vlanIdStr,IFX_F_GET_ENA) == IFX_SUCCESS)
	    {
                /* VLAN Id already exists */
                if(IFX_MODIFY_F_SET(flags))
                {
                    /* vlan id match should be for the same object that we are trying to modify in rc.conf */
                    sprintf(stNameBuff,"%s_pcpeId",ret_vlanIdStr);
                    memset(sValue,'\0',sizeof(sValue));
                    if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_ETH_CHANNEL, stNameBuff,
                                                 flags, &outflag, sValue)) == IFX_SUCCESS)
                    {
                        pcpeId = atoi(sValue);
                        if(pcpeId != entry->iid.pcpeId.Id)
                        {
	                    #ifdef IFX_LOG_DEBUG
                            IFX_DBG("[%s:%d] Modify Error! VLAN Id and pCpeId mismatch", __FUNCTION__, __LINE__);
		            #endif
		            IFX_MEM_FREE(ret_vlanIdStr)
                            ret = IFX_FAILURE;
                            goto IFX_Handler;
                        }
                    }
                }
                else
                {
                    /* Adding a new entry and VLAN ID exists already. Error */
	            #ifdef IFX_LOG_DEBUG
                    IFX_DBG("[%s:%d] VLAN ID already exists ", __FUNCTION__, __LINE__);
		    #endif
		    IFX_MEM_FREE(ret_vlanIdStr)
                    ret = IFX_DUPLICATE_ENTRY; /* need this to display appropriate error msg in GUI */
                    goto IFX_Handler;
                }
            }
	}
    }
    
    sprintf(entry->iid.cpeId.secName, "%s", TAG_ETH_CHANNEL);
    sprintf(entry->iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);

    /**************** ID Allocation Block - Only for ADD Operation **************/
    if (IFX_ADD_F_SET(flags))
    {
        /* Allocate the IID for this vcc */
        if(ifx_get_IID(&entry->iid, "vlanId") != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Could not allocate IID", __FUNCTION__, __LINE__);
            #endif
            ret = IFX_FAILURE;
	    goto IFX_Handler;
        }
    } 
    /**************** Name Value Formation as per RC.CONF ********************/
    /* Form the FVP from the given structure for ADD/MODIFY Operations */
    /*char8 * eth_ch_params[] = {"cpeId", "pcpeId", "fEnable", "ethChName", "mac", "macOverride","vlanId"};*/
    count = 0;
    if(IFX_DELETE_F_NOT_SET(flags))
    {
        ifx_fill_ArrayFvp_FName(array_fvp, 0, 7, eth_ch_params);

        ifx_fill_ArrayFvp_intValues(array_fvp, 0, 3, (int32 *)&entry->iid.cpeId.Id, &entry->iid.pcpeId.Id, &entry->f_enable);
	sprintf(array_fvp[3].value, "%s", entry->eth_ch_name);
	sprintf(array_fvp[4].value, "%s", entry->mac_addr);
	ifx_fill_ArrayFvp_boolValues(array_fvp, 5, 1, (uchar8 *)&entry->macOverride);
        ifx_fill_ArrayFvp_intValues(array_fvp, 6, 1, (int32 *)&entry->vlanId);

	passed_index = -1;
    }
    count = 7;
    /* Get Config Index in case of modify/delete operations from CPEID */
    if((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags)))
    {
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, entry->iid.cpeId, passed_index)
    }

    /* Determine the configuration index - for Add, Delete, Modify operations 
     * Name is partial since index is not known 
     * Fill array_fvp[] */
    if(ifx_get_conf_index_and_nv_pairs(&entry->iid, passed_index, PREFIX_ETH_CHANNEL, 
				count, array_fvp, flags) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] Could not determine config index", __FUNCTION__, __LINE__);
	#endif
	ret = IFX_FAILURE;
	goto IFX_Handler;
    }

    /************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
    if(IFX_ADD_F_NOT_SET(flags))
    {
        CHECK_ACL_RET(entry->iid, count, array_fvp, changed_count, array_changed_fvp, flags, IFX_Handler)
    }


    /************** System Config File Update Block ****************/
    /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
    form_cfgdb_buf(conf_buf, count, array_fvp);

    /* RC.CONF Configuration block */
    ret = ifx_SetObjData(FILE_RC_CONF, TAG_ETH_CHANNEL, flags, 1, conf_buf);

    if(ret != IFX_SUCCESS)
    {
	#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] ifx_SetObjData() FAIL! conf_buf[%s]", __FUNCTION__, __LINE__, conf_buf);
	#endif
	goto IFX_Handler;
    }

    /* this will Compact the section and also update the count for both ADD and DELETE */
    if(IFX_MODIFY_F_NOT_SET(flags))
	ifx_CompactCfgSection(FILE_RC_CONF, TAG_ETH_CHANNEL, flags);


    /*********** Notification Block *************/
    /* Notify the Internal TR69 Stack in case of MODIFY */

    /*********** Epilog Block **************/
    /* Update the IID mappings in the mappings section for ADD/DELETE */
    if(IFX_MODIFY_F_SET(flags))
    {
        CHECK_N_SEND_NOTIFICATION(entry->iid, changed_count, array_changed_fvp, flags, IFX_Handler)
    }
    else if (IFX_INT_ADD_F_SET(flags))
    {
	/* In case of ADD operation, first update the ID Mappings
	 * and then send the Notification for the attributes
	 */	
	/*********** Epilog Block **************/
	UPDATE_ID_MAP_N_ATTRIBUTES(&entry->iid, count, array_fvp, flags, IFX_Handler)

	CHECK_N_SEND_NOTIFICATION(entry->iid, count, array_fvp, flags, IFX_Handler)

	/* Manipulate nextCpeId only for ADD operations */
	ifx_increment_next_cpeId(FILE_RC_CONF, TAG_ETH_CHANNEL);
    }
    else if (IFX_DELETE_F_SET(flags))
    {
	/* In case of DELETE operation, first send the notificatio update the ID Mappings
	 * and then send the Notification for the attributes
	 */	
	/*********** Epilog Block **************/
	CHECK_N_SEND_NOTIFICATION(entry->iid, count, array_fvp, flags, IFX_Handler)

	UPDATE_ID_MAP_N_ATTRIBUTES(&entry->iid, count, array_fvp, flags, IFX_Handler)
    }


    /* Updating Persistent Storage */
    ret = ifx_config_write(FILE_RC_CONF, flags);
    if(ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Updating Persistent Storage FAIL", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }


IFX_Handler:
    IFX_MEM_FREE(array_changed_fvp);
    if(ret != IFX_SUCCESS)
    {
	IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
	return ret;
    }
    else
	return IFX_SUCCESS;
#else
    return IFX_SUCCESS;
#endif //CONFIG_FEATURE_ETH_WAN_SUPPORT
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_ptm_ch_cfg(...)
*               operation	==> 	specifies the operation to be done such as ADD, DELETE or MODIFY
*               entry           ==>     pointer to PTM_CH_CFG which will store the PTM Link Config 
*                                       information to be configured
*    	        flags           ==>     flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
*       Description:
*       The api takes the structure entry which will have the values filled in to be configured.
*       Based on the operation, it will either add, delete or modify a ptm channel connection.
*       For Modify and Delete Validations are put to check for an existing Wan Connection on this vcc
*       It will return IFX_SUCCESS or IFX_FAILURE
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_ptm_ch_cfg(int32 operation, PTM_CH_CFG *entry, uint32 flags)
{
#ifdef CONFIG_FEATURE_PTM_WAN_SUPPORT
    char8	conf_buf[MAX_DATA_LEN];
    int32	count = 0;
    //#if 0
    int32 changed_count = 0;
    //#endif
    int32 passed_index = -1, ret = IFX_SUCCESS;
    IFX_NAME_VALUE_PAIR array_fvp[15], *array_changed_fvp = NULL;
    char8    stVlanId[8];
    uint32 outflag = 0;
    char8 sValue[MAX_FILELINE_LEN];
    uint32 pcpeId = 0;
    char8    *ret_vlanIdStr = NULL;
    char8    stNameBuff[32];
    NULL_TERMINATE(stNameBuff, 0, sizeof(stNameBuff));
    NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));
    NULL_TERMINATE(stVlanId, 0, sizeof(stVlanId));
    memset(array_fvp, 0, sizeof(array_fvp));

    /*************** Prolog Block *********************/
    /* Based on operation (ADD or DELETE or MODIFY) 
     * append the flag with internal flags */
    if (operation == IFX_OP_DEL) 
        flags |= IFX_F_DELETE;
    else if (operation == IFX_OP_ADD)
    {
        if((IFX_MODIFY_F_NOT_SET(flags)))
            flags |= IFX_F_INT_ADD;
    }
    else
        flags |= IFX_F_MODIFY;

    /**************** Validation Block *****************/
    if(IFX_DONT_VALIDATE_F_NOT_SET(flags))
    {
        /* Do simple validation of pointer such as NULL */
        IFX_VALIDATE_PTR(entry)
        /* Do simple validation of flags such as less than 0 */
        IFX_VALIDATE_FLAGS(flags)

        if(entry->iid.pcpeId.Id == 0)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Invalid pCpeId", __FUNCTION__, __LINE__);
            #endif
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }

            IFX_DBG("[%s:%d] ", __FUNCTION__, __LINE__);
        /* Check if Vlan ID exists in ptm_channel section. VlanID should be unique for new addition*/
        if(IFX_DELETE_F_NOT_SET(flags))
        {
            snprintf(stVlanId,sizeof(stVlanId), "%d", entry->vlanId);
            if(ifx_ret_substr_from_distfield_with_state(FILE_RC_CONF, TAG_PTM_CHANNEL,
                                   "vlanId",stVlanId, &ret_vlanIdStr,IFX_F_GET_ENA) == IFX_SUCCESS)
            {
                /* VLAN Id already exists */
                if(IFX_MODIFY_F_SET(flags))
                {
                    /* vlan id match should be for the same object that we are trying to modify in rc.conf */
                    sprintf(stNameBuff,"%s_pcpeId",ret_vlanIdStr);
                    memset(sValue,'\0',sizeof(sValue));
                    if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_PTM_CHANNEL, stNameBuff,
                                                 flags, &outflag, sValue)) == IFX_SUCCESS)
                    {
                        pcpeId = atoi(sValue);
                        if(pcpeId != entry->iid.pcpeId.Id)
                        {
                            #ifdef IFX_LOG_DEBUG
                            IFX_DBG("[%s:%d] Modify Error! VLAN Id and pCpeId mismatch", __FUNCTION__, __LINE__);
                            #endif
                            IFX_MEM_FREE(ret_vlanIdStr)
                            ret = IFX_FAILURE;
                            goto IFX_Handler;
			}
                    }
                }
                else
                {
                    /* Adding a new entry and VLAN ID exists already. Error */
                    #ifdef IFX_LOG_DEBUG
                    IFX_DBG("[%s:%d] VLAN ID already exists ", __FUNCTION__, __LINE__);
                    #endif
                    IFX_MEM_FREE(ret_vlanIdStr)
                    ret = IFX_DUPLICATE_ENTRY; /* need this to display appropriate error msg in GUI */
                    goto IFX_Handler;
                }
            }
        }
    }


    sprintf(entry->iid.cpeId.secName, "%s", TAG_PTM_CHANNEL);
    sprintf(entry->iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);

    /**************** ID Allocation Block - Only for ADD Operation **************/
    if (IFX_ADD_F_SET(flags))
    {
        /* Allocate the IID for this vcc */
        //if(ifx_get_IID_Without_TR69(&entry->iid, "vcc") != IFX_SUCCESS)
        if(ifx_get_IID(&entry->iid, "vlanId") != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Error allocating IID", __FUNCTION__, __LINE__);
            #endif
            ret = IFX_FAILURE;
	    goto IFX_Handler;
        }
    } 
    /**************** Name Value Formation as per RC.CONF ********************/
    /* Form the FVP from the given structure for ADD/MODIFY
    * Operations 
    */
    //char8 * ptm_ch_params[] = {"cpeId", "pcpeId", "fEnable", "ptmChName", "mac", "macOverride","vlanId", "preempt"};
    count = 0;
    if(IFX_DELETE_F_NOT_SET(flags))
    {
        ifx_fill_ArrayFvp_FName(array_fvp, 0, 8, ptm_ch_params);

        ifx_fill_ArrayFvp_intValues(array_fvp, 0, 3, (int32 *)&entry->iid.cpeId.Id, &entry->iid.pcpeId.Id, &entry->f_enable);
	sprintf(array_fvp[3].value, "%s", entry->ptm_ch_name);
	sprintf(array_fvp[4].value, "%s", entry->mac_addr);
	ifx_fill_ArrayFvp_boolValues(array_fvp, 5, 1, (uchar8 *)&entry->macOverride);
        ifx_fill_ArrayFvp_intValues(array_fvp, 6, 1, (int32 *)&entry->vlanId);
	ifx_fill_ArrayFvp_boolValues(array_fvp, 7, 1, (uchar8 *)&entry->preempt);

	passed_index = -1;
    }
    count = 8;

    /* Get Config Index in case of modify/delete operations from CPEID */
    if((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags)))
    {
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, entry->iid.cpeId, passed_index)
    }

    /* Determine the configuration index - for Add, Delete, Modify operations 
     * Name is partial since index is not known 
     * Fill array_fvp[] */
    if(ifx_get_conf_index_and_nv_pairs(&entry->iid, passed_index, PREFIX_PTM_CHANNEL, 
				count, array_fvp, flags) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] Unable to determine config index", __FUNCTION__, __LINE__);
	#endif
	ret = IFX_FAILURE;
	goto IFX_Handler;
    }
    /*This has been commented out for the time being since PTM WAN is not supported from TR69*/
    //#if 0
    /************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
    if(IFX_ADD_F_NOT_SET(flags))
    {
        CHECK_ACL_RET(entry->iid, count, array_fvp, changed_count, array_changed_fvp, flags, IFX_Handler)
    }
    //#endif

    /************** System Config File Update Block ****************/
    /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
    form_cfgdb_buf(conf_buf, count, array_fvp);

    /* RC.CONF Configuration block */
    ret = ifx_SetObjData(FILE_RC_CONF, TAG_PTM_CHANNEL, flags, 1, conf_buf);
    if(ret != IFX_SUCCESS)
    {
	#ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] ifx_SetObjData FAIL,conf_buf[%s]", __FUNCTION__, __LINE__, conf_buf);
	#endif
	goto IFX_Handler;
    }

    /* This will Compact the section and also update the count for both ADD and DELETE */
    if(IFX_MODIFY_F_NOT_SET(flags))
	ifx_CompactCfgSection(FILE_RC_CONF, TAG_PTM_CHANNEL, flags);


    /*********** Notification Block *************/
    /* Notify the Internal TR69 Stack in case of MODIFY */

    /*********** Epilog Block **************/
    /* Update the IID mappings in the mappings section for ADD/DELETE */
    if(IFX_MODIFY_F_SET(flags))
    {
        /*This has been commented out for the time being since PTM WAN is not supported from TR69*/
        //#if 0
        CHECK_N_SEND_NOTIFICATION(entry->iid, changed_count, array_changed_fvp, flags, IFX_Handler)
        //#endif
    }
    else if (IFX_INT_ADD_F_SET(flags))
    {
	/* In case of ADD operation, first update the ID Mappings
	 * and then send the Notification for the attributes
	 */	
	/*********** Epilog Block **************/
        /*This has been commented out for the time being since PTM WAN is not supported from TR69*/
        //#if 0
	UPDATE_ID_MAP_N_ATTRIBUTES(&entry->iid, count, array_fvp, flags, IFX_Handler)

	CHECK_N_SEND_NOTIFICATION(entry->iid, count, array_fvp, flags, IFX_Handler)
        //#endif
	/* Manipulate nextCpeId only for ADD operations */
	ifx_increment_next_cpeId(FILE_RC_CONF, TAG_PTM_CHANNEL);
    }
    else if (IFX_DELETE_F_SET(flags))
    {
	/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
	 * and then send the Notification for the attributes
	 */	
	/*********** Epilog Block **************/
        /*This has been commented out for the time being since PTM WAN is not supported from TR69*/
        //#if 0
	CHECK_N_SEND_NOTIFICATION(entry->iid, count, array_fvp, flags, IFX_Handler)

	UPDATE_ID_MAP_N_ATTRIBUTES(&entry->iid, count, array_fvp, flags, IFX_Handler)
        //#endif
    }

    /* Updating Persistent Storage */
    ret = ifx_config_write(FILE_RC_CONF, flags);
    if(ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Updating Persistent Storage FAIL", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }


IFX_Handler:
    IFX_MEM_FREE(array_changed_fvp);
    if(ret != IFX_SUCCESS)
    {
	IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
	return ret;
    }
    else
	return IFX_SUCCESS;
#else
	return IFX_SUCCESS;
#endif //CONFIG_FEATURE_PTM_WAN_SUPPORT
}

/* GET APIs */
/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_eth_ch_cfg(...)
*	eth_entry	==>	pointer to ETH_CH_CFG in which Ethernet Link Config information will be returned
*    	iCpeId		==>	CPEID corresponding to the instance which has to be returned
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
*	Description  :
*			The api takes the iCpeId passed to it, gets the values of the corresponding
*                       ethernet channel connection, stores values in eth_entry and returns.
*       Return       :	It will return IFX_SUCCESS or IFX_FAILURE
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_eth_ch_cfg(ETH_CH_CFG *eth_entry, uint32 flags)
{
#ifdef CONFIG_FEATURE_ETH_WAN_SUPPORT
    uint32 wanIdx = -1;
    CPE_ID cpe_id;
    int ret = IFX_SUCCESS;
    char8 command[MAX_FILELINE_LEN];
    uint32 outflag = 0;
    char8 sValue[MAX_FILELINE_LEN];

    if(eth_entry == NULL)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Invalid input", __FUNCTION__, __LINE__);
        #endif
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    memset(&cpe_id, 0x00, sizeof(cpe_id));
    sprintf(cpe_id.secName,"%s",TAG_ETH_CHANNEL);
    cpe_id.Id = eth_entry->iid.cpeId.Id;

    IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id, wanIdx)

    if(wanIdx == -1)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Invalid wan index", __FUNCTION__, __LINE__);
        #endif
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }
	/* initialize the cache for this instance */
	sprintf(command, "%s_%d_",PREFIX_ETH_CHANNEL,wanIdx);
	if(ifx_GetObjDataOpt(FILE_RC_CONF,TAG_ETH_CHANNEL,command, IFX_F_INT_CACHE_INIT | flags, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
    
    /* get the cpeid for this eth channel index */
    MAKE_SECTION_ELEMENT_TAG(PREFIX_ETH_CHANNEL, wanIdx, "cpeId", command);
    memset(sValue,'\0',sizeof(sValue));
    if ((ret=(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ETH_CHANNEL, 
              command, flags, &outflag, sValue))) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Could not retrieve cpeId", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    eth_entry->iid.cpeId.Id = atoi(sValue);

    /* get the parent cpeid for this eth channel index */
    MAKE_SECTION_ELEMENT_TAG(PREFIX_ETH_CHANNEL, wanIdx, "pcpeId", command);
    memset(sValue,'\0',sizeof(sValue));
    if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ETH_CHANNEL, 
	        command, flags, &outflag, sValue)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Could not retrieve pCpeId", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    eth_entry->iid.pcpeId.Id = atoi(sValue);

    /* get the enable value for this eth channel index */
    MAKE_SECTION_ELEMENT_TAG(PREFIX_ETH_CHANNEL, wanIdx, "fEnable", command);
    memset(sValue,'\0',sizeof(sValue));
    if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ETH_CHANNEL, 
		         command, flags, &outflag, sValue)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Could not retrieve enable state", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    eth_entry->f_enable = atoi(sValue);

    /* get the name for this eth channel index */
    MAKE_SECTION_ELEMENT_TAG(PREFIX_ETH_CHANNEL, wanIdx, "ethChName", command);
    memset(sValue,'\0',sizeof(sValue));
    if ((ret = (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ETH_CHANNEL, 
			command, flags, &outflag, sValue))) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Could not retrieve channel name", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    snprintf(eth_entry->eth_ch_name,MAX_NAME_LEN,"%s", sValue);

    /* get the MAC addr for this eth channel index */
    MAKE_SECTION_ELEMENT_TAG(PREFIX_ETH_CHANNEL, wanIdx, "mac", command);
    memset(sValue,'\0',sizeof(sValue));
    if ((ret = (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ETH_CHANNEL, 
		command, flags, &outflag, sValue))) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Could not retrieve MAC Addr", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    snprintf(eth_entry->mac_addr,MAX_MAC_ADDR_LEN,"%s", sValue);

    /* get the override status for this eth channel index */
    MAKE_SECTION_ELEMENT_TAG(PREFIX_ETH_CHANNEL, wanIdx, "macOverride", command);
    memset(sValue,'\0',sizeof(sValue));
    if ((ret = (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ETH_CHANNEL, 
			command, flags, &outflag, sValue))) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Could not retrieve macOverride status", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    eth_entry->macOverride = atoi(sValue);

    /* get the vlanId for this vc channel index */
    MAKE_SECTION_ELEMENT_TAG(PREFIX_ETH_CHANNEL, wanIdx, "vlanId", command);
    memset(sValue,'\0',sizeof(sValue));
    if ((ret = (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ETH_CHANNEL, 
	command, flags, &outflag, sValue))) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Could not retrieve vlanId", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    eth_entry->vlanId = atoi(sValue);

IFX_Handler:
	/* destroy the cache for this instance */
	sprintf(command, "%s_%d_",PREFIX_ETH_CHANNEL,wanIdx);
	if(ifx_GetObjDataOpt(FILE_RC_CONF,TAG_ETH_CHANNEL,command,IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
    if(ret != IFX_SUCCESS)
    {
        IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
    }
    return ret;
#else
    return IFX_SUCCESS;
#endif //CONFIG_FEATURE_ETH_WAN_SUPPORT
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_all_eth_info(...)
*	num_entries	==>	ouput number of eth channels present in rc.conf
*	eth_array	==>	output pointer to the array of eth channels present in rc.conf
*	flags		==>	
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
*		Description:
*			This function reads the eth channels from rc.conf and stores them
*			in the output array eth_array.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_all_eth_info(int32 *num_entries, ETH_CH_CFG **eth_array, uint32 flags)
{
#ifdef CONFIG_FEATURE_ETH_WAN_SUPPORT
    char8 sValue[MAX_FILELINE_LEN];
    char8 command[MAX_FILELINE_LEN];

    int i = 0;
    int	ret = IFX_SUCCESS;
    char num;
    uint32 inflag = flags, outflag = 0;
    ETH_CH_CFG *t_ptr = NULL;
    
    
    /* get the count of eth channels present in rc.conf */
    memset(sValue,'\0',sizeof(sValue));
    if(ifx_GetObjData(FILE_RC_CONF, TAG_ETH_CHANNEL, 
		"eth_channel_Count", inflag, &outflag, sValue) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] COuld not retreive Ethernet channel count", __FUNCTION__, __LINE__);
        #endif
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }
    else
    {
        num = atoi(sValue);
        *num_entries = num;
    }

    if(num < 1 || num > 32767)
    {
        *num_entries = 0;
        *eth_array = NULL;
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] No Ethernet Channels", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }

    t_ptr = (ETH_CH_CFG *)IFX_MALLOC(sizeof(ETH_CH_CFG)*num);
    /* check if malloc failed, if so jump to IFX_Handler and free the already allocated buffer */
    if(t_ptr == NULL)
    {
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }
    /* otherwise assign  pointer to  the eth_array*/
    *eth_array = t_ptr;

    //char8 * eth_ch_params[] = {"cpeId", "pcpeId", "ethChName", "mac", "macOverride","vlanId"};
    /* allocate memory for num_entries of ethchannels in the output array eth_array */
    for (i=0; i<num; i++)
    {
	/* initialize the cache for this instance */
	sprintf(command, "%s_%d_",PREFIX_ETH_CHANNEL,i);
	if(ifx_GetObjDataOpt(FILE_RC_CONF,TAG_ETH_CHANNEL,command, IFX_F_INT_CACHE_INIT | flags, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
        /* get the cpeid for this eth channel index i */
        MAKE_SECTION_ELEMENT_TAG(PREFIX_ETH_CHANNEL, i, "cpeId", command);
        memset(sValue,'\0',sizeof(sValue));
        if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ETH_CHANNEL, 
		    command, inflag, &outflag, sValue)) == IFX_SUCCESS)
        {
            (*eth_array+i)->iid.cpeId.Id = atoi(sValue);
        }

        /* get the parent cpeid for this eth channel index i */
        MAKE_SECTION_ELEMENT_TAG(PREFIX_ETH_CHANNEL, i, "pcpeId", command);
        memset(sValue,'\0',sizeof(sValue));
        if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ETH_CHANNEL, 
		         command, inflag, &outflag, sValue)) == IFX_SUCCESS)
        {
            (*eth_array+i)->iid.pcpeId.Id = atoi(sValue);
        }

        /* get the enable value for this eth channel index i */
        MAKE_SECTION_ELEMENT_TAG(PREFIX_ETH_CHANNEL, i, "fEnable", command);
        memset(sValue,'\0',sizeof(sValue));
        if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ETH_CHANNEL, 
		         command, inflag, &outflag, sValue)) == IFX_SUCCESS)
        {
            (*eth_array+i)->f_enable = atoi(sValue);
        }

        /* get the name for this eth channel index i */
        MAKE_SECTION_ELEMENT_TAG(PREFIX_ETH_CHANNEL, i, "ethChName", command);
        memset(sValue,'\0',sizeof(sValue));
        if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ETH_CHANNEL, 
			command, inflag, &outflag, sValue)) == IFX_SUCCESS)
        {
            snprintf((*eth_array+i)->eth_ch_name,MAX_NAME_LEN,"%s", sValue);
        }

        /* get the MAC addr for this eth channel index i */
        MAKE_SECTION_ELEMENT_TAG(PREFIX_ETH_CHANNEL, i, "mac", command);
        memset(sValue,'\0',sizeof(sValue));
        if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ETH_CHANNEL, 
		command, inflag, &outflag, sValue)) == IFX_SUCCESS)
        {
            snprintf((*eth_array+i)->mac_addr,MAX_MAC_ADDR_LEN,"%s", sValue);
        }

        /* get the override status for this eth channel index i */
        MAKE_SECTION_ELEMENT_TAG(PREFIX_ETH_CHANNEL, i, "macOverride", command);
        memset(sValue,'\0',sizeof(sValue));
        if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ETH_CHANNEL, 
				command, inflag, &outflag, sValue)) == IFX_SUCCESS)
        {
            (*eth_array+i)->macOverride = atoi(sValue);
        }

        /* get the vlanId for this vc channel index i */
        MAKE_SECTION_ELEMENT_TAG(PREFIX_ETH_CHANNEL, i, "vlanId", command);
        memset(sValue,'\0',sizeof(sValue));
        if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ETH_CHANNEL, 
		command, inflag, &outflag, sValue)) == IFX_SUCCESS)
        {
            (*eth_array+i)->vlanId = atoi(sValue);
        }

	/* destroy the cache for this instance */
	sprintf(command, "%s_%d_",PREFIX_ETH_CHANNEL,i);
	if(ifx_GetObjDataOpt(FILE_RC_CONF,TAG_ETH_CHANNEL,command,IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to destroy cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
    }


IFX_Handler:
    if(ret != IFX_SUCCESS)
    {
        IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
        *num_entries = 0;
        IFX_MEM_FREE(*eth_array)
    }
    return ret;
#else
    return IFX_SUCCESS;
#endif //CONFIG_FEATURE_ETH_WAN_SUPPORT
}



/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_vcc(...)
*	vcc		==>	input pointer to the ATM_VCC_INFO array which will store the
*				vc channel information
*	num		==>	number of vc channels in the array vcc
*	vpivci		==>	the vpi/vci value pair for which the name has to be searhced
*	name		==>	the vc channel member for which value has to be returned
*	sValue		==>	output which will have of the name for this vpici
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function takes a pointer to the array vcc, searches for the vc channel
			which has the vpi-vci pair as vpivci and returns the value for the member
			name for this vcchannel.
*//////////////////////////////////////////////////////////////////////////////
int ifx_get_vcc(ATM_VCC_INFO *vcc, int num, char *vpivci, char *name, int *sValue)
{

		char	t_vpivci[MAX_NAME_SIZE];
		int		ret = IFX_SUCCESS;
		int		i=0;

		NULL_TERMINATE(t_vpivci, 0x00, sizeof(t_vpivci));
		for(i=0;i<num;i++) {
				/* compare the input vpivci with the ones present in the input array
				 * of vc channels read from rc.conf */
				sprintf(t_vpivci, "%d/%d", (vcc+i)->vc.pvc.vpi, (vcc+i)->vc.pvc.vci);
				if( !strcmp(t_vpivci, vpivci) ) {

						/* if the vpivci match, get the value for the corresponding field name
						 * requested in the input argument name */
						if( !strcmp(name, "vpi"))
								*sValue = (vcc+i)->vc.pvc.vpi;
						else if( !strcmp(name, "vci"))
								*sValue = (vcc+i)->vc.pvc.vci;
						else if( !strcmp(name, "QoSMode"))
								*sValue = ((vcc+i)->txtp.traffic_class);
						else if( !strcmp(name, "CapMode"))
								*sValue = (vcc+i)->encap;
						else if( !strcmp(name, "pcr"))
								*sValue = (vcc+i)->txtp.max_pcr;
						else if( !strcmp(name, "min_pcr"))
								*sValue = (vcc+i)->txtp.min_pcr;
#ifndef HOSTENV
						else if( !strcmp(name, "cdv"))
								*sValue = (vcc+i)->txtp.cdv;
						else if( !strcmp(name, "scr"))
								*sValue = (vcc+i)->txtp.scr;
						else if( !strcmp(name, "mbs"))
								*sValue = (vcc+i)->txtp.mbs;
#endif
						goto IFX_Handler;
				}
		}

		ret = IFX_FAILURE;

IFX_Handler:
		if(ret != IFX_SUCCESS) {
			IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
			return ret;
		}
		else
			return IFX_SUCCESS;

}
///////////////////////////////////////////////////////////////////////////////
//function : ifx_get_one_vcc_info
//arguments: ATM_VCC_INFO *vcc
//	     uint32 iCpeid
//           uint32 flags
//return   :IFX_SUCCESS if successful 
//          IFX_FAIL otherwise
///////////////////////////////////////////////////////////////////////////////
int32 ifx_get_one_vcc_info(ATM_VCC_INFO *vcc)
{
        char8   *vpi = NULL, *vci = NULL; 
	char8   sValue[MAX_FILELINE_LEN];
	char8   command[MAX_FILELINE_LEN];	
	uint32  inflag = IFX_F_GET_ANY, outflag = 0;
	int     i = 0, found = 0;
	int     ret = IFX_SUCCESS;
 #ifdef CPU_AMAZON
        uint32  crc_errors=0;
#endif
	IFX_ID iid;
	iid.cpeId.Id=vcc->iid.cpeId.Id;
	ATM_VCC_INFO *temp=vcc;
	int32 vcc_index=-1;
	sprintf(iid.cpeId.secName, "%s", TAG_ADSL_VCCHANNEL);
	sprintf(vcc->iid.cpeId.secName, "%s", TAG_ADSL_VCCHANNEL);
	if(ifx_get_index_from_cpe_id(FILE_RC_CONF, &(iid.cpeId), &vcc_index) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
                        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
		#endif
                        ret = IFX_FAILURE;
                        goto IFX_Handler;
	}
        i=vcc_index;	
//	memset(temp,'\0',sizeof(ATM_VCC_INFO));
	 
	/* initialize the cache for this instance */
	sprintf(command, "%s_%d_", PREFIX_ADSL_VCCHANNEL, vcc_index);
	if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, command, IFX_F_INT_CACHE_INIT | IFX_F_GET_ANY, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "cpeId", command);
	memset(sValue,'\0',sizeof(sValue));
         if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
                                  command, inflag, &outflag, sValue)) != IFX_SUCCESS)
         {
         }
         else
           temp->iid.cpeId.Id = atoi(sValue);
	 
	 MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "pcpeId", command);
	memset(sValue,'\0',sizeof(sValue));
         if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
                                  command, inflag, &outflag, sValue)) !=         IFX_SUCCESS) {
		#ifdef IFX_LOG_DEBUG
                          IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
                #endif
                        ret = IFX_FAILURE;
                        goto IFX_Handler;
         }
         else
                         temp->iid.pcpeId.Id = atoi(sValue);
    
                 MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "fEnable", command);
	memset(sValue,'\0',sizeof(sValue));
                 if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
                                    command, inflag, &outflag, sValue)) !=         IFX_SUCCESS) {
                 }
                 else
                         temp->f_enable = atoi(sValue);
  
                 MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "linkType", command);
	memset(sValue,'\0',sizeof(sValue));
                 if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
                                    command, inflag, &outflag, sValue)) !=         IFX_SUCCESS) {
                 }
                 else
                         temp->type = atoi(sValue);
   
                 MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "aal", command);
	memset(sValue,'\0',sizeof(sValue));
                 if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
                                     command, inflag, &outflag, sValue)) !=         IFX_SUCCESS) {
                 }
                 else
                         temp->aal = atoi(sValue);
	
	  	 MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "fcs", command);
	memset(sValue,'\0',sizeof(sValue));
                 if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
                                     command, inflag, &outflag, sValue)) !=         IFX_SUCCESS) {
                 }
                 else
                          temp->fcs_preserved = atoi(sValue);

                 MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "vcc", command);
	memset(sValue,'\0',sizeof(sValue));
                 if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
                                     command, inflag, &outflag, sValue)) !=         IFX_SUCCESS) {
                 }
                 else {
                           vpi = strtok(sValue, "/");
			   if(vpi != NULL)
	                   {
				temp->vc.pvc.vpi = atoi(vpi);
			   }
                           vci = strtok(NULL, "/");
        		   if(vci != NULL)
		           {
				temp->vc.pvc.vci = atoi(vci);
			   }
                 }
   
                 MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "encap", command);
	memset(sValue,'\0',sizeof(sValue));
                 if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
                                     command, inflag, &outflag, sValue)) !=         IFX_SUCCESS) {
                 }
                 else
                          temp->encap = atoi(sValue);
    
                 MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "qos", command);
	memset(sValue,'\0',sizeof(sValue));
                 if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
                                     command, inflag, &outflag, sValue)) !=         IFX_SUCCESS) {
                 }
                 else
                          temp->txtp.traffic_class = sValue[0] - '0';
		  
		 MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "maxpcr", command);
	memset(sValue,'\0',sizeof(sValue));
                 if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
                                    command, inflag, &outflag, sValue)) !=         IFX_SUCCESS) {
                 }
                 else {
                          temp->txtp.max_pcr = atoi(sValue);
                 }

                 MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "minpcr", command);
	memset(sValue,'\0',sizeof(sValue));
                 if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
                                     command, inflag, &outflag, sValue)) !=         IFX_SUCCESS) {
                 }
                 else {
                          temp->txtp.min_pcr = atoi(sValue);
                 }
    #ifndef HOSTENV
                 MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "cdv", command);
	memset(sValue,'\0',sizeof(sValue));
                 if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
                                    command, inflag, &outflag, sValue)) !=         IFX_SUCCESS) {
                 }
                 else {
                          temp->txtp.cdv = atoi(sValue);
                 }
   
                 MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "scr", command);
	memset(sValue,'\0',sizeof(sValue));
                 if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
                                    command, inflag, &outflag, sValue)) !=         IFX_SUCCESS) {}
                 else {
                          temp->txtp.scr = atoi(sValue);
                 }

		 MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "mbs", command);
	memset(sValue,'\0',sizeof(sValue));
                 if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
                                     command, inflag, &outflag, sValue)) !=         IFX_SUCCESS) {
                 }
                 else {
                          temp->txtp.mbs = atoi(sValue);
                 }
   #endif
  
                if(outflag != IFX_F_GET_ENA)
                          temp->link_status = DSL_LINK_STATUS_UNAVAILABLE;
                else {
                          sprintf(command, "VCChannel%d_Info", i+1);
	               memset(sValue,'\0',sizeof(sValue));
                       if ((ifx_GetObjData(FILE_SYSTEM_STATUS, command, "STATUS",
                                                  inflag, &outflag, sValue)) != IFX_SUCCESS) {
                                 temp->link_status = DSL_LINK_STATUS_DOWN;
                        }
                        else {
                                  if(!strcmp(sValue, "CONNECTING"))
                                             temp->link_status = DSL_LINK_STATUS_INITIALIZE;
                                  else if(!strcmp(sValue, "CONNECTED"))
                                             temp->link_status = DSL_LINK_STATUS_UP;
                                  else
                                             temp->link_status = DSL_LINK_STATUS_DOWN;
                        }
                }
		
		found = 0;
#ifdef CPU_AMAZON
                if (!(in = fopen(PROCF_AMZ_VC, "r"))) {
#ifdef IFX_LOG_DEBUG
	                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                        temp->crc_errors = 0;
                }
                else {
	                   found = 0;
                           while (sValue == fgets(sValue, sizeof(sValue), in)) {
                           if (strstr(sValue, "vpi")) {
                                  sscanf(sValue, "\tvpi=%d vci=%d ", &file_vpi, &file_vci);
                                  if((file_vpi == temp->vc.pvc.vpi) && (file_vci == temp->vc.pvc.vci))
                                          found = 1;
  	                          }
                                  else if (strstr(sValue, "CRC error") && found) {
                                          sscanf(sValue, "\tCRC error=%d", &crc_errors);
                                          temp->crc_errors = crc_errors;
                                           break;
                                  }
 	                   }
        	           fclose(in);
                }
		if (!(in = fopen(PROCF_DNB_VC, "r"))) {
#ifdef IFX_LOG_DEBUG
	                IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
        	        temp->crc_errors = 0;
 	        }
                else {
                           found = 0;
                           while (sValue == fgets(sValue, sizeof(sValue), in)) {
                                 if(strstr(sValue, "Address") != NULL)
                                          continue;
                                 if (strstr(sValue, "vpi")) {
	                                  sscanf(sValue, "%s %3d %3d %5d ", tmp, &itf, &file_vpi, &file_        vci);
	                                          if((file_vpi == temp->vc.pvc.vpi) && (file_vci == temp->vc.pvc.vci))
                                                            found = 1;
                                 }
                                /* Pramod : dont know how to get this....
                                else if (strstr(sValue, "CRC error") && found) {
                                sscanf(sValue, "\tCRC error=%d", &crc_errors);
                                     (*vcc_array+i)->crc_errors = crc_errors;
                                      break;
                                } */
                 	   }
                 	   fclose(in);
                }
#endif // CPU_AMAZON
                temp->autoconfig = 0;
       /* hard code the transmitted and recieved blocks to 0
       * (in 3.1.7 there is no iface with name atm.x.x registered)
      */
                temp->tx_cells = 0;
                temp->rx_cells = 0;
	//	*vcc=temp;			
IFX_Handler:
	/* destroy the cache for this instance */
	sprintf(command, "%s_%d_", PREFIX_ADSL_VCCHANNEL, vcc_index);
	if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, command, IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to destroy cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

     if(ret != IFX_SUCCESS) {
              IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
              return ret;
     }
     else
              return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_all_vcc_info(...)
*	num_entries	==>	ouput number of vc channels present in rc.conf
*	vcc_array	==>	output pointer to the array of vc channels present in rc.conf
*	flags		==>	
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads the vc channels from rc.conf and stores them
			in the output array vcc_array.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_all_vcc_info(int32 *num_entries, ATM_VCC_INFO **vcc_array, uint32 flags)
{
		char8	sValue[MAX_FILELINE_LEN];
		char8	command[MAX_FILELINE_LEN];
		char8	*vpi = NULL, *vci = NULL;
		char8	tmp[MAX_FILELINE_LEN];

		int     i = 0, found = 0, itf = 0;
		int		ret = IFX_SUCCESS, file_vpi = 0, file_vci = 0;
		char    num;
		uint32	inflag = flags, outflag = 0;
		FILE	*in = NULL;
#ifdef CPU_AMAZON
		uint32	crc_errors = 0;
#endif
		ATM_VCC_INFO *t_ptr = NULL;

		NULL_TERMINATE(tmp, 0x00, sizeof(tmp));

		/* get the count of vc channels present in rc.conf */
	        memset(sValue,'\0',sizeof(sValue));
		if (ifx_GetObjData(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, 
								"adsl_vcchannel_Count", inflag, &outflag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
		}
		else {
				num = atoi(sValue);
				*num_entries = num;
		}

		if (num < 1 || num > 32767) {
				*num_entries = 0;
				*vcc_array = NULL;
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
		}

		t_ptr = (ATM_VCC_INFO *)IFX_MALLOC(sizeof(ATM_VCC_INFO)*num);
	   /* check if malloc failed, if so jump to IFX_Handler and free the already allocated buffer */
		if(t_ptr == NULL) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
				/* otherwise assign  pointer to  the vcc_array*/
		*vcc_array = t_ptr;

		/* allocate memory for num_entries of vcchannels in the output array vcc_array */
		for (i=0; i<num; i++)	{

	/* initialize the cache for this instance */
	sprintf(command, "%s_%d_","VCChannel",i);
	if(ifx_GetObjDataOpt(FILE_RC_CONF,TAG_ADSL_VCCHANNEL, command, IFX_F_INT_CACHE_INIT | flags, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
				

                                /* get the vcc_name for this vc channel index i */
                                MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "VccNAME", command);
	                        memset(sValue,'\0',sizeof(sValue));
                                if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL,
                                                                                command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
                                }
                                else
                                        snprintf((*vcc_array+i)->vcc_ch_name,MAX_NAME_LEN,"%s",sValue);

                                 


                                

                                /* get the cpeid for this vc channel index i */
				MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "cpeId", command);
	                        memset(sValue,'\0',sizeof(sValue));
				if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, 
										command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
				}
				else
					(*vcc_array+i)->iid.cpeId.Id = atoi(sValue);
				/* get the parent cpeid for this vc channel index i */
				MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "pcpeId", command);
	                        memset(sValue,'\0',sizeof(sValue));
				if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, 
										command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
				}
				else
						(*vcc_array+i)->iid.pcpeId.Id = atoi(sValue);
				/* get the enable status for this vc channel index i */
				MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "fEnable", command);
	                        memset(sValue,'\0',sizeof(sValue));
				if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, 
										command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
				}
				else
						(*vcc_array+i)->f_enable = atoi(sValue);
				/* get the link type (atm protocol) for this vc channel index i */
				MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "linkType", command);
	                        memset(sValue,'\0',sizeof(sValue));
				if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, 
										command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
				}
				else
						(*vcc_array+i)->type = atoi(sValue);
/* ???? */				/* get the atm adaptation layer for this vc channel index i */
				MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "aal", command);
	                        memset(sValue,'\0',sizeof(sValue));
				if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, 
										command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
				}
				else
						(*vcc_array+i)->aal = atoi(sValue);
/* ???? */				/* get the for this vc channel index i */
				MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "fcs", command);
	                        memset(sValue,'\0',sizeof(sValue));
				if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, 
										command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
				}
				else
						(*vcc_array+i)->fcs_preserved = atoi(sValue);
				/* get the vpi/vci value for this vcchannel index i */
				MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "vcc", command);
	                        memset(sValue,'\0',sizeof(sValue));
				if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, 
										command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
				}
				else {
						/* parse the read vpivci value of the form vpi/vci into
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);		 * the output structure */
					    	vpi = strtok(sValue, "/");
						if(vpi != NULL)
	                    			{
							(*vcc_array+i)->vc.pvc.vpi = atoi(vpi);
			   			}
						vci = strtok(NULL, "/");
						if(vci != NULL)
	                			{
							(*vcc_array+i)->vc.pvc.vci = atoi(vci);
			   			}
				}
				/* get the encap mode for this vcchannel index i */
				MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "encap", command);
	                        memset(sValue,'\0',sizeof(sValue));
				if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, 
										command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
				}
				else
						(*vcc_array+i)->encap = atoi(sValue);
				/* get the qos mode for this vcchannel index i */
				MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "qos", command);
	                        memset(sValue,'\0',sizeof(sValue));
				if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, 
										command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
				}
				else
						(*vcc_array+i)->txtp.traffic_class = sValue[0] - '0';
				/* get the max pcr value for this vcchannel index i */
				MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "maxpcr", command);
	                        memset(sValue,'\0',sizeof(sValue));
				if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, 
										command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
				}
				else {
						(*vcc_array+i)->txtp.max_pcr = atoi(sValue);
				}
				/* get the min pcr value for this vcchannel index i */
				MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "minpcr", command);
	                        memset(sValue,'\0',sizeof(sValue));
				if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, 
										command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
				}
				else {
						(*vcc_array+i)->txtp.min_pcr = atoi(sValue);
				}
#ifndef HOSTENV
				/* get the cdv value for this vcchannel index i */
				MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "cdv", command);
	                        memset(sValue,'\0',sizeof(sValue));
				if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, 
										command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
				}
				else {
						(*vcc_array+i)->txtp.cdv = atoi(sValue);
				}
				/* get the scr value for this vcchannel index i */
				MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "scr", command);
	                        memset(sValue,'\0',sizeof(sValue));
				if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, 
										command, inflag, &outflag, sValue)) != IFX_SUCCESS) {}
				else {
						(*vcc_array+i)->txtp.scr = atoi(sValue);
				}
				/* get the mbs value for this vcchannel index i */
				MAKE_SECTION_ELEMENT_TAG("VCChannel", i, "mbs", command);
	                        memset(sValue,'\0',sizeof(sValue));
				if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, 
										command, inflag, &outflag, sValue)) != IFX_SUCCESS) {
				}
				else {
						(*vcc_array+i)->txtp.mbs = atoi(sValue);
				}

	/* destroy the cache for this instance */
	sprintf(command, "%s_%d_","VCChannel",i);
	if(ifx_GetObjDataOpt(FILE_RC_CONF,TAG_ADSL_VCCHANNEL, command,IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to destroy cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
#endif

				/* if vcc is present in rc.conf in disabled state then set status to down
				 * if its enabled in rc.conf then check on the status of this vcc in system_status file */
				if(outflag != IFX_F_GET_ENA)
					(*vcc_array+i)->link_status = DSL_LINK_STATUS_UNAVAILABLE;
				else {
					sprintf(command, "VCChannel%d_Info", i+1);
	                                memset(sValue,'\0',sizeof(sValue));
					if ((ifx_GetObjData(FILE_SYSTEM_STATUS, command, "STATUS",
									inflag, &outflag, sValue)) != IFX_SUCCESS) {
							(*vcc_array+i)->link_status = DSL_LINK_STATUS_DOWN;
					}
					else {
						if(!strcmp(sValue, "CONNECTING"))
							(*vcc_array+i)->link_status = DSL_LINK_STATUS_INITIALIZE;
						else if(!strcmp(sValue, "CONNECTED"))
							(*vcc_array+i)->link_status = DSL_LINK_STATUS_UP;
						else
							(*vcc_array+i)->link_status = DSL_LINK_STATUS_DOWN;
					}
				}

				/* get the atm crc errors from /proc/amazon_atm_vcc */
				found = 0;
#ifdef CPU_AMAZON
			    if (!(in = fopen(PROCF_AMZ_VC, "r"))) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
					(*vcc_array+i)->crc_errors = 0;
				}
				else {
					found = 0;
					while (sValue == fgets(sValue, sizeof(sValue), in)) {
						if (strstr(sValue, "vpi")) {
							sscanf(sValue, "\tvpi=%d vci=%d ", &file_vpi, &file_vci);
							if((file_vpi == (*vcc_array+i)->vc.pvc.vpi) && (file_vci == (*vcc_array+i)->vc.pvc.vci))
								found = 1;
						}
					    else if (strstr(sValue, "CRC error") && found) {
					        sscanf(sValue, "\tCRC error=%d", &crc_errors);
							(*vcc_array+i)->crc_errors = crc_errors;
							break;
						}
					}
					fclose(in);
				}
#else

			    if (!(in = fopen(PROCF_DNB_VC, "r"))) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
					(*vcc_array+i)->crc_errors = 0;
				}
				else {
					found = 0;
					while (sValue == fgets(sValue, sizeof(sValue), in)) {
						if(strstr(sValue, "Address") != NULL)
							continue;
						if (strstr(sValue, "vpi")) {
							sscanf(sValue, "%s %3d %3d %5d ", tmp, &itf, &file_vpi, &file_vci);
							if((file_vpi == (*vcc_array+i)->vc.pvc.vpi) && (file_vci == (*vcc_array+i)->vc.pvc.vci))
								found = 1;
						}
						/* Pramod : dont know how to get this....
					    else if (strstr(sValue, "CRC error") && found) {
					        sscanf(sValue, "\tCRC error=%d", &crc_errors);
							(*vcc_array+i)->crc_errors = crc_errors;
							break;
						} */
					}
					fclose(in);
				}
#endif // CPU_AMAZON
				
				/* hard code autoconfig to false */
				(*vcc_array+i)->autoconfig = 0;

				/* hard code the transmitted and recieved blocks to 0
				 * (in 3.1.7 there is no iface with name atm.x.x registered)
				 */
				(*vcc_array+i)->tx_cells = 0;
				(*vcc_array+i)->rx_cells = 0;
		}

IFX_Handler:
		if(ret != IFX_SUCCESS) {
			IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
			*num_entries = 0;
			IFX_MEM_FREE(*vcc_array)
			return ret;
		}
		else
				return IFX_SUCCESS;

}
/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_ptm_ch_cfg(...)
*	ptm_entry	==>	pointer to ETH_CH_CFG in which Ethernet Link Config information will be returned
*    	iCpeId		==>	CPEID corresponding to the instance which has to be returned
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
*	Description  :
*			The api takes the iCpeId passed to it, gets the values of the corresponding
*                       ethernet channel connection, stores values in ptm_entry and returns.
*       Return       :	It will return IFX_SUCCESS or IFX_FAILURE
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_ptm_ch_cfg(PTM_CH_CFG *ptm_entry, uint32 flags)
{
#ifdef CONFIG_FEATURE_PTM_WAN_SUPPORT
    uint32 wanIdx = -1;
    CPE_ID cpe_id;
    int ret = IFX_SUCCESS;
    char8 command[MAX_FILELINE_LEN];
    uint32 outflag = 0;
    char8 sValue[MAX_FILELINE_LEN];

    if(ptm_entry == NULL)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Invalid inputs", __FUNCTION__, __LINE__);
        #endif
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    memset(&cpe_id, 0x00, sizeof(cpe_id));
    sprintf(cpe_id.secName,"%s",TAG_PTM_CHANNEL);
    cpe_id.Id = ptm_entry->iid.cpeId.Id;
    IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id, wanIdx)

    if(wanIdx == -1)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Invalid wan index", __FUNCTION__, __LINE__);
        #endif
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

	/* initialize the cache for this instance */
	sprintf(command, "%s_%d_", PREFIX_PTM_CHANNEL,wanIdx);
	if(ifx_GetObjDataOpt(FILE_RC_CONF,TAG_PTM_CHANNEL,command, IFX_F_INT_CACHE_INIT | flags, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
    
    /* get the cpeid for this ptm channel index */
    MAKE_SECTION_ELEMENT_TAG(PREFIX_PTM_CHANNEL, wanIdx, "cpeId", command);
    memset(sValue,'\0',sizeof(sValue));
    if ((ret=(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_PTM_CHANNEL, 
              command, flags, &outflag, sValue))) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to get cpeId wanidx[%d] flags[%d]", __FUNCTION__, __LINE__, wanIdx, flags);
        #endif
        goto IFX_Handler;
    }
    ptm_entry->iid.cpeId.Id = atoi(sValue);

    /* get the parent pCpeid for this ptm channel index */
    MAKE_SECTION_ELEMENT_TAG(PREFIX_PTM_CHANNEL, wanIdx, "pcpeId", command);
    memset(sValue,'\0',sizeof(sValue));
    if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_PTM_CHANNEL, 
	        command, flags, &outflag, sValue)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to get pCpeId", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    ptm_entry->iid.pcpeId.Id = atoi(sValue);

    /* get the enable value for this ptm channel index */
    MAKE_SECTION_ELEMENT_TAG(PREFIX_PTM_CHANNEL, wanIdx, "fEnable", command);
    memset(sValue,'\0',sizeof(sValue));
    if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_PTM_CHANNEL, 
		         command, flags, &outflag, sValue)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to get enable status", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    ptm_entry->f_enable = atoi(sValue);

    /* get the name for this ptm channel index */
    MAKE_SECTION_ELEMENT_TAG(PREFIX_PTM_CHANNEL, wanIdx, "ptmChName", command);
    memset(sValue,'\0',sizeof(sValue));
    if ((ret = (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_PTM_CHANNEL, 
			command, flags, &outflag, sValue))) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to get channel name", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    snprintf(ptm_entry->ptm_ch_name,MAX_NAME_LEN,"%s", sValue);

    /* get the MAC addr for this eth channel index */
    MAKE_SECTION_ELEMENT_TAG(PREFIX_PTM_CHANNEL, wanIdx, "mac", command);
    memset(sValue,'\0',sizeof(sValue));
    if ((ret = (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_PTM_CHANNEL, 
		command, flags, &outflag, sValue))) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to get Mac Addr", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    snprintf(ptm_entry->mac_addr,MAX_MAC_ADDR_LEN,"%s", sValue);

    /* get the override status for this eth channel index */
    MAKE_SECTION_ELEMENT_TAG(PREFIX_PTM_CHANNEL, wanIdx, "macOverride", command);
    memset(sValue,'\0',sizeof(sValue));
    if ((ret = (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_PTM_CHANNEL, 
			command, flags, &outflag, sValue))) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to get MacOverride status", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    ptm_entry->macOverride = atoi(sValue);

    /* get the vlanId for this vc channel index */
    MAKE_SECTION_ELEMENT_TAG(PREFIX_PTM_CHANNEL, wanIdx, "vlanId", command);
    memset(sValue,'\0',sizeof(sValue));
    if ((ret = (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_PTM_CHANNEL, 
	command, flags, &outflag, sValue))) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to get vlan Id", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    ptm_entry->vlanId = atoi(sValue);

    /* get the preempt value for this vc channel index */
    MAKE_SECTION_ELEMENT_TAG(PREFIX_PTM_CHANNEL, wanIdx, "preempt", command);
    memset(sValue,'\0',sizeof(sValue));
    if ((ret = (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_PTM_CHANNEL, 
	command, flags, &outflag, sValue))) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to get preempt", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    ptm_entry->preempt = atoi(sValue);

IFX_Handler:

	/* destroy the cache for this instance */
	sprintf(command, "%s_%d_", PREFIX_PTM_CHANNEL,wanIdx);
	if(ifx_GetObjDataOpt(FILE_RC_CONF,TAG_PTM_CHANNEL,command,IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to destroy cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
    if(ret != IFX_SUCCESS)
    {
        IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
    }
    return ret;
#else
    return IFX_SUCCESS;
#endif //CONFIG_FEATURE_PTM_WAN_SUPPORT
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_all_ptm_info(...)
*	num_entries	==>	ouput number of ptm channels present in rc.conf
*	ptm_array	==>	output pointer to the array of ptm channels present in rc.conf
*	flags		==>	
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
*		Description:
*			This function reads the ptm channels from rc.conf and stores them
*			in the output array ptm_array.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_all_ptm_info(int32 *num_entries, PTM_CH_CFG **ptm_array, uint32 flags)
{
#ifdef CONFIG_FEATURE_PTM_WAN_SUPPORT
    char8 sValue[MAX_FILELINE_LEN];
    char8 command[MAX_FILELINE_LEN];

    int i = 0;
    int	ret = IFX_SUCCESS;
    char num;
    uint32 inflag = flags, outflag = 0;
    PTM_CH_CFG *t_ptr = NULL;
    
    
    /* get the count of ptm channels present in rc.conf */
    memset(sValue,'\0',sizeof(sValue));
    if(ifx_GetObjData(FILE_RC_CONF, TAG_PTM_CHANNEL, 
		"ptm_channel_Count", inflag, &outflag, sValue) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to get preempt value", __FUNCTION__, __LINE__);
        #endif
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }
    else
    {
        num = atoi(sValue);
        *num_entries = num;
    }

    if(num < 1 || num > 32767)
    {
        *num_entries = 0;
        *ptm_array = NULL;
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] No channels present", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }

    t_ptr = (PTM_CH_CFG *)IFX_MALLOC(sizeof(PTM_CH_CFG)*num);
    /* check if malloc failed, if so jump to IFX_Handler and free the already allocated buffer */
    if(t_ptr == NULL)
    {
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }
    /* otherwise assign  pointer to  the ptm_array*/
    *ptm_array = t_ptr;

    //char8 * ptm_ch_params[] = {"cpeId", "pcpeId", "ethChName", "mac", "macOverride","vlanId","preempt"};
    /* allocate memory for num_entries of ptmchannels in the output array ptm_array */
    for (i=0; i<num; i++)
    {

	/* initialize the cache for this instance */
	sprintf(command, "%s_%d_",PREFIX_PTM_CHANNEL,i);
	if(ifx_GetObjDataOpt(FILE_RC_CONF,TAG_PTM_CHANNEL,command, IFX_F_INT_CACHE_INIT | flags, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

        /* get the cpeid for this ptm channel index i */
        MAKE_SECTION_ELEMENT_TAG(PREFIX_PTM_CHANNEL, i, "cpeId", command);
        memset(sValue,'\0',sizeof(sValue));
        if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_PTM_CHANNEL, 
		    command, inflag, &outflag, sValue)) == IFX_SUCCESS)
        {
            (*ptm_array+i)->iid.cpeId.Id = atoi(sValue);
        }

        /* get the parent cpeid for this ptm channel index i */
        MAKE_SECTION_ELEMENT_TAG(PREFIX_PTM_CHANNEL, i, "pcpeId", command);
        memset(sValue,'\0',sizeof(sValue));
        if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_PTM_CHANNEL, 
		         command, inflag, &outflag, sValue)) == IFX_SUCCESS)
        {
            (*ptm_array+i)->iid.pcpeId.Id = atoi(sValue);
        }

        /* get the enable value for this eth channel index i */
        MAKE_SECTION_ELEMENT_TAG(PREFIX_PTM_CHANNEL, i, "fEnable", command);
        memset(sValue,'\0',sizeof(sValue));
        if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_PTM_CHANNEL, 
		         command, inflag, &outflag, sValue)) == IFX_SUCCESS)
        {
            (*ptm_array+i)->f_enable = atoi(sValue);
        }

        /* get the name for this ptm channel index i */
        MAKE_SECTION_ELEMENT_TAG(PREFIX_PTM_CHANNEL, i, "ptmChName", command);
        memset(sValue,'\0',sizeof(sValue));
        if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_PTM_CHANNEL, 
			command, inflag, &outflag, sValue)) == IFX_SUCCESS)
        {
            snprintf((*ptm_array+i)->ptm_ch_name,MAX_NAME_LEN,"%s", sValue);
        }

        /* get the MAC addr for this ptm channel index i */
        MAKE_SECTION_ELEMENT_TAG(PREFIX_PTM_CHANNEL, i, "mac", command);
        memset(sValue,'\0',sizeof(sValue));
        if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_PTM_CHANNEL, 
		command, inflag, &outflag, sValue)) == IFX_SUCCESS)
        {
            snprintf((*ptm_array+i)->mac_addr,MAX_MAC_ADDR_LEN,"%s", sValue);
        }

        /* get the override status for this ptm channel index i */
        MAKE_SECTION_ELEMENT_TAG(PREFIX_PTM_CHANNEL, i, "macOverride", command);
        memset(sValue,'\0',sizeof(sValue));
        if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_PTM_CHANNEL, 
				command, inflag, &outflag, sValue)) == IFX_SUCCESS)
        {
            (*ptm_array+i)->macOverride = atoi(sValue);
        }

        /* get the vlanId for this vc channel index i */
        MAKE_SECTION_ELEMENT_TAG(PREFIX_PTM_CHANNEL, i, "vlanId", command);
        memset(sValue,'\0',sizeof(sValue));
        if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_PTM_CHANNEL, 
		command, inflag, &outflag, sValue)) == IFX_SUCCESS)
        {
            (*ptm_array+i)->vlanId = atoi(sValue);
        }

        /* get the preempt value for this vc channel index */
        MAKE_SECTION_ELEMENT_TAG(PREFIX_PTM_CHANNEL, i, "preempt", command);
        memset(sValue,'\0',sizeof(sValue));
        if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_PTM_CHANNEL, 
	            command, inflag, &outflag, sValue)) == IFX_SUCCESS)
        {
            (*ptm_array+i)->preempt = atoi(sValue);
        }

	/* destroy the cache for this instance */
	sprintf(command, "%s_%d_",PREFIX_PTM_CHANNEL,i);
	if(ifx_GetObjDataOpt(FILE_RC_CONF,TAG_PTM_CHANNEL,command,IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to destroy cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
    }

IFX_Handler:
    if(ret != IFX_SUCCESS)
    {
        IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
        *num_entries = 0;
        IFX_MEM_FREE(*ptm_array)
    }
    return ret;
#else
   return IFX_SUCCESS;
#endif //CONFIG_FEATURE_PTM_WAN_SUPPORT
}
