
#include <stdio.h>
#include <ctype.h>
#include <fcntl.h>
#include <string.h>
#include <syslog.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <sys/sysinfo.h>
#include "ifx_config.h"
#include "ifx_amazon_cfg.h"
#ifdef CONFIG_PACKAGE_LQ_IGMPD
#include <ifx_emf.h>
#include <string.h>
#include <signal.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/wait.h>
#endif

#define USE_SWITCH_API_ENUM_H
#include "ifx_common.h"
#include "ifx_api_include.h"
#ifdef CONFIG_PACKAGE_IFX_ETHSW
#ifdef IFX_SUCCESS
#undef IFX_SUCCESS
#endif

#include "ifx_ethsw.h"
#include "ifx_ethsw_api.h"
#endif // CONFIG_PACKAGE_IFX_ETHSW


#ifdef CONFIG_PACKAGE_LQ_IGMPD
#define IFNAMSIZ 16
#define TAG_MULTICAST	"mcast_proxy_snooping"
#define IFACE_SIZE		256

struct igmp_rc {
	uint32 igmp_query_interval;
  uint32 igmp_query_resp_interval;
  uint32 igmp_last_mem_query_interval;
  uint32 igmp_last_mem_query_count;
  int32 igmp_query_interval_status;
  int32 igmp_query_resp_interval_status;
  int32 igmp_last_mem_query_interval_status;
  int32 igmp_last_mem_query_count_status;
  int32 igmp_fast_leave_status;
  int32 igmp_snooping_status;
  int32 igmp_proxy_status;
  int32 igmp_snooping_mode;
  uint32 mld_query_interval;
  uint32 mld_query_resp_interval;
  uint32 mld_last_mem_query_interval;
  uint32 mld_last_mem_query_count;
  int32 mld_query_interval_status;
  int32 mld_query_resp_interval_status;
  int32 mld_last_mem_query_interval_status;
  int32 mld_last_mem_query_count_status;
  int32 mld_fast_leave_status;
  int32 mld_snooping_status;
  int32 mld_proxy_status;
  int32 mld_snooping_mode;

  char8 mcast_grp_entry[MAX_DATA_LEN];
  char8 up_iface_str[IFACE_SIZE];
  char8 up_wan_iface_str[IFACE_SIZE];
  char8 down_iface_str[IFACE_SIZE];
};
#endif

/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_set_igmp_snoop_cfg(...)
*    	cmd	==>     ioctl command	
*	flags   ==>     not used for now
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
/////////////////////////////////////////////////////////////////////////////*/
int32 ifx_mapi_set_igmp_snoop_cfg (uint32 cmd, uint32 flags)
{
#ifdef CONFIG_FEATURE_IFX_IGMPPROXY

#ifdef CONFIG_PACKAGE_IFX_ETHSW

   IFX_ETHSW_multicastSnoopCfg_t multicast_SnoopCfgSet;
   int retval=-1, ret = IFX_FAILURE;
   int switch_fd = -1;
   char switch_dev[]="/dev/switch_api/1";
   void* ioctl_params = NULL;

   /* open char device for ioctl communication */
   if((switch_fd=open(switch_dev, O_RDONLY))==-1)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("Error opening char device %s\n", switch_dev);
#endif
      return IFX_FAILURE;
   }
   memset(&multicast_SnoopCfgSet, 0x00, sizeof(multicast_SnoopCfgSet));

   switch (cmd) {
      case IFX_IGMPv2_SNOOPING_ENABLE:
         multicast_SnoopCfgSet.eIGMP_Mode = IFX_ETHSW_MULTICAST_SNOOP_MODE_AUTOLEARNING;
	 multicast_SnoopCfgSet.bIGMPv3 = 0;
	 multicast_SnoopCfgSet.bCrossVLAN = 0;
	 multicast_SnoopCfgSet.eForwardPort = 2;
	 multicast_SnoopCfgSet.nClassOfService = 0;
	 multicast_SnoopCfgSet.nRobust = 2;
	 multicast_SnoopCfgSet.nQueryInterval = 124;
	 multicast_SnoopCfgSet.eSuppressionAggregation = 0;
	 multicast_SnoopCfgSet.bFastLeave = 1;	
	 ioctl_params = (void *)&multicast_SnoopCfgSet;

         break;
 
     case IFX_IGMPv2_SNOOPING_DISABLE:
         multicast_SnoopCfgSet.eIGMP_Mode = IFX_ETHSW_MULTICAST_SNOOP_MODE_DISABLED;
	 multicast_SnoopCfgSet.bIGMPv3 = 0;
	 multicast_SnoopCfgSet.bCrossVLAN = 0;
	 multicast_SnoopCfgSet.eForwardPort = 2;
	 multicast_SnoopCfgSet.nClassOfService = 0;
	 multicast_SnoopCfgSet.nRobust = 0;
	 multicast_SnoopCfgSet.nQueryInterval = 124;
	 multicast_SnoopCfgSet.eSuppressionAggregation = 0;
	 multicast_SnoopCfgSet.bFastLeave = 0;	
	 ioctl_params = (void *)&multicast_SnoopCfgSet;

         break;

     default:
	goto IFX_Handler;
   }
   ioctl_params = (void *)&multicast_SnoopCfgSet;
   retval=ioctl( switch_fd, IFX_ETHSW_MULTICAST_SNOOP_CFG_SET, ioctl_params );
   if(retval < 0)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG ("[%s]:[%d]\n", __FUNCTION__, __LINE__);
#endif
      ret = IFX_FAILURE;	
      goto IFX_Handler;
   }
   ret = IFX_SUCCESS;	

IFX_Handler:
   close(switch_fd);
   if (ret != IFX_SUCCESS) {
      return IFX_FAILURE;
   }
   return IFX_SUCCESS;

#else

   return IFX_FAILURE;
#endif

#else

   return IFX_SUCCESS;
#endif
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_mapi_set_igmp_router_port(...)
*	port	==> 	port info 
*    	cmd	==>     ioctl command	
*    	flags	==>     not used for now	
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
/////////////////////////////////////////////////////////////////////////////*/
int32 ifx_mapi_set_igmp_router_port (uint32 port, uint32 cmd, uint32 flags)
{
#ifdef CONFIG_FEATURE_IFX_IGMPPROXY

#ifdef CONFIG_PACKAGE_IFX_ETHSW

   IFX_ETHSW_multicastRouter_t multicast_RouterPortConfig; 
   int retval=-1, ret =IFX_FAILURE;
   int switch_fd = -1;
   char switch_dev[]="/dev/switch_api/1";
   void* ioctl_params = NULL;

#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);
#endif

   /* open char device for ioctl communication */
   if((switch_fd=open(switch_dev, O_RDONLY))==-1)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("Error opening char device %s\n", switch_dev);
#endif
      return IFX_FAILURE;
   }
   memset(&multicast_RouterPortConfig, 0x00, sizeof(multicast_RouterPortConfig));

   multicast_RouterPortConfig.nPortId = port; /* CPU port */ 	    
   ioctl_params = (void *)&multicast_RouterPortConfig;

   switch (cmd) {

	case IFX_MCAST_ROUTER_PORT_ADD:
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);
#endif
   	   retval=ioctl( switch_fd, IFX_ETHSW_MULTICAST_ROUTER_PORT_ADD, ioctl_params );
	   break;

	case IFX_MCAST_ROUTER_PORT_REMOVE:
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);
#endif
   	   retval=ioctl( switch_fd, IFX_ETHSW_MULTICAST_ROUTER_PORT_REMOVE, ioctl_params );
           break;

	default:
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s]:[%d]\n", __FUNCTION__, __LINE__);
#endif
	   goto IFX_Handler;
   }

   if(retval < 0)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG ("[%s]:[%d]\n", __FUNCTION__, __LINE__);
#endif
      ret = IFX_FAILURE;
      goto IFX_Handler;
   }

   ret = IFX_SUCCESS;	

IFX_Handler:
   close(switch_fd);
   if (ret != IFX_SUCCESS) {
      return IFX_FAILURE;
   }
   return IFX_SUCCESS;

#else

   return IFX_FAILURE;
#endif

#else

   return IFX_FAILURE;
#endif
}

#ifdef CONFIG_PACKAGE_LQ_IGMPD
static void signal_daemon(int sig)
{
    FILE    *fd = NULL;
    int32   pid = 0;

    fd = fopen("/var/run/mcastd.pid","r");
    if (fd) {
        fscanf(fd, "%d", &pid);

        kill(pid, sig);
        fclose(fd);
    }
    else {
        if (sig != SIGINT)
            system("/usr/sbin/mcastd -b -c /etc/rc.conf");
    }
}
int ifx_SetIgmpParam_ToRcConf(struct igmp_rc *ptrSet)
{
	char_t sAdvparameter[1024];
  char_t sAdvparameter1[1024];
  char_t sAdvparameter2[1024];
  char_t sAdvparameter3[1024];
  char_t sAdvparameter4[1024];

  /* Populate parameters in rc.conf */
  gsprintf(sAdvparameter,
  "mcast_grp_entries=\"%s\"\nmcast_upstream=\"%s\"\nmcast_upstream_wan=\"%s\"\nmcast_downstream=\"%s\"\n", ptrSet->mcast_grp_entry, ptrSet->up_iface_str, ptrSet->up_wan_iface_str, ptrSet->down_iface_str);

  gsprintf(sAdvparameter1,
  "mcast_igmp_query_interval=\"%d\"\nmcast_igmp_query_resp_interval=\"%d\"\nmcast_igmp_last_mem_query_interval=\"%d\"\nmcast_igmp_last_mem_query_count=\"%d\"\n", ptrSet->igmp_query_interval, ptrSet->igmp_query_resp_interval, ptrSet->igmp_last_mem_query_interval, ptrSet->igmp_last_mem_query_count);

  gsprintf(sAdvparameter2,
  "mcast_igmp_query_interval_status=\"%d\"\nmcast_igmp_query_resp_interval_status=\"%d\"\nmcast_igmp_last_mem_query_interval_status=\"%d\"\nmcast_igmp_last_mem_query_count_status=\"%d\"\nmcast_igmp_fast_leave_status=\"%d\"\nmcast_igmp_snooping_status=\"%d\"\nmcast_igmp_proxy_status=\"%d\"\nmcast_igmp_snooping_mode=\"%d\"\n",  ptrSet->igmp_query_interval_status, ptrSet->igmp_query_resp_interval_status, ptrSet->igmp_last_mem_query_interval_status, ptrSet->igmp_last_mem_query_count_status, ptrSet->igmp_fast_leave_status, ptrSet->igmp_snooping_status, ptrSet->igmp_proxy_status, ptrSet->igmp_snooping_mode);

  gsprintf(sAdvparameter3,
  "mcast_mld_query_interval=\"%d\"\nmcast_mld_query_resp_interval=\"%d\"\nmcast_mld_last_mem_query_interval=\"%d\"\nmcast_mld_last_mem_query_count=\"%d\"\n", ptrSet->mld_query_interval, ptrSet->mld_query_resp_interval, ptrSet->mld_last_mem_query_interval, ptrSet->mld_last_mem_query_count);

  gsprintf(sAdvparameter4,
  "mcast_mld_query_interval_status=\"%d\"\nmcast_mld_query_resp_interval_status=\"%d\"\nmcast_mld_last_mem_query_interval_status=\"%d\"\nmcast_mld_last_mem_query_count_status=\"%d\"\nmcast_mld_fast_leave_status=\"%d\"\nmcast_mld_snooping_status=\"%d\"\nmcast_mld_proxy_status=\"%d\"\nmcast_mld_snooping_mode=\"%d\"\n",  ptrSet->mld_query_interval_status, ptrSet->mld_query_resp_interval_status, ptrSet->mld_last_mem_query_interval_status, ptrSet->mld_last_mem_query_count_status, ptrSet->mld_fast_leave_status, ptrSet->mld_snooping_status, ptrSet->mld_proxy_status, ptrSet->mld_snooping_mode);

  if (ifx_SetCfgData(FILE_RC_CONF, TAG_MULTICAST, 5, sAdvparameter, sAdvparameter1, sAdvparameter2, sAdvparameter3, sAdvparameter4) == 0) {
    return IFX_FAILURE;
	}

  /* Save to flash */
  if (ifx_flash_write()<=0) {
    return IFX_FAILURE;
  }

  /* Set/Reset the proc entry */
  if (1) {
    FILE *fp = fopen("/proc/sys/net/bridge/bridge-igmp-snooping", "w");
    if (fp) {
      fprintf(fp, "%d", ptrSet->igmp_snooping_status);
      fclose(fp);
    }
  }
  if (1) {
    FILE *fp = fopen("/proc/sys/net/bridge/bridge-mld-snooping", "w");
    if (fp) {
      fprintf(fp, "%d", ptrSet->mld_snooping_status);
      fclose(fp);
    }
  }

  /* Signal the daemon */
  if (ptrSet->mld_snooping_status == 0 && ptrSet->mld_proxy_status == 0 &&
      ptrSet->igmp_snooping_status == 0 && ptrSet->igmp_proxy_status == 0)
    signal_daemon(SIGINT);
  else
    signal_daemon(SIGHUP);	

  return IFX_SUCCESS;
}

void ifx_GetIgmpParam_FromRcConf(struct igmp_rc *ptrGet)
{
	int range_val = 0;
	char sVal[MAX_DATA_LEN];

	/* <==== IGMP params ====> */
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_query_interval", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_query_interval = range_val;
		range_val = 0;
	} else { 
		ptrGet->igmp_query_interval = 125;
	}
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_query_resp_interval", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_query_resp_interval = range_val;
		range_val = 0;
	} else { 
		ptrGet->igmp_query_resp_interval = 10;
	}
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_last_mem_query_interval", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_last_mem_query_interval = range_val;
		range_val = 0;
	} else { 
		ptrGet->igmp_last_mem_query_interval = 1;
	}
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_last_mem_query_count", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_last_mem_query_count = range_val;
		range_val = 0;
	} else { 
		ptrGet->igmp_last_mem_query_count = 2;
	}

	// Status checking 
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_query_interval_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_query_interval_status = range_val;
		range_val = 0;
	} else {
		ptrGet->igmp_query_interval_status = 0;
	}	 
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_query_resp_interval_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_query_resp_interval_status = range_val;
		range_val = 0;
	} else { 
		ptrGet->igmp_query_resp_interval_status = 0;
	}
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_last_mem_query_interval_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_last_mem_query_interval_status = range_val;
		range_val = 0;
	} else { 
		ptrGet->igmp_last_mem_query_interval_status = 0;
	}
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_last_mem_query_count_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_last_mem_query_count_status = range_val;
		range_val = 0;
	} else { 
		ptrGet->igmp_last_mem_query_count_status = 0;
	}
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_fast_leave_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_fast_leave_status = range_val;
		range_val = 0;
	} else { 
		ptrGet->igmp_fast_leave_status = 0;
	}
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_snooping_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_snooping_status = range_val;
		range_val = 0;
	} else { 
		ptrGet->igmp_snooping_status = range_val;
	}
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_proxy_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_proxy_status = range_val;
		range_val = 0;
	} else { 
		ptrGet->igmp_proxy_status = range_val;
	}
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_igmp_snooping_mode", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->igmp_snooping_mode = range_val;
		range_val = 0;
	} else { 
		ptrGet->igmp_snooping_mode = range_val;
	}

	/* <==== MLD params ====> */
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_query_interval", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_query_interval = range_val;
		range_val = 0;
	} else { 
		ptrGet->mld_query_interval = 125;
	}
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_query_resp_interval", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_query_resp_interval = range_val;
		range_val = 0;
	} else { 
		ptrGet->mld_query_resp_interval = 10;
	}
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_last_mem_query_interval", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_last_mem_query_interval = range_val;
		range_val = 0;
	} else { 
		ptrGet->mld_last_mem_query_interval = 1;
	}
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_last_mem_query_count", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_last_mem_query_count = range_val;
		range_val = 0;
	} else { 
		ptrGet->mld_last_mem_query_count = 2;
	}

	// Status checking 
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_query_interval_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_query_interval_status = range_val;
		range_val = 0;
	} else {
		ptrGet->mld_query_interval_status = 0;
	}	 
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_query_resp_interval_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_query_resp_interval_status = range_val;
		range_val = 0;
	} else { 
		ptrGet->mld_query_resp_interval_status = 0;
	}
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_last_mem_query_interval_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_last_mem_query_interval_status = range_val;
		range_val = 0;
	} else { 
		ptrGet->mld_last_mem_query_interval_status = 0;
	}
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_last_mem_query_count_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_last_mem_query_count_status = range_val;
		range_val = 0;
	} else { 
		ptrGet->mld_last_mem_query_count_status = 0;
	}
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_fast_leave_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_fast_leave_status = range_val;
		range_val = 0;
	} else { 
		ptrGet->mld_fast_leave_status = 0;
	}
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_snooping_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_snooping_status = range_val;
		range_val = 0;
	} else { 
		ptrGet->mld_snooping_status = range_val;
	}
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_proxy_status", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_proxy_status = range_val;
		range_val = 0;
	} else { 
		ptrGet->mld_proxy_status = range_val;
	}
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_mld_snooping_mode", sVal) == 1) {
		range_val = atoi(sVal);
		ptrGet->mld_snooping_mode = range_val;
		range_val = 0;
	} else { 
		ptrGet->mld_snooping_mode = range_val;
	}


	// Multicast Group Entries
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_grp_entries", sVal) == 1) {
		strcpy(ptrGet->mcast_grp_entry, sVal);
	} else {
		strcpy(ptrGet->mcast_grp_entry, "\0");
	}	 
	
	// UPSTREAM Interface Checking
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_upstream", sVal) == 1) {
		strcpy(ptrGet->up_iface_str, sVal);
	} else {
		strcpy(ptrGet->up_iface_str, "\0");
	}	 
	// UPSTREAM WAN Interface Checking
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_upstream_wan", sVal) == 1) {
		strcpy(ptrGet->up_wan_iface_str, sVal);
	} else {
		strcpy(ptrGet->up_wan_iface_str, "\0");
	}	 
	// DOWNSTREAM Interface Checking
	if (ifx_GetCfgData(FILE_RC_CONF, TAG_MULTICAST, "mcast_downstream", sVal) == 1) {
		strcpy(ptrGet->down_iface_str, sVal);
	} else {
		strcpy(ptrGet->down_iface_str, "\0");
	}	
}
#endif



