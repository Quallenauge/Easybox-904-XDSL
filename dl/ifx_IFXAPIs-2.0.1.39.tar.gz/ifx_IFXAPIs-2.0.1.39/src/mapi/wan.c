
#include <stdio.h>
#include <ctype.h>
#include <fcntl.h>
#include <string.h>
#include <syslog.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <sys/sysinfo.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"


int32 viTR69RdFd;
char8 vcOsModId=1;


char8 *wan_main_param_names[] = {"cpeId", "pcpeId", "fEnable", "linkType", "autoDiscTime", "idleDiscTime", "warnDiscTime", "RSIP", "NATEnable", "DNSEnable", "DNSOverride", "macAddrOverride", "connTrigger", "rxRouteProto", "vcc", "ipAddr", "ipMask", "connName", "conf_connName", "DNSServers", "macAddr", "wanMode", "vlanId"};

char8 *wan_ip_param_names[] = {"cpeId", "pcpeId", "connStatus", "connType", "addrType", "maxMTU", "gateway", "ifatm"};

char8 *wan_ppp_param_names[] = {"cpeId", "pcpeId", "connType", "encrProto", "comprProto", "authProto", "maxMRU", "echoPeriod", "echoRetry", "MTU", "bridgeEnable", "ACName", "serviceName", "user", "passwd", "ifppp"};

char8 *wan_atmf5_param_names[] = {"cpeId", "pcpeId", "fEnable", "vpi", "vci", "scope", "diagnosticState", "timeout", "pingCount", "loopback", "contCheck", "successCount", "failureCount", "minRespTime", "maxRespTime", "avgRespTime", "contCheckOpt"};



#define _AMAZON_ADSL_APP
#ifndef AMAZON_MEI_MIB_RFC3440
#define AMAZON_MEI_MIB_RFC3440
#endif // AMAZON_MEI_MIB_RFC3440

#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
// #include <drv_dsl_cpe_api_config.h>
#include <drv_dsl_cpe_api.h>
#include <drv_dsl_cpe_api_ioctl.h>
#endif /*!CONFIG_PACKAGE_IFX_DSL_CPE_API */



#define	IFX_CHECK_IF_VC_IN_USE(wan_cfg, flags) { \
								int32	i =0; \
								char8	conf_vc[MAX_FILELINE_LEN], file_vc[MAX_FILELINE_LEN], t_status[MAX_FILELINE_LEN]; \
								char8	t_secName[MAX_NAME_LEN], t_vc[MAX_FILELINE_LEN], t_count[MAX_FILELINE_LEN]; \
								sprintf(conf_vc, "%d/%d", wan_cfg->vc.pvc.vpi, wan_cfg->vc.pvc.vci); \
								sprintf(t_secName, "wan_%d_vcc", wan_cfg->wan_index); \
								if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, t_secName, IFX_F_GET_ANY, \
										(IFX_OUT uint32 *)&outFlag, file_vc) == IFX_SUCCESS) { \
									if(strcmp(file_vc, conf_vc)) { \
										if (ifx_GetObjData(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, \
												"adsl_vcchannel_Count", IFX_F_GET_ENA, (IFX_OUT uint32 *)&outFlag, t_count) != IFX_SUCCESS) { \
											/* #ifdef IFX_LOG_DEBUG \
												IFX_DBG("\n\n Error : In function [%s] --> Failed to get adsl_vcchannel_Count \
															from rc.conf !! \n\n", __FUNCTION__); \
											#endif \ */ \
											ret = IFX_FAILURE; \
											goto IFX_Handler; \
										} \
										for(i=0; i<atoi(t_count); i++) { \
											sprintf(t_secName, "VCChannel%d_Info", i+1); \
											if(ifx_GetObjData(FILE_SYSTEM_STATUS, t_secName, "VCC", IFX_F_GET_ENA, \
														(IFX_OUT uint32 *)&outFlag, t_vc) != IFX_SUCCESS) { \
												continue; \
											} \
											if(!strcmp(t_vc, conf_vc)) { \
												sprintf(t_secName, "VCChannel%d_Info", i+1); \
												if(ifx_GetObjData(FILE_SYSTEM_STATUS, t_secName, "STATUS", IFX_F_GET_ENA, \
															(IFX_OUT uint32 *)&outFlag, t_status) != IFX_SUCCESS) { \
													continue; \
												} \
												if(strcmp(t_status, "DISCONNECT") && strcmp(t_status, "DISCONNECTED")) { \
													/*#ifdef IFX_LOG_DEBUG \
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
													#endif \ */ \
													ret = IFX_FAILURE; \
													goto IFX_Handler; \
												} \
											} \
										} \
									} \
								} \
							}

#define GET_WANIP_FRM_CONF(wan_index, retVal, flags) { \
								char8	buf[MAX_FILELINE_LEN]; \
								uint32	outFlag = IFX_F_DEFAULT; \
								memset(buf, 0x00, sizeof(buf)); \
								sprintf(buf, "wan_%d_ipAddr", wan_index); \
								if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, &outFlag, retVal)) != IFX_SUCCESS) { \
									sprintf(retVal, "%s", "0.0.0.0"); \
									goto IFX_Handler; \
								} \
							}

#define GET_WANMASK_FRM_CONF(wan_index, retVal, flags) { \
								char8	buf[MAX_FILELINE_LEN]; \
								uint32	outFlag = IFX_F_DEFAULT; \
								memset(buf, 0x00, sizeof(buf)); \
								sprintf(buf, "wan_%d_ipMask", wan_index); \
								if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, &outFlag, retVal)) != IFX_SUCCESS) { \
									sprintf(retVal, "%s", "0.0.0.0"); \
									goto IFX_Handler; \
								} \
							}

#define GET_WANGW_FRM_CONF(wan_index, retVal, flags) { \
								char8	buf[MAX_FILELINE_LEN]; \
								uint32	outFlag = IFX_F_DEFAULT; \
								memset(buf, 0x00, sizeof(buf)); \
								sprintf(buf, "wanip_%d_gateway", wan_index); \
								if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags, &outFlag, retVal)) != IFX_SUCCESS) { \
									sprintf(retVal, "%s", "0.0.0.0"); \
									goto IFX_Handler; \
								} \
							}

/* SET APIs */


/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_vcc_link_type(...)
*		vc			==> 	specifies vpi and vci values for which the link type has to be modified
*		type		==>		specified the new link type value
*    	flags		==>   flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
					This api takes the link type which has to be asscoiated with the vc having tha vpi/vci value pair
					it first checks if the vc is present, if present it does the updation and returns IFX_SUCCESS
					otherwise returns IFX_FAILURE.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_vcc_link_type(union vcc *vc, LINK_TYPE type, uint32 flags)
{
	int32	ret = IFX_SUCCESS;
	char8	vpivci[MAX_NAME_LEN], conf_buf[MAX_DATA_LEN], *retStr = NULL;

    NULL_TERMINATE(vpivci, 0, sizeof(vpivci));
    NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));

	sprintf(vpivci, "%d/%d", vc->pvc.vpi, vc->pvc.vci);
	ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, "vcc", vpivci, &retStr);
	if(ret != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] get index from vpi vci Fail", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	sprintf(conf_buf, "%s_linkType=\"%d\"\n", retStr, type);
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, flags, 1, conf_buf);	
	if(ret != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Get Link Type Fail", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}

IFX_Handler:
	IFX_MEM_FREE(retStr)
	if(ret != IFX_SUCCESS)
	{
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_wan_atm_vcc_config(...)
*		operation	==> 	specifies the operation to be done such as ADD, DELETE or MODIFY
*		wan_cfg		==>		pointer to WAN_CONN_CFG structure which will store the common parameters of the wan
*							connection and the wan ip/ppp specific parameters
*       flags       ==>   flags that define the behaviour
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
        Description:
				The api adds, deletes or modifies a wan connection. the api will store the wan connection over two
				sections in rc.conf, wan_main (common parameters) and wan_ip (ip specific parameters)
				or wan_ppp (ppp specific parameters). 
				the caller should pass the vcc value in the structue, the api assumes that the caller will
				pass the vcc also if he is passing the parent cpeid. The api calls respective ip or ppp set apis
				for add/modify/delete opeartion only based on the link type. The check has been provided to avoid
				any of the two api call for a disable operation. The api assumes that the adaptation has the validation
				to avoid modify operation on a wan ip connection to wan ppp connection and vice-versa.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_wan_atm_vcc_config(int32 operation, WAN_CONN_CFG *wan_cfg, uint32 flags)
{
	char8    wanVCC[20];
	char8    wan_conn_name[MAX_CONN_NAME_LEN];
	char8    cpeIDValStr[20];
	char8    *ret_WANStr = NULL, *ret_WANConnDevStr = NULL;
	char8    buf_ifnas[MAX_FILELINE_LEN], ifnasStr[10];
	char8    buf_ifatm[MAX_FILELINE_LEN], ifatmStr[10];
	IFX_ID   parent_iid, iid;
	int32    dist_wan_index = -1;
	int32    wan_index = 0;
	int32    temp_wanIndx = -1;
	int32    dist_nas_index = -1;
	int32 dist_atm_index = -1;
	IFX_NAME_VALUE_PAIR wan_main_array_fvp[34];
	uint32   wan_main_fvp_count = 0;
	IFX_NAME_VALUE_PAIR *wan_main_changed_array_fvp = NULL;
	uint32   wan_main_changed_fcount = 0;
	char8    buf[MAX_DATA_LEN], conf_buf[MAX_FILELINE_LEN];
	int32    ret=IFX_SUCCESS;
	int32	 outFlag = IFX_F_DEFAULT;
	char8	sValue[MAX_FILELINE_LEN];
	WAN_CONN_CFG old_wan_cfg;
	char8	retVal[20];
	WAN_COMMON_CFG wan_comm_cfg;
	char8	sWan_IP[MAX_IP_ADDR_LEN], sWan_Mask[MAX_IP_ADDR_LEN];
	char8	dns_servers[MAX_DNS_SERVERS * MAX_IP_ADDR_LEN];
	int32	i = 0, pcr_val = 0, qos_mode = 0;


	NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
	NULL_TERMINATE(wanVCC, 0, sizeof(wanVCC));
	NULL_TERMINATE(cpeIDValStr, 0, sizeof(cpeIDValStr));
	NULL_TERMINATE(buf_ifnas, 0, sizeof(buf_ifnas));
	NULL_TERMINATE(buf_ifatm, 0, sizeof(buf_ifatm));
	NULL_TERMINATE(sWan_IP, 0x00, sizeof(sWan_IP));
	NULL_TERMINATE(sWan_Mask, 0x00, sizeof(sWan_Mask));
	memset(&wan_main_array_fvp, 0, sizeof(wan_main_array_fvp));
	memset(&wan_comm_cfg, 0x00, sizeof(wan_comm_cfg));
	memset(&old_wan_cfg, 0x00, sizeof(old_wan_cfg));
	memset(&parent_iid, 0, sizeof(parent_iid));
	memset(&iid, 0, sizeof(iid));

	/*************** Prolog Block *********************/
	/* Set the flags based on operation */
	if (operation == IFX_OP_DEL) 
			flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_MOD)
			flags |= IFX_F_MODIFY;
	else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags))) {
			flags |= IFX_F_INT_ADD;
	}

	if( IFX_DONT_VALIDATE_F_NOT_SET(flags))
	{
		if (IFX_DELETE_F_NOT_SET(flags))
		{
			/* 1. Check whether the WAN_CONN_CFG is NULL, if so it's an Error!
				Also check on valid flags condition */
			IFX_VALIDATE_PTR(wan_cfg)
			IFX_VALIDATE_FLAGS(flags)
		}
	}
	
	/*************** Prolog Block Continued *********************/
	/* Determine the WAN's parent Section from the pcpeId if it is
	 * passed or from VCC otherwise (incase of WEB/CLI configuration 
	 */
	iid = wan_cfg->iid;
	sprintf(iid.cpeId.secName, "%s", TAG_WAN_MAIN);
	
	if (iid.pcpeId.Id == 0)
	{
		/* Get the parent info from the passed VCC
		 * information refering to WAN_CONN_DEV.
		 * Here it is mandatory to pass the VCC info */

		/* First get the VCC information */
		NULL_TERMINATE(wanVCC, 0x00, sizeof(wanVCC));
		sprintf(wanVCC, "%d/%d", wan_cfg->vc.pvc.vpi, wan_cfg->vc.pvc.vci);

		if (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_CONN_DEVICE, 
						"vcc", wanVCC, &ret_WANConnDevStr) != IFX_SUCCESS) {
			/* Check if the given VCC exists in WAN Connection Device Section
			   If it doesn't exist then it's an error */
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve parent cpe Id", __FUNCTION__, __LINE__);
			#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		else
		{
			/* Here we would have got the return string as wan_dev_x
			 * where 'x' denotes the device instance. Now get the cpeId
			 * for this instance 'x' */
			NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
			sprintf(conf_buf, "%s_%s", ret_WANConnDevStr, "cpeId");
			if((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_CONN_DEVICE, conf_buf, IFX_F_GET_ANY, 
							(IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Unable to retrieve parent cpe Id", __FUNCTION__, __LINE__);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			else
			{
				iid.pcpeId.Id = atoi(sValue);
				sprintf(iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);
			}
		}
	}
	else
	{
		/* Parent's cpeId is specified, fill in the parent section 
		 * which is WAN_CONN_DEVICE now */
		sprintf(iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);
		sprintf(wanVCC, "%d/%d", wan_cfg->vc.pvc.vpi, wan_cfg->vc.pvc.vci);
	}

 
	/* Update the Parent's cpeID and Section Name in piid
	 * This would be required only for ADD operation */
	parent_iid.cpeId.Id = iid.pcpeId.Id;
	sprintf(parent_iid.cpeId.secName, "%s", iid.pcpeId.secName);


	/* Determine the WAN Connection Type - WAN_IP or WAN_PPP from
	 * the link type associated with the WAN device */
	if ((wan_cfg->type == LINK_TYPE_PPPOE) ||
		(wan_cfg->type == LINK_TYPE_PPPOATM))
	{
		wan_comm_cfg = wan_cfg->WAN_PPP_CONN.WAN_CONN;
	}
	else
	{
		/* Case of UnConfigured is assumed to be WAN_IP */
		wan_comm_cfg = wan_cfg->WAN_IP_CONN.WAN_CONN;
	}

	/**************** Validation Block *****************/
	/* For Operations other than DELETE perform the following validation on input params */
	if( IFX_DONT_VALIDATE_F_NOT_SET(flags))
	{
		if (IFX_DELETE_F_NOT_SET(flags))
		{
			/* MANDATORY CHECK:
			 * Check if the wan_Connection Name is unique across WAN IP and PPP
			 * We assume that the wan_Connection Name must be unique across
			 * all connections ! */
			NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
			STRNCPY(conf_buf, wan_comm_cfg.WAN_CONN_NAME, strlen(wan_comm_cfg.WAN_CONN_NAME));

			/* Check if the wanConnName is configured, then it MUST be unique for any ADD Operation */	
			if ((strcmp(conf_buf, "")) && (IFX_INT_ADD_F_SET(flags)))
			{	
				ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_MAIN, 
								"connName", conf_buf, &ret_WANStr);
				if (ret == IFX_SUCCESS)
				{
					#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] connName = [%s] Not Unique", __FUNCTION__, __LINE__,ret_WANStr);
					#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}	
			}
			/* Check if the VCC requested is already used by ANOTHER wan connection */
			IFX_CHECK_IF_VC_IN_USE(wan_cfg, flags)
		}
	}


	/**************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_INT_ADD_F_SET(flags))
	{
		/* Form tag of parent section and get cpeId
		 * Allocate iid for Add */
		memset(&iid, 0x00, sizeof(iid));
		if (ifx_get_iid(TAG_WAN_MAIN, TAG_WAN_CONN_DEVICE, &parent_iid, 
													&iid) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to allocate IID for ADD", __FUNCTION__, __LINE__);
			#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}

		/* Check if wan_index is passed or not
		 * If not passed then get unused wan_index - for ADD */
		if (wan_cfg->wan_index <= 0)
		{
			if (ifx_get_available_distinct_index(FILE_RC_CONF, TAG_WAN_MAIN, "index", 
						MIN_WAN_INDEX, MAX_WAN_INDEX, &dist_wan_index) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] ADD: Unable to allocate wanindex", __FUNCTION__, __LINE__);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			else
				wan_cfg->wan_index = dist_wan_index;
		}
	}


	/* Update the allocated IID in WAN CONNECTION */
	wan_cfg->iid.cpeId = iid.cpeId;
	wan_cfg->iid.pcpeId = iid.pcpeId;


	/* Get WAN Index in case of modify/delete operations from CPEID */
	if((IFX_MODIFY_F_SET(flags)) ||	(IFX_DELETE_F_SET(flags)))
	{
		/* If WAN index is not specified, only then get the wan Index
		 * from cpeId, else use the wan_index passed */
		if (wan_cfg->wan_index <= 0)
		{
			IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wan_cfg->iid.cpeId, wan_index)

			/* Update the wan index in WAN CONFIG structure */
			wan_cfg->wan_index = wan_index;
		}

		/* Populate the OLD WAN Connection config structure for MODIFY*/
		old_wan_cfg.wan_index = wan_cfg->wan_index;
		old_wan_cfg.iid = wan_cfg->iid;
	 	/* Check the LinkType for the given wan_index and invoke the
		 * appropriate function */
		NULL_TERMINATE(buf, 0x00, sizeof(buf));
		NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
		sprintf(buf, "wan_%d_linkType", old_wan_cfg.wan_index);
		if((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, IFX_F_GET_ANY, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve Link Type", __FUNCTION__, __LINE__);
			#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		old_wan_cfg.type = atoi(retVal);
		
		if ((old_wan_cfg.type == WAN_LINK_TYPE_PPPOE) ||
				(old_wan_cfg.type == WAN_LINK_TYPE_PPPOATM))
		{

			if (ifx_get_wan_ppp_config(old_wan_cfg.wan_index, 
					&old_wan_cfg, IFX_F_GET_ANY) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Get PPP Configuration failed", __FUNCTION__, __LINE__);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
		else
		{
			if (ifx_get_wan_ip_config(old_wan_cfg.wan_index, 
					&old_wan_cfg, IFX_F_GET_ANY) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Get IP Configuration failed", __FUNCTION__, __LINE__);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}

		/* Get the nas interface index for the WAN Connection for EoA and PPPoE */
		if ((old_wan_cfg.type == LINK_TYPE_PPPOE) ||
			(old_wan_cfg.type == LINK_TYPE_EOATM) || 
			(old_wan_cfg.type == LINK_TYPE_IPOATM))
		{
			/* Get the nasIndx for deleting that nas index */
			sprintf(buf_ifnas, "wan_%d_iface", old_wan_cfg.wan_index);
			NULL_TERMINATE(ifnasStr, 0x00, sizeof(ifnasStr));
			if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf_ifnas, 
					IFX_F_GET_ANY, (IFX_OUT uint32 *)&outFlag, ifnasStr) != IFX_SUCCESS)
			{
				/* This cannot happen at all */
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Interface name(wan_%d_iface) not found", __FUNCTION__, __LINE__, old_wan_cfg.wan_index);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			else
			{
				char8 tmpbuf[10];
				sscanf(ifnasStr, "%03s%d", tmpbuf, &dist_nas_index);
			}
		
			/* If OLD Configuration is PPPoE/EoA/IPoA, and NEW Configuration is CLIP,
			 * then clean up the nas indexes. Add the atm Indexes */
			if (IFX_MODIFY_F_SET(flags) && (wan_cfg->type == LINK_TYPE_CLIP))
			{
				/* Manipulate nas indexes - basically delete the nas indexes*/
				if (ifx_manipulate_wan_indexs(FILE_RC_CONF, TAG_WAN_MAIN, "wan_main_nasIdx", 
						dist_nas_index,	IFX_F_DELETE) != IFX_SUCCESS)
				{
					#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] Clean up nas Index fail", __FUNCTION__, __LINE__);
					#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}

				/* Determine the new ATM index */	
				if (ifx_get_available_distinct_index(FILE_RC_CONF, TAG_WAN_IP, "atmIdx",
                    	(MIN_WAN_INDEX - 1), MAX_WAN_INDEX, &dist_atm_index) != IFX_SUCCESS)
				{
					#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] Get new ATM Index fail", __FUNCTION__, __LINE__);
					#endif
                	ret = IFX_FAILURE;
                	goto IFX_Handler;
            	}

				if (ifx_manipulate_wan_indexs(FILE_RC_CONF, TAG_WAN_IP, "wan_ip_atmIdx",
						dist_atm_index, IFX_F_INT_ADD) != IFX_SUCCESS)
				{
					#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] Manipulate wan indices Fail", __FUNCTION__, __LINE__);
					#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
				/* Update the atm interface in WANIP Section */
				sprintf(buf, "wanip_%d_ifatm=\"%s%d\"\n",wan_cfg->wan_index, "atm", dist_atm_index);
				ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_IP, flags, 1, buf);
			}
		}
		else if(old_wan_cfg.type == LINK_TYPE_CLIP)
		{
			if(wan_cfg->type != LINK_TYPE_CLIP && IFX_MODIFY_F_SET(flags))
			{
				/* Get the atmIndx for deleting that atm index */
				sprintf(buf_ifatm, "wanip_%d_ifatm", old_wan_cfg.wan_index);
				NULL_TERMINATE(ifatmStr, 0x00, sizeof(ifatmStr));
				if (ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf_ifatm, 
						IFX_F_GET_ANY, (IFX_OUT uint32 *)&outFlag, ifatmStr) != IFX_SUCCESS)
				{
					/* This cannot happen at all */
					#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] Get interface name fail", __FUNCTION__, __LINE__);
					#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
				else
				{
					char8 tmpbuf[10];
					sscanf(ifatmStr, "%03s%d", tmpbuf, &dist_atm_index);
				}
				/* Manipulate atm indexes - basically delete the atm indexes*/
				if (ifx_manipulate_wan_indexs(FILE_RC_CONF, TAG_WAN_IP, "wan_ip_atmIdx", 
						dist_atm_index,	IFX_F_DELETE) != IFX_SUCCESS)
				{
					#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] Manipulate wan indices fail", __FUNCTION__, __LINE__);
					#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}

				/* Determine the new NAS index */	
				if (ifx_get_available_distinct_index(FILE_RC_CONF, TAG_WAN_MAIN, "nasIdx",
                    	(MIN_WAN_INDEX - 1), MAX_WAN_INDEX, &dist_nas_index) != IFX_SUCCESS)
				{
					#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] Get new nas index fail", __FUNCTION__, __LINE__);
					#endif
                	ret = IFX_FAILURE;
                	goto IFX_Handler;
            	}

				if (ifx_manipulate_wan_indexs(FILE_RC_CONF, TAG_WAN_MAIN, "wan_main_nasIdx",
						dist_nas_index, IFX_F_INT_ADD) != IFX_SUCCESS)
				{
					#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] Manipulate wan indices fail", __FUNCTION__, __LINE__);
					#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}

				/* Update the nas interface in WAN MAIN Section */
				sprintf(buf, "wan_%d_iface=\"%s%d\"\n",wan_cfg->wan_index, "nas", dist_nas_index);
				ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_MAIN, flags, 1, buf);
			}
		}
	}

	/**************** Name Value Formation as per RC.CONF ********************/
	/* Form the name-value pairs for ACL Checking & Validation */
	if(IFX_DELETE_F_NOT_SET(flags))
	{
		sprintf(wan_conn_name, "%s%d", "WAN", wan_cfg->wan_index);

		if(wan_comm_cfg.WAN_CONN_DNS_OVERRIDE == IFX_DISABLED)
		{
			memset(dns_servers, 0x00, sizeof(dns_servers));
			for(i=0; i<MAX_DNS_SERVERS; i++)
			{
				strcat(dns_servers, inet_ntoa(wan_comm_cfg.dns_servers[i]));
				if(i < (MAX_DNS_SERVERS - 1))
				{
					/* check if next dns ip value is 0.0.0.0 */
					if(strcmp(inet_ntoa(wan_comm_cfg.dns_servers[i+1]), "0.0.0.0")) 
						strcat(dns_servers, ","); /* if it is not 0.0.0.0, add it to the end of the list */
					else
						break; /* if its is 0.0.0.0 break out of the loop */
				}
			}
		}

		sprintf(sWan_IP, "%s", (char8 *)inet_ntoa(wan_comm_cfg.WAN_CONN_IPADDR));
		sprintf(sWan_Mask, "%s", (char8 *)inet_ntoa(wan_comm_cfg.WAN_CONN_IPMASK));

		ifx_fill_ArrayFvp_FName(wan_main_array_fvp, 0, 23, wan_main_param_names);

		ifx_fill_ArrayFvp_intValues(wan_main_array_fvp, 0, 14, (int32 *)&wan_cfg->iid.cpeId.Id, &wan_cfg->iid.pcpeId.Id, &wan_comm_cfg.WAN_CONN_ENABLE, &wan_cfg->type, &wan_comm_cfg.WAN_CONN_AUTO_DISCONNECT_TIME, &wan_comm_cfg.WAN_CONN_IDLE_DISCONNECT_TIME, &wan_comm_cfg.WAN_CONN_WARN_DISCONNECT_TIME, &wan_comm_cfg.WAN_CONN_RSIP_AVAILABLE, &wan_comm_cfg.WAN_CONN_NAT_ENABLED, &wan_comm_cfg.WAN_CONN_DNS_ENABLED, &wan_comm_cfg.WAN_CONN_DNS_OVERRIDE, &wan_comm_cfg.WAN_CONN_MAC_ADDR_OVERRIDE, &wan_comm_cfg.WAN_CONN_TRIGGER, &wan_comm_cfg.WAN_CONN_ROUTE_PROTO_RX);

		ifx_fill_ArrayFvp_strValues(wan_main_array_fvp, 14, 7, wanVCC, sWan_IP, sWan_Mask, strcmp(wan_comm_cfg.WAN_CONN_NAME, "")?wan_comm_cfg.WAN_CONN_NAME:wan_conn_name, strcmp(wan_comm_cfg.WAN_CONF_CONN_NAME, "")?wan_comm_cfg.WAN_CONF_CONN_NAME:wan_conn_name, (wan_comm_cfg.WAN_CONN_DNS_OVERRIDE == IFX_DISABLED)?dns_servers:"0.0.0.0", strlen(wan_comm_cfg.WAN_CONN_MAC_ADDR)?wan_comm_cfg.WAN_CONN_MAC_ADDR:"");

        sprintf(wan_main_array_fvp[21].value, "%d", wan_cfg->wan_mode.mode);
        ifx_fill_ArrayFvp_intValues(wan_main_array_fvp, 22, 1, &wan_cfg->vlanId);

		temp_wanIndx = wan_cfg->wan_index;

		/* The following two fields are placed just for book keeping purpose 
		 * such as moving across WAN_IP and WAN_PPP connection and also to 
		 * to create the "atm", "nas" and "ppp" interfaces in kernel */
		if ((IFX_INT_ADD_F_SET(flags)) && (dist_nas_index < 0))
		{
			if ((wan_cfg->type != LINK_TYPE_PPPOATM) || (wan_cfg->type != LINK_TYPE_UNCONFIGURED))
			{
				if (ifx_get_available_distinct_index(FILE_RC_CONF, TAG_WAN_MAIN, "nasIdx", 
						(MIN_WAN_INDEX - 1), MAX_WAN_INDEX, &dist_nas_index) != IFX_SUCCESS)
				{
					#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] ADD: Get nas index fail", __FUNCTION__, __LINE__);
					#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
			}
		}
		else
		{
			/* For Modify/Delete operations get the "nas" index from rc.conf for
			 * link types EoA, IPoA, PPPoE */
			if ((wan_cfg->type != LINK_TYPE_PPPOATM) ||	(wan_cfg->type != LINK_TYPE_UNCONFIGURED))
			{
				NULL_TERMINATE(buf_ifnas, 0x00, sizeof(buf_ifnas));
				NULL_TERMINATE(ifnasStr, 0x00, sizeof(ifnasStr));
				MAKE_SECTION_ELEMENT_TAG(PREFIX_WAN_MAIN, temp_wanIndx, "iface", buf_ifnas);
        		if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN,
                        buf_ifnas, IFX_F_GET_ANY, (IFX_OUT uint32 *)&outFlag, ifnasStr) != IFX_SUCCESS)
				{
					#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] Modify/Delete: Get nas interface Fail", __FUNCTION__, __LINE__);
					#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
				char8 tmpbuf[10];
				sscanf(ifnasStr, "%03s%d", tmpbuf, &dist_nas_index);
			}
		}

		sprintf(wan_main_array_fvp[23].fieldname, "%s", "iface");
		sprintf(wan_main_array_fvp[24].fieldname, "%s", "ifType");
		if ((wan_cfg->type == LINK_TYPE_EOATM) ||
				(wan_cfg->type == LINK_TYPE_IPOATM) ||
				(wan_cfg->type == LINK_TYPE_PPPOE))
		{ 
			sprintf(wan_main_array_fvp[23].value, "%s%d", "nas", dist_nas_index);
			if (wan_cfg->type == LINK_TYPE_PPPOE)
			{
				sprintf(wan_main_array_fvp[24].value, "%s", "ppp");
			}
			else
			{
				sprintf(wan_main_array_fvp[24].value, "%s", "nas");
			}
		}
		else
		{
			sprintf(wan_main_array_fvp[23].value, "%s", "");
			if (wan_cfg->type == LINK_TYPE_CLIP)
				sprintf(wan_main_array_fvp[24].value, "%s", "atm");
			if (wan_cfg->type == LINK_TYPE_PPPOATM)
				sprintf(wan_main_array_fvp[24].value, "%s", "ppp");
		}
		sprintf(wan_main_array_fvp[25].fieldname, "%s", "ipv4");
		sprintf(wan_main_array_fvp[26].fieldname, "%s", "ipv6");
		sprintf(wan_main_array_fvp[27].fieldname, "%s", "dhcpv6State");
		sprintf(wan_main_array_fvp[28].fieldname, "%s", "ianaID");
		sprintf(wan_main_array_fvp[29].fieldname, "%s", "iapdID");
		sprintf(wan_main_array_fvp[30].fieldname, "%s", "slaID");
		sprintf(wan_main_array_fvp[31].fieldname, "%s", "rapid");
		sprintf(wan_main_array_fvp[32].fieldname, "%s", "tunnel");
                ifx_fill_ArrayFvp_intValues(wan_main_array_fvp, 25, 8, &wan_cfg->ipv4, &wan_cfg->ipv6, &wan_cfg->dhcp_mode, 
                     &wan_cfg->iana, &wan_cfg->iapd, &wan_cfg->slaid, &wan_cfg->rapid, &wan_cfg->tunnel); //AMS
	}

	wan_main_fvp_count = 33; 
	/* Form the fully qualified Name Value Pairs */
	if(ifx_get_conf_index_and_nv_pairs(&wan_cfg->iid, wan_cfg->wan_index, PREFIX_WAN_MAIN, 
			wan_main_fvp_count, wan_main_array_fvp, flags) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
		#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}


	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	/* Ignore the "ifnas" and "ifType" in WAN MAIN for ACL 
	 * Hence count should be (count - 2)
	 */
	CHECK_ACL_RET(wan_cfg->iid, (wan_main_fvp_count-2), wan_main_array_fvp,
					wan_main_changed_fcount, wan_main_changed_array_fvp, flags, IFX_Handler)

	/********* System Config File Update Block  **********/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	memset(buf, 0x00, sizeof(buf));
	form_cfgdb_buf(buf, wan_main_fvp_count, wan_main_array_fvp);

	/* Backup rc.conf before proceeding with configuration */
	ret = IFX_SUCCESS;
	if (operation == IFX_OP_ADD)
	{
		if(IFX_DONT_VALIDATE_F_NOT_SET(flags) && (IFX_DONT_ACTIVATE_F_NOT_SET(flags) || IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) && IFX_DEACTIVATE_F_NOT_SET(flags) && IFX_INCOMPLETE_F_NOT_SET(flags))
		{
			if(get_pcr_val_for_vcc(wanVCC, &pcr_val) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Failed to get QoS parameters for vcc [%s] !!",
					__FUNCTION__, __LINE__, wanVCC);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			if(get_qos_mode_for_vcc(wanVCC, &qos_mode) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Failed to get QoS parameters for vcc [%s] !!",
					__FUNCTION__, __LINE__, sValue);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			if(ifx_check_for_available_bandwidth(wan_cfg->iid, pcr_val, qos_mode) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Requested PCR [%d] exceeds Max. Upstream Bandwidth !!",
					__FUNCTION__, __LINE__, pcr_val);
				#endif
				ret = IFX_PCR_CHK_FAIL;
				goto IFX_Handler;
			}
		}

		ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_MAIN, flags, 1, buf);
		if(ret != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Set Data in rc.conf Fail", __FUNCTION__, __LINE__);
			#endif
			goto IFX_Handler;
		}

		wan_comm_cfg.WAN_CONN_IID = wan_cfg->iid;

		if ((wan_cfg->type == LINK_TYPE_PPPOE) || (wan_cfg->type == LINK_TYPE_PPPOATM))
		{
			/* Invoke the WAN PPP Configuration function */
			strcpy(wan_comm_cfg.WAN_CONN_IID.cpeId.secName, TAG_WAN_PPP);
			/* Pramod - need to fill IID inside PPP structure also */
			wan_cfg->WAN_PPP_CONN.WAN_CONN.WAN_CONN_IID = wan_comm_cfg.WAN_CONN_IID; 
																							
			if ((ret = ifx_set_wan_ppp_config(operation, wan_cfg->wan_index, &wan_cfg->WAN_PPP_CONN,
									(flags | IFX_F_DONT_CHECKPOINT))) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Set WAN PPP Fail", __FUNCTION__, __LINE__);
				#endif
				goto IFX_Handler;
			}

			/* Copy the tr69id field from ip connection tr69id, because the tr69id allocation will happen in ip set api */
			if(wan_cfg->iid.config_owner == IFX_WEB)
			{
				STRNCPY(wan_comm_cfg.WAN_CONN_IID.tr69Id, wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IID.tr69Id, 
							strlen(wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IID.tr69Id));
			}
		}
		else if ((wan_cfg->type == LINK_TYPE_EOATM) ||
					(wan_cfg->type == LINK_TYPE_IPOATM) ||
					(wan_cfg->type == LINK_TYPE_CLIP))
		{
			/* Invoke the WAN IP Configuration function 
			 * Update the WAN_COMMON_CFG IID structure value from WAN_CONN_CFG IID 
			 * Update the CPEID to WAN_IP Section
			 */
			strcpy(wan_comm_cfg.WAN_CONN_IID.cpeId.secName, TAG_WAN_IP);
			/* Pramod - need to fill IID inside IP structure also */
			wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IID = wan_comm_cfg.WAN_CONN_IID; 

			if ((ret = ifx_set_wan_ip_config(operation, wan_cfg->wan_index,
						&wan_cfg->WAN_IP_CONN, (flags | IFX_F_DONT_CHECKPOINT)))
						!= IFX_SUCCESS)
			{
				/* ??? Will this flags ORING Required ??? */
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Set WAN IP Fail", __FUNCTION__, __LINE__);
				#endif
				goto IFX_Handler;
			}

			/* Copy the tr69id field from ip connection tr69id, because the tr69id allocation will happen in ip set api */
			if(wan_cfg->iid.config_owner == IFX_WEB)
			{
				STRNCPY(wan_comm_cfg.WAN_CONN_IID.tr69Id, wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IID.tr69Id, 
							strlen(wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IID.tr69Id));
			}
		}
	}
	else if (operation == IFX_OP_MOD)
	{

		if(IFX_DONT_VALIDATE_F_NOT_SET(flags) && (IFX_DONT_ACTIVATE_F_NOT_SET(flags) || IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) && IFX_DEACTIVATE_F_NOT_SET(flags) && IFX_INCOMPLETE_F_NOT_SET(flags))
		{
			if(get_pcr_val_for_vcc(wanVCC, &pcr_val) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Failed to get QoS parameters for vcc [%s] !!",
					__FUNCTION__, __LINE__, buf);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			if(get_qos_mode_for_vcc(wanVCC, &qos_mode) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Failed to get QoS parameters for vcc [%s] !!",
					__FUNCTION__, __LINE__, buf);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			if(ifx_check_for_available_bandwidth(wan_cfg->iid, pcr_val, qos_mode) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Requested PCR [%d] exceeds Max. Upstream Bandwidth !!",
					__FUNCTION__, __LINE__, pcr_val);
				#endif
				ret = IFX_PCR_CHK_FAIL;
				goto IFX_Handler;
			}
		}

		if ((old_wan_cfg.type == LINK_TYPE_PPPOE) || (old_wan_cfg.type == LINK_TYPE_PPPOATM))
		{
			/* Invoke the WAN PPP Configuration function */
			old_wan_cfg.WAN_PPP_CONN.WAN_CONN.WAN_CONN_IID = old_wan_cfg.iid;
			strcpy(old_wan_cfg.WAN_PPP_CONN.WAN_CONN.WAN_CONN_IID.cpeId.secName, TAG_WAN_PPP);

			/* check the state of this object, if enabled then only call the api to stop with the current config */
			sprintf(conf_buf, "%s_%d_cpeId", PREFIX_WAN_PPP, old_wan_cfg.wan_index);
			if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP,
					conf_buf, IFX_F_GET_ENA, (IFX_OUT uint32 *)&outFlag, sValue) == IFX_SUCCESS)
			{
				if ((ret = ifx_set_wan_ppp_config(operation, old_wan_cfg.wan_index, &old_wan_cfg.WAN_PPP_CONN,
									(flags | IFX_F_DEACTIVATE | IFX_F_DONT_VALIDATE))) != IFX_SUCCESS)
				{
					#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] Set WAN PPP Config Fail", __FUNCTION__, __LINE__);
					#endif
					goto IFX_Handler;
				}
			}
		}
		else if ((old_wan_cfg.type == LINK_TYPE_EOATM) ||
					(old_wan_cfg.type == LINK_TYPE_IPOATM) ||
					(old_wan_cfg.type == LINK_TYPE_CLIP))
		{
			/* Invoke the WAN IP Configuration function 
			 * Update the WAN_COMMON_CFG IID structure value from WAN_CONN_CFG IID 
			 * Update the CPEID to WAN_IP Section
			 */
			old_wan_cfg.WAN_IP_CONN.WAN_CONN.WAN_CONN_IID = old_wan_cfg.iid;
			strcpy(old_wan_cfg.WAN_IP_CONN.WAN_CONN.WAN_CONN_IID.cpeId.secName, TAG_WAN_IP);

			/* check the state of this object, if enabled then only call the api to stop with the current config */
			sprintf(conf_buf, "%s_%d_cpeId", PREFIX_WAN_IP, old_wan_cfg.wan_index);
			if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP,
					conf_buf, IFX_F_GET_ENA, (IFX_OUT uint32 *)&outFlag, sValue) == IFX_SUCCESS)
			{
				if ((ret = ifx_set_wan_ip_config(operation, old_wan_cfg.wan_index,
				&old_wan_cfg.WAN_IP_CONN, (flags | IFX_F_DEACTIVATE | IFX_F_DONT_VALIDATE)))
				!= IFX_SUCCESS)
				{
					#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] Set WAN IP Fail", __FUNCTION__, __LINE__);
					#endif
					goto IFX_Handler;
				}
			}
		}

		/* Now update rc.conf with the new configuration */
		ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_MAIN, flags, 1, buf);
		if(ret != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Set Data in rc.conf Fail", __FUNCTION__, __LINE__);
			#endif
			goto IFX_Handler;
		}

		wan_comm_cfg.WAN_CONN_IID = wan_cfg->iid;

		if ((wan_cfg->type == LINK_TYPE_PPPOE) || (wan_cfg->type == LINK_TYPE_PPPOATM))
		{
			/* Invoke the WAN PPP Configuration function */
			strcpy(wan_comm_cfg.WAN_CONN_IID.cpeId.secName, TAG_WAN_PPP);
			/* Pramod - need to fill IID inside	PPP structure also */
			wan_cfg->WAN_PPP_CONN.WAN_CONN.WAN_CONN_IID = wan_comm_cfg.WAN_CONN_IID; 

			if ((ret = ifx_set_wan_ppp_config(operation, wan_cfg->wan_index, &wan_cfg->WAN_PPP_CONN,
									(flags | IFX_F_MODIFY))) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Set WAN PPP Config Fail", __FUNCTION__, __LINE__);
				#endif
				goto IFX_Handler;
			}
		}
		else if ((wan_cfg->type == LINK_TYPE_EOATM) ||
					(wan_cfg->type == LINK_TYPE_IPOATM) ||
					(wan_cfg->type == LINK_TYPE_CLIP))
		{
			/* Activate with the new configuration */
			strcpy(wan_comm_cfg.WAN_CONN_IID.cpeId.secName, TAG_WAN_IP);
			/* Pramod - need to fill IID inside IP structure also */
			wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IID = wan_comm_cfg.WAN_CONN_IID; 
																						
			if ((ret = ifx_set_wan_ip_config(operation, wan_cfg->wan_index, &wan_cfg->WAN_IP_CONN,
									(flags | IFX_F_MODIFY))) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Set WAN IP Config Fail", __FUNCTION__, __LINE__);
				#endif
				goto IFX_Handler;
			}
		}
	}
	else
	{
		/* Case of Delete - so first remove the entry from wan_ip/wan_ppp section
		 * then update the wan_main section in rc.conf */
		wan_comm_cfg.WAN_CONN_IID = wan_cfg->iid;
		if ((wan_cfg->type == LINK_TYPE_PPPOE) || (wan_cfg->type == LINK_TYPE_PPPOATM))
		{
			/* Invoke the WAN PPP Configuration function */
			strcpy(wan_comm_cfg.WAN_CONN_IID.cpeId.secName, TAG_WAN_PPP);
			wan_cfg->WAN_PPP_CONN.WAN_CONN.WAN_CONN_IID = wan_comm_cfg.WAN_CONN_IID; /* Pramod - need to fill IID inside
																						PPP structure also */
			if ((ret = ifx_set_wan_ppp_config(operation, wan_cfg->wan_index, &wan_cfg->WAN_PPP_CONN,
									(flags | IFX_F_DELETE))) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Set WAN PPP Config Fail", __FUNCTION__, __LINE__);
				#endif
				goto IFX_Handler;
			}
		}
		else if ((wan_cfg->type == LINK_TYPE_EOATM) ||
					(wan_cfg->type == LINK_TYPE_IPOATM) ||
					(wan_cfg->type == LINK_TYPE_CLIP))
		{
			/* Invoke the WAN IP Configuration function 
			 * Update the WAN_COMMON_CFG IID structure value from WAN_CONN_CFG IID 
			 * Update the CPEID to WAN_IP Section
			 */
			strcpy(wan_comm_cfg.WAN_CONN_IID.cpeId.secName, TAG_WAN_IP);
			wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IID = wan_comm_cfg.WAN_CONN_IID; /* Pramod - need to fill IID inside
																						IP structure also */
			if ((ret = ifx_set_wan_ip_config(operation, wan_cfg->wan_index, &wan_cfg->WAN_IP_CONN,
									(flags | IFX_F_DELETE))) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Set WAN IP Config Fail", __FUNCTION__, __LINE__);
				#endif
				goto IFX_Handler;
			}
		}

		/* Now update rc.conf with the new configuration */
		ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_MAIN, flags, 1, buf);
		if(ret != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Set Data in rc.conf Fail", __FUNCTION__, __LINE__);
			#endif
			goto IFX_Handler;
		}
	}

	/* Update the TR69 ID obtained above to reflect in the Mappings for WAN MAIN */
	STRNCPY(wan_cfg->iid.tr69Id, wan_comm_cfg.WAN_CONN_IID.tr69Id, 
				strlen(wan_comm_cfg.WAN_CONN_IID.tr69Id));


	/* Update the LinkType in VCChannel Section if config owner is WEB
	 * In case of WEB, we will be creating the VCC before creation of WAN
	 * Connection. So we wouldn't be knowing the LinkType of the VCC. This
	 * will be known only from the WAN IP or WAN PPP Connections */
 
	if ((IFX_DELETE_F_NOT_SET(flags)) && (wan_cfg->iid.config_owner == IFX_WEB))
	{
		if((ret = ifx_set_vcc_link_type(&wan_cfg->vc, wan_cfg->type, IFX_F_MODIFY)) != IFX_SUCCESS)
		{
			/* Here we need to put in ACL & Notification inside this function
			 * But if ACL prevents this modfication - how to revert back ??
			 */
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Update Link Type Fail", __FUNCTION__, __LINE__);
			#endif
			goto IFX_Handler;
		}
	}


	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions 
	 * This would have been done from the WANIP or WANPPP calls */


    /*********** Notification Block *************/
    /* Notify the Internal TR69 Stack in case of MODIFY 
	 * This Notification would only be for WAN MAIN params */
    if(IFX_MODIFY_F_SET(flags))
	{
		/* Notification for WAN MAIN mappings */
        CHECK_N_SEND_NOTIFICATION(wan_cfg->iid, wan_main_changed_fcount, 
						wan_main_changed_array_fvp, flags, IFX_Handler)
	}
	else if (IFX_INT_ADD_F_SET(flags))
	{
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
        UPDATE_ID_MAP_N_ATTRIBUTES(&wan_cfg->iid, wan_main_fvp_count, 
						wan_main_array_fvp, flags, IFX_Handler)
		
		/* Update the "WAN" Index in WAN_MAIN Section */
		if (ifx_manipulate_wan_indexs(FILE_RC_CONF, TAG_WAN_MAIN, "wan_main_index", 
							wan_cfg->wan_index,	IFX_F_INT_ADD) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Update wan index Fail", __FUNCTION__, __LINE__);
			#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}

		/* Update the "nas" Index in WAN_MAIN Section if 
		 * linkType is EoA, IPoA, PPPoE */
		if ((wan_cfg->type != LINK_TYPE_PPPOATM) &&
			(wan_cfg->type != LINK_TYPE_UNCONFIGURED) &&
			(wan_cfg->type != LINK_TYPE_CLIP))
		{
			if (ifx_manipulate_wan_indexs(FILE_RC_CONF, TAG_WAN_MAIN, "wan_main_nasIdx", 
					dist_nas_index,	IFX_F_INT_ADD) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Update nas Index Fail", __FUNCTION__, __LINE__);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
		/* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WAN_MAIN); 
	}
	else if (IFX_DELETE_F_SET(flags))
	{
		/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
        UPDATE_ID_MAP_N_ATTRIBUTES(&wan_cfg->iid, wan_main_fvp_count, 
						wan_main_array_fvp, flags, IFX_Handler)

		/* Delete the "WAN" Index in WAN_MAIN Section */
		if (ifx_manipulate_wan_indexs(FILE_RC_CONF, TAG_WAN_MAIN, "wan_main_index", 
							wan_cfg->wan_index,	IFX_F_DELETE) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Update nas Index Fail", __FUNCTION__, __LINE__);
			#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}

		/* Delete the "nas" Index in WAN_MAIN Section if linkType
		 * is EoA, IPoA, PPPoE */
		if ((wan_cfg->type != LINK_TYPE_PPPOATM) &&
			(wan_cfg->type != LINK_TYPE_UNCONFIGURED) &&
			(wan_cfg->type != LINK_TYPE_CLIP))
		{
			if (ifx_manipulate_wan_indexs(FILE_RC_CONF, TAG_WAN_MAIN, "wan_main_nasIdx", 
					dist_nas_index,	IFX_F_DELETE) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Update wan Index Fail", __FUNCTION__, __LINE__);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
	}

    /* Updating Persistent Storage */
    ret = ifx_config_write(FILE_RC_CONF, flags);
    if(ret != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Update persistent storage fail", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
    }

IFX_Handler:
	IFX_MEM_FREE(ret_WANStr)
	IFX_MEM_FREE(ret_WANConnDevStr)
	IFX_MEM_FREE(wan_main_changed_array_fvp)
	if (ret != IFX_SUCCESS)
	{
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_wan_ip_config(...)
*		operation	==> 	specifies the operation to be done such as ADD, DELETE or MODIFY
*		wan_index	==>		specifies the wan index of the wan connection to be configured
*		wan_ip_cfg	==>		pointer to WAN_IP_CONFIG structure which will store the ip connection specific parameters
*       flags       ==>  	flags that define the behaviour
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
        Description:
				The api adds, deletes or modifies wan ip connection. the api will store the wan ip connection specific
				parameters for the wan connection specified by wan_index. if the operation is modify the api will call
				service stop on the wan_index, modify the ip parameters and call service start on the same wan_index.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_wan_ip_config(int32 operation, int32 wan_index,
					WAN_IP_CONFIG *wan_ip_cfg, uint32 flags)
{
    char8 buf[MAX_DATA_LEN];
    char8 linkTypeStr[30];
    char8 conf_buf[MAX_FILELINE_LEN];
    char8 ifatmStr[10];
    int32 ret = IFX_SUCCESS;
    IFX_NAME_VALUE_PAIR wan_ip_array_fvp[9];
    uint32 wan_ip_fvp_count = 0;
    IFX_NAME_VALUE_PAIR *wanip_changed_array_fvp = NULL;
    uint32 wanip_changed_fvp_count = 0, outFlag = IFX_F_DEFAULT;
    int32 dist_atm_index = -1;
    char8 sCommand[MAX_FILELINE_LEN];

    NULL_TERMINATE(linkTypeStr, 0, sizeof(linkTypeStr));
    NULL_TERMINATE(buf, 0, sizeof(buf));
    NULL_TERMINATE(sCommand, 0, sizeof(sCommand));
    memset(wan_ip_array_fvp, 0, sizeof(wan_ip_array_fvp));

	/* Validate the ipAddrType against the ipAddress, ipMask and ipGateway fields
	 * These fields are settable only if AddrType is STATIC
	 */
	if (IFX_DONT_VALIDATE_F_NOT_SET(flags))
	{
		if (IFX_DELETE_F_NOT_SET(flags))
		{
			if (wan_ip_cfg->addr_type != IP_TYPE_STATIC)
			{
				/* Check the values of IP Address, Mask and Gateway
				 * If these fields are non-zero then it's an Error!
				 */
				if ((wan_ip_cfg->WAN_CONN.WAN_CONN_IPADDR.s_addr != INADDR_ANY) ||
						(wan_ip_cfg->WAN_CONN.WAN_CONN_IPMASK.s_addr != INADDR_ANY) ||
						(wan_ip_cfg->ip_gw.s_addr != INADDR_ANY))
				{
					#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] IP address/mask/Gateway Non-Zero", __FUNCTION__, __LINE__);
					#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
			}
		}
	}

	/* IID Allocation Block */
	if (IFX_INT_ADD_F_SET(flags))
	{
		/* Get the IID values from WAN_CONN_CFG - where the parent section 
		 * would be that of WAN_MAIN and cpeID that of WAN_MAIN 
		 * This is a deviation from other devices */

		/* The index used for WAN_IP Section is also derived from
		 * WAN_MAIN Section */		
		/* Alloc TR69 ID for this instance of WAN IP Connection */
		IFX_ALLOC_TR69ID(wan_ip_cfg->WAN_CONN.WAN_CONN_IID, "addrType", IFX_Handler);
	}

	/* Determine the linkType of this connection */
	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
	NULL_TERMINATE(linkTypeStr, 0x00, sizeof(linkTypeStr));
	MAKE_SECTION_ELEMENT_TAG(PREFIX_WAN_MAIN, wan_index, "linkType", conf_buf);
	if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN,
			conf_buf, IFX_F_GET_ANY, &outFlag, linkTypeStr) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Get Link Type from rc.conf Fail", __FUNCTION__, __LINE__);
		#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* The following fields will be used only for book keeping */
	
	/* For linkType CLIP, determine the operation is ADD/DELETE/MODIFY
	 * For ADD operation get a new atm interface index. For DELETE/MODIFY
	 * operations, get the already existing atm interface index 
	 */
	if (atoi(linkTypeStr) == LINK_TYPE_CLIP)
	{
		if (IFX_INT_ADD_F_SET(flags))
		{
			if (ifx_get_available_distinct_index(FILE_RC_CONF, TAG_WAN_IP, "atmIdx", 
					(MIN_WAN_INDEX - 1), MAX_WAN_INDEX, &dist_atm_index) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] ADD: Get new atm index fail", __FUNCTION__, __LINE__);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
		else
		{
		   /* For Modify/Delete operations get the "atm" index from rc.conf	*/
			NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
			NULL_TERMINATE(ifatmStr, 0x00, sizeof(ifatmStr));
			MAKE_SECTION_ELEMENT_TAG(PREFIX_WAN_IP, wan_index, "ifatm", conf_buf);
			if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP,
					conf_buf, IFX_F_GET_ANY, &outFlag, ifatmStr) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] DEL/MOD: Get atm index Fail", __FUNCTION__, __LINE__);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			char8 tmpbuf[10];
			sscanf(ifatmStr, "%03s%d", tmpbuf, &dist_atm_index);
		}
	}

	/* Form the name-value pairs for ACL Checking & Validation */
	if(IFX_DELETE_F_NOT_SET(flags))
	{
		ifx_fill_ArrayFvp_FName(wan_ip_array_fvp, 0, 8, wan_ip_param_names);

		if(!wan_ip_cfg->max_mtu)
			wan_ip_cfg->max_mtu = DEFAULT_MAX_MTU;

		ifx_fill_ArrayFvp_intValues(wan_ip_array_fvp, 0, 6, (int32 *)&wan_ip_cfg->WAN_CONN.WAN_CONN_IID.cpeId.Id, &wan_ip_cfg->WAN_CONN.WAN_CONN_IID.pcpeId.Id, &wan_ip_cfg->conn_status, &wan_ip_cfg->conn_type, &wan_ip_cfg->addr_type, &wan_ip_cfg->max_mtu, &wan_ip_cfg->max_mtu);

		sprintf(wan_ip_array_fvp[6].value, "%s", inet_ntoa(wan_ip_cfg->ip_gw));

		if (atoi(linkTypeStr) == LINK_TYPE_CLIP)
		{
			sprintf(wan_ip_array_fvp[7].value, "%s%d", "atm", dist_atm_index);
		}
		else
		{
			sprintf(wan_ip_array_fvp[7].value, "%s", "");
		}
	}

	wan_ip_fvp_count = 8; 
	/* Form the fully qualified Name Value Pairs */
	if(ifx_get_conf_index_and_nv_pairs(&wan_ip_cfg->WAN_CONN.WAN_CONN_IID, wan_index, PREFIX_WAN_IP,
							wan_ip_fvp_count, wan_ip_array_fvp, flags) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
		#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}


	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	/* Ignore the "ifatm" in WAN IP for ACL 
	 * Hence count should be (count - 1)
	 */
	CHECK_ACL_RET(wan_ip_cfg->WAN_CONN.WAN_CONN_IID, (wan_ip_fvp_count-1), wan_ip_array_fvp,
				wanip_changed_fvp_count, wanip_changed_array_fvp, flags, IFX_Handler)


	/********* System Config File Update Block  **********/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	form_cfgdb_buf(buf, wan_ip_fvp_count, wan_ip_array_fvp);

	/* For MODIFY/DELETE operations, first we need to stop the running configuration
	 * with the CheckPointed file in WAN MAIN.
	 * Restore the CHECKPOINTED FILE in WAN MAIN to RC.CONF in order to stop service
	 */
	if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) && IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags))
	{
		/* Subramani - 19/08/2009 */
		/* We need to stop the ripd - To fix unregister_netdevice */
		sprintf(sCommand, "%s", SERVICE_RIPD_STOP);
		ret = system(sCommand);
		ret = IFX_SUCCESS;

		if(IFX_INT_ADD_F_NOT_SET(flags))
		{
			/* Case of MODIFY & DELETE */
			/* Stop the Sevice with Checkpointed file in WAN MAIN */
			/* First get the CheckPointed file to rc.conf */
			#ifdef NOT_REQUIRED_FOR_ZERO_DOT_FIVE
			ifx_config_write(CHKPOINT_FILE, IFX_F_DEFAULT);
			#endif
		
			sprintf(sCommand,"%s %d", SERVICE_WAN_STOP, wan_index);
			ret = system(sCommand);
			ret = IFX_SUCCESS;
		}
		if(ret != IFX_SUCCESS)
		{
			/* ??? What do we need to do if some services Stopped while others
			 * are still running ? Do we need to start the services again
			 * with the Check-Pointed file ?
			 * ??? */
			/* For now we just goto the IFX_Handler and return IFX_FAILURE */
			 goto IFX_Handler;	
		}
	}
	
	/* Here there is no Backup of rc.conf required as we have done backup at WAN MAIN 
	 * Directly call SetCfgData function to update the system cofiguration in rc.conf */
	ret = IFX_SUCCESS;
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_IP, flags, 1, buf);
	if(ret != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Set Data in rc.conf Fail", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}

	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) && IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags))
	{
		/* We need to invoke the scripts to bringup WAN interface. 
		 * ??? What do we need to do if some services Started while others
		 * are stopped ? Do we need to stop the services again
		 * with the Check-Pointed file ?
		 * ??? */

		/* For now we ignore all the stopped services and start
		 * services again */
		if (IFX_DELETE_F_NOT_SET(flags) && (IFX_DEACTIVATE_F_NOT_SET(flags)))
		{
			/* Just bring up this WAN interface for ADD/MODIFY-ENABLE cases */
			sprintf(sCommand,"%s %d",SERVICE_WAN_START, wan_index);
			ret = system(sCommand);
			ret = IFX_SUCCESS;
		}
		
		/* Call for RIPd service restart - which handles the interface level
		 * RIP enable/disable */

		/* Subramani - 19/08/2009 */
		/* We need to start the ripd not restart - To fix unregister_netdevice issue */
		sprintf(sCommand, "%s %d", SERVICE_RIPD_START, wan_index);
		ret = system(sCommand);
		ret = IFX_SUCCESS;

		if(ret != IFX_SUCCESS)
		{
			/* Bringup WAN interface script failed!
			 * Do a Rollback with CHKPOINT_FILE2 and stop the service
			 */
			/** FIX ME: 
			 * Currently we have an issue with WAN BRINGUP
			 * WAN BRING UP calls several other scripts and it's
			 * difficult to track all those services in order to stop 
			 *
			 ROLLBACK_DEV_RST_RET(NULL, "Device Configuration error", 
			 CHKPOINT_FILE2, CHKPOINT_FILE, NULL, IFX_Handler)
			 */

			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
			#endif
			goto IFX_Handler;
		}
	}


	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if(IFX_MODIFY_F_SET(flags))
	{
		CHECK_N_SEND_NOTIFICATION(wan_ip_cfg->WAN_CONN.WAN_CONN_IID, wanip_changed_fvp_count, 
			wanip_changed_array_fvp, flags, IFX_Handler)
	}
	else if (IFX_INT_ADD_F_SET(flags))
	{
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
		UPDATE_ID_MAP_N_ATTRIBUTES(&wan_ip_cfg->WAN_CONN.WAN_CONN_IID, wan_ip_fvp_count, 
						wan_ip_array_fvp, flags, IFX_Handler)

		CHECK_N_SEND_NOTIFICATION(wan_ip_cfg->WAN_CONN.WAN_CONN_IID, wan_ip_fvp_count, 
			wan_ip_array_fvp, flags, IFX_Handler)

		/* Update the "atm" Index in WAN_IP Section */
		if (atoi(linkTypeStr) == LINK_TYPE_CLIP)
		{
			if (ifx_manipulate_wan_indexs(FILE_RC_CONF, TAG_WAN_IP, "wan_ip_atmIdx", 
					dist_atm_index,	IFX_F_INT_ADD) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] update atm index in WAN IP section Fail", __FUNCTION__, __LINE__);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
	}
	else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
		CHECK_N_SEND_NOTIFICATION(wan_ip_cfg->WAN_CONN.WAN_CONN_IID, wan_ip_fvp_count, 
			wan_ip_array_fvp, flags, IFX_Handler)
		UPDATE_ID_MAP_N_ATTRIBUTES(&wan_ip_cfg->WAN_CONN.WAN_CONN_IID, wan_ip_fvp_count, 
						wan_ip_array_fvp, flags, IFX_Handler)

		/* Delete the "atm" Index in WAN_IP Section if linkType is CLIP */
		if (atoi(linkTypeStr) == LINK_TYPE_CLIP)
		{
			if (ifx_manipulate_wan_indexs(FILE_RC_CONF, TAG_WAN_IP, "wan_ip_atmIdx",
					dist_atm_index,	IFX_F_DELETE) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Delete atm index Fail", __FUNCTION__, __LINE__);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
	}

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if(ret != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Update Persistent Storage Fail", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}


IFX_Handler:
	IFX_MEM_FREE(wanip_changed_array_fvp)
	if (ret != IFX_SUCCESS)
	{
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return IFX_FAILURE;
	}
	else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_wan_ppp_config(...)
*		operation	==> 	specifies the operation to be done such as ADD, DELETE or MODIFY
*		wan_index	==>		specifies the wan index of the wan connection to be configured
*		wan_ppp_cfg	==>		pointer to WAN_PPP_CONFIG structure which will store the ppp connection specific parameters
*       flags       ==>  	flags that define the behaviour
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
        Description:
				The api adds, deletes or modifies wan ppp connection. the api will store the wan ppp connection specific
				parameters for the wan connection specified by wan_index. if the operation is modify the api will call
				service stop on the wan_index, modify the ppp parameters and call service start on the same wan_index.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_wan_ppp_config(int32 operation, int32 wan_index,
					WAN_PPP_CONFIG *wan_ppp_cfg, uint32 flags)
{
	char8 buf[MAX_DATA_LEN];
	char8 conf_buf[MAX_FILELINE_LEN];
	char8 linkTypeStr[10];
	char8 ifpppStr[10];
	int32 ret = IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR wan_ppp_array_fvp[17];
    uint32 wan_ppp_fvp_count = 0;
	IFX_NAME_VALUE_PAIR *wan_ppp_changed_array_fvp = NULL;
	uint32 wan_ppp_changed_fvp_count = 0, outFlag = IFX_F_DEFAULT;
	int32 dist_ppp_index = -1;
    char8 sCommand[MAX_FILELINE_LEN];

    NULL_TERMINATE(linkTypeStr, 0, sizeof(linkTypeStr));
    NULL_TERMINATE(sCommand, 0, sizeof(sCommand));

    memset(wan_ppp_array_fvp, 0, sizeof(wan_ppp_array_fvp));

	/* Any Validation identified as required needs to go in here */
	if (IFX_DONT_VALIDATE_F_NOT_SET(flags))
	{
		if (IFX_DELETE_F_NOT_SET(flags))
		{
			/* PPP UserName cannot be NULL */
			if (strlen(wan_ppp_cfg->ppp_user_name) == 0)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] PPP Username NULL", __FUNCTION__, __LINE__);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
	}


	/* IID Allocation Block */
	if (IFX_INT_ADD_F_SET(flags))
	{
		/* Get the IID values from WAN_CONN_CFG - where the parent section 
		 * would be that of WAN_MAIN and cpeID that of WAN_MAIN 
		 * This is a deviation from other devices */

		/* The index used for WAN_PPP Section is also derived from
		 * WAN_MAIN Section */		
		/* Alloc TR69 ID for this instance of WAN PPP Connection */
		IFX_ALLOC_TR69ID(wan_ppp_cfg->WAN_CONN.WAN_CONN_IID, "encrProto", IFX_Handler);
	}

	/* Determine the linkType of this connection */
	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
	NULL_TERMINATE(linkTypeStr, 0x00, sizeof(linkTypeStr));
	MAKE_SECTION_ELEMENT_TAG(PREFIX_WAN_MAIN, wan_index, "linkType", conf_buf);
	if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN,
			conf_buf, IFX_F_GET_ANY, &outFlag, linkTypeStr) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("In [%s] : Unable to determine the LinkType for this Connection for [%d] (query [%s] in [%s] !!\n", 
						__FUNCTION__, wan_index, conf_buf, FILE_RC_CONF);
		#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}


	/* The following fields will be used only for book keeping */
	/* Determine the ppp index to be used with operation */
	if(IFX_INT_ADD_F_SET(flags))
	{
		if (ifx_get_available_distinct_index(FILE_RC_CONF, TAG_WAN_PPP, "pppIdx", 
				(MIN_WAN_INDEX - 1), MAX_WAN_INDEX, &dist_ppp_index) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("Unable to determine the PPP index\n");
			#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}
	else
	{
	   /* For Modify/Delete operations get the "ppp" index from rc.conf	*/
		NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
		NULL_TERMINATE(ifpppStr, 0x00, sizeof(ifpppStr));
		MAKE_SECTION_ELEMENT_TAG(PREFIX_WAN_PPP, wan_index, "ifppp", conf_buf);
		if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP,
				conf_buf, IFX_F_GET_ANY, &outFlag, ifpppStr) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Modify/Delete: Get ppp index Fail", __FUNCTION__, __LINE__);
			#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		char8 tmpbuf[10];
		sscanf(ifpppStr, "%03s%d", tmpbuf, &dist_ppp_index);
	}

	/* Form the name-value pairs for ACL Checking & Validation */
	if(IFX_DELETE_F_NOT_SET(flags))
	{
		ifx_fill_ArrayFvp_FName(wan_ppp_array_fvp, 0, 16, wan_ppp_param_names);

		/* PPP Encryption, Compression, Authentication Protocols */
		/* LCP Echo intervals */
		/* PPPoE Access Concentrator, Service Name Configuration */

		ifx_fill_ArrayFvp_intValues(wan_ppp_array_fvp, 0, 11, (int32 *)&wan_ppp_cfg->WAN_CONN.WAN_CONN_IID.cpeId.Id, &wan_ppp_cfg->WAN_CONN.WAN_CONN_IID.pcpeId.Id, &wan_ppp_cfg->conn_type, &wan_ppp_cfg->encr_proto, &wan_ppp_cfg->compr_proto, &wan_ppp_cfg->auth_proto, &wan_ppp_cfg->max_mru_size, &wan_ppp_cfg->ppp_lcp_echo_period, &wan_ppp_cfg->ppp_lcp_echo_retry, &wan_ppp_cfg->max_mtu, &wan_ppp_cfg->bridge_enable);

		/* PPP Username & Password */
		ifx_fill_ArrayFvp_strValues(wan_ppp_array_fvp, 11, 4, (strlen(wan_ppp_cfg->pppoe_ac_name))?wan_ppp_cfg->pppoe_ac_name:"", (strlen(wan_ppp_cfg->pppoe_service_name))?wan_ppp_cfg->pppoe_service_name:"", wan_ppp_cfg->ppp_user_name, wan_ppp_cfg->ppp_user_passwd);

		sprintf(wan_ppp_array_fvp[15].value, "%s%d", "ppp", dist_ppp_index);
	}

	wan_ppp_fvp_count = 16; 
	/* Form the fully qualified Name Value Pairs */
	if(ifx_get_conf_index_and_nv_pairs(&wan_ppp_cfg->WAN_CONN.WAN_CONN_IID, wan_index, PREFIX_WAN_PPP,
							wan_ppp_fvp_count, wan_ppp_array_fvp, flags) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
		#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	/* Ignore the "ifppp" in WAN IP for ACL 
	 * Hence count should be (count - 1) */
	CHECK_ACL_RET(wan_ppp_cfg->WAN_CONN.WAN_CONN_IID, (wan_ppp_fvp_count-1), wan_ppp_array_fvp,
				wan_ppp_changed_fvp_count, wan_ppp_changed_array_fvp, flags, IFX_Handler)

	/********* System Config File Update Block  **********/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	form_cfgdb_buf(buf, wan_ppp_fvp_count, wan_ppp_array_fvp);

	/* For MODIFY/DELETE operations, first we need to stop the running configuration
	 * with the CheckPointed file in WAN MAIN.
	 * Restore the CHECKPOINTED FILE in WAN MAIN to RC.CONF in order to stop service
	 */
	if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) && IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags))
	{
		/* Subramani - 19/08/2009 */
		/* We need to stop the ripd - To fix unregister_netdevice */
		sprintf(sCommand, "%s", SERVICE_RIPD_STOP);
		ret = system(sCommand);
		ret = IFX_SUCCESS;

		if (IFX_INT_ADD_F_NOT_SET(flags))
		{
			/* Case of MODIFY & DELETE */
			/* Stop the Sevice with Checkpointed file in WAN MAIN */
			/* First get the CheckPointed file to rc.conf */
			#ifdef NOT_REQUIRED_FOR_ZERO_DOT_FIVE
			ifx_config_write(CHKPOINT_FILE, IFX_F_DEFAULT);
			#endif
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] owner [%d]", __FUNCTION__, __LINE__, wan_ppp_cfg->WAN_CONN.WAN_CONN_IID.config_owner);
			#endif
			sprintf(sCommand,"%s %d", SERVICE_WAN_STOP, wan_index);
			ret = system(sCommand);
			ret = IFX_SUCCESS;
		}
		if (ret != IFX_SUCCESS)
		{
			/* ??? What do we need to do if some services Stopped while others
			 * are still running ? Do we need to start the services again
			 * with the Check-Pointed file ?
			 * ??? */
			/* For now we just goto the IFX_Handler and return IFX_FAILURE */
			 goto IFX_Handler;	
		}
	}
	
	/* Here we restore back the Temp CheckPointed file that
	 * contains the changes made in WAN MAIN */
	#ifdef NOT_REQUIRED_FOR_ZERO_DOT_FIVE
	ifx_config_write(CHKPOINT_FILE2, IFX_F_DEFAULT);
	#endif

	/* Here there is no Backup of rc.conf required as we have done backup at WAN MAIN 
	 * Directly call SetCfgData function to update the system cofiguration in rc.conf */
	ret = IFX_SUCCESS;
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_PPP, flags, 1, buf);
	if(ret != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Set Data in rc.conf Fail", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}

	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) && IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags))
	{
		/* We need to invoke the scripts to bringup WAN interface. 
		 * ??? What do we need to do if some services Started while others
		 * are stopped ? Do we need to stop the services again
		 * with the Check-Pointed file ?
		 * ??? */

		/* For now we ignore all the stopped services and start
		 * services again */
		if (IFX_DELETE_F_NOT_SET(flags) && (IFX_DEACTIVATE_F_NOT_SET(flags)))
		{
			/* Just bring up this WAN interface for ADD/MODIFY-ENABLE cases */
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] owner [%d]", __FUNCTION__, __LINE__, wan_ppp_cfg->WAN_CONN.WAN_CONN_IID.config_owner);
			#endif
			sprintf(sCommand,"%s %d",SERVICE_WAN_START, wan_index);
			ret = system(sCommand);
			ret = IFX_SUCCESS;
		}

        /* Call for RIPd service restart - which handles the interface level
         * RIP enable/disable */
			
		/* Subramani - 19/08/2009 */
		/* We should start the ripd not restart - To fix unregister_netdevice issue */
        sprintf(sCommand, "%s %d", SERVICE_RIPD_START, wan_index);
        ret = system(sCommand);
        ret = IFX_SUCCESS;

        if (ret != IFX_SUCCESS)
        {
			/* Bringup WAN interface script failed!
			 * Do a Rollback with CHKPOINT_FILE2 and stop the service
			 */
			/** FIX ME: 
			 * Currently we have an issue with WAN BRINGUP
			 * WAN BRING UP calls several other scripts and it's
			 * difficult to track all those services in order to stop 
			 *
			 ROLLBACK_DEV_RST_RET(NULL, "Device Configuration error", 
			 CHKPOINT_FILE2, CHKPOINT_FILE, NULL, IFX_Handler)
		    */
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
			#endif
			goto IFX_Handler;
		}
	}

	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if(IFX_MODIFY_F_SET(flags))
	{
		CHECK_N_SEND_NOTIFICATION(wan_ppp_cfg->WAN_CONN.WAN_CONN_IID, wan_ppp_changed_fvp_count, 
			wan_ppp_changed_array_fvp, flags, IFX_Handler)
	}
	else if (IFX_INT_ADD_F_SET(flags))
	{
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
		UPDATE_ID_MAP_N_ATTRIBUTES(&wan_ppp_cfg->WAN_CONN.WAN_CONN_IID, wan_ppp_fvp_count, 
						wan_ppp_array_fvp, flags, IFX_Handler)
		CHECK_N_SEND_NOTIFICATION(wan_ppp_cfg->WAN_CONN.WAN_CONN_IID, wan_ppp_fvp_count, 
			wan_ppp_array_fvp, flags, IFX_Handler)

		/* Update the "ppp" Index in wan_ppp Section */
		if (ifx_manipulate_wan_indexs(FILE_RC_CONF, TAG_WAN_PPP, "wan_ppp_pppIdx", 
				dist_ppp_index,	IFX_F_INT_ADD) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Update ppp index in wan_ppp section Fail", __FUNCTION__, __LINE__);
			#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}
	else if (IFX_DELETE_F_SET(flags))
	{
		/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
		CHECK_N_SEND_NOTIFICATION(wan_ppp_cfg->WAN_CONN.WAN_CONN_IID, wan_ppp_fvp_count, 
			wan_ppp_array_fvp, flags, IFX_Handler)
		UPDATE_ID_MAP_N_ATTRIBUTES(&wan_ppp_cfg->WAN_CONN.WAN_CONN_IID, wan_ppp_fvp_count, 
						wan_ppp_array_fvp, flags, IFX_Handler)

		/* Delete the "ppp" Index in WAN_PPP Section */
		if (ifx_manipulate_wan_indexs(FILE_RC_CONF, TAG_WAN_PPP, "wan_ppp_pppIdx", 
				dist_ppp_index,	IFX_F_DELETE) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Update ppp index in wan_ppp section Fail", __FUNCTION__, __LINE__);
			#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if(ret != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Update Persistent Storage Fail", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}


IFX_Handler:
	IFX_MEM_FREE(wan_ppp_changed_array_fvp)
	if (ret != IFX_SUCCESS)
	{
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return IFX_FAILURE;
	}
	else
		return IFX_SUCCESS;
}

/*Temporarily added*/
/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_wan_ip_config_Without_TR69 (...)
*		operation	==> 	specifies the operation to be done such as ADD, DELETE or MODIFY
*		wan_index	==>		specifies the wan index of the wan connection to be configured
*		wan_ip_cfg	==>		pointer to WAN_IP_CONFIG structure which will store the ip connection specific parameters
*       flags       ==>  	flags that define the behaviour
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
        Description:
				This API is the same as ifx_set_wan_ip_config. Except that the TR69 related operations have been
				left Out.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_wan_ip_config_Without_TR69(int32 operation, int32 wan_index,
					WAN_IP_CONFIG *wan_ip_cfg, uint32 flags)
{
    char8 buf[MAX_DATA_LEN];
    char8 linkTypeStr[30];
    char8 conf_buf[MAX_FILELINE_LEN];
    char8 ifatmStr[10];
    int32 ret = IFX_SUCCESS;
    IFX_NAME_VALUE_PAIR wan_ip_array_fvp[9];
    uint32 wan_ip_fvp_count = 0;
    IFX_NAME_VALUE_PAIR *wanip_changed_array_fvp = NULL;
	//uint32 wanip_changed_fvp_count = 0;
    uint32 outFlag = IFX_F_DEFAULT;
    int32 dist_atm_index = -1;
    char8 sCommand[MAX_FILELINE_LEN];

    NULL_TERMINATE(linkTypeStr, 0, sizeof(linkTypeStr));
    NULL_TERMINATE(buf, 0, sizeof(buf));
    NULL_TERMINATE(sCommand, 0, sizeof(sCommand));
    memset(wan_ip_array_fvp, 0, sizeof(wan_ip_array_fvp));

	/* Validate the ipAddrType against the ipAddress, ipMask and ipGateway fields
	 * These fields are settable only if AddrType is STATIC
	 */
	if (IFX_DONT_VALIDATE_F_NOT_SET(flags))
	{
		if (IFX_DELETE_F_NOT_SET(flags))
		{
			if (wan_ip_cfg->addr_type != IP_TYPE_STATIC)
			{
				/* Check the values of IP Address, Mask and Gateway
				 * If these fields are non-zero then it's an Error!
				 */
				if ((wan_ip_cfg->WAN_CONN.WAN_CONN_IPADDR.s_addr != INADDR_ANY) ||
						(wan_ip_cfg->WAN_CONN.WAN_CONN_IPMASK.s_addr != INADDR_ANY) ||
						(wan_ip_cfg->ip_gw.s_addr != INADDR_ANY))
				{
					#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] Validate IP address Fail", __FUNCTION__, __LINE__);
					#endif
					ret = IFX_FAILURE;
					goto IFX_Handler;
				}
			}
		}
	}

	/* IID Allocation Block */
	if (IFX_INT_ADD_F_SET(flags))
	{
		/* Get the IID values from WAN_CONN_CFG - where the parent section 
		 * would be that of WAN_MAIN and cpeID that of WAN_MAIN 
		 * This is a deviation from other devices */

		/* The index used for WAN_IP Section is also derived from
		 * WAN_MAIN Section */		
		/* Alloc TR69 ID for this instance of WAN IP Connection */
		//IFX_ALLOC_TR69ID(wan_ip_cfg->WAN_CONN.WAN_CONN_IID, "addrType", IFX_Handler);
	}

	/* Determine the linkType of this connection */
	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
	NULL_TERMINATE(linkTypeStr, 0x00, sizeof(linkTypeStr));
	MAKE_SECTION_ELEMENT_TAG(PREFIX_WAN_MAIN, wan_index, "linkType", conf_buf);
	if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN,
			conf_buf, IFX_F_GET_ANY, &outFlag, linkTypeStr) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Get link Type of the connection Fail", __FUNCTION__, __LINE__);
		#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* The following fields will be used only for book keeping */
	/* For linkType CLIP, determine the operation is ADD/DELETE/MODIFY
	 * For ADD operation get a new atm interface index. For DELETE/MODIFY
	 * operations, get the already existing atm interface index */
	if (atoi(linkTypeStr) == LINK_TYPE_CLIP)
	{
		if (IFX_INT_ADD_F_SET(flags))
		{
			if (ifx_get_available_distinct_index(FILE_RC_CONF, TAG_WAN_IP, "atmIdx", 
					(MIN_WAN_INDEX - 1), MAX_WAN_INDEX, &dist_atm_index) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] ADD: Get available atm index fail", __FUNCTION__, __LINE__);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
		else
		{
		   /* For Modify/Delete operations get the "atm" index from rc.conf	*/
			NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
			NULL_TERMINATE(ifatmStr, 0x00, sizeof(ifatmStr));
			MAKE_SECTION_ELEMENT_TAG(PREFIX_WAN_IP, wan_index, "ifatm", conf_buf);
			if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP,
					conf_buf, IFX_F_GET_ANY, &outFlag, ifatmStr) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] MODIFY/DELETE: Get atm index from rc.conf Fail", __FUNCTION__, __LINE__);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			char8 tmpbuf[10];
			sscanf(ifatmStr, "%03s%d", tmpbuf, &dist_atm_index);
		}
	}

	/* Form the name-value pairs for ACL Checking & Validation */
	if(IFX_DELETE_F_NOT_SET(flags))
	{
		ifx_fill_ArrayFvp_FName(wan_ip_array_fvp, 0, 8, wan_ip_param_names);

		if(!wan_ip_cfg->max_mtu)
			wan_ip_cfg->max_mtu = DEFAULT_MAX_MTU;

		ifx_fill_ArrayFvp_intValues(wan_ip_array_fvp, 0, 6, (int32 *)&wan_ip_cfg->WAN_CONN.WAN_CONN_IID.cpeId.Id, &wan_ip_cfg->WAN_CONN.WAN_CONN_IID.pcpeId.Id, &wan_ip_cfg->conn_status, &wan_ip_cfg->conn_type, &wan_ip_cfg->addr_type, &wan_ip_cfg->max_mtu, &wan_ip_cfg->max_mtu);

		sprintf(wan_ip_array_fvp[6].value, "%s", inet_ntoa(wan_ip_cfg->ip_gw));

		if (atoi(linkTypeStr) == LINK_TYPE_CLIP)
		{
			sprintf(wan_ip_array_fvp[7].value, "%s%d", "atm", dist_atm_index);
		}
		else
		{
			sprintf(wan_ip_array_fvp[7].value, "%s", "");
		}
	}

	wan_ip_fvp_count = 8; 
	/* Form the fully qualified Name Value Pairs */
	if(ifx_get_conf_index_and_nv_pairs(&wan_ip_cfg->WAN_CONN.WAN_CONN_IID, wan_index, PREFIX_WAN_IP,
							wan_ip_fvp_count, wan_ip_array_fvp, flags) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Form Name Value Pairs buffer Fail", __FUNCTION__, __LINE__);
		#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	/* Ignore the "ifatm" in WAN IP for ACL 
	 * Hence count should be (count - 1)
	 */
	#if 0
	CHECK_ACL_RET(wan_ip_cfg->WAN_CONN.WAN_CONN_IID, (wan_ip_fvp_count-1), wan_ip_array_fvp,
			wanip_changed_fvp_count, wanip_changed_array_fvp, flags, IFX_Handler)
	#endif

	/********* System Config File Update Block  **********/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	form_cfgdb_buf(buf, wan_ip_fvp_count, wan_ip_array_fvp);

	/* For MODIFY/DELETE operations, first we need to stop the running configuration
	 * with the CheckPointed file in WAN MAIN.
	 * Restore the CHECKPOINTED FILE in WAN MAIN to RC.CONF in order to stop service
	 */
	if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) || IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags))
	{
		/* Subramani - 19/08/2009 */
		/* We need to stop the ripd - To fix unregister_netdevice */
		sprintf(sCommand, "%s", SERVICE_RIPD_STOP);
		ret = system(sCommand);
		ret = IFX_SUCCESS;

		if (IFX_INT_ADD_F_NOT_SET(flags))
		{
			/* Case of MODIFY & DELETE */
			/* Stop the Sevice with Checkpointed file in WAN MAIN */
			/* First get the CheckPointed file to rc.conf */
			#ifdef NOT_REQUIRED_FOR_ZERO_DOT_FIVE
			ifx_config_write(CHKPOINT_FILE, IFX_F_DEFAULT);
			#endif
		
			sprintf(sCommand,"%s %d", SERVICE_WAN_STOP, wan_index);
			ret = system(sCommand);
			ret = IFX_SUCCESS;
		}
		if (ret != IFX_SUCCESS)
		{
			/* ??? What do we need to do if some services Stopped while others
			 * are still running ? Do we need to start the services again
			 * with the Check-Pointed file ?
			 * ??? */
			/* For now we just goto the IFX_Handler and return IFX_FAILURE */
			 goto IFX_Handler;	
		}
	}
	
	/* Here there is no Backup of rc.conf required as we have done backup at WAN MAIN 
	 * Directly call SetCfgData function to update the system cofiguration in rc.conf */
	ret = IFX_SUCCESS;
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_IP, flags, 1, buf);
	if(ret != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Set Data in rc.conf Fail", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}

	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) || IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags))
	{
		/* We need to invoke the scripts to bringup WAN interface. 
		 * ??? What do we need to do if some services Started while others
		 * are stopped ? Do we need to stop the services again
		 * with the Check-Pointed file ?
		 * ??? */

		/* For now we ignore all the stopped services and start
		 * services again */
		if (IFX_DELETE_F_NOT_SET(flags) && (IFX_DEACTIVATE_F_NOT_SET(flags)))
		{
			/* Just bring up this WAN interface for ADD/MODIFY-ENABLE cases */
			sprintf(sCommand,"%s %d",SERVICE_WAN_START, wan_index);
			ret = system(sCommand);
			ret = IFX_SUCCESS;
		}
		
		/* Call for RIPd service restart - which handles the interface level
		 * RIP enable/disable */
		/* Subramani - 19/08/2009 */
		/* We need to start the ripd not restart - To fix unregister_netdevice issue */
		sprintf(sCommand, "%s %d", SERVICE_RIPD_START, wan_index);
		ret = system(sCommand);
		ret = IFX_SUCCESS;

		if(ret != IFX_SUCCESS)
		{
			/* Bringup WAN interface script failed!
			 * Do a Rollback with CHKPOINT_FILE2 and stop the service
			 */
			/** FIX ME: 
			 * Currently we have an issue with WAN BRINGUP
			 * WAN BRING UP calls several other scripts and it's
			 * difficult to track all those services in order to stop 
			 *
			 ROLLBACK_DEV_RST_RET(NULL, "Device Configuration error", 
			 CHKPOINT_FILE2, CHKPOINT_FILE, NULL, IFX_Handler)
			 */
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
			#endif
			goto IFX_Handler;
		}
	}

	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if(IFX_MODIFY_F_SET(flags))
	{
		#if 0
		CHECK_N_SEND_NOTIFICATION(wan_ip_cfg->WAN_CONN.WAN_CONN_IID, wanip_changed_fvp_count, 
			wanip_changed_array_fvp, flags, IFX_Handler)
		#endif
	}
	else if (IFX_INT_ADD_F_SET(flags))
	{
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
		#if 0
		UPDATE_ID_MAP_N_ATTRIBUTES(&wan_ip_cfg->WAN_CONN.WAN_CONN_IID, wan_ip_fvp_count, 
						wan_ip_array_fvp, flags, IFX_Handler)

		CHECK_N_SEND_NOTIFICATION(wan_ip_cfg->WAN_CONN.WAN_CONN_IID, wan_ip_fvp_count, 
			wan_ip_array_fvp, flags, IFX_Handler)
		#endif
		/* Update the "atm" Index in WAN_IP Section */
		if(atoi(linkTypeStr) == LINK_TYPE_CLIP)
		{
			if (ifx_manipulate_wan_indexs(FILE_RC_CONF, TAG_WAN_IP, "wan_ip_atmIdx", 
					dist_atm_index,	IFX_F_INT_ADD) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Manipulate wan indices Fail", __FUNCTION__, __LINE__);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
	}
	else if(IFX_DELETE_F_SET(flags))
	{
		/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
		#if 0
		CHECK_N_SEND_NOTIFICATION(wan_ip_cfg->WAN_CONN.WAN_CONN_IID, wan_ip_fvp_count, 
			wan_ip_array_fvp, flags, IFX_Handler)
		UPDATE_ID_MAP_N_ATTRIBUTES(&wan_ip_cfg->WAN_CONN.WAN_CONN_IID, wan_ip_fvp_count, 
						wan_ip_array_fvp, flags, IFX_Handler)
		#endif
		/* Delete the "atm" Index in WAN_IP Section if linkType
		 * is CLIP */
		if (atoi(linkTypeStr) == LINK_TYPE_CLIP)
		{
			if (ifx_manipulate_wan_indexs(FILE_RC_CONF, TAG_WAN_IP, "wan_ip_atmIdx",
					dist_atm_index,	IFX_F_DELETE) != IFX_SUCCESS)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] Manipulate wan indices Fail", __FUNCTION__, __LINE__);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
	}

	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if(ret != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Updating Persistent Storage Fail", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}


IFX_Handler:
	IFX_MEM_FREE(wanip_changed_array_fvp)
	if (ret != IFX_SUCCESS)
	{
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return IFX_FAILURE;
	}
	else
		return IFX_SUCCESS;
}
/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_wan_ppp_configi_Without_TR69(...)
*		operation	==> 	specifies the operation to be done such as ADD, DELETE or MODIFY
*		wan_index	==>		specifies the wan index of the wan connection to be configured
*		wan_ppp_cfg	==>		pointer to WAN_PPP_CONFIG structure which will store the ppp connection specific parameters
*       flags       ==>  	flags that define the behaviour
*
*       Return Value :   IFX_SUCCESS or IFX_FAILURE
        Description:
                This API is the same as ifx_set_wan_ppp_config. Except that the TR69 related operations have been
                left Out.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_wan_ppp_config_Without_TR69(int32 operation, int32 wan_index,
					WAN_PPP_CONFIG *wan_ppp_cfg, uint32 flags)
{
	char8 buf[MAX_DATA_LEN];
	char8 conf_buf[MAX_FILELINE_LEN];
	char8 linkTypeStr[10];
	char8 ifpppStr[10];
	int32 ret = IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR wan_ppp_array_fvp[17];
    uint32 wan_ppp_fvp_count = 0;
	IFX_NAME_VALUE_PAIR *wan_ppp_changed_array_fvp = NULL;
//	uint32 wan_ppp_changed_fvp_count = 0;
	uint32 outFlag = IFX_F_DEFAULT;
	int32 dist_ppp_index = -1;
    char8 sCommand[MAX_FILELINE_LEN];

    NULL_TERMINATE(linkTypeStr, 0, sizeof(linkTypeStr));
    NULL_TERMINATE(sCommand, 0, sizeof(sCommand));

    memset(wan_ppp_array_fvp, 0, sizeof(wan_ppp_array_fvp));

	/* Any Validation identified as required needs to go in here */
	if(IFX_DONT_VALIDATE_F_NOT_SET(flags))
	{
		if(IFX_DELETE_F_NOT_SET(flags))
		{
			/* PPP UserName cannot be NULL */
			if (strlen(wan_ppp_cfg->ppp_user_name) == 0)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] PPP Username NULL", __FUNCTION__, __LINE__);
				#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
		}
	}


	/* IID Allocation Block */
	if (IFX_INT_ADD_F_SET(flags))
	{
		/* Get the IID values from WAN_CONN_CFG - where the parent section 
		 * would be that of WAN_MAIN and cpeID that of WAN_MAIN 
		 * This is a deviation from other devices */

		/* The index used for WAN_PPP Section is also derived from
		 * WAN_MAIN Section */		
		/* Alloc TR69 ID for this instance of WAN PPP Connection */
		//IFX_ALLOC_TR69ID(wan_ppp_cfg->WAN_CONN.WAN_CONN_IID, "encrProto", IFX_Handler);
	}

	/* Determine the linkType of this connection */
	NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
	NULL_TERMINATE(linkTypeStr, 0x00, sizeof(linkTypeStr));
	MAKE_SECTION_ELEMENT_TAG(PREFIX_WAN_MAIN, wan_index, "linkType", conf_buf);
	if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN,
			conf_buf, IFX_F_GET_ANY, &outFlag, linkTypeStr) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("In [%s] : Unable to determine the LinkType for this Connection for [%d] (query [%s] in [%s] !!\n", 
						__FUNCTION__, wan_index, conf_buf, FILE_RC_CONF);
		#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* The following fields will be used only for book keeping */
	/* Determine the ppp index to be used with operation */
	if (IFX_INT_ADD_F_SET(flags))
	{
		if (ifx_get_available_distinct_index(FILE_RC_CONF, TAG_WAN_PPP, "pppIdx", 
				(MIN_WAN_INDEX - 1), MAX_WAN_INDEX, &dist_ppp_index) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("Unable to determine the PPP index\n");
			#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}
	else
	{
	   /* For Modify/Delete operations get the "ppp" index from rc.conf	*/
		NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
		NULL_TERMINATE(ifpppStr, 0x00, sizeof(ifpppStr));
		MAKE_SECTION_ELEMENT_TAG(PREFIX_WAN_PPP, wan_index, "ifppp", conf_buf);
		if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP,
				conf_buf, IFX_F_GET_ANY, &outFlag, ifpppStr) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Get ppp index from rc.conf fail", __FUNCTION__, __LINE__);
			#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		char8 tmpbuf[10];
		sscanf(ifpppStr, "%03s%d", tmpbuf, &dist_ppp_index);
	}

	/* Form the name-value pairs for ACL Checking & Validation */
	if(IFX_DELETE_F_NOT_SET(flags))
	{
		ifx_fill_ArrayFvp_FName(wan_ppp_array_fvp, 0, 16, wan_ppp_param_names);

		/* PPP Encryption, Compression, Authentication Protocols */
		/* LCP Echo intervals */
		/* PPPoE Access Concentrator, Service Name Configuration */

		ifx_fill_ArrayFvp_intValues(wan_ppp_array_fvp, 0, 11, (int32 *)&wan_ppp_cfg->WAN_CONN.WAN_CONN_IID.cpeId.Id, &wan_ppp_cfg->WAN_CONN.WAN_CONN_IID.pcpeId.Id, &wan_ppp_cfg->conn_type, &wan_ppp_cfg->encr_proto, &wan_ppp_cfg->compr_proto, &wan_ppp_cfg->auth_proto, &wan_ppp_cfg->max_mru_size, &wan_ppp_cfg->ppp_lcp_echo_period, &wan_ppp_cfg->ppp_lcp_echo_retry, &wan_ppp_cfg->max_mtu, &wan_ppp_cfg->bridge_enable);

		/* PPP Username & Password */
		ifx_fill_ArrayFvp_strValues(wan_ppp_array_fvp, 11, 4, (strlen(wan_ppp_cfg->pppoe_ac_name))?wan_ppp_cfg->pppoe_ac_name:"", (strlen(wan_ppp_cfg->pppoe_service_name))?wan_ppp_cfg->pppoe_service_name:"", wan_ppp_cfg->ppp_user_name, wan_ppp_cfg->ppp_user_passwd);

		sprintf(wan_ppp_array_fvp[15].value, "%s%d", "ppp", dist_ppp_index);
	}

	wan_ppp_fvp_count = 16; 

	/* Form the fully qualified Name Value Pairs */
	if(ifx_get_conf_index_and_nv_pairs(&wan_ppp_cfg->WAN_CONN.WAN_CONN_IID, wan_index, PREFIX_WAN_PPP,
							wan_ppp_fvp_count, wan_ppp_array_fvp, flags) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Form Name=Value buffer Fail", __FUNCTION__, __LINE__);
		#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	/* Ignore the "ifppp" in WAN IP for ACL 
	 * Hence count should be (count - 1)
	 */
	#if 0
	CHECK_ACL_RET(wan_ppp_cfg->WAN_CONN.WAN_CONN_IID, (wan_ppp_fvp_count-1), wan_ppp_array_fvp,
				wan_ppp_changed_fvp_count, wan_ppp_changed_array_fvp, flags, IFX_Handler)
	#endif

	/********* System Config File Update Block  **********/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	form_cfgdb_buf(buf, wan_ppp_fvp_count, wan_ppp_array_fvp);

	/* For MODIFY/DELETE operations, first we need to stop the running configuration
	 * with the CheckPointed file in WAN MAIN.
	 * Restore the CHECKPOINTED FILE in WAN MAIN to RC.CONF in order to stop service
	 */
	if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) || IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags))
	{
		/* Subramani - 19/08/2009 */
		/* We need to stop the ripd - To fix unregister_netdevice */
		sprintf(sCommand, "%s", SERVICE_RIPD_STOP);
		ret = system(sCommand);
		ret = IFX_SUCCESS;

		if(IFX_INT_ADD_F_NOT_SET(flags))
		{
			/* Case of MODIFY & DELETE */
			/* Stop the Sevice with Checkpointed file in WAN MAIN */
			/* First get the CheckPointed file to rc.conf */
			#ifdef NOT_REQUIRED_FOR_ZERO_DOT_FIVE
			ifx_config_write(CHKPOINT_FILE, IFX_F_DEFAULT);
			#endif
			IFX_DBG("[%s:%d] owner [%d]", __FUNCTION__, __LINE__, wan_ppp_cfg->WAN_CONN.WAN_CONN_IID.config_owner);
			sprintf(sCommand,"%s %d", SERVICE_WAN_STOP, wan_index);
			ret = system(sCommand);
			ret = IFX_SUCCESS;
		}
		if(ret != IFX_SUCCESS)
		{
			/* ??? What do we need to do if some services Stopped while others
			 * are still running ? Do we need to start the services again
			 * with the Check-Pointed file ?
			 * ??? */
		
			/* For now we just goto the IFX_Handler and return IFX_FAILURE */
			 goto IFX_Handler;	
		}
	}
	
	/* Here we restore back the Temp CheckPointed file that
	 * contains the changes made in WAN MAIN */
	#ifdef NOT_REQUIRED_FOR_ZERO_DOT_FIVE
	ifx_config_write(CHKPOINT_FILE2, IFX_F_DEFAULT);
	#endif

	/* Here there is no Backup of rc.conf required as we have done backup at WAN MAIN 
	 * Directly call SetCfgData function to update the system cofiguration in rc.conf */
	ret = IFX_SUCCESS;
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_PPP, flags, 1, buf);
	if(ret != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Set Data in rc.conf Fail", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}

	/*********** Device Configuration Block ****************/
	/* Device config thru Scripts/Utilities or Functions */
	if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) || IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags))
	{
		/* We need to invoke the scripts to bringup WAN interface. 
		 * ??? What do we need to do if some services Started while others
		 * are stopped ? Do we need to stop the services again
		 * with the Check-Pointed file ?
		 * ??? */
		/* For now we ignore all the stopped services and start
		 * services again */
		if(IFX_DELETE_F_NOT_SET(flags) && (IFX_DEACTIVATE_F_NOT_SET(flags)))
		{
			/* Just bring up this WAN interface for ADD/MODIFY-ENABLE cases */
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] owner [%d]", __FUNCTION__, __LINE__, wan_ppp_cfg->WAN_CONN.WAN_CONN_IID.config_owner);
			#endif
			sprintf(sCommand,"%s %d",SERVICE_WAN_START, wan_index);
			ret = system(sCommand);
			ret = IFX_SUCCESS;

		}

        /* Call for RIPd service restart - which handles the interface level
         * RIP enable/disable */
			
		/* Subramani - 19/08/2009 */
		/* We should start the ripd not restart - To fix unregister_netdevice issue */
        sprintf(sCommand, "%s %d", SERVICE_RIPD_START, wan_index);
        ret = system(sCommand);
        ret = IFX_SUCCESS;

        if (ret != IFX_SUCCESS)
        {
			/* Bringup WAN interface script failed!
			 * Do a Rollback with CHKPOINT_FILE2 and stop the service
			 */
			/** FIX ME: 
			 * Currently we have an issue with WAN BRINGUP
			 * WAN BRING UP calls several other scripts and it's
			 * difficult to track all those services in order to stop 
			 *
			 ROLLBACK_DEV_RST_RET(NULL, "Device Configuration error", 
			 CHKPOINT_FILE2, CHKPOINT_FILE, NULL, IFX_Handler)
	         */
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
			#endif
			goto IFX_Handler;
		}
	}

	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if(IFX_MODIFY_F_SET(flags))
	{
		#if 0
		CHECK_N_SEND_NOTIFICATION(wan_ppp_cfg->WAN_CONN.WAN_CONN_IID, wan_ppp_changed_fvp_count, 
			wan_ppp_changed_array_fvp, flags, IFX_Handler)
		#endif
	}
	else if(IFX_INT_ADD_F_SET(flags))
	{
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
		#if 0
		UPDATE_ID_MAP_N_ATTRIBUTES(&wan_ppp_cfg->WAN_CONN.WAN_CONN_IID, wan_ppp_fvp_count, 
						wan_ppp_array_fvp, flags, IFX_Handler)
		CHECK_N_SEND_NOTIFICATION(wan_ppp_cfg->WAN_CONN.WAN_CONN_IID, wan_ppp_fvp_count, 
			wan_ppp_array_fvp, flags, IFX_Handler)
		#endif
		/* Update the "ppp" Index in wan_ppp Section */
		if (ifx_manipulate_wan_indexs(FILE_RC_CONF, TAG_WAN_PPP, "wan_ppp_pppIdx", 
				dist_ppp_index,	IFX_F_INT_ADD) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Manipulate wan index Fail", __FUNCTION__, __LINE__);
			#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}
	else if(IFX_DELETE_F_SET(flags))
	{
		/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		/*********** Epilog Block **************/
		#if 0
		CHECK_N_SEND_NOTIFICATION(wan_ppp_cfg->WAN_CONN.WAN_CONN_IID, wan_ppp_fvp_count, 
			wan_ppp_array_fvp, flags, IFX_Handler)
		UPDATE_ID_MAP_N_ATTRIBUTES(&wan_ppp_cfg->WAN_CONN.WAN_CONN_IID, wan_ppp_fvp_count, 
						wan_ppp_array_fvp, flags, IFX_Handler)
		#endif
		/* Delete the "ppp" Index in WAN_PPP Section */
		if (ifx_manipulate_wan_indexs(FILE_RC_CONF, TAG_WAN_PPP, "wan_ppp_pppIdx", 
				dist_ppp_index,	IFX_F_DELETE) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Manipulate ppp index Fail", __FUNCTION__, __LINE__);
			#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}


	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if(ret != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Updating Persistent Storage Fail", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}

IFX_Handler:
	IFX_MEM_FREE(wan_ppp_changed_array_fvp)
	if (ret != IFX_SUCCESS)
	{
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return IFX_FAILURE;
	}
	else
		return IFX_SUCCESS;
}

#ifdef CONFIG_PACKAGE_IFX_OAM
int32 ifx_set_atmf5_loop_diagnostics(int32 operation, WAN_ATMF5_LOOP_DIAGNOSTICS* atmf5_daigs, uint32 flags)
{
    FILE	*in = NULL;
	char8	conf_buf[MAX_DATA_LEN];
	char8	*ret_WANConnDevStr = NULL, sValue[MAX_FILELINE_LEN];
	char8	buf[MAX_FILELINE_LEN];
	int32	ret = IFX_SUCCESS, passed_index = -1, count = 0, changed_count = 0;
	int32	f_vpi = 0, f_vci = 0, itf = 0;
	uint32	outFlag = IFX_F_DELETE;
	IFX_NAME_VALUE_PAIR array_fvp[18], *array_changed_fvp = NULL;
	

	if(atmf5_daigs == NULL)
	{
		return IFX_FAILURE;
	}

	/*************** Prolog Block *********************/
	/* Based on operation (ADD or DELETE or MODIFY) 
	 * append the flag with internal flags */
	if (operation == IFX_OP_DEL) 
		flags |= IFX_F_DELETE;
	else if (operation == IFX_OP_ADD) {
		if( (IFX_MODIFY_F_NOT_SET(flags)))
			flags |= IFX_F_INT_ADD;
	}
	else
		flags |= IFX_F_MODIFY;

	if (atmf5_daigs->iid.pcpeId.Id == 0) {
		/* Get the parent info from the passed VCC
		 * information refering to WAN_CONN_DEV.
		 * Here it is mandatory to pass the VCC info */

		/* First get the VCC information */
		NULL_TERMINATE(buf, 0x00, sizeof(buf));
		sprintf(buf, "%d/%d", atmf5_daigs->vpi, atmf5_daigs->vci);

		if (ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_CONN_DEVICE, 
						"vcc", buf, &ret_WANConnDevStr) != IFX_SUCCESS) {
			/* Check if the given VCC exists in WAN Connection Device Section
			   If it doesn't exist then it's an error */
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		else {
			/* Here we would have got the return string as wan_dev_x
			 * where 'x' denotes the device instance. Now get the cpeId
			 * for this instance 'x' */
			sprintf(buf, "%s_%s", ret_WANConnDevStr, "cpeId");
			if((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_CONN_DEVICE, buf, IFX_F_GET_ANY, 
							&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				ret = IFX_FAILURE;
				goto IFX_Handler;
			}
			else {
				atmf5_daigs->iid.pcpeId.Id = atoi(sValue);
				sprintf(atmf5_daigs->iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);
			}
		}
	}

	/**************** Validation Block *****************/
	/* For Operations other than DELETE do the verification of input params */
	if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		//IFX_VALIDATE_PTR(atmf5_daigs)
		/* Do simple validation of flags sucha as less than 0 */
		//IFX_VALIDATE_FLAGS(flags)
		if(flags == 0)
		{
                        ret = IFX_FAILURE;
                        goto IFX_Handler;
                }
		/* if entry is disabled then deny a modify enable from non-tr69 entity */
		IFX_VALIDATE_OAM_F5_ENTRY(atmf5_daigs, operation)
	}


	/**************** ID Allocation Block - Only for ADD Operation **************/
	sprintf(atmf5_daigs->iid.cpeId.secName, "%s", TAG_WAN_ATMF5);
	sprintf(atmf5_daigs->iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);

	if (IFX_ADD_F_SET(flags)) {
		/* Allocate the IID for this route instance
		 * Set the parent SectionName and parent IID values 
		 * to NULL as there is no parent for Route Entity 
		 */
		if(ifx_get_IID(&atmf5_daigs->iid, "diagnosticState") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
    } 


	/**************** Name Value Formation as per RC.CONF ********************/
	/* Form the FVP from the given structure for ADD/MODIFY Operations */
	if(IFX_DELETE_F_NOT_SET(flags)) {
		/* Build name value pairs only for RW Parameters of the obejct (Diagostic_state,Timeout,
			pingcount,loopback,cccheck,cccheckoption) */
		sprintf(array_fvp[0].fieldname, "%s", "diagnosticState");
		sprintf(array_fvp[0].value, "%d", atmf5_daigs->diagnostic_state);
        sprintf(array_fvp[1].fieldname, "%s", "timeout");
        sprintf(array_fvp[2].fieldname, "%s", "pingCount");
        sprintf(array_fvp[3].fieldname, "%s", "loopback");
        sprintf(array_fvp[4].fieldname, "%s", "contCheck");
        sprintf(array_fvp[5].fieldname, "%s", "contCheckOpt");

		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 5, (int32 *)&atmf5_daigs->diagnostic_state, (int32 *)&atmf5_daigs->ping_timeout, (int32 *)&atmf5_daigs->oam_pings, (int32 *)&atmf5_daigs->loopback, &atmf5_daigs->cc_check);
		/* Map the continuity check option value from {0,1,2} to {1,2,3} as understood by oamctl command */
        sprintf(array_fvp[5].value, "%d", (atmf5_daigs->cc_check_opt + 1));
		passed_index = -1;
	}

	count = 6;


	/* Get Config Index in case of modify/delete operations from CPEID */
	if((IFX_MODIFY_F_SET(flags)) ||
		(IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, atmf5_daigs->iid.cpeId, passed_index)
	}


	/* Determine the configuration index - for Add, Delete, Modify operations 
     * Name is partial since index is not known 
     * Fill array_fvp[] */
	if(ifx_get_conf_index_and_nv_pairs(&atmf5_daigs->iid, passed_index, PREFIX_WAN_ATMF5, 
				count, array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
	}


	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	/* Check Acl only for RW Parameters of the obejct (Diagostic_state,Timeout,Repetitions) */
	if(IFX_ADD_F_NOT_SET(flags)) {
		CHECK_ACL_RET(atmf5_daigs->iid, count, array_fvp,
						changed_count, array_changed_fvp, flags, IFX_Handler)
	}
	

	/*********** Device Configuration Block ****************/
	/* Call the API with respective values Call API if IFX_F_DON'T_CONFIGURE is not set
	 * and diagnostic_state=WAN_DIAG_START_DIAGNOSING */
	if((IFX_DONT_ACTIVATE_F_NOT_SET(flags) || IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) && atmf5_daigs->diagnostic_state == WAN_DIAG_START_DIAGNOSING) {
		/* check if the vcc is configured in kernel, if configured then only do the ping test otherwise set state to error */
#ifdef CPU_AMAZON
		if((in = fopen(PROCF_AMZ_VC, "r"))) {
			while (buf == fgets(buf, sizeof(buf), in)) {
				if(strstr(buf, "vpi")) {
					sscanf(buf, "\tvpi=%d vci=%d ", &f_vpi, &f_vci);
					if(atmf5_daigs->vpi == f_vpi && atmf5_daigs->vci == f_vci) {
						if(ifx_oam_f5_ping(atmf5_daigs->vpi, atmf5_daigs->vci, atmf5_daigs->scope, atmf5_daigs->ping_timeout,
									atmf5_daigs->oam_pings, &atmf5_daigs->success_count, &atmf5_daigs->max_resp_time,
									&atmf5_daigs->min_resp_time, &atmf5_daigs->avg_resp_time) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
							atmf5_daigs->diagnostic_state = WAN_DIAG_ERROR_INT;
						}
						else
							atmf5_daigs->diagnostic_state = WAN_DIAG_COMEPLETE;
					}
				}
			}
			fclose(in);
		}

#else

		if((in = fopen(PROCF_DNB_VC, "r"))) {
			while (buf == fgets(buf, sizeof(buf), in)) {
				if(strstr(buf, "Address") != NULL)
					continue;
				sscanf(buf, "%s %3d %3d %5d ", sValue, &itf, &f_vpi, &f_vci);
				if(atmf5_daigs->vpi == f_vpi && atmf5_daigs->vci == f_vci) {
					if(ifx_oam_f5_ping(atmf5_daigs->vpi, atmf5_daigs->vci, atmf5_daigs->scope, atmf5_daigs->ping_timeout,
							atmf5_daigs->oam_pings, (int *)&atmf5_daigs->success_count, (int *)&atmf5_daigs->max_resp_time,
							(int *)&atmf5_daigs->min_resp_time, (int *)&atmf5_daigs->avg_resp_time) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
								atmf5_daigs->diagnostic_state = WAN_DIAG_ERROR_INT;
					}
					else
						atmf5_daigs->diagnostic_state = WAN_DIAG_COMEPLETE;
				}
			}
			if(strlen(buf) <= 0)
				atmf5_daigs->diagnostic_state = WAN_DIAG_ERROR_INT;
			fclose(in);
		}
#endif
		else
			atmf5_daigs->diagnostic_state = WAN_DIAG_ERROR_INT;

	}


	/************** System Config File Update Block ****************/
	/* Form the complete field value pairs with the values updated from the ping api */
	if(IFX_DELETE_F_NOT_SET(flags)) {
		atmf5_daigs->failure_count = atmf5_daigs->oam_pings - atmf5_daigs->success_count;

		memset(array_fvp, 0x00, sizeof(array_fvp));
		ifx_fill_ArrayFvp_FName(array_fvp, 0, 17, wan_atmf5_param_names);

		f_vpi = atmf5_daigs->vpi;
		f_vci = atmf5_daigs->vci;
		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 5, (int32 *)&atmf5_daigs->iid.cpeId.Id, &atmf5_daigs->iid.pcpeId.Id, &atmf5_daigs->f_enable, &f_vpi, &f_vci);

		sprintf(array_fvp[5].value, "%d", atmf5_daigs->scope);
		ifx_fill_ArrayFvp_intValues(array_fvp, 6, 10, (int32 *)&atmf5_daigs->diagnostic_state, (int32 *)&atmf5_daigs->ping_timeout, (int32 *)&atmf5_daigs->oam_pings, (int32 *)&atmf5_daigs->loopback, (int32 *)&atmf5_daigs->cc_check, (int32 *)&atmf5_daigs->success_count, (int32 *)&atmf5_daigs->failure_count, (int32 *)&atmf5_daigs->min_resp_time, (int32 *)&atmf5_daigs->max_resp_time, (int32 *)&atmf5_daigs->avg_resp_time);

		sprintf(array_fvp[16].value, "%d", (atmf5_daigs->cc_check_opt + 1));
		passed_index = -1;
	}
	count = 17;

	/* Get Config Index in case of modify/delete operations from CPEID */
	if((IFX_MODIFY_F_SET(flags)) ||
		(IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, atmf5_daigs->iid.cpeId, passed_index)
	}


	/* Determine the configuration index - for Add, Delete, Modify operations 
     * Name is partial since index is not known 
     * Fill array_fvp[] */
	if(ifx_get_conf_index_and_nv_pairs(&atmf5_daigs->iid, passed_index, PREFIX_WAN_ATMF5, 
				count, array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
	}


	/************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
	/* Clean up the changes array fvp pointer and count before calling ACL check with these parameters */
	changed_count = 0;
	IFX_MEM_FREE(array_changed_fvp)
	if(IFX_ADD_F_NOT_SET(flags)) {
		CHECK_ACL_RET(atmf5_daigs->iid, count, array_fvp,
						changed_count, array_changed_fvp, flags, IFX_Handler)
	}


	/*************** System Config File Update Block *****************/
	/* Backup rc.conf before proceeding with configuration */
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(conf_buf, count, array_fvp);

	/* RC.CONF Configuration block */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_ATMF5, flags, 1, conf_buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/****************** Device configuration block *******************/
	/* this will Compact the section and also update the count for both ADD and DELETE */
	if(IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_WAN_ATMF5, flags);


	/*********** Notification Block *************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if(IFX_MODIFY_F_SET(flags))
		CHECK_N_SEND_NOTIFICATION(atmf5_daigs->iid, changed_count, array_changed_fvp, flags, IFX_Handler)

	else if (IFX_INT_ADD_F_SET(flags)) {
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		UPDATE_ID_MAP_N_ATTRIBUTES(&atmf5_daigs->iid, count, array_fvp, flags, IFX_Handler)

		CHECK_N_SEND_NOTIFICATION(atmf5_daigs->iid, count, array_fvp, flags, IFX_Handler)

		/* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WAN_ATMF5);
	}
	else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		 * and then send the Notification for the attributes
		 */	
		CHECK_N_SEND_NOTIFICATION(atmf5_daigs->iid, count, array_fvp, flags, IFX_Handler)

		UPDATE_ID_MAP_N_ATTRIBUTES(&atmf5_daigs->iid, count, array_fvp, flags, IFX_Handler)
	}


	/*********** Epilog Block **************/
	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}


IFX_Handler:
	IFX_MEM_FREE(ret_WANConnDevStr)
	IFX_MEM_FREE(array_changed_fvp)
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;

}
#endif


#if 0
#ifndef CONFIG_PACKAGE_IFX_DSL_CPE_API
int32 ifx_set_wan_dsl_diagnostics(int32 operation, WAN_DSL_DIAGNOSTICS *Wan_Dsl_Diag, uint32 flags)
{
		char8	buf[MAX_FILELINE_LEN], conf_buf[MAX_DATA_LEN * MAX_FILELINE_LEN], adsl_status[10];
		int32	i = 0, count = 0, t_count = 0, status = 0, Fd = 0, ret = IFX_SUCCESS, t_fd = 0;
		struct	adslAtucPhysEntry adslAtucPhysStruct;
		// struct	adslAturPhysEntry adslAturPhysStruct;
		struct	adslATURSubcarrierInfo adslATURSubcarrierInfoStruct;
		struct	adslPowerSpectralDensity adslPowerSpecDensityStruct;
		IFX_NAME_VALUE_PAIR array_fvp[2];

		NULL_TERMINATE(array_fvp, 0x00, sizeof(array_fvp));
		NULL_TERMINATE(buf, 0x00, sizeof(buf));
		NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
		NULL_TERMINATE(adsl_status, 0x00, sizeof(adsl_status));
		NULL_TERMINATE(&adslAtucPhysStruct, 0x00, sizeof(adslAtucPhysStruct));
		NULL_TERMINATE(&adslAturPhysStruct, 0x00, sizeof(adslAturPhysStruct));
		NULL_TERMINATE(&adslATURSubcarrierInfoStruct, 0x00, sizeof(adslATURSubcarrierInfoStruct));
		NULL_TERMINATE(&adslPowerSpecDensityStruct, 0x00, sizeof(adslPowerSpecDensityStruct));

		// Check if f_enable is set to enabled
		// and diagnostic_state is WAN_DSL_START_DIAGNOSING
		if((Wan_Dsl_Diag->f_enable == IFX_ENABLED) &&
						(Wan_Dsl_Diag->diagnostic_state == WAN_DIAG_START_DIAGNOSING)) {
				//Open the amazon_mei device
				Fd = open(ADSL_DEV_PATH, O_RDONLY);
				if (Fd <=0) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
						ret = IFX_FAILURE;
						goto IFX_Handler;
				}

				//Call the ioctl API start the DSL Diagnosis
				ioctl(Fd, SET_ADSL_LOOP_DIAGNOSTICS_MODE, 1);


				//Wait for some time
				//Check whether the diagnosis is complete
				//Check this in a loop after some sleep
				for(i=0; i<15; i++) {
						sleep(10);
						ioctl(Fd, IS_ADSL_LOOP_DIAGNOSTICS_MODE_COMPLETE, &status);

						if(status == 1) {
								break;
						}
				}

				/* set the adsl loop diagnostic mode back to 0 */
				ioctl(Fd, SET_ADSL_LOOP_DIAGNOSTICS_MODE, 0);

				/* test for adsl showtime in a loop and then call ioctls to get values */
				for(i=0; i<15; i++) {
						sleep(2);
						t_fd = open("/tmp/adsl_status", O_RDONLY);
						read(t_fd, adsl_status, sizeof(adsl_status));
						close(t_fd);
						if(atoi(adsl_status) == 7)
							break;
				}

				//Get the values after the diagnostic test
				ioctl(Fd,GET_ADSL_POWER_SPECTRAL_DENSITY, (void *) &adslPowerSpecDensityStruct);//ACTPSDds,ACTPSDus

				SET_FLAG(&adslAtucPhysStruct.flags,ATUC_CURR_OUT_PWR_FLAG);
				ioctl(Fd,GET_ADSL_ATUC_PHY,(void *) &adslAtucPhysStruct); //ACTATPds(outputPwr)

				SET_FLAG(&adslAturPhysStruct.flags,ATUR_CURR_OUT_PWR_FLAG);
				ioctl(Fd,GET_ADSL_ATUR_PHY,(void *) &adslAturPhysStruct); //ACTATPus(outputPwr)

				SET_FLAG(&adslATURSubcarrierInfoStruct.flags,FAREND_HLINSC);
				SET_FLAG(&adslATURSubcarrierInfoStruct.flags,FAREND_HLINPS);
				SET_FLAG(&adslATURSubcarrierInfoStruct.flags,FAREND_QLNPS);
				SET_FLAG(&adslATURSubcarrierInfoStruct.flags,FAREND_SNRPS);
				SET_FLAG(&adslATURSubcarrierInfoStruct.flags,FAREND_BITPS);
				SET_FLAG(&adslATURSubcarrierInfoStruct.flags,FAREND_GAINPS);

				ioctl(Fd,GET_ADSL_ATUR_SUBCARRIER_STATS,(void *) &adslATURSubcarrierInfoStruct);

				sprintf(Wan_Dsl_Diag->iid.cpeId.secName, "%s", TAG_DSL_DIAG);
				sprintf(Wan_Dsl_Diag->iid.cpeId.secName, "%s", TAG_WAN_DEVICE);

				ifx_fill_ArrayFvp_intValues(array_fvp, 0, 9, &Wan_Dsl_Diag->iid.cpeId.Id, &Wan_Dsl_Diag->iid.pcpeId.Id, &Wan_Dsl_Diag->f_enable, &Wan_Dsl_Diag->diagnostic_state, &adslPowerSpecDensityStruct.ACTPSDds, &adslPowerSpecDensityStruct.ACTPSDus, &adslAtucPhysStruct.outputPwr, &adslAturPhysStruct.outputPwr, &adslATURSubcarrierInfoStruct.HLINSCds);

				//Store it in rc.conf or copy the values to a static struct
				sprintf(array_fvp[count].fieldname, "%s_cpeId", PREFIX_DSL_DIAG);
				sprintf(array_fvp[count].fieldname, "%s_pcpeId", PREFIX_DSL_DIAG);
				sprintf(array_fvp[count].fieldname, "%s_fEnable", PREFIX_DSL_DIAG);
				// SetCfgData(adslATURSubcarrierInfoStruct.diagnostic_state); int
				sprintf(array_fvp[count].fieldname, "%s_diagnosticState", PREFIX_DSL_DIAG);
				// SetCfgData(adslAtucPhysStruct.ACTPSDds, adslAtucPhysStruct.ACTPSDus); both ints
				sprintf(array_fvp[count].fieldname, "%s_ACTPSDds", PREFIX_DSL_DIAG);
				sprintf(array_fvp[count].fieldname, "%s_ACTPSDus", PREFIX_DSL_DIAG);
				// SetCfgData(adslAtucPhysStruct.outputPwr); int
				sprintf(array_fvp[count].fieldname, "%s_ACTATPds", PREFIX_DSL_DIAG);
				// SetCfgData(adslAturPhysStruct.outputPwr); int
				sprintf(array_fvp[count].fieldname, "%s_ACTATPus", PREFIX_DSL_DIAG);
				// SetCfgData(adslATURSubcarrierInfoStruct.HLINSCds); int
				sprintf(array_fvp[count].fieldname, "%s_HLINSCds", PREFIX_DSL_DIAG);
				// SetCfgData(adslATURSubcarrierInfoStruct.HLINpsds); store as array
				t_count = 0;
				for(i=0; i<1024; i++) {
						sprintf(buf, "%d", adslATURSubcarrierInfoStruct.HLINpsds[i]);
						strcat(conf_buf, buf);
						if(((i+1)%32) == 0) {
								sprintf(array_fvp[count].fieldname, "%s_HLINpsds_%d", PREFIX_DSL_DIAG, t_count);
								sprintf(array_fvp[count].value, "%s", conf_buf);
								t_count++;
								count++;
						}
						else {
								strcat(conf_buf, ",");
						}
				}
				// SetCfgData(adslATURSubcarrierInfoStruct.QLNpsds); store as array
				t_count = 0;
				for(i=0; i<512; i++) {
						sprintf(buf, "%d", adslATURSubcarrierInfoStruct.QLNpsds[i]);
						strcat(conf_buf, buf);
						if(((i+1)%32) == 0) {
								sprintf(array_fvp[count].fieldname, "%s_QLNpsds_%d", PREFIX_DSL_DIAG, t_count);
								sprintf(array_fvp[count].value, "%s", conf_buf);
								t_count++;
								count++;
						}
						else {
								strcat(conf_buf, ",");
						}
				}
				// SetCfgData(adslATURSubcarrierInfoStruct.SNRpsds); store as array
				t_count = 0;
				for(i=0; i<512; i++) {
						sprintf(buf, "%d", adslATURSubcarrierInfoStruct.SNRpsds[i]);
						strcat(conf_buf, buf);
						if(((i+1)%32) == 0) {
								sprintf(array_fvp[count].fieldname, "%s_SNRpsds_%d", PREFIX_DSL_DIAG, t_count);
								sprintf(array_fvp[count].value, "%s", conf_buf);
								t_count++;
								count++;
						}
						else {
								strcat(conf_buf, ",");
						}
				}
				// SetCfgData(adslATURSubcarrierInfoStruct.BITSpsds); store as array
				t_count = 0;
				for(i=0; i<512; i++) {
						sprintf(buf, "%d", adslATURSubcarrierInfoStruct.BITpsds[i]);
						strcat(conf_buf, buf);
						if(((i+1)%32) == 0) {
								sprintf(array_fvp[count].fieldname, "%s_BITpsds_%d", PREFIX_DSL_DIAG, t_count);
								sprintf(array_fvp[count].value, "%s", conf_buf);
								t_count++;
								count++;
						}
						else {
								strcat(conf_buf, ",");
						}
				}
				// SetCfgData(adslATURSubcarrierInfoStruct.GAINSpsds); store as array
				t_count = 0;
				for(i=0; i<512; i++) {
						sprintf(buf, "%d", adslATURSubcarrierInfoStruct.GAINpsds[i]);
						strcat(conf_buf, buf);
						if(((i+1)%32) == 0) {
								sprintf(array_fvp[count].fieldname, "%s_GAINpsds_%d", PREFIX_DSL_DIAG, t_count);
								sprintf(array_fvp[count].value, "%s", conf_buf);
								t_count++;
								count++;
						}
						else {
								strcat(conf_buf, ",");
						}
				}

				/********* System Config File Update Block  **********/
				/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
				NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
				form_cfgdb_buf(conf_buf, count, array_fvp);

				ret = ifx_SetObjData(FILE_DSL_DIAG, TAG_DSL_DIAG, flags, 1, conf_buf);
				/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
				if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
					goto IFX_Handler;
				}
		}
		else {
				sprintf(buf, "%s_diagnosticState=\"%d\"\n", PREFIX_DSL_DIAG, Wan_Dsl_Diag->diagnostic_state);

				ret = ifx_SetObjData(FILE_DSL_DIAG, TAG_DSL_DIAG, flags, 1, buf);
				/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
				if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
					goto IFX_Handler;
				}
		}

IFX_Handler:
		close(Fd);
		if(ret != IFX_SUCCESS)
				return ret;
		else
				return IFX_SUCCESS;
}
#endif //!CONFIG_PACKAGE_IFX_DSL_CPE_API
#endif


/* GET APIs */


/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_default_wan_if(...)
*		operation	==>   the operation to be performed for this route entry, can be ADD, DELETE or MODIFY
*    	entry		==>   pointer to ROUTE_ENTRY structure that has the route details
*    	flags		==>   flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description	 :	This api sets the default wan interface
						it gets the wan connection name and interface either from the input wan_index
 						or cpeId in iid structure.
*/////////////////////////////////////////////////////////////////////////////
int32 ifx_set_default_wan_if(IFX_ID *iid, int32 wan_index, uint32 flags)
{
	char8	def_iface[IFNAMSIZE], conn_name[MAX_CONN_NAME_LEN], buf[MAX_DATA_LEN], prev_def_iface[IFNAMSIZE];
	char8	secName[MAX_FILELINE_LEN], gw_addr[MAX_IP_ADDR_LEN], conf_conn_name[MAX_CONN_NAME_LEN];
	char8	*retStr = NULL, sValue[MAX_FILELINE_LEN], qosenable[10], tcpackenable[10];
	int32	ret = IFX_SUCCESS, count = 0, changed_fcount = 0, acl_array_count = 0;
	char8   sCommand[MAX_FILELINE_LEN];
#ifdef  CONFIG_PACKAGE_NTPCLIENT
	char8 sVal[MAX_FILELINE_LEN];
	int32 ntp_fEnable=0;
#endif
	uint32	outFlag = IFX_F_DEFAULT;
	FILE	*fd = NULL;
	IFX_NAME_VALUE_PAIR array_fvp[5], *array_changed_fvp = NULL, acl_array_fvp[1];
	IFX_ID	t_iid;
	WAN_CONN_CFG	wan_cfg;
	int num_bytes = 0;

    NULL_TERMINATE(prev_def_iface, 0, sizeof(prev_def_iface));
    NULL_TERMINATE(def_iface, 0, sizeof(def_iface));
    NULL_TERMINATE(conn_name, 0, sizeof(conn_name));
    NULL_TERMINATE(gw_addr, 0, sizeof(gw_addr));
    NULL_TERMINATE(buf, 0, sizeof(buf));
    NULL_TERMINATE(sCommand, 0, sizeof(sCommand));
    memset(&wan_cfg, 0, sizeof(wan_cfg));
    memset(&t_iid, 0, sizeof(t_iid));

	/************* Prolog Block **************/
	/* Based on operation (ADD or DEL or MOD) 
	 * append the flag with internal flags */
	flags |= IFX_F_MODIFY;


	/************* Validation Block ************/
	/* Do simple validation of flags such as less than 0 */
	if(IFX_DONT_VALIDATE_F_NOT_SET(flags))
		IFX_VALIDATE_FLAGS(flags)


	/******************* Id Block ************************/
	sprintf(iid->cpeId.secName, "%s", TAG_DEFAULT_WAN);
	sprintf(iid->pcpeId.secName, "%s", TAG_IGD);
// #705244:Pramod start
#if 1
	t_iid = *iid;
	t_iid.cpeId.Id = 1;
	t_iid.pcpeId.Id = 1;
#endif
// #705244:Pramod end

	if((ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_enable", IFX_F_GET_ANY, &outFlag, qosenable)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	if((ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_tcpackprio", IFX_F_GET_ANY, &outFlag, tcpackenable)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}


	/************* Name Value Formation as per RC.CONF *************/
	/* Pramod : should use wan_index if iid not given */
	sprintf(buf, "%d", iid->cpeId.Id);
	ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_MAIN, "cpeId", buf, &retStr);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("failed to get substring out of distinct string !!\n");
#endif
		goto IFX_Handler;
	}

	/* if no wan index is input then get it using cpeid */
	if(wan_index < 1) {
		sscanf(retStr, "wan_%d", &wan_index);
	}

	/* from the substring such as wan_2_ form the wan_2_linkType 
	 * tag and check the value for this */
	sprintf(buf, "%s_connName", retStr);
	if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, IFX_F_GET_ANY, &outFlag, conn_name)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}

	ret = ifx_get_wan_ifname_from_connName(conn_name, def_iface);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
	IFX_DBG("failed to get default iface !!\n");
#endif
		goto IFX_Handler;
	}

	sprintf(buf, "%s_conf_connName", retStr);
	if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, IFX_F_GET_ANY, &outFlag, conf_conn_name)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}


	/* get the connection name as wan2, wan6, .... */
	sprintf(array_fvp[0].fieldname, "%s", "default_wan_conn_cpeId");
	sprintf(array_fvp[0].value, "%d", iid->cpeId.Id);
	sprintf(array_fvp[1].fieldname, "%s", "default_wan_conn_pcpeId");
	sprintf(array_fvp[1].value, "%d", iid->pcpeId.Id);
	/*sprintf(array_fvp[2].fieldname, "%s", "default_wan_conn_wan_cpeId");
	sprintf(array_fvp[2].value, "%s", wan_cpeId);*/
	sprintf(array_fvp[2].fieldname, "%s", "default_wan_conn_connName");
	sprintf(array_fvp[2].value, "%s", conn_name);
	sprintf(array_fvp[3].fieldname, "%s", "default_wan_conn_conf_connName");
	sprintf(array_fvp[3].value, "%s", conf_conn_name);
	sprintf(array_fvp[4].fieldname, "%s", "default_wan_conn_iface");
	sprintf(array_fvp[4].value, "%s", def_iface);
	count = 5;
	sprintf(acl_array_fvp[0].fieldname, "%s", "default_wan_conn_conf_connName");
	sprintf(acl_array_fvp[0].value, "%s", conf_conn_name);
	acl_array_count = 1;

	/**************** ACL Checking Block *****************/
	CHECK_ACL_RET(t_iid, acl_array_count, acl_array_fvp,
		changed_fcount, array_changed_fvp, flags, IFX_Handler)

	/* Delete the previously configured default route */
	if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) || IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) {
		fd = popen("/sbin/route -n | grep ^0.0.0.0 | tr -s ' ' | cut -d ' ' -f 8", "r");
		if(fd != NULL) {
			num_bytes = fread(prev_def_iface, 1, sizeof(prev_def_iface), fd);
			prev_def_iface[num_bytes] = '\0';
			if(isspace(prev_def_iface[strlen(prev_def_iface)-1]))
				prev_def_iface[strlen(prev_def_iface)-1] = '\0';
			if(strlen(prev_def_iface)) {
				sprintf(buf, "route del default dev %s > /dev/null 2> /dev/null", prev_def_iface);
				if(system(buf))
					// ret = IFX_FAILURE;
					ret = IFX_SUCCESS;
			}
		}
		if(fd)
			pclose(fd);

        /* need to call mgmt.sh stop for web */
		fd = popen("/etc/rc.d/ipqos_mgmt_traffic_config web stop", "r");
		if(fd == NULL) {
#ifdef IFX_LOG_DEBUG
		    IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
            ret = IFX_FAILURE;
		    goto IFX_Handler;
		}
		if(fd)
			pclose(fd);
			
		        /* Call TCP ACK Prio script with DELETE option to delete IPTABLE Postrouting rule with older default interface name*/
        		if ((atoi(qosenable) == 0) && (atoi(tcpackenable) == 1))
        		{
                		sprintf(sCommand,". /etc/rc.d/ipqos_tcp_ack_prio 2");
                		system(sCommand);
        		}

	} // IFX_DONT_ACTIVATE_F_NOT_SET

	/********* System Config File Update Block  **********/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(buf, count, array_fvp);

	/* Backup rc.conf before proceeding with configuration */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_DEFAULT_WAN, flags, 1, buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* Update the wan_main_defConn tag in wan_main section also with this connection name */
	sprintf(buf, "wan_main_defConn=\"%s\"\n", conn_name);

	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_MAIN, flags, 1, buf);

	/* Check if ret is not IFX_SUCCESS then restore the rc.conf with backup rc.conf */
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}


	/*********************** Device Configuration Block **************************/
	/* Pramod : commenting adding the default route, but this is a design issue to take up later
		Call get api for this wan index, get the ip address from the returned structure and use it
		as the gateway for the the default route */
	if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) || IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) {
		sprintf(secName, "WAN%d_GATEWAY", wan_index);
		if((ret = ifx_GetObjData(FILE_SYSTEM_STATUS, secName, "ROUTER1", IFX_F_GET_ANY, &outFlag, gw_addr)) == IFX_SUCCESS) {
			if(strlen(gw_addr) && strcmp(gw_addr, "0.0.0.0")) {
				sprintf(buf, "route add default gw %s dev %s", gw_addr, def_iface);
				if(system(buf))
					// ret = IFX_FAILURE;
					ret = IFX_SUCCESS;
			}
		}


        /* TODO : need comment here */
        sprintf(buf, "/etc/rc.d/ipqos_cfg_mgmt start %d", wan_index);
        system(buf);

    	memset(buf, 0, sizeof(MAX_DATA_LEN));

        /* restart udhcpd since relay service, part of udhcpd, is dependant on default wan interface */
    	sprintf(buf, "%s_0_dhcpMode", TAG_LAN_MAIN);
	ifx_GetObjData(FILE_RC_CONF, TAG_LAN_MAIN, buf, IFX_F_GET_ANY, &outFlag, sValue);
	if(!strcmp(sValue, "relay")) {
		system("/etc/rc.d/init.d/udhcpd stop");
        	system("/etc/rc.d/init.d/udhcpd start");
	}

        /* need to call mgmt.sh start for web */
		fd = popen("/etc/rc.d/ipqos_mgmt_traffic_config web start", "r");
		if(fd == NULL) {
#ifdef IFX_LOG_DEBUG
		    IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
            ret = IFX_FAILURE;
		    goto IFX_Handler;
		}
		if(fd)
			pclose(fd);
#if 0
	/*Init PPE_IPQOS when ever default wan connection is changed from web page */
		sprintf(sCommand, "%s", PPE_IPQOS_MAIN);
		system(sCommand);
#endif
		/* Call Ipqos TCP ACK Prio script with ADD option to ADD new Iptables Postrouting rule with the new interface name*/
		if ((atoi(qosenable) == 0) && (atoi(tcpackenable) == 1))
		{
        		sprintf(sCommand,". /etc/rc.d/ipqos_tcp_ack_prio 0");
        		system(sCommand);
		}

	} // IFX_DONT_ACTIVATE_F_NOT_SET


	/**************** Notification Block ******************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if(IFX_ADD_F_NOT_SET(flags) && IFX_DELETE_F_NOT_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION (t_iid, changed_fcount, array_changed_fvp, flags, IFX_Handler)
	}


	/***************** Epilog Block **********************/
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* manage Internet LED for change in Default WAN */
        sprintf(buf, "/etc/rc.d/invoke_internet_led %d", wan_index);
        system(buf);

#ifdef CONFIG_PACKAGE_NTPCLIENT
        memset(sVal, 0x00, sizeof(sVal));
        if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_TIME_SECTION, TAG_TIME_SECTION "_" IFX_TIME_NTPENABLE,
        flags, &outFlag, sVal)) != IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
        IFX_DBG("\n\n In Function [%s] : Error--> Failed to get NTP Enable Value !!\n\n", __FUNCTION__);
#endif
        goto IFX_Handler;
        }
        ntp_fEnable=atoi(sVal);
        if(ntp_fEnable==1){
                fd = popen("/etc/rc.d/init.d/ntpc", "r");
                if(fd == NULL) {
#ifdef IFX_LOG_DEBUG
                    IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
                        ret = IFX_FAILURE;
                        goto IFX_Handler;
                }
                if(fd){
                       system(" . /etc/rc.d/init.d/ntpc restart > /dev/null 2>&1");
		}
				pclose(fd);
        }
#endif


IFX_Handler:
	IFX_MEM_FREE(retStr);
	IFX_MEM_FREE(array_changed_fvp)
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}

/////////////////////////////////////////////////////////////////////////////
//function  : ifx_get_one_wan_atm_vcc_config
//arguments : WAN_CONN_CFG *p_wancfg,
//            uint32 iCpeId,
//	      uint32 flags
//return    : IFX_SUCCESS if successful
//	      IFX_FAIL otherwise
//////////////////////////////////////////////////////////////////////////////

int32 ifx_get_one_wan_atm_vcc_config(WAN_CONN_CFG *p_wancfg)
{
	int32 ret = ifx_get_wan_atm_vcc_config(-1, p_wancfg, IFX_F_GET_ANY);
        if(ret != IFX_SUCCESS) 
	{
#ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s] : returned failure!", __FUNCTION__);
#endif
             	return ret;
        }
        else
               return IFX_SUCCESS;
}
/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_all_wan_atm_vcc_config(...)
*	num_entries	==>	number of wan connections
*	pp_wancfg	==>	output pointer to array of wan connections WAN_CONN_CFG
*	flags		==>	
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads all the wan connections from rc.conf
			and returns them in the array pp_wancfg. Also the number of wan
			connections read will be returned in num_entries.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_all_wan_atm_vcc_config(int32 *num_entries, WAN_CONN_CFG **pp_wancfg, uint32 flags)
{
	uint32	outFlag = IFX_F_DEFAULT;
	char8	buf[MAX_FILELINE_LEN], sIndexes[MAX_FILELINE_LEN];
	int32	count = 0, ret = IFX_SUCCESS, idx_count = 0, *idx_array = NULL, i =0;
	WAN_CONN_CFG wan_cfg, *t_ptr = NULL;

	*num_entries = 0;
	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	NULL_TERMINATE(sIndexes, 0x00, sizeof(sIndexes));

	sprintf(buf, "%s", "wan_main_index");
	if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, &outFlag, sIndexes)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	get_wan_indices(sIndexes, &idx_count, &idx_array);

	t_ptr = (WAN_CONN_CFG *)IFX_MALLOC(idx_count * sizeof(WAN_CONN_CFG));

	if(t_ptr == NULL)
	{
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	*pp_wancfg = t_ptr;

	for(i=0; i<idx_count; i++) {
	//	NULL_TERMINATE(&wan_cfg, 0x00, sizeof(wan_cfg));
		memset(&wan_cfg, 0x00, sizeof(wan_cfg));
		wan_cfg.wan_index = *(idx_array + i);
		sprintf(wan_cfg.iid.cpeId.secName, "%s", TAG_WAN_MAIN);

		/* if there is no wan object in wan_main section for this wanIdx, continue */
		if((ret = ifx_get_wan_atm_vcc_config(*(idx_array + i), &wan_cfg, flags)) != IFX_SUCCESS) {
			goto IFX_Handler;
		}

/*		t_ptr = (WAN_CONN_CFG *)realloc(*pp_wancfg, (count + 1) * sizeof(WAN_CONN_CFG));

		if(t_ptr == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
		}

		*pp_wancfg = t_ptr;

		//memset((*pp_wancfg + count), 0x00, sizeof(WAN_CONN_CFG));

*/
	/*manohar : this check is not required
		if (*pp_wancfg == NULL || pp_wancfg == NULL) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	*/
		/* else copy the wan_cfg into pp_wancfg */
		*(*pp_wancfg + count) = wan_cfg;
		count++;
	}
	*num_entries = idx_count;

IFX_Handler:
	IFX_MEM_FREE(idx_array)
	if(ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*pp_wancfg)
		*num_entries = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_wan_ip_config(...)
*	wanIdx		==>	input index of the wan ip connection for which configuration
*				has to be returned
*	wan_cfg		==>	output pointer to wan ip connection WAN_CFG
*	flags		==>	
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads the wan ip connection configuration from rc.conf
			for the input wan index wanIdx.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_wan_ip_config(int32 wanIdx, WAN_CONN_CFG *wan_cfg, uint32 flags)
{
	int32	ret = IFX_SUCCESS;
	uint32	outFlag = IFX_F_DEFAULT;
	char8	buf[MAX_FILELINE_LEN], retVal[MAX_FILELINE_LEN], wan_section[MAX_NAME_LEN];

	NULL_TERMINATE(wan_section, 0x00, sizeof(wan_section));
	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	NULL_TERMINATE(retVal, 0x00, sizeof(retVal));

	if (wan_cfg == NULL) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("\n\n In Function [%s] : Error--> No WAN Connection config specified!!\n\n",__FUNCTION__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* initialize the cache for this instance */
	sprintf(buf, "%s_%d_", PREFIX_WAN_IP, wan_cfg->wan_index);
	if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_IP, buf, IFX_F_INT_CACHE_INIT | flags, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* check for linktype : if clip information should be fetched from wan_main and wan_ip
	 * the same for ipoa and eoa, diff is that for clip iftype=atm, and iftype=nas for eoa and ipoa
	 * also check for addrtype in wan_ip section, if its static get ipaddress from wan_main section
	 * else if its dhcp get the ip address from system_status file */
	sprintf(buf, "wan_%d_linkType", wanIdx);
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, &outFlag, retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* Return the static values of possible connection types */
	wan_cfg->WAN_IP_CONN.possible_conn_types[0] = WAN_IP_CONN_TYPE_UNCONFIGURED;
	wan_cfg->WAN_IP_CONN.possible_conn_types[1] = WAN_IP_CONN_TYPE_IP_ROUTED;
	wan_cfg->WAN_IP_CONN.possible_conn_types[2] = WAN_IP_CONN_TYPE_IP_BRIDGED;

	/* Hard coding Last connection error to none */
	wan_cfg->WAN_IP_CONN.last_conn_error = WANIP_LAST_CONN_ERROR_NONE;

	sprintf(wan_section, "Wan%d_IF_Info", wan_cfg->wan_index);

	if(atoi(retVal) == WAN_LINK_TYPE_EOATM || atoi(retVal) == WAN_LINK_TYPE_IPOATM || atoi(retVal) == WAN_LINK_TYPE_ETH || atoi(retVal) == WAN_LINK_TYPE_PTM )
        {
		sprintf(buf, "wanip_%d_connType", wan_cfg->wan_index);
		if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_IP, buf, flags, &outFlag, retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		wan_cfg->WAN_IP_CONN.conn_type = atoi(retVal);

		sprintf(buf, "wanip_%d_maxMTU", wan_cfg->wan_index);
		if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_IP, buf, flags, &outFlag, retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		wan_cfg->WAN_IP_CONN.max_mtu = atoi(retVal);

		sprintf(buf, "wanip_%d_addrType", wan_cfg->wan_index);
		if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_IP, buf, flags, &outFlag, retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		wan_cfg->WAN_IP_CONN.addr_type = atoi(retVal);

		/* if the entry is enabled then try getting values from running status file */
//		if(wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_ENABLE == IFX_ENABLED) {
			/* if values are not found in running status the entry is disabled in the system
			 * return the default values in the fields and status based on the status from the running status */
			/* This sleep call is currently put to avoid failure on Get Parameters immediately after
			 * doing a SET operation - since the WAN bringup scripts takes some time before the WAN
			 * Link is actually UP and the status updated in FILE_SYSTEM_STATUS */
			/** TO DO - This call to be moved into TR69 Adaptation or the ACS should wait before
			 **			issuing a GET Call after a SET */
          
		//	sleep(10);

			/* try getting the ip address, netmask and gateway from running config file
				if not found then try getting from rc.conf. for static wan connections read these fields
				from rc.conf itself */

			if(wan_cfg->WAN_IP_CONN.addr_type == IP_TYPE_STATIC) {
				NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
				GET_WANIP_FRM_CONF(wanIdx, retVal, flags)
				wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IPADDR.s_addr = inet_addr(retVal);

				NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
				GET_WANMASK_FRM_CONF(wanIdx, retVal, flags)
				wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IPMASK.s_addr = inet_addr(retVal);

				NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
				GET_WANGW_FRM_CONF(wan_cfg->wan_index, retVal, flags)
				wan_cfg->WAN_IP_CONN.ip_gw.s_addr = inet_addr(retVal);
			}
			else {
				NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
				if((ifx_GetObjDataOpt(FILE_SYSTEM_STATUS, wan_section, "IP", flags, &outFlag, retVal)) != IFX_SUCCESS) {
	#ifdef IFX_LOG_DEBUG
					IFX_DBG("\nIn Function [%s] : [IP] not found under [%s] in [%s] !!\n",
						__FUNCTION__, wan_section, FILE_SYSTEM_STATUS);
	#endif
					NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
					GET_WANIP_FRM_CONF(wanIdx, retVal, flags)
					wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IPADDR.s_addr = inet_addr(retVal);
				}
				else {
					if(strlen(retVal)) {
						wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IPADDR.s_addr = inet_addr(retVal);
					}
					else {
						GET_WANIP_FRM_CONF(wanIdx, retVal, flags)
						wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IPADDR.s_addr = inet_addr(retVal);
					}
				}
	
				NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
				if((ifx_GetObjDataOpt(FILE_SYSTEM_STATUS, wan_section, "MASK", flags, &outFlag, retVal)) != IFX_SUCCESS) {
					NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
					GET_WANMASK_FRM_CONF(wanIdx, retVal, flags)
					wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IPMASK.s_addr = inet_addr(retVal);
				}
				else {
					if(strlen(retVal)) {
						wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IPMASK.s_addr = inet_addr(retVal);
					}
					else {
						GET_WANMASK_FRM_CONF(wanIdx, retVal, flags)
						wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IPMASK.s_addr = inet_addr(retVal);
					}
				}
	
			#if 0
				if((ifx_GetObjData(FILE_SYSTEM_STATUS, wan_section, "STATUS", flags, &outFlag, retVal)) != IFX_SUCCESS) {
					/* if the status tag is not found in running status then also dont return error
					 * instead put the status as disconnected */
					wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_DISCONNECTED;
				}
				else {
					if(!strcmp(retVal, "CONNECTING"))
						wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_CONNECTING;
					else if(!strcmp(retVal, "CONNECTED"))
						wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_CONNECTED;
					else if(!strcmp(retVal, "DISCONNECTING"))
						wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_DISCONNECTING;
					else if(!strcmp(retVal, "DISCONNECTED"))
						wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_DISCONNECTED;
					else if(!strcmp(retVal, "PENDING_DISCONNECT"))
						wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_PENDING_DISCONNECT;
					else
						wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_UNCONFIGURED;
				}
			#endif
	
				NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
				sprintf(wan_section, "WAN%d_GATEWAY", wan_cfg->wan_index);
				if((ifx_GetObjDataOpt(FILE_SYSTEM_STATUS, wan_section, "ROUTER1", flags, &outFlag, retVal)) != IFX_SUCCESS) {
					NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
					GET_WANGW_FRM_CONF(wan_cfg->wan_index, retVal, flags)
					wan_cfg->WAN_IP_CONN.ip_gw.s_addr = inet_addr(retVal);
				}
				else {
					if(strlen(retVal)) {
						wan_cfg->WAN_IP_CONN.ip_gw.s_addr = inet_addr(retVal);
					}
					else {
						GET_WANGW_FRM_CONF(wan_cfg->wan_index, retVal, flags)
						wan_cfg->WAN_IP_CONN.ip_gw.s_addr = inet_addr(retVal);
					}
				}
			}
//		}
#if 0
if user wants to get values of disabled entry where in he has configured valid values
for the fields then this portion of code will always return 0.0.0.0
		/* otherwise set all the values to default and status as disconnected */
		else {
			wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_DISCONNECTED;
			wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IPADDR.s_addr = inet_addr("0.0.0.0");
			wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IPMASK.s_addr = inet_addr("0.0.0.0");
		}
#endif

#if 0
		if(atoi(retVal) == IP_TYPE_STATIC) {
			sprintf(buf, "wan_%d_ipAddr", wan_cfg->wan_index);
			if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, &outFlag, retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}
			wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IPADDR.s_addr = inet_addr(retVal);

			sprintf(buf, "wan_%d_ipMask", wan_cfg->wan_index);
			if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, &outFlag, retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}
			wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IPMASK.s_addr = inet_addr(retVal);

			sprintf(buf, "wanip_%d_connStatus", wan_cfg->wan_index);
			if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags, &outFlag, retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}
			wan_cfg->WAN_IP_CONN.conn_status = atoi(retVal);

			sprintf(buf, "wanip_%d_gateway", wan_cfg->wan_index);
			if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags, &outFlag, retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
			}
			wan_cfg->WAN_IP_CONN.ip_gw.s_addr = inet_addr(retVal);
		}
		else if(atoi(retVal) == IP_TYPE_DHCP) {
			/* if the entry is enabled then try getting values from running status file */
			if(wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_ENABLE == IFX_ENABLED) {
				/* if values are not found in running status the entry is disabled in the system
				 * return the default values in the fields and status based on the status from the running status */
				/* This sleep call is currently put to avoid failure on Get Parameters immediately after
				 * doing a SET operation - since the WAN bringup scripts takes some time before the WAN
				 * Link is actually UP and the status updated in FILE_SYSTEM_STATUS */
				/** TO DO - This call to be moved into TR69 Adaptation or the ACS should wait before
				 **			issuing a GET Call after a SET */
              
			//	sleep(10);
				sprintf(wan_section, "Wan%d_IF_Info", wan_cfg->wan_index);
				if((ifx_GetObjData(FILE_SYSTEM_STATUS, wan_section, "IP", flags, &outFlag, retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
						IFX_DBG("\nIn Function [%s] : [IP] not found under [%s] in [%s] !!\n",
							__FUNCTION__, wan_section, FILE_SYSTEM_STATUS);
#endif
					wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IPADDR.s_addr = inet_addr("0.0.0.0");
				}
				else {
					wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IPADDR.s_addr = inet_addr(retVal);
				}

				if((ifx_GetObjData(FILE_SYSTEM_STATUS, wan_section, "MASK", flags, &outFlag, retVal)) != IFX_SUCCESS) {
					wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IPMASK.s_addr = inet_addr("0.0.0.0");
				}
				else {
					wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IPMASK.s_addr = inet_addr(retVal);
				}

				if((ifx_GetObjData(FILE_SYSTEM_STATUS, wan_section, "STATUS", flags, &outFlag, retVal)) != IFX_SUCCESS) {
					/* if the status tag is not found in running status then also dont return error
					 * instead put the status as disconnected */
					wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_DISCONNECTED;
				}
				else {
					if(!strcmp(retVal, "CONNECTING"))
						wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_CONNECTING;
					else if(!strcmp(retVal, "CONNECTED"))
						wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_CONNECTED;
					else if(!strcmp(retVal, "DISCONNECTING"))
						wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_DISCONNECTING;
					else if(!strcmp(retVal, "DISCONNECTED"))
						wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_DISCONNECTED;
					else if(!strcmp(retVal, "PENDING_DISCONNECT"))
						wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_PENDING_DISCONNECT;
					else
						wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_UNCONFIGURED;
				}

				sprintf(wan_section, "WAN%d_GATEWAY", wan_cfg->wan_index);
				if((ifx_GetObjData(FILE_SYSTEM_STATUS, wan_section, "ROUTER1", flags, &outFlag, retVal)) != IFX_SUCCESS) {
					wan_cfg->WAN_IP_CONN.ip_gw.s_addr = inet_addr("0.0.0.0");
				}
				else {
					wan_cfg->WAN_IP_CONN.ip_gw.s_addr = inet_addr(retVal);
				}
			}
			/* otherwise set all the values to default and status as disconnected */
			else {
				wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_DISCONNECTED;
				wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IPADDR.s_addr = inet_addr("0.0.0.0");
				wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IPMASK.s_addr = inet_addr("0.0.0.0");
			}
		}
#endif
	}
	else if(atoi(retVal) == WAN_LINK_TYPE_CLIP) {
		/* get ip address and netmask from wan main, gateway, connection type and connection status from wan_ip
		 * addrType, ifatm, mtu from wan_ip */

		sprintf(buf, "wan_%d_ipAddr", wan_cfg->wan_index);
		if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, &outFlag, retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IPADDR.s_addr = inet_addr(retVal);

		sprintf(buf, "wan_%d_ipMask", wan_cfg->wan_index);
		if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, &outFlag, retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IPMASK.s_addr = inet_addr(retVal);

		sprintf(buf, "wanip_%d_gateway", wan_cfg->wan_index);
		if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_IP, buf, flags, &outFlag, retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		wan_cfg->WAN_IP_CONN.ip_gw.s_addr = inet_addr(retVal);

		sprintf(buf, "wanip_%d_connType", wan_cfg->wan_index);
		if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_IP, buf, flags, &outFlag, retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		wan_cfg->WAN_IP_CONN.conn_type = atoi(retVal);

#if 0
		sprintf(buf, "wanip_%d_connStatus", wan_cfg->wan_index);
		if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, buf, flags, &outFlag, retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		wan_cfg->WAN_IP_CONN.conn_status = atoi(retVal);
#endif

		sprintf(buf, "wanip_%d_maxMTU", wan_cfg->wan_index);
		if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_IP, buf, flags, &outFlag, retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		wan_cfg->WAN_IP_CONN.max_mtu = atoi(retVal);

		sprintf(buf, "wanip_%d_addrType", wan_cfg->wan_index);
		if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_IP, buf, flags, &outFlag, retVal)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
		wan_cfg->WAN_IP_CONN.addr_type = atoi(retVal);
	}
	else {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* get the status of the wan ip connection from running config file */
	sprintf(wan_section, "Wan%d_IF_Info", wan_cfg->wan_index);
	if((ifx_GetObjDataOpt(FILE_SYSTEM_STATUS, wan_section, "STATUS", flags, &outFlag, retVal)) != IFX_SUCCESS) {
		/* if the status tag is not found in running config file then dont return error
		 * instead put the status as disconnected */
		wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_UNCONFIGURED;
	}
	else {
		if(!strcmp(retVal, "CONNECTING"))
			wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_CONNECTING;
		else if(!strcmp(retVal, "CONNECTED"))
			wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_CONNECTED;
		else if(!strcmp(retVal, "DISCONNECTING"))
			wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_DISCONNECTING;
		else if(!strcmp(retVal, "DISCONNECTED"))
			wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_DISCONNECTED;
		else if(!strcmp(retVal, "PENDING_DISCONNECT"))
			wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_PENDING_DISCONNECT;
		else if(!strcmp(retVal, "UNCONFIGURED"))
			wan_cfg->WAN_IP_CONN.conn_status = WAN_IP_CONN_STATUS_UNCONFIGURED;
	}

IFX_Handler:
	if(wan_cfg != NULL)
	{
		/* destroy the cache for this instance */
		sprintf(buf, "%s_%d_", PREFIX_WAN_IP, wan_cfg->wan_index);
		if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_IP, buf, IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Failed to destroy cache for this instance", __FUNCTION__, __LINE__);
			#endif
			ret = IFX_FAILURE;
		}
	}
	if (ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return IFX_FAILURE;
	}
	else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_wan_ppp_config(...)
*	wanIdx		==>	input index of the wan ppp connection for which configuration
*				has to be returned
*	wan_cfg		==>	output pointer to wan ppp connection WAN_CFG
*	flags		==>	
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads the wan ppp connection configuration from rc.conf
			for the input wan index wanIdx.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_wan_ppp_config(int32 wanIdx, WAN_CONN_CFG *wan_cfg, uint32 flags)
{
	char8 buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN], ppp_ifname[MAX_FILELINE_LEN], secName[MAX_FILELINE_LEN];
	int32 ret=IFX_SUCCESS, outFlag = IFX_F_DEFAULT;
	FILE  *fp = NULL;

	/* initialize the cache for this instance */
	sprintf(buf, "%s_%d_", PREFIX_WAN_PPP, wan_cfg->wan_index);
	if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, IFX_F_INT_CACHE_INIT | flags, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	sprintf(buf, "wanppp_%d_connType", wanIdx);
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags,(IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_cfg->wancfg.ppp.conn_type = atoi(sValue);

	/* Hard coding Last connection error to none */
	//wan_cfg->WAN_IP_CONN.last_conn_error = WANIP_LAST_CONN_ERROR_NONE;
	wan_cfg->WAN_PPP_CONN.last_conn_error = WANPPP_LAST_CONN_ERROR_NONE;

	/* Get connection status from system_status file */
	/* check if there is a auth_fail file for this ppp interface, if so set status auth failure */
	sprintf(buf, "wanppp_%d_ifppp", wanIdx);
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, (IFX_OUT uint32 *)&outFlag, ppp_ifname)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	snprintf(buf,sizeof(buf),"/tmp/%s_auth_fail", ppp_ifname);
	fp = fopen(buf, "r");
	if(fp != NULL) {
		/* Hack : update status as auth failure in system_status for this wan, as web reads the status directly */
		memset(buf, 0x00, sizeof(buf));
		memset(secName, 0x00, sizeof(secName));
		sprintf(buf, "%s", "STATUS=\"AUTHENTICATION FAILURE\"\n");
		sprintf(secName, "Wan%d_IF_Info", wanIdx);
		ifx_SetObjData(FILE_SYSTEM_STATUS, secName, IFX_F_MODIFY, 1, buf);
		wan_cfg->WAN_PPP_CONN.conn_status = WAN_PPP_CONN_STATUS_AUTHENTICATING;
		wan_cfg->WAN_PPP_CONN.last_conn_error = WANPPP_LAST_CONN_ERROR_AUTHENTICATION_FAILURE;
	}
	else {
		sprintf(buf, "Wan%d_IF_Info", wanIdx);
		if((ret = ifx_GetObjDataOpt(FILE_SYSTEM_STATUS, buf, "STATUS", flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			wan_cfg->WAN_PPP_CONN.conn_status = WAN_PPP_CONN_STATUS_UNCONFIGURED;
		}
		else {
			if(!strcmp(sValue, "CONNECTING"))
				wan_cfg->WAN_PPP_CONN.conn_status = WAN_PPP_CONN_STATUS_CONNECTING;
			else if(!strcmp(sValue, "CONNECTED"))
				wan_cfg->WAN_PPP_CONN.conn_status = WAN_PPP_CONN_STATUS_CONNECTED;
			else if(!strcmp(sValue, "DISCONNECTING"))
				wan_cfg->WAN_PPP_CONN.conn_status = WAN_PPP_CONN_STATUS_DISCONNECTING;
			else if(!strcmp(sValue, "DISCONNECTED"))
				wan_cfg->WAN_PPP_CONN.conn_status = WAN_PPP_CONN_STATUS_DISCONNECTED;
			else if(!strcmp(sValue, "PENDING_DISCONNECT"))
				wan_cfg->WAN_PPP_CONN.conn_status = WAN_PPP_CONN_STATUS_PENDING_DISCONNECT;
			else if(!strcmp(sValue, "AUTHENTICATING"))
				wan_cfg->WAN_PPP_CONN.conn_status = WAN_PPP_CONN_STATUS_AUTHENTICATING;
			else if(!strcmp(sValue, "UNCONFIGURED"))
				wan_cfg->WAN_PPP_CONN.conn_status = WAN_PPP_CONN_STATUS_UNCONFIGURED;
		}
	}
	if (fp)
		fclose(fp);

	/* Return the static values of possible connection types */
	wan_cfg->WAN_PPP_CONN.possible_conn_types[0] = WAN_PPP_CONN_TYPE_UNCONFIGURED;
	wan_cfg->WAN_PPP_CONN.possible_conn_types[1] = WAN_PPP_CONN_TYPE_IP_ROUTED;
	wan_cfg->WAN_PPP_CONN.possible_conn_types[2] = WAN_PPP_CONN_TYPE_PPPOE_BRIDGED;
	wan_cfg->WAN_PPP_CONN.possible_conn_types[3] = WAN_PPP_CONN_TYPE_PPPOE_RELAY;

	sprintf(buf, "wanppp_%d_encrProto", wanIdx);
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	else
		wan_cfg->wancfg.ppp.encr_proto = atoi(sValue);

	sprintf(buf, "wanppp_%d_comprProto", wanIdx);
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	else
		wan_cfg->wancfg.ppp.compr_proto = atoi(sValue);

	sprintf(buf, "wanppp_%d_authProto", wanIdx);
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	else
		wan_cfg->wancfg.ppp.auth_proto = atoi(sValue);

	sprintf(buf, "wanppp_%d_maxMRU", wanIdx);
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_cfg->wancfg.ppp.max_mru_size = atoi(sValue);

	/* Get current MRU */
	/* wan_cfg->wancfg.ppp.current_mru = ;*/
	/* Get remote ip from ifconfig */
	#if 0
	sprintf(buf, "Wan%d_IF_Info", wanIdx);
	if((ret = ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "IP", flags, &outFlag, sValue)) != IFX_SUCCESS) {
		if(wan_cfg->wancfg.ppp.conn_status == WAN_PPP_CONN_STATUS_CONNECTED) { /* If ip addess not found for status conencted
																					return an error !! */
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		}
	}
	else
		wan_cfg->wancfg.ppp.remote_addr.s_addr = inet_addr(sValue);
	#endif // 0

	sprintf(buf, "WAN%d_PPP_INFO", wanIdx);
	if((ret = ifx_GetObjDataOpt(FILE_SYSTEM_STATUS, buf, "LOCAL_IP", flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
		if(wan_cfg->wancfg.ppp.conn_status == WAN_PPP_CONN_STATUS_CONNECTED) { /* If ip addess not found for status conencted
																					return an error !! */
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		}
	}
	else
		wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IPADDR.s_addr = inet_addr(sValue);

	sprintf(buf, "WAN%d_PPP_INFO", wanIdx);
	if((ret = ifx_GetObjDataOpt(FILE_SYSTEM_STATUS, buf, "REMOTE_IP", flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
		if(wan_cfg->wancfg.ppp.conn_status == WAN_PPP_CONN_STATUS_CONNECTED) { /* If ip addess not found for status conencted
																					return an error !! */
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		}
	}
	else
		wan_cfg->wancfg.ppp.remote_addr.s_addr = inet_addr(sValue);

	/* Get transport type based on if the connection is pppoa or pppoe */
	/* if ifnas is null and iftype is ppp then its pppoa, if ifnas is not null and iftype is ppp its pppoe */
	/* For now we are using only PPPoE or PPPoA, not the remaining two optins PPTP and L2TP */
	if(wan_cfg->type == WAN_LINK_TYPE_PPPOE) {
		wan_cfg->wancfg.ppp.transport_type = WAN_PPP_TRANSPORT_TYPE_PPPOE;
	}
	else if(wan_cfg->type == WAN_LINK_TYPE_PPPOATM) {
		wan_cfg->wancfg.ppp.transport_type = WAN_PPP_TRANSPORT_TYPE_PPPOA;
	}

	/* Get echo period and echo retry from where ?? */
	sprintf(buf, "wanppp_%d_ACName", wanIdx);
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	snprintf(wan_cfg->wancfg.ppp.pppoe_ac_name,MAX_CONN_NAME_LEN,"%s", sValue);

	sprintf(buf, "wanppp_%d_serviceName", wanIdx);
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	snprintf(wan_cfg->wancfg.ppp.pppoe_service_name,MAX_CONN_NAME_LEN,"%s", sValue);

	sprintf(buf, "wanppp_%d_user", wanIdx);
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	snprintf(wan_cfg->wancfg.ppp.ppp_user_name,MAX_PPP_USER_NAME_PASSWD_LEN,"%s", sValue);

	sprintf(buf, "wanppp_%d_passwd", wanIdx);
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	snprintf(wan_cfg->wancfg.ppp.ppp_user_passwd,MAX_PPP_USER_NAME_PASSWD_LEN,"%s", sValue);

	sprintf(buf, "wanppp_%d_MTU", wanIdx);
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_cfg->wancfg.ppp.max_mtu = atoi(sValue);

	sprintf(buf, "wanppp_%d_bridgeEnable", wanIdx);
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, flags, (IFX_OUT uint32 *)&outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_cfg->wancfg.ppp.bridge_enable = atoi(sValue);

IFX_Handler:
	/* destroy the cache for this instance */
	sprintf(buf, "%s_%d_", PREFIX_WAN_PPP, wan_cfg->wan_index);
	if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_PPP, buf, IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to destroy cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_wan_atm_vcc_config(...)
*	wanIdx		==>	input index of the wan connection for which configuration
*				has to be returned
*	wan_cfg		==>	output pointer to wan connection WAN_CONN_CFG
*	flags		==>	
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads the wan connection configuration from rc.conf
			for the input wan index wanIdx. This function reads the wan main 
			configuration from wan_main section and based on the link type it
			reads the specific connection parameters from either the 
			wan_ip or wan_ppp section from rc.conf
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_wan_atm_vcc_config(int32 wanIdx, WAN_CONN_CFG *wan_cfg, uint32 flags)
{
	IFX_ID iid;
	int32 dist_wan_index = -1, i = 0;
	char8 buf[MAX_FILELINE_LEN], *vpi = NULL, *vci = NULL, retVal[MAX_FILELINE_LEN], *dns_servers = NULL;
	int32 ret=IFX_SUCCESS, outFlag = IFX_F_DEFAULT;
	WAN_COMMON_CFG wan_comm_cfg;
	char8 name[16];
	NET_INTF_CFG params;

	memset(&wan_comm_cfg, 0x00, sizeof(wan_comm_cfg));

	/* Check if wan_index is passed or not, is passed get wan connection type from wan_index
	 * If not passed then get wan index for the cpeid passed
	 * if both wan index and cpeid are not passed return error !! */
	sprintf(iid.cpeId.secName, "%s", TAG_WAN_MAIN);
	iid.cpeId.Id = wan_cfg->iid.cpeId.Id;

	if (wanIdx < 0)
	{
		if(wan_cfg->iid.cpeId.Id < 1)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Wan Index and cpeId invalid", __FUNCTION__, __LINE__);
			#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}

		if(ifx_get_index_from_cpe_id(FILE_RC_CONF, &iid.cpeId, &dist_wan_index) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve wan index from cpeId", __FUNCTION__, __LINE__);
			#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		wan_cfg->wan_index = dist_wan_index;
	}
	else
		wan_cfg->wan_index = wanIdx;

	/* initialize the cache for this instance */
	sprintf(buf, "%s_%d_", PREFIX_WAN_MAIN, wan_cfg->wan_index);
	if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, IFX_F_INT_CACHE_INIT | flags, NULL, NULL) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
		#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	sprintf(buf, "wan_%d_cpeId", wan_cfg->wan_index);
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve cpe Id", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	wan_cfg->iid.cpeId.Id = atoi(retVal);

	sprintf(buf, "wan_%d_pcpeId", wan_cfg->wan_index);
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve  parent cpe Id", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	wan_cfg->iid.pcpeId.Id = atoi(retVal);

	sprintf(buf, "wan_%d_linkType", wan_cfg->wan_index);
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve Link type", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	wan_cfg->type = atoi(retVal);

	/* Determine the WAN Connection Type - WAN_IP or WAN_PPP from
	 * the link type associated with the WAN device */
	if ((wan_cfg->type == LINK_TYPE_PPPOE) || (wan_cfg->type == LINK_TYPE_PPPOATM))
	{
		wan_comm_cfg = wan_cfg->WAN_PPP_CONN.WAN_CONN;
	}
	else
	{
		/* Case of UnConfigured is assumed to be WAN_IP */
		wan_comm_cfg = wan_cfg->WAN_IP_CONN.WAN_CONN;
	}

	if (wan_cfg->type == LINK_TYPE_CLIP)
	{
		sprintf(buf, "wanip_%d_ifatm", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
		if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_IP, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve interface name", __FUNCTION__, __LINE__);
  		    #endif
		    goto IFX_Handler;
		}
		strlcpy(name,retVal,sizeof(name));
	}
	else if (wan_cfg->type == LINK_TYPE_ETH)
	{
  	 	sprintf(buf, "wan_%d_iface", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
		if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve interface name", __FUNCTION__, __LINE__);
		    #endif
		    goto IFX_Handler;
		}
		strcpy(name,retVal);
	}
	else if (wan_cfg->type == LINK_TYPE_PTM)
	{
  		sprintf(buf, "wan_%d_iface", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
		if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve interface name", __FUNCTION__, __LINE__);
		    #endif
		    goto IFX_Handler;
		}
		strcpy(name,retVal);
	}
	else if (wan_cfg->type == LINK_TYPE_PPPOE)
	{
  	 	sprintf(buf, "wan_%d_wanMode", wan_cfg->wan_index);
#if 0
		if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve wan mode", __FUNCTION__, __LINE__);
		    #endif
		    goto IFX_Handler;
		}
		if(atoi(retVal) == WAN_MODE_ATM)
		{
			sprintf(buf, "wan_%d_ifnas", wan_cfg->wan_index);
		}
		else if(atoi(retVal) == WAN_MODE_PTM || atoi(retVal) == WAN_MODE_VDSL_PTM)
		{
			sprintf(buf, "wan_%d_ifptm", wan_cfg->wan_index);
		}
        else
  	 	{
  	 	    sprintf(buf, "wan_%d_ifeth", wan_cfg->wan_index);
        }
#endif
		sprintf(buf, "wan_%d_iface", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));

		if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
		{
		    #ifdef IFX_LOG_DEBUG
		    IFX_DBG("[%s:%d] Unable to retrieve interface name", __FUNCTION__, __LINE__);
		    #endif
		    goto IFX_Handler;
		}
		strcpy(name,retVal);
	}
	else
	{
  	 	sprintf(buf, "wan_%d_iface", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
		if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve interface name", __FUNCTION__, __LINE__);
			#endif
			goto IFX_Handler;
		}
		strcpy(name,retVal);
	}

	sprintf(buf, "wan_%d_wanMode", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve wan mode", __FUNCTION__, __LINE__);
		#endif
	    goto IFX_Handler;
	}
	wan_cfg->wan_mode.mode = atoi(retVal);

	sprintf(buf, "wan_%d_vlanId", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve vlan Id", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	wan_cfg->vlanId = atoi(retVal);

	sprintf(buf, "Wan%d_IF_Info", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
	if((ret = ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "bringup_time_secs", flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve Wan%d_IF_Info", __FUNCTION__, __LINE__, wan_cfg->wan_index);
		#endif
	}
	else
	{
		struct sysinfo info;
		memset(&info,0,sizeof(info));
		sysinfo(&info);
		wan_comm_cfg.uptime = info.uptime - atol(retVal);
	}

	sprintf(buf, "wan_%d_autoDiscTime", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve autoDiscTime", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.WAN_CONN_AUTO_DISCONNECT_TIME = atoi(retVal);

	sprintf(buf, "wan_%d_idleDiscTime", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve idleDiscTime", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.WAN_CONN_IDLE_DISCONNECT_TIME = atoi(retVal);

	sprintf(buf, "wan_%d_warnDiscTime", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve warnDiscTime", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.WAN_CONN_WARN_DISCONNECT_TIME = atoi(retVal);

	sprintf(buf, "wan_%d_RSIP", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve RSIP", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.WAN_CONN_RSIP_AVAILABLE = atoi(retVal);

	sprintf(buf, "wan_%d_NATEnable", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve NAT Enable value", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.WAN_CONN_NAT_ENABLED = atoi(retVal);

	sprintf(buf, "wan_%d_DNSEnable", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve DNS Enable value", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.WAN_CONN_DNS_ENABLED = atoi(retVal);

	sprintf(buf, "wan_%d_DNSOverride", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve DNS Override value", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.WAN_CONN_DNS_OVERRIDE = atoi(retVal);

	if(wan_comm_cfg.WAN_CONN_DNS_OVERRIDE == IFX_DISABLED) {
		/* read dns server values from rc.conf */
		sprintf(buf, "wan_%d_DNSServers", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
		if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve DNS servers value", __FUNCTION__, __LINE__);
			#endif
			goto IFX_Handler;
		}

		dns_servers = strtok(retVal, ",");
		i = 0;
		while(dns_servers != NULL)
		{
			wan_comm_cfg.dns_servers[i].s_addr = inet_addr(dns_servers);
			dns_servers = strtok(NULL, ",");
			i++;
		}
	}
	else
	{
		/* read dns server ip addressed from system_status */
		sprintf(buf, "WAN%d_DNS_SERVER", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
		if((ret = ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "DNS1", flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve DNS1 value", __FUNCTION__, __LINE__);
			#endif
		}
		else
			wan_comm_cfg.dns_servers[0].s_addr = inet_addr(retVal);

		memset(retVal,'\0',sizeof(retVal));
		if((ret = ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "DNS2", flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve DNS2 value", __FUNCTION__, __LINE__);
			#endif
		}
		else
			wan_comm_cfg.dns_servers[1].s_addr = inet_addr(retVal);

		memset(retVal,'\0',sizeof(retVal));
		if((ret = ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "DNS3", flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Unable to retrieve DNS3 value", __FUNCTION__, __LINE__);
			#endif
		}
		else
			wan_comm_cfg.dns_servers[2].s_addr = inet_addr(retVal);
	}

	memset(&params,0,sizeof(params));
	ifx_mod_interface_attr(name,IFX_GET_INTF_ATTR,&params);
	snprintf(wan_comm_cfg.WAN_CONN_MAC_ADDR,MAX_MAC_ADDR_LEN,"%s", params.hwaddr);

	sprintf(buf, "wan_%d_macAddrOverride", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve mac override value", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.WAN_CONN_MAC_ADDR_OVERRIDE = atoi(retVal);

	sprintf(buf, "wan_%d_connTrigger", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve connection trigger", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.WAN_CONN_TRIGGER = atoi(retVal);

	sprintf(buf, "wan_%d_rxRouteProto", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve routing protocol", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.WAN_CONN_ROUTE_PROTO_RX = atoi(retVal);

	sprintf(buf, "wan_%d_fEnable", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve enable status", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	wan_comm_cfg.WAN_CONN_ENABLE = atoi(retVal);

	sprintf(buf, "wan_%d_connName", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve connection name", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	strlcpy(wan_comm_cfg.WAN_CONN_NAME, retVal,MAX_CONN_NAME_LEN);

	sprintf(buf, "wan_%d_conf_connName", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve conf connection name", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	strlcpy(wan_comm_cfg.WAN_CONF_CONN_NAME, retVal,MAX_CONN_NAME_LEN);

	/* get the vpi vci out of retVal */
	sprintf(buf, "wan_%d_vcc", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
	if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve vcc", __FUNCTION__, __LINE__);
		#endif
		goto IFX_Handler;
	}
	vpi = strtok(retVal, "/");
	vci = strtok(NULL, "/");
	if(vpi != NULL)
		wan_cfg->vc.pvc.vpi = atoi(vpi);
	if(vci != NULL)
		wan_cfg->vc.pvc.vci = atoi(vci);

   sprintf(buf, "wan_%d_wanMode", wan_cfg->wan_index);
		memset(retVal,'\0',sizeof(retVal));
   if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
   {
        #ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] Unable to retrieve wan mode", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_cfg->wan_mode.mode = atoi(retVal);

	/* destroy the cache for this instance */
	sprintf(buf, "%s_%d_", PREFIX_WAN_MAIN, wan_cfg->wan_index);
	if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to destroy cache for this instance", __FUNCTION__, __LINE__);
		#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	if ((wan_cfg->type == WAN_LINK_TYPE_PPPOE) ||
		(wan_cfg->type == WAN_LINK_TYPE_PPPOATM))
	{
        	memcpy(&wan_cfg->WAN_PPP_CONN.WAN_CONN, &wan_comm_cfg, sizeof(wan_comm_cfg));
		ifx_get_wan_ppp_config(wan_cfg->wan_index, wan_cfg, flags);
	}
	else
	{
	        memcpy(&wan_cfg->WAN_IP_CONN.WAN_CONN, &wan_comm_cfg, sizeof(wan_comm_cfg));
		ifx_get_wan_ip_config(wan_cfg->wan_index, wan_cfg, flags);
	}

IFX_Handler:
	if (ret != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s] : returned failure!", __FUNCTION__);
		#endif
		return ret;
	}
	else
		return IFX_SUCCESS;
}


#ifdef CONFIG_PACKAGE_IFX_OAM
int32 ifx_get_all_wan_atmf5_loop_diagnostics(int32 *num_entries, WAN_ATMF5_LOOP_DIAGNOSTICS **atmf5_diagnostics, uint32 flags)
{
	uint32	outFlag = IFX_F_DEFAULT;
	int32	i = 0, count = 0, atmf5_count = 0, ret = IFX_SUCCESS;
	char8	command[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	WAN_ATMF5_LOOP_DIAGNOSTICS t_atmf5, *t_ptr = NULL;

	sprintf(command, "%s_Count", TAG_WAN_ATMF5);
	if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_ATMF5, command, flags, &outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return IFX_FAILURE;
	}

	atmf5_count = 0;
	count = atoi(sValue);
	if(count < 0 || count > 32767)
		return IFX_FAILURE;

	t_ptr = (WAN_ATMF5_LOOP_DIAGNOSTICS *)IFX_MALLOC(count * sizeof(WAN_ATMF5_LOOP_DIAGNOSTICS));

		if(t_ptr == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
		}

		*atmf5_diagnostics = t_ptr;



	for(i=0; i<count; i++) {
		memset(&t_atmf5, 0x00, sizeof(t_atmf5));

		sprintf(command, "%s_%d_cpeId", PREFIX_WAN_ATMF5, i);
		if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_ATMF5, command, flags, &outFlag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			continue;
		}
		t_atmf5.iid.cpeId.Id = atoi(sValue);

		if(ifx_get_atmf5_loop_diagnostics(&t_atmf5, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			continue;			
		}

	/*	t_ptr = (WAN_ATMF5_LOOP_DIAGNOSTICS *)realloc(*atmf5_diagnostics, 
								(atmf5_count + 1) * sizeof(WAN_ATMF5_LOOP_DIAGNOSTICS));

		if(t_ptr == NULL) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
		}

		*atmf5_diagnostics = t_ptr;
       */
		if(*atmf5_diagnostics == NULL) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		*(*atmf5_diagnostics + atmf5_count) = t_atmf5;
		atmf5_count++;
	}
	*num_entries = atmf5_count;

IFX_Handler:
	if(ret != IFX_SUCCESS) {
		*num_entries = 0;
		IFX_MEM_FREE(*atmf5_diagnostics)
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}


int32 ifx_get_atmf5_loop_diagnostics(WAN_ATMF5_LOOP_DIAGNOSTICS *atmf5_diagnostics, uint32 flags)
{
	char8	buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	uint32	outFlag = IFX_F_DEFAULT;
	int32	dist_wan_index = -1, ret = IFX_SUCCESS;

	sprintf(atmf5_diagnostics->iid.cpeId.secName, "%s", TAG_WAN_ATMF5);
	sprintf(atmf5_diagnostics->iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);

	if(ifx_get_index_from_cpe_id(FILE_RC_CONF, &atmf5_diagnostics->iid.cpeId, &dist_wan_index) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

	/* initialize the cache for this instance */
	sprintf(buf, "%s_%d_", PREFIX_WAN_ATMF5, dist_wan_index);
	if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5, buf, IFX_F_INT_CACHE_INIT | flags, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	sprintf(buf, "%s_%d_pcpeId", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5, 
					buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	else
		atmf5_diagnostics->iid.pcpeId.Id = atoi(sValue);

	sprintf(buf, "%s_%d_fEnable", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5, 
					buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	else
		atmf5_diagnostics->f_enable = atoi(sValue);

	sprintf(buf, "%s_%d_vpi", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5, 
					buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	else
		atmf5_diagnostics->vpi = atoi(sValue);

	sprintf(buf, "%s_%d_vci", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5, 
					buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	else
		atmf5_diagnostics->vci = atoi(sValue);

	sprintf(buf, "%s_%d_scope", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5, 
					buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	else
		atmf5_diagnostics->scope = atoi(sValue);

	sprintf(buf, "%s_%d_diagnosticState", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5, 
					buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	else
		atmf5_diagnostics->diagnostic_state = atoi(sValue);

	sprintf(buf, "%s_%d_timeout", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5, 
					buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	else
		atmf5_diagnostics->ping_timeout = atoi(sValue);

	sprintf(buf, "%s_%d_pingCount", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5, 
					buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	else
		atmf5_diagnostics->oam_pings = atoi(sValue);

	sprintf(buf, "%s_%d_loopback", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5, 
					buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	else
		atmf5_diagnostics->loopback = atoi(sValue);

	sprintf(buf, "%s_%d_contCheck", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5, 
					buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	else
		atmf5_diagnostics->cc_check = atoi(sValue);

	sprintf(buf, "%s_%d_contCheckOpt", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5, 
					buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	else
		/* Map the continuity check option value from {1,2,3} to {0,1,2} as understood by the enums */
		atmf5_diagnostics->cc_check_opt = (atoi(sValue) - 1);

	sprintf(buf, "%s_%d_successCount", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5, 
					buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	else
		atmf5_diagnostics->success_count = atoi(sValue);

	sprintf(buf, "%s_%d_failureCount", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5, 
					buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	else
		atmf5_diagnostics->failure_count = atoi(sValue);

	sprintf(buf, "%s_%d_minRespTime", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5, 
					buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	else
		atmf5_diagnostics->min_resp_time = atoi(sValue);

	sprintf(buf, "%s_%d_maxRespTime", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5, 
					buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	else
		atmf5_diagnostics->max_resp_time = atoi(sValue);

	sprintf(buf, "%s_%d_avgRespTime", PREFIX_WAN_ATMF5, dist_wan_index);
	if ((ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5, 
					buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
	}
	else
		atmf5_diagnostics->avg_resp_time = atoi(sValue);

IFX_Handler:
	/* destroy the cache for this instance */
	sprintf(buf, "%s_%d_", PREFIX_WAN_ATMF5, dist_wan_index);
	if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_ATMF5, buf, IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to destory cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}
#endif

#ifndef CONFIG_PACKAGE_IFX_DSL_CPE_API
int32 ifx_get_wan_dsl_diagnostics(WAN_DSL_DIAGNOSTICS *Wan_Dsl_Diag, uint32 flags)
{
	int32	i = 0, j = 0, ret = IFX_SUCCESS;
	uint32	outFlag = IFX_F_DEFAULT;
	char8	buf[MAX_FILELINE_LEN], sValue[MAX_DATA_LEN];
	char8	*read_ptr = NULL, *t_ptr = NULL, *pptr = NULL;

//	 initialize the cache for this instance 
	sprintf(buf, "%s_",PREFIX_DSL_DIAG);
	if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, IFX_F_INT_CACHE_INIT | flags, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	sprintf(buf, "%s_cpeId", PREFIX_DSL_DIAG);
    if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
	}
	Wan_Dsl_Diag->iid.cpeId.Id = atoi(sValue);

	sprintf(buf, "%s_pcpeId", PREFIX_DSL_DIAG);
    if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
	}
	Wan_Dsl_Diag->iid.pcpeId.Id = atoi(sValue);

	sprintf(Wan_Dsl_Diag->iid.cpeId.secName, "%s", TAG_DSL_DIAG);
	sprintf(Wan_Dsl_Diag->iid.cpeId.secName, "%s", TAG_WAN_DEVICE);

	sprintf(buf, "%s_fEnable", PREFIX_DSL_DIAG);
    if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
	}
	Wan_Dsl_Diag->f_enable = atoi(sValue);

	sprintf(buf, "%s_diagnosticState", PREFIX_DSL_DIAG);
    if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
	}
	Wan_Dsl_Diag->diagnostic_state = atoi(sValue);

	sprintf(buf, "%s_ACTPSDds", PREFIX_DSL_DIAG);
    if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
	}
	Wan_Dsl_Diag->ACTPSDds = atoi(sValue);

	sprintf(buf, "%s_ACTPSDus", PREFIX_DSL_DIAG);
    if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
	}
	Wan_Dsl_Diag->ACTPSDus = atoi(sValue);

	sprintf(buf, "%s_ACTATPds", PREFIX_DSL_DIAG);
    if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
	}
	Wan_Dsl_Diag->ACTATPds = atoi(sValue);

	sprintf(buf, "%s_ACTATPus", PREFIX_DSL_DIAG);
    if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
	}
	Wan_Dsl_Diag->ACTATPus = atoi(sValue);

	sprintf(buf, "%s_HLINSCds", PREFIX_DSL_DIAG);
    if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
	}
	Wan_Dsl_Diag->HLINSCds = atoi(sValue);

	j = 0;
	for(i=0; i<32; i++) {
		sprintf(buf, "%s_HLINpsds_%d", PREFIX_DSL_DIAG, i);
    	if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
		}
		read_ptr = sValue;
		t_ptr = strtok_r(read_ptr, ",", &pptr);
		while(t_ptr != NULL) {
			Wan_Dsl_Diag->HLINpsds[j++] = atoi(t_ptr);
			t_ptr = strtok_r(NULL, ",", &pptr);
		}
	}

	j = 0;
	for(i=0; i<16; i++) {
		sprintf(buf, "%s_QLNpsds_%d", PREFIX_DSL_DIAG, i);
    	if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
		}
		read_ptr = sValue;
		t_ptr = strtok_r(read_ptr, ",", &pptr);
		while(t_ptr != NULL) {
			Wan_Dsl_Diag->QLNpsds[j++] = atoi(t_ptr);
			t_ptr = strtok_r(NULL, ",", &pptr);
		}
	}

	j = 0;
	for(i=0; i<16; i++) {
		sprintf(buf, "%s_SNRpsds_%d", PREFIX_DSL_DIAG, i);
    	if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
		}
		read_ptr = sValue;
		t_ptr = strtok_r(read_ptr, ",", &pptr);
		while(t_ptr != NULL) {
			Wan_Dsl_Diag->SNRpsds[j++] = atoi(t_ptr);
			t_ptr = strtok_r(NULL, ",", &pptr);
		}
	}

	j = 0;
	for(i=0; i<16; i++) {
		sprintf(buf, "%s_BITpsds_%d", PREFIX_DSL_DIAG, i);
    	if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
		}
		read_ptr = sValue;
		t_ptr = strtok_r(read_ptr, ",", &pptr);
		while(t_ptr != NULL) {
			Wan_Dsl_Diag->BITSpsds[j++] = atoi(t_ptr);
			t_ptr = strtok_r(NULL, ",", &pptr);
		}
	}

	j = 0;
	for(i=0; i<16; i++) {
		sprintf(buf, "%s_GAINpsds_%d", PREFIX_DSL_DIAG, i);
    	if ((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_DSL_DIAG, buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
				goto IFX_Handler;
		}
		read_ptr = sValue;
		t_ptr = strtok_r(read_ptr, ",", &pptr);
		while(t_ptr != NULL) {
			Wan_Dsl_Diag->GAINSpsds[j++] = atoi(t_ptr);
			t_ptr = strtok_r(NULL, ",", &pptr);
		}
	}

IFX_Handler:
	/* destroy the cache for this instance */
	sprintf(buf, "%s_",PREFIX_DSL_DIAG);
	if(ifx_GetObjDataOpt(FILE_RC_CONF,TAG_DSL_DIAG, buf, IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to destroy cache for this instance", __FUNCTION__, __LINE__);
		#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}
#endif //!CONFIG_PACKAGE_IFX_DSL_CPE_API

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_default_wan_if(...)
*    	iid		==>  output ifx_id structure which will have the cpeid and parent cpeid of 
*				the default wan connection
*    	wan_index	==>  index of the default wan connection in wan_main section
*		flags	==>		
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function returns the cpeID, pcpeId and wan_index for the default
			WAN connection configured in the system
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_default_wan_if(IFX_ID *iid, int32 *wan_index, uint32 flags)
{
	int32	ret = IFX_SUCCESS;
	uint32	outFlag = IFX_F_DEFAULT;
	char8	*retStr = NULL;
	char8	*sIdx = NULL;
	char8	wan_connName[MAX_FILELINE_LEN];
	char8 sCommand[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN], def_iface[IFNAMSIZE];

	NULL_TERMINATE(wan_connName,0x00, sizeof(wan_connName));
	NULL_TERMINATE(sCommand,0x00, sizeof(sCommand));
	NULL_TERMINATE(def_iface,0x00, sizeof(def_iface));

	/* read the rc.conf for default_wan_iface section */
	sprintf(sCommand, "%s", "default_wan_conn_connName");
	if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_DEFAULT_WAN, sCommand, IFX_F_GET_ANY, &outFlag, sValue)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Default Wan ConnName not found", __FUNCTION__, __LINE__);
		#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* get the conn_name and form the distinct connName=value pair */
	sprintf(wan_connName, "%s", sValue);
	ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_MAIN, "connName", wan_connName, &retStr);
	if(ret != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve wan_X index", __FUNCTION__, __LINE__);
		#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/* get the wan index out of the return string which is of the format wan_{index} */
	sIdx = strrchr(retStr, '_') + 1;
	if(sIdx == NULL)
	{
		*wan_index = -1;
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve wan index", __FUNCTION__, __LINE__);
		#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	else
		*wan_index = atoi(sIdx);

	/* get the cpeid and parent cpeid of the default wan connection */
	sprintf(sCommand, "%s_cpeId", retStr);
	if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, sCommand, IFX_F_GET_ANY, &outFlag, sValue)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve cpe Id", __FUNCTION__, __LINE__);
		#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	iid->cpeId.Id = atoi(sValue);

	sprintf(sCommand, "%s_pcpeId", retStr);
	if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, sCommand, IFX_F_GET_ANY, &outFlag, sValue)) != IFX_SUCCESS)
	{
		#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Unable to retrieve parent cpe Id", __FUNCTION__, __LINE__);
		#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	iid->pcpeId.Id = atoi(sValue);

	/* copy the object section and parent section names to ouput IFX_ID */
	snprintf(iid->cpeId.secName, strlen(TAG_WAN_MAIN) + 1, "%s", TAG_WAN_MAIN);
	snprintf(iid->pcpeId.secName, strlen(TAG_WAN_CONN_DEVICE) + 1, "%s", TAG_WAN_CONN_DEVICE);

IFX_Handler:
	IFX_MEM_FREE(retStr)
	if(ret != IFX_SUCCESS)
	{
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;

}



/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_vcc_encap_type(...)
*		vc			==> 	specifies vpi and vci values for which the link type has to be modified
*		type		==>		specified the new vcc encap value
*    	flags		==>   flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
					This api takes the link type which has to be asscoiated with the vc having tha vpi/vci value pair
					it first checks if the vc is present, if present it does the updation and returns IFX_SUCCESS
					otherwise returns IFX_FAILURE.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_vcc_encap_type(char *vpivci, VC_ENCAP type, uint32 flags)
{
    int32   ret = IFX_SUCCESS;
    char8   conf_buf[MAX_DATA_LEN], *retStr = NULL;

    NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));

    ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, "vcc", vpivci, &retStr);
    if(ret != IFX_SUCCESS)
    {
        goto IFX_Handler;
    }
    sprintf(conf_buf, "%s_encap=\"%d\"\n", retStr, type);
    ret = ifx_SetObjData(FILE_RC_CONF, TAG_ADSL_VCCHANNEL, flags, 1, conf_buf);
    if(ret != IFX_SUCCESS)
    {
        goto IFX_Handler;
    }

IFX_Handler:
    IFX_MEM_FREE(retStr)
    if(ret != IFX_SUCCESS)
    {
        IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
        return ret;
    }
    else
        return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_wan_eth_config(...)
*     operation      ==>     specifies the operation to be done such as ADD, DELETE or MODIFY
*     wan_cfg        ==>     pointer to WAN_CONN_CFG structure which will store the common parameters of the wan
*                            connection and the wan ip/ppp specific parameters
*       flags        ==>      flags that define the behaviour
*
*     Return Value :   IFX_SUCCESS or IFX_FAILURE
*     Description:
*                    The api adds, deletes or modifies a wan connection. the api will store the wan connection over two
*                    sections in rc.conf, wan_main (common parameters) and wan_ip (ip specific parameters)
*                    or wan_ppp (ppp specific parameters). 
*                    the caller should pass the vcc value in the structue, the api assumes that the caller will
*                    pass the vcc also if he is passing the parent cpeid. The api calls respective ip or ppp set apis
*                    for add/modify/delete opeartion only based on the link type. The check has been provided to avoid
*                    any of the two api call for a disable operation. The api assumes that the adaptation has the 
*                    validation to avoid modify operation on a wan ip connection to wan ppp connection and vice-versa.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_wan_eth_config(int32 operation, WAN_CONN_CFG *wan_cfg, uint32 flags)
{
#ifdef CONFIG_FEATURE_ETH_WAN_SUPPORT
    char8    wanVCC[20];
    char8    wan_conn_name[MAX_CONN_NAME_LEN];
    char8    cpeIDValStr[20];
    char8    *ret_WANStr = NULL, *ret_WANConnDevStr = NULL;
    IFX_ID   parent_iid, iid;
    int32    dist_wan_index = -1;
    int32    wan_index = 0;
    IFX_NAME_VALUE_PAIR wan_main_array_fvp[34];
    uint32   wan_main_fvp_count = 0;
    IFX_NAME_VALUE_PAIR *wan_main_changed_array_fvp = NULL;
    uint32   wan_main_changed_fcount = 0;
    char8    buf[MAX_DATA_LEN], conf_buf[MAX_FILELINE_LEN];
    int32    ret=IFX_SUCCESS;
    int32    phy_mode=-1, mii1_vlan_mode=-1;
    int32    outFlag = IFX_F_DEFAULT;
    char8    sValue[MAX_FILELINE_LEN];
    WAN_CONN_CFG old_wan_cfg;
    char8    retVal[20];
    WAN_COMMON_CFG wan_comm_cfg;
    char8    sWan_IP[MAX_IP_ADDR_LEN], sWan_Mask[MAX_IP_ADDR_LEN];
    char8    dns_servers[MAX_DNS_SERVERS * MAX_IP_ADDR_LEN];
    int32    i = 0;
    char8    tempBuf[16],* RetStr = NULL;

    NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
    NULL_TERMINATE(wanVCC, 0, sizeof(wanVCC));
    NULL_TERMINATE(cpeIDValStr, 0, sizeof(cpeIDValStr));
    NULL_TERMINATE(sWan_IP, 0x00, sizeof(sWan_IP));
    NULL_TERMINATE(sWan_Mask, 0x00, sizeof(sWan_Mask));
    NULL_TERMINATE(tempBuf, 0x00, sizeof(tempBuf));
    memset(&wan_main_array_fvp, 0, sizeof(wan_main_array_fvp));
    memset(&wan_comm_cfg, 0x00, sizeof(wan_comm_cfg));
    memset(&old_wan_cfg, 0x00, sizeof(old_wan_cfg));
    memset(&parent_iid, 0, sizeof(parent_iid));
    memset(&iid, 0, sizeof(iid));

    /*************** Prolog Block *********************/
    /* Set the flags based on operation */
    if (operation == IFX_OP_DEL) 
        flags |= IFX_F_DELETE;
    else if (operation == IFX_OP_MOD)
        flags |= IFX_F_MODIFY;
    else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
    {
        flags |= IFX_F_INT_ADD;
    }

    if( IFX_DONT_VALIDATE_F_NOT_SET(flags))
    {
        /* 1. Check whether the WAN_CONN_CFG is NULL, if so it's an Error!
        Also check on valid flags condition */
        IFX_VALIDATE_PTR(wan_cfg)
        IFX_VALIDATE_FLAGS(flags)
    }
	
    /*************** Prolog Block Continued *********************/
    /* Determine the WAN's parent Section from the pcpeId if it is
     * passed or from VCC otherwise (incase of WEB/CLI configuration 
    */
    iid = wan_cfg->iid;
    if (iid.pcpeId.Id == 0)
    {
       #ifdef IFX_LOG_DEBUG
       IFX_DBG("[%s:%d] Invalid parent cpe Id", __FUNCTION__, __LINE__);
       #endif
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    sprintf(iid.cpeId.secName, "%s", TAG_WAN_MAIN);

    /* Parent's cpeId is specified, fill in the parent section which is WAN_CONN_DEVICE now */
    sprintf(iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);

    /* Update the Parent's cpeID and Section Name in piid
    * This would be required only for ADD operation */
    parent_iid.cpeId.Id = iid.pcpeId.Id;
    sprintf(parent_iid.cpeId.secName, "%s", iid.pcpeId.secName);

    /* Determine the WAN Connection Type - WAN_IP or WAN_PPP from
     * the link type associated with the WAN device */
    if(wan_cfg->type == LINK_TYPE_PPPOE)
    {
        wan_comm_cfg = wan_cfg->WAN_PPP_CONN.WAN_CONN;
    }
    else
    {
        /* Case of UnConfigured is assumed to be WAN_IP */
        wan_comm_cfg = wan_cfg->WAN_IP_CONN.WAN_CONN;
    }
#if 0
    if((wan_cfg->vc.pvc.vpi != 0) || (wan_cfg->vc.pvc.vci != 0))
    {
       #ifdef IFX_LOG_DEBUG
       IFX_DBG("[%s:%d] Invalid VCC vpi[%d], vci [%d]", __FUNCTION__, __LINE__, wan_cfg->vc.pvc.vpi, wan_cfg->vc.pvc.vci);
       #endif
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }
#endif
    //sprintf(wanVCC, "%d/%d", wan_cfg->vc.pvc.vpi, wan_cfg->vc.pvc.vci);
    sprintf(wanVCC, "256/0");
    /**************** Validation Block *****************/
    /* For Operations other than DELETE perform the following validation on input params */
    if( IFX_DONT_VALIDATE_F_NOT_SET(flags))
    {
        if (IFX_DELETE_F_NOT_SET(flags))
        {
            /* MANDATORY CHECK:
            * Check if the wan_Connection Name is unique across WAN IP and PPP
            * We assume that the wan_Connection Name must be unique across
            * all connections ! */
            NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
            STRNCPY(conf_buf, wan_comm_cfg.WAN_CONN_NAME, strlen(wan_comm_cfg.WAN_CONN_NAME));

            /* Check if the wanConnName is configured, then it MUST be unique for any ADD Operation */	
            if ((strcmp(conf_buf, "")) && (IFX_INT_ADD_F_SET(flags)))
            {	
                ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_MAIN, "connName", conf_buf, &ret_WANStr);
                if(ret == IFX_SUCCESS)
                {
                    #ifdef IFX_LOG_DEBUG
                    IFX_DBG("[%s:%d] Error. connName[%s] should be unique", __FUNCTION__, __LINE__,ret_WANStr);
                    #endif
                    ret = IFX_FAILURE;
                    goto IFX_Handler;
                }	
            }
            /* Sanity check: an ethernet channel should be present with the same parent cpe Id*/
            sprintf(tempBuf, "%d", iid.pcpeId.Id);
            ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_ETH_CHANNEL, "pcpeId", tempBuf, &RetStr);
            if(ret != IFX_SUCCESS)
            {
                #ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] Corresponding Eth channel not present", __FUNCTION__, __LINE__);
                #endif
                ret = IFX_FAILURE;
                goto IFX_Handler;
            }
						#if 0
						TODO : this needs to be enabled
            /*Eth Channel present. vlan Id of the eth channel and wan section should match*/
            NULL_TERMINATE(tempBuf, 0x00, sizeof(tempBuf));
            sprintf(tempBuf, "%s_%s", RetStr, "vlanId");
            if((ifx_GetObjData(FILE_RC_CONF, TAG_ETH_CHANNEL, tempBuf, IFX_F_GET_ANY,
                                                        &outFlag, sValue)) != IFX_SUCCESS)
            {
                #ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] Vlan Id not found", __FUNCTION__, __LINE__);
                #endif
                ret = IFX_FAILURE;
                goto IFX_Handler;
            }
            if(atoi(sValue) != wan_cfg->vlanId)
	    {
                #ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] Vlan Id doesnt match", __FUNCTION__, __LINE__);
                #endif
                ret = IFX_FAILURE;
                goto IFX_Handler;
            }
						#endif // 0
        }
    }

    /**************** ID Allocation Block - Only for ADD Operation **************/
    if (IFX_INT_ADD_F_SET(flags))
    {
        /* Form tag of parent section and get cpeId
        * Allocate iid for Add */
        memset(&iid, 0x00, sizeof(iid));
        if (ifx_get_iid(TAG_WAN_MAIN, TAG_WAN_CONN_DEVICE, &parent_iid, &iid) != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Unable to get IID", __FUNCTION__, __LINE__);
            #endif
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }

        /* Check if wan_index is passed or not
        * If not passed then get unused wan_index - for ADD */
        if (wan_cfg->wan_index <= 0)
        {
            if (ifx_get_available_distinct_index(FILE_RC_CONF, TAG_WAN_MAIN, "index", 
                            MIN_WAN_INDEX, MAX_WAN_INDEX, &dist_wan_index) != IFX_SUCCESS)
            {
                #ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] Unable to allocate wan index", __FUNCTION__, __LINE__);
                #endif
                ret = IFX_FAILURE;
                goto IFX_Handler;
            }
            else
                wan_cfg->wan_index = dist_wan_index;
        }
    }

    /* Update the allocated IID in WAN CONNECTION */
    wan_cfg->iid.cpeId = iid.cpeId;
    wan_cfg->iid.pcpeId = iid.pcpeId;

    /* Get WAN Index in case of modify/delete operations from CPEID */
    if((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags)))
    {
        /* If WAN index is not specified, only then get the wan Index
		* from cpeId, else use the wan_index passed */
        if (wan_cfg->wan_index <= 0)
        {
            IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wan_cfg->iid.cpeId, wan_index)

            /* Update the wan index in WAN CONFIG structure */
            wan_cfg->wan_index = wan_index;
        }

        /* Populate the OLD WAN Connection config structure for MODIFY*/
        old_wan_cfg.wan_index = wan_cfg->wan_index;
        old_wan_cfg.iid = wan_cfg->iid;
        /* Check the LinkType for the given wan_index and invoke the
        * appropriate function */
        NULL_TERMINATE(buf, 0x00, sizeof(buf));
        NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
        sprintf(buf, "wan_%d_linkType", old_wan_cfg.wan_index);
        if((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, IFX_F_GET_ANY, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Unable to retrieve link type from rc.conf", __FUNCTION__, __LINE__);
            #endif
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }
        old_wan_cfg.type = atoi(retVal);
		
        if (old_wan_cfg.type == WAN_LINK_TYPE_PPPOE)
        { 	
            if (ifx_get_wan_ppp_config(old_wan_cfg.wan_index,&old_wan_cfg, IFX_F_GET_ANY) != IFX_SUCCESS)
            {
                #ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] Unable to retrieve old wan_ppp configuration", __FUNCTION__, __LINE__);
                #endif
                ret = IFX_FAILURE;
                goto IFX_Handler;
            }
        }
        else
        {
            if (ifx_get_wan_ip_config(old_wan_cfg.wan_index, &old_wan_cfg, IFX_F_GET_ANY) != IFX_SUCCESS)
            {
                #ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] Unable to retrieve old wan_ip configuration", __FUNCTION__, __LINE__);
                #endif
                ret = IFX_FAILURE;
                goto IFX_Handler;
            }
        }
    }

    /**************** Name Value Formation as per RC.CONF ********************/
    /* Form the name-value pairs for ACL Checking & Validation */
    if(IFX_DELETE_F_NOT_SET(flags))
    {
        sprintf(wan_conn_name, "%s%d", "WAN", wan_cfg->wan_index);
        if(wan_comm_cfg.WAN_CONN_DNS_OVERRIDE == IFX_DISABLED)
        {
            memset(dns_servers, 0x00, sizeof(dns_servers));
            for(i=0; i<MAX_DNS_SERVERS; i++)
            {
                strcat(dns_servers, inet_ntoa(wan_comm_cfg.dns_servers[i]));
                if(i < (MAX_DNS_SERVERS - 1))
                {
                    /* check if next dns ip value is 0.0.0.0 */
                    if(strcmp(inet_ntoa(wan_comm_cfg.dns_servers[i+1]), "0.0.0.0")) 
                        strcat(dns_servers, ","); /* if it is not 0.0.0.0, add it to the end of the list */
                    else
                        break; /* if its is 0.0.0.0 break out of the loop */
                }
            }
        }

        sprintf(sWan_IP, "%s", (char8 *)inet_ntoa(wan_comm_cfg.WAN_CONN_IPADDR));
        sprintf(sWan_Mask, "%s", (char8 *)inet_ntoa(wan_comm_cfg.WAN_CONN_IPMASK));

        ifx_fill_ArrayFvp_FName(wan_main_array_fvp, 0, 23, wan_main_param_names);

        ifx_fill_ArrayFvp_intValues(wan_main_array_fvp, 0, 14, (int32 *)&wan_cfg->iid.cpeId.Id, &wan_cfg->iid.pcpeId.Id, &wan_comm_cfg.WAN_CONN_ENABLE, &wan_cfg->type, &wan_comm_cfg.WAN_CONN_AUTO_DISCONNECT_TIME, &wan_comm_cfg.WAN_CONN_IDLE_DISCONNECT_TIME, &wan_comm_cfg.WAN_CONN_WARN_DISCONNECT_TIME, &wan_comm_cfg.WAN_CONN_RSIP_AVAILABLE, &wan_comm_cfg.WAN_CONN_NAT_ENABLED, &wan_comm_cfg.WAN_CONN_DNS_ENABLED, &wan_comm_cfg.WAN_CONN_DNS_OVERRIDE, &wan_comm_cfg.WAN_CONN_MAC_ADDR_OVERRIDE, &wan_comm_cfg.WAN_CONN_TRIGGER, &wan_comm_cfg.WAN_CONN_ROUTE_PROTO_RX);

        ifx_fill_ArrayFvp_strValues(wan_main_array_fvp, 14, 7, "256/0", sWan_IP, sWan_Mask, strcmp(wan_comm_cfg.WAN_CONN_NAME, "")?wan_comm_cfg.WAN_CONN_NAME:wan_conn_name, strcmp(wan_comm_cfg.WAN_CONF_CONN_NAME, "")?wan_comm_cfg.WAN_CONF_CONN_NAME:wan_conn_name, (wan_comm_cfg.WAN_CONN_DNS_OVERRIDE == IFX_DISABLED)?dns_servers:"0.0.0.0", strlen(wan_comm_cfg.WAN_CONN_MAC_ADDR)?wan_comm_cfg.WAN_CONN_MAC_ADDR:"");

                                IFX_DBG("[%s:%d] wan mode [%d]", __FUNCTION__, __LINE__, wan_cfg->wan_mode.mode);
        sprintf(wan_main_array_fvp[21].value, "%d", wan_cfg->wan_mode.mode);
        ifx_fill_ArrayFvp_intValues(wan_main_array_fvp, 22, 1, &wan_cfg->vlanId);

        sprintf(wan_main_array_fvp[23].fieldname, "%s", "iface");
        sprintf(wan_main_array_fvp[24].fieldname, "%s", "ifType");

	if (ifx_GetObjData(FILE_RC_CONF, "wan_phy_cfg", "wanphy_phymode", IFX_F_GET_ANY, (IFX_OUT uint32 *)&outFlag, sValue) !=  IFX_SUCCESS) {// Get Global mode
       	                        #ifdef IFX_LOG_DEBUG
                                IFX_DBG("[%s:%d] Failed to obtain global mode", __FUNCTION__, __LINE__);
                                #endif
                                ret = IFX_FAILURE;
                                goto IFX_Handler;

	}
        else {
        	phy_mode=atoi(sValue);//Global Mode
        }
#if !defined(PLATFORM_AMAZON_SE)  && !defined(PLATFORM_DANUBE)
	if (ifx_GetObjData(FILE_RC_CONF, "wan_phy_cfg", "wanphy_mii1ethVlanMode", IFX_F_GET_ANY, (IFX_OUT uint32 *)&outFlag, sValue) !=  IFX_SUCCESS) {// Get MII1 VLAN Support Mode
       	                        #ifdef IFX_LOG_DEBUG
                                IFX_DBG("[%s:%d] Failed to obtain MII1 VLAN mode", __FUNCTION__, __LINE__);
                                #endif
                                ret = IFX_FAILURE;
                                goto IFX_Handler;

	}
        else {
        	mii1_vlan_mode=atoi(sValue);//MII1 VLAN Support Mode
        }
#else
	mii1_vlan_mode=0;
#endif
	
	if(!wan_cfg->vlanId){
		if((phy_mode == 2) && (mii1_vlan_mode == 1) )//MII1 mode and VLAN support is disabled
			sprintf(wan_main_array_fvp[23].value, "%s", wan_cfg->wan_mode.iface);
		else
                        sprintf(wan_main_array_fvp[23].value, "%s.100", wan_cfg->wan_mode.iface);
	}
        else
        	sprintf(wan_main_array_fvp[23].value, "%s.%d", wan_cfg->wan_mode.iface , wan_cfg->vlanId );

        if(wan_cfg->type == LINK_TYPE_PPPOE)
        {
            sprintf(wan_main_array_fvp[24].value, "%s", "ppp");
        }
        else
        {
            sprintf(wan_main_array_fvp[24].value, "%s", "eth");
        }

        /* AMS */
        sprintf(wan_main_array_fvp[25].fieldname, "%s", "ipv4");
        sprintf(wan_main_array_fvp[26].fieldname, "%s", "ipv6");
        sprintf(wan_main_array_fvp[27].fieldname, "%s", "dhcpv6State");
        sprintf(wan_main_array_fvp[28].fieldname, "%s", "ianaID");
        sprintf(wan_main_array_fvp[29].fieldname, "%s", "iapdID");
        sprintf(wan_main_array_fvp[30].fieldname, "%s", "slaID");
        sprintf(wan_main_array_fvp[31].fieldname, "%s", "rapid");
	sprintf(wan_main_array_fvp[32].fieldname, "%s", "tunnel");
        ifx_fill_ArrayFvp_intValues(wan_main_array_fvp, 25, 8, &wan_cfg->ipv4, &wan_cfg->ipv6, &wan_cfg->dhcp_mode,
                     &wan_cfg->iana, &wan_cfg->iapd, &wan_cfg->slaid, &wan_cfg->rapid, &wan_cfg->tunnel); //AMS
        
    }

    wan_main_fvp_count = 33; 
	
    /* Form the fully qualified Name Value Pairs */
    if(ifx_get_conf_index_and_nv_pairs(&wan_cfg->iid, wan_cfg->wan_index, PREFIX_WAN_MAIN, 
                            wan_main_fvp_count, wan_main_array_fvp, flags) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to form the Name value pairs", __FUNCTION__, __LINE__);
        #endif
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    /************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
    /* Ignore the "ifnas" and "ifType" in WAN MAIN for ACL 
     * Hence count should be (count - 2)
     */
    CHECK_ACL_RET(wan_cfg->iid, (wan_main_fvp_count-2), wan_main_array_fvp,
        wan_main_changed_fcount, wan_main_changed_array_fvp, flags, IFX_Handler)

    /********* System Config File Update Block  **********/
    /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
    memset(buf, 0x00, sizeof(buf));
    form_cfgdb_buf(buf, wan_main_fvp_count, wan_main_array_fvp);

    ret = IFX_SUCCESS;
    if (operation == IFX_OP_ADD)
    {
        /* Update wan_main section in rc.conf*/
        ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_MAIN, flags, 1, buf);
        if(ret != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] ifx_SetObjData() Fail", __FUNCTION__, __LINE__);
            #endif
            goto IFX_Handler;
        }

        wan_comm_cfg.WAN_CONN_IID = wan_cfg->iid;

        if (wan_cfg->type == LINK_TYPE_PPPOE)
        {
            /* Invoke the WAN PPP Configuration function */
            strcpy(wan_comm_cfg.WAN_CONN_IID.cpeId.secName, TAG_WAN_PPP);
            /* Pramod - need to fill IID inside PPP structure also */
            wan_cfg->WAN_PPP_CONN.WAN_CONN.WAN_CONN_IID = wan_comm_cfg.WAN_CONN_IID; 

            if((ret = ifx_set_wan_ppp_config(operation, wan_cfg->wan_index, &wan_cfg->WAN_PPP_CONN,
						       (flags | IFX_F_DONT_CHECKPOINT))) != IFX_SUCCESS)
            {
                #ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] ifx_set_wan_ppp_config() Fail", __FUNCTION__, __LINE__);
                #endif
                goto IFX_Handler;
            }

            /* Copy the tr69id field from ip connection tr69id, because the tr69id 
            allocation will happen in ip set api */
            if(wan_cfg->iid.config_owner == IFX_WEB)
            {
	        STRNCPY(wan_comm_cfg.WAN_CONN_IID.tr69Id, wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IID.tr69Id, 
		strlen(wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IID.tr69Id));
            }
        }
        else if (wan_cfg->type == LINK_TYPE_ETH)
        {
            /* Invoke the WAN IP Configuration function 
             * Update the WAN_COMMON_CFG IID structure value from WAN_CONN_CFG IID 
             * Update the CPEID to WAN_IP Section
            */
            strcpy(wan_comm_cfg.WAN_CONN_IID.cpeId.secName, TAG_WAN_IP);
            /* Pramod - need to fill IID inside IP structure also */
            wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IID = wan_comm_cfg.WAN_CONN_IID; 

            if ((ret = ifx_set_wan_ip_config(operation, wan_cfg->wan_index,	&wan_cfg->WAN_IP_CONN, (flags | IFX_F_DONT_CHECKPOINT))) != IFX_SUCCESS)
            {
                /* ??? Is this flags ORING Required ??? */
                #ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] ifx_set_wan_ip_config() Fail", __FUNCTION__, __LINE__);
                #endif
                goto IFX_Handler;
            }

            /* Copy the tr69id field from ip connection tr69id, because the tr69id 
            allocation will happen in ip set api */
            if(wan_cfg->iid.config_owner == IFX_WEB)
            {
                STRNCPY(wan_comm_cfg.WAN_CONN_IID.tr69Id, wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IID.tr69Id, 
                strlen(wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IID.tr69Id));
	    }
	}
    }
    else if (operation == IFX_OP_MOD)
    {
        if (old_wan_cfg.type == LINK_TYPE_PPPOE)
        {
            /* Invoke the WAN PPP Configuration function */
            old_wan_cfg.WAN_PPP_CONN.WAN_CONN.WAN_CONN_IID = old_wan_cfg.iid;
            strcpy(old_wan_cfg.WAN_PPP_CONN.WAN_CONN.WAN_CONN_IID.cpeId.secName, TAG_WAN_PPP);


            /* check the state of this object, if enabled then only call the api to stop with the current config */
            sprintf(conf_buf, "%s_%d_cpeId", PREFIX_WAN_PPP, old_wan_cfg.wan_index);
            if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP,
			conf_buf, IFX_F_GET_ENA, (IFX_OUT uint32 *)&outFlag, sValue) == IFX_SUCCESS)
            {
                if ((ret = ifx_set_wan_ppp_config(operation, old_wan_cfg.wan_index, &old_wan_cfg.WAN_PPP_CONN,
						(flags | IFX_F_DEACTIVATE | IFX_F_DONT_VALIDATE))) != IFX_SUCCESS)
                {
                    #ifdef IFX_LOG_DEBUG
                    IFX_DBG("[%s:%d]  Deactivate old PPP connection Fail", __FUNCTION__, __LINE__);
                    #endif
                    goto IFX_Handler;
                }
            }
        }
        else
        {
            /* Invoke the WAN IP Configuration function 
             * Update the WAN_COMMON_CFG IID structure value from WAN_CONN_CFG IID 
             * Update the CPEID to WAN_IP Section
            */
	    old_wan_cfg.WAN_IP_CONN.WAN_CONN.WAN_CONN_IID = old_wan_cfg.iid;
	    strcpy(old_wan_cfg.WAN_IP_CONN.WAN_CONN.WAN_CONN_IID.cpeId.secName, TAG_WAN_IP);

            /* check the state of this object, if enabled then only call the api to stop with the current config */
	    sprintf(conf_buf, "%s_%d_cpeId", PREFIX_WAN_IP, old_wan_cfg.wan_index);
	    if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, conf_buf, IFX_F_GET_ENA, (IFX_OUT uint32 *)&outFlag, sValue) == IFX_SUCCESS)
            {
		if((ret = ifx_set_wan_ip_config(operation, old_wan_cfg.wan_index, &old_wan_cfg.WAN_IP_CONN,
                            (flags | IFX_F_DEACTIVATE | IFX_F_DONT_VALIDATE))) != IFX_SUCCESS)
                {
                    #ifdef IFX_LOG_DEBUG
                    IFX_DBG("[%s:%d] Deactivate old IP connection Fail", __FUNCTION__, __LINE__);
                    #endif
                    goto IFX_Handler;
                }
            }
        }

	/* Now update rc.conf with the new configuration */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_MAIN, flags, 1, buf);
	if(ret != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
	    IFX_DBG("[%s:%d] ifx_SetObjData() Fail", __FUNCTION__, __LINE__);
            #endif
	    goto IFX_Handler;
	}

	wan_comm_cfg.WAN_CONN_IID = wan_cfg->iid;

	if (wan_cfg->type == LINK_TYPE_PPPOE)
        {
	    /* Invoke the WAN PPP Configuration function */
	    strcpy(wan_comm_cfg.WAN_CONN_IID.cpeId.secName, TAG_WAN_PPP);
	    wan_cfg->WAN_PPP_CONN.WAN_CONN.WAN_CONN_IID = wan_comm_cfg.WAN_CONN_IID; /* Pramod - need to fill IID inside
	                                                                             PPP structure also */
            if ((ret = ifx_set_wan_ppp_config(operation, wan_cfg->wan_index, &wan_cfg->WAN_PPP_CONN,
							(flags | IFX_F_MODIFY))) != IFX_SUCCESS)
            {
                #ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] Set new PPP Fail", __FUNCTION__, __LINE__);
                #endif
		goto IFX_Handler;
            }
	}
	else if(wan_cfg->type == LINK_TYPE_ETH)
        {
	    /* Activate with the new configuration */
	    strcpy(wan_comm_cfg.WAN_CONN_IID.cpeId.secName, TAG_WAN_IP);
	    wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IID = wan_comm_cfg.WAN_CONN_IID; /* Pramod - need to fill IID inside
									            IP structure also */

	    if ((ret = ifx_set_wan_ip_config(operation, wan_cfg->wan_index, &wan_cfg->WAN_IP_CONN,
	                						(flags | IFX_F_MODIFY))) != IFX_SUCCESS)
            {
                #ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Set new WAN IP Fail", __FUNCTION__, __LINE__);
                #endif
		goto IFX_Handler;
	    }
	}
    }
    else
    {
	/* Case of Delete - so first remove the entry from wan_ip/wan_ppp section
	 * then update the wan_main section in rc.conf */
	wan_comm_cfg.WAN_CONN_IID = wan_cfg->iid;
	if (wan_cfg->type == LINK_TYPE_PPPOE)
        {
            /* Invoke the WAN PPP Configuration function */
	    strcpy(wan_comm_cfg.WAN_CONN_IID.cpeId.secName, TAG_WAN_PPP);
	    wan_cfg->WAN_PPP_CONN.WAN_CONN.WAN_CONN_IID = wan_comm_cfg.WAN_CONN_IID; /* Pramod - need to fill IID inside PPP structure also */

            if ((ret = ifx_set_wan_ppp_config(operation, wan_cfg->wan_index, &wan_cfg->WAN_PPP_CONN,
	  				                           (flags | IFX_F_DELETE))) != IFX_SUCCESS)
            {
                #ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Delete case: ifx_set_wan_ppp_config() Fail", __FUNCTION__, __LINE__);
                #endif
		goto IFX_Handler;
	    }
	}
	else if(wan_cfg->type == LINK_TYPE_ETH)
        {
	    /* Invoke the WAN IP Configuration function 
	     * Update the WAN_COMMON_CFG IID structure value from WAN_CONN_CFG IID 
	     * Update the CPEID to WAN_IP Section
	    */
	    strcpy(wan_comm_cfg.WAN_CONN_IID.cpeId.secName, TAG_WAN_IP);
	    wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IID = wan_comm_cfg.WAN_CONN_IID; /* Pramod - need to fill IID inside
	 									       IP structure also */

    	    if((ret = ifx_set_wan_ip_config(operation, wan_cfg->wan_index, &wan_cfg->WAN_IP_CONN,
									(flags | IFX_F_DELETE))) != IFX_SUCCESS)
            {
                #ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Delete case: ifx_set_wan_ip_config() Fail", __FUNCTION__, __LINE__);
                #endif
		goto IFX_Handler;
	    }
	}
	/* Now update rc.conf with the new configuration */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_MAIN, flags, 1, buf);
	if(ret != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
	    IFX_DBG("[%s:%d] Delete case: ifx_SetObjData() Fail", __FUNCTION__, __LINE__);
            #endif
	    goto IFX_Handler;
	}
    }

    /* Update the TR69 ID obtained above to reflect in the Mappings for WAN MAIN */
    STRNCPY(wan_cfg->iid.tr69Id, wan_comm_cfg.WAN_CONN_IID.tr69Id, 
				            strlen(wan_comm_cfg.WAN_CONN_IID.tr69Id));

    /*********** Device Configuration Block ****************/
    /* Device config thru Scripts/Utilities or Functions 
     * This would have been done from the WANIP or WANPPP calls */


    /*********** Notification Block *************/
    /* Notify the Internal TR69 Stack in case of MODIFY 
     * This Notification would only be for WAN MAIN params */
    if(IFX_MODIFY_F_SET(flags))
    {
        /* Notification for WAN MAIN mappings */
        CHECK_N_SEND_NOTIFICATION(wan_cfg->iid, wan_main_changed_fcount, 
	  	 	      wan_main_changed_array_fvp, flags, IFX_Handler)
    }
    else if (IFX_INT_ADD_F_SET(flags))
    {
 	/* In case of ADD operation, first update the ID Mappings
	 * and then send the Notification for the attributes
	 */	
	/*********** Epilog Block **************/
       UPDATE_ID_MAP_N_ATTRIBUTES(&wan_cfg->iid, wan_main_fvp_count, 
						wan_main_array_fvp, flags, IFX_Handler)
		
	/* Update the "WAN" Index in WAN_MAIN Section */
	if (ifx_manipulate_wan_indexs(FILE_RC_CONF, TAG_WAN_MAIN, "wan_main_index", 
 				wan_cfg->wan_index,	IFX_F_INT_ADD) != IFX_SUCCESS)
       {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Update WAN Index Fail", __FUNCTION__, __LINE__);
            #endif
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }


	/* Manipulate nextCpeId only for ADD operations */
	ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WAN_MAIN); 
    }
    else if (IFX_DELETE_F_SET(flags))
    {
        /* In case of DELETE operation, first send the notificatioupdate the ID Mappings
	 * and then send the Notification for the attributes
	 */	
	/*********** Epilog Block **************/
        UPDATE_ID_MAP_N_ATTRIBUTES(&wan_cfg->iid, wan_main_fvp_count, 
		 	          wan_main_array_fvp, flags, IFX_Handler)

	/* Delete the "WAN" Index in WAN_MAIN Section */
	if (ifx_manipulate_wan_indexs(FILE_RC_CONF, TAG_WAN_MAIN, "wan_main_index", 
				wan_cfg->wan_index,	IFX_F_DELETE) != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
	    IFX_DBG("[%s:%d] Delete case: Delete WAN Index Fail", __FUNCTION__, __LINE__);
            #endif
	    ret = IFX_FAILURE;
	    goto IFX_Handler;
        }
    }

    /* Updating Persistent Storage */
    ret = ifx_config_write(FILE_RC_CONF, flags);
    if(ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] Updating Persistent Storage Fail", __FUNCTION__, __LINE__);
        #endif
		goto IFX_Handler;
    }

IFX_Handler:
	IFX_MEM_FREE(ret_WANStr);
	IFX_MEM_FREE(ret_WANConnDevStr);
	IFX_MEM_FREE(wan_main_changed_array_fvp);
	IFX_MEM_FREE(RetStr);
	if(ret != IFX_SUCCESS)
        {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;


#else
	return IFX_SUCCESS;
#endif // CONFIG_FEATURE_ETH_WAN_SUPPORT
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_wan_eth_config(...)
*	wanIdx		==>	input index of the wan connection for which configuration
*				has to be returned
*	wan_cfg		==>	output pointer to wan connection WAN_CONN_CFG
*	flags		==>	
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads the wan connection configuration from rc.conf
			for the input wan index wanIdx and based on the link type it
			reads the specific connection parameters from either the 
			wan_ip or wan_ppp section from rc.conf
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_wan_eth_config(int32 wanIdx, WAN_CONN_CFG *wan_cfg, uint32 flags)
{
#ifdef CONFIG_FEATURE_ETH_WAN_SUPPORT
    IFX_ID iid;
    int32 dist_wan_index = -1, i = 0;
    char8 buf[MAX_FILELINE_LEN], *vpi = NULL, *vci = NULL, retVal[MAX_FILELINE_LEN], *dns_servers = NULL;
    char8 * iface = NULL;
    int32 ret=IFX_SUCCESS, outFlag = IFX_F_DEFAULT;
    WAN_COMMON_CFG wan_comm_cfg;
    char8 name[16]="";
    NET_INTF_CFG params;

    memset(&wan_comm_cfg, 0x00, sizeof(wan_comm_cfg));

    /* Check if wan_index is passed or not. If passed get wan connection type from wan_index
     * If not passed then get wan index for the cpeid passed
     * if both wan index and cpeid are not passed return error !! */
    sprintf(iid.cpeId.secName, "%s", TAG_WAN_MAIN);
    iid.cpeId.Id = wan_cfg->iid.cpeId.Id;

    if(wanIdx < 0)
    {
        if(wan_cfg->iid.cpeId.Id < 1)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] No WAN Index and cpeId", __FUNCTION__, __LINE__);
            #endif
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }

        if(ifx_get_index_from_cpe_id(FILE_RC_CONF, &iid.cpeId, &dist_wan_index) != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
            #endif
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }
        wan_cfg->wan_index = dist_wan_index;
    }
    else
        wan_cfg->wan_index = wanIdx;

    /* initialize the cache for this instance */
    sprintf(buf, "%s_%d_", PREFIX_WAN_MAIN, wan_cfg->wan_index);
    if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, IFX_F_INT_CACHE_INIT | flags, NULL, NULL) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
        #endif
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    sprintf(buf, "wan_%d_cpeId", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve cpeId", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_cfg->iid.cpeId.Id = atoi(retVal);

    sprintf(buf, "wan_%d_pcpeId", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve parent CpeId", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_cfg->iid.pcpeId.Id = atoi(retVal);

    sprintf(buf, "wan_%d_linkType", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve LinkType", __FUNCTION__, __LINE__);
        #endif
	      goto IFX_Handler;
    }
    wan_cfg->type = atoi(retVal);

    /* Determine the WAN Connection Type - WAN_IP or WAN_PPP from
     * the link type associated with the WAN device */
    if (wan_cfg->type == LINK_TYPE_PPPOE)
    {
        wan_comm_cfg = wan_cfg->WAN_PPP_CONN.WAN_CONN;
    }
    else
    {
        /* Case of UnConfigured is assumed to be WAN_IP */
        wan_comm_cfg = wan_cfg->WAN_IP_CONN.WAN_CONN;
    }

    sprintf(buf, "Wan%d_IF_Info", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_SYSTEM_STATUS, buf, "bringup_time_secs", flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve Wan%d_IF_Info", __FUNCTION__, __LINE__, wan_cfg->wan_index);
        #endif
    }
    else
    {
        struct sysinfo info;
				memset(&info,0,sizeof(info));
        sysinfo(&info);
        wan_comm_cfg.uptime = info.uptime - atol(retVal);
    }

    sprintf(buf, "wan_%d_autoDiscTime", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve wan_%d_autoDiscTime", __FUNCTION__, __LINE__,wan_cfg->wan_index);
        #endif
        goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_AUTO_DISCONNECT_TIME = atoi(retVal);

    sprintf(buf, "wan_%d_idleDiscTime", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve wan_%d_idleDiscTime", __FUNCTION__, __LINE__,wan_cfg->wan_index);
        #endif
        goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_IDLE_DISCONNECT_TIME = atoi(retVal);

    sprintf(buf, "wan_%d_warnDiscTime", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve wan_%d_warnDiscTime", __FUNCTION__, __LINE__,wan_cfg->wan_index);
        #endif
        goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_WARN_DISCONNECT_TIME = atoi(retVal);

    sprintf(buf, "wan_%d_RSIP", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve RSIP", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_RSIP_AVAILABLE = atoi(retVal);

    sprintf(buf, "wan_%d_NATEnable", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve NAT Enable", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_NAT_ENABLED = atoi(retVal);

    sprintf(buf, "wan_%d_DNSEnable", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve DNS Enable", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_DNS_ENABLED = atoi(retVal);

    sprintf(buf, "wan_%d_DNSOverride", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve DNS Override", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_DNS_OVERRIDE = atoi(retVal);

    if(wan_comm_cfg.WAN_CONN_DNS_OVERRIDE == IFX_DISABLED)
    {
        /* read dns server values from rc.conf */
        sprintf(buf, "wan_%d_DNSServers", wan_cfg->wan_index);
        if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Unable to retrieve iDNS server info", __FUNCTION__, __LINE__);
            #endif
            goto IFX_Handler;
        }

        dns_servers = strtok(retVal, ",");
        i = 0;
        while(dns_servers != NULL)
        {
            wan_comm_cfg.dns_servers[i].s_addr = inet_addr(dns_servers);
            dns_servers = strtok(NULL, ",");
            i++;
        }
    }
    else
    {
        /* read dns server ip addressed from system_status */
        sprintf(buf, "WAN%d_DNS_SERVER", wan_cfg->wan_index);
        if((ret = ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "DNS1", flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Unable to retrieve DNS1 value from system status file", __FUNCTION__, __LINE__);
            #endif
        }
        else
            wan_comm_cfg.dns_servers[0].s_addr = inet_addr(retVal);

        if((ret = ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "DNS2", flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Unable to retrieve DNS2 value from system status file", __FUNCTION__, __LINE__);
            #endif
        }
        else
            wan_comm_cfg.dns_servers[1].s_addr = inet_addr(retVal);

	     if((ret = ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "DNS3", flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Unable to retrieve DNS3 value from system status file", __FUNCTION__, __LINE__);
            #endif
        }
	else
            wan_comm_cfg.dns_servers[2].s_addr = inet_addr(retVal);
    }

    memset(&params,0,sizeof(params));
    ifx_mod_interface_attr(name,IFX_GET_INTF_ATTR,&params);
    snprintf(wan_comm_cfg.WAN_CONN_MAC_ADDR,MAX_MAC_ADDR_LEN,"%s", params.hwaddr);

    sprintf(buf, "wan_%d_macAddrOverride", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve mac override value", __FUNCTION__, __LINE__);
        #endif
	      goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_MAC_ADDR_OVERRIDE = atoi(retVal);

    sprintf(buf, "wan_%d_connTrigger", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve connection trigger value", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_TRIGGER = atoi(retVal);

    sprintf(buf, "wan_%d_rxRouteProto", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve routing protocol", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_ROUTE_PROTO_RX = atoi(retVal);

    sprintf(buf, "wan_%d_fEnable", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve enable value", __FUNCTION__, __LINE__);
        #endif 
        goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_ENABLE = atoi(retVal);

    sprintf(buf, "wan_%d_connName", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve connection name", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    strlcpy(wan_comm_cfg.WAN_CONN_NAME, retVal,MAX_CONN_NAME_LEN);

    sprintf(buf, "wan_%d_wanMode", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve wan mode", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_cfg->wan_mode.mode = atoi(retVal);


    sprintf(buf, "wan_%d_vlanId", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve vlan Id", __FUNCTION__, __LINE__);
		    #endif
		    goto IFX_Handler;
    }
    wan_cfg->vlanId = atoi(retVal);


    sprintf(buf, "wan_%d_iface", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve interface name", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    iface = strtok(retVal, ".");
    sprintf(wan_cfg->wan_mode.iface, "%s", iface);

    sprintf(buf, "wan_%d_conf_connName", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve wan_%d_conf_connName", __FUNCTION__, __LINE__, wan_cfg->wan_index);
        #endif
        goto IFX_Handler;
    }
    strlcpy(wan_comm_cfg.WAN_CONF_CONN_NAME, retVal,MAX_CONN_NAME_LEN);

    /* get the vpi vci out of retVal */
    sprintf(buf, "wan_%d_vcc", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve vcc", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    vpi = strtok(retVal, "/");
    vci = strtok(NULL, "/");
    if(vpi != NULL)
        wan_cfg->vc.pvc.vpi = atoi(vpi);
    if(vci != NULL)
        wan_cfg->vc.pvc.vci = atoi(vci);

    /* destroy the cache for this instance */
    sprintf(buf, "%s_%d_", PREFIX_WAN_MAIN, wan_cfg->wan_index);
    if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Failed to destroy cache for this instance", __FUNCTION__, __LINE__);
        #endif
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    if(wan_cfg->type == WAN_LINK_TYPE_PPPOE)
    {
        memcpy(&wan_cfg->WAN_PPP_CONN.WAN_CONN, &wan_comm_cfg, sizeof(wan_comm_cfg));
        ifx_get_wan_ppp_config(wan_cfg->wan_index, wan_cfg, flags);
    }
    else
    {
        memcpy(&wan_cfg->WAN_IP_CONN.WAN_CONN, &wan_comm_cfg, sizeof(wan_comm_cfg));
        ifx_get_wan_ip_config(wan_cfg->wan_index, wan_cfg, flags);
    }

IFX_Handler:
    /* destroy the cache for this instance */
    sprintf(buf, "%s_%d_", PREFIX_WAN_MAIN, wan_cfg->wan_index);
    if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
	      IFX_DBG("[%s:%d] Failed to destroy cache for this instance", __FUNCTION__, __LINE__);
        #endif
        ret = IFX_FAILURE;
    }

    if (ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s] : returned failure!", __FUNCTION__);
        #endif
    }
    return ret;

#else

    return IFX_SUCCESS;
#endif // CONFIG_FEATURE_ETH_WAN_SUPPORT
}


/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_all_wan_config(...)
*	num_entries	==>	number of wan connections
*	pp_wancfg	==>	output pointer to array of wan connections WAN_CONN_CFG
*	flags		==>	
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads all the wan connections from rc.conf
			and returns them in the array pp_wancfg. Also the number of wan
			connections read will be returned in num_entries.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_all_wan_config(int32 *num_entries, uint32 mode, WAN_CONN_CFG **pp_wancfg, uint32 flags)
{
	uint32	outFlag = IFX_F_DEFAULT;
	char8	buf[MAX_FILELINE_LEN], sIndexes[MAX_FILELINE_LEN];
	int32	count = 0, ret = IFX_SUCCESS, idx_count = 0, *idx_array = NULL, i =0;
	WAN_CONN_CFG wan_cfg, *t_ptr = NULL;
        char8 tempBuf[32];
        char8    retVal[20];
	uint32 thismode = 0;

	*num_entries = 0;
	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	NULL_TERMINATE(sIndexes, 0x00, sizeof(sIndexes));
	NULL_TERMINATE(tempBuf, 0x00, sizeof(tempBuf));

	sprintf(buf, "%s", "wan_main_index");
	if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, &outFlag, sIndexes)) != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
            #endif
            goto IFX_Handler;
        }

	get_wan_indices(sIndexes, &idx_count, &idx_array);

	t_ptr = (WAN_CONN_CFG *)IFX_MALLOC(idx_count * sizeof(WAN_CONN_CFG));

	if(t_ptr == NULL)
	{
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	*pp_wancfg = t_ptr;


	for(i=0; i<idx_count; i++)
        {
		memset(&wan_cfg, 0x00, sizeof(wan_cfg));
		wan_cfg.wan_index = *(idx_array + i);
		sprintf(wan_cfg.iid.cpeId.secName, "%s", TAG_WAN_MAIN);
	        
                sprintf(tempBuf, "%s_%d_wanMode", PREFIX_WAN_MAIN, wan_cfg.wan_index);
                if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, tempBuf, flags, &outFlag, retVal)) != IFX_SUCCESS)
                {
                    #ifdef IFX_LOG_DEBUG
                    IFX_DBG("[%s:%d] Unable to retrieve wan mode", __FUNCTION__, __LINE__);
                    #endif
                    goto IFX_Handler;
                }
                thismode = atoi(retVal);
		if(WAN_MODE_ATM == thismode)
		{
		    /* if there is no wan object in wan_main section for this wanIdx, continue */
                    if((mode == GET_WAN_CONFIG_ATM) || (mode == GET_WAN_CONFIG_ALL))
                    { 
		       if((ret = ifx_get_wan_atm_vcc_config(*(idx_array + i), &wan_cfg, flags)) != IFX_SUCCESS)
                        {
                            #ifdef IFX_LOG_DEBUG
                            IFX_DBG("[%s:%d] ifx_get_wan_atm_vcc_config() Fail", __FUNCTION__, __LINE__);
                            #endif
		            goto IFX_Handler;
                        }
                    }
                }
		else if((WAN_MODE_ETH0 == thismode) || (WAN_MODE_ETH1 == thismode))
                {
                    if((mode == GET_WAN_CONFIG_ETH) || (mode == GET_WAN_CONFIG_ALL))
                    { 
		        /* if there is no wan object in wan_main section for this wanIdx, continue */
		        if((ret = ifx_get_wan_eth_config(*(idx_array + i), &wan_cfg, flags)) != IFX_SUCCESS)
                        {
                            #ifdef IFX_LOG_DEBUG
                            IFX_DBG("[%s:%d] ifx_get_wan_eth_config() Fail", __FUNCTION__, __LINE__);
                            #endif
		            goto IFX_Handler;
                        }
                    }
                }
                else if(WAN_MODE_PTM == thismode || WAN_MODE_VDSL_PTM == thismode)
                {
                    if((mode == GET_WAN_CONFIG_PTM) || (mode == GET_WAN_CONFIG_ALL))
                    { 
		        /* if there is no wan object in wan_main section for this wanIdx, continue */
		        if((ret = ifx_get_wan_ptm_config(*(idx_array + i), &wan_cfg, flags)) != IFX_SUCCESS)
                        {
                            #ifdef IFX_LOG_DEBUG
                            IFX_DBG("[%s:%d] ifx_get_wan_ptm_config() Fail", __FUNCTION__, __LINE__);
                            #endif
		            goto IFX_Handler;
                        }
                    }
                }
	
/*manohar : this check is not required
		if(pp_wancfg == NULL || *pp_wancfg == NULL)
        	{
            		#ifdef IFX_LOG_DEBUG
             			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
             		#endif
             	 	ret = IFX_FAILURE;
              		goto IFX_Handler;
		}
*/              
		*(*pp_wancfg + count) = wan_cfg;
		count++;
	}
	*num_entries = idx_count;

IFX_Handler:
	IFX_MEM_FREE(idx_array)
	if(ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*pp_wancfg)
		*num_entries = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}

#ifdef CONFIG_FEATURE_ADSL_WAN_SUPPORT
int32 ifx_set_xdsl_phy_cfg(XDSL_PHY_CFG *pstXdslPhy)
{
    int32 ret = IFX_SUCCESS;
    char8 data_buff[MAX_DATA_LEN];

    if(pstXdslPhy == NULL)
    {
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    memset(data_buff, 0x00, sizeof(data_buff));

    sprintf(data_buff, "ADSL_MODE=\"%s\"\n",pstXdslPhy->sAdsl_Mode);
    sprintf(data_buff, "%sDSL_API_DEBUG=\"%s\"\n", data_buff, pstXdslPhy->sDsl_Api_Debug);
    sprintf(data_buff, "%sVDSL_MODE=\"%s\"\n", data_buff, pstXdslPhy->sVdsl_Mode);
    sprintf(data_buff, "%sxDSL_MODE=\"%s\"\n", data_buff, pstXdslPhy->sXdsl_Mode);
    sprintf(data_buff, "%sCNTL_MODE_ENA=\"%d\"\n", data_buff, pstXdslPhy->cntl_mode_ena);
    sprintf(data_buff, "%sCNTL_MODE=\"%d\"\n", data_buff, pstXdslPhy->cntl_mode);
    sprintf(data_buff, "%sPWR_MODE_ENA=\"%d\"\n", data_buff, pstXdslPhy->pwr_mode_ena);
    sprintf(data_buff, "%sPWR_MODE=\"%d\"\n", data_buff, pstXdslPhy->pwr_mode);
    ret = ifx_SetObjData(FILE_RC_CONF, TAG_ADSL_PHY, IFX_F_MODIFY, 1, data_buff);
    if(ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] ifx_SetObjData() Fail", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }

    /* Updating Persistent Storage */
    ret = ifx_config_write(FILE_RC_CONF,IFX_F_DEFAULT);
    if(ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Update Persistent Storage Fail", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }

IFX_Handler:
   if (ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s] : returned failure!", __FUNCTION__);
        #endif
    }
    return ret;
}
#endif


/**************************************************************
* Function    : ifx_set_wan_phy_cfg()
* Description : Sets the value of phycfg_tc and phycfg_mode under
*               wan_phy_cfg section in rc.conf
* Parameters  : WAN_PHY_CFG *pstWanPhy -> should be filled by caller.
*               contains value of PHY TC and PHY Mode
* Return      : IFX_SUCCESS on success, IFX_FAILURE on error
**************************************************************/

int32 ifx_set_wan_phy_cfg(WAN_PHY_CFG *pstWanPhy)
{
    int32 ret = IFX_SUCCESS;
    char8 data_buff[MAX_DATA_LEN];
		IFX_MAPI_QoS_QM qm;
	char8 sLine[256];

    if(pstWanPhy == NULL)
    {
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    memset(data_buff, 0x00, sizeof(data_buff));
		memset(&qm, 0x00, sizeof(qm));

    sprintf(data_buff, "%s_tc=\"%d\"\n", PREFIX_WAN_PHY_CFG, pstWanPhy->wan_tc);
    sprintf(data_buff, "%s%s_phymode=\"%d\"\n", data_buff, PREFIX_WAN_PHY_CFG, pstWanPhy->phy_mode);
    sprintf(data_buff, "%s%s_settc=\"%d\"\n", data_buff, PREFIX_WAN_PHY_CFG, pstWanPhy->set_wan_tc);
    sprintf(data_buff, "%s%s_setphymode=\"%d\"\n", data_buff, PREFIX_WAN_PHY_CFG, pstWanPhy->set_phy_mode);
#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
    sprintf(data_buff, "%s%s_ptmVlanMode=\"%d\"\n", data_buff, PREFIX_WAN_PHY_CFG, pstWanPhy->ptm_vlan_mode);
#endif
#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
#if !defined(PLATFORM_VR9)
    sprintf(data_buff, "%s%s_ethVlanMode=\"%d\"\n", data_buff, PREFIX_WAN_PHY_CFG, pstWanPhy->eth_vlan_mode);
#endif
#if !defined(PLATFORM_DANUBE)
    sprintf(data_buff, "%s%s_mii1ethVlanMode=\"%d\"\n", data_buff, PREFIX_WAN_PHY_CFG, pstWanPhy->eth_mii1_vlan_mode);
#endif
#endif
    sprintf(data_buff, "%s%s_tr69_encaprequested=\"%s\"\n", data_buff, PREFIX_WAN_PHY_CFG, pstWanPhy->tr69_encaprequested);
    ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, IFX_F_DEFAULT, 1, data_buff);
    if(ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] ifx_SetObjData() Fail", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
      ifx_GetObjData(FILE_RC_CONF, TAG_IPQOS_QM, "qm_atmQmode", IFX_F_GET_ENA, 0, sLine);
      if (atoi(sLine) == IFX_MAPI_QoS_ATM_PVC_BASED)
      {

		if(pstWanPhy->phy_mode == WAN_PHY_MODE_ADSL2 && pstWanPhy->wan_tc == WAN_TC_ATM) {
				if((ret = ifx_mapi_get_qos_qm(&qm, IFX_F_DEFAULT)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
						IFX_DBG("[%s:%d] queue config read failed", __FUNCTION__, __LINE__);
#endif
						goto IFX_Handler;
				}

				if(!strcmp(qm.qIf, "0/0")) {
						qm.status = IFX_DISABLED;
						qm.enable = IFX_DISABLED;
						if((ret = ifx_mapi_set_qos_qm(IFX_OP_MOD, &qm, IFX_F_MODIFY | IFX_F_DONT_ACTIVATE)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
							IFX_DBG("[%s:%d] queue config set failed", __FUNCTION__, __LINE__);
#endif
							goto IFX_Handler;
						}
				}
		}
	}
    /* Updating Persistent Storage */
    ret = ifx_config_write(FILE_RC_CONF,IFX_F_DEFAULT);
    if(ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Update Persistent Storage Fail", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
/*
    if(pstWanPhy->phy_mode == WAN_PHY_MODE_ADSL2)
        system("/usr/sbin/upgrade ethwan_set 0");
    else if(pstWanPhy->phy_mode == WAN_PHY_MODE_ETH_MII0) 
        system("/usr/sbin/upgrade ethwan_set 1");
    else if (pstWanPhy->phy_mode == WAN_PHY_MODE_ETH_MII1)
        system("/usr/sbin/upgrade ethwan_set 2");
    else if (pstWanPhy->phy_mode == WAN_PHY_MODE_VDSL2)
        system("/usr/sbin/upgrade ethwan_set 3");
*/
IFX_Handler:
   if (ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s] : returned failure!", __FUNCTION__);
        #endif
    }
    return ret;
}

/**************************************************************
* Function    : ifx_get_wan_phy_cfg()
* Description : Gets the value of phycfg_tc and phycfg_mode under
*               wan_phy_cfg section in rc.conf
* Parameters  : WAN_PHY_CFG *pstWanPhy -> should be allocated by caller.
* Return      : IFX_SUCCESS on success, IFX_FAILURE on error
**************************************************************/
int32 ifx_get_wan_phy_cfg(WAN_PHY_CFG *pstWanPhy)
{
    int32 ret = IFX_SUCCESS;
    char8 sValue[MAX_FILELINE_LEN];
    char8 data_buff[MAX_DATA_LEN];
    uint32 outFlag = IFX_F_DEFAULT;

    if(pstWanPhy == NULL)
    {
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    memset(data_buff, 0x00, sizeof(data_buff));
    sprintf(data_buff, "%s_tc", PREFIX_WAN_PHY_CFG);
    ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, data_buff, IFX_F_GET_ANY, &outFlag, sValue);
    if(ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] wanphy_tc: Get Fail", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    pstWanPhy->wan_tc = atoi(sValue);
    memset(data_buff, 0x00, sizeof(data_buff));
    sprintf(data_buff, "%s_phymode", PREFIX_WAN_PHY_CFG);
    ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, data_buff, IFX_F_GET_ANY, &outFlag, sValue);
    if(ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] wanphy_phymode: Get Fail", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    pstWanPhy->phy_mode = atoi(sValue);

    memset(data_buff, 0x00, sizeof(data_buff));
    sprintf(data_buff, "%s_settc", PREFIX_WAN_PHY_CFG);
    ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, data_buff, IFX_F_GET_ANY, &outFlag, sValue);
    if(ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] wanphy_settc: Get Fail", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    pstWanPhy->set_wan_tc = atoi(sValue);
    memset(data_buff, 0x00, sizeof(data_buff));
    sprintf(data_buff, "%s_setphymode", PREFIX_WAN_PHY_CFG);
    ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, data_buff, IFX_F_GET_ANY, &outFlag, sValue);
    if(ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] wanphy_setphymode: Get Fail", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    pstWanPhy->set_phy_mode = atoi(sValue);

#if defined(CONFIG_FEATURE_ETH_WAN_SUPPORT)
#if !defined(PLATFORM_AMAZON_SE) && !defined(PLATFORM_VR9)
    memset(data_buff, 0x00, sizeof(data_buff));
    sprintf(data_buff, "%s_ethVlanMode", PREFIX_WAN_PHY_CFG);
    ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, data_buff, IFX_F_GET_ANY, &outFlag, sValue);
    if(ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    pstWanPhy->eth_vlan_mode = atoi(sValue);
#endif // PLATFORM_AMAZON_SE && VR9
#if !defined(PLATFORM_AMAZON_SE) && !defined(PLATFORM_DANUBE)
    memset(data_buff, 0x00, sizeof(data_buff));
    sprintf(data_buff, "%s_mii1ethVlanMode", PREFIX_WAN_PHY_CFG);
    ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, data_buff, IFX_F_GET_ANY, &outFlag, sValue);
    if(ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    pstWanPhy->eth_mii1_vlan_mode = atoi(sValue);
#endif // PLATFORM_AMAZON_SE && DANUBE
#endif // CONFIG_FEATURE_ETH_WAN_SUPPORT

#if defined(CONFIG_FEATURE_PTM_WAN_SUPPORT)
    memset(data_buff, 0x00, sizeof(data_buff));
    sprintf(data_buff, "%s_ptmVlanMode", PREFIX_WAN_PHY_CFG);
    ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, data_buff, IFX_F_GET_ANY, &outFlag, sValue);
    if(ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    pstWanPhy->ptm_vlan_mode = atoi(sValue);
#endif

    memset(data_buff, 0x00, sizeof(data_buff));
    sprintf(data_buff, "%s_tr69_encaprequested", PREFIX_WAN_PHY_CFG);
    ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PHY_CFG, data_buff, IFX_F_GET_ANY, &outFlag, sValue);
    if(ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    snprintf(pstWanPhy->tr69_encaprequested,MAX_FIELD_RANGE,"%s", sValue);

IFX_Handler:
   if (ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s] : returned failure!", __FUNCTION__);
        #endif
    }
    return ret;
}


/**************************************************************************************
* Function    : ifx_mapi_set_wan_config()
* Description : Wrapper mapi called from adaptation. Based on wan mode it calls 
*               the appropriate internal set funciton to set wan config info in rc.conf
* Parameters  : operation -> specifies add/del/modify
*               flags     -> affect the kind of validation on the parameters
*               wan_conn_cfg -> contains the values to be set
* Return      : IFX_SUCCESS on success, IFX_FAILURE on error
**************************************************************************************/
int32 ifx_mapi_set_wan_config(int32 operation, WAN_CONN_CFG *wan_conn_cfg, uint32 flags)
{
    int wan_mode=0;
    IFX_ID  iid;
    int32   nWAN_IDX = 0;
    memset(&iid, 0x00, sizeof(iid));
    int ret = IFX_SUCCESS;

    IFX_VALIDATE_PTR(wan_conn_cfg)

    wan_mode = wan_conn_cfg->wan_mode.mode;
    switch(wan_mode)
    {
        case WAN_MODE_ATM:
        {
            ret = ifx_set_wan_atm_vcc_config(operation, wan_conn_cfg, flags);
            break;
        }
        case WAN_MODE_ETH0:
        case WAN_MODE_ETH1:
        {
            ret = ifx_set_wan_eth_config(operation, wan_conn_cfg, flags);
            break;
        }
        case WAN_MODE_PTM:
        case WAN_MODE_VDSL_PTM:
        {
            ret = ifx_set_wan_ptm_config(operation, wan_conn_cfg, flags);
            break;
        }
        default:
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Default case", __FUNCTION__, __LINE__);
            #endif
            break;
        }
    }
    if(ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Set wan Fail", __FUNCTION__, __LINE__);
        #endif
    }
    else
    {
        if(operation == IFX_OP_MOD || operation == IFX_OP_ADD)
        {
            if(ifx_get_default_wan_if(&iid, &nWAN_IDX, IFX_F_DEFAULT) == IFX_SUCCESS)
            {
                #ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] default gateway index = %d", __FUNCTION__, __LINE__,nWAN_IDX);
                #endif
            }
            if(nWAN_IDX == wan_conn_cfg->wan_index)
            {
                if(IFX_DONT_VALIDATE_F_NOT_SET(flags) && (IFX_DONT_ACTIVATE_F_NOT_SET(flags) || IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags)) && IFX_DEACTIVATE_F_NOT_SET(flags) && IFX_INCOMPLETE_F_NOT_SET(flags))
                {
										flags &= ~IFX_F_INT_ADD;
										flags |= IFX_F_MODIFY;
                    if(ifx_set_default_wan_if(&wan_conn_cfg->iid,wan_conn_cfg->wan_index, flags) != IFX_SUCCESS)
                    {
                        #ifdef IFX_LOG_DEBUG
                        IFX_DBG("\n\n In Function [%s][%d] : ifx_set_default_wan_if !!\n\n", __FUNCTION__,__LINE__);
                        #endif
                    }
                }
            }
        }    
    }
    return ret;
}

int32 ifx_mapi_get_wan_config(int32 wanIdx,WAN_CONN_CFG *wan_conn_cfg, uint32 flags)
{
    int wan_mode=0;
    int32 ret=IFX_SUCCESS, outFlag = IFX_F_DEFAULT;
    char8 buf[MAX_FILELINE_LEN], retVal[MAX_FILELINE_LEN];
    IFX_ID iid;
    int32 dist_wan_index = -1;

    IFX_VALIDATE_PTR(wan_conn_cfg)

    /* Check if wan_index is passed or not. If passed get wan connection type from wan_index
     * If not passed then get wan index for the cpeid passed
     * if both wan index and cpeid are not passed return error !! */
    sprintf(iid.cpeId.secName, "%s", TAG_WAN_MAIN);
    iid.cpeId.Id = wan_conn_cfg->iid.cpeId.Id;

    if(wanIdx < 0)
    {
        if(wan_conn_cfg->iid.cpeId.Id < 1)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Invalid wan index and cpeId", __FUNCTION__, __LINE__);
            #endif
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }

        if(ifx_get_index_from_cpe_id(FILE_RC_CONF, &iid.cpeId, &dist_wan_index) != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Unable to retrieve wan index from cpeId", __FUNCTION__, __LINE__);
            #endif
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }
        wan_conn_cfg->wan_index = dist_wan_index;
    }
    else
    {
        wan_conn_cfg->wan_index = wanIdx;
    }
    sprintf(buf, "wan_%d_wanMode", wan_conn_cfg->wan_index);
    if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve wan mode", __FUNCTION__, __LINE__);
        #endif
        return ret;
    }
    wan_mode = wan_conn_cfg->wan_mode.mode = atoi(retVal);
    switch(wan_mode)
    {
        case WAN_MODE_ATM:
        {
            ret = ifx_get_wan_atm_vcc_config(wanIdx, wan_conn_cfg, flags);
            break;
        }
        case WAN_MODE_ETH0:
        case WAN_MODE_ETH1:
        {
            ret = ifx_get_wan_eth_config(wanIdx, wan_conn_cfg, flags);
            break;
        }
        case WAN_MODE_PTM:
        case WAN_MODE_VDSL_PTM:
        {
            ret = ifx_get_wan_ptm_config(wanIdx, wan_conn_cfg, flags);
            break;
        }
        default:
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] default case", __FUNCTION__, __LINE__);
            #endif
            wan_mode = wan_conn_cfg->wan_mode.mode;
            break;
        }
    }
IFX_Handler:
    if(ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] return failure", __FUNCTION__, __LINE__);
        #endif
    }
    return ret;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_wan_ptm_config(...)
*     operation      ==>     specifies the operation to be done such as ADD, DELETE or MODIFY
*     wan_cfg        ==>     pointer to WAN_CONN_CFG structure which will store the common parameters of the wan
*                            connection and the wan ip/ppp specific parameters
*       flags        ==>      flags that define the behaviour
*
*     Return Value :   IFX_SUCCESS or IFX_FAILURE
*     Description:
*                    The api adds, deletes or modifies a wan connection. the api will store the wan connection over two
*                    sections in rc.conf, wan_main (common parameters) and wan_ip (ip specific parameters)
*                    or wan_ppp (ppp specific parameters). 
*                    the caller should pass the vcc value in the structue, the api assumes that the caller will
*                    pass the vcc also if he is passing the parent cpeid. The api calls respective ip or ppp set apis
*                    for add/modify/delete opeartion only based on the link type. The check has been provided to avoid
*                    any of the two api call for a disable operation. The api assumes that the adaptation has the 
*                    validation to avoid modify operation on a wan ip connection to wan ppp connection and vice-versa.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_wan_ptm_config(int32 operation, WAN_CONN_CFG *wan_cfg, uint32 flags)
{
#ifdef CONFIG_FEATURE_PTM_WAN_SUPPORT
    char8    wanVCC[20];
    char8    wan_conn_name[MAX_CONN_NAME_LEN];
    char8    cpeIDValStr[20];
    char8    *ret_WANStr = NULL, *ret_WANConnDevStr = NULL;
    IFX_ID   parent_iid, iid;
    int32    dist_wan_index = -1;
    int32    wan_index = 0;
    IFX_NAME_VALUE_PAIR wan_main_array_fvp[34];
    uint32   wan_main_fvp_count = 0;
    IFX_NAME_VALUE_PAIR *wan_main_changed_array_fvp = NULL;
    //#if 0
    uint32   wan_main_changed_fcount = 0;
    //#endif
    char8    buf[MAX_DATA_LEN], conf_buf[MAX_FILELINE_LEN];
    int32    ret=IFX_SUCCESS;
    int32    outFlag = IFX_F_DEFAULT;
    char8    sValue[MAX_FILELINE_LEN];
    WAN_CONN_CFG old_wan_cfg;
    char8    retVal[20];
    WAN_COMMON_CFG wan_comm_cfg;
    char8    sWan_IP[MAX_IP_ADDR_LEN], sWan_Mask[MAX_IP_ADDR_LEN];
    char8    dns_servers[MAX_DNS_SERVERS * MAX_IP_ADDR_LEN];
    int32    i = 0;
    char8 tempBuf[16],* RetStr = NULL;

    NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
    NULL_TERMINATE(wanVCC, 0, sizeof(wanVCC));
    NULL_TERMINATE(cpeIDValStr, 0, sizeof(cpeIDValStr));
    NULL_TERMINATE(sWan_IP, 0x00, sizeof(sWan_IP));
    NULL_TERMINATE(sWan_Mask, 0x00, sizeof(sWan_Mask));
    NULL_TERMINATE(tempBuf, 0x00, sizeof(tempBuf));
    memset(&wan_main_array_fvp, 0, sizeof(wan_main_array_fvp));
    memset(&wan_comm_cfg, 0x00, sizeof(wan_comm_cfg));
    memset(&old_wan_cfg, 0x00, sizeof(old_wan_cfg));
    memset(&parent_iid, 0, sizeof(parent_iid));
    memset(&iid, 0, sizeof(iid));

    /*************** Prolog Block *********************/
    /* Set the flags based on operation */
    if (operation == IFX_OP_DEL) 
        flags |= IFX_F_DELETE;
    else if (operation == IFX_OP_MOD)
        flags |= IFX_F_MODIFY;
    else if ((operation == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
    {
        flags |= IFX_F_INT_ADD;
    }

    if( IFX_DONT_VALIDATE_F_NOT_SET(flags))
    {
        /* 1. Check whether the WAN_CONN_CFG is NULL, if so it's an Error!
        Also check on valid flags condition */
        IFX_VALIDATE_PTR(wan_cfg)
        IFX_VALIDATE_FLAGS(flags)
    }
	
    /*************** Prolog Block Continued *********************/
    /* Determine the WAN's parent Section from the pcpeId if it is
     * passed or from VCC otherwise (incase of WEB/CLI configuration 
    */
    iid = wan_cfg->iid;
    if (iid.pcpeId.Id == 0)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Invalid parent cpeId", __FUNCTION__, __LINE__);
        #endif
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    sprintf(iid.cpeId.secName, "%s", TAG_WAN_MAIN);

    /* Parent's cpeId is specified, fill in the parent section which is WAN_CONN_DEVICE now */
    sprintf(iid.pcpeId.secName, "%s", TAG_WAN_CONN_DEVICE);

    /* Update the Parent's cpeID and Section Name in piid
    * This would be required only for ADD operation */
    parent_iid.cpeId.Id = iid.pcpeId.Id;
    sprintf(parent_iid.cpeId.secName, "%s", iid.pcpeId.secName);

    /* Determine the WAN Connection Type - WAN_IP or WAN_PPP from
     * the link type associated with the WAN device */
    if(wan_cfg->type == LINK_TYPE_PPPOE)
    {
        wan_comm_cfg = wan_cfg->WAN_PPP_CONN.WAN_CONN;
    }
    else
    {
        /* Case of UnConfigured is assumed to be WAN_IP */
        wan_comm_cfg = wan_cfg->WAN_IP_CONN.WAN_CONN;
    }
#if 0
   if((wan_cfg->vc.pvc.vpi != 0) || (wan_cfg->vc.pvc.vci != 0))
    { 
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Invalid VCC", __FUNCTION__, __LINE__);
        #endif
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }
#endif
    sprintf(wanVCC, "%d/%d", wan_cfg->vc.pvc.vpi, wan_cfg->vc.pvc.vci);
        IFX_DBG("[%s:%d] wanVCC -> %s", __FUNCTION__, __LINE__,wanVCC);

    /**************** Validation Block *****************/
    /* For Operations other than DELETE perform the following validation on input params */
    if( IFX_DONT_VALIDATE_F_NOT_SET(flags))
    {
        if (IFX_DELETE_F_NOT_SET(flags))
        {
            /* MANDATORY CHECK:
            * Check if the wan_Connection Name is unique across WAN IP and PPP
            * We assume that the wan_Connection Name must be unique across
            * all connections ! */
            NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
            STRNCPY(conf_buf, wan_comm_cfg.WAN_CONN_NAME, strlen(wan_comm_cfg.WAN_CONN_NAME));

            /* Check if the wanConnName is configured, then it MUST be unique for any ADD Operation */	
            if ((strcmp(conf_buf, "")) && (IFX_INT_ADD_F_SET(flags)))
            {	
                ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_WAN_MAIN, "connName", conf_buf, &ret_WANStr);
                if(ret == IFX_SUCCESS)
                {
                    #ifdef IFX_LOG_DEBUG
                    IFX_DBG("[%s:%d] Connection name is not unique for ADD.connName = %s", __FUNCTION__, __LINE__,ret_WANStr);
                    #endif
                    ret = IFX_FAILURE;
                    goto IFX_Handler;
                }	
            }
            /*pcpeId should be present in the PTM channel section*/
            sprintf(tempBuf, "%d", iid.pcpeId.Id);
            ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, TAG_PTM_CHANNEL, "pcpeId", tempBuf, &RetStr);
            if(ret != IFX_SUCCESS)
            {
                #ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] Unable to retrieve parent cpeId", __FUNCTION__, __LINE__);
                #endif
                ret = IFX_FAILURE;
                goto IFX_Handler;
            }

            /*VLANID should be present in the PTM channel section*/
            NULL_TERMINATE(tempBuf, 0x00, sizeof(tempBuf));
            sprintf(tempBuf, "%s_%s", RetStr, "vlanId");
            if((ifx_GetObjData(FILE_RC_CONF, TAG_PTM_CHANNEL, tempBuf, IFX_F_GET_ANY,
                                                        (IFX_OUT uint32 *) &outFlag, sValue)) != IFX_SUCCESS)
            {
                #ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] Unable to retrieve vlan Id", __FUNCTION__, __LINE__);
                #endif
                ret = IFX_FAILURE;
                goto IFX_Handler;
            }
            if(atoi(sValue) != wan_cfg->vlanId)
	    {
                #ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] No VLAN Id match", __FUNCTION__, __LINE__);
                #endif
                ret = IFX_FAILURE;
                goto IFX_Handler;
            }
        }
    }

    /**************** ID Allocation Block - Only for ADD Operation **************/
    if (IFX_INT_ADD_F_SET(flags))
    {
        /* Form tag of parent section and get cpeId
        * Allocate iid for Add */
        memset(&iid, 0x00, sizeof(iid));
        if (ifx_get_iid(TAG_WAN_MAIN, TAG_WAN_CONN_DEVICE, &parent_iid, &iid) != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Unable to allocate iid for ADD", __FUNCTION__, __LINE__);
            #endif
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }

        /* Check if wan_index is passed or not
        * If not passed then get unused wan_index - for ADD */
        if (wan_cfg->wan_index <= 0)
        {
            if (ifx_get_available_distinct_index(FILE_RC_CONF, TAG_WAN_MAIN, "index", 
                            MIN_WAN_INDEX, MAX_WAN_INDEX, &dist_wan_index) != IFX_SUCCESS)
            {
                 #ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] Unable to obtain unused wan index", __FUNCTION__, __LINE__);
                #endif
                ret = IFX_FAILURE;
                goto IFX_Handler;
            }
            else
                wan_cfg->wan_index = dist_wan_index;
        }
    }

    /* Update the allocated IID in WAN CONNECTION */
    wan_cfg->iid.cpeId = iid.cpeId;
    wan_cfg->iid.pcpeId = iid.pcpeId;

    /* Get WAN Index in case of modify/delete operations from CPEID */
    if((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags)))
    {
        /* If WAN index is not specified, only then get the wan Index
		* from cpeId, else use the wan_index passed */
        if (wan_cfg->wan_index <= 0)
        {
            IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wan_cfg->iid.cpeId, wan_index)

            /* Update the wan index in WAN CONFIG structure */
            wan_cfg->wan_index = wan_index;
        }

        /* Populate the OLD WAN Connection config structure for MODIFY*/
        old_wan_cfg.wan_index = wan_cfg->wan_index;
        old_wan_cfg.iid = wan_cfg->iid;
        /* Check the LinkType for the given wan_index and invoke the
        * appropriate function */
        NULL_TERMINATE(buf, 0x00, sizeof(buf));
        NULL_TERMINATE(retVal, 0x00, sizeof(retVal));
        sprintf(buf, "wan_%d_linkType", old_wan_cfg.wan_index);
        if((ifx_GetObjData(FILE_RC_CONF, TAG_WAN_MAIN, buf, IFX_F_GET_ANY, (IFX_OUT uint32 *) &outFlag, retVal)) != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Unable to retrieve link Type", __FUNCTION__, __LINE__);
            #endif
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }
        old_wan_cfg.type = atoi(retVal);
		
        if (old_wan_cfg.type == WAN_LINK_TYPE_PPPOE)
        { 	
            if (ifx_get_wan_ppp_config(old_wan_cfg.wan_index,&old_wan_cfg, IFX_F_GET_ANY) != IFX_SUCCESS)
            {
                #ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] Get old wan ppp config failed", __FUNCTION__, __LINE__);
                #endif
                ret = IFX_FAILURE;
                goto IFX_Handler;
            }
        }
        else
        {
            if (ifx_get_wan_ip_config(old_wan_cfg.wan_index, &old_wan_cfg, IFX_F_GET_ANY) != IFX_SUCCESS)
            {
                #ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] Get old wan ip config failed", __FUNCTION__, __LINE__);
                #endif
                ret = IFX_FAILURE;
                goto IFX_Handler;
            }
        }
    }

    /**************** Name Value Formation as per RC.CONF ********************/
    /* Form the name-value pairs for ACL Checking & Validation */
    if(IFX_DELETE_F_NOT_SET(flags))
    {
        sprintf(wan_conn_name, "%s%d", "WAN", wan_cfg->wan_index);
        if(wan_comm_cfg.WAN_CONN_DNS_OVERRIDE == IFX_DISABLED)
        {
            memset(dns_servers, 0x00, sizeof(dns_servers));
            for(i=0; i<MAX_DNS_SERVERS; i++)
            {
                strcat(dns_servers, inet_ntoa(wan_comm_cfg.dns_servers[i]));
                if(i < (MAX_DNS_SERVERS - 1))
                {
                    /* check if next dns ip value is 0.0.0.0 */
                    if(strcmp(inet_ntoa(wan_comm_cfg.dns_servers[i+1]), "0.0.0.0")) 
                        strcat(dns_servers, ","); /* if it is not 0.0.0.0, add it to the end of the list */
                    else
                        break; /* if its is 0.0.0.0 break out of the loop */
                }
            }
        }

        sprintf(sWan_IP, "%s", (char8 *)inet_ntoa(wan_comm_cfg.WAN_CONN_IPADDR));
        sprintf(sWan_Mask, "%s", (char8 *)inet_ntoa(wan_comm_cfg.WAN_CONN_IPMASK));

        ifx_fill_ArrayFvp_FName(wan_main_array_fvp, 0, 23, wan_main_param_names);

        ifx_fill_ArrayFvp_intValues(wan_main_array_fvp, 0, 14, (int32 *) &wan_cfg->iid.cpeId.Id, &wan_cfg->iid.pcpeId.Id, &wan_comm_cfg.WAN_CONN_ENABLE, &wan_cfg->type, &wan_comm_cfg.WAN_CONN_AUTO_DISCONNECT_TIME, &wan_comm_cfg.WAN_CONN_IDLE_DISCONNECT_TIME, &wan_comm_cfg.WAN_CONN_WARN_DISCONNECT_TIME, &wan_comm_cfg.WAN_CONN_RSIP_AVAILABLE, &wan_comm_cfg.WAN_CONN_NAT_ENABLED, &wan_comm_cfg.WAN_CONN_DNS_ENABLED, &wan_comm_cfg.WAN_CONN_DNS_OVERRIDE, &wan_comm_cfg.WAN_CONN_MAC_ADDR_OVERRIDE, &wan_comm_cfg.WAN_CONN_TRIGGER, &wan_comm_cfg.WAN_CONN_ROUTE_PROTO_RX);

        IFX_DBG("[%s:%d] wanVCC -> %s", __FUNCTION__, __LINE__,wanVCC);
	if(wan_cfg->iid.config_owner == IFX_WEB){
        ifx_fill_ArrayFvp_strValues(wan_main_array_fvp, 14, 7, "256/0", sWan_IP, sWan_Mask, strcmp(wan_comm_cfg.WAN_CONN_NAME, "")?wan_comm_cfg.WAN_CONN_NAME:wan_conn_name, strcmp(wan_comm_cfg.WAN_CONF_CONN_NAME, "")?wan_comm_cfg.WAN_CONF_CONN_NAME:wan_conn_name, (wan_comm_cfg.WAN_CONN_DNS_OVERRIDE == IFX_DISABLED)?dns_servers:"0.0.0.0", strlen(wan_comm_cfg.WAN_CONN_MAC_ADDR)?wan_comm_cfg.WAN_CONN_MAC_ADDR:"");
}
else{
        ifx_fill_ArrayFvp_strValues(wan_main_array_fvp, 14, 7, wanVCC, sWan_IP, sWan_Mask, strcmp(wan_comm_cfg.WAN_CONN_NAME, "")?wan_comm_cfg.WAN_CONN_NAME:wan_conn_name, strcmp(wan_comm_cfg.WAN_CONF_CONN_NAME, "")?wan_comm_cfg.WAN_CONF_CONN_NAME:wan_conn_name, (wan_comm_cfg.WAN_CONN_DNS_OVERRIDE == IFX_DISABLED)?dns_servers:"0.0.0.0", strlen(wan_comm_cfg.WAN_CONN_MAC_ADDR)?wan_comm_cfg.WAN_CONN_MAC_ADDR:"");
}
        sprintf(wan_main_array_fvp[21].value, "%d", wan_cfg->wan_mode.mode);
        ifx_fill_ArrayFvp_intValues(wan_main_array_fvp, 22, 1, &wan_cfg->vlanId);

        sprintf(wan_main_array_fvp[23].fieldname, "%s", "iface");
        sprintf(wan_main_array_fvp[24].fieldname, "%s", "ifType");

        memset(wan_cfg->wan_mode.iface, 0x00, (sizeof(char8)*IFNAMSIZE));
        strcpy(wan_cfg->wan_mode.iface,"ptm0");
        if(wan_cfg->vlanId == 0)
        {
	    sprintf(wan_main_array_fvp[23].value, "%s", wan_cfg->wan_mode.iface);
        }
        else
        {
	    sprintf(wan_main_array_fvp[23].value, "%s.%d", wan_cfg->wan_mode.iface , wan_cfg->vlanId );
        }
        if(wan_cfg->type == LINK_TYPE_PPPOE)
        {
            sprintf(wan_main_array_fvp[24].value, "%s", "ppp");
        }
        else
        {
            sprintf(wan_main_array_fvp[24].value, "%s", "ptm");
        }

        /* AMS */
        sprintf(wan_main_array_fvp[25].fieldname, "%s", "ipv4");
        sprintf(wan_main_array_fvp[26].fieldname, "%s", "ipv6");
        sprintf(wan_main_array_fvp[27].fieldname, "%s", "dhcpv6State");
        sprintf(wan_main_array_fvp[28].fieldname, "%s", "ianaID");
        sprintf(wan_main_array_fvp[29].fieldname, "%s", "iapdID");
        sprintf(wan_main_array_fvp[30].fieldname, "%s", "slaID");
        sprintf(wan_main_array_fvp[31].fieldname, "%s", "rapid");
	sprintf(wan_main_array_fvp[32].fieldname, "%s", "tunnel");
        ifx_fill_ArrayFvp_intValues(wan_main_array_fvp, 25, 8, &wan_cfg->ipv4, &wan_cfg->ipv6, &wan_cfg->dhcp_mode,
                     &wan_cfg->iana, &wan_cfg->iapd, &wan_cfg->slaid, &wan_cfg->rapid, &wan_cfg->tunnel); //AMS
     
    }

    wan_main_fvp_count = 33; 
	
    /* Form the fully qualified Name Value Pairs */
    if(ifx_get_conf_index_and_nv_pairs(&wan_cfg->iid, wan_cfg->wan_index, PREFIX_WAN_MAIN, 
                            wan_main_fvp_count, wan_main_array_fvp, flags) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to form NV Pairs", __FUNCTION__, __LINE__);
        #endif
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    /************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
    /* Ignore the "ifnas" and "ifType" in WAN MAIN for ACL 
     * Hence count should be (count - 2)
    */
    /*Commented for the time being*/
    //#if 0
    CHECK_ACL_RET(wan_cfg->iid, (wan_main_fvp_count-2), wan_main_array_fvp,
                   wan_main_changed_fcount, wan_main_changed_array_fvp, flags, IFX_Handler)
    //#endif
    /********* System Config File Update Block  **********/
    /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
    memset(buf, 0x00, sizeof(buf));
    form_cfgdb_buf(buf, wan_main_fvp_count, wan_main_array_fvp);

    ret = IFX_SUCCESS;
    if (operation == IFX_OP_ADD)
    {
        /* Update wan_main section in rc.conf*/
        ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_MAIN, flags, 1, buf);
        if(ret != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] ADD: ifx_SetObjData() Fail", __FUNCTION__, __LINE__);
            #endif
            goto IFX_Handler;
        }

        wan_comm_cfg.WAN_CONN_IID = wan_cfg->iid;

        if (wan_cfg->type == LINK_TYPE_PPPOE)
        {
            /* Invoke the WAN PPP Configuration function */
            strcpy(wan_comm_cfg.WAN_CONN_IID.cpeId.secName, TAG_WAN_PPP);
            /* Pramod - need to fill IID inside PPP structure also */
            wan_cfg->WAN_PPP_CONN.WAN_CONN.WAN_CONN_IID = wan_comm_cfg.WAN_CONN_IID; 

            //if((ret = ifx_set_wan_ppp_config_Without_TR69(operation, wan_cfg->wan_index, &wan_cfg->WAN_PPP_CONN,(flags | IFX_F_DONT_CHECKPOINT))) != IFX_SUCCESS)
            if((ret = ifx_set_wan_ppp_config(operation, wan_cfg->wan_index, &wan_cfg->WAN_PPP_CONN,(flags | IFX_F_DONT_CHECKPOINT))) != IFX_SUCCESS)
            {
                #ifdef IFX_LOG_DEBUG
                //IFX_DBG("[%s:%d] ADD: ifx_set_wan_ppp_config_Without_TR69() Fail", __FUNCTION__, __LINE__);
                IFX_DBG("[%s:%d] ADD: ifx_set_wan_ppp_config() Fail", __FUNCTION__, __LINE__);
                #endif
                goto IFX_Handler;
            }

            /* Copy the tr69id field from ip connection tr69id, because the tr69id 
            allocation will happen in ip set api */
            if(wan_cfg->iid.config_owner == IFX_WEB)
            {
	        STRNCPY(wan_comm_cfg.WAN_CONN_IID.tr69Id, wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IID.tr69Id, 
		strlen(wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IID.tr69Id));
            }
        }
        else if (wan_cfg->type == LINK_TYPE_PTM)
        {
            /* Invoke the WAN IP Configuration function 
             * Update the WAN_COMMON_CFG IID structure value from WAN_CONN_CFG IID 
             * Update the CPEID to WAN_IP Section
            */
            strcpy(wan_comm_cfg.WAN_CONN_IID.cpeId.secName, TAG_WAN_IP);
            /* Pramod - need to fill IID inside IP structure also */
            wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IID = wan_comm_cfg.WAN_CONN_IID; 

            //if ((ret = ifx_set_wan_ip_config_Without_TR69(operation, wan_cfg->wan_index, &wan_cfg->WAN_IP_CONN, flags)) != IFX_SUCCESS)
            if ((ret = ifx_set_wan_ip_config(operation, wan_cfg->wan_index, &wan_cfg->WAN_IP_CONN, flags)) != IFX_SUCCESS)
            {
                #ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] ADD: ifx_set_wan_ip_config() Fail", __FUNCTION__, __LINE__);
                #endif
                goto IFX_Handler;
            }

            /* Copy the tr69id field from ip connection tr69id, because the tr69id 
            allocation will happen in ip set api */
            if(wan_cfg->iid.config_owner == IFX_WEB)
            {
                STRNCPY(wan_comm_cfg.WAN_CONN_IID.tr69Id, wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IID.tr69Id, 
                strlen(wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IID.tr69Id));
	    }
	}
    }
    else if (operation == IFX_OP_MOD)
    {
        if (old_wan_cfg.type == LINK_TYPE_PPPOE)
        {
            /* Invoke the WAN PPP Configuration function */
            old_wan_cfg.WAN_PPP_CONN.WAN_CONN.WAN_CONN_IID = old_wan_cfg.iid;
            strcpy(old_wan_cfg.WAN_PPP_CONN.WAN_CONN.WAN_CONN_IID.cpeId.secName, TAG_WAN_PPP);

            /* check the state of this object, if enabled then only call the api to stop with the current config */
            sprintf(conf_buf, "%s_%d_cpeId", PREFIX_WAN_PPP, old_wan_cfg.wan_index);
            if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_PPP,
			conf_buf, IFX_F_GET_ENA, (IFX_OUT uint32 *) &outFlag, sValue) == IFX_SUCCESS)
            {
                //if ((ret = ifx_set_wan_ppp_config_Without_TR69(operation, old_wan_cfg.wan_index, &old_wan_cfg.WAN_PPP_CONN,(flags | IFX_F_DEACTIVATE | IFX_F_DONT_VALIDATE))) != IFX_SUCCESS)
                if ((ret = ifx_set_wan_ppp_config(operation, old_wan_cfg.wan_index, &old_wan_cfg.WAN_PPP_CONN,(flags | IFX_F_DEACTIVATE | IFX_F_DONT_VALIDATE))) != IFX_SUCCESS)
                {
                    #ifdef IFX_LOG_DEBUG
                    //IFX_DBG("[%s:%d] MODIFY: old wan conn Deactivate, ifx_set_wan_ppp_config_Without_TR69() Fail", __FUNCTION__, __LINE__);
                    IFX_DBG("[%s:%d] MODIFY: old wan conn Deactivate, ifx_set_wan_ppp_config() Fail", __FUNCTION__, __LINE__);
                    #endif
                    goto IFX_Handler;
                }
            }
        }
        else
        {
            /* Invoke the WAN IP Configuration function 
             * Update the WAN_COMMON_CFG IID structure value from WAN_CONN_CFG IID 
             * Update the CPEID to WAN_IP Section
            */
	    old_wan_cfg.WAN_IP_CONN.WAN_CONN.WAN_CONN_IID = old_wan_cfg.iid;
	    strcpy(old_wan_cfg.WAN_IP_CONN.WAN_CONN.WAN_CONN_IID.cpeId.secName, TAG_WAN_IP);

            /* check the state of this object, if enabled then only call the api to stop with the current config */
	    sprintf(conf_buf, "%s_%d_cpeId", PREFIX_WAN_IP, old_wan_cfg.wan_index);
	    if(ifx_GetObjData(FILE_RC_CONF, TAG_WAN_IP, conf_buf, IFX_F_GET_ENA, (IFX_OUT uint32 *) &outFlag, sValue) == IFX_SUCCESS)
            {
                //if((ret = ifx_set_wan_ip_config_Without_TR69(operation, old_wan_cfg.wan_index, &old_wan_cfg.WAN_IP_CONN, (flags | IFX_F_DEACTIVATE | IFX_F_DONT_VALIDATE))) != IFX_SUCCESS)
                if((ret = ifx_set_wan_ip_config(operation, old_wan_cfg.wan_index, &old_wan_cfg.WAN_IP_CONN, (flags | IFX_F_DEACTIVATE | IFX_F_DONT_VALIDATE))) != IFX_SUCCESS)
                {
                    #ifdef IFX_LOG_DEBUG
                    IFX_DBG("[%s:%d] MODIFY: old wan conn Deactivate, ifx_set_wan_ip_config() Fail", __FUNCTION__, __LINE__);
                    #endif
                    goto IFX_Handler;
                }
            }
        }

	/* Now update rc.conf with the new configuration */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_MAIN, flags, 1, buf);
	if(ret != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
	    IFX_DBG("[%s:%d] MODIFY: ifx_SetObjData() Fail", __FUNCTION__, __LINE__);
            #endif
	    goto IFX_Handler;
	}

	wan_comm_cfg.WAN_CONN_IID = wan_cfg->iid;

	if (wan_cfg->type == LINK_TYPE_PPPOE)
        {
	    /* Invoke the WAN PPP Configuration function */
	    strcpy(wan_comm_cfg.WAN_CONN_IID.cpeId.secName, TAG_WAN_PPP);
	    wan_cfg->WAN_PPP_CONN.WAN_CONN.WAN_CONN_IID = wan_comm_cfg.WAN_CONN_IID; /* Pramod - need to fill IID inside
	                                                                             PPP structure also */
            //if ((ret = ifx_set_wan_ppp_config_Without_TR69(operation, wan_cfg->wan_index, &wan_cfg->WAN_PPP_CONN,(flags | IFX_F_MODIFY))) != IFX_SUCCESS)
            if ((ret = ifx_set_wan_ppp_config(operation, wan_cfg->wan_index, &wan_cfg->WAN_PPP_CONN,(flags | IFX_F_MODIFY))) != IFX_SUCCESS)
            {
                #ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] MODIFY: Activate new connection, ifx_set_wan_ppp_config() Fail", __FUNCTION__, __LINE__);
                #endif
		goto IFX_Handler;
            }
	}
	else if(wan_cfg->type == LINK_TYPE_PTM)
        {
	    /* Activate with the new configuration */
	    strcpy(wan_comm_cfg.WAN_CONN_IID.cpeId.secName, TAG_WAN_IP);
	    wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IID = wan_comm_cfg.WAN_CONN_IID; /* Pramod - need to fill IID inside
									            IP structure also */

//if ((ret = ifx_set_wan_ip_config_Without_TR69(operation, wan_cfg->wan_index, &wan_cfg->WAN_IP_CONN, (flags | IFX_F_MODIFY))) != IFX_SUCCESS)
if ((ret = ifx_set_wan_ip_config(operation, wan_cfg->wan_index, &wan_cfg->WAN_IP_CONN, (flags | IFX_F_MODIFY))) != IFX_SUCCESS)
            {
                #ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s:%d] MODIFY: Activate new connection, ifx_set_wan_ip_config() Fail", __FUNCTION__, __LINE__);
                #endif
		goto IFX_Handler;
	    }
	}
    }
    else
    {
	/* Case of Delete - so first remove the entry from wan_ip/wan_ppp section
	 * then update the wan_main section in rc.conf */
	wan_comm_cfg.WAN_CONN_IID = wan_cfg->iid;
	if (wan_cfg->type == LINK_TYPE_PPPOE)
        {
            /* Invoke the WAN PPP Configuration function */
	    strcpy(wan_comm_cfg.WAN_CONN_IID.cpeId.secName, TAG_WAN_PPP);
	    wan_cfg->WAN_PPP_CONN.WAN_CONN.WAN_CONN_IID = wan_comm_cfg.WAN_CONN_IID; /* Pramod - need to fill IID inside PPP structure also */

            //if ((ret = ifx_set_wan_ppp_config_Without_TR69(operation, wan_cfg->wan_index, &wan_cfg->WAN_PPP_CONN, (flags | IFX_F_DELETE))) != IFX_SUCCESS)
            if ((ret = ifx_set_wan_ppp_config(operation, wan_cfg->wan_index, &wan_cfg->WAN_PPP_CONN, (flags | IFX_F_DELETE))) != IFX_SUCCESS)
            {
                #ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Delete: ifx_set_wan_ppp_config() Fail", __FUNCTION__, __LINE__);
                #endif
		goto IFX_Handler;
	    }
	}
	else if(wan_cfg->type == LINK_TYPE_PTM)
        {
	    /* Invoke the WAN IP Configuration function 
	     * Update the WAN_COMMON_CFG IID structure value from WAN_CONN_CFG IID 
	     * Update the CPEID to WAN_IP Section
	    */
	    strcpy(wan_comm_cfg.WAN_CONN_IID.cpeId.secName, TAG_WAN_IP);
	    wan_cfg->WAN_IP_CONN.WAN_CONN.WAN_CONN_IID = wan_comm_cfg.WAN_CONN_IID; /* Pramod - need to fill IID inside
	 									       IP structure also */

    	    //if((ret = ifx_set_wan_ip_config_Without_TR69(operation, wan_cfg->wan_index, &wan_cfg->WAN_IP_CONN,(flags | IFX_F_DELETE))) != IFX_SUCCESS)
    	    if((ret = ifx_set_wan_ip_config(operation, wan_cfg->wan_index, &wan_cfg->WAN_IP_CONN,(flags | IFX_F_DELETE))) != IFX_SUCCESS)
            {
                #ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Delete: ifx_set_wan_ip_config() Fail", __FUNCTION__, __LINE__);
                #endif
		goto IFX_Handler;
	    }
	}
	/* Now update rc.conf with the new configuration */
	ret = ifx_SetObjData(FILE_RC_CONF, TAG_WAN_MAIN, flags, 1, buf);
	if(ret != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Delete: ifx_SetObjData() Fail", __FUNCTION__, __LINE__);
            #endif
	    goto IFX_Handler;
	}
    }
//#if 0
    /* Update the TR69 ID obtained above to reflect in the Mappings for WAN MAIN */
    STRNCPY(wan_cfg->iid.tr69Id, wan_comm_cfg.WAN_CONN_IID.tr69Id, 
				            strlen(wan_comm_cfg.WAN_CONN_IID.tr69Id));
//#endif
    /*********** Device Configuration Block ****************/
    /* Device config thru Scripts/Utilities or Functions 
     * This would have been done from the WANIP or WANPPP calls */


    /*********** Notification Block *************/
    /* Notify the Internal TR69 Stack in case of MODIFY 
     * This Notification would only be for WAN MAIN params */
    if(IFX_MODIFY_F_SET(flags))
    {
        /* Notification for WAN MAIN mappings */
        /*Commented out for now until TR69 is enabled on PTM WAN*/
        //#if 0
        CHECK_N_SEND_NOTIFICATION(wan_cfg->iid, wan_main_changed_fcount, 
	  	 	      wan_main_changed_array_fvp, flags, IFX_Handler)
        //#endif
    }
    else if (IFX_INT_ADD_F_SET(flags))
    {
 	/* In case of ADD operation, first update the ID Mappings
	 * and then send the Notification for the attributes
	 */	
	/*********** Epilog Block **************/
        /*Commented out for now until TR69 is enabled on PTM WAN*/
        //#if 0
       UPDATE_ID_MAP_N_ATTRIBUTES(&wan_cfg->iid, wan_main_fvp_count, 
						wan_main_array_fvp, flags, IFX_Handler)
	//#endif	
	/* Update the "WAN" Index in WAN_MAIN Section */
	if (ifx_manipulate_wan_indexs(FILE_RC_CONF, TAG_WAN_MAIN, "wan_main_index", 
 				wan_cfg->wan_index,	IFX_F_INT_ADD) != IFX_SUCCESS)
       {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] ADD: Update WAN Index fail", __FUNCTION__, __LINE__);
            #endif
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }

	/* Manipulate nextCpeId only for ADD operations */
	ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WAN_MAIN); 
    }
    else if (IFX_DELETE_F_SET(flags))
    {
        /* In case of DELETE operation, first send the notificatioupdate the ID Mappings
	 * and then send the Notification for the attributes
	 */	
	/*********** Epilog Block **************/
        /*Commented out for now until TR69 is enabled on PTM WAN*/
        //#if 0
        UPDATE_ID_MAP_N_ATTRIBUTES(&wan_cfg->iid, wan_main_fvp_count, 
		 	          wan_main_array_fvp, flags, IFX_Handler)
        //#endif
	/* Delete the "WAN" Index in WAN_MAIN Section */
	if (ifx_manipulate_wan_indexs(FILE_RC_CONF, TAG_WAN_MAIN, "wan_main_index", 
				wan_cfg->wan_index, IFX_F_DELETE) != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Delete: Update WAN Index fail", __FUNCTION__, __LINE__);
            #endif
	    ret = IFX_FAILURE;
	    goto IFX_Handler;
        }
    }

    /* Updating Persistent Storage */
    ret = ifx_config_write(FILE_RC_CONF, flags);
    if(ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
	IFX_DBG("[%s:%d] Update Persistent Storage Fail", __FUNCTION__, __LINE__);
        #endif
	goto IFX_Handler;
    }

IFX_Handler:
    IFX_MEM_FREE(ret_WANConnDevStr)
    IFX_MEM_FREE(wan_main_changed_array_fvp)
    IFX_MEM_FREE(RetStr)
    IFX_MEM_FREE(ret_WANStr)
    if(ret != IFX_SUCCESS)
    {
        IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
    }
    return ret;
#else
	return IFX_SUCCESS;
#endif // CONFIG_FEATURE_PTM_WAN_SUPPORT
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_wan_ptm_config(...)
*	wanIdx		==>	input index of the wan connection for which configuration
*				has to be returned
*	wan_cfg		==>	output pointer to wan connection WAN_CONN_CFG
*	flags		==>	
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
		Description:
			This function reads the wan connection configuration from rc.conf
			for the input wan index wanIdx and based on the link type it
			reads the specific connection parameters from either the 
			wan_ip or wan_ppp section from rc.conf
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_wan_ptm_config(int32 wanIdx, WAN_CONN_CFG *wan_cfg, uint32 flags)
{
#ifdef CONFIG_FEATURE_PTM_WAN_SUPPORT
    IFX_ID iid;
    int32 dist_wan_index = -1, i = 0;
    char8 buf[MAX_FILELINE_LEN], *vpi = NULL, *vci = NULL, retVal[MAX_FILELINE_LEN], *dns_servers = NULL;
    char8 * iface = NULL;
    int32 ret=IFX_SUCCESS, outFlag = IFX_F_DEFAULT;
    WAN_COMMON_CFG wan_comm_cfg;
    char8 name[16]="";
    NET_INTF_CFG params;

    memset(&wan_comm_cfg, 0x00, sizeof(wan_comm_cfg));

    /* Check if wan_index is passed or not. If passed get wan connection type from wan_index
     * If not passed then get wan index for the cpeid passed
     * if both wan index and cpeid are not passed return error !! */
    sprintf(iid.cpeId.secName, "%s", TAG_WAN_MAIN);
    iid.cpeId.Id = wan_cfg->iid.cpeId.Id;

    if(wanIdx < 0)
    {
        if(wan_cfg->iid.cpeId.Id < 1)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Invalid wan index and cpe Id", __FUNCTION__, __LINE__);
            #endif
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }

        if(ifx_get_index_from_cpe_id(FILE_RC_CONF, &iid.cpeId, &dist_wan_index) != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Unable to retrieve wan index from cpeId", __FUNCTION__, __LINE__);
            #endif
            ret = IFX_FAILURE;
            goto IFX_Handler;
        }
        wan_cfg->wan_index = dist_wan_index;
    }
    else
        wan_cfg->wan_index = wanIdx;

    /* initialize the cache for this instance */
    sprintf(buf, "%s_%d_", PREFIX_WAN_MAIN, wan_cfg->wan_index);
    if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, IFX_F_INT_CACHE_INIT | flags, NULL, NULL) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
        #endif
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    sprintf(buf, "wan_%d_cpeId", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *) &outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve cpeId", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_cfg->iid.cpeId.Id = atoi(retVal);

    sprintf(buf, "wan_%d_pcpeId", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *) &outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve parent cpeId", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_cfg->iid.pcpeId.Id = atoi(retVal);

    sprintf(buf, "wan_%d_linkType", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve LinkType", __FUNCTION__, __LINE__);
        #endif
	goto IFX_Handler;
    }
    wan_cfg->type = atoi(retVal);

    /* Determine the WAN Connection Type - WAN_IP or WAN_PPP from
     * the link type associated with the WAN device */
    if (wan_cfg->type == LINK_TYPE_PPPOE)
    {
        wan_comm_cfg = wan_cfg->WAN_PPP_CONN.WAN_CONN;
    }
    else
    {
        /* Case of UnConfigured is assumed to be WAN_IP */
        wan_comm_cfg = wan_cfg->WAN_IP_CONN.WAN_CONN;
    }

    sprintf(buf, "Wan%d_IF_Info", wan_cfg->wan_index);
    if((ret = ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "bringup_time_secs", flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve IF Info", __FUNCTION__, __LINE__);
        #endif
    }
    else
    {
        struct sysinfo info;
				memset(&info,0,sizeof(info));
        sysinfo(&info);
        wan_comm_cfg.uptime = info.uptime - atol(retVal);
    }

    sprintf(buf, "wan_%d_autoDiscTime", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve autoDiscTime", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_AUTO_DISCONNECT_TIME = atoi(retVal);

    sprintf(buf, "wan_%d_idleDiscTime", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve idleDiscTime", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_IDLE_DISCONNECT_TIME = atoi(retVal);

    sprintf(buf, "wan_%d_warnDiscTime", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve warnDiscTime", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_WARN_DISCONNECT_TIME = atoi(retVal);

    sprintf(buf, "wan_%d_RSIP", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve RSIP", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_RSIP_AVAILABLE = atoi(retVal);

    sprintf(buf, "wan_%d_NATEnable", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve NAT Enable value", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_NAT_ENABLED = atoi(retVal);

    sprintf(buf, "wan_%d_DNSEnable", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve DNS Enable value", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_DNS_ENABLED = atoi(retVal);

    sprintf(buf, "wan_%d_DNSOverride", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve  DNS Override value", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_DNS_OVERRIDE = atoi(retVal);

    if(wan_comm_cfg.WAN_CONN_DNS_OVERRIDE == IFX_DISABLED)
    {
        /* read dns server values from rc.conf */
        sprintf(buf, "wan_%d_DNSServers", wan_cfg->wan_index);
        if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Unable to retrieve DNS Server info", __FUNCTION__, __LINE__);
            #endif
            goto IFX_Handler;
        }

        dns_servers = strtok(retVal, ",");
        i = 0;
        while(dns_servers != NULL)
        {
            wan_comm_cfg.dns_servers[i].s_addr = inet_addr(dns_servers);
            dns_servers = strtok(NULL, ",");
            i++;
        }
    }
    else
    {
        /* read dns server ip addressed from system_status */
        sprintf(buf, "WAN%d_DNS_SERVER", wan_cfg->wan_index);
        if((ret = ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "DNS1", flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Unable to retrieve DNS1 value from system status file", __FUNCTION__, __LINE__);
            #endif
        }
        else
            wan_comm_cfg.dns_servers[0].s_addr = inet_addr(retVal);

        if((ret = ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "DNS2", flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Unable to retrieve DNS2 value from system status file", __FUNCTION__, __LINE__);
            #endif
        }
        else
            wan_comm_cfg.dns_servers[1].s_addr = inet_addr(retVal);

	if((ret = ifx_GetObjData(FILE_SYSTEM_STATUS, buf, "DNS3", flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
        {
            #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] Unable to retrieve DNS3 value from system status file", __FUNCTION__, __LINE__);
            #endif
        }
	else
            wan_comm_cfg.dns_servers[2].s_addr = inet_addr(retVal);
    }

    memset(&params,0,sizeof(params));
    ifx_mod_interface_attr(name,IFX_GET_INTF_ATTR,&params);
    snprintf(wan_comm_cfg.WAN_CONN_MAC_ADDR,MAX_MAC_ADDR_LEN,"%s", params.hwaddr);

    sprintf(buf, "wan_%d_macAddrOverride", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve macAddrOverride", __FUNCTION__, __LINE__);
        #endif
	goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_MAC_ADDR_OVERRIDE = atoi(retVal);

    sprintf(buf, "wan_%d_connTrigger", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve connection trigger value", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_TRIGGER = atoi(retVal);

    sprintf(buf, "wan_%d_rxRouteProto", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve routing protocol", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_ROUTE_PROTO_RX = atoi(retVal);

    sprintf(buf, "wan_%d_fEnable", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve enable value", __FUNCTION__, __LINE__);
        #endif 
        goto IFX_Handler;
    }
    wan_comm_cfg.WAN_CONN_ENABLE = atoi(retVal);

    sprintf(buf, "wan_%d_connName", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve connection name", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    strlcpy(wan_comm_cfg.WAN_CONN_NAME, retVal,MAX_CONN_NAME_LEN);

    sprintf(buf, "wan_%d_wanMode", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *) &outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve wan mode", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    wan_cfg->wan_mode.mode = atoi(retVal);

    sprintf(buf, "wan_%d_vlanId", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *) &outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve vlan Id", __FUNCTION__, __LINE__);
	#endif
		goto IFX_Handler;
    }
    wan_cfg->vlanId = atoi(retVal);

    sprintf(buf, "wan_%d_iface", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *) &outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve interface name", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    iface = strtok(retVal, ".");
    sprintf(wan_cfg->wan_mode.iface, "%s", iface);

    sprintf(buf, "wan_%d_conf_connName", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *) &outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve wan_%d_conf_connName", __FUNCTION__, __LINE__, wan_cfg->wan_index);
        #endif
        goto IFX_Handler;
    }
    strlcpy(wan_comm_cfg.WAN_CONF_CONN_NAME, retVal,MAX_CONN_NAME_LEN);

    /* get the vpi vci out of retVal */
    sprintf(buf, "wan_%d_vcc", wan_cfg->wan_index);
    if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, flags, (IFX_OUT uint32 *)&outFlag, retVal)) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Unable to retrieve VCC", __FUNCTION__, __LINE__);
        #endif
        goto IFX_Handler;
    }
    vpi = strtok(retVal, "/");
    vci = strtok(NULL, "/");
    if(vpi != NULL)
        wan_cfg->vc.pvc.vpi = atoi(vpi);
    if(vci != NULL)
        wan_cfg->vc.pvc.vci = atoi(vci);

    /* destroy the cache for this instance */
    sprintf(buf, "%s_%d_", PREFIX_WAN_MAIN, wan_cfg->wan_index);
    if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Failed to destroy cache for this instance", __FUNCTION__, __LINE__);
        #endif
        ret = IFX_FAILURE;
        goto IFX_Handler;
    }

    if(wan_cfg->type == WAN_LINK_TYPE_PPPOE)
    {
        memcpy(&wan_cfg->WAN_PPP_CONN.WAN_CONN, &wan_comm_cfg, sizeof(wan_comm_cfg));
        ifx_get_wan_ppp_config(wan_cfg->wan_index, wan_cfg, flags);
    }
    else
    {
        memcpy(&wan_cfg->WAN_IP_CONN.WAN_CONN, &wan_comm_cfg, sizeof(wan_comm_cfg));
        ifx_get_wan_ip_config(wan_cfg->wan_index, wan_cfg, flags);
    }

IFX_Handler:
    /* destroy the cache for this instance */
    sprintf(buf, "%s_%d_", PREFIX_WAN_MAIN, wan_cfg->wan_index);
    if(ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WAN_MAIN, buf, IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s:%d] Failed to destroy cache for this instance", __FUNCTION__, __LINE__);
        #endif
        ret = IFX_FAILURE;
    }
    if (ret != IFX_SUCCESS)
    {
        #ifdef IFX_LOG_DEBUG
        IFX_DBG("[%s] : returned failure!", __FUNCTION__);
        #endif
    }
    return ret;
#else
    return IFX_SUCCESS;
#endif // CONFIG_FEATURE_PTM_WAN_SUPPORT
}
