#include <time.h>
#include "interfaces.h"

#if 0
#define ifx_snmp_dbg(format, args...) printf(format, ##args)
#else
#define ifx_snmp_dbg(format, args...)
#endif

#define DEBUGMSGTL(x)
#define ip_addr_maskcmp(addr1, addr2, mask) ((addr1 & mask) == \
                                             (addr2 & mask))
/*
 * if_type_from_name
 * Return interface type using the interface name as a clue.
 * Returns 1 to imply "other" type if name not recognized.
 */
static int
if_type_from_name(const char *pcch)
{
    typedef struct _match_if {
        int             mi_type;
        const char     *mi_name;
    }              *pmatch_if, match_if;

    static match_if lmatch_if[] = {
        {24, "lo"},
        {6, "eth"},
        {9, "tr"},
        {23, "ppp"},
        {28, "sl"},
        {94, "MEI_PHY"},
        {124, "MEI_INTL"},
        {125, "MEI_FAST"},
        {0, 0}                  /* end of list */
    };
    int             ii, len;
    register pmatch_if pm;

    for (ii = 0, pm = lmatch_if; pm->mi_name; pm++) {
        len = strlen(pm->mi_name);
        if (0 == strncmp(pcch, pm->mi_name, len)) {
            return (pm->mi_type);
        }
    }
    return (1);                 /* in case search fails */
}

/**
* Determines network interface speed. It is system specific. Only linux
* realization is made.
*/
unsigned int getIfSpeed(int fd, struct ifreq ifr){
    unsigned int retspeed = 10000000;
/* the code is based on mii-diag utility by Donald Becker
* see ftp://ftp.scyld.com/pub/diag/mii-diag.c
*/
    ushort *data = (ushort *)(&ifr.ifr_data);
    unsigned phy_id;
    unsigned char new_ioctl_nums = 0;
    int mii_reg, i;
    ushort mii_val[32];
    ushort bmcr, bmsr, nway_advert, lkpar;
    const unsigned int media_speeds[] = {10000000, 10000000, 100000000, 100000000, 10000000, 0};
/* It corresponds to "10baseT", "10baseT-FD", "100baseTx", "100baseTx-FD", "100baseT4", "Flow-control", 0, */

    data[0] = 0;

    if (ioctl(fd, 0x8947, &ifr) >= 0) {
        new_ioctl_nums = 1;
    } else if (ioctl(fd, SIOCDEVPRIVATE, &ifr) >= 0) {
        new_ioctl_nums = 0;
    } else {
        DEBUGMSGTL(("mibII/interfaces", "SIOCGMIIPHY on %s failed\n", ifr.ifr_name));
        return retspeed;
    }
/* Begin getting mii register values */
    phy_id = data[0];
    for (mii_reg = 0; mii_reg < 8; mii_reg++){
        data[0] = phy_id;
        data[1] = mii_reg;
        if(ioctl(fd, new_ioctl_nums ? 0x8948 : SIOCDEVPRIVATE+1, &ifr) <0){
            DEBUGMSGTL(("mibII/interfaces", "SIOCGMIIREG on %s failed\n", ifr.ifr_name));
        }
        mii_val[mii_reg] = data[3];
    }
/*Parsing of mii values*/
/*Invalid basic mode control register*/
    if (mii_val[0] == 0xffff  ||  mii_val[1] == 0x0000) {
        DEBUGMSGTL(("mibII/interfaces", "No MII transceiver present!.\n"));
        return retspeed;
    }
    /* Descriptive rename. */
    bmcr = mii_val[0];    /*basic mode control register*/
    bmsr = mii_val[1];    /* basic mode status register*/
    nway_advert = mii_val[4]; /* autonegotiation advertisement*/
    lkpar = mii_val[5];       /*link partner ability*/

/*Check for link existence, returns 0 if link is absent*/
    if ((bmsr & 0x0016) != 0x0004){
        DEBUGMSGTL(("mibII/interfaces", "No link...\n"));
        retspeed = 0;
        return retspeed;
    }

    if(!(bmcr & 0x1000) ){
        DEBUGMSGTL(("mibII/interfaces", "Auto-negotiation disabled.\n"));
        retspeed = bmcr & 0x2000 ? 100000000 : 10000000;
        return retspeed;
    }
/* Link partner got our advertised abilities */
    if (lkpar & 0x4000) {
        int negotiated = nway_advert & lkpar & 0x3e0;
        int max_capability = 0;
        /* Scan for the highest negotiated capability, highest priority
           (100baseTx-FDX) to lowest (10baseT-HDX). */
        int media_priority[] = {8, 9, 7, 6, 5};     /* media_names[i-5] */
        for (i = 0; media_priority[i]; i++){
            if (negotiated & (1 << media_priority[i])) {
                max_capability = media_priority[i];
                break;
            }
        }
        if (max_capability)
            retspeed = media_speeds[max_capability - 5];
        else
            DEBUGMSGTL(("mibII/interfaces", "No common media type was autonegotiated!\n"));
    }else if(lkpar & 0x00A0){
        retspeed = (lkpar & 0x0080) ? 100000000 : 10000000;
    }
    return retspeed;
}


void
Interface_Scan_Init(void)
{
    char            line[256], ifname_buf[64], *ifname, *ptr;
    struct ifreq    ifrq;
    struct ifnet  **ifnetaddr_ptr;
    FILE           *devin;
    unsigned long   rec_pkt = 0, rec_oct = 0, rec_err = 0, rec_drop = 0;
    unsigned long   snd_pkt = 0, snd_oct = 0, snd_err = 0, snd_drop = 0, coll = 0;
    int             i, fd;
    conf_if_list   *if_ptr;
    const char     *scan_line_2_2 =
        "%lu %lu %lu %lu %*lu %*lu %*lu %*lu %lu %lu %lu %lu %*lu %lu";
    const char     *scan_line_2_0 =
        "%lu %lu %*lu %*lu %*lu %lu %lu %*lu %*lu %lu";
    const char     *scan_line_to_use;
    struct timeval et;                              /* elapsed time */
    memset(&et,0,sizeof(et));

    /*  disallow reloading of structures too often */
    gettimeofday ( &et, ( struct timezone * ) 0 );  /*  get time-of-day */
    if ( et.tv_sec < LastLoad + MINLOADFREQ ) {     /*  only reload so often */
      ifnetaddr = ifnetaddr_list;                   /*  initialize pointer */
      return;
    }
    LastLoad = et.tv_sec;

    /*
     * free old list:
     */
    while (ifnetaddr_list) {
        struct ifnet   *old = ifnetaddr_list;
        ifnetaddr_list = ifnetaddr_list->if_next;
        free(old->if_name);
        free(old->if_unit);
        free(old);
    }

    ifnetaddr = 0;
    ifnetaddr_ptr = &ifnetaddr_list;

    if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        DEBUGMSGTL(("snmpd",
                    "socket open failure in Interface_Scan_Init\n"));
        return; /** exit (1); **/
    }

    /*
     * build up ifnetaddr list by hand:
     */

    /*
     * at least linux v1.3.53 says EMFILE without reason...
     */
    if (!(devin = fopen("/proc/net/dev", "r"))) {
        close(fd);
        /* snmp_log(LOG_ERR, "cannot open /proc/net/dev - continuing...\n"); */
        return; /** exit (1); **/
    }

    i = 0;

    /*
     * read the second line (a header) and determine the fields we
     * should read from.  This should be done in a better way by
     * actually looking for the field names we want.  But thats too
     * much work for today.  -- Wes
     */
    fgets(line, sizeof(line), devin);
    fgets(line, sizeof(line), devin);
    if (strstr(line, "compressed")) {
        scan_line_to_use = scan_line_2_2;
        DEBUGMSGTL(("mibII/interfaces",
                    "using linux 2.2 kernel /proc/net/dev\n"));
    } else {
        scan_line_to_use = scan_line_2_0;
        DEBUGMSGTL(("mibII/interfaces",
                    "using linux 2.0 kernel /proc/net/dev\n"));
    }


    while (fgets(line, sizeof(line), devin)) {
        struct ifnet   *nnew;
        char           *stats, *ifstart = line;

        if (line[strlen(line) - 1] == '\n')
            line[strlen(line) - 1] = '\0';

        while (*ifstart && *ifstart == ' ')
            ifstart++;

        if (!*ifstart || ((stats = strrchr(ifstart, ':')) == NULL)) {
            /*snmp_log(LOG_ERR,
                     "/proc/net/dev data format error, line ==|%s|", line); */
            continue;
        }
        if ((scan_line_to_use == scan_line_2_2) && ((stats - line) < 6)) {
            /* snmp_log(LOG_ERR,
                     "/proc/net/dev data format error, line ==|%s|", line); */
        }

        *stats   = 0;
        strncpy(ifname_buf, ifstart, sizeof(ifname_buf));
        ifname_buf[ sizeof(ifname_buf)-1 ] = 0;
        *stats++ = ':';
        while (*stats == ' ')
            stats++;

        if ((scan_line_to_use == scan_line_2_2 &&
             sscanf(stats, scan_line_to_use, &rec_oct, &rec_pkt, &rec_err,
                    &rec_drop, &snd_oct, &snd_pkt, &snd_err, &snd_drop,
                    &coll) != 9) || (scan_line_to_use == scan_line_2_0
                                     && sscanf(stats, scan_line_to_use,
                                               &rec_pkt, &rec_err,
                                               &snd_pkt, &snd_err,
                                               &coll) != 5)) {
            if ((scan_line_to_use == scan_line_2_2)
                && !strstr(line, "No statistics available"))
                /* snmp_log(LOG_ERR,
                         "/proc/net/dev data format error, line ==|%s|",
                         line); */
            continue;
        }

        nnew = (struct ifnet *) calloc(1, sizeof(struct ifnet));
        if (nnew == NULL)
            break;              /* alloc error */

        /*
//         * chain in:
         */
        *ifnetaddr_ptr = nnew;
        ifnetaddr_ptr = &nnew->if_next;
        i++;

        /*
         * linux previous to 1.3.~13 may miss transmitted loopback pkts:
         */
        if (!strcmp(ifname_buf, "lo") && rec_pkt > 0 && !snd_pkt)
            snd_pkt = rec_pkt;

        nnew->if_ipackets = rec_pkt;
        nnew->if_ierrors = rec_err;
        nnew->if_opackets = snd_pkt;
        nnew->if_oerrors = snd_err;
        nnew->if_collisions = coll;
        if (scan_line_to_use == scan_line_2_2) {
            nnew->if_ibytes = rec_oct;
            nnew->if_obytes = snd_oct;
            nnew->if_iqdrops = rec_drop;
            nnew->if_snd.ifq_drops = snd_drop;
        } else {
            nnew->if_ibytes = rec_pkt * 308;
            nnew->if_obytes = snd_pkt * 308;
        }

        /*
         * ifnames are given as ``   eth0'': split in ``eth'' and ``0'':
         */
        for (ifname = ifname_buf; *ifname && *ifname == ' '; ifname++);

        /*
         * set name and interface# :
         */
        nnew->if_name = (char *) strdup(ifname);
        for (ptr = nnew->if_name; ptr && *ptr && (*ptr < '0' || *ptr > '9');
             ptr++);
        nnew->if_unit = strdup(*ptr ? ptr : "");
        *ptr = 0;

        strncpy(ifrq.ifr_name, ifname, sizeof(ifrq.ifr_name));
        ifrq.ifr_name[ sizeof(ifrq.ifr_name)-1 ] = 0;
        if (ioctl(fd, SIOCGIFADDR, &ifrq) < 0)
            memset((char *) &nnew->if_addr, 0, sizeof(nnew->if_addr));
        else
            nnew->if_addr = ifrq.ifr_addr;

        strncpy(ifrq.ifr_name, ifname, sizeof(ifrq.ifr_name));
        ifrq.ifr_name[ sizeof(ifrq.ifr_name)-1 ] = 0;
        if (ioctl(fd, SIOCGIFBRDADDR, &ifrq) < 0)
            memset((char *) &nnew->ifu_broadaddr, 0,
                   sizeof(nnew->ifu_broadaddr));
        else
            nnew->ifu_broadaddr = ifrq.ifr_broadaddr;

        strncpy(ifrq.ifr_name, ifname, sizeof(ifrq.ifr_name));
        ifrq.ifr_name[ sizeof(ifrq.ifr_name)-1 ] = 0;
        if (ioctl(fd, SIOCGIFNETMASK, &ifrq) < 0)
            memset((char *) &nnew->ia_subnetmask, 0,
                   sizeof(nnew->ia_subnetmask));
        else
            nnew->ia_subnetmask = ifrq.ifr_netmask;

        strncpy(ifrq.ifr_name, ifname, sizeof(ifrq.ifr_name));
        ifrq.ifr_name[ sizeof(ifrq.ifr_name)-1 ] = 0;
        nnew->if_flags = ioctl(fd, SIOCGIFFLAGS, &ifrq) < 0
            ? 0 : ifrq.ifr_flags;

        nnew->if_type = 0;

        strncpy(ifrq.ifr_name, ifname, sizeof(ifrq.ifr_name));
        ifrq.ifr_name[ sizeof(ifrq.ifr_name)-1 ] = 0;
        if (ioctl(fd, SIOCGIFHWADDR, &ifrq) < 0)
            memset(nnew->if_hwaddr, (0), 6);
        else {
            memcpy(nnew->if_hwaddr, ifrq.ifr_hwaddr.sa_data, 6);

#ifdef ARPHRD_LOOPBACK
            switch (ifrq.ifr_hwaddr.sa_family) {
            case ARPHRD_ETHER:
                nnew->if_type = 6;
                break;
            case ARPHRD_TUNNEL:
            case ARPHRD_TUNNEL6:
#ifdef ARPHRD_IPGRE
            case ARPHRD_IPGRE:
#endif
            case ARPHRD_SIT:
                nnew->if_type = 131;
                break;          /* tunnel */
            case ARPHRD_SLIP:
            case ARPHRD_CSLIP:
            case ARPHRD_SLIP6:
            case ARPHRD_CSLIP6:
                nnew->if_type = 28;
                break;          /* slip */
            case ARPHRD_PPP:
                nnew->if_type = 23;
                break;          /* ppp */
            case ARPHRD_LOOPBACK:
                nnew->if_type = 24;
                break;          /* softwareLoopback */
            case ARPHRD_FDDI:
                nnew->if_type = 15;
                break;
            case ARPHRD_ARCNET:
                nnew->if_type = 35;
                break;
            case ARPHRD_LOCALTLK:
                nnew->if_type = 42;
                break;
#ifdef ARPHRD_HIPPI
            case ARPHRD_HIPPI:
                nnew->if_type = 47;
                break;
#endif
#ifdef ARPHRD_ATM
            case ARPHRD_ATM:
                nnew->if_type = 37;
                break;
#endif
                /*
                 * XXX: more if_arp.h:ARPHDR_xxx to IANAifType mappings...
                 */
            }
#endif
        }

        strncpy(ifrq.ifr_name, ifname, sizeof(ifrq.ifr_name));
        ifrq.ifr_name[ sizeof(ifrq.ifr_name)-1 ] = 0;
        nnew->if_metric = ioctl(fd, SIOCGIFMETRIC, &ifrq) < 0
            ? 0 : ifrq.ifr_metric;

#ifdef SIOCGIFMTU
        strncpy(ifrq.ifr_name, ifname, sizeof(ifrq.ifr_name));
        ifrq.ifr_name[ sizeof(ifrq.ifr_name)-1 ] = 0;
        nnew->if_mtu = (ioctl(fd, SIOCGIFMTU, &ifrq) < 0)
            ? 0 : ifrq.ifr_mtu;
#else
        nnew->if_mtu = 0;
#endif

        for (if_ptr = conf_list; if_ptr; if_ptr = if_ptr->next)
            if (!strcmp(if_ptr->name, ifname))
                break;

        if (if_ptr) {
            nnew->if_type = if_ptr->type;
            nnew->if_speed = if_ptr->speed;
        } else {
            /*
             * do only guess if_type from name, if we could not read
             * * it before from SIOCGIFHWADDR
             */
            if (!nnew->if_type)
                nnew->if_type = if_type_from_name(nnew->if_name);
            nnew->if_speed = nnew->if_type == 6 ? getIfSpeed(fd, ifrq) :
                nnew->if_type == 24 ? 10000000 :
                nnew->if_type == 9 ? 4000000 : 0;
            /*Zero speed means link problem*/
            if(nnew->if_speed == 0 && nnew->if_flags & IFF_UP){
                nnew->if_flags &= ~IFF_RUNNING;
            }
        }

    }                           /* while (fgets ... */

    ifnetaddr = ifnetaddr_list;
#if 0
    if (snmp_get_do_debugging()) {
        {
            struct ifnet   *x = ifnetaddr;
            DEBUGMSGTL(("mibII/interfaces", "* see: known interfaces:"));
            while (x) {
                DEBUGMSG(("mibII/interfaces", " %s", x->if_name));
                x = x->if_next;
            }
            DEBUGMSG(("mibII/interfaces", "\n"));
        }                       /* XXX */
    }
#endif //0

    fclose(devin);
    close(fd);
}
#if 1
/*
 * **  4.2 BSD doesn't have ifaddr
 * **
 */
int
Interface_Scan_Next(short *Index,
                    char *Name,
                    struct ifnet *Retifnet, struct in_ifaddr *dummy)
{
    static struct ifnet    ifnet;
    register char  *cp;

    while (ifnetaddr) {
        /*
         *      Get the "ifnet" structure and extract the device name
         */
        ifnet = *ifnetaddr;
        strncpy(saveName, ifnet.if_name, sizeof(saveName));
        if (strcmp(saveName, "ip") == 0) {
            ifnetaddr = ifnet.if_next;
            continue;
        }
        saveName[sizeof(saveName) - 1] = '\0';
        cp = (char *) strchr(saveName, '\0');
        if (cp != NULL)
		strncat(cp, ifnet.if_unit, sizeof(saveName)-strlen(saveName)-1);
        saveName[sizeof(saveName) - 1] = '\0';
        if (1 || strcmp(saveName, "lo0") != 0) {        /* XXX */
#if 0
#if 1
// Modification made for Amazon
           if (Index)
              GetIfIndex(saveName,Index);
#else
            if (Index)
                *Index = ++saveIndex;
#endif // 0
#endif // 0
            if (Retifnet)
                *Retifnet = ifnet;
            if (Name)
                strcpy(Name, saveName);
            saveifnet = &ifnet;
            saveifnetaddr = ifnetaddr;
            ifnetaddr = ifnet.if_next;
            return (1);         /* DONE */
        }
        ifnetaddr = ifnet.if_next;
    }
    return (0);                 /* EOF */
}

int
Interface_Scan_By_Index(int Index,
                        char *Name,
                        struct ifnet *Retifnet,
                        struct in_ifaddr *Retin_ifaddr)
{
    short           i=0;

    Interface_Scan_Init();
    while (Interface_Scan_Next(&i, Name, Retifnet, Retin_ifaddr)) {
        if (i == Index)
            break;
    }
    if (i != Index)
        return (-1);            /* Error, doesn't exist */
    return (0);                 /* DONE */
}
#endif // 0


#if 1
struct ifnet *Get_Ifnet_From_Addr (struct in_addr *dest)
{
    struct ifnet    *ifnet;
    unsigned int addr, mask;

    Interface_Scan_Init();

    while (ifnetaddr) {
        /*
         *      Get the "ifnet" structure and extract the device name
         */
        ifnet = ifnetaddr;
	addr = (unsigned int) ifnet->if_addr.sa_data;
	mask = (unsigned int) ifnet->ia_subnetmask.sa_data;
	if (!ip_addr_maskcmp (dest->s_addr, addr, mask)){
            ifnetaddr = ifnet->if_next;
            continue;
	}
    	ifx_snmp_dbg ("in file %s, fxn %s line %d\n", __FILE__, __FUNCTION__, __LINE__);
            return ifnet;         /* DONE */
    }
    ifx_snmp_dbg ("in file %s, fxn %s line %d\n", __FILE__, __FUNCTION__, __LINE__);
    return NULL;
	

}
#endif

#if 1
struct ifnet *Get_Ifnet (short Index, char *Name)
{
    struct ifnet    *ifnet;
    // char   *cp;
	char   saveName[16];

    Interface_Scan_Init();

	ifnet = ifnetaddr;
    while (ifnet) {
        /*
         *      Get the "ifnet" structure and extract the device name
         */
		
        strlcpy(saveName, ifnet->if_name, sizeof(saveName));
		strlcat(saveName, ifnet->if_unit,sizeof(saveName));
		ifx_snmp_dbg ("saveName %s ifnet->if_unit %s\n", saveName, ifnet->if_unit);
        if ((strcmp(saveName, Name)) != 0) {
            ifnet = ifnet->if_next;
            continue;
        }
    	    ifx_snmp_dbg ("in file %s, fxn %s line %d\n", __FILE__, __FUNCTION__, __LINE__);
            return ifnet;         /* DONE */
    }
    ifx_snmp_dbg ("in file %s, fxn %s line %d\n", __FILE__, __FUNCTION__, __LINE__);
    return NULL;
}
#else
struct ifnet *Get_Ifnet (short Index, char *Name)
{
	struct ifnet ifnet_entry;
	struct ifnet *ifnet;
	
	ifx_snmp_dbg ("in file %s, fxn %s line %d index %d name %s\n", __FILE__, __FUNCTION__, __LINE__, Index, Name);
	Interface_Scan_By_Index (&Index, Name, &ifnet_entry, NULL);
	ifnet = &ifnet_entry;
	ifx_snmp_dbg ("ifnet %x\n", ifnet);
	return ifnet;
    
}
#endif //0

static int      Interface_Count = 0;
static time_t   scan_time = 0;

int
Interface_Scan_Get_Count(void)
{
    time_t          time_now = time(NULL);
    if (!Interface_Count || (time_now > scan_time + 60)) {
        scan_time = time_now;
        Interface_Scan_Init();
        Interface_Count = 0;
        while (Interface_Scan_Next(NULL, NULL, NULL, NULL) != 0) {
            Interface_Count++;
        }
    }
    // This is mem fix
    while (ifnetaddr_list) {
        struct ifnet   *old = ifnetaddr_list;
        ifnetaddr_list = ifnetaddr_list->if_next;
        free(old->if_name);
        free(old->if_unit);
        free(old);
    }

    return (Interface_Count);
}


