
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <stdlib.h>
#include <unistd.h>
//#include <arpa/inet.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"
#if defined(IFX_SMALL_FOOTPRINT) && defined(IFX_DLOAD_LIBCRYPT)
//6090602:hsumc change default libcrypt-0.9.26.so to libcrypt.so
#define LIBCRYPT	"libcrypt.so.0"
#include <dlfcn.h>
#else
#include "crypt.h"
#endif
#ifndef HOSTENV
#include "image.h"
#endif
#include "crc32.h"

#ifdef CONFIG_FEATURE_SAMBA //#ifdef CONFIG_PACKAGE_samba3
char8 *smb_param_names[] = {"smb_cpeId", "smb_pcpeId", "smb_ena", "smb_name", "smb_descr", "smb_workgroup"};
char8 *fs_param_names[] = {"cpeId", "pcpeId", "name", "path", "rwLvl", "users"};
//char8 *fu_param_names[] = {"cpeId", "pcpeId", "ena", "name", "pwd", "share", "rwLvl"};
char8 *fu_param_names[] = {"cpeId", "pcpeId", "name", "pwd", "share", "rwLvl"};
#define IFX_FILE_SHARE_PARAM_COUNT 6
#define IFX_FILE_USER_PARAM_COUNT 6

#define PREFIX_SAMBA_SERVER "smb"
#define PREFIX_FILE_SHARE "fs"
#define PREFIX_FILE_USER "fu"

#define IFX_VALIDATE_SHARE_INFO(entry, flags) {\
				if(IFX_INT_ADD_F_SET(flags) || IFX_MODIFY_F_SET(flags)) { \
					/* check for duplicate share entry */ \
					if((ret = ifx_duplicate_share(entry->iid.cpeId, entry)) != IFX_SUCCESS) {\
						goto IFX_Handler; \
					} \
				} \
			}

#define IFX_VALIDATE_USER_INFO(entry, flags) {\
				if(IFX_INT_ADD_F_SET(flags) || IFX_MODIFY_F_SET(flags)) { \
					/* check for duplicate user entry */ \
					if((ret = ifx_duplicate_user(entry->iid.cpeId, entry->userName)) != IFX_SUCCESS) {\
						goto IFX_Handler; \
					} \
				} \
			}

#ifndef HOSTENV
int ifx_set_system_username_password(uint32 oper, uint32 id, char *name, char *password)
{
    const char *fname = "/ramdisk/flash/passwd";
    char sLine[MAX_FILELINE_LEN];
    char user[MAX_NAME_LEN];
    int user_len = 0;
    FILE *fp = NULL;
    FILE *fp1 = NULL;
    char *cp = NULL;
    char8	sValue[MAX_FILELINE_LEN];
    int32	outflags = IFX_F_DEFAULT;
    int ret = IFX_SUCCESS;
#if defined(IFX_SMALL_FOOTPRINT) && defined(IFX_DLOAD_LIBCRYPT)
    char *(*crypt_ptr)(char *,char *) = NULL;
    void *dlHandle = NULL;
    char *error = NULL;
#endif

    if (oper != IFX_OP_DEL) {
#if defined(IFX_SMALL_FOOTPRINT) && defined(IFX_DLOAD_LIBCRYPT)
        dlHandle = dlopen(LIBCRYPT,RTLD_LAZY);
        if(dlHandle) {
            crypt_ptr = dlsym(dlHandle,"crypt");
            if((error = dlerror()) != NULL) {
#ifdef IFX_LOG_DEBUG
                IFX_DBG( "could not find function crypt in libcrypt. Error : %s\n",error);
#endif
    	    }
    	    if (crypt_ptr != NULL)
    	    	cp = (char *)(*crypt_ptr)(password, "$1$");
    	    dlclose(dlHandle);
        } else {
#ifdef IFX_LOG_DEBUG
            IFX_DBG( "could not open library %s",LIBCRYPT);
#endif
        }
#else
        cp = (char *)crypt(password, "$1$");
#endif
    }
    sprintf(user, "%s:", name);
    user_len = strlen(user);
    sLine[0]='\0';
    if (oper == IFX_OP_ADD) {
	if ( (ret = ifx_GetObjData(FILE_RC_CONF, TAG_NEXT_CPEID, "file_user_nextCpeId", 
			IFX_F_DEFAULT, (IFX_OUT uint32 *)&outflags, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		return ret;
	}

	id = atoi(sValue);

        if ((fp = fopen(fname, "a+")) == NULL)
        {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\nCan't open/create file %s\n", fname);
#endif
            return -1;
        }
        while (fgets(sLine, sizeof(sLine), fp)) {
            if (!strncmp(sLine, user, user_len)) {
#ifdef IFX_LOG_DEBUG
                IFX_DBG("[%s] : user already exists!", __FUNCTION__);
#endif
                fclose(fp);
		return IFX_DUPLICATE_ENTRY;
            }
        }
#if 0
        fprintf(fp, "%s:%s:%d:200:%s:/tmp:/bin/sh\n", name, cp, 500 + id, "usergrp"); // FIXME: get next id first
#else
        fprintf(fp, "%s:%s:%d:0:users:/tmp:/bin/sh\n", name, cp, 200 + id);
#endif
        fflush(fp);
        fclose(fp);
    } else if (oper == IFX_OP_MOD || oper == IFX_OP_DEL) {
        if ((fp = fopen(fname, "r")) == NULL)
        {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\nCan't open/create file %s\n", fname);
#endif
            return -1;
        }
        if ((fp1 = fopen("/tmp/tmp_passwd", "w")) == NULL)
        {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("\nCan't open/create file %s\n", fname);
#endif
	    fclose(fp);
            return -1;
        }
        while (fgets(sLine, sizeof(sLine), fp)) {
            if (strncmp(sLine, user, user_len)) {
                fprintf(fp1, "%s", sLine);
            }
        }
	if (oper == IFX_OP_MOD)
#if 0
            fprintf(fp1, "%s:%s:%d:200:%s:/tmp:/bin/sh\n", name, cp, 200 + id, "usergrp");
#else
            fprintf(fp1, "%s:%s:%d:0:users:/tmp:/bin/sh\n", name, cp, 200 + id);
#endif
        fflush(fp1);
        fclose(fp);
        fclose(fp1);
	ifx_copy_file("/tmp/tmp_passwd", "/ramdisk/flash/passwd");
    }

    return IFX_SUCCESS;
}
#endif // HOSTENV

/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_samba_server(...)
*	oper	==>   the operation to be performed for the samba server, can be MODIFY only
*    	smbSrvr	==>   pointer to LTQ_MAPI_SAMBA_Server structure that has the samba server details
*    	flags	==>   flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
Description:
	This function configures the SAMBA Server paramters. It configures the samba server based on the
	values in the LTQ_MAPI_SAMBA_Server structure and the operation which can be MODIFY only
	of a samba server.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_samba_server(uint32 oper, LTQ_MAPI_SAMBA_Server *smbSrvr, uint32 flags)
{
	int32	count = 0;
#ifdef TR69_DEFINED
	int32	changed_fcount = 0;
#endif /* TR69_DEFINED */
	char8	sCommand[MAX_FILELINE_LEN];
	char8   buf[MAX_DATA_LEN];
	IFX_NAME_VALUE_PAIR array_fvp[12];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;
	int32	ret = IFX_SUCCESS;

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(buf, 0x00, sizeof(buf));

	memset(array_fvp, 0x00, sizeof(array_fvp));

	/*************** Prolog Block ****************/
	/* Based on operation (ADD or DEL or MOD)
	 * append the flag with internal flags. For other ops,
	 * the flag denotes the action */
#if 0 // FIXME: not needed as there is no ADD/DEL operation
	if (oper == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if ((oper == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
		flags |= IFX_F_INT_ADD;
	else
		flags |= IFX_F_MODIFY;
#else // 0
	flags |= IFX_F_MODIFY;
#endif // !0


	/************* Validation Block **************/
	if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(smbSrvr)
		/* Do simple validation of flags sucha as less than 0 */
		IFX_VALIDATE_FLAGS(flags)
	}


	smbSrvr->iid.cpeId.Id = 1;
	sprintf(smbSrvr->iid.cpeId.secName, "%s", TAG_SAMBA_SERVER);
	smbSrvr->iid.pcpeId.Id = 1;
	sprintf(smbSrvr->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE); /* FIXME: ??? anath */

	/*********** Name Value Formation As Per RC.CONF ****************/
	/* Build the API Specific name value pair */

	ifx_fill_ArrayFvp_FName(array_fvp, 0, 6, smb_param_names);

	ifx_fill_ArrayFvp_intValues(array_fvp, 0, 2, (int32 *)&smbSrvr->iid.cpeId.Id, &smbSrvr->iid.pcpeId.Id);

	ifx_fill_ArrayFvp_boolValues(array_fvp, 2, 1, (uchar8 *)&smbSrvr->smbEna);

	ifx_fill_ArrayFvp_strValues(array_fvp, 3, 3, smbSrvr->smbName, smbSrvr->smbDescr, smbSrvr->wrkgrpName);

	count = 6;


#if 0 // FIXME: need to understand
	/**************** ACL Checking Block *****************/
	/* pass all this field for acl checking */
	CHECK_ACL_RET(smbSrvr->iid, count, array_fvp,
		changed_fcount, array_changed_fvp, flags, IFX_Handler)
#endif


	/********* System Config File Update Block  **********/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(buf, count, array_fvp);

	ret = ifx_SetObjData(FILE_RC_CONF, TAG_SAMBA_SERVER, flags, 1, buf);

	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}


	/************ Device Configuration Block ***********/
	/* Multiple System Configuration Calls */
	/* Back up rc.conf to second temporary file before proceeding with configuration */
	if(IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		/* Call samba_server_start which will configure smb.conf based on new configuration */
		if (smbSrvr->smbEna) {
			system("/etc/init.d/samba stop");
			system("/etc/init.d/samba start"); // FIXME: if it is stopped; otherwise restart
		}
		else {
			system("/etc/init.d/samba stop");
		}

		/* Rollback by stopping service with CHKPOINT_FILE2 and starting service with CHKPOINT_FILE */
		if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

	} // IFX_DONT_ACTIVATE_F_NOT_SET


	/**************** Notification Block ******************/
	/* Notify the Internal TR69 Stack in case of MODIFY */
	if(IFX_ADD_F_NOT_SET(flags) && IFX_DELETE_F_NOT_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION (smbSrvr->iid, changed_fcount, array_changed_fvp, flags, IFX_Handler)
	}


#if 0 // FIXME: not needed as there is no ADD/DELETE
	/***************** Epilog Block **********************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	/* Currently never addressed as there is no ADD/DELETE */
	if (IFX_MODIFY_F_NOT_SET(flags)) {
		UPDATE_ID_MAP_N_ATTRIBUTES(&smbSrvr->iid, count, array_fvp, flags, IFX_Handler)
	}
#endif // 0

	ret = ifx_config_write(FILE_RC_CONF, flags);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}


IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_samba_server(...)
*	smbSrvr		==>  output pointer to LTQ_MAPI_SAMBA_Server which will store the samba server configuration
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
Description:
	This function reads the samba server configuration from the rc.conf file
	and returns it as in the pointer smbSrvr.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_samba_server(LTQ_MAPI_SAMBA_Server *smbSrvr, uint32 flags)
{
	char8	sValue[MAX_FILELINE_LEN];
	uint32	inflag = flags, outflag = IFX_F_DEFAULT;
	int	ret = IFX_SUCCESS;

	/* The CPEID values for SAMBA Server are pre-determined */
	/* get the cpeid for the samba server */
	if (ifx_GetObjData(FILE_RC_CONF, TAG_SAMBA_SERVER, 
							"smb_cpeId", inflag, &outflag, sValue) != IFX_SUCCESS)	{
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	else {
		smbSrvr -> iid.cpeId.Id = atoi(sValue);
		strcpy(smbSrvr -> iid.cpeId.secName, TAG_SAMBA_SERVER);
	}

	/* get the parent cpeid for the samba server */
	if (ifx_GetObjData(FILE_RC_CONF, TAG_SAMBA_SERVER, 
							"smb_pcpeId", inflag, &outflag, sValue) != IFX_SUCCESS)	{
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	else {
		smbSrvr -> iid.pcpeId.Id = atoi(sValue);
		strcpy(smbSrvr -> iid.pcpeId.secName, TAG_LAN_DEVICE);
	}

	/* get the status of the samba server */
	if (ifx_GetObjData(FILE_RC_CONF, TAG_SAMBA_SERVER, 
				"smb_ena", inflag, &outflag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;

	}
	else {
		if (!strcmp(sValue, "1"))
			smbSrvr -> smbEna = 1;
		else
			smbSrvr -> smbEna = 0;
	}

	/* get the name of the samba server */
	if (ifx_GetObjData(FILE_RC_CONF, TAG_SAMBA_SERVER, 
				"smb_name", inflag, &outflag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;

	}
	else {
		if (strlen(sValue) > 0)
			snprintf(smbSrvr -> smbName,MAX_NAME_LEN,"%s", sValue);
		else
			snprintf(smbSrvr -> smbName,MAX_NAME_LEN,"%s", "\0");
	}

	/* get the description of the samba server */
	memset(sValue,'\0',sizeof(sValue));
	if (ifx_GetObjData(FILE_RC_CONF, TAG_SAMBA_SERVER, 
				"smb_descr", inflag, &outflag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;

	}
	else {
		if (strlen(sValue) > 0)
			snprintf(smbSrvr -> smbDescr,MAX_NAME_LEN,"%s", sValue);
		else
			snprintf(smbSrvr -> smbDescr,MAX_NAME_LEN,"%s", "\0");
	}

	/* get the workgroup of the samba server */
	if (ifx_GetObjData(FILE_RC_CONF, TAG_SAMBA_SERVER, 
				"smb_workgroup", inflag, &outflag, sValue) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;

	}
	else {
		if (strlen(sValue) > 0)
			snprintf(smbSrvr -> wrkgrpName,MAX_NAME_LEN,"%s", sValue);
		else
			snprintf(smbSrvr -> wrkgrpName,MAX_NAME_LEN,"%s", "\0");
	}

IFX_Handler:
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
 * ifx_duplicate_share(....)
 *	cpeId	==>	Input cpeid of the share
 *    	share	==>	pointer to LTQ_MAPI_File_Share structure that has the share details
 *	Return Value : IFX_SUCCESS or IFX_FAILURE
Description :
	This function takes the input pointer to LTQ_MAPI_File_Share structure and checks
	if there is any other share with same share name and user name then it returns
	IFX_SUCCESS otherwise IFX_FAILURE
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_duplicate_share(CPE_ID cpeId, LTQ_MAPI_File_Share *share)
{
	int32	ret = IFX_SUCCESS, i = 0;
	uint32	num_entries = 0;
	LTQ_MAPI_File_Share	*share_array = NULL;

#if 0
	ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, cpeId.secName, "vcc", sValue, &vc_retStr);
	if(ret != IFX_SUCCESS)
		ret = IFX_SUCCESS;
	else {
		sprintf(command, "%s_vcc", vc_retStr);
		ifx_GetObjData(FILE_RC_CONF, cpeId.secName, command, IFX_F_GET_ENA, &outFlag, sValue);
		if(outFlag == IFX_F_GET_ENA) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] for vc[%d/%d] in [%s]", __FUNCTION__, __LINE__, vc.vpi, vc.vpi, cpeId.secName);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}
#endif

	if(ifx_get_all_file_share_entries(&num_entries, &share_array, IFX_F_GET_ANY) != IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	for(i=0;i<num_entries;i++)
	{
		/* Check :- If input vc matches with vc channel entry(if the vc channel is enabled)
			and if input cpeid doesnt match with vc channel entry cpeid, then return error.
			caller is trying to modify vc which will clash with already existing vc channel */
		if(!strcmp((share_array+i)->shareName, share->shareName))
		{
			if((share_array+i)->iid.cpeId.Id != cpeId.Id)
			{
				if(strcmp((share_array+i)->folderPath, share->folderPath))
				{
					#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] share name with different folder path found !!%s %s %d",
						__FUNCTION__, __LINE__, (share_array+i)->shareName, share->folderPath, (share_array+i)->iid.cpeId.Id);
					#endif
					ret = IFX_DUPLICATE_ENTRY;
					goto IFX_Handler;
				}
				else if(!strcmp((share_array+i)->users[0], share->users[0]))
				{
					#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d] share name with duplicate user found !!%s %s %d",
						__FUNCTION__, __LINE__, (share_array+i)->shareName, share->users[0], (share_array+i)->iid.cpeId.Id);
					#endif
					ret = IFX_DUPLICATE_ENTRY;
					goto IFX_Handler;
				}
			}
		}
	}
	ret = IFX_SUCCESS;

IFX_Handler:
//	IFX_MEM_FREE(vc_retStr)
	IFX_MEM_FREE(share_array)
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
 * ifx_duplicate_user(....)
 *	cpeId	==>	Input cpeid of the user
 * 	user	==>	Input user name
 *	Return Value : IFX_SUCCESS or IFX_FAILURE
Description :
	This function takes the input user name and checks if there is any other
	user with same user name then it returns IFX_SUCCESS otherwise IFX_FAILURE
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_duplicate_user(CPE_ID cpeId, char8 *user)
{
	int32	ret = IFX_SUCCESS, i = 0;
	uint32	num_entries = 0;
	LTQ_MAPI_File_User	*user_array = NULL;

#if 0
	ret = ifx_ret_substr_from_distfield(FILE_RC_CONF, cpeId.secName, "vcc", sValue, &vc_retStr);
	if(ret != IFX_SUCCESS)
		ret = IFX_SUCCESS;
	else {
		sprintf(command, "%s_vcc", vc_retStr);
		ifx_GetObjData(FILE_RC_CONF, cpeId.secName, command, IFX_F_GET_ENA, &outFlag, sValue);
		if(outFlag == IFX_F_GET_ENA) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] for vc[%d/%d] in [%s]", __FUNCTION__, __LINE__, vc.vpi, vc.vpi, cpeId.secName);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}
#endif

	if(ifx_get_all_fs_usr_act_entries(&num_entries, &user_array, IFX_F_GET_ANY) != IFX_SUCCESS) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	for(i=0;i<num_entries;i++)
	{
		/* Check :- If input vc matches with vc channel entry(if the vc channel is enabled)
			and if input cpeid doesnt match with vc channel entry cpeid, then return error.
			caller is trying to modify vc which will clash with already existing vc channel */
		if(!strcmp((user_array+i)->userName, user))
		{
			if((user_array+i)->iid.cpeId.Id != cpeId.Id)
			{
				#ifdef IFX_LOG_DEBUG
				IFX_DBG("[%s:%d] duplicate user found !!%s %s %d",
					__FUNCTION__, __LINE__, (user_array+i)->userName, user, (user_array+i)->iid.cpeId.Id);
				#endif
				ret = IFX_DUPLICATE_ENTRY;
				goto IFX_Handler;
			}
		}
	}
	ret = IFX_SUCCESS;

IFX_Handler:
//	IFX_MEM_FREE(vc_retStr)
	IFX_MEM_FREE(user_array)
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_file_share(...)
*	oper	==>   the operation to be performed for this share entry, can be ADD, DELETE or MODIFY
*    	fileShare	==>   pointer to LTQ_MAPI_File_Share structure that has the share details
*    	flags	==>   flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
Description:
	This function configures the File Share paramters. It configures the file share based on the
	values in the LTQ_MAPI_File_Share structure and the operation which can be either ADD, DELETE or MODIFY
	of a file share.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_file_share(uint32 oper, LTQ_MAPI_File_Share *fileShare, uint32 flags)
{
	int32	count = 0;
#ifdef TR69_DEFINED
	int32	changed_fcount = 0;
#endif /* TR69_DEFINED */
	char8	sCommand[MAX_FILELINE_LEN];
	char8   buf[MAX_DATA_LEN], sValue[10];
	//char8   buf[MAX_DATA_LEN], old_order[20], sValue[10];
	IFX_NAME_VALUE_PAIR array_fvp[12];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;
	int32	ret = IFX_SUCCESS;
	int32	passed_index = -1;
	uint32	outflag = IFX_F_DEFAULT;

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(buf, 0x00, sizeof(buf));

	memset(array_fvp, 0x00, sizeof(array_fvp));

	/*************** Prolog Block ****************/
	/* Based on operation (ADD or DEL or MOD)
	 * append the flag with internal flags. For other ops,
	 * the flag denotes the action */
	if (oper == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if ((oper == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
		flags |= IFX_F_INT_ADD;
	else
		flags |= IFX_F_MODIFY;


	/************* Validation Block **************/
	if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(fileShare)
		/* Do simple validation of flags sucha as less than 0 */
		IFX_VALIDATE_FLAGS(flags)
		/* Do validation of duplicate share */
		IFX_VALIDATE_SHARE_INFO(fileShare, flags)
	}


	//fileShare->iid.cpeId.Id = 1;
	sprintf(fileShare->iid.cpeId.secName, "%s", TAG_FILE_SHARE);
	fileShare->iid.pcpeId.Id = 1; /* TODO */
	sprintf(fileShare->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE); /* FIXME: ??? anath */

	/* currently we allow only 16 shares to be configured */
	MAKE_SECTION_COUNT_TAG(TAG_FILE_SHARE, buf);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_FILE_SHARE,
			buf, flags, &outflag, sValue)) != IFX_SUCCESS){
		goto IFX_Handler;
	}
	if((atoi(sValue) == MAX_SHARES) && IFX_INT_ADD_F_SET(flags)) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/**************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
		/* Allocate the IID for this file share */
		fileShare->iid.cpeId.Id=0;
		if(ifx_get_IID(&fileShare->iid, "name") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	/*********** Name Value Formation As Per RC.CONF ****************/
	/* Build the API Specific name value pair */

	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		ifx_fill_ArrayFvp_FName(array_fvp, 0, IFX_FILE_SHARE_PARAM_COUNT, fs_param_names);

		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 2, (int32 *)&fileShare->iid.cpeId.Id, &fileShare->iid.pcpeId.Id);

		ifx_fill_ArrayFvp_strValues(array_fvp, 2, 2, fileShare->shareName, fileShare->folderPath);

		ifx_fill_ArrayFvp_boolValues(array_fvp, 4, 1, (uchar8*)&fileShare->rwAccess);

		ifx_fill_ArrayFvp_strValues(array_fvp, 5, 1, fileShare->users[0]);

		passed_index = -1;
	}

	count = IFX_FILE_SHARE_PARAM_COUNT;

	/* Get Config Index in case of modify/delete operations from CPEID */
	if((IFX_MODIFY_F_SET(flags)) ||	(IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, fileShare->iid.cpeId, passed_index)
	}

	/* Determine the configuration index - for Add, Delete, Modify operations 
	 * Name is partial since index is not known 
	 * Fill array_fvp[] */
	if(ifx_get_conf_index_and_nv_pairs(&fileShare->iid, passed_index, PREFIX_FILE_SHARE, 
				count, array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

#if 0 // FIXME: not working
	/**************** ACL Checking Block *****************/
	/* pass all this field for acl checking */
	if (IFX_ADD_F_NOT_SET(flags)) {
		CHECK_ACL_RET(fileShare->iid, count, array_fvp,
			changed_fcount, array_changed_fvp, flags, IFX_Handler)
	}
#endif


	/********* System Config File Update Block  **********/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(buf, count, array_fvp);

	ret = ifx_SetObjData(FILE_RC_CONF, TAG_FILE_SHARE, flags, 1, buf);

	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

#if 0
	if(IFX_DELETE_F_SET(flags)) {
		if(ifx_modify_n_reorder_fvp(TAG_FILE_SHARE, PREFIX_FILE_SHARE, "poolOrder", old_order, NULL, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
	}
#endif //0

	/* this will Compact the section and also update the count for both ADD and DELETE */
	if(IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_FILE_SHARE, flags);

	/************ Device Configuration Block ***********/
	/* Multiple System Configuration Calls */
	/* Back up rc.conf to second temporary file before proceeding with configuration */
	if(IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
		/* Call samba_server_start which will configure smb.conf based on new configuration */
		system("/etc/init.d/samba stop");
		system("/etc/init.d/samba start"); // FIXME: if it is stopped; otherwise restart

		/* Rollback by stopping service with CHKPOINT_FILE2 and starting service with CHKPOINT_FILE */
		if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

		/* FIXME: Call ftp server based on new configuration */

	} // IFX_DONT_ACTIVATE_F_NOT_SET


	/**************** Notification Block ******************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

	/*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if(IFX_MODIFY_F_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION (fileShare->iid, changed_fcount, array_changed_fvp, flags, IFX_Handler)
	}
	else if (IFX_INT_ADD_F_SET(flags)) {
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */
		/*********** Epilog Block **************/
		UPDATE_ID_MAP_N_ATTRIBUTES(&fileShare->iid, count, array_fvp, flags, IFX_Handler)

		//CHECK_N_SEND_NOTIFICATION (fileShare->iid, count, array_fvp, flags, IFX_Handler) // FIXME: not working

		/* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_FILE_SHARE);
	}
	else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		 * and then send the Notification for the attributes
		 */
		/*********** Epilog Block **************/
		//CHECK_N_SEND_NOTIFICATION(fileShare->iid, count, array_fvp, flags, IFX_Handler) // FIXME: not working

		//UPDATE_ID_MAP_N_ATTRIBUTES(&fileShare->iid, count, array_fvp, flags, IFX_Handler) // FIXME
	}


	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}


IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_file_share(...)
*	fileShare	==>  output pointer to LTQ_MAPI_File_Share which will store the file share configuration
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
Description:
	This function reads the file share configuration from the rc.conf file
	and returns it as in the pointer fileShare.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_file_share(LTQ_MAPI_File_Share *fileShare, uint32 flags)
{
	char8	sBuf[MAX_FILELINE_LEN], *sValue=NULL;
	int32  passed_index = -1, count = 0;
	// uint32 outflag = IFX_F_DEFAULT;
	int		ret = IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR array_fvp[IFX_FILE_SHARE_PARAM_COUNT + 1];

	/* Fill the section tag */
	sprintf(fileShare->iid.cpeId.secName, "%s", TAG_FILE_SHARE);

	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	/* get index from cpeid */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, fileShare->iid.cpeId, passed_index)
	sprintf(sBuf, "%s_%d_", PREFIX_FILE_SHARE, passed_index);
	if((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_FILE_SHARE,
			sBuf, flags, &sValue)) != IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	memset(array_fvp, 0x00, sizeof(array_fvp));

	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);


	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	/* copy the fileShare entries into the structure */
	ifx_fill_intValues_ArrayFvp(array_fvp, 0, 2,
                                            (int32 *)&fileShare->iid.cpeId.Id,
                                            &fileShare->iid.pcpeId.Id);

	ifx_fill_strValues_ArrayFvp(array_fvp, 2, 2,
                                            fileShare->shareName,
                                            fileShare->folderPath);

	ifx_fill_boolValues_ArrayFvp(array_fvp, 4, 1, (uchar8 *)&fileShare->rwAccess);


	ifx_fill_strValues_ArrayFvp(array_fvp, 5, 1, fileShare->users[0]);

	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);

IFX_Handler:
	IFX_MEM_FREE(sValue);
	if(ret != IFX_SUCCESS){
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_all_file_share_entries(...)
*	numFS	==>  ouput pointer to number of shares exists
*	fsEntries	==>  output pointer to LTQ_MAPI_File_Share which will store the share configuration
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
Description:
	This function reads the share configuration from the rc.conf file
	and returns it as in the pointer fsEntries.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_all_file_share_entries(uint32 *numFS, LTQ_MAPI_File_Share **fsEntries, uint32 flags)
{
	int32 nCount = 0, nIndex = 0;
	int32 ret = IFX_SUCCESS, share_count = 0;
	char8	sCommand[MAX_FILELINE_LEN], sBuf[MAX_FILELINE_LEN];
	uint32	outFlag = IFX_F_DEFAULT;

	LTQ_MAPI_File_Share *t_ptr = NULL;

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

	/* first, get the number of file share entries from rc.conf */
	MAKE_SECTION_COUNT_TAG(TAG_FILE_SHARE, sCommand);

	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_FILE_SHARE,
		sCommand, flags, &outFlag, sBuf)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	nCount = atoi(sBuf);
	if (nCount < 1 || nCount > 32767) {
		*numFS = 0;
		*fsEntries = NULL;
		goto IFX_Handler;
	}
	*fsEntries = NULL;
	t_ptr = (LTQ_MAPI_File_Share *)IFX_MALLOC(nCount * sizeof(LTQ_MAPI_File_Share));
	if(t_ptr == NULL) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	*fsEntries = t_ptr;

	for (nIndex=0; nIndex < nCount; nIndex++) {

		NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
		sprintf(sCommand, "%s_%d_cpeId", PREFIX_FILE_SHARE, nIndex);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_FILE_SHARE,
				sCommand, flags, &outFlag, sBuf)) != IFX_SUCCESS){
			goto IFX_Handler;
		}

		(*fsEntries + share_count)->iid.cpeId.Id = atoi(sBuf);

		if((ret = ifx_get_file_share((*fsEntries + share_count), flags) !=
				IFX_SUCCESS)) {
			goto IFX_Handler;
		}

		share_count++;
	}

	*numFS = share_count;

IFX_Handler:
	if(ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*fsEntries)
		*numFS = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_set_fs_usr_act(...)
*	oper	==>   the operation to be performed for this user entry, can be ADD, DELETE or MODIFY
*    	fileUser	==>   pointer to LTQ_MAPI_File_User structure that has the user details
*    	flags	==>   flags that define the behaviour
*
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
Description:
	This function configures the File User paramters. It configures the file user based on the
	values in the LTQ_MAPI_File_User structure and the operation which can be either ADD, DELETE or MODIFY
	of a file user.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_set_fs_usr_act(uint32 oper, LTQ_MAPI_File_User *fileUser, uint32 flags)
{
	int32	count = 0;
#ifdef TR69_DEFINED
	int32	changed_fcount = 0;
#endif /* TR69_DEFINED */
	char8	sCommand[MAX_FILELINE_LEN];
	char8   buf[MAX_DATA_LEN], sValue[10];
	//char8   buf[MAX_DATA_LEN], old_order[20], sValue[10];
	IFX_NAME_VALUE_PAIR array_fvp[12];
	IFX_NAME_VALUE_PAIR *array_changed_fvp = NULL;
	int32	ret = IFX_SUCCESS;
	int32	passed_index = -1;
	uint32	outflag = IFX_F_DEFAULT;
	char passwd_buffer[MAX_NAME_LEN];
	char enc_passwd[MAX_NAME_LEN];

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(buf, 0x00, sizeof(buf));
	NULL_TERMINATE(passwd_buffer, 0x00, sizeof(passwd_buffer));
	NULL_TERMINATE(enc_passwd, 0x00, sizeof(enc_passwd));

	memset(array_fvp, 0x00, sizeof(array_fvp));

	/*************** Prolog Block ****************/
	/* Based on operation (ADD or DEL or MOD)
	 * append the flag with internal flags. For other ops,
	 * the flag denotes the action */
	if (oper == IFX_OP_DEL)
		flags |= IFX_F_DELETE;
	else if ((oper == IFX_OP_ADD) && (IFX_MODIFY_F_NOT_SET(flags)))
		flags |= IFX_F_INT_ADD;
	else
		flags |= IFX_F_MODIFY;


	/************* Validation Block **************/
	if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
		/* Do simple validation of pointer such as NULL */
		IFX_VALIDATE_PTR(fileUser)
		/* Do simple validation of flags sucha as less than 0 */
		IFX_VALIDATE_FLAGS(flags)
		/* Do validation of duplicate user */
		IFX_VALIDATE_USER_INFO(fileUser, flags)
	}


	//fileUser->iid.cpeId.Id = 1;
	sprintf(fileUser->iid.cpeId.secName, "%s", TAG_FILE_USER);
	fileUser->iid.pcpeId.Id = 1; /* TODO */
	sprintf(fileUser->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE); /* FIXME: ??? anath */

	/* currently we allow only 16 shares to be configured */
	MAKE_SECTION_COUNT_TAG(TAG_FILE_USER, buf);
	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_FILE_USER,
			buf, flags, &outflag, sValue)) != IFX_SUCCESS){
		goto IFX_Handler;
	}
	if((atoi(sValue) == MAX_SHARES) && IFX_INT_ADD_F_SET(flags)) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

	/**************** ID Allocation Block - Only for ADD Operation **************/
	if (IFX_ADD_F_SET(flags)) {
		/* Allocate the IID for this file share */
		fileUser->iid.cpeId.Id=0;
		if(ifx_get_IID(&fileUser->iid, "name") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
	}

	/*********** Name Value Formation As Per RC.CONF ****************/
	/* Build the API Specific name value pair */

	count = 0;
	if (IFX_DELETE_F_NOT_SET(flags)) {
		{
		int i = 0;
		char *iv = "abcdefgh";
		char *key = "abcdefghabcdefgh";
		int encrypted_len = strlen(fileUser->pwd);
		strcpy(enc_passwd, fileUser->pwd);
		encrypted_len = (encrypted_len & 0x07) > 0 ? ((encrypted_len >> 3) + 1) << 3 : encrypted_len;
		/* Encrypt user password */
		if (CAST5(1, (unsigned char*)enc_passwd, encrypted_len, NULL, 0, iv, key, 16)) {
			ret = IFX_FAILURE;
			goto IFX_Handler;
		}
		for (i = 0; i < encrypted_len; i++) {
			sprintf(passwd_buffer + i * 2, "%02X", (unsigned char)enc_passwd[i]); 
		}
		}

		ifx_fill_ArrayFvp_FName(array_fvp, 0, IFX_FILE_USER_PARAM_COUNT, fu_param_names);

		ifx_fill_ArrayFvp_intValues(array_fvp, 0, 2, (int32 *)&fileUser->iid.cpeId.Id, &fileUser->iid.pcpeId.Id);

//		ifx_fill_ArrayFvp_boolValues(array_fvp, 2, 1, (uchar8*)&fileUser->userEna);

		ifx_fill_ArrayFvp_strValues(array_fvp, 2, 3, fileUser->userName, passwd_buffer, fileUser->shares[0]);
//		ifx_fill_ArrayFvp_strValues(array_fvp, 2, 3, fileUser->userName, fileUser->pwd, fileUser->shares[0]);

		ifx_fill_ArrayFvp_boolValues(array_fvp, 5, 1, (uchar8*)&fileUser->rwAccess);

		passed_index = -1;
	}

	count = IFX_FILE_USER_PARAM_COUNT;

	/* Get Config Index in case of modify/delete operations from CPEID */
	if((IFX_MODIFY_F_SET(flags)) ||	(IFX_DELETE_F_SET(flags))) {
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, fileUser->iid.cpeId, passed_index)
	}

	/* Determine the configuration index - for Add, Delete, Modify operations 
	 * Name is partial since index is not known 
	 * Fill array_fvp[] */
	if(ifx_get_conf_index_and_nv_pairs(&fileUser->iid, passed_index, PREFIX_FILE_USER, 
				count, array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}

#if 0 // FIXME: not working
	/**************** ACL Checking Block *****************/
	/* pass all this field for acl checking */
	if (IFX_ADD_F_NOT_SET(flags)) {
		CHECK_ACL_RET(fileUser->iid, count, array_fvp,
			changed_fcount, array_changed_fvp, flags, IFX_Handler)
	}
#endif


	/********* System Config File Update Block  **********/
	/* Convert the name value pair in array_fvp into string format expected by rc.conf file */
	form_cfgdb_buf(buf, count, array_fvp);

	ret = ifx_SetObjData(FILE_RC_CONF, TAG_FILE_USER, flags, 1, buf);

	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}

#if 0
	if(IFX_DELETE_F_SET(flags)) {
		if(ifx_modify_n_reorder_fvp(TAG_FILE_USER, PREFIX_FILE_USER, "poolOrder", old_order, NULL, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}
	}
#endif //0

	/* this will Compact the section and also update the count for both ADD and DELETE */
	if(IFX_MODIFY_F_NOT_SET(flags))
		ifx_CompactCfgSection(FILE_RC_CONF, TAG_FILE_USER, flags);

	/************ Device Configuration Block ***********/
	/* Multiple System Configuration Calls */
	/* Back up rc.conf to second temporary file before proceeding with configuration */
	if(IFX_DONT_ACTIVATE_F_NOT_SET(flags)) {
#if 0
		/* Call samba_server_start which will configure smb.conf based on new user */
		system("/etc/init.d/samba stop");
		system("/etc/init.d/samba start");
#else
		/* Call adduser/deluser which will configure users */
		if(IFX_ADD_F_SET(flags)) {
			sprintf(sCommand, "/usr/sbin/update_user.sh add %s %s %d", fileUser->userName, fileUser->pwd, fileUser->iid.cpeId.Id + 200);
			ret = system(sCommand);
		}
		if(IFX_MODIFY_F_SET(flags)) {
#if 0
			sprintf(sCommand, "/usr/sbin/update_user.sh del %s", fileUser->userName);
			system(sCommand);
			sprintf(sCommand, "/usr/sbin/update_user.sh add %s %s", fileUser->userName, fileUser->pwd, fileUser->iid.cpeId.Id);
#else
			sprintf(sCommand, "/usr/sbin/update_user.sh mod %s %s", fileUser->userName, fileUser->pwd);
#endif
			ret = system(sCommand);
		}
		else if(IFX_DELETE_F_SET(flags)) {
			sprintf(sCommand, "/usr/sbin/update_user.sh del %s", fileUser->userName);
			ret = system(sCommand);
		}
#endif

		/* Rollback by stopping service with CHKPOINT_FILE2 and starting service with CHKPOINT_FILE */
		if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
			goto IFX_Handler;
		}

	} // IFX_DONT_ACTIVATE_F_NOT_SET


	/**************** Notification Block ******************/
	/* Notify the Internal TR69 Stack in case of MODIFY */

	/*********** Epilog Block **************/
	/* Update the IID mappings in the mappings section for ADD/DELETE */
	if(IFX_MODIFY_F_SET(flags)) {
		CHECK_N_SEND_NOTIFICATION (fileUser->iid, changed_fcount, array_changed_fvp, flags, IFX_Handler)
	}
	else if (IFX_INT_ADD_F_SET(flags)) {
		/* In case of ADD operation, first update the ID Mappings
		 * and then send the Notification for the attributes
		 */
		/*********** Epilog Block **************/
		UPDATE_ID_MAP_N_ATTRIBUTES(&fileUser->iid, count, array_fvp, flags, IFX_Handler)

		//CHECK_N_SEND_NOTIFICATION (fileUser->iid, count, array_fvp, flags, IFX_Handler) // FIXME: not working

		/* Manipulate nextCpeId only for ADD operations */
		ifx_increment_next_cpeId(FILE_RC_CONF, TAG_FILE_USER);
	}
	else if (IFX_DELETE_F_SET(flags)) {
		/* In case of DELETE operation, first send the notificatioupdate the ID Mappings
		 * and then send the Notification for the attributes
		 */
		/*********** Epilog Block **************/
		//CHECK_N_SEND_NOTIFICATION(fileUser->iid, count, array_fvp, flags, IFX_Handler) // FIXME: not working

		//UPDATE_ID_MAP_N_ATTRIBUTES(&fileUser->iid, count, array_fvp, flags, IFX_Handler) // FIXME
	}


	/* Updating Persistent Storage */
	ret = ifx_config_write(FILE_RC_CONF, flags);
	if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		goto IFX_Handler;
	}


IFX_Handler:
	IFX_MEM_FREE(array_changed_fvp)
	if(ret != IFX_SUCCESS) {
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_fs_usr_act(...)
*	fileUser	==>  output pointer to LTQ_MAPI_File_User which will store the file user configuration
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
Description:
	This function reads the file user configuration from the rc.conf file
	and returns it as in the pointer fileUser.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_fs_usr_act(LTQ_MAPI_File_User *fileUser, uint32 flags)
{
	char8	sBuf[MAX_FILELINE_LEN], *sValue=NULL;
	int32  passed_index = -1, count = 0;
	// uint32 outflag = IFX_F_DEFAULT;
	int		ret = IFX_SUCCESS;
	IFX_NAME_VALUE_PAIR array_fvp[IFX_FILE_USER_PARAM_COUNT + 1];

	/* Fill the section tag */
	sprintf(fileUser->iid.cpeId.secName, "%s", TAG_FILE_USER);

	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	/* get index from cpeid */
	IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, fileUser->iid.cpeId, passed_index)
	sprintf(sBuf, "%s_%d_", PREFIX_FILE_USER, passed_index);
	if((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_FILE_USER,
			sBuf, flags, &sValue)) != IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	memset(array_fvp, 0x00, sizeof(array_fvp));

	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);


	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
	/* copy the fileUser entries into the structure */
	ifx_fill_intValues_ArrayFvp(array_fvp, 0, 2,
                                            (int32 *)&fileUser->iid.cpeId.Id,
                                            &fileUser->iid.pcpeId.Id);

//	ifx_fill_boolValues_ArrayFvp(array_fvp, 2, 1, (uchar8 *)&fileUser->userEna);

	ifx_fill_strValues_ArrayFvp(array_fvp, 2, 3,
                                            fileUser->userName,
                                            fileUser->pwd,
                                            fileUser->shares[0]);

	ifx_fill_boolValues_ArrayFvp(array_fvp, 5, 1, (uchar8 *)&fileUser->rwAccess);

	{
	char *iv = "abcdefgh";
	char *key = "abcdefghabcdefgh";
	int encrypted_len = strlen(fileUser->pwd);

	ifx_convert_hex_to_ascii(fileUser->pwd, fileUser->pwd);
	/* Decrypt user password */
	if (CAST5(0, (unsigned char*)fileUser->pwd, encrypted_len >> 1, NULL, 0, iv, key, 16)) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	}

	IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);

IFX_Handler:
	IFX_MEM_FREE(sValue);
	if(ret != IFX_SUCCESS){
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}

/*//////////////////////////////////////////////////////////////////////////////
* ifx_get_all_fs_usr_act_entries(...)
*	numFS	==>  output pointer to number of users exists
*	fsEntries	==>  output pointer to LTQ_MAPI_File_User which will store the user configuration
*	flags		==>
*    	Return Value :   IFX_SUCCESS or IFX_FAILURE
Description:
	This function reads the user configuration from the rc.conf file
	and returns it as in the pointer usrEntries.
*//////////////////////////////////////////////////////////////////////////////
int32 ifx_get_all_fs_usr_act_entries(uint32 *numFSUsr, LTQ_MAPI_File_User **usrEntries, uint32 flags)
{
	int32 nCount = 0, nIndex = 0;
	int32 ret = IFX_SUCCESS, user_count = 0;
	char8	sCommand[MAX_FILELINE_LEN], sBuf[MAX_FILELINE_LEN];
	uint32	outFlag = IFX_F_DEFAULT;

	LTQ_MAPI_File_User *t_ptr = NULL;

	NULL_TERMINATE(sCommand, 0x00, sizeof(sCommand));
	NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));

	/* first, get the number of file share entries from rc.conf */
	MAKE_SECTION_COUNT_TAG(TAG_FILE_USER, sCommand);

	if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_FILE_USER,
		sCommand, flags, &outFlag, sBuf)) != IFX_SUCCESS) {
		goto IFX_Handler;
	}
	nCount = atoi(sBuf);
	if (nCount < 1 || nCount > 32767) {
		*numFSUsr = 0;
		*usrEntries = NULL;
		goto IFX_Handler;
	}
	*usrEntries = NULL;
	t_ptr = (LTQ_MAPI_File_User *)IFX_MALLOC(nCount * sizeof(LTQ_MAPI_File_User));
	if(t_ptr == NULL) {
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
	*usrEntries = t_ptr;

	for (nIndex=0; nIndex < nCount; nIndex++) {

		NULL_TERMINATE(sBuf, 0x00, sizeof(sBuf));
		sprintf(sCommand, "%s_%d_cpeId", PREFIX_FILE_USER, nIndex);
		if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_FILE_USER,
				sCommand, flags, &outFlag, sBuf)) != IFX_SUCCESS){
			goto IFX_Handler;
		}

		(*usrEntries + user_count)->iid.cpeId.Id = atoi(sBuf);

		if((ret = ifx_get_fs_usr_act((*usrEntries + user_count), flags) !=
				IFX_SUCCESS)) {
			goto IFX_Handler;
		}

		user_count++;
	}

	*numFSUsr = user_count;

IFX_Handler:
	if(ret != IFX_SUCCESS) {
		IFX_MEM_FREE(*usrEntries)
		*numFSUsr = 0;
		IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
		return ret;
	}
	else
		return IFX_SUCCESS;
}
#endif /* CONFIG_PACKAGE_samba3 */

