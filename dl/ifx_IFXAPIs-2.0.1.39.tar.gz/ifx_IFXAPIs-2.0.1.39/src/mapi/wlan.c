/******************************************************************************

                               Copyright (c) 2008
                            Infineon Technologies AG
                     Am Campeon 1-12; 81726 Munich, Germany

  THE DELIVERY OF THIS SOFTWARE AS WELL AS THE HEREBY GRANTED NON-EXCLUSIVE,
  WORLDWIDE LICENSE TO USE, COPY, MODIFY, DISTRIBUTE AND SUBLICENSE THIS
  SOFTWARE IS FREE OF CHARGE.

  THE LICENSED SOFTWARE IS PROVIDED "AS IS" AND INFINEON EXPRESSLY DISCLAIMS
  ALL REPRESENTATIONS AND WARRANTIES, WHETHER EXPRESS OR IMPLIED, INCLUDING
  WITHOUT LIMITATION, WARRANTIES OR REPRESENTATIONS OF WORKMANSHIP,
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, DURABILITY, THAT THE
  OPERATING OF THE LICENSED SOFTWARE WILL BE ERROR FREE OR FREE OF ANY THIRD
  PARTY CLAIMS, INCLUDING WITHOUT LIMITATION CLAIMS OF THIRD PARTY INTELLECTUAL
  PROPERTY INFRINGEMENT.

  EXCEPT FOR ANY LIABILITY DUE TO WILFUL ACTS OR GROSS NEGLIGENCE AND EXCEPT
  FOR ANY PERSONAL INJURY INFINEON SHALL IN NO EVENT BE LIABLE FOR ANY CLAIM
  OR DAMAGES OF ANY KIND, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
  ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
  DEALINGS IN THE SOFTWARE.

******************************************************************************/

/**
   \file wlan.c
*/

#ifdef CONFIG_FEATURE_IFX_WIRELESS
/* ========================================================================== */
/*                                 Includes                                   */
/* ========================================================================== */
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <fcntl.h>
#include <syslog.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include "ifx_common.h"
#include "ifx_config.h"
#include "ifx_api_util.h"
#include "ifx_amazon_cfg.h"
#include <sys/time.h>

#if 0
#define IFX_MAPI_DEBUG(fd, file, text, args...)   \
do {  \
      FILE  *fd = NULL; \
      if((fd = fopen(file, "a")) == NULL) \
         system("echo \"debug file could not be opened in "file"!!\" >> /tmp/httpd_error");  \
      fprintf(fd, "[%s:%s:%d]: "text"\n\r", __FILE__, __FUNCTION__, __LINE__, ##args);   \
      fclose(fd); \
   } while (0)
#else
#define IFX_MAPI_DEBUG(fd, file, text, args...)
#endif /* #if 1 */

/* included for definition of bool */
#include "ifx_api_ipt_common.h"

#if defined IFX_CONFIG_TSC_WLAN && !(defined HOST_PLATFORM)
//#include "max_errHandling.h"
#include "max_mac_typedefs.h"
#include "max_mib_define.h"
#endif // IFX_CONFIG_TSC_WLAN

/* ========================================================================== */
/*                             Macro definitions                              */
/* ========================================================================== */
#define ISALNUM(ch) (isalnum(ch))
#define ISSPACE(ch) (isspace(ch))
#define ISASCII(ch) (isascii(ch))

#define ISALLOWED_SPECIAL(ch) (ch == '!' || ch == '_' || ch == '.' || \
                               ch == '-' || ch == '*' || ch == '?' || \
                               ch == '/' || ch == '(' || ch == ')' || \
                               ch == ';')

#define IFX_VALIDATE_SSID(wlan_main) { \
                           if((strlen(wlan_main->ssid) < 1) || (strlen(wlan_main->ssid) > 32)) { \
                              IFX_DBG("Please input valid ssid. Length of ssid should be between 1 and 32"); \
                              ret = IFX_FAILURE; \
                              goto IFX_Handler; \
                           } \
                           int32 i = 0, found = 0; \
                           for(i=0; i<strlen(wlan_main->ssid); i++) { \
                              /* check if any alphynumerical or allowed special character is present */ \
                              if(ISALNUM(wlan_main->ssid[i]) || ISALLOWED_SPECIAL(wlan_main->ssid[i])) { \
                                 found = 1; \
                                 break; \
                              } \
                           } \
                           /* check if any special character other than allowed list is present */ \
                           for (i=0; i<strlen(wlan_main->ssid); i++) \
                           { \
                              if(!(ISALNUM(wlan_main->ssid[i])) && \
                                 !(ISALLOWED_SPECIAL(wlan_main->ssid[i])) && \
                                 !(ISSPACE(wlan_main->ssid[i]))) \
                              { \
                                 found = 0; \
                                 goto flag_check; \
                              } \
                           } \
                           flag_check: \
                           if(!found) { \
                              IFX_DBG("Please input valid ssid. SSID cannot be blank"); \
                              ret = IFX_FAILURE; \
                              goto IFX_Handler; \
                           } \
                        }

#define WLAN_MAIN_PARAM_COUNT	            20
#if 0
#define WLAN_PHY_PARAM_COUNT	            35
#else
#define WLAN_PHY_PARAM_COUNT	            34
#endif
#define WLAN_SEC_PARAM_COUNT	            15
#define WLAN_WEP_CONFIG_PARAM_COUNT	      3
#define WLAN_PSK_PARAM_COUNT              5
#define WLAN_802_1X_PARAM_COUNT           14
#define WLAN_GLOBAL_MAC_CNTRL_PARAM_COUNT 5
#define WLAN_MAC_CNTRL_PARAM_COUNT        3
/* ========================================================================== */
/*                             Type definitions                               */
/* ========================================================================== */
/* lookup table for supported data rates based on standard */
struct basic_data_rate {
    int32 length;
    float rates[IFX_MAPI_WLAN_MAX_DATA_RATES_NUM];
};
struct basic_data_rate basic_data_rates_11a = {8, {6.0, 9.0, 12.0, 18.0, 24.0, 36.0, 48.0, 54.0}};
struct basic_data_rate basic_data_rates_11b = {4, {1.0, 2.0, 5.5, 11.0}};
struct basic_data_rate basic_data_rates_11bg = {12, {1.0, 2.0, 5.5, 6.0, 9.0, 11.0, 12.0, 18.0, 24.0, 36.0, 48.0, 54.0}};

/* ========================================================================== */
/*                             Global variables                               */
/* ========================================================================== */

char8 *wlan_main_params[] = {"cpeId", "pcpeId", "radioCpeId", "apEnable",
               "apName","apType", "ssid", "ssidMode", "bssidOverride",
               "bssid", "basicDataRate", "operDataRate", "maxBitRate", "vlanId",
               "apIsolationEna", "wmmEna", "uapsdEna", "wdsEna", "wpsEna","maxSta"};

#if 0
char8 *wlan_phy_params[] = {"cpeId", "pcpeId", "standard", "country", "usageEnv",
                            "freqBand","channelNo", "autoChanEna", "beaconTxEna",
                            "beaconInt", "dtimInt", "rts", "fts", "powerLvl",
                            "radioEnable", "autoRateFallbackEna", "staticRate",
                            "preamble", "nChanWidth", "nExtChanPos", "nGuardIntvl", "nMCS",
                            "nDivEna", "nDivDir", "nDivAntennaNum", "nSTBCrx", "nBAWsize",
                            "nAMPDUena", "nAMPDUdir", "nAMPDUlen", "nAMPDUfrms",
                             "nAMSDUena", "nAMSDUdir", "nAMSDUlen", "nGreenfieldEnable"};
#else
char8 *wlan_phy_params[] = {"cpeId", "pcpeId", "standard", "country", "usageEnv",
                            "freqBand","channelNo", "autoChanEna", "beaconTxEna",
                            "beaconInt", "dtimInt", "rts", "fts", "powerLvl",
                            "radioEnable", "autoRateFallbackEna", "staticRate",
                            "preamble", "nChanWidth", "nExtChanPos", "nGuardIntvl", "nMCS",
                            "nDivEna", "nDivDir", "nDivAntennaNum", "nSTBCrx", "nBAWsize",
                            "nAMPDUena", "nAMPDUdir", "nAMPDUlen", "nAMPDUfrms",
                             "nAMSDUena", "nAMSDUdir", "nAMSDUlen"};
#endif

char8 *wlan_sec_params[] = {"cpeId", "pcpeId", "beaconType", "authType",
               "encrType", "basicAuthType", "basicEncrType", "wpaAuthType",
               "wpaEncrType", "wpa2AuthType", "wpa2EncrType", "wepEncrLvl",
               "wepKeyType", "wepKeyIndx", "macAddrCntrlType"};

char8 *wlan_wep_config_params[] = {"cpeId", "pcpeId", "key"};

char8 *wlan_psk_params[] = {"cpeId", "pcpeId", "pskFlag", "passPhrase", "psk"};

char8 *wlan_802_1x_params[] = {"cpeId", "pcpeId", "grpKeyEna", "grpKeyIntvl",
                               "wpa2PreAuthEna", "reAuthIntvl", "localRadius",
                               "authType", "authProto", "radiusIP", "radiusPort",
                               "radiusSecret", "domainName", "userName"};

char8 *wlan_global_mac_cntrl_params[] = {"cpeId", "pcpeId", "ifType", "macAddr", "control"};
char8 *wlan_mac_cntrl_params[] = {"cpeId", "pcpeId", "macAddr"};

/** definition of used wlan channels in different regulatory domains */
static const IFX_MAPI_WLAN_RegDomain   regDomainWorld_11a   =
            {IFX_MAPI_WLAN_REGDOMAIN_WORLD_11A_LENGTH,
             {IFX_MAPI_WLAN_CHANNEL_36, IFX_MAPI_WLAN_CHANNEL_40, IFX_MAPI_WLAN_CHANNEL_44, IFX_MAPI_WLAN_CHANNEL_48,
              IFX_MAPI_WLAN_CHANNEL_52, IFX_MAPI_WLAN_CHANNEL_56, IFX_MAPI_WLAN_CHANNEL_60, IFX_MAPI_WLAN_CHANNEL_64,
              IFX_MAPI_WLAN_CHANNEL_100, IFX_MAPI_WLAN_CHANNEL_104, IFX_MAPI_WLAN_CHANNEL_108, IFX_MAPI_WLAN_CHANNEL_112,
              IFX_MAPI_WLAN_CHANNEL_116, IFX_MAPI_WLAN_CHANNEL_120, IFX_MAPI_WLAN_CHANNEL_124, IFX_MAPI_WLAN_CHANNEL_128,
              IFX_MAPI_WLAN_CHANNEL_132, IFX_MAPI_WLAN_CHANNEL_136, IFX_MAPI_WLAN_CHANNEL_140, IFX_MAPI_WLAN_CHANNEL_149,
              IFX_MAPI_WLAN_CHANNEL_153, IFX_MAPI_WLAN_CHANNEL_157, IFX_MAPI_WLAN_CHANNEL_161, IFX_MAPI_WLAN_CHANNEL_165}
            };
static const IFX_MAPI_WLAN_RegDomain   regDomainEurope_11a   =
            {IFX_MAPI_WLAN_REGDOMAIN_EUROPE_11A_LENGTH,
             {IFX_MAPI_WLAN_CHANNEL_36, IFX_MAPI_WLAN_CHANNEL_40, IFX_MAPI_WLAN_CHANNEL_44, IFX_MAPI_WLAN_CHANNEL_48,
              IFX_MAPI_WLAN_CHANNEL_52, IFX_MAPI_WLAN_CHANNEL_56, IFX_MAPI_WLAN_CHANNEL_60, IFX_MAPI_WLAN_CHANNEL_64,
              IFX_MAPI_WLAN_CHANNEL_100, IFX_MAPI_WLAN_CHANNEL_104, IFX_MAPI_WLAN_CHANNEL_108, IFX_MAPI_WLAN_CHANNEL_112,
              IFX_MAPI_WLAN_CHANNEL_116, IFX_MAPI_WLAN_CHANNEL_120, IFX_MAPI_WLAN_CHANNEL_124, IFX_MAPI_WLAN_CHANNEL_128,
              IFX_MAPI_WLAN_CHANNEL_132, IFX_MAPI_WLAN_CHANNEL_136, IFX_MAPI_WLAN_CHANNEL_140}
            };
static const IFX_MAPI_WLAN_RegDomain   regDomainJapan_11a   =
            {IFX_MAPI_WLAN_REGDOMAIN_JAPAN_11A_LENGTH,
             {IFX_MAPI_WLAN_CHANNEL_36, IFX_MAPI_WLAN_CHANNEL_40, IFX_MAPI_WLAN_CHANNEL_44, IFX_MAPI_WLAN_CHANNEL_48,
              IFX_MAPI_WLAN_CHANNEL_52, IFX_MAPI_WLAN_CHANNEL_56, IFX_MAPI_WLAN_CHANNEL_60, IFX_MAPI_WLAN_CHANNEL_64,
              IFX_MAPI_WLAN_CHANNEL_100, IFX_MAPI_WLAN_CHANNEL_104, IFX_MAPI_WLAN_CHANNEL_108, IFX_MAPI_WLAN_CHANNEL_112,
              IFX_MAPI_WLAN_CHANNEL_116, IFX_MAPI_WLAN_CHANNEL_120, IFX_MAPI_WLAN_CHANNEL_124, IFX_MAPI_WLAN_CHANNEL_128,
              IFX_MAPI_WLAN_CHANNEL_132, IFX_MAPI_WLAN_CHANNEL_136, IFX_MAPI_WLAN_CHANNEL_140, IFX_MAPI_WLAN_CHANNEL_184,
              IFX_MAPI_WLAN_CHANNEL_188, IFX_MAPI_WLAN_CHANNEL_192, IFX_MAPI_WLAN_CHANNEL_196}
            };
static const IFX_MAPI_WLAN_RegDomain   regDomainChina_11a   =
            {IFX_MAPI_WLAN_REGDOMAIN_CHINA_11A_LENGTH,
             {IFX_MAPI_WLAN_CHANNEL_149, IFX_MAPI_WLAN_CHANNEL_153, IFX_MAPI_WLAN_CHANNEL_157,
              IFX_MAPI_WLAN_CHANNEL_161, IFX_MAPI_WLAN_CHANNEL_165}
            };
static const IFX_MAPI_WLAN_RegDomain   regDomainWorld_11g   =
            {IFX_MAPI_WLAN_REGDOMAIN_WORLD_11G_LENGTH,
             {IFX_MAPI_WLAN_CHANNEL_1, IFX_MAPI_WLAN_CHANNEL_2, IFX_MAPI_WLAN_CHANNEL_3, IFX_MAPI_WLAN_CHANNEL_4,
              IFX_MAPI_WLAN_CHANNEL_5, IFX_MAPI_WLAN_CHANNEL_6, IFX_MAPI_WLAN_CHANNEL_7, IFX_MAPI_WLAN_CHANNEL_8,
              IFX_MAPI_WLAN_CHANNEL_9, IFX_MAPI_WLAN_CHANNEL_10, IFX_MAPI_WLAN_CHANNEL_11, IFX_MAPI_WLAN_CHANNEL_12,
              IFX_MAPI_WLAN_CHANNEL_13}
            };
static const IFX_MAPI_WLAN_RegDomain   regDomainUSA_11g   =
            {IFX_MAPI_WLAN_REGDOMAIN_USA_11G_LENGTH,
             {IFX_MAPI_WLAN_CHANNEL_1, IFX_MAPI_WLAN_CHANNEL_2, IFX_MAPI_WLAN_CHANNEL_3, IFX_MAPI_WLAN_CHANNEL_4,
              IFX_MAPI_WLAN_CHANNEL_5, IFX_MAPI_WLAN_CHANNEL_6, IFX_MAPI_WLAN_CHANNEL_7, IFX_MAPI_WLAN_CHANNEL_8,
              IFX_MAPI_WLAN_CHANNEL_9, IFX_MAPI_WLAN_CHANNEL_10, IFX_MAPI_WLAN_CHANNEL_11}
            };
static const IFX_MAPI_WLAN_RegDomain   regDomainJapan_11g   =
            {IFX_MAPI_WLAN_REGDOMAIN_JAPAN_11G_LENGTH,
             {IFX_MAPI_WLAN_CHANNEL_1, IFX_MAPI_WLAN_CHANNEL_2, IFX_MAPI_WLAN_CHANNEL_3, IFX_MAPI_WLAN_CHANNEL_4,
              IFX_MAPI_WLAN_CHANNEL_5, IFX_MAPI_WLAN_CHANNEL_6, IFX_MAPI_WLAN_CHANNEL_7, IFX_MAPI_WLAN_CHANNEL_8,
              IFX_MAPI_WLAN_CHANNEL_9, IFX_MAPI_WLAN_CHANNEL_10, IFX_MAPI_WLAN_CHANNEL_11, IFX_MAPI_WLAN_CHANNEL_12,
              IFX_MAPI_WLAN_CHANNEL_13}
            };
static const IFX_MAPI_WLAN_RegDomain   regDomainJapan_11b   =
            {IFX_MAPI_WLAN_REGDOMAIN_JAPAN_11B_LENGTH,
             {IFX_MAPI_WLAN_CHANNEL_1, IFX_MAPI_WLAN_CHANNEL_2, IFX_MAPI_WLAN_CHANNEL_3, IFX_MAPI_WLAN_CHANNEL_4,
              IFX_MAPI_WLAN_CHANNEL_5, IFX_MAPI_WLAN_CHANNEL_6, IFX_MAPI_WLAN_CHANNEL_7, IFX_MAPI_WLAN_CHANNEL_8,
              IFX_MAPI_WLAN_CHANNEL_9, IFX_MAPI_WLAN_CHANNEL_10, IFX_MAPI_WLAN_CHANNEL_11, IFX_MAPI_WLAN_CHANNEL_12,
              IFX_MAPI_WLAN_CHANNEL_13, IFX_MAPI_WLAN_CHANNEL_14}
            };

/* global string array to hold the buffer returned from varous scripts */
char8 sResultFromScript[MAX_DATA_LEN];

#if defined (IFX_CONFIG_TSC_WLAN) && !(defined HOST_PLATFORM)
/* lookup table for list of channels supported based on country and mode */
/* 802.11A Standard */
// static const mac_channelDomain_t  macChannelDomainIND5 = {11, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11}};
static const mac_channelDomain_t  macChannelDomainFCC5 = {12, {36, 40, 44, 48, 52, 56, 60, 64, 149, 153, 157, 161}};
static const mac_channelDomain_t  macChannelDomainIC5 = {12, {36, 40, 44, 48, 52, 56, 60, 64, 149, 153, 157, 161}};
static const mac_channelDomain_t  macChannelDomainESP5 = {17, {36, 40, 44, 48, 52, 56, 60, 64, 104, 108, 112, 116, 120, 124, 128, 132, 140}};
static const mac_channelDomain_t  macChannelDomainFRA5 = {8, {36, 40, 44, 48, 52, 56, 60, 64}};
static const mac_channelDomain_t  macChannelDomainCHA5 = {4, {149, 153, 157, 161}};
// static const mac_channelDomain_t  macChannelDomainJPN5 = {8, {36, 40, 44, 48, 52, 56, 60, 64}};
static const mac_channelDomain_t  macChannelDomainJPN5 = {7, {1, 2, 3, 34, 38, 42, 46}};
/* 802.11b or 802.11b/g Standard */
static const mac_channelDomain_t  macChannelDomainIND24 = {11, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11}};
static const mac_channelDomain_t  macChannelDomainFCC24 = {11, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11}};
static const mac_channelDomain_t  macChannelDomainIC24 = {11, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11}};
static const mac_channelDomain_t  macChannelDomainEMEA24 = {13, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13}};
// static const mac_channelDomain_t  macChannelDomainESP24 = {2, {10, 11}}; as per TSC
static const mac_channelDomain_t  macChannelDomainESP24 = {11, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11}};
// static const mac_channelDomain_t  macChannelDomainFRA24 = {4, {10, 11, 12, 13}}; as per TSC
static const mac_channelDomain_t  macChannelDomainFRA24 = {11, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11}};
static const mac_channelDomain_t  macChannelDomainCHA24 = {13, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13}};
static const mac_channelDomain_t  macChannelDomainJPN24b = {14, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14}};
static const mac_channelDomain_t  macChannelDomainJPN24bg = {13, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13}};
#endif // IFX_CONFIG_TSC_WLAN

/* ========================================================================== */
/*                           Function prototypes                              */
/* ========================================================================== */
static int32 mapiWlanPersonalConfig (uint32 oper, IFX_MAPI_WLAN_SecCfg *wlSec);
static int32 mapiWlan8021XConfig    (uint32 oper, IFX_MAPI_WLAN_SecCfg *wlSec);
static int32 mapiWlanWepConfig      (uint32 oper, IFX_MAPI_WLAN_SecCfg *wlSec);
static int32 mapiWlanSetPersonalConfig (uint32 oper, IFX_MAPI_WLAN_PSKey *wlPsk, uint32 flags);
static int32 mapiWlanSetWepInSecurity (uint32 operation, IFX_MAPI_WLAN_WEP_Cfg *wlWepCfg, int32 passed_index, uint32 flags);
#ifdef IFX_MAPI_WLAN_WPS
static int32 mapiWlanGetSecurityConfigFromWps (IFX_MAPI_WLAN_SecCfg *wlSec, int32 index);
//static int32 mapiWlanGetSsidFromWps (IFX_MAPI_WLAN_MainCfg *wlMain, int32 index);
#endif /* IFX_MAPI_WLAN_WPS */
static int32 mapiWlanGetObjectFromRcConf(IFX_ID iid, IFX_NAME_VALUE_PAIR *array_fvp);

/* ========================================================================== */
/*                         Function implementation                            */
/* ========================================================================== */
int32 ltq_get_param(const char8 *param, char8 *result) {
		int32    	ret = IFX_SUCCESS;
		char8		sValue[MAX_DATA_LEN];
		char8    	*pTmpStr = NULL, *pTmpStr2 = NULL, *pTmpStr3;

		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_param", "param: %s", param);
		/* restore sValue buffer from global variable */
		strcpy(sValue, sResultFromScript);
		if((pTmpStr = strstr(sValue, param)) != NULL) {
				if (!(strncmp(param, "SSID_", 5))) {
						/* The algorithm with strstr to detect  the pattern in the output has a flaw:
						 * If two very similar parameter like SSID and BSSID are in the output, then
						 * BSSID is mistakenly detected as SSID.
						 * THis is a dirty hack to overcome this for the moment. Move the pointer to the
						 * next character and search again for SSID.
						 */
						pTmpStr3 = pTmpStr+1;
						IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_param", "pTmpStr: %s", pTmpStr);
						if((pTmpStr = strstr(pTmpStr3, param)) != NULL) {
								IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_param", "pTmpStr: %s", pTmpStr);
						}
				}
				pTmpStr2 = strtok(pTmpStr, "\"");
				if(pTmpStr2 == NULL) {
						ret = IFX_FAILURE;
						goto LTQ_Handler;
				}
				pTmpStr2 = strtok(NULL, "\"");
				if(pTmpStr2 == NULL) {
						ret = IFX_FAILURE;
						goto LTQ_Handler;
				}
		}
		else {
				IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_param", "sResultFromScript: %s", sResultFromScript);
				ret = IFX_FAILURE;
				goto LTQ_Handler;
		}
		strcpy(result, pTmpStr2);

LTQ_Handler:
		IFX_MAPI_DEBUG(fd, "/tmp/ltq_get_param", "ret=%d", ret);
		return ret;
}

/**

   \param wlSec

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
static int32 mapiWlanPersonalConfig(uint32 oper, IFX_MAPI_WLAN_SecCfg *wlSec)
{
   IFX_MAPI_WLAN_PSKey  wlPsk;
   int32                flags, ret = IFX_SUCCESS;
   char8	               buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
   uint32               outFlag = IFX_F_DEFAULT;

   IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanPersonalConfig", "");

   memset(&wlPsk, 0, sizeof(IFX_MAPI_WLAN_PSKey));
   wlPsk.iid.pcpeId.Id     = wlSec->iid.cpeId.Id;
   wlPsk.iid.config_owner  = wlSec->iid.config_owner;

	if ((oper == IFX_OP_ADD) || (oper == IFX_OP_DEL))
   {
	   flags = IFX_F_INT_DONT_CONFIGURE | IFX_F_DONT_WRITE_TO_FLASH;

      /* for add operation  set some default values */
   	if (oper == IFX_OP_ADD)
      {
         /* default values for wlPsk */
         strcpy(wlPsk.passPhrase, "NEW_PASS_PHRASE");
         strcpy(wlPsk.preSharedKey, "NEW_PSK");
      }
      else
      {
         /* get cpeId */
         sprintf(buf, "%s%d_0_cpeId", PREFIX_WLAN_PASSPHRASE, wlSec->iid.cpeId.Id);
         if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_PASSPHRASE,
            buf, IFX_F_GET_ANY, &outFlag, sValue)) != IFX_SUCCESS)
         {
            IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanPersonalConfig", "");
            goto IFX_Handler;
         }
         wlPsk.iid.cpeId.Id = atoi(sValue);
      }

      if((ret = mapiWlanSetPersonalConfig(oper, &wlPsk, flags))
          != IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanPersonalConfig", "mapiWlanSetPersonalConfig has failed");
         goto IFX_Handler;
      }
   }

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanPersonalConfig", "ret: %d", ret);
   if(ret != IFX_SUCCESS)
   {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return ret;
   }
   else
      return IFX_SUCCESS;
}

/**

   \param wlSec

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
static int32 mapiWlan8021XConfig(uint32 oper, IFX_MAPI_WLAN_SecCfg *wlSec)
{
   IFX_MAPI_WLAN_802_1x wlRadius;
   int32                flags, ret = IFX_SUCCESS, passed_index = -1;
   char8	               buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
   uint32               outFlag = IFX_F_DEFAULT;

   IFX_MAPI_DEBUG(fd, "/tmp/mapiWlan8021XConfig", "");

   memset(&wlRadius, 0, sizeof(IFX_MAPI_WLAN_802_1x));
   wlRadius.iid.pcpeId.Id  = wlSec->iid.cpeId.Id;
   wlRadius.iid.config_owner = wlSec->iid.config_owner;

	if ((oper == IFX_OP_ADD) || (oper == IFX_OP_DEL))
   {
	   flags = IFX_F_INT_DONT_CONFIGURE | IFX_F_INT_DONT_SEND_NOTIFICATION |
              IFX_F_INT_DONT_CHECK_ACL | IFX_F_DONT_WRITE_TO_FLASH;

      /* for add operation  set some default values */
   	if (oper == IFX_OP_ADD)
      {
         /* default values for wlRadius */
         wlRadius.groupKeyEna       = TRUE;
         wlRadius.groupKeyIntvl     = 3600;
         wlRadius.wpa2PreAuthEna    = TRUE;
         wlRadius.wpa2ReAuthIntvl   = 3600;
         if (!(inet_aton("192.168.1.1", &wlRadius.radiusServerIP)))
         {
            IFX_MAPI_DEBUG(fd, "/tmp/mapiWlan8021XConfig", "inet_aton has failed");
            ret = IFX_FAILURE;
            goto IFX_Handler;
         }

         wlRadius.radiusPort        = 1812;
         strcpy(wlRadius.radiusServerSecret, "NEW_RADIUS_SECRET");
         strcpy(wlRadius.domainName, "");
         strcpy(wlRadius.userName, "");
         wlRadius.authType          = IFX_MAPI_1X_AUTH_TYPE_LEAP;
         wlRadius.authProto         = IFX_MAPI_1X_AUTH_PROTO_PAP;
      }
      else
      {
         IFX_GET_INDEX_FROM_PCPEID(FILE_RC_CONF, wlSec->iid.cpeId, passed_index)

         sprintf(buf, "%s_%d_cpeId", PREFIX_WLAN_SEC_1X, passed_index);
         if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_1X,
               buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
            IFX_MAPI_DEBUG(fd, "/tmp/mapiWlan8021XConfig", "");
            goto IFX_Handler;
         }
         wlRadius.iid.cpeId.Id = atoi(sValue);
      }

      if ( (ret = ifx_mapi_set_wlan_802_1x_config(oper, &wlRadius, flags)) != IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/mapiWlan8021XConfig", "ifx_mapi_set_wlan_802_1x_config has failed");
         goto IFX_Handler;
      }
   }

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/mapiWlan8021XConfig", "ret: %d", ret);
   if(ret != IFX_SUCCESS)
   {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return ret;
   }
   else
      return IFX_SUCCESS;
}

/**

   \param wlSec

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
static int32 mapiWlanWepConfig(uint32 oper, IFX_MAPI_WLAN_SecCfg *wlSec)
{
   int32                   flags, i, ret = IFX_SUCCESS;
   IFX_MAPI_WLAN_WEP_Key   wlWepKey;
   char8	                  buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
   uint32                  outFlag = IFX_F_DEFAULT;

   IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanWepConfig", "");

   memset(&wlWepKey, 0, sizeof(IFX_MAPI_WLAN_WEP_Key));
   wlWepKey.iid.pcpeId.Id  = wlSec->iid.cpeId.Id;
   wlWepKey.iid.config_owner = wlSec->iid.config_owner;

	if ((oper == IFX_OP_ADD) || (oper == IFX_OP_DEL))
   {
	   flags = IFX_F_INT_DONT_CONFIGURE | IFX_F_DONT_WRITE_TO_FLASH;

      /* default values for wlWepKey */
      if (oper == IFX_OP_ADD)
         sprintf(wlWepKey.wepKey, "123456789abcdef0123456789a");

      for(i = 0; i < IFX_MAPI_NUM_WEP_KEYS; i++)
      {
         if (oper == IFX_OP_DEL)
         {
            sprintf(buf, "%s%d_%d_cpeId", PREFIX_WLAN_WEP, wlSec->iid.cpeId.Id, i);
            if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_WEP,
               buf, IFX_F_GET_ANY, &outFlag, sValue)) != IFX_SUCCESS)
            {
               IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanWepConfig", "");
               goto IFX_Handler;
            }
            wlWepKey.iid.cpeId.Id = atoi(sValue);
         }

         if((ret = ifx_mapi_set_wlan_wep_key(oper, i, &wlWepKey, flags)) != IFX_SUCCESS)
         {
            IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanWepConfig", "ifx_mapi_set_wlan_wep_key has failed");
            goto IFX_Handler;
         }
      }
   }

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanWepConfig", "ret: %d", ret);
   if(ret != IFX_SUCCESS)
   {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return ret;
   }
   else
      return IFX_SUCCESS;
}

#ifdef IFX_MAPI_WLAN_WPS
/**
   This function is called at the end of ifx_mapi_get_wlan_security_config.
   Purpose is to ensure that the correct security credentials are written to
   rc.conf. In case the security has been configured through WPS, then for the
   moment the content of rc.conf does not show the currently configured
   security. Everytime the security configuration shall be obtained it is
   checked if security has been configured through WPS. If yes, the settings
   are obtained from ra_wlan_wps_get_profile script and written back to rc.conf.

   \param wlSec

   \param index

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
static int32 mapiWlanGetSecurityConfigFromWps (IFX_MAPI_WLAN_SecCfg *wlSec, int32 index)
{
   int32                   ret = IFX_SUCCESS, beaconType = wlSec->beaconType, i;
   int32                   wlAuth = wlSec->wlAuth, wlEncr = wlSec->wlEncr;
   bool                    updateSecurityFlag = FALSE;
   uint32                  flags;
   char8                   sWpsProfileInfo[MAX_DATA_LEN], buf[MAX_FILELINE_LEN];
   char8                   sWpsProfileInfoTmp[MAX_DATA_LEN];
   char8	                  *pTmpStr = NULL, *pTmpStr2;
   /* struct timeval tv;

   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
	*/

   /*
      if security has been configured through WPS, then the new security
      credentials have to be obtained and must be written back to rc.conf
   */
   /*
      first get the configuration state
   */
   NULL_TERMINATE(buf, 0x00, sizeof(buf));
   memset(sWpsProfileInfo, 0x00, sizeof(sWpsProfileInfo));
   sprintf(buf, "%s %d", SERVICE_WLAN_GET_WPS_PROFILE, index);

   /* get security information from WPS profile */
   if (ifx_GetCfgData((char8*)buf, NULL, "-1", sWpsProfileInfo) == 0)
   {
      ret = IFX_FAILURE;
      goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps",
                      "sWpsProfileInfo: %s", sWpsProfileInfo);

   /* save buffer in sValueTmp */
   strcpy(sWpsProfileInfoTmp, sWpsProfileInfo);

   /* get configuration state */
   if((pTmpStr = strstr(sWpsProfileInfo,"CONFIGURED=")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if (pTmpStr2 == NULL)
      {
          goto IFX_Handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if (pTmpStr2 == NULL)
      {
          goto IFX_Handler;
      }

   	/* Configured is not set to "Yes", therefore return */
      if (!(strcmp(pTmpStr2, "EMPTY")))
      {
         IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps", "");
         goto IFX_Handler;
      }
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps",
                         "sWpsProfileInfo: %s",sWpsProfileInfo);

   /* restore sWpsProfileInfo buffer from sWpsProfileInfoTmp */
   strcpy(sWpsProfileInfo, sWpsProfileInfoTmp);

   /* get beacon mode */
   if((pTmpStr = strstr(sWpsProfileInfo,"BEACON=")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if (pTmpStr2 == NULL)
      {
          goto IFX_Handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if (pTmpStr2 == NULL)
      {
          goto IFX_Handler;
      }
      beaconType = atoi(pTmpStr2);
//      wlSec->beaconType = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps",
                         "Beacon: %d", beaconType);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps",
                         "sWpsProfileInfo: %s",sWpsProfileInfo);

   /* restore sWpsProfileInfo buffer from sWpsProfileInfoTmp */
   strcpy(sWpsProfileInfo, sWpsProfileInfoTmp);

   /* get authentication mode */
   if((pTmpStr = strstr(sWpsProfileInfo,"AUTH=")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if (pTmpStr2 == NULL)
      {
          goto IFX_Handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if (pTmpStr2 == NULL)
      {
          goto IFX_Handler;
      }
      wlAuth = atoi(pTmpStr2);
//      wlSec->wlAuth = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps",
                         "Authentication: %d", wlAuth);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps",
                         "sWpsProfileInfo: %s",sWpsProfileInfo);
   /* restore sWpsProfileInfo buffer from sWpsProfileInfoTmp */
   strcpy(sWpsProfileInfo, sWpsProfileInfoTmp);

   /* get encryption mode */
   if((pTmpStr = strstr(sWpsProfileInfo,"ENCR=")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if (pTmpStr2 == NULL)
      {
          goto IFX_Handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if (pTmpStr2 == NULL)
      {
          goto IFX_Handler;
      }
      wlEncr = atoi(pTmpStr2);
//      wlSec->wlEncr = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps",
                         "Encryption: %d", wlEncr);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps",
                         "sWpsProfileInfo: %s",sWpsProfileInfo);
   /* restore sWpsProfileInfo buffer from sWpsProfileInfoTmp */
   strcpy(sWpsProfileInfo, sWpsProfileInfoTmp);

   /* check if something has changed */
   if ((wlSec->beaconType != beaconType)  ||
       (wlSec->wlAuth != wlAuth)          ||
       (wlSec->wlEncr != wlEncr))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps",
                         "security changed and must be updated");
      wlSec->beaconType    = beaconType;
      wlSec->wlAuth        = wlAuth;
      wlSec->wlEncr        = wlEncr;
      updateSecurityFlag   = TRUE;
   }
   if (wlSec->wlAuth == IFX_MAPI_WLAN_AUTH_PERSONAL)
   {
      /* if security has changed we need to get the configuration again */
      if (updateSecurityFlag == TRUE)
      {
      wlSec->secParams.personalCfg.psk.iid.pcpeId.Id = wlSec->iid.cpeId.Id;
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps",
                         "pcpeID: %d",
                         wlSec->secParams.personalCfg.psk.iid.pcpeId.Id);
      if((ret = ifx_mapi_get_wlan_personal_config(&wlSec->secParams.personalCfg, IFX_F_DEFAULT)) != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps", "");
         goto IFX_Handler;
      }
      }

      /* now get passphrase */
      if((pTmpStr = strstr(sWpsProfileInfo,"PSK=")) != NULL)
      {
         pTmpStr2 = strtok(pTmpStr, "\"");
         if (pTmpStr2 == NULL)
         {
             goto IFX_Handler;
         }
         pTmpStr2 = strtok(NULL, "\"");
         if (pTmpStr2 == NULL)
         {
             goto IFX_Handler;
         }
         IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps", "psk: %s",
                        pTmpStr2);

         /* if we already know that security must be updated, we do not need
            the below comparisons */
         if (updateSecurityFlag == FALSE)
         {
            /* if passphrase or psk is different, we need to update */
            if ((wlSec->secParams.personalCfg.pskType == IFX_MAPI_WLAN_ASCII_KEY) &&
                (strcmp(pTmpStr2, wlSec->secParams.personalCfg.psk.passPhrase)))
            {
               updateSecurityFlag = TRUE;
            }
            else if ((wlSec->secParams.personalCfg.pskType == IFX_MAPI_WLAN_HEX_KEY) &&
                     (strcmp(pTmpStr2, wlSec->secParams.personalCfg.psk.preSharedKey)))
            {
               updateSecurityFlag = TRUE;
            }
            else
            {
               IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps",
                                  "we should not be here");
               goto IFX_Handler;
            }
         }

         /* if security must be updated, copy the new passphrase/psk to wlSec */
         if (updateSecurityFlag == TRUE)
         {
            IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps",
                               "security changed and must be updated");
            if (strlen(pTmpStr2) == IFX_MAPI_PSK_MAX_LEN-1)
            {
               strcpy(wlSec->secParams.personalCfg.psk.preSharedKey, pTmpStr2);
               strcpy(wlSec->secParams.personalCfg.psk.passPhrase, "");
               wlSec->secParams.personalCfg.pskType = IFX_MAPI_WLAN_HEX_KEY;
            }
            else
            {
         strcpy(wlSec->secParams.personalCfg.psk.passPhrase, pTmpStr2);
               strcpy(wlSec->secParams.personalCfg.psk.preSharedKey, "");
         wlSec->secParams.personalCfg.pskType = IFX_MAPI_WLAN_ASCII_KEY;
            }
         }
      }
      else
         IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps",
                            "sWpsProfileInfo: %s",sWpsProfileInfo);
   }
   else if (wlSec->wlAuth == IFX_MAPI_WLAN_AUTH_RADIUS)
   {
      wlSec->secParams.wlRadius.iid.pcpeId.Id = wlSec->iid.cpeId.Id;
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps",
                         "pcpeID: %d",
                         wlSec->secParams.wlRadius.iid.pcpeId.Id);
      if((ret = ifx_mapi_get_wlan_802_1x_config(&wlSec->secParams.wlRadius, IFX_F_DEFAULT)) != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps", "");
         goto IFX_Handler;
      }

      /*
         \todo
         now get radius secret
      */
   }
   else
   {
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps", "TODO");
      if (wlSec->wlEncr == IFX_MAPI_WLAN_ENCR_WEP)
      {
         for (i = 0; i < IFX_MAPI_NUM_WEP_KEYS; i++)
            wlSec->secParams.wepCfg.wepKey[i].iid.pcpeId.Id = wlSec->iid.cpeId.Id;

		   if ((ret = ifx_mapi_get_wlan_wep_config(
                     &wlSec->secParams.wepCfg, IFX_F_DEFAULT)) != IFX_SUCCESS)
         {
            IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps", "");
            goto IFX_Handler;
		   }

         /*
            \todo
            now get the wep keys
         */
      }
   }

   if (updateSecurityFlag == TRUE)
   {
	flags = IFX_F_MODIFY | IFX_F_INT_DONT_CONFIGURE;
	if (( ret = ifx_mapi_set_wlan_security_config(IFX_OP_MOD, wlSec, flags)) != IFX_SUCCESS)
	{
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps", "");
      goto IFX_Handler;
	}
   }
IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps", "ret: %d", ret);
	/*
   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSecurityConfigFromWps", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
	*/
   return ret;
}
#if 0
/**
   This function is called at the end of ifx_mapi_get_wlan_main_config.
   Purpose is to ensure that the correct ssid is written to rc.conf. In case the
   security has been configured through an external registrar, then for the
   moment the content of rc.conf does not show the currently configured
   ssid.

   \param wlMain

   \param index

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
static int32 mapiWlanGetSsidFromWps (IFX_MAPI_WLAN_MainCfg *wlMain, int32 index)
{
   int32                   ret = IFX_SUCCESS;
   uint32                  flags;
   char8                   sWpsProfileInfo[MAX_DATA_LEN], buf[MAX_FILELINE_LEN];
   char8                   sWpsProfileInfoTmp[MAX_DATA_LEN];
   char8	                  *pTmpStr = NULL, *pTmpStr2 = NULL, new_ssid[IFX_MAPI_WLAN_SSID_LEN];
	/*
   struct timeval tv;

   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSsidFromWps", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
	*/

   /* first get the wps profile */
   NULL_TERMINATE(buf, 0x00, sizeof(buf));
   memset(sWpsProfileInfo, 0x00, sizeof(sWpsProfileInfo));
   sprintf(buf, "%s %d", SERVICE_WLAN_GET_WPS_PROFILE, index);

   /* get security information from WPS profile */
   if (ifx_GetCfgData((char8*)buf, NULL, "-1", sWpsProfileInfo) == 0)
   {
      ret = IFX_FAILURE;
      goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSsidFromWps",
                      "sWpsProfileInfo: %s", sWpsProfileInfo);

   /* save buffer in sValueTmp */
   strcpy(sWpsProfileInfoTmp, sWpsProfileInfo);

#if 1
   /* get configuration state */
   if((pTmpStr = strstr(sWpsProfileInfo,"CONFIGURED=")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if (pTmpStr2 == NULL)
      {
      	  ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSsidFromWps", "");
      if (pTmpStr2 == NULL)
      {
      	 ret = IFX_FAILURE;
         goto IFX_Handler;
      }
   }
   else
   {
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSsidFromWps",
                         "Configured state not found!");
      goto IFX_Handler;
   }

   /* Configured is set to "EMPTY", therefore return */
   if (!(strcmp(pTmpStr2, "EMPTY")))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSsidFromWps", "");
      goto IFX_Handler;
   }

   /*
      Configured is set to "Yes", therefore we need to get ssid from wps
      profile;
      first restore profile info from sWpsProfileInfoTmp
   */
   strcpy(sWpsProfileInfo, sWpsProfileInfoTmp);
#endif /* #if 0 */

   /* get ssid */
   if((pTmpStr = strstr(sWpsProfileInfo,"SSID=")) != NULL)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSsidFromWps", "pTmpStr: %s", pTmpStr);
      pTmpStr2 = strtok(pTmpStr, "\"");
      if (pTmpStr2 == NULL)
      {
      	 ret = IFX_FAILURE;
         goto IFX_Handler;
      }
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSsidFromWps", "pTmpStr2: %s", pTmpStr2);
      pTmpStr2 = strtok(NULL, "\"");
      if (pTmpStr2 == NULL)
      {
      	 ret = IFX_FAILURE;
         goto IFX_Handler;
      }
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSsidFromWps", "pTmpStr2: %s", pTmpStr2);

      strcpy(new_ssid, pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSsidFromWps", "new_ssid: %s", new_ssid);
   }
   else
   {
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSsidFromWps",
                         "sWpsProfileInfo: %s",sWpsProfileInfo);
      ret = IFX_FAILURE;
      goto IFX_Handler;
   }

   /*
      if SSID from wps profile is different than the one stored in rc.conf and
      is not an empty string, then an update is required
   */
   if (strcmp(pTmpStr2, wlMain->ssid) && strlen(pTmpStr2))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSsidFromWps", "");
      strcpy(wlMain->ssid, pTmpStr2);
	   flags = IFX_F_MODIFY | IFX_F_INT_DONT_CONFIGURE;
	   if (( ret = ifx_mapi_set_wlan_main_config(IFX_OP_MOD, wlMain, flags)) != IFX_SUCCESS)
	   {
         IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSsidFromWps", "");
         goto IFX_Handler;
	   }
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSsidFromWps", "");

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSsidFromWps", "ret: %d", ret);
	/*
   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetSsidFromWps", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
	*/
   return ret;
}
#endif
#endif /* #ifdef IFX_MAPI_WLAN_WPS */

/**
   \param iid

   \param array_fvp

   \return
   - IFX_SUCCESS
   - IFX_FAILURE
*/
static int32 mapiWlanGetObjectFromRcConf (IFX_ID iid, IFX_NAME_VALUE_PAIR *array_fvp)
{
   int32    ret = IFX_SUCCESS, passed_index = -1, count = 0, i;
   char8	*sValue = NULL, conf_buf[MAX_DATA_LEN];

   if (!strcmp(iid.cpeId.secName, TAG_WLAN_SEC))
   {
      IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, iid.cpeId, passed_index)
      sprintf(conf_buf, "%s_%d_", PREFIX_WLAN_SEC, passed_index);
   }
   else
   {
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetObjectFromRcConf",
                         "Tag not yet supported: %s", iid.cpeId.secName);
   }

   if((ret = ifx_GetCfgObject(FILE_RC_CONF, iid.cpeId.secName, conf_buf,
                              IFX_F_DEFAULT, &sValue)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetObjectFromRcConf",
                         "conf_buf: %s, passed_index: %d",
                         conf_buf, passed_index);
      goto IFX_Handler;
   }

   /* form an array of field value pairs for easier access to parameters */
   form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);

   for (i = 0; i < count; i++)
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetObjectFromRcConf", "%s:%s",
                         array_fvp[i].fieldname, array_fvp[i].value);
IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetObjectFromRcConf", "ret: %d", ret);
   IFX_MEM_FREE(sValue);
	/*
   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanGetObjectFromRcConf", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
	*/
   return ret;
}

/**

   \param oper

   \param wlMain

   \param flags

   \return
   - IFX_SUCCESS
   - IFX_FAILURE

   \notes   - should an add here, add object for security config also?
              no it should be done from ifx_set_wlan_ap_config
            - notification and tr69 map update should be called locally?
               yes
            - validation to check for combination of standard, country,
              op-reates, basic-rates and channels
            - wireless start script checks if both phy-radio and this ap/vap is
              enabled, then only starts the service
*/
int32 ifx_mapi_set_wlan_main_config(uint32 oper, IFX_MAPI_WLAN_MainCfg *wlMain, uint32 flags)
{
   bool                 found = 0;
   char8	               conf_buf[MAX_DATA_LEN], buf[MAX_FILELINE_LEN];
   int32                count = 0, changed_count = 0, passed_index = -1;
   int32                ret = IFX_SUCCESS, i = 0;
   IFX_NAME_VALUE_PAIR  array_fvp[WLAN_MAIN_PARAM_COUNT + 1];
   IFX_NAME_VALUE_PAIR  *array_changed_fvp = NULL;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");

    memset(array_fvp, 0, sizeof(array_fvp));
    NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));


   /*************** Prolog Block *********************/
   /* Based on operation (ADD or DELETE or MODIFY)
    * append the flag with internal flags */
   if (oper == IFX_OP_DEL)
      flags |= IFX_F_DELETE;
   else if (oper == IFX_OP_ADD) {
      if( (IFX_MODIFY_F_NOT_SET(flags)))
         flags |= IFX_F_INT_ADD;
   }
   else
      flags |= IFX_F_MODIFY;

   sprintf(wlMain->iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
   sprintf(wlMain->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

   /**************** Validation Block *****************/
   /* For Operations other than DELETE do the verification of input params */
   if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
      /* Do simple validation of pointer such as NULL */
      IFX_VALIDATE_PTR(wlMain)
      /* Do simple validation of flags sucha as less than 0 */
      IFX_VALIDATE_FLAGS(flags)
      /* validate max-bit rate here */
      if(wlMain->maxBitRate == 0)
         found = 1;
      else {
         i = 0;
         while(wlMain->operDataRates[i] != 0) {
            if(wlMain->operDataRates[i] == wlMain->maxBitRate) {
               found = 1;
               break;
            }
            i++;
         }
      }
      if(!found) {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d] Validation failed : max bit rate should be one of operational data rates",
                     __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig",
                            "Validation failed : max bit rate should be one of "
                            "operational data rates");
         ret = IFX_FAILURE;
         goto IFX_Handler;
      }
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "ssid: %s", wlMain->ssid);
      IFX_VALIDATE_SSID(wlMain)
   }

#if 0
   /**************** ID Allocation Block - Only for ADD Operation **************/
   if (IFX_ADD_F_SET(flags))
   {
      /*
         get new IID if called from WEB GUI, if called through TR69 (ifx_mapi_set_wlan_ap_config)
         new IID has been allocated in ifx_set_wlan_ap_config
      */
      if (wlMain->iid.config_owner == IFX_WEB)
      {
         if(ifx_get_IID(&wlMain->iid, "ssid") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "ifx_get_IID:tr69id:%s", wlMain->iid.tr69Id);
            ret = IFX_FAILURE;
            goto IFX_Handler;
         }
      }
    }
#endif /* #if 0 */

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "cpeID: %d, pCpeID: %d", wlMain->iid.cpeId.Id, wlMain->iid.pcpeId.Id);
   /**************** Name Value Formation as per RC.CONF ********************/
   /* Form the FVP from the given structure for ADD/MODIFY
    * Operations
    */
   count = 0;
   if(IFX_DELETE_F_NOT_SET(flags)) {
      ifx_fill_ArrayFvp_FName(array_fvp, 0, WLAN_MAIN_PARAM_COUNT, wlan_main_params);

      /* apEnable is uint32 here !! */
      ifx_fill_ArrayFvp_intValues(
         array_fvp, 0, 4, (int32 *) &wlMain->iid.cpeId.Id, &wlMain->iid.pcpeId.Id,
         &wlMain->radioCpeId, &wlMain->apEnable);
      sprintf(array_fvp[4].value, "%s", wlMain->apName); /* apName */
      sprintf(array_fvp[5].value, "%d", wlMain->devType); /* apName */
      sprintf(array_fvp[6].value, "%s", wlMain->ssid);
      sprintf(array_fvp[7].value, "%d", wlMain->ssidMode);
      sprintf(array_fvp[8].value, "%d", wlMain->bssidOverride);
      if(strlen(wlMain->bssid)==17)
      	sprintf(array_fvp[9].value, "%s", wlMain->bssid);
      else
	sprintf(array_fvp[9].value, "%s","");
      /* Pramod - how to fill basic and operational data rates
                  have them as comma seperated integers in a string */
      i = 0;
      while(wlMain->basicDataRates[i] != 0) {
         memset(buf, 0x00, sizeof(buf));
         sprintf(buf, "%.1f,", wlMain->basicDataRates[i]);
         strcat(array_fvp[10].value, buf);
         i++;
      }
      array_fvp[10].value[strlen(array_fvp[10].value) - 1] = '\0';

      i = 0;
      while(wlMain->operDataRates[i] != 0) {
         memset(buf, 0x00, sizeof(buf));
         sprintf(buf, "%.1f,", wlMain->operDataRates[i]);
         strcat(array_fvp[11].value, buf);
         i++;
      }
      array_fvp[11].value[strlen(array_fvp[11].value) - 1] = '\0';

      sprintf(array_fvp[12].value, "%2.1f", wlMain->maxBitRate);
      ifx_fill_ArrayFvp_intValues(
         array_fvp, 13, 1, (int32 *) &wlMain->vlanId);
      sprintf(array_fvp[14].value, "%d", wlMain->apIsolationEna);

      sprintf(array_fvp[15].value, "%d", wlMain->WMMena);
      sprintf(array_fvp[16].value, "%d", wlMain->UAPSDena);
      sprintf(array_fvp[17].value, "%d", wlMain->WDSena);
      sprintf(array_fvp[18].value, "%d", wlMain->WPSena);
      sprintf(array_fvp[19].value, "%d", wlMain->maxStations);      
      passed_index = -1;
   }

   count = WLAN_MAIN_PARAM_COUNT;

   /* Get Config Index in case of modify/delete operations from CPEID */
   if((IFX_MODIFY_F_SET(flags)) ||
      (IFX_DELETE_F_SET(flags))) {
      IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlMain->iid.cpeId, passed_index)
   }

   /* Determine the configuration index - for Add, Delete, Modify operations
     * Name is partial since index is not known
     * Fill array_fvp[] */
   if(ifx_get_conf_index_and_nv_pairs(&wlMain->iid, passed_index, PREFIX_WLAN_MAIN,
            count, array_fvp, flags) != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
      ret = IFX_FAILURE;
      goto IFX_Handler;
   }

   if (IFX_INT_ADD_F_SET(flags))
   {
		/* Get index value from Section Count if it exists */
      if ((ret = (ifx_get_index_from_sec_count(FILE_RC_CONF, wlMain->iid.cpeId.secName,
           &passed_index, flags))) != IFX_SUCCESS)
      {
         goto IFX_Handler;
      }
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "passed_index: %d", passed_index);
   }

   /************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/

   if(IFX_ADD_F_NOT_SET(flags) && IFX_INT_DONT_CHECK_ACL_F_NOT_SET(flags))
   {
      CHECK_ACL_RET(wlMain->iid, count, array_fvp,
                  changed_count, array_changed_fvp, flags, IFX_Handler)
   }

   /*
      before the configuration file is updated, the ap/vap is stopped in case of
      a modify operation; in case of a delete operation the vap is removed
   */
   /*
      \todo check code
   */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
         IFX_DEACTIVATE_F_NOT_SET(flags))
   {
      if (IFX_MODIFY_F_SET(flags))
      {
         /* disable AP before updating with new configuration */
         sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, passed_index);
         system(conf_buf);
      }
      else if (IFX_DELETE_F_SET(flags))
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
         /* remove AP */
         sprintf(conf_buf, "%s %d", SERVICE_WLAN_REMOVE_VAP, passed_index);
         system(conf_buf);
      }
   }

   /************** System Config File Update Block ****************/
   /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
   form_cfgdb_buf(conf_buf, count, array_fvp);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "conf_buf: %s", conf_buf);

   /* RC.CONF Configuration block */
   ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_MAIN, flags, 1, conf_buf);

   if(ret != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
      goto IFX_Handler;
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
   /*********** Device Configuration Block ****************/
   /* Device config thru Scripts/Utilities or Functions */
   /* after config file update, for modify or add operation start all ap/vap */

   /*
      \todo check code: add IFX_DEACTIVATE_F_NOT_SET flag check
   */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags) &&
      (IFX_INT_ADD_F_SET(flags) || IFX_MODIFY_F_SET(flags)))
   {
      sprintf(conf_buf, "%s %d", SERVICE_WLAN_START, passed_index);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "conf_buf: %s", conf_buf);
      system(conf_buf);
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
   /* this will Compact the section and also update the count for both ADD and DELETE */
   if(IFX_MODIFY_F_NOT_SET(flags))
      ifx_CompactCfgSection(FILE_RC_CONF, TAG_WLAN_MAIN, flags);

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
   /*********** Notification Block *************/
   /* Notify the Internal TR69 Stack in case of MODIFY */

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
   /*********** Epilog Block **************/
   /* Update the IID mappings in the mappings section for ADD/DELETE */
   if(IFX_MODIFY_F_SET(flags))
   {
      CHECK_N_SEND_NOTIFICATION(wlMain->iid, changed_count, array_changed_fvp, flags, IFX_Handler)
   }
   else if (IFX_INT_ADD_F_SET(flags))
   {
      /* In case of ADD operation, first update the ID Mappings
       * and then send the Notification for the attributes
       */
      /*********** Epilog Block **************/
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "UPDATE_ID_MAP_N_ATTRIBUTES");
      UPDATE_ID_MAP_N_ATTRIBUTES(&wlMain->iid, count, array_fvp, flags, IFX_Handler)

      if (IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(flags))
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
         CHECK_N_SEND_NOTIFICATION(wlMain->iid, count, array_fvp, flags, IFX_Handler)
      }

      /* Manipulate nextCpeId only for ADD operations */
      ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_MAIN);
   }
   else if (IFX_DELETE_F_SET(flags)) {
      /* In case of DELETE operation, first send the notificatioupdate the ID Mappings
       * and then send the Notification for the attributes
       */
      /*********** Epilog Block **************/
      if (IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(flags))
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
         CHECK_N_SEND_NOTIFICATION(wlMain->iid, count, array_fvp, flags, IFX_Handler)
      }

      UPDATE_ID_MAP_N_ATTRIBUTES(&wlMain->iid, count, array_fvp, flags, IFX_Handler)
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "flags: 0x%x", flags);
   /* Updating Persistent Storage */
   ret = ifx_config_write(FILE_RC_CONF, flags);
   if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "");
      goto IFX_Handler;
   }

IFX_Handler:
   IFX_MEM_FREE(array_changed_fvp);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "ret: %d", ret);
   if(ret != IFX_SUCCESS)
   {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return ret;
   }
   else
      return IFX_SUCCESS;
}

/**
   \param   wlSec - pointer to IFX_MAPI_WLAN_SecCfg Main config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks -  Only modify operation is supported on device type = AP
            -  validation to check for combination of standard, country, op-reates, basic-rates and channels
            -  wireless start script checks if both phy-radio and this ap/vap is enabled, then only starts the service
*/
int32 ifx_mapi_set_wlan_phy_config(uint32 oper, IFX_MAPI_WLAN_PhyCfg *wlPhyCfg, uint32 flags)
{
   char8	conf_buf[MAX_DATA_LEN];
   int32	count = 0, changed_count = 0, passed_index = -1, ret = IFX_SUCCESS;
   IFX_NAME_VALUE_PAIR array_fvp[WLAN_PHY_PARAM_COUNT + 1], *array_changed_fvp = NULL;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "");
   memset(array_fvp, 0, sizeof(array_fvp));
   NULL_TERMINATE(conf_buf, 0, sizeof(conf_buf));

   /*************** Prolog Block *********************/
   /* only modify operation is supported */
   if (oper == IFX_OP_MOD)
      flags |= IFX_F_MODIFY;
   else {
      ret = IFX_FAILURE;
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "");
      goto IFX_Handler;
   }

   /**************** Validation Block *****************/
   /* For Operations other than DELETE do the verification of input params */
   if(IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
      /* Do simple validation of pointer such as NULL */
      IFX_VALIDATE_PTR(wlPhyCfg)
      /* Do simple validation of flags sucha as less than 0 */
      IFX_VALIDATE_FLAGS(flags)
   }

   /* set cpeId.ID and pcpeId.ID of wlPhyCfg */
   /*
      \todo
      check for dual radio setup, for now assume only one radio and set to
      fixed (default) value
   */
   sprintf(wlPhyCfg->iid.cpeId.secName, "%s", TAG_WLAN_PHY);
   sprintf(wlPhyCfg->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
   /* default is 1 */

   //kamal: change
   // wlPhyCfg->iid.cpeId.Id = 1;
   /* parent is always LAN -> fixed value = 1 */
   wlPhyCfg->iid.pcpeId.Id = 1; // cpeid of lan device

   /*********************** Name Value Formation as per RC.CONF **********************/
   ifx_fill_ArrayFvp_FName(array_fvp, 0, WLAN_PHY_PARAM_COUNT, wlan_phy_params);

   ifx_fill_ArrayFvp_intValues (
      array_fvp, 0, 3, (int32 *) &wlPhyCfg->iid.cpeId.Id, &wlPhyCfg->iid.pcpeId.Id,
      &wlPhyCfg->standard);

   sprintf(array_fvp[3].value, "%s",wlPhyCfg->country); 
   sprintf(array_fvp[4].value, "%d",wlPhyCfg->usageEnv);
   sprintf(array_fvp[5].value, "%d",wlPhyCfg->freqBand);

   /* channel number is uint8 type and can not be set with ifx_fill_ArrayFvp_intValues */
   sprintf(array_fvp[6].value, "%u", wlPhyCfg->channelNo);
   sprintf(array_fvp[7].value, "%d", wlPhyCfg->autoChannelEna);
   sprintf(array_fvp[8].value, "%d", wlPhyCfg->beaconTxEna);
   sprintf(array_fvp[9].value, "%d", wlPhyCfg->beaconIntvl);
#if 0
   ifx_fill_ArrayFvp_intValues (
      array_fvp, 7, 3, &wlPhyCfg->autoChannelEna, &wlPhyCfg->beaconTxEna,
      &wlPhyCfg->beaconIntvl);
#endif

   /* DTIM interval is uint8 type and can not be set with ifx_fill_ArrayFvp_intValues */
   sprintf(array_fvp[10].value, "%d", wlPhyCfg->dtimInt);
   ifx_fill_ArrayFvp_intValues (
      array_fvp, 11, 3, (int32 *) &wlPhyCfg->rts, &wlPhyCfg->fts, &wlPhyCfg->powerLvl);
   sprintf(array_fvp[14].value, "%d", wlPhyCfg->radioEnable);
   sprintf(array_fvp[15].value, "%d", wlPhyCfg->autoRateFallBackEna);

#if 0
   ifx_fill_ArrayFvp_intValues (
      array_fvp, 11, 5, &wlPhyCfg->rts, &wlPhyCfg->fts, &wlPhyCfg->powerLvl,
      &wlPhyCfg->radioEnable, &wlPhyCfg->autoRateFallBackEna);
#endif

   if (wlPhyCfg->staticRate == 0)
	   	   sprintf(array_fvp[16].value, "%d", (int32)wlPhyCfg->staticRate);
   else
   	   	   sprintf(array_fvp[16].value, "%.1f", wlPhyCfg->staticRate);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "array_fvp[16].value = %s", array_fvp[16].value);

   sprintf(array_fvp[17].value, "%d", wlPhyCfg->preamble);

   sprintf(array_fvp[18].value, "%d", wlPhyCfg->phy11N.chanBW);

   sprintf(array_fvp[19].value, "%d", wlPhyCfg->phy11N.extChPos);

   sprintf(array_fvp[20].value, "%d", wlPhyCfg->phy11N.guardIntvl );

   sprintf(array_fvp[21].value, "%d", wlPhyCfg->phy11N.mcs);

   sprintf(array_fvp[22].value, "%d", wlPhyCfg->phy11N.diversity.diversityEna);
   sprintf(array_fvp[23].value, "%d", wlPhyCfg->phy11N.diversity.diversityDir);
   sprintf(array_fvp[24].value, "%d", wlPhyCfg->phy11N.diversity.antenna);
   sprintf(array_fvp[25].value, "%d", wlPhyCfg->phy11N.rxStbc);

   sprintf(array_fvp[26].value, "%d", wlPhyCfg->phy11N.baWinSize);

   sprintf(array_fvp[27].value, "%d", wlPhyCfg->phy11N.aggr.ampduEna);
   sprintf(array_fvp[28].value, "%d", wlPhyCfg->phy11N.aggr.ampduDir);
   sprintf(array_fvp[29].value, "%d", wlPhyCfg->phy11N.aggr.ampduLen);
   sprintf(array_fvp[30].value, "%d", wlPhyCfg->phy11N.aggr.ampduFrmsDensity);
   sprintf(array_fvp[31].value, "%d", wlPhyCfg->phy11N.aggr.amsduEna);
   sprintf(array_fvp[32].value, "%d", wlPhyCfg->phy11N.aggr.amsduDir);
   sprintf(array_fvp[33].value, "%d", wlPhyCfg->phy11N.aggr.amsduLen);
#if 0
   sprintf(array_fvp[34].value, "%d", wlPhyCfg->phy11N.greenfieldEna);
#endif
   passed_index = -1;
   count = WLAN_PHY_PARAM_COUNT;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "");
   /* Get Config Index in case of modify/delete operations from CPEID */
   IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlPhyCfg->iid.cpeId, passed_index)

   /* determine the configuration index
      name is partial since index is not known
      fill array_fvp[]
   */
   if (ifx_get_conf_index_and_nv_pairs(
         &wlPhyCfg->iid, passed_index, PREFIX_WLAN_PHY, count, array_fvp, flags)
         != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif /* #ifdef IFX_LOG_DEBUG */
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "");
      ret = IFX_FAILURE;
      goto IFX_Handler;
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "");
   /************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
   CHECK_ACL_RET(wlPhyCfg->iid, count, array_fvp,
               changed_count, array_changed_fvp, flags, IFX_Handler)

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "");
   /* before config file update, for modify or delete operation stop all ap/vap */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      (IFX_DELETE_F_SET(flags) || IFX_MODIFY_F_SET(flags))) {
      /* only stop AP */
      sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, passed_index);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "conf_buf: %s", conf_buf);
      system(conf_buf);
   }

   /************** System Config File Update Block ****************/
   /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
   form_cfgdb_buf(conf_buf, count, array_fvp);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "conf_buf: %s", conf_buf);

   /* RC.CONF Configuration block */
   ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_PHY, flags, 1, conf_buf);

   if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "");
      goto IFX_Handler;
   }

   /*********** Device Configuration Block ****************/
   /* Device config thru Scripts/Utilities or Functions */
   /* after config file update, for modify or add operation start all ap/vap */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      (IFX_INT_ADD_F_SET(flags) || IFX_MODIFY_F_SET(flags)))
   {
      /* hard-coded to AP index */
      sprintf(conf_buf, "%s %d", SERVICE_WLAN_START, passed_index);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "conf_buf: %s", conf_buf);
      system(conf_buf);
   }

   /*********** Notification Block *************/
   /* Notify the Internal TR69 Stack in case of MODIFY */

   /*********** Epilog Block **************/
   /* Update the IID mappings in the mappings section for ADD/DELETE */
   /*
      \todo check with Subramani what to do
   */
   if(IFX_MODIFY_F_SET(flags)) {
      CHECK_N_SEND_NOTIFICATION(wlPhyCfg->iid, changed_count, array_changed_fvp, flags, IFX_Handler)
   }

   /* Updating Persistent Storage */
   ret = ifx_config_write(FILE_RC_CONF, flags);
   if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "");
      goto IFX_Handler;
   }

IFX_Handler:
   IFX_MEM_FREE(array_changed_fvp);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPhyConfig", "ret: %d", ret);
   if(ret != IFX_SUCCESS) {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return ret;
   }
   else
      return IFX_SUCCESS;
}

/**
   This API configures the WLAN WEP parameters for given AP/VAP.

   \param   operation   - type of operation (ADD, MODIFY, DELETE)

   \param   wepKeyIndex -

   \param   wlWepKey    - pointer to IFX_MAPI_WLAN_SecCfg structure

   \param   flags       - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks - this api is a little different from the usual set apis. in that
               the format it stores in rc.conf is prefix{pcpeid}_0_param which
               is against conventional prefix_0_param. so be careful while
               calling the utility functions
            - this api cannot be called for all the 4 keys combined. since
              notification, update map and acl need single instance iid we
              cannot have the api handle all the 4 instances at a time. so it
              should be called for each of the 4 wep key objects one by one.
            - the api should be called with wlan_sec->wepKeyIndex filled with
              the wep key index that is operated irrespective of the operation
            - for this object WEP_KEY structure should be used and this will have
              cpeid and pcpeid filled for modify operation also key index should
              be given as seperate argument to this api
            - for wep key value can be either decimal or hex, so we need to
              introduce field in struct which says the key type in which the key
              is input
            - validation for wep key type and passphrase key type
            - wireless start script checks if both phy-radio and this ap/vap is
              enabled, then only starts the service
*/
int32 ifx_mapi_set_wlan_wep_key(uint32 operation, int32 wepKeyIndex, IFX_MAPI_WLAN_WEP_Key *wlWepKey, uint32 flags)
{
   CPE_ID               P_CPEID;
   char8	               conf_buf[MAX_DATA_LEN], wep_key_prefix[MAX_FILELINE_LEN];
   int32	               count = 0, changed_count = 0, passed_index = -1, ret = IFX_SUCCESS, i;
   IFX_NAME_VALUE_PAIR  array_fvp[WLAN_WEP_CONFIG_PARAM_COUNT + 1], *array_changed_fvp = NULL;
   char                 *tmp, buf[12];

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");

   memset(conf_buf, 0x00, sizeof(conf_buf));
   memset(array_fvp, 0x00, sizeof(array_fvp));

   /*************** Prolog Block *********************/
   /* Based on operation (ADD or DELETE or MODIFY)
    * append the flag with internal flags */
   if (operation == IFX_OP_DEL)
      flags |= IFX_F_DELETE;
   else if (operation == IFX_OP_ADD)
   {
      if( (IFX_MODIFY_F_NOT_SET(flags)))
         flags |= IFX_F_INT_ADD;
   }
   else
      flags |= IFX_F_MODIFY;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
   /**************** Validation Block *****************/
   /* For Operations other than DELETE do the verification of input params */
   if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
      /* Do simple validation of pointer such as NULL */
      IFX_VALIDATE_PTR(wlWepKey)
      /* Do simple validation of flags sucha as less than 0 */
      IFX_VALIDATE_FLAGS(flags)
   }

   sprintf(wlWepKey->iid.cpeId.secName, "%s", TAG_WLAN_WEP);
   sprintf(wlWepKey->iid.pcpeId.secName, "%s", TAG_WLAN_SEC);

   /**************** ID Allocation Block - Only for ADD Operation **************/
   if (IFX_ADD_F_SET(flags))
   {
      if(ifx_get_IID(&wlWepKey->iid, "key") != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
         ret = IFX_FAILURE;
         goto IFX_Handler;
      }

      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "tr69Id: %s", wlWepKey->iid.tr69Id);
      /* workaround for changing the tr69id */
      tmp = NULL;
      tmp = strrchr(wlWepKey->iid.tr69Id,'.');
      if(tmp)
         *tmp='\0';

      tmp = strrchr(wlWepKey->iid.tr69Id,'.');
      if(tmp!=NULL)
      {
         sprintf(buf,"%d.",wepKeyIndex+1);
         strcpy(tmp+1,buf);
      }
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "tr69Id: %s", wlWepKey->iid.tr69Id);
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
   /**************** Name Value Formation as per RC.CONF ********************/
   /* Form the FVP from the given structure for ADD/MODIFY
    * Operations
    */

   sprintf(wep_key_prefix, "%s%d", PREFIX_WLAN_WEP, wlWepKey->iid.pcpeId.Id);

   count = 0;
   if(IFX_DELETE_F_NOT_SET(flags)) {
      ifx_fill_ArrayFvp_FName(array_fvp, count, WLAN_WEP_CONFIG_PARAM_COUNT, wlan_wep_config_params);

      sprintf(array_fvp[0].value, "%d", wlWepKey->iid.cpeId.Id);
      sprintf(array_fvp[1].value, "%d", wlWepKey->iid.pcpeId.Id);
      sprintf(array_fvp[2].value, "%s", wlWepKey->wepKey);

      passed_index = -1;
   }

   count = WLAN_WEP_CONFIG_PARAM_COUNT;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
   /* Get Config Index in case of modify operation from CPEID */
   if((IFX_MODIFY_F_SET(flags))) {
      IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlWepKey->iid.cpeId, passed_index)
   }

   /*
      in case of add operation first assign wlan_sec->wepKeyIndex to passed_index
      and then call the function, so that it does not try to get the new index
      from section count
   */

   if(IFX_INT_ADD_F_SET(flags) || (IFX_DELETE_F_SET(flags)))
      passed_index = wepKeyIndex;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "passed_index: %d", passed_index);
   /*
      Determine the configuration index - for Add, Delete, Modify operations
      \note - Name is partial since index is not known
            - Fill array_fvp[]
   */
   if(ifx_get_conf_index_and_nv_pairs(&wlWepKey->iid, passed_index, wep_key_prefix,
            count, array_fvp, flags) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif /* #ifdef IFX_LOG_DEBUG */
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
         ret = IFX_FAILURE;
         goto IFX_Handler;
   }

   /************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
   if(IFX_ADD_F_NOT_SET(flags) && IFX_INT_DONT_CHECK_ACL_F_NOT_SET(flags))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "config_owner: %d, cpeId: %d, pcpeId: %d", wlWepKey->iid.config_owner, wlWepKey->iid.cpeId.Id, wlWepKey->iid.pcpeId.Id);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "cpeId.secName: %s, pcpeId.secName: %s", wlWepKey->iid.cpeId.secName, wlWepKey->iid.pcpeId.secName);
      CHECK_ACL_RET(wlWepKey->iid, count, array_fvp,
                  changed_count, array_changed_fvp, flags, IFX_Handler)
   }

   for (i = 0; i < WLAN_WEP_CONFIG_PARAM_COUNT; i++)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "name: %s, value: %s",
                     array_fvp[i].fieldname, array_fvp[i].value);
   /*
      before updating the config file:
      stop the AP/VAP in case of delete operation only
   */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags) &&
      IFX_DELETE_F_SET(flags))
   {
      /* use the parent cpeid to get index of the parent instance */
      P_CPEID.Id = wlWepKey->iid.pcpeId.Id;
      sprintf(P_CPEID.secName, "%s", TAG_WLAN_MAIN);
      IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, P_CPEID, passed_index)
      sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, passed_index);
      system(conf_buf);
   }

   /************** System Config File Update Block ****************/
   /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
   ret = form_cfgdb_buf(conf_buf, count, array_fvp);
   if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
      goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "conf_buf: %s", conf_buf);

   /* RC.CONF Configuration block */
   ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_WEP, flags, 1, conf_buf);
   if(ret != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
      goto IFX_Handler;
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");

   /**************** Device Configuration Block *********************/
   /*
      Device config thru Scripts/Utilities or Functions
      after config file update, for modify operation start script for applying
      the changes
   */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags))
   {
      if (operation == IFX_OP_MOD)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
         sprintf(conf_buf, "%s %d &", SERVICE_WLAN_SEC_MODIFY, passed_index);
         system(conf_buf);
      }
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");

   /* this will Compact the section and also update the count for both ADD and DELETE */
   if(IFX_MODIFY_F_NOT_SET(flags))
   {
      ret = ifx_UpdateCountInSection(FILE_RC_CONF, TAG_WLAN_WEP, flags);
      if(ret != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "ret: %d", ret);
         goto IFX_Handler;
      }
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
   }
   /*********** Notification Block *************/
   /* Notify the Internal TR69 Stack in case of MODIFY */

   /*********** Epilog Block **************/
   /* Update the IID mappings in the mappings section for ADD/DELETE */
   if(IFX_MODIFY_F_SET(flags))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
      CHECK_N_SEND_NOTIFICATION(wlWepKey->iid, changed_count, array_changed_fvp, flags, IFX_Handler)
   }
   else if (IFX_INT_ADD_F_SET(flags))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
      /* In case of ADD operation, first update the ID Mappings
       * and then send the Notification for the attributes
       */
      /*********** Epilog Block **************/
      UPDATE_ID_MAP_N_ATTRIBUTES(&wlWepKey->iid, count, array_fvp, flags, IFX_Handler)

      if (IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(flags))
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
         CHECK_N_SEND_NOTIFICATION(wlWepKey->iid, count, array_fvp, flags, IFX_Handler)
      }

      /* Manipulate nextCpeId only for ADD operations */
      ret = ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_WEP);
      if(ret != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "ret: %d", ret);
         goto IFX_Handler;
      }
   }
   else if (IFX_DELETE_F_SET(flags))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
      /* In case of DELETE operation, first send the notificatioupdate the ID Mappings
       * and then send the Notification for the attributes
       */
      /*********** Epilog Block **************/
      if (IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(flags))
      {
         CHECK_N_SEND_NOTIFICATION(wlWepKey->iid, count, array_fvp, flags, IFX_Handler)
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "ret: %d", ret);
      }

      UPDATE_ID_MAP_N_ATTRIBUTES(&wlWepKey->iid, count, array_fvp, flags, IFX_Handler)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "ret: %d", ret);
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "");
   /* Updating Persistent Storage */
   ret = ifx_config_write(FILE_RC_CONF, flags);
   if(ret != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "ret: %d", ret);
      goto IFX_Handler;
   }

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepKey", "ret: %d", ret);
   IFX_MEM_FREE(array_changed_fvp);
   if(ret != IFX_SUCCESS) {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return ret;
   }
   else
      return IFX_SUCCESS;
}

/**
   This API configures a set of WLAN WEP keys for a given AP/VAP.

   \param   operation   - type of operation (ADD, MODIFY, DELETE)

   \param   wlWepCfg    - pointer to IFX_MAPI_WLAN_WEP_Cfg structure

   \param   flags       - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks this api can only be called for modify operation
*/
int32 ifx_mapi_set_wlan_wep_config(uint32 oper, IFX_MAPI_WLAN_WEP_Cfg *wlWepCfg, uint32 flags)
{
   CPE_ID                  parentCpeId;
   char8	                  conf_buf[MAX_DATA_LEN];
   int32	                  passed_index = -1, ret = IFX_SUCCESS, i;
   IFX_MAPI_WLAN_WEP_Key   wlWepKey;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepConfig", "flags: 0x%x", flags);

   memset(conf_buf, 0x00, sizeof(conf_buf));
   memset(&wlWepKey, 0, sizeof(IFX_MAPI_WLAN_WEP_Key));

   /*************** Prolog Block *********************/
   /* Based on operation (ADD or DELETE or MODIFY)
    * append the flag with internal flags */
   if ((oper == IFX_OP_ADD) || (oper == IFX_OP_DEL))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepConfig", "");
      ret = IFX_FAILURE;
      goto IFX_Handler;
   }

   /**************** Validation Block *****************/
   if(IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
      /* Do simple validation of pointer such as NULL */
      IFX_VALIDATE_PTR(wlWepCfg)
      /* Do simple validation of flags such as less than 0 */
      IFX_VALIDATE_FLAGS(flags)
   }

   sprintf(wlWepKey.iid.cpeId.secName, "%s", TAG_WLAN_WEP);
   sprintf(wlWepKey.iid.pcpeId.secName, "%s", TAG_WLAN_SEC);

   for(i = 0; i < IFX_MAPI_NUM_WEP_KEYS; i++)
   {
      wlWepKey.iid.cpeId.Id      = wlWepCfg->wepKey[i].iid.cpeId.Id;
      wlWepKey.iid.pcpeId.Id     = wlWepCfg->wepKey[i].iid.pcpeId.Id;
      wlWepKey.iid.config_owner  = wlWepCfg->wepKey[i].iid.config_owner;
      strncpy(wlWepKey.wepKey, wlWepCfg->wepKey[i].wepKey, sizeof(wlWepCfg->wepKey[i].wepKey));
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepConfig", "wepKey: %s", wlWepKey.wepKey);

      if((ret = ifx_mapi_set_wlan_wep_key(oper, i, &wlWepKey, flags | IFX_F_INT_DONT_CONFIGURE | IFX_F_DONT_WRITE_TO_FLASH)) != IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepConfig", "ifx_mapi_set_wlan_wep_key has failed");
         goto IFX_Handler;
      }
   }

   /* use the parent cpeid to get index of the parent instance */
   parentCpeId.Id = wlWepKey.iid.pcpeId.Id;
   sprintf(parentCpeId.secName, "%s", TAG_WLAN_MAIN);
   IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, parentCpeId, passed_index)
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepConfig", "passed_index: %d", passed_index);

   if ((ret = mapiWlanSetWepInSecurity (oper, wlWepCfg, passed_index, flags)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepConfig", "ifx_mapi_set_wlan_wep_key has failed");
      goto IFX_Handler;
   }

   /* Device config thru Scripts/Utilities or Functions */
   /* after config file update, for modify or add operation start all ap/vap */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepConfig", "");
      sprintf(conf_buf, "%s %d", SERVICE_WLAN_SEC_MODIFY, passed_index);
      system(conf_buf);
   }

   /* before config file update, for modify or delete operation stop all ap/vap */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags))
   {
      sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, passed_index);
      system(conf_buf);
   }

   /*********** Device Configuration Block ****************/
   /* Device config thru Scripts/Utilities or Functions */
   /* after config file update, for modify or add operation start all ap/vap */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepConfig", "");
      sprintf(conf_buf, "%s %d", SERVICE_WLAN_START, passed_index);
      system(conf_buf);
   }

   /* Updating Persistent Storage */
   ret = ifx_config_write(FILE_RC_CONF, flags);
   if(ret != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepConfig", "ret: %d", ret);
      goto IFX_Handler;
   }

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepConfig", "ret: %d", ret);
   if(ret != IFX_SUCCESS) {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return ret;
   }
   else
      return IFX_SUCCESS;
}

/**
   This API configures the WLAN WEP parameters in the security objecet for given AP/VAP.

   \param   operation   - type of operation (ADD, MODIFY, DELETE)

   \param   wlWepCfg    - pointer to IFX_MAPI_WLAN_WEP_Cfg structure

   \param   passed_index - index of security object

   \param   flags       - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
static int32 mapiWlanSetWepInSecurity (uint32 operation,
             IFX_MAPI_WLAN_WEP_Cfg *wlWepCfg, int32 passed_index, uint32 flags)
{
   int32                ret = IFX_SUCCESS, count, i, changed_count = 0;
   char8	               buf[MAX_FILELINE_LEN], *sValue = NULL, conf_buf[MAX_DATA_LEN];
   IFX_NAME_VALUE_PAIR  array_fvp[WLAN_SEC_PARAM_COUNT], *array_changed_fvp = NULL;
   IFX_ID               wlSecId;

   IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanSetWepInSecurity", "passed_index: %d, flags: %d",
                  passed_index, flags);

   memset(&wlSecId, 0x00, sizeof(wlSecId));
   memset(array_fvp, 0x00, sizeof(array_fvp));

   wlSecId.cpeId.Id     = wlWepCfg->wepKey[0].iid.pcpeId.Id;
   wlSecId.config_owner = wlWepCfg->wepKey[0].iid.config_owner;
   sprintf(wlSecId.cpeId.secName, "%s", TAG_WLAN_SEC);
   sprintf(wlSecId.pcpeId.secName, "%s", TAG_LAN_DEVICE);

   /*************** Prolog Block *********************/
   /* Based on operation (ADD or DELETE or MODIFY)
    * append the flag with internal flags */
   if (operation != IFX_OP_MOD)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanSetWepInSecurity", "only modify operation");
      ret = IFX_FAILURE;
      goto IFX_Handler;
   }

   /**************** Validation Block *****************/


   sprintf(buf, "%s_%d_", PREFIX_WLAN_SEC, passed_index);
   if((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_SEC, buf, IFX_F_DEFAULT,
                              &sValue)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanSetWepInSecurity", "buf: %s", buf);
      goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanSetWepInSecurity",
                      "buf: %s, passed_index: %d, sValue: %s",
                      buf, passed_index, sValue);

   /* form an array of field value pairs for easier access to parameters */
   memset(array_fvp, 0x00, sizeof(array_fvp));
   form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);

   sprintf(array_fvp[11].value, "%d", wlWepCfg->wepEncrLevel);
   sprintf(array_fvp[12].value, "%d", wlWepCfg->wepKeyType);
   sprintf(array_fvp[13].value, "%d", wlWepCfg->wepKeyIndex);
   for (i = 0; i < count; i++)
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanSetWepInSecurity", "%s:%s",
                         array_fvp[i].fieldname, array_fvp[i].value);

   /************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
   if(IFX_INT_DONT_CHECK_ACL_F_NOT_SET(flags))
   {
      CHECK_ACL_RET(wlSecId, count, array_fvp,
                    changed_count, array_changed_fvp, flags, IFX_Handler)
   }

   /************** System Config File Update Block ****************/
   /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
   ret = form_cfgdb_buf(conf_buf, count, array_fvp);
   if(ret != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanSetWepInSecurity", "");
      goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanSetWepInSecurity", "conf_buf: %s", conf_buf);
   /* RC.CONF Configuration block */
   if ((ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_SEC, flags, 1, conf_buf)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanSetWepInSecurity", "");
      goto IFX_Handler;
   }

   /*********** Device Configuration Block ****************/
   /* Device config thru Scripts/Utilities or Functions */
   /* after config file update, for modify or add operation start all ap/vap */

   /*********** Notification Block *************/
   /* Notify the Internal TR69 Stack in case of MODIFY */

   /*********** Epilog Block **************/
   CHECK_N_SEND_NOTIFICATION(wlSecId, changed_count, array_changed_fvp, flags, IFX_Handler)

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/mapiWlanSetWepInSecurity", "ret: %d", ret);
   IFX_MEM_FREE(array_changed_fvp);
   IFX_MEM_FREE(sValue);
   return ret;
}

/**
   This API configures the WLAN PSK parameters for given AP/VAP.

   \param   operation   - type of operation (ADD, MODIFY, DELETE)

   \param   wlPsk       - pointer to IFX_MAPI_WLAN_PSKey structure

   \param   flags       - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks - this api is a little different from the usual set apis. in that
               the format it stores in rc.conf is prefix{pcpeid}_0_param which
               is against conventional prefix_0_param.
            - for passphrase key value can be either decimal or hex, so we need
               to introduce field in struct which says the key type in which the
               key is input
*/
static int32 mapiWlanSetPersonalConfig(uint32 operation, IFX_MAPI_WLAN_PSKey *wlPsk, uint32 flags)
{
   CPE_ID               P_CPEID;
   char8	               conf_buf[MAX_DATA_LEN], psk_prefix[MAX_FILELINE_LEN];
   int32	               count = 0, changed_count = 0, passed_index = -1;
   int32                ret = IFX_SUCCESS, i;
   IFX_NAME_VALUE_PAIR  array_fvp[WLAN_PSK_PARAM_COUNT], *array_changed_fvp = NULL;
   char                 *tmp, buf[]="1.";

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");

   memset(&P_CPEID, 0x00, sizeof(P_CPEID));
   memset(array_fvp, 0x00, sizeof(array_fvp));

   /*************** Prolog Block *********************/
   /* Based on operation (ADD or DELETE or MODIFY)
    * append the flag with internal flags */
   if (operation == IFX_OP_DEL)
      flags |= IFX_F_DELETE;
   else if (operation == IFX_OP_ADD) {
      if( (IFX_MODIFY_F_NOT_SET(flags)))
         flags |= IFX_F_INT_ADD;
   }
   else
      flags |= IFX_F_MODIFY;

   sprintf(wlPsk->iid.cpeId.secName, "%s", TAG_WLAN_PASSPHRASE);
   sprintf(wlPsk->iid.pcpeId.secName, "%s", TAG_WLAN_SEC);


   /**************** Validation Block *****************/
   /* For Operations other than DELETE do the verification of input params */
   if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
      /* Do simple validation of pointer such as NULL */
      IFX_VALIDATE_PTR(wlPsk)
      /* Do simple validation of flags sucha as less than 0 */
      IFX_VALIDATE_FLAGS(flags)
      /* Validate key type for ascii value */
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
   /**************** ID Allocation Block - Only for ADD Operation **************/
   if (IFX_ADD_F_SET(flags))
   {
      /*
         get the next cpe id for the section wlPsk from the next_cpe_id
         section in rc.conf and store it as cpeId; the distinct parameter
         passPhrase is provided for TR69
      */
      if(ifx_get_IID(&wlPsk->iid, "passPhrase") != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
         ret = IFX_FAILURE;
         goto IFX_Handler;
      }
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "tr69Id: %s",
                     wlPsk->iid.tr69Id);
      /* workaround for changing the tr69id as 1 for all psk objects */
      tmp = NULL;
      tmp = strrchr(wlPsk->iid.tr69Id,'.');
      if(tmp)
         *tmp='\0';

      tmp = strrchr(wlPsk->iid.tr69Id,'.');
      if(tmp!=NULL)
	      strcpy(tmp+1,buf);

      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "tr69Id: %s",
                     wlPsk->iid.tr69Id);
    }

   /**************** Name Value Formation as per RC.CONF ********************/
   /* Form the FVP from the given structure for ADD/MODIFY
    * Operations
    */

   /*
      the format for wlPsk object is wlPsk<pCpeId>_<Index>_param
      for this purpose we are defining the used prefix wlPsk<pCpeId> here
   */
   sprintf(psk_prefix, "%s%d", PREFIX_WLAN_PASSPHRASE, wlPsk->iid.pcpeId.Id);

   count = 0;
   if(IFX_DELETE_F_NOT_SET(flags))
   {
      ifx_fill_ArrayFvp_FName(array_fvp, count, WLAN_PSK_PARAM_COUNT, wlan_psk_params);
      sprintf(array_fvp[0].value, "%d", wlPsk->iid.cpeId.Id);
      sprintf(array_fvp[1].value, "%d", wlPsk->iid.pcpeId.Id);

      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "passPhrase: %s, psk: %s",
                     wlPsk->passPhrase, wlPsk->preSharedKey);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "passPhraseLength: %d, pskLength: %d",
                     strlen(wlPsk->passPhrase), strlen(wlPsk->preSharedKey));

      if (strlen(wlPsk->passPhrase) > 0)
      {
         sprintf(array_fvp[2].value, "%d", IFX_MAPI_WLAN_ASCII_KEY);
         sprintf(array_fvp[3].value, "%s", wlPsk->passPhrase);
         sprintf(array_fvp[4].value, "%s", "");
      }
      else if (strlen(wlPsk->preSharedKey) > 0)
      {
         sprintf(array_fvp[2].value, "%d", IFX_MAPI_WLAN_HEX_KEY);
         sprintf(array_fvp[3].value, "%s", "");
         sprintf(array_fvp[4].value, "%s", wlPsk->preSharedKey);
      }
      else
      {
         sprintf(array_fvp[2].value, "%d", IFX_MAPI_WLAN_HEX_KEY);
         sprintf(array_fvp[3].value, "%s", "");
         sprintf(array_fvp[4].value, "%s", "");
      }

      for (i = 0; i < WLAN_PSK_PARAM_COUNT; i++)
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "fvp_field: %s, fvp_value:%s",
                        array_fvp[i].fieldname, array_fvp[i].value);

      passed_index = -1;
   }

   count = WLAN_PSK_PARAM_COUNT;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");

   /*
      configuration index = 0 for all instances - for Add, Delete, Modify
      operations; instead pcpeId is appended in prefix name; example:
      wlpsk<pcpeId>_0_param
   */
   passed_index = 0;
   if(ifx_get_conf_index_and_nv_pairs(&wlPsk->iid, passed_index, psk_prefix,
            count, array_fvp, flags) != IFX_SUCCESS)
   {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
         ret = IFX_FAILURE;
         goto IFX_Handler;
   }
   for (i = 0; i < WLAN_PSK_PARAM_COUNT; i++)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "fvp_field: %s, fvp_value:%s",
                     array_fvp[i].fieldname, array_fvp[i].value);

   /************* ACL Checking block - MUST for MODIFY/DELETE operations ***********/
   if(IFX_ADD_F_NOT_SET(flags) && IFX_INT_DONT_CHECK_ACL_F_NOT_SET(flags))
   {
      CHECK_ACL_RET(wlPsk->iid, count, array_fvp,
                  changed_count, array_changed_fvp, flags, IFX_Handler)
   }

   /*
      before updating the config file:
      stop the AP/VAP in case of delete operation only
   */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags) &&
      IFX_DELETE_F_SET(flags))
   {
      /* use the parent cpeid to get index of the parent instance */
      P_CPEID.Id = wlPsk->iid.pcpeId.Id;
      sprintf(P_CPEID.secName, "%s", TAG_WLAN_MAIN);
      IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, P_CPEID, passed_index)
      sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, passed_index); /* passed index should be that of wlan_main instance */
      system(conf_buf);
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
   /************** System Config File Update Block ****************/
   /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
   ret = form_cfgdb_buf(conf_buf, count, array_fvp);
   if(ret != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
      goto IFX_Handler;
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "conf_buf: %s", conf_buf);
   /* RC.CONF Configuration block */
   ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_PASSPHRASE, flags, 1, conf_buf);

   if(ret != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
      goto IFX_Handler;
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
   /*********** Device Configuration Block ****************/
   /* Device config thru Scripts/Utilities or Functions */
   /* after config file update, for modify or add operation start all ap/vap */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags))
   {
      if (operation == IFX_OP_ADD)
      {
         /* passed index should be that of wlan_main instance */
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
         sprintf(conf_buf, "%s %d", SERVICE_WLAN_START, passed_index);
         system(conf_buf);
      }
      else if(operation == IFX_OP_MOD)
      {
         /* passed index should be that of wlan_main instance */
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
         sprintf(conf_buf, "%s %d &", SERVICE_WLAN_SEC_MODIFY, passed_index);
         system(conf_buf);
      }
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
   /* this will update the count for both ADD and DELETE */
   if(IFX_MODIFY_F_NOT_SET(flags))
      ifx_UpdateCountInSection(FILE_RC_CONF, TAG_WLAN_PASSPHRASE, flags);

   /*********** Notification Block *************/
   /* Notify the Internal TR69 Stack in case of MODIFY */

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
   /*********** Epilog Block **************/
   /* Update the IID mappings in the mappings section for ADD/DELETE */
   if(IFX_MODIFY_F_SET(flags))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
      CHECK_N_SEND_NOTIFICATION(wlPsk->iid, changed_count, array_changed_fvp, flags, IFX_Handler)
   }
   else if (IFX_INT_ADD_F_SET(flags)) {
      /*********** Epilog Block **************/
      /*
         in case of ADD operation, first update the ID Mappings and then send
         the Notification for the attributes
      */
      UPDATE_ID_MAP_N_ATTRIBUTES(&wlPsk->iid, count, array_fvp, flags, IFX_Handler)

      if (IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(flags))
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
         CHECK_N_SEND_NOTIFICATION(wlPsk->iid, count, array_fvp, flags, IFX_Handler)
      }

      /* Manipulate nextCpeId only for ADD operations */
      ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_PASSPHRASE);

   }
   else if (IFX_DELETE_F_SET(flags)) {
      /* In case of DELETE operation, first send the notificatioupdate the ID Mappings
       * and then send the Notification for the attributes
       */
      /*********** Epilog Block **************/
      if (IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(flags))
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
         CHECK_N_SEND_NOTIFICATION(wlPsk->iid, count, array_fvp, flags, IFX_Handler)
      }
      UPDATE_ID_MAP_N_ATTRIBUTES(&wlPsk->iid, count, array_fvp, flags, IFX_Handler)
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
   /* Updating Persistent Storage */
   ret = ifx_config_write(FILE_RC_CONF, flags);
   if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "");
      goto IFX_Handler;
   }


IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphrase", "ret: %d", ret);
   IFX_MEM_FREE(array_changed_fvp);
   if(ret != IFX_SUCCESS) {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return ret;
   }
   else
      return IFX_SUCCESS;
}

/**
   This API is a wrapper function required for devm.
   Basically it simply calls mapiWlanSetPersonalConfig.

   \param   operation   - type of operation (ADD, MODIFY, DELETE)

   \param   wlPsk       - pointer to IFX_MAPI_WLAN_PSKey structure

   \param   flags       - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_set_wlan_passphrase_config(uint32 operation, IFX_MAPI_WLAN_PSKey *wlPsk, uint32 flags)
{
   CPE_ID               P_CPEID;
   char8	        conf_buf[MAX_DATA_LEN];
   int32	        passed_index = -1;
   int32                ret = IFX_SUCCESS;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphraseConfig", "");

   memset(&P_CPEID, 0x00, sizeof(P_CPEID));

   /*************** Prolog Block *********************/
   /* Based on operation (ADD or DELETE or MODIFY)
    * append the flag with internal flags */
   if ((operation== IFX_OP_ADD) || (operation == IFX_OP_DEL))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphraseConfig", "");
      ret = IFX_FAILURE;
      goto IFX_Handler;
   }

   sprintf(wlPsk->iid.cpeId.secName, "%s", TAG_WLAN_PASSPHRASE);
   sprintf(wlPsk->iid.pcpeId.secName, "%s", TAG_WLAN_SEC);

   /**************** Validation Block *****************/
   /* For Operations other than DELETE do the verification of input params */
   if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
      /* Do simple validation of pointer such as NULL */
      IFX_VALIDATE_PTR(wlPsk)
      /* Do simple validation of flags sucha as less than 0 */
      IFX_VALIDATE_FLAGS(flags)
      /* Validate key type for ascii value */
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphraseConfig", "");

   if((ret = mapiWlanSetPersonalConfig(operation, wlPsk, flags | IFX_F_INT_DONT_CONFIGURE | IFX_F_DONT_WRITE_TO_FLASH)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphraseConfig", "mapiWlanSetPersonalConfig has failed");
      goto IFX_Handler;
   }

  /* use the parent cpeid to get index of the parent instance */
   P_CPEID.Id = wlPsk->iid.pcpeId.Id;
   sprintf(P_CPEID.secName, "%s", TAG_WLAN_MAIN);
   IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, P_CPEID, passed_index)
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphraseConfig", "passed_index: %d", passed_index);

   /* Device config thru Scripts/Utilities or Functions */
   /* after config file update, for modify or add operation start all ap/vap */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphraseConfig", "");
      sprintf(conf_buf, "%s %d", SERVICE_WLAN_SEC_MODIFY, passed_index);
      system(conf_buf);
   }

   /* before config file update, for modify or delete operation stop all ap/vap */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags))
   {
      sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, passed_index);
      system(conf_buf);
   }

   /*********** Device Configuration Block ****************/
   /* Device config thru Scripts/Utilities or Functions */
   /* after config file update, for modify or add operation start all ap/vap */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphraseConfig", "");
      sprintf(conf_buf, "%s %d", SERVICE_WLAN_START, passed_index);
      system(conf_buf);
   }

   /* Updating Persistent Storage */
   ret = ifx_config_write(FILE_RC_CONF, flags);
   if(ret != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWepConfig", "ret: %d", ret);
      goto IFX_Handler;
   }

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanPassphraseConfig", "ret: %d", ret);
   if(ret != IFX_SUCCESS) {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return ret;
   }
   else
      return IFX_SUCCESS;
}

/**
   This API configures the WLAN 802.1X parameters for a given AP/VAP.

   \param   operation   - type of operation (ADD, MODIFY, DELETE)

   \param   wlRadius       - pointer to IFX_MAPI_WLAN_802_1x structure

   \param   flags       - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks the wlan_1x objects has not corresponding TR69 object, therefore
            no interaction with TR69 is required in this function
*/
int32 ifx_mapi_set_wlan_802_1x_config(uint32 operation, IFX_MAPI_WLAN_802_1x *wlRadius, uint32 flags)
{
   CPE_ID               pCpeId;
   char8	               conf_buf[MAX_DATA_LEN], radiusPrefix[MAX_FILELINE_LEN];
   int32	               count = 0, changed_count = 0, passed_index = -1;
   int32                ret = IFX_SUCCESS, i;
   IFX_NAME_VALUE_PAIR array_fvp[WLAN_802_1X_PARAM_COUNT], *array_changed_fvp = NULL;
   IFX_ID   parent_iid;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");

   memset(&pCpeId, 0x00, sizeof(CPE_ID));
   memset(array_fvp, 0x00, sizeof(array_fvp));
   memset(&parent_iid, 0, sizeof(parent_iid));

   /*
      *************** Prolog Block *******************
      Based on operation (ADD or DELETE or MODIFY)
      append the flag with internal flags
   */
   if (operation == IFX_OP_DEL)
      flags |= IFX_F_DELETE;
   else if (operation == IFX_OP_ADD)
   {
      if( (IFX_MODIFY_F_NOT_SET(flags)))
         flags |= IFX_F_INT_ADD;
   }
   else
      flags |= IFX_F_MODIFY;

   /*
      *************** Validation Block *****************
      For Operations other than DELETE do the verification of input params
   */
   if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags))
   {
      /* Do simple validation of pointer such as NULL */
      IFX_VALIDATE_PTR(wlRadius)
      /* Do simple validation of flags sucha as less than 0 */
      IFX_VALIDATE_FLAGS(flags)
      /* Validate key type for ascii value */
   }

   sprintf(wlRadius->iid.cpeId.secName, "%s", TAG_WLAN_1X);
   sprintf(wlRadius->iid.pcpeId.secName, "%s", TAG_WLAN_SEC);

   parent_iid.cpeId.Id = wlRadius->iid.pcpeId.Id;
   sprintf(parent_iid.cpeId.secName, "%s", wlRadius->iid.pcpeId.secName);


   /*
      *************** ID Allocation Block - Only for ADD Operation *************
   */
   if (IFX_ADD_F_SET(flags))
   {
      /*
			This function call gets the cpeId of parent_iid and copies it to pcpdId
         of wlRadius->iid.
      */
      if (ifx_get_iid(TAG_WLAN_1X, TAG_WLAN_SEC, &parent_iid,
				&wlRadius->iid) != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
         ret = IFX_FAILURE;
         goto IFX_Handler;
      }
   }

   /*
      *************** Name Value Formation as per RC.CONF ********************
      Form the FVP from the given structure for ADD/MODIFY
      Operations
   */
   sprintf(radiusPrefix, "%s", PREFIX_WLAN_SEC_1X);

   count = 0;
   if(IFX_DELETE_F_NOT_SET(flags))
   {
      ifx_fill_ArrayFvp_FName(array_fvp, count, WLAN_802_1X_PARAM_COUNT, wlan_802_1x_params);
      /*
         this function call is used to fill the array array_fvp with parameters
         of type integer;
         \note -  this function can only be used for successive parameters of
                  type integer; if one of the parameters is for example of type
                  string, then this function can only be used to fill in the
                  parameters up to the paramter of type string;
      */
      ifx_fill_ArrayFvp_intValues(
         array_fvp, 0, 2, (int32 *) &wlRadius->iid.cpeId.Id, &wlRadius->iid.pcpeId.Id);

      sprintf(array_fvp[2].value, "%d", wlRadius->groupKeyEna);
      sprintf(array_fvp[3].value, "%d", wlRadius->groupKeyIntvl);
      sprintf(array_fvp[4].value, "%d", wlRadius->wpa2PreAuthEna);
      sprintf(array_fvp[5].value, "%d", wlRadius->wpa2ReAuthIntvl);

      sprintf(array_fvp[7].value, "%d", wlRadius->authType);
      sprintf(array_fvp[8].value, "%d", wlRadius->authProto);

      sprintf(array_fvp[9].value, "%s", inet_ntoa(wlRadius->radiusServerIP));
      sprintf(array_fvp[10].value, "%d", wlRadius->radiusPort);
      sprintf(array_fvp[11].value, "%s", wlRadius->radiusServerSecret);
      sprintf(array_fvp[12].value, "%s", wlRadius->domainName);
      sprintf(array_fvp[13].value, "%s", wlRadius->userName);

      for (i = 0; i < WLAN_802_1X_PARAM_COUNT; i++)
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "name: %s, value: %s",
                        array_fvp[i].fieldname, array_fvp[i].value);
      passed_index = -1;
   }

   count = WLAN_802_1X_PARAM_COUNT;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
   /* Get Config Index in case of modify/delete operations from CPEID */
   if((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags)))
   {
      IFX_GET_INDEX_FROM_PCPEID(FILE_RC_CONF, wlRadius->iid.pcpeId, passed_index)
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
   /*
      Determine the configuration index - for Add, Delete, Modify operations
      Name is partial since index is not known
      Fill array_fvp[]
   */
   if(ifx_get_conf_index_and_nv_pairs(&wlRadius->iid, passed_index, radiusPrefix,
         count, array_fvp, flags) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
      ret = IFX_FAILURE;
      goto IFX_Handler;
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
   /*
      ********** ACL Checking block - MUST for MODIFY/DELETE operations *********
   */

   if(IFX_ADD_F_NOT_SET(flags) && IFX_INT_DONT_CHECK_ACL_F_NOT_SET(flags))
   {
      CHECK_ACL_RET(wlRadius->iid, count, array_fvp, changed_count,
                    array_changed_fvp, flags, IFX_Handler)
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");

   /* before config file update, for modify or delete operation stop all ap/vap */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags) &&
      (IFX_DELETE_F_SET(flags) || IFX_MODIFY_F_SET(flags)))
   {
      /* use the parent cpeid to get index of the parent instance */
      pCpeId.Id = wlRadius->iid.pcpeId.Id;
      sprintf(pCpeId.secName, "%s", TAG_WLAN_SEC);
      IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, pCpeId, passed_index)
      sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, passed_index); /* passed index should be that of wlan_main instance ??? */
      system(conf_buf);
   }

   /*
      ************* System Config File Update Block ****************
      Convert the name value pair in array_fvp into string format expected by
      rc.conf file
   */
   ret = form_cfgdb_buf(conf_buf, count, array_fvp);
   if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
      goto IFX_Handler;
   }

   /* RC.CONF Configuration block */
   ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_1X, flags, 1, conf_buf);
   if(ret != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
      goto IFX_Handler;
   }

   /*
      ********** Device Configuration Block ****************
      Device config thru Scripts/Utilities or Functions
      after config file update, for modify or add operation start all ap/vap
   */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags) &&
      (IFX_INT_ADD_F_SET(flags) || IFX_MODIFY_F_SET(flags)))
   {
      if (operation == IFX_OP_ADD)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
         /* passed index should be that of wlan_main instance */
         sprintf(conf_buf, "%s %d", SERVICE_WLAN_START, passed_index);
         system(conf_buf);
      }
      else if(operation == IFX_OP_MOD)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
         /* passed index should be that of wlan_main instance */
         sprintf(conf_buf, "%s %d &", SERVICE_WLAN_SEC_MODIFY, passed_index);
         system(conf_buf);
      }
   }

   /* this will Compact the section and also update the count for both ADD and DELETE */
   if(IFX_MODIFY_F_NOT_SET(flags))
      ifx_CompactCfgSection(FILE_RC_CONF, TAG_WLAN_1X, flags);

   /*
      ********* Notification Block *************
      Notify the Internal TR69 Stack in case of MODIFY
      \todo check here
   */

   /*
      ********** Epilog Block **************
      Update the IID mappings in the mappings section for ADD/DELETE
   */
   if(IFX_MODIFY_F_SET(flags))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
#if 0
      /* wlan_1x has no interaction with TR69 */
      if (IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(flags))
      {
         CHECK_N_SEND_NOTIFICATION(wlRadius->iid, changed_count, array_changed_fvp, flags, IFX_Handler)
      }
#endif /* #if 0 */
   }
   else if (IFX_INT_ADD_F_SET(flags))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
      /*
         In case of ADD operation, first update the ID Mappings
         and then send the Notification for the attributes
      */
#if 0
      /* wlan_1x has no interaction with TR69 */
      if (IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(flags))
      {
      	UPDATE_ID_MAP_N_ATTRIBUTES(&wlRadius->iid, count, array_fvp, flags, IFX_Handler)
         CHECK_N_SEND_NOTIFICATION(wlRadius->iid, count, array_fvp, flags, IFX_Handler)
      }
#endif /* #if 0 */
      /* Manipulate nextCpeId only for ADD operations */
      ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_1X);
   }
   else if (IFX_DELETE_F_SET(flags))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
#if 0
      /* wlan_1x has no interaction with TR69 */
      if (IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(flags))
      {
         /*
            in case of DELETE operation, first send the notification, then
            update the ID mappings
         */
         CHECK_N_SEND_NOTIFICATION(wlRadius->iid, count, array_fvp, flags, IFX_Handler)
      	UPDATE_ID_MAP_N_ATTRIBUTES(&wlRadius->iid, count, array_fvp, flags, IFX_Handler)
      }
#endif /* #if 0 */
   }

   /* Updating Persistent Storage */
   ret = ifx_config_write(FILE_RC_CONF, flags);
   if(ret != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif /* #ifdef IFX_LOG_DEBUG */
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "");
      goto IFX_Handler;
   }

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlan8021xConfig", "ret: %d", ret);
   IFX_MEM_FREE(array_changed_fvp);
   if(ret != IFX_SUCCESS)
   {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return ret;
   }
   else
      return IFX_SUCCESS;
}

/**
   This API configures the WLAN security parameters for given AP/VAP
   specified by CpeId

   \param   oper  - type of operation (ADD, MODIFY, DELETE)

   \param   wlSec - pointer to IFX_MAPI_WLAN_SecCfg structure

   \param   flags - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks - irrespective of protocol to be used, each instance should be added/deleted/modified in wep and passphrase
            - should have same cpeid and pcpeid as the wlan_main instance
            - wireless start script checks if both phy-radio and this ap/vap is enabled, then only starts the service
*/
int32 ifx_mapi_set_wlan_security_config(uint32 oper, IFX_MAPI_WLAN_SecCfg *wlSec, uint32 flags)
{
   char8	               conf_buf[MAX_DATA_LEN];
   int32	               count = 0, changed_count = 0, passed_index = -1;
   int32                ret = IFX_SUCCESS, i = 0;
   IFX_NAME_VALUE_PAIR  array_fvp[WLAN_SEC_PARAM_COUNT + 1], *array_changed_fvp = NULL;
	/*
   struct timeval tv;

   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
	*/

   /*
      *************** Prolog Block *******************
      Based on operation (ADD or DELETE or MODIFY)
      append the flag with internal flags
   */
   if (oper == IFX_OP_DEL)
      flags |= IFX_F_DELETE;
   else if (oper == IFX_OP_ADD) {
      if( (IFX_MODIFY_F_NOT_SET(flags)))
         flags |= IFX_F_INT_ADD;
   }
   else
      flags |= IFX_F_MODIFY;

   sprintf(wlSec->iid.cpeId.secName, "%s", TAG_WLAN_SEC); /* Pramod - TAG_WLAN_SEC or TAG_WLAN_MAIN */
   sprintf(wlSec->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE); /* Pramod - who is the parent here */

   if (IFX_DELETE_F_SET(flags))
   {
      /**
         on a delete operation for the wlan security object, first all child
         objects have to be deleted
      */
      if ( (ret = mapiWlanPersonalConfig(oper, wlSec)) != IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "mapiWlanPersonalConfig has failed");
         goto IFX_Handler;
      }
      if ( (ret = mapiWlan8021XConfig(oper, wlSec)) != IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "mapiWlan8021XConfig has failed");
         goto IFX_Handler;
      }
      if ( (ret = mapiWlanWepConfig(oper, wlSec)) != IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "mapiWlanWepConfig has failed");
         goto IFX_Handler;
      }
   }

   /*
      *************** Validation Block ***************
      For Operations other than DELETE do the verification of input params
   */
   if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags))
   {
      /* Do simple validation of pointer such as NULL */
      IFX_VALIDATE_PTR(wlSec)
      /* Do simple validation of flags sucha as less than 0 */
      IFX_VALIDATE_FLAGS(flags)
   }

   /*
      Get the configuration index in case of modify/delete operations from CPEID
      \note -  CPEID must be filled by calling function
   */
   if ( (IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags)) )
   {
      IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlSec->iid.cpeId, passed_index)
   }

   /*
      Name Value Formation as per RC.CONF
      \note - form the FVP from the given structure for ADD/MODIFY operations
   */
   count = 0;
   if(IFX_DELETE_F_NOT_SET(flags))
   {
      IFX_MAPI_WLAN_WEP_Cfg   wlWepCfg;
      int32                   j;

   	memset(&wlWepCfg, 0x00, sizeof(IFX_MAPI_WLAN_WEP_Cfg));
      for (j = 0; j < IFX_MAPI_NUM_WEP_KEYS; j++)
         wlWepCfg.wepKey[j].iid.pcpeId.Id = wlSec->iid.cpeId.Id;

      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
      if(IFX_INT_ADD_F_NOT_SET(flags))
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
         /* some wep parameters are stored in wlan security objecct in rc.conf */
		   if ((ret = ifx_mapi_get_wlan_wep_config(&wlWepCfg, IFX_F_DEFAULT)) != IFX_SUCCESS)
         {
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
            goto IFX_Handler;
         }
      }

#if 0
      /*
         array_fvp is an array holding parameters of IFX_NAME_VALUE_PAIR type;
         here the fieldnames of wlan security parameters are filled in the array
      */
      ifx_fill_ArrayFvp_FName(array_fvp, 0, WLAN_SEC_PARAM_COUNT, wlan_sec_params);
#endif /* #if 0 */

      /* initialize array */
      memset(array_fvp, 0x00, sizeof(array_fvp));
      /* based on beacon type get authentication and encryption mode from respective fields */
      if(wlSec->beaconType == IFX_MAPI_WLAN_BEACON_BASIC)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
         /* set auth type */
         wlSec->basicAuth = wlSec->wlAuth;
         /* set encrypt type */
         wlSec->basicEncr = wlSec->wlEncr;

         if(IFX_INT_ADD_F_NOT_SET(flags))
         {
            /* if encryption is WEP take values stored in wlSec */
            if (wlSec->wlEncr == IFX_MAPI_WLAN_ENCR_WEP)
            {
               IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
               wlWepCfg.wepEncrLevel = wlSec->secParams.wepCfg.wepEncrLevel;
               wlWepCfg.wepKeyType = wlSec->secParams.wepCfg.wepKeyType;
               wlWepCfg.wepKeyIndex = wlSec->secParams.wepCfg.wepKeyIndex;
            }
         }
         else
         {
            wlWepCfg.wepEncrLevel   = IFX_MAPI_WEP_ENCR_LVL_128BIT;
            wlWepCfg.wepKeyType     = IFX_MAPI_WLAN_HEX_KEY;
            wlWepCfg.wepKeyIndex    = IFX_MAPI_WEP_KEY_INDX_1;
         }
      }
      else if (wlSec->beaconType == IFX_MAPI_WLAN_BEACON_WPA)
      {
         if (wlSec->iid.config_owner == IFX_WEB)
         {
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
            /* set auth type */
            wlSec->wpaAuth = wlSec->wlAuth;
            /* set encrypt type */
            wlSec->wpaEncr = wlSec->wlEncr;
         }
         else
         {
            /*
               check if authentication and encryption type are valid in wlSec
               if not: take values for wpaAuthType/wpaEncrType from rc.conf
            */
            if (((wlSec->wlAuth == IFX_MAPI_WLAN_AUTH_RADIUS)     ||
                 (wlSec->wlAuth == IFX_MAPI_WLAN_AUTH_PERSONAL))  &&
                ((wlSec->wlEncr == IFX_MAPI_WLAN_ENCR_TKIP)       ||
                 (wlSec->wlEncr == IFX_MAPI_WLAN_ENCR_CCMP)       ||
                 (wlSec->wlEncr == IFX_MAPI_WLAN_ENCR_TKIP_CCMP)))
            {
               IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
               /* set auth type */
               wlSec->wpaAuth = wlSec->wlAuth;
               /* set encrypt type */
               wlSec->wpaEncr = wlSec->wlEncr;
            }
            else
            {
               IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
               if ((ret = mapiWlanGetObjectFromRcConf(wlSec->iid, array_fvp)) != IFX_SUCCESS)
               {
                  IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
                  goto IFX_Handler;
               }

               /* get value for authentication and encryption from rc.conf */
               wlSec->wpaAuth          = atoi(array_fvp[7].value);
               wlSec->wpaEncr          = atoi(array_fvp[8].value);
               /* store values for authentication and encryption also in general param */
               wlSec->wlAuth           = wlSec->wpaAuth;
               wlSec->wlEncr           = wlSec->wpaEncr;
               /* get the remaining values from rc.conf, so they do not get lost */
               wlSec->basicAuth        = atoi(array_fvp[5].value);
               wlSec->basicEncr        = atoi(array_fvp[6].value);
               wlSec->wpa2Auth         = atoi(array_fvp[9].value);
               wlSec->wpa2Encr         = atoi(array_fvp[10].value);
               wlSec->macAddrCntrlEna  = atoi(array_fvp[14].value);
            }
         }
      }
      else if (wlSec->beaconType == IFX_MAPI_WLAN_BEACON_WPA2)
      {
         if (wlSec->iid.config_owner == IFX_WEB)
         {
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
            /* set auth type */
            wlSec->wpa2Auth = wlSec->wlAuth;
            /* set encrypt type */
            wlSec->wpa2Encr = wlSec->wlEncr;
         }
         else
         {
            /*
               check if authentication and encryption type are valid in wlSec
               if not: take values for wpaAuthType/wpaEncrType from rc.conf
            */
            if (((wlSec->wlAuth == IFX_MAPI_WLAN_AUTH_RADIUS) ||
                 (wlSec->wlAuth == IFX_MAPI_WLAN_AUTH_PERSONAL)) &&
                 ((wlSec->wlEncr == IFX_MAPI_WLAN_ENCR_TKIP) ||
                 (wlSec->wlEncr == IFX_MAPI_WLAN_ENCR_CCMP)  ||
                 (wlSec->wlEncr == IFX_MAPI_WLAN_ENCR_TKIP_CCMP)))
            {
               IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
               /* set auth type */
               wlSec->wpa2Auth = wlSec->wlAuth;
               /* set encrypt type */
               wlSec->wpa2Encr = wlSec->wlEncr;
            }
            else
            {
               IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
               if ((ret = mapiWlanGetObjectFromRcConf(wlSec->iid, array_fvp)) != IFX_SUCCESS)
               {
                  IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
                  goto IFX_Handler;
               }
               /* get value for authentication and encryption from rc.conf */
               wlSec->wpa2Auth         = atoi(array_fvp[9].value);
               wlSec->wpa2Encr         = atoi(array_fvp[10].value);
               /* store values for authentication and encryption also in general param */
               wlSec->wlAuth           = wlSec->wpa2Auth;
               wlSec->wlEncr           = wlSec->wpa2Encr;
               /* get the remaining values from rc.conf, so they do not get lost */
               wlSec->basicAuth        = atoi(array_fvp[5].value);
               wlSec->basicEncr        = atoi(array_fvp[6].value);
               wlSec->wpaAuth          = atoi(array_fvp[7].value);
               wlSec->wpaEncr          = atoi(array_fvp[8].value);
               wlSec->macAddrCntrlEna  = atoi(array_fvp[14].value);
            }
         }
      }
      else if (wlSec->beaconType == IFX_MAPI_WLAN_BEACON_WPA_WPA2)
      {
         if (wlSec->iid.config_owner == IFX_WEB)
         {
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
            /* set auth type */
            wlSec->wpaAuth = wlSec->wlAuth;
            /* set encrypt type */
            wlSec->wpaEncr = wlSec->wlEncr;
            /* set auth type */
            wlSec->wpa2Auth = wlSec->wlAuth;
            /* set encrypt type */
            wlSec->wpa2Encr = wlSec->wlEncr;
         }
         else
         {
            /*
               check if authentication and encryption type are valid in wlSec
               if not: take values for wpaAuthType/wpaEncrType from rc.conf
            */
            if (((wlSec->wlAuth == IFX_MAPI_WLAN_AUTH_RADIUS) ||
                 (wlSec->wlAuth == IFX_MAPI_WLAN_AUTH_PERSONAL)) &&
                 ((wlSec->wlEncr == IFX_MAPI_WLAN_ENCR_TKIP) ||
                 (wlSec->wlEncr == IFX_MAPI_WLAN_ENCR_CCMP)  ||
                 (wlSec->wlEncr == IFX_MAPI_WLAN_ENCR_TKIP_CCMP)))
            {
               IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
               /* set auth type */
               wlSec->wpaAuth = wlSec->wlAuth;
               /* set encrypt type */
               wlSec->wpaEncr = wlSec->wlEncr;
               /* set auth type */
               wlSec->wpa2Auth = wlSec->wlAuth;
               /* set encrypt type */
               wlSec->wpa2Encr = wlSec->wlEncr;
            }
            else
            {
               IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
               if ((ret = mapiWlanGetObjectFromRcConf(wlSec->iid, array_fvp)) != IFX_SUCCESS)
               {
                  IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
                  goto IFX_Handler;
               }
               /* get value for authentication and encryption from rc.conf */
               wlSec->wpaAuth          = atoi(array_fvp[7].value);
               wlSec->wpaEncr          = atoi(array_fvp[8].value);
               wlSec->wpa2Auth         = atoi(array_fvp[9].value);
               wlSec->wpa2Encr         = atoi(array_fvp[10].value);
               /* store values for authentication and encryption also in general param */
               wlSec->wlAuth           = wlSec->wpaAuth;
               wlSec->wlEncr           = wlSec->wpaEncr;
               /* get the remaining values from rc.conf, so they do not get lost */
               wlSec->basicAuth        = atoi(array_fvp[5].value);
               wlSec->basicEncr        = atoi(array_fvp[6].value);
               wlSec->macAddrCntrlEna  = atoi(array_fvp[14].value);
            }
         }
      }

      /* initialize array */
      memset(array_fvp, 0x00, sizeof(array_fvp));
      /*
         array_fvp is an array holding parameters of IFX_NAME_VALUE_PAIR type;
         here the fieldnames of wlan security parameters are filled in the array
      */
      ifx_fill_ArrayFvp_FName(array_fvp, 0, WLAN_SEC_PARAM_COUNT, wlan_sec_params);
      /*
         this function call is used to fill the array array_fvp with parameters
         of type integer;
         \note -  this function can only be used for successive parameters of
                  type integer; if one of the parameters is for example of type
                  string, then this function can only be used to fill in the
                  parameters up to the paramter of type string;
      */
      ifx_fill_ArrayFvp_intValues(
         array_fvp, 0, WLAN_SEC_PARAM_COUNT, (int32 *) &wlSec->iid.cpeId.Id,
         &wlSec->iid.pcpeId.Id, &wlSec->beaconType, &wlSec->wlAuth,
         &wlSec->wlEncr, &wlSec->basicAuth, &wlSec->basicEncr, &wlSec->wpaAuth,
         &wlSec->wpaEncr, &wlSec->wpa2Auth, &wlSec->wpa2Encr,
         &wlWepCfg.wepEncrLevel, &wlWepCfg.wepKeyType, &wlWepCfg.wepKeyIndex,
         &wlSec->macAddrCntrlEna);

      for (i = 0; i < WLAN_SEC_PARAM_COUNT; i++)
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
                            "name: %s, value: %s",
                            array_fvp[i].fieldname, array_fvp[i].value);
   }

   count = WLAN_SEC_PARAM_COUNT;

   /*
      Determine the configuration index and the fully qualified field value
      pairs in array_fvp
      \note - for Add, Delete, Modify operations
   */
   if(ifx_get_conf_index_and_nv_pairs(&wlSec->iid, passed_index, PREFIX_WLAN_SEC,
            count, array_fvp, flags) != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif /* #ifdef IFX_LOG_DEBUG */
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
         ret = IFX_FAILURE;
         goto IFX_Handler;
   }

   for (i = 0; i < WLAN_SEC_PARAM_COUNT; i++)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
                         "name: %s, value: %s",
                         array_fvp[i].fieldname, array_fvp[i].value);

   /*
      ACL (access control) checking block - MUST for MODIFY/DELETE operations
   */
   if(IFX_ADD_F_NOT_SET(flags) && IFX_INT_DONT_CHECK_ACL_F_NOT_SET(flags))
   {
      CHECK_ACL_RET(wlSec->iid, count, array_fvp,
                  changed_count, array_changed_fvp, flags, IFX_Handler)
   }

   /* stop this ap/vap before calling apis below */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags))
   {
      /* only stop the ap on delete operation */
      if (oper == IFX_OP_DEL)
      {
         /* both wlan main and wlan security instances share same index */
         sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, passed_index);
         system(conf_buf);
      }
   }

   /*
      ************* System Config File Update Block ***************
      convert the name value pair in array_fvp into string format expected by rc.conf file
   */
   ret = form_cfgdb_buf(conf_buf, count, array_fvp);
   if (ret != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif /* #ifdef IFX_LOG_DEBUG */
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
      goto IFX_Handler;
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "conf_buf: %s, flags: 0x%x", conf_buf, flags);
   /* RC.CONF Configuration block */
   ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_SEC, flags, 1, conf_buf);
   if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif /* #ifdef IFX_LOG_DEBUG */
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
      goto IFX_Handler;
   }

   if(IFX_MODIFY_F_SET(flags))
   {
      /*
         if beacon type is basic and encryption type is wep then call api to set
         all wep keys
      */
      if (wlSec->beaconType == IFX_MAPI_WLAN_BEACON_BASIC)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "passed_index: %d", passed_index);
         if (wlSec->wlEncr == IFX_MAPI_WLAN_ENCR_WEP)
         {
            /*
               call ifx_mapi_set_wlan_wep_key
               \note - this api is called irrespective of the operation for each of
                       the 4 keys. For modify operation cpeid should be passed, so
                       that api will come to know the index of the wep key which is
                       being modified.
                     - the wep key api should be called with wlSec->wepKeyIndex filled
                       with the wep key index that is operated irrespective of the operation
                     - if IFX_F_INT_DONT_CONFIGURE flag is not set then set the flag bit
                       before calling apis below this is to avoid device configuration
                       at multiple points which may be inconsistent and also maintain
                       virtual single entry point when calling the below apis
            */
#if 1
            for(i=0; i<IFX_MAPI_NUM_WEP_KEYS; i++)
            {
               IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
               if((ret = ifx_mapi_set_wlan_wep_key(oper, i,
                   &wlSec->secParams.wepCfg.wepKey[i],
                   flags | IFX_F_INT_DONT_CONFIGURE | IFX_F_DONT_WRITE_TO_FLASH))
                   != IFX_SUCCESS)
               {
#ifdef IFX_LOG_DEBUG
                  IFX_DBG("[%s:%d] ifx_mapi_set_wlan_wep_key has failed", __FUNCTION__, __LINE__);
#endif /* #ifdef IFX_LOG_DEBUG */
                  IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "ifx_mapi_set_wlan_wep_key has failed");
                  goto IFX_Handler;
               }
            }
#else
	         if (( ret = ifx_mapi_set_wlan_wep_config(oper,&wlSec->secParams.wepCfg,
                  flags | IFX_F_INT_DONT_CONFIGURE)) != IFX_SUCCESS)
	         {
               IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "ifx_mapi_set_wlan_wep_config has failed");
               goto IFX_Handler;
	         }
#endif /* if 0 */
         }
      }
      else if(
               (wlSec->beaconType == IFX_MAPI_WLAN_BEACON_WPA) ||
               (wlSec->beaconType == IFX_MAPI_WLAN_BEACON_WPA2) ||
               (wlSec->beaconType == IFX_MAPI_WLAN_BEACON_WPA_WPA2)
              )
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");

         if (wlSec->wlAuth == IFX_MAPI_WLAN_AUTH_PERSONAL)
         {
            /* call mapiWlanSetPersonalConfig config */
            wlSec->secParams.personalCfg.psk.iid.pcpeId.Id = wlSec->iid.cpeId.Id;
            wlSec->secParams.personalCfg.psk.iid.config_owner = wlSec->iid.config_owner;
            wlSec->secParams.personalCfg.psk.iid.cpeId.Id = wlSec->iid.cpeId.Id;

            if((ret = mapiWlanSetPersonalConfig(
                        oper, &wlSec->secParams.personalCfg.psk,
                        flags | IFX_F_INT_DONT_CONFIGURE | IFX_F_DONT_WRITE_TO_FLASH))
                        != IFX_SUCCESS)
            {
#ifdef IFX_LOG_DEBUG
               IFX_DBG("[%s:%d] ifx_set_wlan_passphrase_config has failed", __FUNCTION__, __LINE__);
#endif /* #ifdef IFX_LOG_DEBUG */
               IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
                                  "mapiWlanSetPersonalConfig has failed");
               goto IFX_Handler;
            }

            {
               IFX_MAPI_WLAN_802_1x wlRadius;

               memset(&wlRadius, 0x00, sizeof(IFX_MAPI_WLAN_802_1x));
               /* parent CPE ID of wlRadius object is cpeID of wlan security object */
               wlRadius.iid.pcpeId.Id  = wlSec->iid.cpeId.Id;
               if ((ret = ifx_mapi_get_wlan_802_1x_config(&wlRadius, IFX_F_DEFAULT)) != IFX_SUCCESS)
               {
                  IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
                                     "ifx_mapi_get_wlan_802_1x_config has failed");
                  goto IFX_Handler;
               }
               wlRadius.groupKeyEna    = wlSec->secParams.personalCfg.groupKeyEna;
               wlRadius.groupKeyIntvl  = wlSec->secParams.personalCfg.groupKeyIntvl;
               /*
                  \todo
                     check flags, when TR69 is available for Radius
               */
               if((ret =
                     ifx_mapi_set_wlan_802_1x_config(
                        oper, &wlRadius,
                        (flags | IFX_F_INT_DONT_CONFIGURE |
                         IFX_F_DONT_WRITE_TO_FLASH |
                         IFX_F_INT_DONT_SEND_NOTIFICATION |
                         IFX_F_INT_DONT_CHECK_ACL)  )
                  ) != IFX_SUCCESS)
               {
                  IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig",
                                 "ifx_mapi_set_wlan_802_1x_config has failed");
                  goto IFX_Handler;
               }
            }
         }
         else if (wlSec->wlAuth == IFX_MAPI_WLAN_AUTH_RADIUS)
         {
            /* call ifx_set_wlan_passphrase config */
            wlSec->secParams.wlRadius.iid.pcpeId.Id = wlSec->iid.cpeId.Id;
            wlSec->secParams.wlRadius.iid.config_owner = wlSec->iid.config_owner;
            wlSec->secParams.wlRadius.iid.cpeId.Id = wlSec->iid.cpeId.Id;
            /*
               \todo
                  check flags, when TR69 is available for Radius
            */
            if((ret = ifx_mapi_set_wlan_802_1x_config(
                        oper, &wlSec->secParams.wlRadius,
                        (flags | IFX_F_INT_DONT_CONFIGURE |
                         IFX_F_DONT_WRITE_TO_FLASH |
                         IFX_F_INT_DONT_SEND_NOTIFICATION |
                         IFX_F_INT_DONT_CHECK_ACL)  )
               ) != IFX_SUCCESS)
            {
#ifdef IFX_LOG_DEBUG
               IFX_DBG("[%s:%d] ifx_mapi_set_wlan_802_1x_config has failed", __FUNCTION__, __LINE__);
#endif /* #ifdef IFX_LOG_DEBUG */
               IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "ifx_mapi_set_wlan_802_1x_config has failed");
               goto IFX_Handler;
            }
         }
      }
   }

   /*
      ********** Device Configuration Block ****************
      Device config thru Scripts/Utilities or Functions
   */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags))
   {
      if(oper == IFX_OP_MOD)
      {
         /* both wlan main and wlan security instances share same index */
#ifdef CONFIG_FEATURE_IFX_WIRELESS_WAVE300
         sprintf(conf_buf, "%s %d", SERVICE_WLAN_SEC_MODIFY, passed_index);
#else
         sprintf(conf_buf, "%s %d &", SERVICE_WLAN_SEC_MODIFY, passed_index);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "conf_buf: %s", conf_buf);
         system(conf_buf);
      }
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "flags: 0x%x", flags);
   /* this will Compact the section and also update the count for both ADD and DELETE */
   if(IFX_MODIFY_F_NOT_SET(flags))
      ifx_CompactCfgSection(FILE_RC_CONF, TAG_WLAN_SEC, flags);

   /*********** Notification Block *************/
   /* Notify the Internal TR69 Stack in case of MODIFY */

   /*********** Epilog Block **************/
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
   /* Update the IID mappings in the mappings section for ADD/DELETE */
   if(IFX_MODIFY_F_SET(flags))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
      CHECK_N_SEND_NOTIFICATION(wlSec->iid, changed_count, array_changed_fvp, flags, IFX_Handler)
   }
   else if (IFX_INT_ADD_F_SET(flags))
   {
      /* In case of ADD operation, first update the ID Mappings
       * and then send the Notification for the attributes
       */
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
      /*********** Epilog Block **************/
      UPDATE_ID_MAP_N_ATTRIBUTES(&wlSec->iid, count, array_fvp, flags, IFX_Handler)

      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "cpeId: %d, pCpeId:%d, owner: %d", wlSec->iid.cpeId.Id, wlSec->iid.pcpeId.Id, wlSec->iid.config_owner);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "cpeId.secName: %s, pcpeId.secName: %s", wlSec->iid.cpeId.secName, wlSec->iid.pcpeId.secName);

      if (IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(flags))
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
         CHECK_N_SEND_NOTIFICATION(wlSec->iid, count, array_fvp, flags, IFX_Handler)
      }

      /* Manipulate nextCpeId only for ADD operations */
      ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_SEC);

   }
   else if (IFX_DELETE_F_SET(flags))
   {
      /* In case of DELETE operation, first send the notificatioupdate the ID Mappings
       * and then send the Notification for the attributes
       */
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
      /*********** Epilog Block **************/
      if (IFX_INT_DONT_SEND_NOTIFICATION_F_NOT_SET(flags))
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
         CHECK_N_SEND_NOTIFICATION(wlSec->iid, count, array_fvp, flags, IFX_Handler)
      }

      UPDATE_ID_MAP_N_ATTRIBUTES(&wlSec->iid, count, array_fvp, flags, IFX_Handler)
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");

   if (oper == IFX_OP_ADD)
   {
      /*
         objects for personal configuration and enterprise configuration have
         to be added as well (use some default values)
      */
      if ( (ret = mapiWlan8021XConfig(oper, wlSec)) != IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "mapiWlan8021XConfig has failed");
         goto IFX_Handler;
      }
      if ( (ret = mapiWlanPersonalConfig(oper, wlSec)) != IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "mapiWlanPersonalConfig has failed");
         goto IFX_Handler;
      }
      if ( (ret = mapiWlanWepConfig(oper, wlSec)) != IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "mapiWlanWepConfig has failed");
         goto IFX_Handler;
      }
   }

   /* Updating Persistent Storage */
   ret = ifx_config_write(FILE_RC_CONF, flags);
   if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif /* #ifdef IFX_LOG_DEBUG */
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "");
      goto IFX_Handler;
   }

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "ret: %d", ret);
   IFX_MEM_FREE(array_changed_fvp)
	/*
   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanSecurityConfig", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
	*/
      return ret;
   }

/**
   \param   oper  - type of operation (ADD, MODIFY, DELETE)

   \param   wlApCfg - pointer to IFX_MAPI_WLAN_AP_Cfg structure

   \param   flags - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks - ap should not be deleted
            - web when calling for delete will pass ssid only or something more ??
            - validation for wep key type and passphrase key type
            - validation to check for combination of standard, country, op-reates, basic-rates and channels
            - wireless start script checks if both phy-radio and this ap/vap is enabled, then only starts the service
*/
int32 ifx_mapi_set_wlan_ap_config(uint32 oper, IFX_MAPI_WLAN_AP_Cfg *wlApCfg, uint32 flags)
{
   CPE_ID	cpe_id;
   char8	   conf_buf[MAX_FILELINE_LEN];
   int32	   ret = IFX_SUCCESS, passed_index = -1;
#ifdef IFX_MAPI_WLAN_WMM
   char8	   sValue[MAX_FILELINE_LEN];
   uint32   outFlag = IFX_F_DEFAULT;
   int32    i;
#endif
   uint32   flags_save = IFX_F_DEFAULT;

   IFX_MAPI_DEBUG(fd,
                  "/tmp/ifxMapiSetWlanApConfig",
                  "wlApCfg->iid.cpeId.Id: %d, wlApCfg->iid.pcpeId.Id: %d "
                  "wlApCfg->iid.cpeId.secName: %s, wlApCfg->iid.pcpeId.secName: %s "
                  "oper: %d, flags: 0x%x",
                  wlApCfg->iid.cpeId.Id, wlApCfg->iid.pcpeId.Id,
                  wlApCfg->iid.cpeId.secName, wlApCfg->iid.pcpeId.secName,
                  oper, flags);

   sprintf(wlApCfg->iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
   sprintf(wlApCfg->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

   if (oper == IFX_OP_ADD)
   {
      /*
         validate operation:
         add and delete operation must not be used with AP
      */
      if(IFX_DONT_VALIDATE_F_NOT_SET(flags))
      {
         if(wlApCfg->main.devType == IFX_MAPI_WLAN_DEV_TYPE_AP)
         {
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
                           "Add operation is not supported on AP");
            ret = IFX_FAILURE;
            goto IFX_Handler;
         }
      }

      /*
         get iid for this ap in case of add and use this iid for wlan_main,
         wlan_sec and wlan_802.1X -> requirement for TR69, which uses only one
         tr69id; other objects like wlan_wep, wlan_psk, wlan_ap_wmm, etc.
         request a unique tr69id when a new object is generated
      */
      if(ifx_get_IID(&wlApCfg->iid, "ssid") != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "");
         ret = IFX_FAILURE;
         goto IFX_Handler;
      }
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
                     "cpeId: %d, tr69Id: %s",
                     wlApCfg->iid.cpeId.Id, wlApCfg->iid.tr69Id);

   /* save given flags to in flags_local */
   flags_save = flags;
   /*
      set the IFX_F_INT_DONT_CONFIGURE flag bit before calling apis below;
      this is to avoid device configuration at multiple points which may be
      inconsistent and also maintain virtual single entry point when calling the
      below apis
   */
   flags |= IFX_F_INT_DONT_CONFIGURE;
   /*
      set the IFX_F_DONT_WRITE_TO_FLASH flag bit before calling apis below;
      this is to avoid that the device configuration is writtten multiple
      times to the flash; it is sufficient to do this once at the end of this
      function
   */
   flags |= IFX_F_DONT_WRITE_TO_FLASH;

      /*
      before calling main api, make sure iid settings are set correct,
      in case they are not already set from upper layer
   */
   sprintf(wlApCfg->main.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
   sprintf(wlApCfg->main.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
   wlApCfg->main.iid.config_owner   = wlApCfg->iid.config_owner;
   wlApCfg->main.iid.cpeId.Id       = wlApCfg->iid.cpeId.Id;
   wlApCfg->main.iid.pcpeId.Id      = wlApCfg->iid.pcpeId.Id;
   strcpy(wlApCfg->main.iid.tr69Id, wlApCfg->iid.tr69Id);
   wlApCfg->main.radioCpeId         = wlApCfg->phy.iid.cpeId.Id;

   /*
         in case of add and delete operation, the two functions ifx_mapi_set_wlan_main_config
         and ifx_mapi_set_wlan_security_config send notifications to TR69 stack;
         this must be avoided; therefore ifx_mapi_set_wlan_security config is called
         with no additional flags, e.g. the TR69 stack is notified, the latter
         call to ifx_mapi_set_wlan_main_config will have additional flags set to
         avoid sending another notification
   */
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig","oper: %d, flags: 0x%x", oper, flags);
   if((ret = ifx_mapi_set_wlan_main_config(oper, &wlApCfg->main, flags)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "ifx_set_wlan_main_config has failed");
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d] ifx_set_wlan_main_config has failed", __FUNCTION__, __LINE__);
#endif
      goto IFX_Handler;
   }

      /*
         before calling security api, make sure iid settings are set correct,
         in case they are not already set from upper layer
      */
      sprintf(wlApCfg->sec.iid.cpeId.secName, "%s", TAG_WLAN_SEC);
      sprintf(wlApCfg->sec.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
      wlApCfg->sec.iid.config_owner    = wlApCfg->iid.config_owner;
      wlApCfg->sec.iid.cpeId.Id        = wlApCfg->iid.cpeId.Id;
      wlApCfg->sec.iid.pcpeId.Id       = wlApCfg->iid.pcpeId.Id;
      strcpy(wlApCfg->sec.iid.tr69Id, wlApCfg->iid.tr69Id);

      /*
         Dont send a notification to TR69 stack:
         notification has already been sent from ifx_mapi_set_wlan_main_config;
         now set the flags to avoid sending notification again
      */
      flags = IFX_SET_DONT_SEND_NOTIFICATION_FLAG(flags);
      flags = IFX_SET_DONT_CHECK_ACL_FLAG(flags);
      flags |= IFX_F_DONT_WRITE_TO_FLASH;
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig","oper: %d, flags: 0x%x", oper, flags);
      if((ret = ifx_mapi_set_wlan_security_config(oper, &wlApCfg->sec, flags)) != IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "ifx_set_wlan_security_config has failed");
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d] ifx_set_wlan_security_config has failed", __FUNCTION__, __LINE__);
#endif
         goto IFX_Handler;
      }
      /* enable notifications to TR69 */
      flags = IFX_UNSET_DONT_SEND_NOTIFICATION_FLAG(flags);
      /* enable check of ACL */
      flags = IFX_UNSET_DONT_CHECK_ACL_FLAG(flags);


#ifdef IFX_MAPI_WLAN_WMM
      /* set flag to avoid writing to flash */
      flags |= IFX_F_DONT_WRITE_TO_FLASH;
      for (i = 0; i < IFX_MAPI_WLAN_WMM_NUM_AC; i++)
      {
         /*
            before calling wmm api, make sure iid settings are set correct,
            in case they are not already set from upper layer
         */
         sprintf(wlApCfg->apWmm[i].iid.cpeId.secName, "%s", TAG_WLAN_WMM_AP);
         sprintf(wlApCfg->apWmm[i].iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
         wlApCfg->apWmm[i].iid.config_owner   = wlApCfg->iid.config_owner;
         /* set pCpeId, which is cpeId of parent (wlan_main) */
         wlApCfg->apWmm[i].iid.pcpeId.Id      = wlApCfg->iid.cpeId.Id;
#if 0
         strcpy(wlApCfg->apWmm[i].iid.tr69Id, wlApCfg->iid.tr69Id);
#endif

         if ((ret = ifx_mapi_set_wlan_wmm_ap_config(oper, &wlApCfg->apWmm[i], flags))!= IFX_SUCCESS)
         {
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "ifx_mapi_set_wlan_wmm_ap_config has failed");
#ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] ifx_mapi_set_wlan_wmm_ap_config has failed", __FUNCTION__, __LINE__);
#endif
            goto IFX_Handler;
         }

         /*
            before calling main api, make sure iid settings are set correct,
            in case they are not already set from upper layer
         */
         sprintf(wlApCfg->staWmm[i].iid.cpeId.secName, "%s", TAG_WLAN_WMM_STA);
         sprintf(wlApCfg->staWmm[i].iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
         wlApCfg->staWmm[i].iid.config_owner   = wlApCfg->iid.config_owner;
         /* set pCpeId, which is cpeId of parent (wlan_main) */
         wlApCfg->staWmm[i].iid.pcpeId.Id      = wlApCfg->iid.cpeId.Id;

#if 0
         /*
            \todo
            check if tr69 id can be copied
         */
         strcpy(wlApCfg->staWmm[i].iid.tr69Id, wlApCfg->iid.tr69Id);
#endif
         if ((ret = ifx_mapi_set_wlan_wmm_sta_config(oper, &wlApCfg->staWmm[i], flags))!= IFX_SUCCESS)
         {
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "ifx_mapi_set_wlan_wmm_ap_config has failed");
#ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] ifx_mapi_set_wlan_wmm_ap_config has failed", __FUNCTION__, __LINE__);
#endif
            goto IFX_Handler;
         }
      }
      /* reset do not write to flash flag */
      flags &= ~((uint32)IFX_F_DONT_WRITE_TO_FLASH);
#endif /* #ifdef IFX_MAPI_WLAN_WMM */

#ifdef IFX_MAPI_WLAN_WPS
      /* set flag to avoid writing to flash */
      flags |= IFX_F_DONT_WRITE_TO_FLASH;

      /*
         before calling api, make sure iid settings are set correct,
         in case they are not already set from upper layer
      */
      sprintf(wlApCfg->wps.iid.cpeId.secName, "%s", TAG_WLAN_WPS);
      sprintf(wlApCfg->wps.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
      wlApCfg->wps.iid.config_owner   = wlApCfg->iid.config_owner;
      /* set pCpeId, which is cpeId of parent (wlan_main) */
      wlApCfg->wps.iid.pcpeId.Id      = wlApCfg->iid.cpeId.Id;

#if 0
      /*
         \todo
         check if tr69 id can be copied
      */
      strcpy(wlApCfg->wps.iid.tr69Id, wlApCfg->iid.tr69Id);
#endif
      if ((ret = ifx_mapi_set_wlan_wps_config(oper, &wlApCfg->wps, flags))!= IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "ifx_mapi_set_wlan_wps_config has failed");
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d] ifx_mapi_set_wlan_wps_config has failed", __FUNCTION__, __LINE__);
#endif
         goto IFX_Handler;
      }

      /*
         before calling api, make sure iid settings are set correct,
         in case they are not already set from upper layer
      */
      sprintf(wlApCfg->wpsRegs.iid.cpeId.secName, "%s", TAG_WLAN_WPS_REGISTRAR);
      sprintf(wlApCfg->wpsRegs.iid.pcpeId.secName, "%s", TAG_WLAN_WPS);
      wlApCfg->wpsRegs.iid.config_owner   = wlApCfg->iid.config_owner;
      /* set pCpeId, which is cpeId of parent (wlan_wps) */
      wlApCfg->wpsRegs.iid.pcpeId.Id      = wlApCfg->wps.iid.cpeId.Id;

      /*
         \todo available  for tr69 make as soon as required changes are
               available in devm
      */
      if ((ret = ifx_mapi_set_wlan_wps_registrar_config(oper, &wlApCfg->wpsRegs, flags))!= IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
                            "ifx_mapi_set_wlan_wps_registrar_config has failed: "
                            "oper: %d, flags: 0x%x", oper, flags);
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d] ifx_mapi_set_wlan_wps_registrar_config has failed", __FUNCTION__, __LINE__);
#endif
         goto IFX_Handler;
      }

      /* reset do not write to flash flag */
      flags &= ~((uint32)IFX_F_DONT_WRITE_TO_FLASH);
#endif /* #ifdef IFX_MAPI_WLAN_WPS */

      /*
         start this ap/vap if the original variable flags does not contain any
         flags, preventing this
      */
      if(IFX_DONT_ACTIVATE_F_NOT_SET(flags_save))
      {
         cpe_id.Id = wlApCfg->iid.cpeId.Id;
         sprintf(cpe_id.secName, "%s", TAG_WLAN_MAIN);
         IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id, passed_index);
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "passed_index: %d", passed_index);
         if (passed_index < 0) {
        	 ret = IFX_FAILURE;
        	 goto IFX_Handler;
         }

         /* passed index should be that of wlan_main instance */
#ifdef CONFIG_FEATURE_IFX_WIRELESS_WAVE300
         sprintf(conf_buf, "%s %d", SERVICE_WLAN_ADD_VAP, passed_index);
#else
         sprintf(conf_buf, "%s %d", SERVICE_WLAN_START, passed_index);
#endif
         system(conf_buf);
      }
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig","oper: %d, flags_save: 0x%x", oper, flags_save);
   }
   else if (oper == IFX_OP_DEL)
   {
      /*
         validate operation:
         add and delete operation must not be used with AP
      */
      if(IFX_DONT_VALIDATE_F_NOT_SET(flags))
      {
         if(wlApCfg->main.devType == IFX_MAPI_WLAN_DEV_TYPE_AP)
         {
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig",
                           "Delete operation is not supported on AP");
            ret = IFX_FAILURE;
            goto IFX_Handler;
         }
      }
      /* VAP shall be deleted, e.g. first get all related objects */
      if (oper == IFX_OP_DEL)
      {
         /* Get object from system */
         ret = ifx_mapi_get_wlan_ap_config(wlApCfg, IFX_F_DEFAULT);
         if (ret != IFX_SUCCESS)
         {
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "");
            goto IFX_Handler;
         }
      }

      /* save given flags to in flags_local */
      flags_save = flags;
      /*
         set the IFX_F_INT_DONT_CONFIGURE flag bit before calling apis below;
         this is to avoid device configuration at multiple points which may be
         inconsistent and also maintain virtual single entry point when calling the
         below apis
      */
      flags |= IFX_F_INT_DONT_CONFIGURE;
      /*
         set the IFX_F_DONT_WRITE_TO_FLASH flag bit before calling apis below;
         this is to avoid that the device configuration is writtten multiple
         times to the flash; it is sufficient to do this once at the end of this
         function
      */
      flags |= IFX_F_DONT_WRITE_TO_FLASH;

      /*
         stop this ap/vap before calling apis below, if the original variable
         flags does not contain any flags, preventing this
      */
      if(IFX_DONT_ACTIVATE_F_NOT_SET(flags_save))
      {
         cpe_id.Id = wlApCfg->iid.cpeId.Id;
         sprintf(cpe_id.secName, "%s", TAG_WLAN_MAIN);
         IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id, passed_index);
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "passed_index: %d", passed_index);
         sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, passed_index);
         system(conf_buf);
      }

      /* first delete the child objects wmm, wps, psk, wep, 8021x */
#ifdef IFX_MAPI_WLAN_WPS
      /* set flag to avoid writing to flash */
      flags |= IFX_F_DONT_WRITE_TO_FLASH;

      /*
         before calling api, make sure iid settings are set correct,
         in case they are not already set from upper layer
      */
      sprintf(wlApCfg->wpsRegs.iid.cpeId.secName, "%s", TAG_WLAN_WPS_REGISTRAR);
      sprintf(wlApCfg->wpsRegs.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
      wlApCfg->wpsRegs.iid.config_owner   = wlApCfg->iid.config_owner;
      /* set pCpeId, which is cpeId of parent (wlan_main) */
      wlApCfg->wpsRegs.iid.pcpeId.Id      = wlApCfg->iid.cpeId.Id;


      /*
         \todo available  for tr69 make as soon as required changes are
               available in devm
      */
      /* enable notifications to TR69 */
      flags = IFX_SET_DONT_SEND_NOTIFICATION_FLAG(flags);
      /* enable check of ACL */
      flags = IFX_SET_DONT_CHECK_ACL_FLAG(flags);
      if ((ret = ifx_mapi_set_wlan_wps_registrar_config(oper, &wlApCfg->wpsRegs, flags))!= IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "ifx_mapi_set_wlan_wps_registrar_config has failed");
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d] ifx_mapi_set_wlan_wps_registrar_config has failed", __FUNCTION__, __LINE__);
#endif
         goto IFX_Handler;
      }
      /* enable notifications to TR69 */
      flags = IFX_UNSET_DONT_SEND_NOTIFICATION_FLAG(flags);
      /* enable check of ACL */
      flags = IFX_UNSET_DONT_CHECK_ACL_FLAG(flags);

      /*
         before calling api, make sure iid settings are set correct,
         in case they are not already set from upper layer
      */
      sprintf(wlApCfg->wps.iid.cpeId.secName, "%s", TAG_WLAN_WPS);
      sprintf(wlApCfg->wps.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
      wlApCfg->wps.iid.config_owner   = wlApCfg->iid.config_owner;
      /* set pCpeId, which is cpeId of parent (wlan_main) */
      wlApCfg->wps.iid.pcpeId.Id      = wlApCfg->iid.cpeId.Id;

#if 0
      /*
         \todo
         check if tr69 id can be copied
      */
      strcpy(wlApCfg->wps.iid.tr69Id, wlApCfg->iid.tr69Id);
#endif
      if ((ret = ifx_mapi_set_wlan_wps_config(oper, &wlApCfg->wps, flags))!= IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "ifx_mapi_set_wlan_wps_config has failed");
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d] ifx_mapi_set_wlan_wps_config has failed", __FUNCTION__, __LINE__);
#endif
         goto IFX_Handler;
      }

      /* reset do not write to flash flag */
      flags &= ~((uint32)IFX_F_DONT_WRITE_TO_FLASH);
#endif /* #ifdef IFX_MAPI_WLAN_WPS */

#ifdef IFX_MAPI_WLAN_WMM
      /* set flag to avoid writing to flash */
      flags |= IFX_F_DONT_WRITE_TO_FLASH;
      for (i = 3; i >= 0; i--)
      {
         /*
            before calling wmm api, make sure iid settings are set correct,
            in case they are not already set from upper layer
         */
         sprintf(wlApCfg->apWmm[i].iid.cpeId.secName, "%s", TAG_WLAN_WMM_AP);
         sprintf(wlApCfg->apWmm[i].iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
         wlApCfg->apWmm[i].iid.config_owner   = wlApCfg->iid.config_owner;
         /* set pCpeId, which is cpeId of parent (wlan_main) */
         wlApCfg->apWmm[i].iid.pcpeId.Id      = wlApCfg->iid.cpeId.Id;
#if 0
         strcpy(wlApCfg->apWmm[i].iid.tr69Id, wlApCfg->iid.tr69Id);
#endif

         /*
            \todo
            this can be removed later
         */
         if (oper == IFX_OP_DEL)
         {
            /* get cpeId */
            sprintf(conf_buf, "%s%d_%d_cpeId", PREFIX_WLAN_WMM_AP,
                    wlApCfg->apWmm[i].iid.pcpeId.Id, i);
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "conf_buf: %s", conf_buf);
            if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_WMM_AP,
               conf_buf, IFX_F_GET_ANY, &outFlag, sValue)) != IFX_SUCCESS)
            {
               IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "");
               goto IFX_Handler;
            }
            wlApCfg->apWmm[i].iid.cpeId.Id = atoi(sValue);
            wlApCfg->apWmm[i].ac = i;
         }

         if ((ret = ifx_mapi_set_wlan_wmm_ap_config(oper, &wlApCfg->apWmm[i], flags))!= IFX_SUCCESS)
         {
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "ifx_mapi_set_wlan_wmm_ap_config has failed");
#ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] ifx_mapi_set_wlan_wmm_ap_config has failed", __FUNCTION__, __LINE__);
#endif
            goto IFX_Handler;
         }

         /*
            before calling wmm sta api, make sure iid settings are set correct,
            in case they are not already set from upper layer
         */
         sprintf(wlApCfg->staWmm[i].iid.cpeId.secName, "%s", TAG_WLAN_WMM_STA);
         sprintf(wlApCfg->staWmm[i].iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
         wlApCfg->staWmm[i].iid.config_owner   = wlApCfg->iid.config_owner;
         /* set pCpeId, which is cpeId of parent (wlan_main) */
         wlApCfg->staWmm[i].iid.pcpeId.Id      = wlApCfg->iid.cpeId.Id;

#if 0
         /*
            \todo
            check if tr69 id can be copied
         */
         strcpy(wlApCfg->staWmm[i].iid.tr69Id, wlApCfg->iid.tr69Id);
#endif
         /*
            \todo
            this can be removed later
         */
         if (oper == IFX_OP_DEL)
         {
            /* get cpeId */
            sprintf(conf_buf, "%s%d_%d_cpeId", PREFIX_WLAN_WMM_STA,
                    wlApCfg->staWmm[i].iid.pcpeId.Id, i);
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "conf_buf: %s", conf_buf);
            if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_WMM_STA,
               conf_buf, IFX_F_GET_ANY, &outFlag, sValue)) != IFX_SUCCESS)
            {
               IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "");
               goto IFX_Handler;
            }
            wlApCfg->staWmm[i].iid.cpeId.Id = atoi(sValue);
            wlApCfg->staWmm[i].ac = i;
         }

         if ((ret = ifx_mapi_set_wlan_wmm_sta_config(oper, &wlApCfg->staWmm[i], flags))!= IFX_SUCCESS)
         {
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "ifx_mapi_set_wlan_wmm_ap_config has failed");
#ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] ifx_mapi_set_wlan_wmm_ap_config has failed", __FUNCTION__, __LINE__);
#endif
            goto IFX_Handler;
         }
      }
      /* reset do not write to flash flag */
      flags &= ~((uint32)IFX_F_DONT_WRITE_TO_FLASH);
#endif /* #ifdef IFX_MAPI_WLAN_WMM */

      /*
         before calling security api, make sure iid settings are set correct,
         in case they are not already set from upper layer
      */
      sprintf(wlApCfg->sec.iid.cpeId.secName, "%s", TAG_WLAN_SEC);
      sprintf(wlApCfg->sec.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
      wlApCfg->sec.iid.config_owner    = wlApCfg->iid.config_owner;
      wlApCfg->sec.iid.cpeId.Id        = wlApCfg->iid.cpeId.Id;
      wlApCfg->sec.iid.pcpeId.Id       = wlApCfg->iid.pcpeId.Id;
      strcpy(wlApCfg->sec.iid.tr69Id, wlApCfg->iid.tr69Id);

      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig","oper: %d, flags: 0x%x", oper, flags);
      /*
         in case of add and delete operation, the two functions ifx_mapi_set_wlan_main_config
         and ifx_mapi_set_wlan_security_config send notifications to TR69 stack;
         this must be avoided; therefore ifx_mapi_set_wlan_security config is called
         with no additional flags, e.g. the TR69 stack is notified, the latter
         call to ifx_mapi_set_wlan_main_config will have additional flags set to
         avoid sending another notification
      */
      if((ret = ifx_mapi_set_wlan_security_config(oper, &wlApCfg->sec, flags)) != IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "ifx_set_wlan_security_config has failed");
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d] ifx_set_wlan_security_config has failed", __FUNCTION__, __LINE__);
#endif
         goto IFX_Handler;
      }

      /*
         before calling main api, make sure iid settings are set correct,
         in case they are not already set from upper layer
      */
      sprintf(wlApCfg->main.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
      sprintf(wlApCfg->main.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
      wlApCfg->main.iid.config_owner   = wlApCfg->iid.config_owner;
      wlApCfg->main.iid.cpeId.Id       = wlApCfg->iid.cpeId.Id;
      wlApCfg->main.iid.pcpeId.Id      = wlApCfg->iid.pcpeId.Id;
#if 0
      strcpy(wlApCfg->main.iid.tr69Id, wlApCfg->iid.tr69Id);
#endif
      wlApCfg->main.radioCpeId         = wlApCfg->phy.iid.cpeId.Id;

      /*
         Dont send a notification to TR69 stack:
         notification has already been sent from ifx_mapi_set_wlan_security_config;
         now set the flags to avoid sending notification again
      */
      flags = IFX_SET_DONT_SEND_NOTIFICATION_FLAG(flags);
      flags = IFX_SET_DONT_CHECK_ACL_FLAG(flags);
      /*
         unset the IFX_F_INT_DONT_CONFIGURE flag bit before calling
         ifx_mapi_set_wlan_main_config api below;
         this is to ensure device configuration at the last stage of VAP
         removal
      */
      flags &= ~((uint32)IFX_F_INT_DONT_CONFIGURE);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig","oper: %d, flags: 0x%x", oper, flags);
      if((ret = ifx_mapi_set_wlan_main_config(oper, &wlApCfg->main, flags)) != IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "ifx_set_wlan_main_config has failed");
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d] ifx_set_wlan_main_config has failed", __FUNCTION__, __LINE__);
#endif
         goto IFX_Handler;
      }
   }
   else if (oper == IFX_OP_MOD)
   {
      /* save given flags to in flags_local */
      flags_save = flags;
      /*
         set the IFX_F_INT_DONT_CONFIGURE flag bit before calling apis below;
         this is to avoid device configuration at multiple points which may be
         inconsistent and also maintain virtual single entry point when calling the
         below apis
      */
      flags |= IFX_F_INT_DONT_CONFIGURE;
      /*
         set the IFX_F_DONT_WRITE_TO_FLASH flag bit before calling apis below;
         this is to avoid that the device configuration is writtten multiple
         times to the flash; it is sufficient to do this once at the end of this
         function
      */
      flags |= IFX_F_DONT_WRITE_TO_FLASH;

      /*
         stop this ap/vap before calling apis below, if the original variable
         flags does not contain any flags, preventing this
      */
      if(IFX_DONT_ACTIVATE_F_NOT_SET(flags_save))
      {
         cpe_id.Id = wlApCfg->iid.cpeId.Id;
         sprintf(cpe_id.secName, "%s", TAG_WLAN_MAIN);
         IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id, passed_index);
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "passed_index: %d", passed_index);
         sprintf(conf_buf, "%s %d", SERVICE_WLAN_STOP, passed_index);
         system(conf_buf);
      }

      /*
         before calling security api, make sure iid settings are set correct,
         in case they are not already set from upper layer
      */
      sprintf(wlApCfg->sec.iid.cpeId.secName, "%s", TAG_WLAN_SEC);
      sprintf(wlApCfg->sec.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
      wlApCfg->sec.iid.config_owner    = wlApCfg->iid.config_owner;
      wlApCfg->sec.iid.cpeId.Id        = wlApCfg->iid.cpeId.Id;
      wlApCfg->sec.iid.pcpeId.Id       = wlApCfg->iid.pcpeId.Id;
      strcpy(wlApCfg->sec.iid.tr69Id, wlApCfg->iid.tr69Id);

      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig","oper: %d, flags: 0x%x", oper, flags);
      /*
         in case of add and delete operation, the two functions ifx_mapi_set_wlan_main_config
         and ifx_mapi_set_wlan_security_config send notifications to TR69 stack;
         this must be avoided; therefore ifx_mapi_set_wlan_security config is called
         with no additional flags, e.g. the TR69 stack is notified, the latter
         call to ifx_mapi_set_wlan_main_config will have additional flags set to
         avoid sending another notification
      */
      if((ret = ifx_mapi_set_wlan_security_config(oper, &wlApCfg->sec, flags)) != IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "ifx_set_wlan_security_config has failed");
   #ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d] ifx_set_wlan_security_config has failed", __FUNCTION__, __LINE__);
   #endif
         goto IFX_Handler;
      }

      /*
         before calling main api, make sure iid settings are set correct,
         in case they are not already set from upper layer
      */
      sprintf(wlApCfg->main.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
      sprintf(wlApCfg->main.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
      wlApCfg->main.iid.config_owner   = wlApCfg->iid.config_owner;
      wlApCfg->main.iid.cpeId.Id       = wlApCfg->iid.cpeId.Id;
      wlApCfg->main.iid.pcpeId.Id      = wlApCfg->iid.pcpeId.Id;
      strcpy(wlApCfg->main.iid.tr69Id, wlApCfg->iid.tr69Id);
      wlApCfg->main.radioCpeId         = wlApCfg->phy.iid.cpeId.Id;

      /*
         Dont send a notification to TR69 stack:
         notification has already been sent from ifx_mapi_get_wlan_security_config;
         now set the flags to avoid sending notification again
      */
      flags = IFX_SET_DONT_SEND_NOTIFICATION_FLAG(flags);
      flags = IFX_SET_DONT_CHECK_ACL_FLAG(flags);
      flags |= IFX_F_DONT_WRITE_TO_FLASH;
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig","oper: %d, flags: 0x%x", oper, flags);
      if((ret = ifx_mapi_set_wlan_main_config(oper, &wlApCfg->main, flags)) != IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "ifx_set_wlan_main_config has failed");
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d] ifx_set_wlan_main_config has failed", __FUNCTION__, __LINE__);
#endif
         goto IFX_Handler;
      }

   /* call set api for wlan phy only if its modify operation */
   if(oper == IFX_OP_MOD)
   {
      sprintf(wlApCfg->phy.iid.cpeId.secName, "%s", TAG_WLAN_PHY);
      sprintf(wlApCfg->phy.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
      wlApCfg->phy.iid.config_owner    = wlApCfg->iid.config_owner;
      wlApCfg->phy.iid.cpeId.Id        = wlApCfg->main.radioCpeId;
      wlApCfg->phy.iid.pcpeId.Id       = wlApCfg->iid.pcpeId.Id;
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig","oper: %d, flags: %d", oper, flags);
      if((ret = ifx_mapi_set_wlan_phy_config(oper, &wlApCfg->phy, flags)) != IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "ifx_set_wlan_phy_config has failed");
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d] ifx_mapi_set_wlan_phy_config has failed", __FUNCTION__, __LINE__);
#endif
         goto IFX_Handler;
      }
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig","oper: %d, flags: 0x%x", oper, flags);

   /*
      start this ap/vap if the original variable flags does not contain any
      flags, preventing this
   */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags_save))
      {
         cpe_id.Id = wlApCfg->iid.cpeId.Id;
         sprintf(cpe_id.secName, "%s", TAG_WLAN_MAIN);
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "cpeId.secName: %s, cpeId.Id: %d", cpe_id.secName, cpe_id.Id);
         IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id, passed_index);
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "passed_index: %d", passed_index);
         sprintf(conf_buf, "%s %d", SERVICE_WLAN_START, passed_index); /* passed index should be that of wlan_main instance */
         system(conf_buf);
      }
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig","oper: %d, flags_save: 0x%x", oper, flags_save);
   }

   /*
      updating Persistent Storage, if original flags variable allows this
   */
   if ((ret = ifx_config_write(FILE_RC_CONF, flags_save)) != IFX_SUCCESS)
   {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig", "ifx_config_write has failed");
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d] ifx_config_write has failed", __FUNCTION__, __LINE__);
#endif
         goto IFX_Handler;
   }

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanApConfig","ret: %d", ret);
   if(ret != IFX_SUCCESS)
   {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return ret;
   }
   else
      return IFX_SUCCESS;
}

/**
   \param   oper  - type of operation (ADD, MODIFY, DELETE)

   \param

   \param   flags - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_set_global_mac_control_status(uint32 operation, IFX_MAPI_GlobalMacControl *glblMacControl, uint32 flags)
{
   int32	ret = IFX_SUCCESS, passed_index = -1;
   char8	buf[MAX_FILELINE_LEN];

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrlStatus", "");

   if(operation != IFX_OP_MOD) {
	#ifdef IFX_LOG_DEBUG
      	IFX_DBG("[%s:%d] Only modify operation is supported", __FUNCTION__, __LINE__);
	#endif // IFX_LOG_DEBUG
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrlStatus", "Only modify operation is supported");
      ret = IFX_FAILURE;
      goto IFX_Handler;
   }

   flags |= IFX_F_MODIFY;

   sprintf(glblMacControl->iid.cpeId.secName, "%s", TAG_WLAN_GLOBAL_MAC_CONTROL);
   sprintf(glblMacControl->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

   IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, glblMacControl->iid.cpeId, passed_index)

   /* before config file update, stop ap/vap's, unless the acl wont take effect */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags))
   {
      sprintf(buf, "%s", SERVICE_WLAN_STOP);
      system(buf);
   }


   sprintf(buf, "%s_%d_control=\"%d\"\n", PREFIX_WLAN_GLOBAL_MAC_CONTROL, passed_index, glblMacControl->cntrlMode);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrlStatus", "buf: %s", buf);
   ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL, flags, 1, buf);
   if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif // IFX_LOG_DEBUG
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrlStatus", "");
      goto IFX_Handler;
   }

   /*********** Device Configuration Block ****************/
   /* Device config thru Scripts/Utilities or Functions */
   /* after config file update, for modify or add operation start all ap/vap */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags))
   {
         sprintf(buf, "%s", SERVICE_WLAN_START);
         system(buf);
   }

   /* Updating Persistent Storage */
   ret = ifx_config_write(FILE_RC_CONF, flags);
   if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      goto IFX_Handler;
   }

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrlStatus", "ret: %d", ret);
   if(ret != IFX_SUCCESS)
   {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return ret;
   }
   else
      return IFX_SUCCESS;
}

/**
   This API configures the WLAN global MAC filter

   \param   oper  - type of operation (ADD, MODIFY, DELETE)

   \param   glblMacControl - pointer to IFX_MAPI_GlobalMacControl structure

   \param   flags - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks - what should be interface type for each rule added ??
              for each wlan mac filter rule interface type is assumed to be wlan
            - since the object is not present in tr69 use owner as tr69 to bypass acl and notification
              otherwise it may return error
            - TSC supports configuring only 6 mac filter entries
*/
int32 ifx_mapi_set_global_mac_control(uint32 oper, IFX_MAPI_GlobalMacControl *glblMacControl, uint32 flags)
{
   int32                ret = IFX_SUCCESS, passed_index = -1, count = 0, changedCount = 0;
   char8                conf_buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
   uint32               outFlag = IFX_F_DEFAULT;
   IFX_NAME_VALUE_PAIR  array_fvp[WLAN_GLOBAL_MAC_CNTRL_PARAM_COUNT], *array_changed_fvp = NULL;
   IFX_ID               parent_iid;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");

   NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
   memset(array_fvp, 0x00, sizeof(array_fvp));
   memset(&parent_iid, 0, sizeof(parent_iid));

   /**************** Validation Block *****************/
   /* For Operations other than DELETE do the verification of input params */
   if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
      /* Do simple validation of pointer such as NULL */
      IFX_VALIDATE_PTR(glblMacControl)
   }

   sprintf(glblMacControl->iid.cpeId.secName, "%s", TAG_WLAN_GLOBAL_MAC_CONTROL);
   /* since this object is not in tr69-model */
   sprintf(glblMacControl->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

   parent_iid.cpeId.Id = glblMacControl->iid.pcpeId.Id;
   sprintf(parent_iid.cpeId.secName, "%s", glblMacControl->iid.pcpeId.secName);

   glblMacControl->iid.config_owner = IFX_WEB;

   /*************** Prolog Block *********************/
   /* Based on operation (ADD or DELETE or MODIFY)
    * append the flag with internal flags */
   if (oper == IFX_OP_DEL)
      flags |= IFX_F_DELETE;
   else if (oper == IFX_OP_ADD) {
      if( (IFX_MODIFY_F_NOT_SET(flags)))
         flags |= IFX_F_INT_ADD;
   }
   else
      flags |= IFX_F_MODIFY;


   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
   /**************** Validation Block *****************/
   /* For Operations other than DELETE do the verification of input params */
   if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
      /* Do simple validation of pointer such as NULL */
#if 0
      IFX_VALIDATE_PTR(wlanMacControl->macAddrList)
#endif /* #if 0 */
      /* do simple validation of flags sucha as less than 0 */
      IFX_VALIDATE_FLAGS(flags)
      /* validate for no. of mac filter rules in acl table, if its 6 return error
         tsc driver can accomodate only 6 rules in acl table */
      if(IFX_ADD_F_SET(flags)) {
         MAKE_SECTION_COUNT_TAG(TAG_WLAN_GLOBAL_MAC_CONTROL, conf_buf);
         if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL,
                           conf_buf, IFX_F_DEFAULT, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
            goto IFX_Handler;
         }
         if(atoi(sValue) == IFX_MAPI_WLAN_NUM_ENTRIES_ACL_TABLE) {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] wlan acl table can only accomodate 6 entries", __FUNCTION__, __LINE__);
#endif
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
            ret = IFX_FAILURE;
            goto IFX_Handler;
         }
      }
   }

   if (IFX_ADD_F_SET(flags))
   {
      /* Allocate the IID for this mac-control instance
       * Set the parent SectionName and parent IID values
       * to NULL as there is no parent for Route Entity
       */
	   if (ifx_get_iid(TAG_WLAN_GLOBAL_MAC_CONTROL, TAG_LAN_DEVICE, &parent_iid,
				&glblMacControl->iid) != IFX_SUCCESS)  {
      //if (ifx_get_IID(&glblMacControl->iid, "macAddr") != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
         ret = IFX_FAILURE;
         goto IFX_Handler;
      }
    }

   /*********************** Name Value Formation as per RC.CONF **********************/
   if(IFX_DELETE_F_NOT_SET(flags)) {
      ifx_fill_ArrayFvp_FName(array_fvp, 0, WLAN_GLOBAL_MAC_CNTRL_PARAM_COUNT, wlan_global_mac_cntrl_params);

      ifx_fill_ArrayFvp_intValues(array_fvp, 0, 3, (int32 *) &glblMacControl->iid.cpeId.Id,
                                       &glblMacControl->iid.pcpeId.Id,
                                       &glblMacControl->ifType);
      sprintf(array_fvp[3].value, "%s", glblMacControl->macAddr);
      sprintf(array_fvp[4].value, "%d", glblMacControl->cntrlMode);
      passed_index = -1;
   }
   count = WLAN_GLOBAL_MAC_CNTRL_PARAM_COUNT;

   /* Get Config Index in case of modify/delete operations from PCPEID */
   if((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags)))
   {
		IFX_GET_INDEX_FROM_PCPEID(FILE_RC_CONF, glblMacControl->iid.pcpeId, passed_index)
      //IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, glblMacControl->iid.cpeId, passed_index)
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "passed_index: %d", passed_index);

   if(ifx_get_conf_index_and_nv_pairs(&glblMacControl->iid, passed_index, PREFIX_WLAN_GLOBAL_MAC_CONTROL,
            count, array_fvp, flags) != IFX_SUCCESS) {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
      ret = IFX_FAILURE;
      goto IFX_Handler;
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
   /* Check ACL in case of Delete - as notification must be sent to TR69 Stack
    * TR69 does a delete from CHECK_ACL_RET function
    * Here the changed array consists of the whole parameter set for DELETE */
   if (IFX_DELETE_F_SET(flags) && IFX_INT_DONT_CHECK_ACL_F_NOT_SET(flags))
   {
      CHECK_ACL_RET(glblMacControl->iid, count, array_fvp,
               changedCount, array_changed_fvp, flags, IFX_Handler)
   }


   /* before config file update, stop ap/vap's */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanWmmApConfig", "SERVICE_WLAN_STOP");
      sprintf(conf_buf, "%s", SERVICE_WLAN_STOP);
      system(conf_buf);
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
   /* this object has a object level parameter, which is stored irrespective of instances.
      so a seperate modify operation should be done this parameter if operation == IFX_OP_MOD */
   if(IFX_MODIFY_F_SET(flags)) {
      sprintf(conf_buf, "%s_control=\"%d\"\n", PREFIX_WLAN_GLOBAL_MAC_CONTROL, glblMacControl->cntrlMode);

      ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL, flags, 1, conf_buf);

      if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
         goto IFX_Handler;
      }
   }

   /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
   memset(conf_buf, 0x00, sizeof(conf_buf));
   form_cfgdb_buf(conf_buf, count, array_fvp);

   /* RC.CONF Configuration block */
   ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL, flags, 1, conf_buf);

   if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
      goto IFX_Handler;
   }


   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
   /*********** Device Configuration Block ****************/
   /* Device config thru Scripts/Utilities or Functions */
   /* after config file update, for modify or add operation start all ap/vap */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags))
   {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
         sprintf(conf_buf, "%s", SERVICE_WLAN_MAC_CTRL_MODIFY);
         system(conf_buf);
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
   /*********** Epilog Block **************/
   /* this will Compact the section and also update the count for both ADD and DELETE */
   if(IFX_MODIFY_F_NOT_SET(flags)) {
      ifx_CompactCfgSection(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL, flags);
   }
   /* Update the IID mappings in the mappings section for ADD/DELETE */
   if (IFX_INT_ADD_F_SET(flags)) {
      /* since this object is not in tr-98 model no need to call update_map and notification here */
      /* Manipulate nextCpeId only for ADD operations */
      ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL);
   }
   else if (IFX_DELETE_F_SET(flags)) {
      /* since this object is not in tr-98 model no need to call update_map and notification here */
   }


   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
   /* Updating Persistent Storage */
   ret = ifx_config_write(FILE_RC_CONF, flags);
   if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d] upgrade failed", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "");
      goto IFX_Handler;
   }



IFX_Handler:
   IFX_MEM_FREE(array_changed_fvp);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetGlobalMacCntrl", "ret: %d", ret);
   if(ret != IFX_SUCCESS) {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return ret;
   }
   else
      return IFX_SUCCESS;
}

/**
   This API configures the WLAN MAC filter

   \param   oper  - type of operation (ADD, MODIFY, DELETE)

   \param   wlMacControl - pointer to IFX_MAPI_WLAN_MAC_Control structure

   \param   flags - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_set_wlan_mac_control(uint32 oper, IFX_MAPI_WLAN_MAC_Control *wlMacControl, uint32 flags)
{
   int32                ret = IFX_SUCCESS, passed_index = -1, count = 0;
   char8	               conf_buf[MAX_FILELINE_LEN];
   IFX_NAME_VALUE_PAIR  array_fvp[WLAN_MAC_CNTRL_PARAM_COUNT];
   IFX_NAME_VALUE_PAIR  *array_changed_fvp = NULL;
   IFX_ID               parent_iid;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "");

   NULL_TERMINATE(conf_buf, 0x00, sizeof(conf_buf));
   memset(array_fvp, 0x00, sizeof(array_fvp));
   memset(&parent_iid, 0, sizeof(parent_iid));


   /*************** Prolog Block *********************/
   /* Based on operation (ADD or DELETE or MODIFY)
    * append the flag with internal flags */
   if (oper == IFX_OP_DEL)
      flags |= IFX_F_DELETE;
   else if (oper == IFX_OP_ADD) {
      if( (IFX_MODIFY_F_NOT_SET(flags)))
         flags |= IFX_F_INT_ADD;
   }
   else
      flags |= IFX_F_MODIFY;

   /**************** Validation Block *****************/
   /* For Operations other than DELETE do the verification of input params */
   if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {
      /* Do simple validation of pointer such as NULL */
      /* Do simple validation of pointer such as NULL */
      IFX_VALIDATE_PTR(wlMacControl)
      /* do simple validation of flags sucha as less than 0 */
      IFX_VALIDATE_FLAGS(flags)
   }

   sprintf(wlMacControl->iid.cpeId.secName, "%s", TAG_WLAN_MAC_CONTROL);
   /* since this object is not in tr69-model */
   sprintf(wlMacControl->iid.pcpeId.secName, "%s", TAG_WLAN_SEC);

   parent_iid.cpeId.Id = wlMacControl->iid.pcpeId.Id;
   sprintf(parent_iid.cpeId.secName, "%s", wlMacControl->iid.pcpeId.secName);

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "parent_iid.cpeId: %s, %d",
                  parent_iid.cpeId.secName, parent_iid.cpeId.Id);

   /**************** Validation Block *****************/
   /* For Operations other than DELETE do the verification of input params */
   if(IFX_DELETE_F_NOT_SET(flags) && IFX_DONT_VALIDATE_F_NOT_SET(flags)) {

/*
   For the moment comment this check for RALINK
   \todo implement a check on per vap base
*/
#if !defined(CONFIG_FEATURE_IFX_WIRELESS_RALINK)
      /* validate for no. of mac filter rules in acl table, if its 6 return error
         tsc driver can accomodate only 6 rules in acl table */
      if(IFX_ADD_F_SET(flags))
      {
         IFX_MAPI_WLAN_Capability   wlCaps;
         char8	                     sValue[MAX_FILELINE_LEN];
         uint32	                  outFlag = IFX_F_DEFAULT;

         MAKE_SECTION_COUNT_TAG(TAG_WLAN_MAC_CONTROL, conf_buf);
         if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAC_CONTROL,
                           conf_buf, IFX_F_DEFAULT, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "");
            goto IFX_Handler;
         }

         /* initialize all structures */
	 memset (&wlCaps, 0xFF, sizeof(IFX_MAPI_WLAN_Capability));

         if ((ret = ifx_mapi_get_wlan_capability(&wlCaps, IFX_F_DEFAULT)) != IFX_SUCCESS)
         {
            ret = IFX_FAILURE;
            goto IFX_Handler;
         }
         if(atoi(sValue) == wlCaps.numMacCntrlEntries)
         {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d] wlan acl table can only accomodate %d entries", __FUNCTION__, __LINE__, wlCaps.numMacCntrlEntries);
#endif
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "wlan acl table can only accomodate %d entries", wlCaps.numMacCntrlEntries);
            ret = IFX_FAILURE;
            goto IFX_Handler;
         }
      }
#endif /* #if !defined(CONFIG_FEATURE_IFX_WIRELESS_RALINK) */
   }

   if (IFX_ADD_F_SET(flags))
   {
      /* Allocate the IID for this mac-control instance
       * Set the parent SectionName and parent IID values
       * to NULL as there is no parent for Route Entity
       */
      if (ifx_get_iid(TAG_WLAN_MAC_CONTROL, TAG_WLAN_SEC, &parent_iid,
				&wlMacControl->iid) != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "");
         ret = IFX_FAILURE;
         goto IFX_Handler;
      }
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "parent_iid.pcpeId: %s, %d",
                     parent_iid.pcpeId.secName, parent_iid.pcpeId.Id);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "parent_iid.cpeId: %s, %d",
                     parent_iid.cpeId.secName, parent_iid.cpeId.Id);
    }

   /*********************** Name Value Formation as per RC.CONF **********************/
   if(IFX_DELETE_F_NOT_SET(flags)) {
      ifx_fill_ArrayFvp_FName(array_fvp, 0, WLAN_MAC_CNTRL_PARAM_COUNT, wlan_mac_cntrl_params);

      ifx_fill_ArrayFvp_intValues(array_fvp, 0, 2, (int32 *) &wlMacControl->iid.cpeId.Id,
                                       &wlMacControl->iid.pcpeId.Id);
      sprintf(array_fvp[2].value, "%s", wlMacControl->macAddr);
      passed_index = -1;
   }
   count = WLAN_MAC_CNTRL_PARAM_COUNT;

   /* Get Config Index in case of modify/delete operations from CPEID */
   if ((IFX_MODIFY_F_SET(flags)) || (IFX_DELETE_F_SET(flags)))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "cpeId: %s: %d",
                     wlMacControl->iid.cpeId.secName, wlMacControl->iid.cpeId.Id);
      IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlMacControl->iid.cpeId, passed_index)
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "passed_index: %d", passed_index);

   if (ifx_get_conf_index_and_nv_pairs(&wlMacControl->iid, passed_index,
       PREFIX_WLAN_MAC_CONTROL, count, array_fvp, flags) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "");
      ret = IFX_FAILURE;
      goto IFX_Handler;
   }

   /* Convert the name value pair in array_fvp into string format expected by rc.conf file */
   memset(conf_buf, 0x00, sizeof(conf_buf));
   form_cfgdb_buf(conf_buf, count, array_fvp);

   /* RC.CONF Configuration block */
   ret = ifx_SetObjData(FILE_RC_CONF, TAG_WLAN_MAC_CONTROL, flags, 1, conf_buf);

   if(ret != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "");
      goto IFX_Handler;
   }

   if (IFX_INT_ADD_F_SET(flags) || (IFX_DELETE_F_SET(flags)))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "parent_iid.pcpeId: %s, %d",
                     parent_iid.pcpeId.secName, parent_iid.pcpeId.Id);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "parent_iid.cpeId: %s, %d",
                     parent_iid.cpeId.secName, parent_iid.cpeId.Id);
      /*
         the correct index to be passed to low level script, must be obtained
         from parent cpeId
      */
      IFX_GET_INDEX_FROM_PCPEID(FILE_RC_CONF, parent_iid.cpeId, passed_index)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMainConfig", "passed_index: %d", passed_index);
   }

   /*********** Device Configuration Block ****************/
   /* Device config thru Scripts/Utilities or Functions */
   /* after config file update, for modify or add operation start all ap/vap */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags)) {
	   	   if (passed_index < 0) {
		   	   	   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl",
		   	   			   "conf_buf: %s", conf_buf);
	   		   	   ret = IFX_FAILURE;
	   		   	   goto IFX_Handler;
	   	   }
	   	   sprintf(conf_buf, "%s %d", SERVICE_WLAN_MAC_CTRL_MODIFY, passed_index);
	   	   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "conf_buf: %s", conf_buf);
	   	   system(conf_buf);
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "");
   /*********** Epilog Block **************/
   /* this will Compact the section and also update the count for both ADD and DELETE */
   if(IFX_MODIFY_F_NOT_SET(flags)) {
      ifx_CompactCfgSection(FILE_RC_CONF, TAG_WLAN_MAC_CONTROL, flags);
   }
   /* Update the IID mappings in the mappings section for ADD/DELETE */
   if (IFX_INT_ADD_F_SET(flags)) {
      /* since this object is not in tr-98 model no need to call update_map and notification here */
      /* Manipulate nextCpeId only for ADD operations */
      ifx_increment_next_cpeId(FILE_RC_CONF, TAG_WLAN_MAC_CONTROL);
   }
   else if (IFX_DELETE_F_SET(flags)) {
      /* since this object is not in tr-98 model no need to call update_map and notification here */
   }


   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "");
   /* Updating Persistent Storage */
   ret = ifx_config_write(FILE_RC_CONF, flags);
   if(ret != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d] upgrade failed", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "");
      goto IFX_Handler;
   }

IFX_Handler:
   IFX_MEM_FREE(array_changed_fvp);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "ret: %d", ret);
	/*
   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrl", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
	*/
   return ret;
}

/**
   \param   oper  - type of operation (ADD, MODIFY, DELETE)

   \param   wlMacControl - pointer to IFX_MAPI_WLAN_MAC_Control structure

   \param   flags - valid flags for SET operation

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_set_wlan_mac_control_status(uint32 mainCpeId, uint32 oper, uint32 flags)
{
   int32                ret = IFX_SUCCESS, passed_index = -1;
   char8	               conf_buf[MAX_FILELINE_LEN];
   CPE_ID               cpe_id;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrlStatus", "");

   /*************** Prolog Block *********************/
   /* Based on operation (ADD or DELETE or MODIFY)
    * append the flag with internal flags */
   if (oper != IFX_OP_MOD)
   {
      ret = IFX_FAILURE;
      goto IFX_Handler;
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrlStatus", "");
   /*********************** Name Value Formation as per RC.CONF **********************/

   /* Get Config Index in case of modify/delete operations from CPEID */
   if (IFX_MODIFY_F_SET(flags))
   {
      sprintf(cpe_id.secName, "%s", TAG_WLAN_SEC);
      cpe_id.Id = mainCpeId;
      /* get index from cpeid first */
      IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id, passed_index)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrlStatus", "passed_index: %d", passed_index);
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrlStatus", "");
   /*********** Device Configuration Block ****************/
   /* Device config thru Scripts/Utilities or Functions */
   /* after config file update, for modify or add operation start all ap/vap */
   if(IFX_DONT_ACTIVATE_F_NOT_SET(flags) &&
      IFX_INT_DONT_CONFIGURE_F_NOT_SET(flags) &&
      IFX_DEACTIVATE_F_NOT_SET(flags))
   {
         sprintf(conf_buf, "%s %d", SERVICE_WLAN_MAC_CTRL_MODIFY, passed_index);
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrlStatus", "conf_buf: %s", conf_buf);
         system(conf_buf);
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrlStatus", "");
   /*********** Epilog Block **************/
   /* this will Compact the section and also update the count for both ADD and DELETE */

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiSetWlanMacCntrlStatus", "ret: %d", ret);
   if(ret != IFX_SUCCESS)
      return ret;
   else
      return IFX_SUCCESS;
}

/**
   this api reads wlan capabilities from /tmp/wlan_caps, which was generated
   during bootup

   \param   wlCaps - pointer to Capability structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_capability(IFX_MAPI_WLAN_Capability *wlCaps, uint32 flags)
{
   int32	   ret = IFX_SUCCESS, i = 0;
   char8    buf[MAX_FILELINE_LEN], sValue[MAX_DATA_LEN], sValueTmp[MAX_DATA_LEN];
   char8    *pTmpStr = NULL, *pTmpStr2 = NULL, *pTmpStr3 = NULL;
   struct timeval tv;

   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);

   NULL_TERMINATE(buf, 0x00, sizeof(buf));

   memset(sValue, 0x00, sizeof(sValue));
   sprintf(buf, "%s", SERVICE_WLAN_GET_DEV_CAP);

   if (ifx_GetCfgData((char8*)buf, NULL, "-1", sValue) == 0)
   {
      ret = IFX_FAILURE;
      goto ifx_handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s", sValue);
   /* save buffer in sValueTmp */
   strcpy(sValueTmp, sValue);

   /* get vendor information */
   if((pTmpStr = strstr(sValue,"vendor")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
		ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
		ret = IFX_FAILURE;
        goto ifx_handler;
      }
      strcpy(wlCaps->vendor, pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "vendor: %s", wlCaps->vendor);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get supported standards */
   if((pTmpStr = strstr(sValue,"standard")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
		ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
		ret = IFX_FAILURE;
        goto ifx_handler;
      }
      i = 0;
      pTmpStr3 = strtok(pTmpStr2, ",");
      while(pTmpStr3 != NULL)
      {
         wlCaps->std[i] = atoi(pTmpStr3);
         /* check if this is a valid standard */
         if (wlCaps->std[i] >= IFX_MAPI_WLAN_MAX_STD)
         {
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "wlCaps->std[%d] = %d; IFX_MAPI_WLAN_MAX_STD = %d", i, wlCaps->std[i], IFX_MAPI_WLAN_MAX_STD);
            ret = IFX_FAILURE;
            goto ifx_handler;
         }
         i++;
         pTmpStr3 = strtok(NULL, ",");
      }
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "Not found in capabilities: \nsValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get supported frequency band */
   if((pTmpStr = strstr(sValue,"freq")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->freq = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "freq: %d", wlCaps->freq);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get supported power levels */
   if((pTmpStr = strstr(sValue,"powerLvl")) != NULL)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "pTmpStr: %s", pTmpStr);
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      i = 0;
      /* now parse the comma separated list */
      pTmpStr3 = strtok(pTmpStr2, ",");
      while ( (pTmpStr3 != NULL) && (i < IFX_MAPI_MAX_POWER_LEVELS) ) {
         wlCaps->powerLevelsSupported[i] = atoi(pTmpStr3);
         /* check if this is a valid value */
         if (wlCaps->powerLevelsSupported[i] > 100) {
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "");
            ret = IFX_FAILURE;
            goto ifx_handler;
         }
         i++;
         pTmpStr3 = strtok(NULL, ",");
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "wlCaps->powerLevelsSupported[%d] = %d", i-1, wlCaps->powerLevelsSupported[i-1]);
      }
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",sValue);


   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get supported security */
   if((pTmpStr = strstr(sValue,"security")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->secType = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "secType: %d", wlCaps->secType);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get radius support */
   if((pTmpStr = strstr(sValue,"radius")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
		ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->radiusSupport = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "radiusSupport: %d", wlCaps->radiusSupport);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get WMM support */
   if((pTmpStr = strstr(sValue,"WMM")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->WMMcapable = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "WMMcapable: %d", wlCaps->WMMcapable);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get UAPSD support */
   if((pTmpStr = strstr(sValue,"UAPSD")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->UAPSDcapable = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "UAPSDcapable: %d", wlCaps->UAPSDcapable);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get WPS support */
   if((pTmpStr = strstr(sValue,"WPS")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->WPScapable = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "WPScapable: %d", wlCaps->WPScapable);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get WPS config methods if WPS is supported */
   if((pTmpStr = strstr(sValue,"WPS_CfgMethods")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      /* supported methods are a comma separated list of integer values */
      i = 0;
      pTmpStr2 = strtok(NULL, ",");
      while(pTmpStr2 != NULL)
      {
         wlCaps->WPSMthdsArray[i++] = atoi(pTmpStr2);
         pTmpStr2 = strtok(NULL, ",");
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "wlCaps->WPSMthdsArray[%d] = %d", i-1, wlCaps->WPSMthdsArray[i-1]);
      }
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get WDS support */
   if((pTmpStr = strstr(sValue,"WDS")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->WDScapable = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "WDScapable: %d", wlCaps->WDScapable);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get WDS repetition count if WDS is supported */
   if((pTmpStr = strstr(sValue,"WDS_RepCount")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->WDSRepsCount = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "WDSRepsCount: %d", wlCaps->WDSRepsCount);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get max. number of supported VAP */
   if((pTmpStr = strstr(sValue,"maxVAP")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->maxVAPSupported = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "maxVAPSupported: %d", wlCaps->maxVAPSupported);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get max. number of clients per VAP */
   if((pTmpStr = strstr(sValue,"maxClientsPerVAP")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->maxClientsPerVAP = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "maxClientsPerVAP: %d", wlCaps->maxClientsPerVAP);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get MAC filtering support */
   if((pTmpStr = strstr(sValue,"macAddrCntrlPerVAP")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->macCntrlPerVAP = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "macCntrlPerVAP: %d", wlCaps->macCntrlPerVAP);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get MAC filtering support */
   if((pTmpStr = strstr(sValue,"numMACCntrlEntries")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->numMacCntrlEntries = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "numMacCntrlEntries: %d", wlCaps->numMacCntrlEntries);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get number of RX antennas */
   if((pTmpStr = strstr(sValue,"numRxAntenna")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->numRxAntns = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "numRxAntenna: %d", wlCaps->numRxAntns);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get number of TX antennas */
   if((pTmpStr = strstr(sValue,"numTxAntenna")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->numTxAntns = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "numTxAntenna: %d", wlCaps->numTxAntns);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get wide channel (40MHz) support */
   if((pTmpStr = strstr(sValue,"wideChanSupport")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->wideChanSupport = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "wideChanSupport: %d", wlCaps->wideChanSupport);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get MCS range */
   if((pTmpStr = strstr(sValue,"MCSrange")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->mcsRange = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "MCSrange: %d", wlCaps->mcsRange);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get A-MPDU support */
   if((pTmpStr = strstr(sValue,"AMPDUsupport")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->ampduSupport = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "AMPDUsupport: %d", wlCaps->ampduSupport);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get A-MSDU support */
   if((pTmpStr = strstr(sValue,"AMSDUsupport")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->amsduSupport = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "AMSDUsupport: %d", wlCaps->amsduSupport);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "sValue: %s",sValue);

ifx_handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "ret: %d", ret);
   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanCapability", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
   return ret;
}

#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
/**
   this api reads secondary wlan capabilities from /tmp/wlan_caps, which was generated
   during bootup

   \param   wlCaps - pointer to Capability structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_sec_capability(IFX_MAPI_WLAN_Capability *wlCaps, uint32 flags)
{
   int32	   ret = IFX_SUCCESS, i = 0;
   char8    buf[MAX_FILELINE_LEN], sValue[MAX_DATA_LEN], sValueTmp[MAX_DATA_LEN];
   char8    *pTmpStr = NULL, *pTmpStr2 = NULL, *pTmpStr3 = NULL;
	/*
   struct timeval tv;

   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
	*/

   NULL_TERMINATE(buf, 0x00, sizeof(buf));

   memset(sValue, 0x00, sizeof(sValue));
   sprintf(buf, "%s", SERVICE_WLAN_GET_DEV_SEC_CAP);

   if (ifx_GetCfgData((char8*)buf, NULL, "-1", sValue) == 0)
   {
      ret = IFX_FAILURE;
      goto ifx_handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s", sValue);
   /* save buffer in sValueTmp */
   strcpy(sValueTmp, sValue);

   /* get vendor information */
   if((pTmpStr = strstr(sValue,"vendor")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
		ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
		ret = IFX_FAILURE;
        goto ifx_handler;
      }
      strcpy(wlCaps->vendor, pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "vendor: %s", wlCaps->vendor);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get supported standards */
   if((pTmpStr = strstr(sValue,"standard")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
		ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
		ret = IFX_FAILURE;
        goto ifx_handler;
      }
      i = 0;
      pTmpStr3 = strtok(pTmpStr2, ",");
      while(pTmpStr3 != NULL)
      {
         wlCaps->std[i] = atoi(pTmpStr3);
         /* check if this is a valid standard */
         if (wlCaps->std[i] >= IFX_MAPI_WLAN_MAX_STD)
         {
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "wlCaps->std[%d] = %d; IFX_MAPI_WLAN_MAX_STD = %d", i, wlCaps->std[i], IFX_MAPI_WLAN_MAX_STD);
            ret = IFX_FAILURE;
            goto ifx_handler;
         }
         i++;
         pTmpStr3 = strtok(NULL, ",");
      }
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "Not found in capabilities: \nsValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get supported frequency band */
   if((pTmpStr = strstr(sValue,"freq")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->freq = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "freq: %d", wlCaps->freq);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get supported power levels */
   if((pTmpStr = strstr(sValue,"powerLvl")) != NULL)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "pTmpStr: %s", pTmpStr);
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      i = 0;
      /* now parse the comma separated list */
      pTmpStr3 = strtok(pTmpStr2, ",");

      while ( (pTmpStr3 != NULL) && (i < IFX_MAPI_MAX_POWER_LEVELS) ) {
         wlCaps->powerLevelsSupported[i] = atoi(pTmpStr3);
         /* check if this is a valid value */
         if (wlCaps->powerLevelsSupported[i] > 100) {
            IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "");
            ret = IFX_FAILURE;
            goto ifx_handler;
         }
         i++;
         pTmpStr3 = strtok(NULL, ",");
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "wlCaps->powerLevelsSupported[%d] = %d", i-1, wlCaps->powerLevelsSupported[i-1]);
      }
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",sValue);


   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get supported security */
   if((pTmpStr = strstr(sValue,"security")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->secType = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "secType: %d", wlCaps->secType);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get radius support */
   if((pTmpStr = strstr(sValue,"radius")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
		ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->radiusSupport = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "radiusSupport: %d", wlCaps->radiusSupport);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get WMM support */
   if((pTmpStr = strstr(sValue,"WMM")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->WMMcapable = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "WMMcapable: %d", wlCaps->WMMcapable);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get UAPSD support */
   if((pTmpStr = strstr(sValue,"UAPSD")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->UAPSDcapable = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "UAPSDcapable: %d", wlCaps->UAPSDcapable);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get WPS support */
   if((pTmpStr = strstr(sValue,"WPS")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->WPScapable = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "WPScapable: %d", wlCaps->WPScapable);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get WPS config methods if WPS is supported */
   if((pTmpStr = strstr(sValue,"WPS_CfgMethods")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      /* supported methods are a comma separated list of integer values */
      i = 0;
      pTmpStr2 = strtok(NULL, ",");
      while(pTmpStr2 != NULL)
      {
         wlCaps->WPSMthdsArray[i++] = atoi(pTmpStr2);
         pTmpStr2 = strtok(NULL, ",");
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "wlCaps->WPSMthdsArray[%d] = %d", i-1, wlCaps->WPSMthdsArray[i-1]);
      }
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get WDS support */
   if((pTmpStr = strstr(sValue,"WDS")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->WDScapable = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "WDScapable: %d", wlCaps->WDScapable);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get WDS repetition count if WDS is supported */
   if((pTmpStr = strstr(sValue,"WDS_RepCount")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->WDSRepsCount = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "WDSRepsCount: %d", wlCaps->WDSRepsCount);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get max. number of supported VAP */
   if((pTmpStr = strstr(sValue,"maxVAP")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->maxVAPSupported = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "maxVAPSupported: %d", wlCaps->maxVAPSupported);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get max. number of clients per VAP */
   if((pTmpStr = strstr(sValue,"maxClientsPerVAP")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->maxClientsPerVAP = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "maxClientsPerVAP: %d", wlCaps->maxClientsPerVAP);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get MAC filtering support */
   if((pTmpStr = strstr(sValue,"macAddrCntrlPerVAP")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->macCntrlPerVAP = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "macCntrlPerVAP: %d", wlCaps->macCntrlPerVAP);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get MAC filtering support */
   if((pTmpStr = strstr(sValue,"numMACCntrlEntries")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->numMacCntrlEntries = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "numMacCntrlEntries: %d", wlCaps->numMacCntrlEntries);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get number of RX antennas */
   if((pTmpStr = strstr(sValue,"numRxAntenna")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->numRxAntns = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "numRxAntenna: %d", wlCaps->numRxAntns);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get number of TX antennas */
   if((pTmpStr = strstr(sValue,"numTxAntenna")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->numTxAntns = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "numTxAntenna: %d", wlCaps->numTxAntns);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get wide channel (40MHz) support */
   if((pTmpStr = strstr(sValue,"wideChanSupport")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->wideChanSupport = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "wideChanSupport: %d", wlCaps->wideChanSupport);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get MCS range */
   if((pTmpStr = strstr(sValue,"MCSrange")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->mcsRange = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "MCSrange: %d", wlCaps->mcsRange);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get A-MPDU support */
   if((pTmpStr = strstr(sValue,"AMPDUsupport")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->ampduSupport = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "AMPDUsupport: %d", wlCaps->ampduSupport);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   /* get A-MSDU support */
   if((pTmpStr = strstr(sValue,"AMSDUsupport")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto ifx_handler;
      }
      wlCaps->amsduSupport = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "AMSDUsupport: %d", wlCaps->amsduSupport);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "sValue: %s",sValue);

ifx_handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "ret: %d", ret);
	/*
   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecCapability", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
	*/
   return ret;
}
#endif //CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS

/**
   This api reads the count and then for each wlan instance gets the cpeid, fills it in the structure
   and calls ifx_mapi_get_wlan_phy_config api with this structure

   \param   numEntries  -

   \param   wlan_phy    - pointer to Phy config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_all_wlan_phy_config(uint32 *numEntries, IFX_MAPI_WLAN_PhyCfg **wlPhyCfg, uint32 flags)
{
   int32	ret = IFX_SUCCESS, nCount = 0, i = 0;
   char8	sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN];
   uint32	outFlag = IFX_F_DEFAULT;
   struct timeval tv;

   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanPhyConfig", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);

   MAKE_SECTION_COUNT_TAG(TAG_WLAN_PHY, buf);
   if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_PHY,
                     buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanPhyConfig", "");
      goto IFX_Handler;
   }

   nCount = atoi(sValue);
   if (nCount == 0) {
      *numEntries = 0;
      *wlPhyCfg = NULL;
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanPhyConfig", "");
      goto IFX_Handler;
   }

   *wlPhyCfg = NULL;
#ifdef CONFIG_FEATURE_IFX_CONCURRENT_DUAL_WIRELESS
   if (nCount <= 2) {
#else
   if (nCount <= 1) {
#endif
	   	   IFX_MEM_ALLOC((*wlPhyCfg), IFX_MAPI_WLAN_PhyCfg *, nCount, sizeof(IFX_MAPI_WLAN_PhyCfg))
   }
   else {
       	   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanPhyConfig", "");
	   	   ret = IFX_FAILURE;
	   	   goto IFX_Handler;
   }

   for (i=0; i < nCount; i++) {
      /* get the cpeid of this instance */
      sprintf(buf, "%s_%d_cpeId", PREFIX_WLAN_PHY, i);
      if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_PHY,
                  buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanPhyConfig", "i=%d, nCount=%d", i, nCount);
         goto IFX_Handler;
      }
      (*wlPhyCfg + i)->iid.cpeId.Id = atoi(sValue);

      if((ret = ifx_mapi_get_wlan_phy_config((*wlPhyCfg + i), flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d] failed to get phy params for instance wlan%d",
                     __FUNCTION__, __LINE__, i);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanPhyConfig", "failed to get phy params for instance wlan%d", i);
         goto IFX_Handler;
      }
   }
   *numEntries = nCount;

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanPhyConfig", "ret: %d", ret);
   if(ret != IFX_SUCCESS) {
      IFX_MEM_FREE(*wlPhyCfg)
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return ret;
   }
   else
      return IFX_SUCCESS;
}

/**
   This api reads wlan phy parameters (such as country, channel no.) from
   rc.conf and returns them in wlan_phy

   \param   wlan_phy - pointer to Phy config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_phy_config(IFX_MAPI_WLAN_PhyCfg *wlan_phy, uint32 flags)
{
   IFX_NAME_VALUE_PAIR  array_fvp[WLAN_PHY_PARAM_COUNT + 1];
   int32    count, i, passed_index = -1, ret = IFX_SUCCESS;
   char8	   sBuf[MAX_FILELINE_LEN], *sValue2 = NULL, buf[MAX_FILELINE_LEN];
   char8	   sValue[MAX_NAME_SIZE];

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPhyConfig", "");

   NULL_TERMINATE(buf, 0x00, sizeof(buf));
   NULL_TERMINATE(sValue, 0x00, sizeof(sValue));

   /* oliver - usually there is only one instance, but in special cases when
      there are two radios, two instances might be available */
   IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlan_phy->iid.cpeId, passed_index)
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPhyConfig", "");

#if 0
   /*
      first get the dynamic information:
      - status
      - channelsInUse
      - channelNo (if autoChannelEna is TRUE)
   */
   if ((ret = ifx_mapi_get_wlan_dyn_phy_config(wlan_phy, flags)) != IFX_SUCCESS) {
	   	   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPhyConfig", "");
	   	   goto IFX_Handler;
   }

   NULL_TERMINATE(buf, 0x00, sizeof(buf));
   memset(sRadioDynInfo, 0x00, sizeof(sRadioDynInfo));
#ifdef CONFIG_FEATURE_IFX_WIRELESS_WAVE300
   sprintf(buf, "%s %d", SERVICE_WLAN_GET_RADIO_DYN_INFO, (wlan_phy->iid.cpeId.Id - 1));
#else
   sprintf(buf, "%s", SERVICE_WLAN_GET_RADIO_DYN_INFO);
#endif
   /* get bssid information */
   if (ifx_GetCfgData((char8*)buf, NULL, "-1", sRadioDynInfo) == 0)
   {
      ret = IFX_FAILURE;
      goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPhyConfig", "sRadioDynInfo: %s", sRadioDynInfo);

   /* save buffer in sRadioDynTmp */
   strcpy(sRadioDynTmp, sRadioDynInfo);

   /* get status information */
   if((pTmpStr = strstr(sRadioDynInfo,"status=")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto IFX_Handler;
      }
      wlan_phy->status = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPhyConfig", "status: %d", wlan_phy->status);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPhyConfig", "sRadioDynInfo: %s",sRadioDynInfo);

   /* restore sValue buffer from sValueTmp */
   strcpy(sRadioDynInfo, sRadioDynTmp);

   /* get channel information */
   if((pTmpStr = strstr(sRadioDynInfo,"channel=")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto IFX_Handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
	ret = IFX_FAILURE;
        goto IFX_Handler;
      }
      wlan_phy->channelNo = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPhyConfig", "channel: %d", wlan_phy->channelNo);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPhyConfig", "sRadioDynInfo: %s",sRadioDynInfo);

   /* restore sValue buffer from sValueTmp */
   strcpy(sRadioDynInfo, sRadioDynTmp);
   /**
      \todo channelsInUse
   */
#endif /* #if 0 */

   sprintf(sBuf, "%s_%d_", PREFIX_WLAN_PHY, passed_index);
   if((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_PHY, sBuf, flags, &sValue2)) != IFX_SUCCESS)
      goto IFX_Handler;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPhyConfig", "sBuf: %s, passed_index: %d, sValue2: %s", sBuf, passed_index, sValue2);

   memset(array_fvp, 0x00, sizeof(array_fvp));
   form_array_fvp_from_cfgdb_buf(sValue2, &count, array_fvp);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPhyConfig", "count: %d", count);
   for (i = 0; i < count; i++)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPhyConfig", "%s:%s", array_fvp[i].fieldname, array_fvp[i].value);

   wlan_phy->iid.cpeId.Id                       = atoi(array_fvp[0].value);
   wlan_phy->iid.pcpeId.Id                      = atoi(array_fvp[1].value);
   wlan_phy->standard                           = atoi(array_fvp[2].value);
   snprintf(wlan_phy->country, sizeof(wlan_phy->country), "%s", array_fvp[3].value);
   wlan_phy->usageEnv                           = atoi(array_fvp[4].value);
   wlan_phy->freqBand                           = atoi(array_fvp[5].value);
   wlan_phy->channelNo							= atoi(array_fvp[6].value);
   wlan_phy->autoChannelEna                     = atoi(array_fvp[7].value);
   wlan_phy->beaconTxEna                        = atoi(array_fvp[8].value);
   wlan_phy->beaconIntvl                        = atoi(array_fvp[9].value);
   wlan_phy->dtimInt                            = atoi(array_fvp[10].value);
   wlan_phy->rts                                = atoi(array_fvp[11].value);
   wlan_phy->fts                                = atoi(array_fvp[12].value);
   wlan_phy->powerLvl                           = atoi(array_fvp[13].value);
   wlan_phy->radioEnable                        = atoi(array_fvp[14].value);
   wlan_phy->autoRateFallBackEna                = atoi(array_fvp[15].value);
   wlan_phy->staticRate                         = atof(array_fvp[16].value);
   wlan_phy->preamble                           = atoi(array_fvp[17].value);
   wlan_phy->phy11N.chanBW                      = atoi(array_fvp[18].value);
   wlan_phy->phy11N.extChPos                    = atoi(array_fvp[19].value);
   wlan_phy->phy11N.guardIntvl                  = atoi(array_fvp[20].value);
   wlan_phy->phy11N.mcs                         = atoi(array_fvp[21].value);
   wlan_phy->phy11N.diversity.diversityEna      = atoi(array_fvp[22].value);
   wlan_phy->phy11N.diversity.diversityDir      = atoi(array_fvp[23].value);
   wlan_phy->phy11N.diversity.antenna           = atoi(array_fvp[24].value);
   wlan_phy->phy11N.rxStbc                      = atoi(array_fvp[25].value);
   wlan_phy->phy11N.baWinSize                   = atoi(array_fvp[26].value);
   wlan_phy->phy11N.aggr.ampduEna               = atoi(array_fvp[27].value);
   wlan_phy->phy11N.aggr.ampduDir               = atoi(array_fvp[28].value);
   wlan_phy->phy11N.aggr.ampduLen               = atoi(array_fvp[29].value);
   wlan_phy->phy11N.aggr.ampduFrmsDensity       = atoi(array_fvp[30].value);
   wlan_phy->phy11N.aggr.amsduEna               = atoi(array_fvp[31].value);
   wlan_phy->phy11N.aggr.amsduDir               = atoi(array_fvp[32].value);
   wlan_phy->phy11N.aggr.amsduLen               = atoi(array_fvp[33].value);
#if 0
   wlan_phy->phy11N.greenfieldEna               = atoi(array_fvp[34].value);
#endif

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPhyConfig", "ret: %d", ret);
   /* free buffer allocated in ifx_GetCfgObject */
   IFX_MEM_FREE(sValue2);
   if(ret != IFX_SUCCESS) {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return IFX_FAILURE;
   }
   else
      return IFX_SUCCESS;
}

/**
   This api reads wlan phy parameters (such as country, channel no.) from
   rc.conf and returns them in wlan_phy

   \param   wlan_phy - pointer to Phy config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_dyn_phy_config(IFX_MAPI_WLAN_PhyCfg *wlan_phy, uint32 flags)
{
		int32    			ret = IFX_SUCCESS;
		char8	   			buf[MAX_FILELINE_LEN];
		char8				sParamValue[MAX_FILELINE_LEN];
		char8				sRadioDynInfo[MAX_DATA_LEN];

		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_phy_config", "");

		NULL_TERMINATE(buf, 0x00, sizeof(buf));
		NULL_TERMINATE(sParamValue, 0x00, sizeof(sParamValue));

		/*
		 * get the dynamic information:
		 * - status
		 * - channelsInUse
		 * - channelNo (if autoChannelEna is TRUE)
		*/
		NULL_TERMINATE(buf, 0x00, sizeof(buf));
		memset(sRadioDynInfo, 0x00, sizeof(sRadioDynInfo));
		sprintf(buf, "%s %d", SERVICE_WLAN_GET_RADIO_DYN_INFO, (wlan_phy->iid.cpeId.Id - 1));

		/* get bssid information */
		if (ifx_GetCfgData((char8*)buf, NULL, "-1", sRadioDynInfo) == 0) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_phy_config", "sRadioDynInfo: %s", sRadioDynInfo);

		/* save buffer in sResultFromScript */
		strcpy(sResultFromScript, sRadioDynInfo);

		if ( (ret = ltq_get_param("status=", sParamValue)) != IFX_SUCCESS) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_phy_config", "Status not available");
				goto IFX_Handler;
		}
		wlan_phy->status = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_phy_config", "status: %d", wlan_phy->status);

		if ( (ret = ltq_get_param("channel=", sParamValue)) != IFX_SUCCESS) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_phy_config", "Status not available");
				goto IFX_Handler;
		}
		wlan_phy->channelNo = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_phy_config", "channel: %d", wlan_phy->channelNo);

#if 0
		/* get status information */
		if((pTmpStr = strstr(sRadioDynInfo,"status=")) != NULL) {
				pTmpStr2 = strtok(pTmpStr, "\"");
				pTmpStr2 = strtok(NULL, "\"");
				if(pTmpStr2 == NULL) {
						ret = IFX_FAILURE;
						goto IFX_Handler;
				}
				wlan_phy->status = atoi(pTmpStr2);
				IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_phy_config", "status: %d", wlan_phy->status);
		}
		else
				IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_phy_config", "sRadioDynInfo: %s",sRadioDynInfo);

		/* restore sValue buffer from sValueTmp */
		strcpy(sRadioDynInfo, sRadioDynTmp);

		/* get channel information */
		if((pTmpStr = strstr(sRadioDynInfo,"channel=")) != NULL) {
				pTmpStr2 = strtok(pTmpStr, "\"");
				if(pTmpStr2 == NULL) {
						ret = IFX_FAILURE;
						goto IFX_Handler;
				}
				pTmpStr2 = strtok(NULL, "\"");
				if(pTmpStr2 == NULL) {
						ret = IFX_FAILURE;
						goto IFX_Handler;
				}
				wlan_phy->channelNo = atoi(pTmpStr2);
				IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_phy_config", "channel: %d", wlan_phy->channelNo);
		}
		else
				IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_phy_config", "sRadioDynInfo: %s",sRadioDynInfo);

		/* restore sValue buffer from sValueTmp */
		strcpy(sRadioDynInfo, sRadioDynTmp);
		/**
			\todo channelsInUse
		*/
#endif
IFX_Handler:
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_phy_config", "ret: %d", ret);
		return ret;
}

/**
   This api reads wlan main parameters from rc.conf and returns them in wlan_main

   \param   wlan_main - pointer to Main config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE

   \note - pcpeid for each ap/vap (instance in wlan main) is lan device
*/
int32 ifx_mapi_get_wlan_main_config(IFX_MAPI_WLAN_MainCfg *wlan_main, uint32 flags)
{
   int32	            passed_index = -1, ret = IFX_SUCCESS, count = 0, i = 0;
   char8	            buf[MAX_FILELINE_LEN], *ptr = NULL, *sValue = NULL;
   char8	            sBuf[MAX_FILELINE_LEN];
   IFX_NAME_VALUE_PAIR	array_fvp[WLAN_MAIN_PARAM_COUNT + 1];

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMainConfig", "");

   sprintf(wlan_main->iid.cpeId.secName, "%s", TAG_WLAN_MAIN);

   /*
      get index from cpeid: example wlmn_1_cpeId="3" => passed_index = 1
   */
   IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlan_main->iid.cpeId, passed_index)
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMainConfig", "passed_index: %d", passed_index);

   sprintf(sBuf, "%s_%d_", PREFIX_WLAN_MAIN, passed_index);
   if((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_MAIN, sBuf, flags, &sValue)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMainConfig",
                         "sBuf: %s, passed_index: %d, cpeId: %s, cpeId: %d",
                         sBuf, passed_index, wlan_main->iid.cpeId.secName,
                         wlan_main->iid.cpeId.Id);
      goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMainConfig", "sBuf: %s, passed_index: %d, sValue: %s", sBuf, passed_index, sValue);

   memset(array_fvp, 0x00, sizeof(array_fvp));
   form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMainConfig", "count: %d", count);
   for (i = 0; i < count; i++)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMainConfig", "%s:%s", array_fvp[i].fieldname, array_fvp[i].value);

   wlan_main->iid.cpeId.Id    = atoi(array_fvp[0].value);
   wlan_main->iid.pcpeId.Id   = atoi(array_fvp[1].value);
   wlan_main->radioCpeId      = atoi(array_fvp[2].value);
   wlan_main->apEnable        = atoi(array_fvp[3].value);
   snprintf(wlan_main->apName, IFX_MAPI_WLAN_AP_NAME, "%s", array_fvp[4].value);
   wlan_main->devType         = atoi(array_fvp[5].value);
   snprintf(wlan_main->ssid, IFX_MAPI_WLAN_SSID_LEN, "%s", array_fvp[6].value);
   wlan_main->ssidMode        = atoi(array_fvp[7].value);
   wlan_main->bssidOverride   = atoi(array_fvp[8].value);

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMainConfig", "ssid: %s", wlan_main->ssid);
#if 0
   if (!wlan_main->bssidOverride)
   {
	   if (passed_index < 0) {
		   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMainConfig",
				   "passed_index: %d", passed_index);
		   ret = IFX_FAILURE;
		   goto IFX_Handler;
	   }
	   memset(sApInfo, 0x00, sizeof(sApInfo));
	   sprintf(buf, "%s %d", SERVICE_WLAN_GET_AP_DYN_INFO, passed_index);

      /* get bssid information */
      if (ifx_GetCfgData((char8*)buf, NULL, "-1", sApInfo) == 0)
      {
         ret = IFX_FAILURE;
         goto IFX_Handler;
      }
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMainConfig", "sApInfo: %s", sApInfo);

      /* get vendor information */
      if((pTmpStr = strstr(sApInfo,"bssid")) != NULL)
      {
         pTmpStr2 = strtok(pTmpStr, "\"");
         if(pTmpStr2 == NULL)
         {
 	    ret = IFX_FAILURE;
            goto IFX_Handler;
         }
         pTmpStr2 = strtok(NULL, "\"");
	 if(pTmpStr2 == NULL)
	 {
	     ret = IFX_FAILURE;
             goto IFX_Handler;
	 }
	 if(strlen(pTmpStr2)==17 && *(pTmpStr2 + 2)==':' && *(pTmpStr2 + 5)==':' && *(pTmpStr2 + 8)==':'  && *(pTmpStr2 + 11)==':'  && *(pTmpStr2 + 14)==':' ){
         	strcpy(wlan_main->bssid, pTmpStr2);
		if(strchr(wlan_main->bssid,'\n'))
		    strcpy(wlan_main->bssid,"");
	 }
	 else 
		strcpy(wlan_main->bssid,"");
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMainConfig", "bssid: %s", wlan_main->bssid);
      }
   }
   else
   {
    	if(strlen(array_fvp[9].value)==17) {
	    sprintf(wlan_main->bssid, "%s", array_fvp[9].value);
	} else {
	    strcpy(wlan_main->bssid,"");
	}
   }
#endif /* #if 0 */

   /*
    * parse the string based on ',' and store it in array basicDataRates
    */
   i = 0;
   sprintf(buf, "%s", array_fvp[10].value);
   ptr = strtok(buf, ",");
   while(ptr != NULL) {
      wlan_main->basicDataRates[i++] = atof(ptr);
      ptr = strtok(NULL, ",");
   }
   wlan_main->basicDataRates[i] = 0;

   //wlan_main->operDataRates = 0; /* Pramod - is it stored as comma seperated ?? */
   /* parse the string based on ',' and store it in array operationalDataRates */
   i = 0;
   sprintf(buf, "%s", array_fvp[11].value);
   ptr = strtok(buf, ",");
   while(ptr != NULL) {
      wlan_main->operDataRates[i++] = atof(ptr);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMainConfig", "operDataRate[%d]: %.1f", i-1, wlan_main->operDataRates[i-1]);
      ptr = strtok(NULL, ",");
   }
   wlan_main->operDataRates[i] = 0;
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMainConfig", "operDataRate[%d]: %.1f", i, wlan_main->operDataRates[i]);

   wlan_main->maxBitRate = (float)strtod(array_fvp[12].value, (char **)NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMainConfig", "maxBitRate: %f",
                      wlan_main->maxBitRate);
#if 0
   atoi(array_fvp[12].value); /*again atoi for uint !?*/

   /*
      \todo get index of phy configuration, currently hardcoded to zero
   */
   sprintf(buf, "%s_%d_standard", PREFIX_WLAN_PHY, 0); /* single instance, so using index 0 */
   if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_PHY,
         buf, IFX_F_GET_ANY, &outFlag, sBuf)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMainConfig", "");
      goto IFX_Handler;
   }
#endif

   wlan_main->vlanId          = atoi(array_fvp[13].value);
   wlan_main->apIsolationEna  = atoi(array_fvp[14].value);
   wlan_main->WMMena          = atoi(array_fvp[15].value);
   wlan_main->UAPSDena        = atoi(array_fvp[16].value);
   wlan_main->WDSena          = atoi(array_fvp[17].value);
   wlan_main->WPSena          = atoi(array_fvp[18].value);
   wlan_main->maxStations     = atoi(array_fvp[19].value); 

#ifdef IFX_MAPI_WLAN_WPS
#if 0 // Kamal: commenting this for the integratin of wave300 scripts. need to be reverted once the scripts are in place
   if (wlan_main->apEnable)
   {
      if ((ret = mapiWlanGetSsidFromWps(wlan_main, passed_index)) != IFX_SUCCESS)
      {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMainConfig", "");
         goto IFX_Handler;
      }
   }
#endif
#endif /* #ifdef IFX_MAPI_WLAN_WPS */

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMainConfig", "ret: %d", ret);
   IFX_MEM_FREE(sValue)
   return ret;
}

/**
   This api reads dynamic wlan ap info from scripts and returns them in wlan_main

   \param   wlan_main - pointer to Main config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE

   \note - pcpeid for each ap/vap (instance in wlan main) is lan device
*/
int32 ifx_mapi_get_wlan_dyn_vap_info(IFX_MAPI_WLAN_MainCfg *wlan_main, uint32 flags)
{
		int32	passed_index = -1, ret = IFX_SUCCESS;
		char8	buf[MAX_FILELINE_LEN], *sValue = NULL;
		char8	sParamValue[MAX_FILELINE_LEN], sApInfo[MAX_DATA_LEN];

		sprintf(wlan_main->iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
		NULL_TERMINATE(sParamValue, 0x00, sizeof(sParamValue));

		/*
		 * get index from cpeid: example wlmn_1_cpeId="3" => passed_index = 1
		 */
		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlan_main->iid.cpeId, passed_index)
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_vap_info", "passed_index: %d", passed_index);

		if (passed_index < 0) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_vap_info",
						"passed_index: %d", passed_index);
				ret = IFX_FAILURE;
				goto IFX_Handler;
		}
		memset(sApInfo, 0x00, sizeof(sApInfo));
		sprintf(buf, "%s %d", SERVICE_WLAN_GET_AP_DYN_INFO, passed_index);

		/* get the dynamic information */
		if (ifx_GetCfgData((char8*)buf, NULL, "-1", sApInfo) == 0) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_vap_info", "sApInfo: %s", sApInfo);

		/* save buffer in global variable sResultFromScript */
		strcpy(sResultFromScript, sApInfo);

		if ( (ret = ltq_get_param("status=", sParamValue)) != IFX_SUCCESS) {
				IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_vap_info", "BSSID not available");
				goto IFX_Handler;
		}
		wlan_main->status = atoi(sParamValue);
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_vap_info", "status: %d", wlan_main->status);

#if 0
		if (!wlan_main->bssidOverride) {
				/* get vendor information */
				if((pTmpStr = strstr(sApInfo,"bssid")) != NULL) {
						pTmpStr2 = strtok(pTmpStr, "\"");
						if(pTmpStr2 == NULL) {
								ret = IFX_FAILURE;
								goto IFX_Handler;
						}
						pTmpStr2 = strtok(NULL, "\"");
						if(pTmpStr2 == NULL) {
								ret = IFX_FAILURE;
								goto IFX_Handler;
						}
						if(strlen(pTmpStr2)==17 && *(pTmpStr2 + 2)==':' && *(pTmpStr2 + 5)==':' && *(pTmpStr2 + 8)==':'  && *(pTmpStr2 + 11)==':'  && *(pTmpStr2 + 14)==':' ) {
								strcpy(wlan_main->bssid, pTmpStr2);
								if(strchr(wlan_main->bssid,'\n'))
										strcpy(wlan_main->bssid,"");
						}
						else
								strcpy(wlan_main->bssid,"");
						IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_vap_info", "bssid: %s", wlan_main->bssid);
				}
		}
#endif /* #if 0 */

IFX_Handler:
		IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_dyn_vap_info", "ret: %d", ret);
		IFX_MEM_FREE(sValue)
		return ret;
}

/**
   This api gets a complete wep configuration, containing a set of four wep
   keys, the encryption type and level (ASCII or HEX, 64 or 128 bit) and
   the selected index.

   \param   wlWepCfg - pointer to IFX_MAPI_WLAN_WEP_Cfg structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_wep_config(IFX_MAPI_WLAN_WEP_Cfg *wlWepCfg, uint32 flags)
{
   int32	   ret = IFX_SUCCESS, passed_index = -1;
   char8	   buf[MAX_DATA_LEN];
   CPE_ID   cpe_id;
   char8	               *sValueNew = NULL;
   int32                count, i;
   IFX_NAME_VALUE_PAIR  array_fvp[WLAN_SEC_PARAM_COUNT + 1];
	/*
   struct timeval tv;

   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWepConfig", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
	*/

   sprintf(cpe_id.secName, "%s", TAG_WLAN_SEC);
   cpe_id.Id = wlWepCfg->wepKey[0].iid.pcpeId.Id;
   /*
      get index from pcpeid, we need the index of the AP, i.e. the configuration
      index of the parent object (wlan_sec), therefore we use the pcpeId here
   */
   IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id, passed_index)
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWepConfig", "passed_index:%d", passed_index);

   /* get wps object from rc.conf */
   sprintf(buf, "%s_%d_", PREFIX_WLAN_SEC, passed_index);
   if((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_SEC, buf, flags, &sValueNew)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWepConfig", "buf: %s", buf);
      goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWepConfig", "buf: %s, sValue: %s",
                  buf, sValueNew);

   /* form an array of field value pairs for easier access to parameters */
   memset(array_fvp, 0x00, sizeof(array_fvp));
   form_array_fvp_from_cfgdb_buf(sValueNew, &count, array_fvp);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWepConfig", "count: %d", count);
   for (i = 0; i < count; i++)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWepConfig", "%s:%s", array_fvp[i].fieldname, array_fvp[i].value);

   wlWepCfg->wepEncrLevel  = atoi(array_fvp[11].value);
   wlWepCfg->wepKeyType    = atoi(array_fvp[12].value);
   wlWepCfg->wepKeyIndex   = atoi(array_fvp[13].value);
   
   IFX_MEM_FREE(sValueNew);
   /* now get wep keys */
   /* get wep object from rc.conf */
   sprintf(buf, "%s%d_", PREFIX_WLAN_WEP, wlWepCfg->wepKey[0].iid.pcpeId.Id);
   if((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_WEP, buf, flags, &sValueNew)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWepConfig", "buf: %s", buf);
      goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWepConfig", "buf: %s, sValue: %s",
                  buf, sValueNew);

   /* form an array of field value pairs for easier access to parameters */
   memset(array_fvp, 0x00, sizeof(array_fvp));
   form_array_fvp_from_cfgdb_buf(sValueNew, &count, array_fvp);
   for (i = 0; i < count; i++)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWepConfig", "%s:%s",
                     array_fvp[i].fieldname, array_fvp[i].value);

   wlWepCfg->wepKey[0].iid.cpeId.Id    = atoi(array_fvp[0].value);
   wlWepCfg->wepKey[0].iid.pcpeId.Id   = atoi(array_fvp[1].value);
   snprintf(wlWepCfg->wepKey[0].wepKey, IFX_MAPI_WEP_KEY_MAX_LEN, "%s", array_fvp[2].value);
   wlWepCfg->wepKey[1].iid.cpeId.Id    = atoi(array_fvp[3].value);
   wlWepCfg->wepKey[1].iid.pcpeId.Id   = atoi(array_fvp[4].value);
   snprintf(wlWepCfg->wepKey[1].wepKey, IFX_MAPI_WEP_KEY_MAX_LEN, "%s", array_fvp[5].value);
   wlWepCfg->wepKey[2].iid.cpeId.Id    = atoi(array_fvp[6].value);
   wlWepCfg->wepKey[2].iid.pcpeId.Id   = atoi(array_fvp[7].value);
   snprintf(wlWepCfg->wepKey[2].wepKey, IFX_MAPI_WEP_KEY_MAX_LEN, "%s", array_fvp[8].value);
   wlWepCfg->wepKey[3].iid.cpeId.Id    = atoi(array_fvp[9].value);
   wlWepCfg->wepKey[3].iid.pcpeId.Id   = atoi(array_fvp[10].value);
   snprintf(wlWepCfg->wepKey[3].wepKey, IFX_MAPI_WEP_KEY_MAX_LEN, "%s", array_fvp[11].value);

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWepConfig", "ret: %d", ret);
   IFX_MEM_FREE(sValueNew);
	/*
   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanWepConfig", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
	*/
   return ret;
}

#if 0
/**
   This api will get the complete WEP configuration a particular ap defined by
   mainCpeId and it assumes that there are only 4 wep key instances.

   \param   mainCpeId  -

   \param   wlWepCfg      - pointer to WLAN Main config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_all_wlan_wep_config(uint32 mainCpeId, IFX_MAPI_WLAN_WEP_Cfg **wlWepCfg, uint32 flags)
{
   int32	   ret = IFX_SUCCESS;
   int32    passed_index = -1, i = 0;
   CPE_ID   cpe_id;
   char8	   buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
   uint32	outFlag = IFX_F_DEFAULT;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanWepConfig", "");

#if 1
   sprintf(cpe_id.secName, "%s", TAG_WLAN_SEC);
   cpe_id.Id = mainCpeId;

   /* get index from cpeid first */
   IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id, passed_index)

   sprintf(buf, "%s_%d_wepEncrLvl", PREFIX_WLAN_SEC, passed_index);
   if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_SEC,
      buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif /* #ifdef IFX_LOG_DEBUG */
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanWepConfig", "");
      goto IFX_Handler;
   }
   (*wlWepCfg)->wepEncrLevel = atoi(sValue);

   sprintf(buf, "%s_%d_wepKeyIndx", PREFIX_WLAN_SEC, passed_index);
   if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_SEC,
      buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif /* #ifdef IFX_LOG_DEBUG */
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanWepConfig", "");
      goto IFX_Handler;
   }
   (*wlWepCfg)->wepKeyIndex = atoi(sValue);

   sprintf(buf, "%s_%d_wepKeyType", PREFIX_WLAN_SEC, passed_index);
   if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_SEC,
      buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif /* #ifdef IFX_LOG_DEBUG */
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanWepConfig", "");
      goto IFX_Handler;
   }
   (*wlWepCfg)->wepKeyType = atoi(sValue);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanWepConfig", "wepKeyType: %d", (*wlWepCfg)->wepKeyType);

#if 0
   for(i=0; i<IFX_MAPI_NUM_WEP_KEYS; i++)
      wlSec->secParams.wepCfg.wepKey[i].iid.pcpeId.Id = wlSec->iid.cpeId.Id;
#endif

   for(i=0; i<IFX_MAPI_NUM_WEP_KEYS; i++)
   {
      (*wlWepCfg)->wepKey[i].iid.pcpeId.Id = mainCpeId;
      if((ret = ifx_mapi_get_wlan_wep_config(*wlWepCfg + i, flags)) != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif /* #ifdef IFX_LOG_DEBUG */
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanWepConfig", "");
         goto IFX_Handler;
      }
   }

IFX_Handler:
#endif /* #if 0 */
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanWepConfig", "ret: %d", ret);
   if(ret != IFX_SUCCESS) {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return ret;
   }
   else
      return IFX_SUCCESS;
}
#endif /* #if 0 */

/**
   This api reads

   \param keyIdx

   \param   wlPersonal - pointer to IFX_MAPI_WLAN_PersonalCfg structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE

   \note - assume instance no. is always 1 for any instance but prefix is unique, pcpeid is must
*/
int32 ifx_mapi_get_wlan_personal_config(IFX_MAPI_WLAN_PersonalCfg *wlPersonal, uint32 flags)
{
   int32	               ret = IFX_SUCCESS, passed_index = -1, count, i;
   CPE_ID	            pcpeId_wl802_1X;
   char8	               buf[MAX_DATA_LEN], *sValueNew = NULL;
   IFX_NAME_VALUE_PAIR  array_fvp[WLAN_802_1X_PARAM_COUNT + 1];
	/*
   struct timeval tv;

   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPersonalConfig", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
	*/

   sprintf(wlPersonal->psk.iid.cpeId.secName, "%s", TAG_WLAN_PASSPHRASE);
   sprintf(wlPersonal->psk.iid.pcpeId.secName, "%s", TAG_WLAN_SEC);

   /* get wlpsk object from rc.conf */
   sprintf(buf, "%s%d_0_", PREFIX_WLAN_PASSPHRASE, wlPersonal->psk.iid.pcpeId.Id);
   if((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_PASSPHRASE, buf, flags, &sValueNew)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPersonalConfig", "buf: %s", buf);
      goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPersonalConfig", "buf: %s, sValue: %s",
                  buf, sValueNew);

   /* form an array of field value pairs for easier access to parameters */
   memset(array_fvp, 0x00, sizeof(array_fvp));
   form_array_fvp_from_cfgdb_buf(sValueNew, &count, array_fvp);
   for (i = 0; i < count; i++)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPersonalConfig", "%s:%s",
                     array_fvp[i].fieldname, array_fvp[i].value);

   wlPersonal->psk.iid.cpeId.Id        = atoi(array_fvp[0].value);
   wlPersonal->psk.iid.pcpeId.Id       = atoi(array_fvp[1].value);
   wlPersonal->pskType                 = atoi(array_fvp[2].value);
   if (wlPersonal->pskType == IFX_MAPI_WLAN_ASCII_KEY)
      snprintf(wlPersonal->psk.passPhrase, IFX_MAPI_PASSPHRASE_MAX_LEN, "%s", array_fvp[3].value);
   else
   {
      if (strlen(array_fvp[4].value) > 0)
      {
         snprintf(wlPersonal->psk.preSharedKey, IFX_MAPI_PSK_MAX_LEN, "%s", array_fvp[4].value);
         wlPersonal->pskType = IFX_MAPI_WLAN_HEX_KEY;
      }
   }

   /*
      get group key update interval and group key enable from WLAN_802_1X object;
      a different index is required for this
   */
   sprintf(pcpeId_wl802_1X.secName, "%s", TAG_WLAN_1X);
   pcpeId_wl802_1X.Id   = wlPersonal->psk.iid.pcpeId.Id;
   IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, pcpeId_wl802_1X, passed_index)
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPersonalConfig", "passed_index: %d",
                  passed_index);

   /* get wl1x object from rc.conf */
   IFX_MEM_FREE(sValueNew);
   sprintf(buf, "%s_%d_", PREFIX_WLAN_SEC_1X, passed_index);
   if((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_1X, buf, flags, &sValueNew)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPersonalConfig", "buf: %s", buf);
      goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPersonalConfig", "buf: %s, sValue: %s",
                  buf, sValueNew);

   /* form an array of field value pairs for easier access to parameters */
   memset(array_fvp, 0x00, sizeof(array_fvp));
   form_array_fvp_from_cfgdb_buf(sValueNew, &count, array_fvp);
   for (i = 0; i < count; i++)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPersonalConfig", "%s:%s",
                     array_fvp[i].fieldname, array_fvp[i].value);

   wlPersonal->groupKeyIntvl  = atoi(array_fvp[3].value);
   wlPersonal->groupKeyEna    = atoi(array_fvp[2].value);

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPersonalConfig", "ret: %d", ret);
   IFX_MEM_FREE(sValueNew);
	/*
   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanPersonalConfig", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
	*/
   return ret;
}


/**
   This API queries WLAN security configuration for given AP/VAP specified by
   CpeId (wlSec->iid.cpeId.Id)

   \param   wlSec - pointer to IFX_MAPI_WLAN_SecCfg config structure,
                    wlSec->iid.cpeId.Id already must have been filled

   \param   flags - valid flag

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_security_config(IFX_MAPI_WLAN_SecCfg *wlSec, uint32 flags)
{
   int32    passed_index = -1, ret = IFX_SUCCESS, i = 0, count;
   char8	   buf[MAX_FILELINE_LEN], *sValue = NULL;
   CPE_ID	cpe_id;
   IFX_NAME_VALUE_PAIR  array_fvp[WLAN_SEC_PARAM_COUNT + 1];
	/*
   struct timeval tv;

   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecurityConfig", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
	*/

   memset(&cpe_id, 0x00, sizeof(cpe_id));

   sprintf(cpe_id.secName, "%s", TAG_WLAN_SEC);
   cpe_id.Id = wlSec->iid.cpeId.Id;

   /* get index from cpeid first */
   IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id, passed_index)

   sprintf(buf, "%s_%d_", PREFIX_WLAN_SEC, passed_index);
   if((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_SEC, buf, flags, &sValue))
       != IFX_SUCCESS)
      goto IFX_Handler;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecurityConfig",
                      "buf: %s, passed_index: %d, sValue: %s",
                      buf, passed_index, sValue);

   /* form an array of field value pairs for easier access to parameters */
   memset(array_fvp, 0x00, sizeof(array_fvp));
   form_array_fvp_from_cfgdb_buf(sValue, &count, array_fvp);

   for (i = 0; i < count; i++)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecurityConfig", "%s:%s",
                         array_fvp[i].fieldname, array_fvp[i].value);

   wlSec->iid.cpeId.Id     = atoi(array_fvp[0].value);
   wlSec->iid.pcpeId.Id    = atoi(array_fvp[1].value);
   wlSec->beaconType       = atoi(array_fvp[2].value);
   wlSec->wlAuth           = atoi(array_fvp[3].value);
   wlSec->wlEncr           = atoi(array_fvp[4].value);
   wlSec->basicAuth        = atoi(array_fvp[5].value);
   wlSec->basicEncr        = atoi(array_fvp[6].value);
   wlSec->wpaAuth          = atoi(array_fvp[7].value);
   wlSec->wpaEncr          = atoi(array_fvp[8].value);
   wlSec->wpa2Auth         = atoi(array_fvp[9].value);
   wlSec->wpa2Encr         = atoi(array_fvp[10].value);
   wlSec->macAddrCntrlEna  = atoi(array_fvp[14].value);

   /*
      if beacon type is basic, call api to get all wep keys;
      note: even if encryption type is none, get the wep configuration, because
      for beacon type basic, wep is the only possible encryption
   */
   if(wlSec->beaconType == IFX_MAPI_WLAN_BEACON_BASIC)
   {
      /* get wep configuration */
      /* fill pcpeid before calling the api */
      for(i=0; i<IFX_MAPI_NUM_WEP_KEYS; i++)
         wlSec->secParams.wepCfg.wepKey[i].iid.pcpeId.Id = wlSec->iid.cpeId.Id;

      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecurityConfig", "wlSec->iid.cpeId.Id: %d", wlSec->iid.cpeId.Id);
      if((ret = ifx_mapi_get_wlan_wep_config( &wlSec->secParams.wepCfg, flags) != IFX_SUCCESS))
      {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecurityConfig", "");
         goto IFX_Handler;
      }
   }
   else if((wlSec->beaconType >= IFX_MAPI_WLAN_BEACON_WPA) && (wlSec->wlAuth == IFX_MAPI_WLAN_AUTH_PERSONAL))
   {
      wlSec->secParams.personalCfg.pskType = IFX_MAPI_WLAN_ASCII_KEY;

      /* if beacon type is wpa then call api to get passphrase */
      /* get passphrase configuration */
      wlSec->secParams.personalCfg.psk.iid.pcpeId.Id = wlSec->iid.cpeId.Id;
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecurityConfig", "pcpeID: %d", wlSec->secParams.personalCfg.psk.iid.pcpeId.Id);
      if((ret = ifx_mapi_get_wlan_personal_config(&wlSec->secParams.personalCfg, flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecurityConfig", "");
         goto IFX_Handler;
      }
   }
   else if((wlSec->beaconType >= IFX_MAPI_WLAN_BEACON_WPA) && (wlSec->wlAuth == IFX_MAPI_WLAN_AUTH_RADIUS))
   {
      /*
         if beacon type is wpa and auth type radius, then call api to get
         802.1x configuration
      */
      wlSec->secParams.wlRadius.iid.pcpeId.Id = wlSec->iid.cpeId.Id;
      if((ret = ifx_mapi_get_wlan_802_1x_config(&wlSec->secParams.wlRadius, flags)) != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecurityConfig", "");
         goto IFX_Handler;
      }
   }

#ifdef IFX_MAPI_WLAN_WPS
   if ((ret = mapiWlanGetSecurityConfigFromWps(wlSec, passed_index)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecurityConfig", "");
      goto IFX_Handler;
   }
#endif /* #ifdef IFX_MAPI_WLAN_WPS */
IFX_Handler:
   IFX_MEM_FREE(sValue);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecurityConfig", "ret: %d", ret);
	/*
   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanSecurityConfig", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
	*/
   return ret;
}

/**
   This api reads the count and then for each IFX_MAPI_WLAN_SecCfg instance gets
   cpeid, fills it in the structure	and calls ifx_mapi_get_wlan_security_config
   api with this structure

   \param   numEntries  -

   \param   wlSec - pointer to IFX_MAPI_WLAN_SecCfg Main config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_all_wlan_security_config(
      uint32 *numEntries, IFX_MAPI_WLAN_SecCfg **wlSec, uint32 flags)
{
   int32    ret = IFX_SUCCESS, nCount = 0, i = 0;
   char8	   sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN];
   uint32	outFlag = IFX_F_DEFAULT;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanSecurityConfig", "");

   MAKE_SECTION_COUNT_TAG(TAG_WLAN_SEC, buf);
   if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_SEC, buf, flags, &outFlag,
                             sValue)) != IFX_SUCCESS) {
      goto IFX_Handler;
   }

   nCount = atoi(sValue);
   if (nCount == 0)
   {
      *numEntries = 0;
      *wlSec = NULL;
      goto IFX_Handler;
   }

   *wlSec = NULL;
   /*
    * \todo
    * get max number of supported VAP from capabilities
    * implement check for nCount with this value instead of hard-coded
    * value below
    */
   if (nCount <= 10) {
	   	   IFX_MEM_ALLOC((*wlSec), IFX_MAPI_WLAN_SecCfg *, nCount, sizeof(IFX_MAPI_WLAN_SecCfg))
   }
   else {
       	   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanSecurityConfig", "");
	   	   ret = IFX_FAILURE;
	   	   goto IFX_Handler;
   }

   for (i=0; i < nCount; i++)
   {
      /* get the cpeid of this instance */
      sprintf(buf, "%s_%d_cpeId", PREFIX_WLAN_SEC, i);
      if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_SEC,
                  buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanSecurityConfig", "i=%d, nCount=%d", i, nCount);
         goto IFX_Handler;
      }
      (*wlSec + i)->iid.cpeId.Id = atoi(sValue);

      if((ret = ifx_mapi_get_wlan_security_config((*wlSec + i), flags)) != IFX_SUCCESS) {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanSecurityConfig", "failed to get security params for instance wlan%d", i);
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d] failed to get security params for instance wlan%d\n\r",
                 __FUNCTION__, __LINE__, i);
#endif
         goto IFX_Handler;
      }
   }
   *numEntries = nCount;

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanSecurityConfig", "ret: %d", ret);
   /* free memory in case of error, otherwise it gets freed  in calling function */
   if(ret != IFX_SUCCESS)
      IFX_MEM_FREE(*wlSec)
	/*
   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanSecurityConfig", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
	*/
   return ret;
}

/**
   This api reads the count and then for each wlan instance gets the cpeid, fills it in the structure
   and calls ifx_mapi_get_wlan_main_config api with this structure

   \param   numEntries  -

   \param   wlMain      - pointer to WLAN Main config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_all_wlan_main_config(uint32 *numEntries, IFX_MAPI_WLAN_MainCfg **wlMain, uint32 flags)
{
   int32	ret = IFX_SUCCESS, nCount = 0, i = 0;
   char8	sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN];
   uint32	outFlag = IFX_F_DEFAULT;
	/*
   struct timeval tv;

   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMainConfig", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
	*/

   MAKE_SECTION_COUNT_TAG(TAG_WLAN_MAIN, buf);
   if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAIN,
                     buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMainConfig", "");
      goto IFX_Handler;
   }

   nCount = atoi(sValue);
   if (nCount == 0) {
      *numEntries = 0;
      *wlMain = NULL;
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMainConfig", "");
      goto IFX_Handler;
   }

   *wlMain = NULL;
   /*
    * \todo
    * get max number of supported VAP from capabilities
    * implement check for nCount with this value instead of hard-coded
    * value below
    */
   if (nCount <= 10) {
	   	   IFX_MEM_ALLOC((*wlMain), IFX_MAPI_WLAN_MainCfg *, nCount, sizeof(IFX_MAPI_WLAN_MainCfg))
   }
   else {
	   	   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMainConfig", "");
	   	   ret = IFX_FAILURE;
	   	   goto IFX_Handler;
   }

   for (i=0; i < nCount; i++) {
      /* get the cpeid of this instance */
      sprintf(buf, "%s_%d_cpeId", PREFIX_WLAN_MAIN, i);
      if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAIN,
                  buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMainConfig", "i=%d, nCount=%d", i, nCount);
         goto IFX_Handler;
      }
      (*wlMain + i)->iid.cpeId.Id = atoi(sValue);

      if((ret = ifx_mapi_get_wlan_main_config((*wlMain + i), flags)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d] failed to get main params for instance wlan%d",
                     __FUNCTION__, __LINE__, i);
#endif
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMainConfig", "failed to get main params for instance wlan%d", i);
         goto IFX_Handler;
      }
   }
   *numEntries = nCount;

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMainConfig", "ret: %d", ret);
   /* free memory in case of error, otherwise it gets freed  in calling function */
   if(ret != IFX_SUCCESS)
      IFX_MEM_FREE(*wlMain)
	/*
   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMainConfig", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
	*/
   return ret;
}


/**
   \param   numEntries  -

   \param   glblMacControl - pointer to IFX_MAPI_GlobalMacControl config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_all_global_mac_control_entries(
      uint32 *numEntries, IFX_MAPI_GlobalMacControl **glblMacControl, uint32 flags)
{
   int32    ret = IFX_SUCCESS, nCount = 0, i = 0;
   char8	   sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN];
   uint32	outFlag = IFX_F_DEFAULT;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllGlobalMacControlEntries", "");

   MAKE_SECTION_COUNT_TAG(TAG_WLAN_GLOBAL_MAC_CONTROL, buf);
   if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL, buf, flags, &outFlag,
                             sValue)) != IFX_SUCCESS) {
      goto IFX_Handler;
   }

   nCount = atoi(sValue);
   if (nCount == 0)
   {
      *numEntries = 0;
      *glblMacControl = NULL;
      goto IFX_Handler;
   }

   *glblMacControl = NULL;
   IFX_MEM_ALLOC((*glblMacControl), IFX_MAPI_GlobalMacControl *, nCount, sizeof(IFX_MAPI_GlobalMacControl))

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllGlobalMacControlEntries", "nCount: %d", nCount);
   for (i=0; i < nCount; i++)
   {
      /* get the cpeid of this instance */
      sprintf(buf, "%s_%d_cpeId", PREFIX_WLAN_GLOBAL_MAC_CONTROL, i);
      if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL,
                  buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllGlobalMacControlEntries", "i=%d, nCount=%d", i, nCount);
         goto IFX_Handler;
      }
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllGlobalMacControlEntries", "buf:%s, sValue=%s", buf, sValue);
      (*glblMacControl + i)->iid.cpeId.Id = atoi(sValue);

      if((ret = ifx_mapi_get_global_mac_control_entry((*glblMacControl + i), flags)) != IFX_SUCCESS) {
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllGlobalMacControlEntries", "failed to get security params for instance wlan%d", i);
         goto IFX_Handler;
      }
   }
   *numEntries = nCount;

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllGlobalMacControlEntries", "ret: %d", ret);
   if(ret != IFX_SUCCESS) {
      IFX_MEM_FREE(*glblMacControl)
      return ret;
   }
   else
      return IFX_SUCCESS;
}

/**
   \param   mainCpeId  -

   \param   numEntries  -

   \param   wlMacControl - pointer to IFX_MAPI_WLAN_MAC_Control config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_all_wlan_mac_control_entries( uint32 mainCpeId,
               uint32 *numEntries, IFX_MAPI_WLAN_MAC_Control **wlMacControl,
               uint32 flags)
{
   int32    ret = IFX_SUCCESS, nAllMacEntries = 0, i = 0, nMacEntries = 0;
   int32	   count = 0;
   char8	   sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN], *sValue2 = NULL;
   uint32	outFlag = IFX_F_DEFAULT, pcpeId;
   IFX_NAME_VALUE_PAIR  array_fvp[72]; /* size of array: max. number of AP * max.number of entries * number of params = 4*8*3 = 72*/

   MAKE_SECTION_COUNT_TAG(TAG_WLAN_MAC_CONTROL, buf);
   if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAC_CONTROL, buf, flags,
                             &outFlag, sValue)) != IFX_SUCCESS) {
      goto IFX_Handler;
   }

   nAllMacEntries = atoi(sValue);
   if (nAllMacEntries == 0)
   {
      *numEntries = 0;
      *wlMacControl = NULL;
      goto IFX_Handler;
   }

   *wlMacControl = NULL;
   /*
    * \todo
    * get max number of supported MAC entries from capabilities
    * implement check for nAllMacEntries with this value instead of hard-coded
    * value below
    */
   /* 160 = 16 per VAP * max number of VAP = 16 * 10 = 160 */
   if (nAllMacEntries <= 160) {
	   	   IFX_MEM_ALLOC((*wlMacControl), IFX_MAPI_WLAN_MAC_Control *, nAllMacEntries, sizeof(IFX_MAPI_WLAN_MAC_Control))
   }
   else {
	   	   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMacControlEntries", "max number of entries reached");
	   	   ret = IFX_FAILURE;
	   	   goto IFX_Handler;
   }

   sprintf(buf, "%s_", PREFIX_WLAN_MAC_CONTROL);
   if((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_MAC_CONTROL, buf, flags,
                              &sValue2)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMacControlEntries", "buf: %s", buf);
      goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMacControlEntries", "buf: %s, sValue2: %s", buf, sValue2);

   memset(array_fvp, 0x00, sizeof(array_fvp));
   form_array_fvp_from_cfgdb_buf(sValue2, &count, array_fvp);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMacControlEntries", "count: %d", count);
   for (i = 0; i < count; i++)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMacControlEntries", "%s:%s", array_fvp[i].fieldname, array_fvp[i].value);

   for (i=0; i < nAllMacEntries; i++)
   {
      pcpeId = atoi(array_fvp[3*i+1].value);
      if (pcpeId == mainCpeId)
      {
         (*wlMacControl + nMacEntries)->iid.cpeId.Id  = atoi(array_fvp[3*i].value);
         (*wlMacControl + nMacEntries)->iid.pcpeId.Id = pcpeId;
         sprintf((*wlMacControl + nMacEntries)->iid.cpeId.secName, "%s", TAG_WLAN_MAC_CONTROL);
         sprintf((*wlMacControl + nMacEntries)->iid.pcpeId.secName, "%s", TAG_WLAN_SEC);
         snprintf((*wlMacControl + nMacEntries)->macAddr, IFX_MAPI_MAC_ADDR_LEN, "%s", array_fvp[3*i+2].value);
         IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMacControlEntries", "macAddr: %s", (*wlMacControl + nMacEntries)->macAddr);
         nMacEntries++;
      }
   }

   *numEntries = nMacEntries;
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMacControlEntries", "numEntries: %d", *numEntries);

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanMacControlEntries", "ret: %d", ret);
   IFX_MEM_FREE(sValue2)
   /*
      in case of error free allocated memory here, otherwise it must be freed
      in calling function
   */
   if(ret != IFX_SUCCESS)
      IFX_MEM_FREE(*wlMacControl)

   return ret;
}

/**
   \param   numEntries  -

   \param   wlApCfg     - pointer to IFX_MAPI_WLAN_AP_Cfg structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_all_wlan_ap_config(uint32 *numEntries, IFX_MAPI_WLAN_AP_Cfg **wlApCfg, uint32 flags)
{
   int32	ret = IFX_SUCCESS, nCount = 0, i = 0;
   char8	sValue[MAX_FILELINE_LEN], buf[MAX_FILELINE_LEN];
   uint32	outFlag = IFX_F_DEFAULT;

   /* get the count first */
   /* then for each object
      read object from wlan_main into buffer, parse buffer to form array_fvp, from array_fvp fill to wlApCfg
      get wlansec instance of this object from cpeId (where wlansec_<inst>_pcpeId=wlan main instance cpeId)
         then get wep key instance of this object using wlanwepkey_<obj_cpeId>_1_cpeId ....
         similarly wlanwpapskkey instance
    */

   MAKE_SECTION_COUNT_TAG(TAG_WLAN_MAIN, buf);
   if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAIN,
                     buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      goto IFX_Handler;
   }

   nCount = atoi(sValue);
   if (nCount == 0)
   {
      *numEntries = 0;
      *wlApCfg = NULL;
      goto IFX_Handler;
   }

   *wlApCfg = NULL;

   /*
    * \todo
    * get max number of supported VAPs from capabilities
    * implement check for nCount with this value instead of hard-coded
    * value below
    */
   if (nCount <= 10) {
	   	   IFX_MEM_ALLOC((*wlApCfg), IFX_MAPI_WLAN_AP_Cfg *, nCount, sizeof(IFX_MAPI_WLAN_AP_Cfg))
   }
   else {
	   	   ret = IFX_FAILURE;
	   	   goto IFX_Handler;
   }

   for (i=0; i < nCount; i++) {
      /*
         get each of the wlan main (ap/vap) instance from the rc.conf file and
         convert it to field value pair array to copy to output array of wlan
         ap's
      */
      sprintf(buf, "%s_%d_cpeId", PREFIX_WLAN_MAIN, i);
      if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAIN,
            buf, IFX_F_GET_ANY, &outFlag, sValue)) != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         goto IFX_Handler;
      }
      (*wlApCfg + i)->iid.cpeId.Id = atoi(sValue);
      sprintf((*wlApCfg + i)->iid.cpeId.secName, "%s", TAG_WLAN_MAIN);

      (*wlApCfg + i)->main.iid.cpeId.Id = atoi(sValue); /* fill cpeid for main */
      sprintf((*wlApCfg + i)->main.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);

      (*wlApCfg + i)->sec.iid.cpeId.Id = atoi(sValue); /* fill pcpeid for sec */
      sprintf((*wlApCfg + i)->sec.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);

      sprintf(buf, "%s_%d_pcpeId", PREFIX_WLAN_MAIN, i);
      if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAIN,
            buf, IFX_F_GET_ANY, &outFlag, sValue)) != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
         goto IFX_Handler;
      }
      (*wlApCfg + i)->iid.pcpeId.Id = atoi(sValue);
      sprintf((*wlApCfg + i)->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

      (*wlApCfg + i)->main.iid.pcpeId.Id = atoi(sValue); /* fill pcpeid for main */
      sprintf((*wlApCfg + i)->main.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

      (*wlApCfg + i)->sec.iid.pcpeId.Id = atoi(sValue); /* fill pcpeid for sec */
      sprintf((*wlApCfg + i)->sec.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

      /*
         call ifx_mapi_get_wlan_phy_config to get phy level radio parameters for
         each ap/vap
      */
      if((ret = ifx_mapi_get_wlan_phy_config(&(*wlApCfg + i)->phy, flags)) != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d] failed to get phy params for instance wlan%d",
                     __FUNCTION__, __LINE__, i);
#endif
         goto IFX_Handler;
      }

      /*
         call ifx_mapi_get_wlan_main_config to get wlan main section parameters
         of each ap/vap;
         make sure cpeId and pcpeId is filled for main before calling the api
      */
      if((ret = ifx_mapi_get_wlan_main_config(&(*wlApCfg + i)->main, flags)) != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d] failed to get main params for instance wlan%d",
                     __FUNCTION__, __LINE__, i);
#endif
         goto IFX_Handler;
      }

      /*
         call ifx_mapi_get_wlan_security_config to get wlan security parameters of
         each ap/vap;
         make sure cpeId and pcpeId is filled for main before calling the api
      */
      if((ret = ifx_mapi_get_wlan_security_config(&(*wlApCfg + i)->sec, flags)) != IFX_SUCCESS)
      {
#ifdef IFX_LOG_DEBUG
         IFX_DBG("[%s:%d] failed to get security params for instance wlan%d",
                     __FUNCTION__, __LINE__, i);
#endif
         goto IFX_Handler;
      }
   }
   *numEntries = nCount;

IFX_Handler:
   if(ret != IFX_SUCCESS)
   {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return ret;
   }
   else
      return IFX_SUCCESS;
}

/**

   \param   wlApCfg  - pointer to IFX_MAPI_WLAN_AP_Cfg structure

   \param   flags    -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_ap_config(IFX_MAPI_WLAN_AP_Cfg *wlApCfg, uint32 flags)
{
   int32                      ret = IFX_SUCCESS, i = 0;
#ifdef IFX_MAPI_WLAN_WMM
   IFX_MAPI_WLAN_AP_WMM_Cfg   *wlApWmm = NULL;
   IFX_MAPI_WLAN_STA_WMM_Cfg  *wlStaWmm = NULL;
   uint32                     numEntries = -1;
#endif /* #ifdef IFX_MAPI_WLAN_WMM */

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanApConfig", "");

   /*
      probably redundant, should already have been initialized by calling
      function
   */
   sprintf(wlApCfg->iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
   sprintf(wlApCfg->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

   /*
      call ifx_mapi_get_wlan_main_config to get wlan main section parameters
      of each ap/vap;
      cpeId and pcpeId is filled with values from wlApCfg->iid
   */
   sprintf(wlApCfg->main.iid.cpeId.secName, "%s", TAG_WLAN_MAIN);
   sprintf(wlApCfg->main.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
   wlApCfg->main.iid.cpeId.Id = wlApCfg->iid.cpeId.Id;
   if((ret = ifx_mapi_get_wlan_main_config(&(wlApCfg->main), flags)) != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d] failed to get main params for instance wlApCfg->main",
              __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanApConfig",
                     "failed to get main params for instance wlApCfg->main");
      goto IFX_Handler;
   }

   /*
      call ifx_mapi_get_wlan_phy_config to get phy level radio parameters for
      each ap/vap
      cpeId of phy object can be taken from wlan_main object (parameter
      radioCpeId)
   */
   sprintf(wlApCfg->phy.iid.cpeId.secName, "%s", TAG_WLAN_PHY);
   sprintf(wlApCfg->phy.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
   wlApCfg->phy.iid.cpeId.Id  = wlApCfg->main.radioCpeId;
   if((ret = ifx_mapi_get_wlan_phy_config(&(wlApCfg->phy), flags)) != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d] failed to get phy params for instance wlApCfg->phy",
              __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanApConfig",
                     "failed to get phy params for instance wlApCfg->phy");
      goto IFX_Handler;
   }

   /*
      call ifx_mapi_get_wlan_security_config to get wlan security parameters of
      each ap/vap;
      cpeId and pcpeId is filled with values from wlApCfg->iid
   */
   sprintf(wlApCfg->sec.iid.cpeId.secName, "%s", TAG_WLAN_SEC);
   sprintf(wlApCfg->sec.iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);
   wlApCfg->sec.iid.cpeId.Id = wlApCfg->iid.cpeId.Id;
   if((ret = ifx_mapi_get_wlan_security_config(&(wlApCfg->sec), flags)) != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d] failed to get security params for instance wlApCfg->sec",
              __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanApConfig",
                     "failed to get security params for instance wlApCfg->sec");
      goto IFX_Handler;
   }

#ifdef IFX_MAPI_WLAN_WMM
   /*
      call ifx_mapi_get_all_wlan_wmm_ap_config to get wlan wmm parameters of
      each ap/vap;
   */
   if((ret = ifx_mapi_get_all_wlan_wmm_ap_config(wlApCfg->iid.cpeId.Id,
            &numEntries, &wlApWmm, flags)) != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d] failed to get wmm outbound params for instance wlApCfg->apWmm",
              __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanApConfig",
                     "failed to get wmm outbound params for instance wlApCfg->apWmm");
      goto IFX_Handler;
   }
   /* copy wmm ap parameters to ap configuration */
//   memcpy(wlApCfg->apWmm, wlApWmm, (sizeof(IFX_MAPI_WLAN_AP_WMM_Cfg) * numEntries));
   for (i = 0; i < numEntries; i++) {
	   	   memcpy(&wlApCfg->apWmm[i], wlApWmm+i, sizeof(IFX_MAPI_WLAN_AP_WMM_Cfg));
   }

   /*
      call ifx_mapi_get_all_wlan_wmm_ap_config to get wlan wmm parameters of
      each ap/vap;
   */
   if((ret = ifx_mapi_get_all_wlan_wmm_sta_config(wlApCfg->iid.cpeId.Id,
            &numEntries, &wlStaWmm, flags)) != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d] failed to get wmm inbound params for instance wlApCfg->staWmm",
              __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanApConfig",
                     "failed to get wmm inbound params for instance wlApCfg->staWmm");
      goto IFX_Handler;
   }
   /* copy wmm sta parameters to ap configuration */
//   memcpy(wlApCfg->staWmm, wlStaWmm, (sizeof(IFX_MAPI_WLAN_STA_WMM_Cfg) * numEntries));
   for (i = 0; i < numEntries; i++) {
	   	   memcpy(&wlApCfg->staWmm[i], wlStaWmm+i, sizeof(IFX_MAPI_WLAN_STA_WMM_Cfg));
   }
#endif /* #ifdef IFX_MAPI_WLAN_WMM */

#ifdef IFX_MAPI_WLAN_WPS
   /*
      call ifx_mapi_get_wlan_wps_config to get wlan wps parameters of
      each ap/vap;
   */
   sprintf(wlApCfg->wps.iid.cpeId.secName, "%s", TAG_WLAN_WPS);
   sprintf(wlApCfg->wps.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
   wlApCfg->wps.iid.pcpeId.Id = wlApCfg->iid.cpeId.Id;
   /*
      \todo cpeId?
   */
   if((ret = ifx_mapi_get_wlan_wps_config(&(wlApCfg->wps), flags)) != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d] failed to get wps params for instance wlApCfg->wps",
              __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanApConfig",
                     "failed to get wps params for instance wlApCfg->wps");
      goto IFX_Handler;
   }

   /*
      call ifx_mapi_get_wlan_wps_registrar_config to get wlan wps registrar
      parameters of each ap/vap;
   */
   sprintf(wlApCfg->wpsRegs.iid.cpeId.secName, "%s", TAG_WLAN_WPS_REGISTRAR);
   sprintf(wlApCfg->wpsRegs.iid.pcpeId.secName, "%s", TAG_WLAN_MAIN);
   wlApCfg->wpsRegs.iid.pcpeId.Id = wlApCfg->iid.cpeId.Id;
   /*
      \todo cpeId?
   */
   if((ret = ifx_mapi_get_wlan_wps_registrar_config(&(wlApCfg->wpsRegs), flags)) != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d] failed to get wps registrar params for instance wlApCfg->wpsRegs",
              __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanApConfig",
                     "failed to get wps registrar params for instance wlApCfg->wpsRegs");
      goto IFX_Handler;
   }
#endif /* #ifdef IFX_MAPI_WLAN_WPS */

IFX_Handler:
#ifdef IFX_MAPI_WLAN_WMM
   IFX_MEM_FREE(wlApWmm);
   IFX_MEM_FREE(wlStaWmm);
#endif /* #ifdef IFX_MAPI_WLAN_WMM */
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanApConfig", "ret: %d", ret);
   if(ret != IFX_SUCCESS)
   {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return ret;
   }
   else
      return IFX_SUCCESS;
}

/* Pramod - this api will return the global filter mode only in the structure */
int32 ifx_get_wlan_mac_control_status(WLAN_MAC_CONTROL *wlan_mac, uint32 flags)
{
   int32	ret = IFX_SUCCESS;
   char8	buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
   uint32	outFlag = IFX_F_DEFAULT;

   /* get global mode */
   sprintf(buf, "%s_control", PREFIX_WLAN_GLOBAL_MAC_CONTROL);
   if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL,
                  buf, flags, &outFlag, sValue)) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      goto IFX_Handler;
   }
   wlan_mac->global_mode = atoi(sValue);

IFX_Handler:
   if(ret != IFX_SUCCESS) {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return ret;
   }
   else
      return IFX_SUCCESS;
}

/**
   \param   glblMacControl - pointer to IFX_MAPI_GlobalMacControl config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
   \remarks
   - does compactcfgsection remove tags other than count and param related ??
     yes
   - why should wlanMacControl be pointer to pointer ??
     no, its sufficient to be a single pointer
   - as of now compactcfgsection assumes that possible tags in an instantiated section are
      section_name_Count
      prefix_index1_param1
      prefix_index1_param2
      ....
      prefix_index2_param1
      prefix_index2_param2
      ....
      any other tag than these may result in error or may be lost during compaction
      but this object has one section param global_mac_filter_mode
      support for this is not there as of now 27.08
      proposed section format is,
      section_param1=val1
      section_param2=val2
      ....
      section_name_Count
      prefix_index1_param1
      prefix_index1_param2
      ....
      prefix_index2_param1
      prefix_index2_param2
      ....
*/
int32 ifx_mapi_get_global_mac_control_entry(IFX_MAPI_GlobalMacControl *gMacControl, uint32 flags)
{
   int32    ret      = IFX_SUCCESS, passed_index = -1;
   uint32   outFlag  = IFX_F_DEFAULT;
   char8	   buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry", "");

   sprintf(gMacControl->iid.cpeId.secName, "%s", TAG_WLAN_GLOBAL_MAC_CONTROL);
   sprintf(gMacControl->iid.pcpeId.secName, "%s", TAG_LAN_DEVICE);

   /*
      get index from cpeid: example gmaccntrl_1_cpeId="3" => passed_index = 1
   */
   IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, gMacControl->iid.cpeId, passed_index)

//manohar
/* initialize the cache for this instance */
  sprintf(buf, "%s_%d_",PREFIX_WLAN_GLOBAL_MAC_CONTROL,passed_index);
  if(ifx_GetObjDataOpt(FILE_RC_CONF,TAG_WLAN_GLOBAL_MAC_CONTROL, buf, IFX_F_INT_CACHE_INIT | flags, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
    IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
#endif
    ret = IFX_FAILURE;
    goto IFX_Handler;
  }
//manohar

   sprintf(buf, "%s_%d_cpeId", PREFIX_WLAN_GLOBAL_MAC_CONTROL, passed_index);
   if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL,
                            buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry", "");
      goto IFX_Handler;
   }
   gMacControl->iid.cpeId.Id = atoi(sValue);
   sprintf(gMacControl->iid.cpeId.secName, "%s", TAG_WLAN_GLOBAL_MAC_CONTROL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry", "cpeId: %d", gMacControl->iid.cpeId.Id);

   sprintf(buf, "%s_%d_pcpeId", PREFIX_WLAN_GLOBAL_MAC_CONTROL, passed_index);
   if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL,
                            buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry", "");
      goto IFX_Handler;
   }
   gMacControl->iid.pcpeId.Id = atoi(sValue);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry", "buf: %s, pcpeId: %d", buf, gMacControl->iid.pcpeId.Id);

   sprintf(buf, "%s_%d_ifType", PREFIX_WLAN_GLOBAL_MAC_CONTROL, passed_index);
   if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL,
                            buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry", "");
      goto IFX_Handler;
   }
   gMacControl->ifType = atoi(sValue);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry", "buf: %s, ifType: %d", buf, gMacControl->ifType);

   sprintf(buf, "%s_%d_macAddr", PREFIX_WLAN_GLOBAL_MAC_CONTROL, passed_index);
   if((ret = ifx_GetObjDataOpt(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL,
                            buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      goto IFX_Handler;
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry", "");
   }
   if (strlen(sValue) <= MAX_MAC_ADDR_LEN - 1) {
	   	   sprintf(gMacControl->macAddr, "%s", sValue);
	   	   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry", "buf: %s, macAddr: %s", buf, gMacControl->macAddr);
   }
   else {
   	   	   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry",
   			   "sValue: %s", sValue);
   }

   /* get global mode */
   sprintf(buf, "%s_0_control", PREFIX_WLAN_GLOBAL_MAC_CONTROL);
   if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_GLOBAL_MAC_CONTROL,
                            buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry", "");
      goto IFX_Handler;
   }
   gMacControl->cntrlMode = atoi(sValue);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry", "buf: %s, control: %d", buf, gMacControl->cntrlMode);

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetGlobalMacControlEntry", "ret: %d", ret);
//manohar 
		/* destroy the cache for this instance */
		sprintf(buf, "%s_%d_",PREFIX_WLAN_GLOBAL_MAC_CONTROL,passed_index);
		if(ifx_GetObjDataOpt(FILE_RC_CONF,TAG_WLAN_GLOBAL_MAC_CONTROL, buf, IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS)
		{
			#ifdef IFX_LOG_DEBUG
			IFX_DBG("[%s:%d] Failed to destroy cache for this instance", __FUNCTION__, __LINE__);
			#endif
			ret = IFX_FAILURE;
		}
//manohar
   if(ret != IFX_SUCCESS)
   {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return ret;
   }
   else
      return IFX_SUCCESS;
}

/**
   \param   glblMacControl - pointer to IFX_MAPI_GlobalMacControl config structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
   \remarks
   - does compactcfgsection remove tags other than count and param related ??
     yes
   - why should wlanMacControl be pointer to pointer ??
     no, its sufficient to be a single pointer
   - as of now compactcfgsection assumes that possible tags in an instantiated section are
      section_name_Count
      prefix_index1_param1
      prefix_index1_param2
      ....
      prefix_index2_param1
      prefix_index2_param2
      ....
      any other tag than these may result in error or may be lost during compaction
      but this object has one section param global_mac_filter_mode
      support for this is not there as of now 27.08
      proposed section format is,
      section_param1=val1
      section_param2=val2
      ....
      section_name_Count
      prefix_index1_param1
      prefix_index1_param2
      ....
      prefix_index2_param1
      prefix_index2_param2
      ....
*/
int32 ifx_mapi_get_wlan_mac_control_entry(IFX_MAPI_WLAN_MAC_Control *wlMacControl, uint32 flags)
{
   int32    ret      = IFX_SUCCESS, passed_index = -1;
   uint32   outFlag  = IFX_F_DEFAULT;
   char8	   buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
	/*
   struct timeval tv;

   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMacControlEntry", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
	*/

   sprintf(wlMacControl->iid.cpeId.secName, "%s", TAG_WLAN_MAC_CONTROL);
   sprintf(wlMacControl->iid.pcpeId.secName, "%s", TAG_WLAN_SEC);

   /*
      get index from cpeid: example wlMaccntrl_1_cpeId="3" => passed_index = 1
   */
   IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, wlMacControl->iid.cpeId, passed_index)
//manohar
	/* initialize the cache for this instance */
	sprintf(buf, "%s_%d_",PREFIX_WLAN_MAC_CONTROL,passed_index);
	if(ifx_GetObjDataOpt(FILE_RC_CONF,TAG_WLAN_MAC_CONTROL, buf, IFX_F_INT_CACHE_INIT | flags, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
//manohar

#if 0
   sprintf(buf, "%s_%d_cpeId", PREFIX_WLAN_MAC_CONTROL, passed_index);
   if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAC_CONTROL,
                            buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
   {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMacControlEntry", "");
      goto IFX_Handler;
   }
   wlMacControl->iid.cpeId.Id = atoi(sValue);
   sprintf(wlMacControl->iid.cpeId.secName, "%s", TAG_WLAN_MAC_CONTROL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMacControlEntry", "cpeId: %d", wlMacControl->iid.cpeId.Id);
#endif /* #if 0 */

   sprintf(buf, "%s_%d_pcpeId", PREFIX_WLAN_MAC_CONTROL, passed_index);
   if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAC_CONTROL,
                            buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMacControlEntry", "");
      goto IFX_Handler;
   }
   wlMacControl->iid.pcpeId.Id = atoi(sValue);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMacControlEntry", "buf: %s, pcpeId: %d",
                  buf, wlMacControl->iid.pcpeId.Id);

   sprintf(buf, "%s_%d_macAddr", PREFIX_WLAN_MAC_CONTROL, passed_index);
   if((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAC_CONTROL,
                            buf, flags, &outFlag, sValue)) != IFX_SUCCESS)
   {
      goto IFX_Handler;
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMacControlEntry", "");
   }

   if (strlen(sValue) <= MAX_MAC_ADDR_LEN - 1) {
	   	   sprintf(wlMacControl->macAddr, "%s", sValue);
	   	   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMacControlEntry",
	   			   "macAddr: %s", wlMacControl->macAddr);
   }
   else {
   	   	   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMacControlEntry",
   			   "sValue: %s", sValue);
   }

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMacControlEntry", "buf: %s, macAddr: %s", buf, wlMacControl->macAddr);

IFX_Handler:
//manohar
	/* initialize the cache for this instance */
	sprintf(buf, "%s_%d_",PREFIX_WLAN_MAC_CONTROL,passed_index);
	if(ifx_GetObjDataOpt(FILE_RC_CONF,TAG_WLAN_MAC_CONTROL, buf, IFX_F_INT_CACHE_DESTROY, NULL, NULL) != IFX_SUCCESS) {
#ifdef IFX_LOG_DEBUG
		IFX_DBG("[%s:%d] Failed to initialize cache for this instance", __FUNCTION__, __LINE__);
#endif
		ret = IFX_FAILURE;
		goto IFX_Handler;
	}
//manohar
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMacControlEntry", "ret: %d", ret);
	/*
   gettimeofday(&tv, NULL);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanMacControlEntry", "%d:%d",
                  (int32)tv.tv_sec, (int32)tv.tv_usec);
	*/
   return ret;
}

/**

   \param   mainCpeId   -

   \param   numEntries  -

   \param   wlAssocInfo      - pointer to IFX_MAPI_WLAN_AssocInfo structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_all_wlan_assoc_devices(
                                          uint32 mainCpeId,
                                          uint32 *numEntries,
                                          IFX_MAPI_WLAN_AssocInfo **wlAssocInfo,
                                          uint32 flags)
{
		int32		ret = IFX_SUCCESS, i = 0, mac_count = 0, apIndex;
		char8	    buf[MAX_FILELINE_LEN], sValue[MAX_DATA_LEN];
		char8       sValueTmp[MAX_DATA_LEN], sParam[MAX_FILELINE_LEN];
		char8       *pTmpStr = NULL, *pTmpStr2;
		DHCP_LEASE_INFO   *lease_info = NULL;
		int32		j = 0, nDhcpClients = 0;
		FILE    	*fp = NULL;
		char8 		ip[MAX_FILELINE_LEN], hwType[MAX_FILELINE_LEN];
		char8		arpFlags[MAX_FILELINE_LEN], hwAddr[MAX_FILELINE_LEN];
		char8		mask[MAX_FILELINE_LEN], device[MAX_FILELINE_LEN];
		CPE_ID      cpeId;
		bool        authState = 0, flagIpFound = 0;
		float       lastDataRate;

		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "");

		/* call staAssocIndAp here to get list of mac address of associated stations */

		/*
		 * Get the Parent section count
		 * Get the first AP/VAP ssid
		 * Get the Corresponding APType
		 * Call the script to get List of Stations
		 * Malloc/calloc for no of stations
		 * Copy the SSID,MacAddress,AuthState,AssocState,ipaddr
		 * Continue for next AP/VAP
		 */

		*wlAssocInfo = NULL;

		memset(&cpeId, 0x00, sizeof(cpeId));

		cpeId.Id = mainCpeId;
		sprintf(cpeId.secName, "%s", TAG_WLAN_MAIN);

		IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpeId, apIndex)

		/* get dhcp leases to obtain ip address below */
		ret = ifx_get_lan_dhcp_leases(&nDhcpClients, &lease_info, flags);
		if(ret != IFX_SUCCESS) {
			IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "");
			goto IFX_Handler;
		}
		else {
			for(i=0; i<nDhcpClients; i++) {
					IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
		    		  "macAddr_%d: %s", i, (lease_info+i)->cli_id);
			}
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "nDhcpClients: %d",
                  nDhcpClients);
		NULL_TERMINATE(buf, 0x00, sizeof(buf));

	    if (apIndex < 0) {
	    		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
				   "passed_index: %d", apIndex);
	    		ret = IFX_FAILURE;
	    		goto IFX_Handler;
	    }
		sprintf(buf, "%s %d", SERVICE_WLAN_GET_ASSOC_DEV, apIndex);
		memset(sValue, 0x00, sizeof(sValue));

		if (ifx_GetCfgData((char8*)buf, NULL, "-1", sValue) == 0) {
				ret = IFX_FAILURE;
				goto IFX_Handler;
		}
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "sValue: %s", sValue);
		/* save buffer in sValueTmp */
		strcpy(sValueTmp, sValue);

		if((pTmpStr = strstr(sValue,"assoc_count=")) != NULL) {
				pTmpStr2 = strtok(pTmpStr, "\"");
				if(pTmpStr2 == NULL) {
						ret = IFX_FAILURE;
						goto IFX_Handler;
				}
				pTmpStr2 = strtok(NULL, "\"");
				if(pTmpStr2 == NULL) {
						ret = IFX_FAILURE;
						goto IFX_Handler;
				}
				mac_count = atoi(pTmpStr2);
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "mac_count: %d", mac_count);
		}
		else
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "sValue: %s",sValue);

#if 0
		sprintf(buf, "%s_%d_maxSta", PREFIX_WLAN_MAIN, apIndex);
	    if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_MAIN,
	    	 buf, IFX_F_GET_ANY, &outFlag, sValue)) != IFX_SUCCESS) {
	    		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "");
				ret = IFX_FAILURE;
	    		goto IFX_Handler;
	    }
#endif
	    /*
	     * \todo
	     * get max number of clients that can associate
	     * then implement a check with this value
	     */
	    if ((mac_count > 0) && (mac_count <= 128)) {
	    	IFX_MEM_ALLOC((*wlAssocInfo), IFX_MAPI_WLAN_AssocInfo *, mac_count, sizeof(IFX_MAPI_WLAN_AssocInfo))
	    }
	    else
	    {
		*numEntries = 0;
		if(mac_count == 0)
			ret = IFX_SUCCESS;
		else
			ret = IFX_FAILURE;
 	
		goto IFX_Handler;
	    }

		/* restore sValue buffer from sValueTmp */
		strcpy(sValue, sValueTmp);
		system("cat /proc/net/arp > /tmp/try");
		for (i = 0; i < mac_count; i++) {
				sprintf(sParam, "mac_%d=", i);
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "sParam: %s", sParam);
				if((pTmpStr = strstr(sValue,sParam)) != NULL) {
						pTmpStr2 = strtok(pTmpStr, "\"");
						if(pTmpStr2 == NULL) {
								ret = IFX_FAILURE;
								goto IFX_Handler;
						}
						pTmpStr2 = strtok(NULL, "\"");
						if(pTmpStr2 == NULL) {
								ret = IFX_FAILURE;
								goto IFX_Handler;
						}
						sprintf((*wlAssocInfo + i)->macAddress, "%s", pTmpStr2);
						ifx_make_canonical_key((*wlAssocInfo + i)->macAddress);
						IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "macAddress: %s", (*wlAssocInfo + i)->macAddress);
				}
				/* restore sValue buffer from sValueTmp */
				strcpy(sValue, sValueTmp);

				/*
         	 	 check for each entry in dhcp lease list, if the mac address is equal,
         	 	 if yes get the corresponding ip address
				*/
				flagIpFound = 0;
				for (j = 0; j < nDhcpClients; j++) {
						char8 lease_mac[MAX_MAC_ADDR_LEN];

						strcpy(lease_mac, (lease_info+j)->cli_id);
						IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
								"lease_mac: %s", lease_mac);
						ifx_make_canonical_key(lease_mac);
						if (!(strcmp(lease_mac, (*wlAssocInfo + i)->macAddress))) {
								pTmpStr = inet_ntoa((lease_info+j)->ip);
								inet_aton(pTmpStr, &(*wlAssocInfo + i)->ipAddress);
								IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
										"ipAddr: %s", inet_ntoa((*wlAssocInfo + i)->ipAddress));
								flagIpFound = 1;
								break;
						}
						else {
								IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
										"lease_mac: %s, wlan_mac: %s",
										lease_mac, (*wlAssocInfo + i)->macAddress);
						}
				}
				/* if IP not found in DHCP lease list, also check arp table */
				if (flagIpFound == 0) {
						fp=fopen("/tmp/try","r");
						if (fp!=NULL) {
								fgets(device,MAX_FILELINE_LEN,fp);
								while(fscanf(fp,"%[^ ] %[^ ] %[^ ] %[^ ] %[^ ] %[^\n]\n", ip, hwType, arpFlags, hwAddr, mask, device) > 0 ) {
										 ifx_make_canonical_key(hwAddr);
										 if (!(strcmp(hwAddr, (*wlAssocInfo + i)->macAddress))) {
												 inet_aton(ip, &(*wlAssocInfo + i)->ipAddress);
												 IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
																"ipAddr: %s", inet_ntoa((*wlAssocInfo + i)->ipAddress));
												 break;
										 }
										 else {
												 IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices",
														 "mac: %s, wlan_mac: %s",
														 hwAddr, (*wlAssocInfo + i)->macAddress);
										 }
								}
								fclose(fp);
						}
				}

				sprintf(sParam, "auth_%d=", i);
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "sParam: %s", sParam);
				if((pTmpStr = strstr(sValue,sParam)) != NULL) {
						pTmpStr2 = strtok(pTmpStr, "\"");
						if(pTmpStr2 == NULL) {
								ret = IFX_FAILURE;
								goto IFX_Handler;
						}
						pTmpStr2 = strtok(NULL, "\"");
						if(pTmpStr2 == NULL) {
								ret = IFX_FAILURE;
								goto IFX_Handler;
						}
						if ((authState = atoi(pTmpStr2)))
								(*wlAssocInfo + i)->staAuthenticated = IFX_MAPI_WLAN_STA_AUTHENTICATED;
						else
								(*wlAssocInfo + i)->staAuthenticated = IFX_MAPI_WLAN_STA_UNAUTHENTICATED;
						IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "authState: %d", (*wlAssocInfo + i)->staAuthenticated);
				}
				/* restore sValue buffer from sValueTmp */
				strcpy(sValue, sValueTmp);

				sprintf(sParam, "rate_%d=", i);
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "sParam: %s", sParam);
				if((pTmpStr = strstr(sValue,sParam)) != NULL) {
						pTmpStr2 = strtok(pTmpStr, "\"");
						if(pTmpStr2 == NULL) {
								ret = IFX_FAILURE;
								goto IFX_Handler;
						}
						pTmpStr2 = strtok(NULL, "\"");
						if(pTmpStr2 == NULL) {
								ret = IFX_FAILURE;
								goto IFX_Handler;
						}
						lastDataRate = (float)strtod(pTmpStr2, (char **)NULL);
						(*wlAssocInfo + i)->lastDataTxRate = lastDataRate;
						IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "dataRate: %f", (*wlAssocInfo + i)->lastDataTxRate);
				}
				/* restore sValue buffer from sValueTmp */
				strcpy(sValue, sValueTmp);

				sprintf(sParam, "wpa2UCcipher_%d=", i);
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "sParam: %s", sParam);
				if((pTmpStr = strstr(sValue,sParam)) != NULL) {
						pTmpStr2 = strtok(pTmpStr, "\"");
						if(pTmpStr2 == NULL) {
								ret = IFX_FAILURE;
								goto IFX_Handler;
						}
						pTmpStr2 = strtok(NULL, "\"");
						if(pTmpStr2 == NULL) {
								ret = IFX_FAILURE;
								goto IFX_Handler;
						}
						sprintf((*wlAssocInfo + i)->wpa2LastUCcipher, "%s", pTmpStr2);
						IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "wpa2LastUCcipher: %s", (*wlAssocInfo + i)->wpa2LastUCcipher);
				}
				/* restore sValue buffer from sValueTmp */
				strcpy(sValue, sValueTmp);

				sprintf(sParam, "wpa2MCcipher%d=", i);
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "sParam: %s", sParam);
				if((pTmpStr = strstr(sValue,sParam)) != NULL) {
						pTmpStr2 = strtok(pTmpStr, "\"");
						if(pTmpStr2 == NULL) {
								ret = IFX_FAILURE;
								goto IFX_Handler;
						}
						pTmpStr2 = strtok(NULL, "\"");
						if(pTmpStr2 == NULL) {
								ret = IFX_FAILURE;
								goto IFX_Handler;
						}
						sprintf((*wlAssocInfo + i)->wpa2LastMCcipher, "%s", pTmpStr2);
						IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "wpa2LastMCcipher: %s", (*wlAssocInfo + i)->wpa2LastMCcipher);
				}
				/* restore sValue buffer from sValueTmp */
				strcpy(sValue, sValueTmp);

				sprintf(sParam, "wpa2PMK%d=", i);
				IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "sParam: %s", sParam);
				if((pTmpStr = strstr(sValue,sParam)) != NULL) {
						pTmpStr2 = strtok(pTmpStr, "\"");
						if(pTmpStr2 == NULL) {
								ret = IFX_FAILURE;
								goto IFX_Handler;
						}
						pTmpStr2 = strtok(NULL, "\"");
						if(pTmpStr2 == NULL) {
								ret = IFX_FAILURE;
								goto IFX_Handler;
						}
						sprintf((*wlAssocInfo + i)->wpa2LastPMKId, "%s", pTmpStr2);
						IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "wpa2LastPMKId: %s", (*wlAssocInfo + i)->wpa2LastPMKId);
				}
				/* restore sValue buffer from sValueTmp */
				strcpy(sValue, sValueTmp);
		}
		system("rm -f /tmp/try");

		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "mac_count: %d", mac_count);
		*numEntries = mac_count;

IFX_Handler:
		IFX_MEM_FREE(lease_info);
		IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetAllWlanAssocDevices", "ret: %d", ret);
		if(ret != IFX_SUCCESS) {
				*numEntries = 0;
				IFX_MEM_FREE(*wlAssocInfo);
				return ret;
		}
		else
   		   return IFX_SUCCESS;
}


/**
   \param   phyCpeId   -

   \param   wlSuppRates      - pointer to WLAN IFX_MAPI_WLAN_SupportedRate structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks - mode(standard) is input here
*/
int32 ifx_mapi_get_wlan_supported_datarates(uint32 phyCpeId, IFX_MAPI_WLAN_SupportedRate *wlSuppRates, uint32 flags)
{
   int32	i = 0;

   memset(wlSuppRates->dataRate, 0x00, sizeof(wlSuppRates->dataRate));
    switch(wlSuppRates->std) {
        case IFX_MAPI_WLAN_STD_802_11A:
                        for(i=0; i<basic_data_rates_11a.length; i++)
                            wlSuppRates->dataRate[i] = basic_data_rates_11a.rates[i];
                        break;
        case IFX_MAPI_WLAN_STD_802_11B:
                        for(i=0; i<basic_data_rates_11b.length; i++)
                            wlSuppRates->dataRate[i] = basic_data_rates_11b.rates[i];
                        break;
        case IFX_MAPI_WLAN_STD_802_11BG:
        case IFX_MAPI_WLAN_STD_802_11G:
                        for(i=0; i<basic_data_rates_11bg.length; i++)
                            wlSuppRates->dataRate[i] = basic_data_rates_11bg.rates[i];
                        break;
        case IFX_MAPI_WLAN_STD_802_11N:
        case IFX_MAPI_WLAN_STD_802_11BGN:
        case IFX_MAPI_WLAN_STD_802_11GN:
        case IFX_MAPI_WLAN_STD_802_11AN:
        default:
         return IFX_FAILURE;
         break;
    }

   return IFX_SUCCESS;
}


/**
   \param   phyCpeId   -

   \param   wlChanList      - pointer to WLAN IFX_MAPI_WLAN_ChannelList structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE

   \remarks - mode(standard) and country is input here
            - the api should not use mode and country as input, it should call
               appropriate api with type as ap to get possible channel list for
               the current configuration only, as list of combinations is not
               given by this api
*/
int32 ifx_mapi_get_wlan_channel_list(uint32 phyCpeId, IFX_MAPI_WLAN_ChannelList *wlChanList, uint32 flags)
{
   uint32                     i = 0;
   IFX_MAPI_WLAN_RegDomain    chList;
   uint8 		      country = 0;
   memset (&chList, 0x00, sizeof(IFX_MAPI_WLAN_RegDomain));
   IFX_MAPI_DEBUG(fd, "/tmp/ifx_mapi_get_wlan_channel_list", "wlChanList->std:%d, wlChanList->country:%s, wlChanList->freqBand:%d", wlChanList->std,wlChanList->country,wlChanList->freqBand);

   if(strcmp(wlChanList->country,"IN")==0) country = IFX_MAPI_WLAN_COUNTRY_INDIA;
   else if (strcmp(wlChanList->country,"US")==0) country = IFX_MAPI_WLAN_COUNTRY_US;
   else if (strcmp(wlChanList->country,"CA")==0) country = IFX_MAPI_WLAN_COUNTRY_IC;
   else if (strcmp(wlChanList->country,"FR")==0) country = IFX_MAPI_WLAN_COUNTRY_FRANCE;
   else if (strcmp(wlChanList->country,"DE")==0) country = IFX_MAPI_WLAN_COUNTRY_GER;
   else if (strcmp(wlChanList->country,"ES")==0) country = IFX_MAPI_WLAN_COUNTRY_ESP;
   else if (strcmp(wlChanList->country,"CN")==0) country = IFX_MAPI_WLAN_COUNTRY_CHINA;
   else if (strcmp(wlChanList->country,"JP")==0) country = IFX_MAPI_WLAN_COUNTRY_JAPAN;
   else country = IFX_MAPI_WLAN_COUNTRY_US;
 
   switch (wlChanList->std)
   {
      case IFX_MAPI_WLAN_STD_802_11A:
      case IFX_MAPI_WLAN_STD_802_11AN:
         IFX_MAPI_DEBUG(fd,"/tmp/ifx_mapi_get_wlan_channel_list","std:%d",wlChanList->std);
	 switch (country)
         {
            case IFX_MAPI_WLAN_COUNTRY_INDIA:
            case IFX_MAPI_WLAN_COUNTRY_US:
            case IFX_MAPI_WLAN_COUNTRY_IC:
               chList = regDomainWorld_11a;
               break;
            case IFX_MAPI_WLAN_COUNTRY_FRANCE:
            case IFX_MAPI_WLAN_COUNTRY_GER:
            case IFX_MAPI_WLAN_COUNTRY_ETSI:
            case IFX_MAPI_WLAN_COUNTRY_ESP:
               chList = regDomainEurope_11a;
               break;
            case IFX_MAPI_WLAN_COUNTRY_CHINA:
               chList = regDomainChina_11a;
               break;
            case IFX_MAPI_WLAN_COUNTRY_JAPAN:
               chList = regDomainJapan_11a;
               break;
            default:
               break;
         }
         break;
      case IFX_MAPI_WLAN_STD_802_11B:
      case IFX_MAPI_WLAN_STD_802_11G:
      case IFX_MAPI_WLAN_STD_802_11BG:
      case IFX_MAPI_WLAN_STD_802_11BGN:
      case IFX_MAPI_WLAN_STD_802_11GN:
         IFX_MAPI_DEBUG(fd,"/tmp/ifx_mapi_get_wlan_channel_list","std:%d",wlChanList->std);
         switch(country) {
            case IFX_MAPI_WLAN_COUNTRY_INDIA:
            case IFX_MAPI_WLAN_COUNTRY_US:
            case IFX_MAPI_WLAN_COUNTRY_IC:
               chList = regDomainUSA_11g;
               break;
            case IFX_MAPI_WLAN_COUNTRY_CHINA:
            case IFX_MAPI_WLAN_COUNTRY_FRANCE:
            case IFX_MAPI_WLAN_COUNTRY_GER:
            case IFX_MAPI_WLAN_COUNTRY_ETSI:
            case IFX_MAPI_WLAN_COUNTRY_ESP:
               chList = regDomainWorld_11g;
               break;
            case IFX_MAPI_WLAN_COUNTRY_JAPAN:
               /*
                  in 802.11b mode Japan allows channel 1 to 14, in 802.11bg,
                  802.11g and 802.11n only channel 1 to 13 is allowed
               */
               if(wlChanList->std == IFX_MAPI_WLAN_STD_802_11B)
                  chList = regDomainJapan_11b;
               else
                  chList = regDomainJapan_11g;
/*
                  chList = regDomainJapan_11b;
*/
                  break;
         }
         break;
      case IFX_MAPI_WLAN_STD_802_11N:
        if(wlChanList->freqBand != IFX_MAPI_WLAN_2_4_GHz_Freq) {
            switch (country)
            {
               case IFX_MAPI_WLAN_COUNTRY_INDIA:
               case IFX_MAPI_WLAN_COUNTRY_US:
               case IFX_MAPI_WLAN_COUNTRY_IC:
                  chList = regDomainWorld_11a;
                  break;
               case IFX_MAPI_WLAN_COUNTRY_FRANCE:
               case IFX_MAPI_WLAN_COUNTRY_GER:
               case IFX_MAPI_WLAN_COUNTRY_ETSI:
               case IFX_MAPI_WLAN_COUNTRY_ESP:
                  chList = regDomainEurope_11a;
                  break;
               case IFX_MAPI_WLAN_COUNTRY_CHINA:
                  chList = regDomainChina_11a;
                  break;
               case IFX_MAPI_WLAN_COUNTRY_JAPAN:
                  chList = regDomainJapan_11a;
                  break;
               default:
                  break;
            }
        } else { 
	    switch(country) {
                case IFX_MAPI_WLAN_COUNTRY_INDIA:
                case IFX_MAPI_WLAN_COUNTRY_US:
                case IFX_MAPI_WLAN_COUNTRY_IC:
                   chList = regDomainUSA_11g;
                 break;
                case IFX_MAPI_WLAN_COUNTRY_CHINA:
                case IFX_MAPI_WLAN_COUNTRY_FRANCE:
                case IFX_MAPI_WLAN_COUNTRY_GER:
                case IFX_MAPI_WLAN_COUNTRY_ETSI:
                case IFX_MAPI_WLAN_COUNTRY_ESP:
                    chList = regDomainWorld_11g;
                 break;
                case IFX_MAPI_WLAN_COUNTRY_JAPAN:
               /*
                  in 802.11b mode Japan allows channel 1 to 14, in 802.11bg,
                  802.11g and 802.11n only channel 1 to 13 is allowed
               */
                   if(wlChanList->std == IFX_MAPI_WLAN_STD_802_11B)
                      chList = regDomainJapan_11b;
                   else
                      chList = regDomainJapan_11g;
/*
                  chList = regDomainJapan_11b;
*/
                break;
             }
        }  
        break;
      default:
			   IFX_MAPI_DEBUG(fd,"/tmp/ifx_mapi_get_wlan_channel_list","failure");
         return IFX_FAILURE;
   }

   for(i = 0; i < chList.length; i++)
      wlChanList->chanNumList[i] = chList.channels[i];
   wlChanList->chanNumList[i] = 0;
   wlChanList->length = chList.length;
			   IFX_MAPI_DEBUG(fd,"/tmp/ifx_mapi_get_wlan_channel_list","success");
   return IFX_SUCCESS;
}

#ifdef CONFIG_FEATURE_IFX_WIRELESS_TSC
int32 max_mib_uint32Get(int32 devType, uint32 cmd ,uint32 *mib_retVal)
{
   char8 buf[128]={0};
   FILE *fp=NULL;
   char8 line[1024]={0};
   uint32 i=0;
   char8 *tmp=NULL;
   char8 *saveptr=NULL;
   int32	ret = IFX_SUCCESS;

#ifdef IFX_LOG_DEBUG
   IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif

      sprintf(buf, "%s %s %d %x", WLAN_UTIL_SCRIPT, "stats", devType, cmd);
   system(buf);
   fp = fopen("/tmp/tsc_wlan_stats","r");
      // fp = popen(buf, "r");

#ifdef IFX_LOG_DEBUG
   IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif
   while(1) {
      if(fp == NULL)
         break;
      if(feof(fp) || ferror(fp))
         break;

      memset(line,0x00,sizeof(1024));
      if(fgets(line,1024,fp)!= NULL) {
         if(i==1) {
   #ifdef IFX_LOG_DEBUG
            IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
   #endif
            if(strstr(line,"B_I>")!=NULL) {
               tmp = strtok_r(line,">",&saveptr);
               tmp = strtok_r(NULL,"\n",&saveptr);
               if(tmp != NULL)
                  *mib_retVal= atoi(tmp);
               break;
            } else {
               ret = IFX_FAILURE;
               goto IFX_Handler;
            }
         }
      }
      ++i;
   }

IFX_Handler:
   if(fp)
      fclose(fp);
   remove("/tmp/tsc_wlan_stats");
   if(ret != IFX_SUCCESS)
      return ret;
   else
      return IFX_SUCCESS;

}
#endif /* #ifdef CONFIG_FEATURE_IFX_WIRELESS_TSC */

/**

   \param   wlStats      - pointer to IFX_MAPI_WLAN_Stats structure

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_stats(IFX_MAPI_WLAN_Stats *wlStats, uint32 flags)
{
   int32    ret = IFX_SUCCESS, passedIndex = -1;
   char8    buf[MAX_FILELINE_LEN], sValue[MAX_DATA_LEN], sValueTmp[MAX_DATA_LEN];
   char8    *pTmpStr = NULL, *pTmpStr2 = NULL;
   CPE_ID   cpe_id;

   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "");

   memset(&cpe_id, 0x00, sizeof(cpe_id));
   cpe_id.Id = wlStats->iid.cpeId.Id;
   sprintf(cpe_id.secName, "%s", TAG_WLAN_MAIN);
   IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id, passedIndex)
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "passedIndex: %d", passedIndex);
   if (passedIndex < 0) {
	   	   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats",
			   "passed_index: %d", passedIndex);
	   	   ret = IFX_FAILURE;
	   	   goto IFX_Handler;
   }

   NULL_TERMINATE(buf, 0x00, sizeof(buf));
   memset(sValue, 0x00, sizeof(sValue));
   sprintf(buf, "%s %d", SERVICE_WLAN_GET_STATS, passedIndex);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "buf: %s", buf);

   if (ifx_GetCfgData((char8*)buf, NULL, "-1", sValue) == 0) {
	   ret = IFX_FAILURE;
	   goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "sValue: %s", sValue);
   /* save buffer in sValueTmp */
   strcpy(sValueTmp, sValue);

   if((pTmpStr = strstr(sValue,"bytesTx")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      wlStats->bytesTx = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "bytesTx: %d", wlStats->bytesTx);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   if((pTmpStr = strstr(sValue,"bytesRx")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      wlStats->bytesRx = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "bytesRx: %d", wlStats->bytesRx);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   if((pTmpStr = strstr(sValue,"errorsTx")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      wlStats->errorsTx = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "errorsTx: %d", wlStats->errorsTx);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   if((pTmpStr = strstr(sValue, "errorsRx")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      wlStats->errorsRx = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "errorsRx: %d", wlStats->errorsRx);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   if((pTmpStr = strstr(sValue,"pktsTx")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      wlStats->pktsTx = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "pktsTx: %d", wlStats->pktsTx);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   if((pTmpStr = strstr(sValue, "pktsRx")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      wlStats->pktsRx = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "pktsRx: %d", wlStats->pktsRx);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   if((pTmpStr = strstr(sValue,"ucPktsTx")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      wlStats->ucPktsTx = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "ucPktsTx: %d", wlStats->ucPktsTx);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   if((pTmpStr = strstr(sValue, "ucPktsRx")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      wlStats->ucPktsRx = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "ucPktsRx: %d", wlStats->ucPktsRx);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   if((pTmpStr = strstr(sValue,"mcPktsTx")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      wlStats->mcPktsTx = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "mcPktsTx: %d", wlStats->mcPktsTx);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   if((pTmpStr = strstr(sValue, "mcPktsRx")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      wlStats->mcPktsRx = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "mcPktsRx: %d", wlStats->mcPktsRx);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   if((pTmpStr = strstr(sValue,"bcPktsTx")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      wlStats->bcPktsTx = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "bcPktsTx: %d", wlStats->bcPktsTx);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   if((pTmpStr = strstr(sValue, "bcPktsRx")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      wlStats->bcPktsRx = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "bcPktsRx: %d", wlStats->bcPktsRx);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   if((pTmpStr = strstr(sValue,"discardPktsTx")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      wlStats->discardPktsTx = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "discardPktsTx: %d", wlStats->discardPktsTx);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "sValue: %s",sValue);

   /* restore sValue buffer from sValueTmp */
   strcpy(sValue, sValueTmp);
   if((pTmpStr = strstr(sValue, "discardPktsRx")) != NULL)
   {
      pTmpStr2 = strtok(pTmpStr, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      pTmpStr2 = strtok(NULL, "\"");
      if(pTmpStr2 == NULL)
      {
          ret = IFX_FAILURE;
          goto IFX_Handler;
      }
      wlStats->discardPktsRx = atoi(pTmpStr2);
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "discardPktsRx: %d", wlStats->discardPktsRx);
   }
   else
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "sValue: %s",sValue);

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlanStats", "ret: %d", ret);
   if(ret != IFX_SUCCESS) {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return IFX_FAILURE;
   }
   else
      return IFX_SUCCESS;
}

/**
   This api reads

   \param   wlRadius

   \param   flags -

   \return
      IFX_SUCCESS or IFX_FAILURE
*/
int32 ifx_mapi_get_wlan_802_1x_config(IFX_MAPI_WLAN_802_1x *wlRadius, uint32 flags)
{
   int32	   			ret = IFX_SUCCESS;
   int32	   			passed_index = -1;
   char8	   			buf[MAX_DATA_LEN];
   char8	   			*sValueNew = NULL;
   int32    			count, i;
   IFX_NAME_VALUE_PAIR  array_fvp[WLAN_802_1X_PARAM_COUNT + 1];

   sprintf(wlRadius->iid.cpeId.secName, "%s", TAG_WLAN_1X);
   sprintf(wlRadius->iid.pcpeId.secName, "%s", TAG_WLAN_1X);
   IFX_GET_INDEX_FROM_PCPEID(FILE_RC_CONF, wlRadius->iid.pcpeId, passed_index)
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlan8021xConfig", "passed_index: %d", passed_index);

   /* get wps object from rc.conf */
   sprintf(buf, "%s_%d_", PREFIX_WLAN_SEC_1X, passed_index);
   if((ret = ifx_GetCfgObject(FILE_RC_CONF, TAG_WLAN_1X, buf, flags, &sValueNew)) != IFX_SUCCESS)
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlan8021xConfig", "buf: %s", buf);
      goto IFX_Handler;
   }
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlan8021xConfig", "buf: %s, sValue: %s",
                  buf, sValueNew);

   /* form an array of field value pairs for easier access to parameters */
   memset(array_fvp, 0x00, sizeof(array_fvp));
   form_array_fvp_from_cfgdb_buf(sValueNew, &count, array_fvp);
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlan8021xConfig", "count: %d", count);
   for (i = 0; i < count; i++)
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlan8021xConfig", "%s:%s", array_fvp[i].fieldname, array_fvp[i].value);

   wlRadius->iid.cpeId.Id        = atoi(array_fvp[0].value);
   wlRadius->iid.pcpeId.Id       = atoi(array_fvp[1].value);
   wlRadius->groupKeyEna         = atoi(array_fvp[2].value);
   wlRadius->groupKeyIntvl       = atoi(array_fvp[3].value);
   wlRadius->wpa2PreAuthEna      = atoi(array_fvp[4].value);
   wlRadius->wpa2ReAuthIntvl     = atoi(array_fvp[5].value);
   wlRadius->authType            = atoi(array_fvp[7].value);
   wlRadius->authProto           = atoi(array_fvp[8].value);
   if (!(inet_aton(array_fvp[9].value, &wlRadius->radiusServerIP)))
   {
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlan8021xConfig", "inet_aton error");
      goto IFX_Handler;
   }
   wlRadius->radiusPort          = atoi(array_fvp[10].value);
   snprintf(wlRadius->radiusServerSecret, IFX_MAPI_PASSPHRASE_MAX_LEN, "%s", array_fvp[11].value);
   snprintf(wlRadius->domainName, IFX_MAPI_RADIUS_AUTH_DOMAIN, "%s", array_fvp[12].value);
   snprintf(wlRadius->userName, IFX_MAPI_RADIUS_AUTH_USER, "%s", array_fvp[13].value);

IFX_Handler:
   IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWlan8021xConfig", "ret: %d", ret);
   IFX_MEM_FREE(sValueNew);
   return ret;
}


/**
   This api reads

   \param   wepkeyindex

   \param   cpeid

   \return
      IFX_SUCCESS or IFX_FAILURE
*/


int32 ifx_mapi_get_wlan_wepkeyindex (
                              uint32 cpeid,
                              uint32 *keyindex)
{
    int32   ret = IFX_SUCCESS, passed_index = -1;
    char8   buf[MAX_FILELINE_LEN], sValue[MAX_FILELINE_LEN];
    CPE_ID   cpe_id;
    uint32	outFlag = IFX_F_DEFAULT;

    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWepKeyIndex", "");

    sprintf(cpe_id.secName, "%s", TAG_WLAN_SEC);
    cpe_id.Id = cpeid;

   /* get index from cpeid first */
    IFX_GET_INDEX_FROM_CPEID(FILE_RC_CONF, cpe_id, passed_index)
    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWepKeyIndex", "passed_index:%d", passed_index);

    sprintf(buf, "%s_%d_wepKeyIndx", PREFIX_WLAN_SEC, passed_index);
    if ((ret = ifx_GetObjData(FILE_RC_CONF, TAG_WLAN_SEC,
      buf, IFX_F_GET_ANY, &outFlag, sValue)) != IFX_SUCCESS)
    {
#ifdef IFX_LOG_DEBUG
      IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif /* #ifdef IFX_LOG_DEBUG */
      IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWepKeyIndex", "");
      goto IFX_Handler;
    }

    *keyindex = atoi(sValue);

 IFX_Handler:
    IFX_MAPI_DEBUG(fd, "/tmp/ifxMapiGetWepKeyIndex", "ret: %d", ret);
    if(ret != IFX_SUCCESS) {
      IFX_API_LOG("[%s] : returned failure!", __FUNCTION__);
      return ret;
    }
    else
      return IFX_SUCCESS;

}

#endif // CONFIG_FEATURE_IFX_WIRELESS
