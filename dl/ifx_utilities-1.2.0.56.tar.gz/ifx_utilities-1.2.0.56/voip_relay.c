#include <ifx_config.h>

#ifdef CONFIG_FEATURE_IFX_VOIP
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#ifndef CPU_DANUBE
#include <asm/amazon/port.h>
#else
#include <asm/danube/port.h>
#endif
#include <string.h>
#define AMAZON_GPIO_DEVICE	"/dev/amazon_port"
#define AMAZON_GPIO_RELAY	27

#ifdef IFX_MULTILIB_UTIL
#define	main	voip_relay_main
#define usage	voip_relay_usage
#endif
void AMAZON_GPIO_CONTROL(int GPIO_NO,int enable)
{
        int fd;
#ifndef CPU_DANUBE
        struct amazon_port_ioctl_parm parm;
        memset(&parm,0,sizeof(struct amazon_port_ioctl_parm));
#else
        struct danube_port_ioctl_parm parm;
        memset(&parm,0,sizeof(struct danube_port_ioctl_parm));
#endif

        fd = open(AMAZON_GPIO_DEVICE,O_RDWR);
        if (fd<=0)
                return;
        parm.pin=GPIO_NO;
        if (parm.pin<16)
        {
             parm.port = 0;
        }
        else if (parm.pin < 32)
        {
             parm.port = 1;
             parm.pin -= 16;
        }else
                return;
        parm.value=1;
#ifndef CPU_DANUBE
        ioctl(fd,AMAZON_PORT_IOCOD,&parm);
#else
        ioctl(fd,DANUBE_PORT_IOCOD,&parm);
#endif
        parm.value=0;
#ifndef CPU_DANUBE
        ioctl(fd,AMAZON_PORT_IOCALTSEL0,&parm);
        ioctl(fd,AMAZON_PORT_IOCALTSEL1,&parm);
#else
        ioctl(fd,DANUBE_PORT_IOCALTSEL0,&parm);
        ioctl(fd,DANUBE_PORT_IOCALTSEL1,&parm);

#endif
        parm.value=1;
#ifndef CPU_DANUBE
        ioctl(fd,AMAZON_PORT_IOCDIR,&parm);
#else
        ioctl(fd,DANUBE_PORT_IOCDIR,&parm);
#endif
        if (enable)
                parm.value=1;
        else
                parm.value=0;
#ifndef CPU_DANUBE
        ioctl(fd,AMAZON_PORT_IOCOUTPUT,&parm);
#else
        ioctl(fd,DANUBE_PORT_IOCOUTPUT,&parm);
#endif
        close(fd);
}

void usage(char *program_name)
{
	printf("usage: %s <0/1>\n\t0: turn relay off\n\t1:turn relay on\n",program_name);
}
int main(int argc, char *argv[])
{
	if (argc <1)
	{
		usage(argv[0]);
   		return 1;
	}
	if (argv[1][0]!='0' && argv[1][0]!='1')
	{
		usage(argv[0]);
   		return 1;
	}
#ifndef CPU_DANUBE
        AMAZON_GPIO_CONTROL(AMAZON_GPIO_RELAY,atoi(argv[1]));
#endif
	
	return 0;
}
#endif
