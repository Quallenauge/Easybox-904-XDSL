#include <stdio.h>
#include <stdlib.h>
#include <linux/types.h>
#include <netinet/in.h>
#include <linux/netlink.h>
#include <string.h>
#include <syslog.h>
#include <sys/socket.h>
#include <linux/atm_autosearch.h>
#include <ifx_common.h>
#include <ifx_amazon_cfg.h>
#include<unistd.h>

#define AUTOSEARCH_MAX_RETRY	3


int as_retry = 0;
char ash_status;
int autosearch_action(int);
int create_nl_socket(void);

static int ash_sd;
int first_trial_failure = 0;

char f_AUTOSEARCH_PART1_FAIL = 0;
char f_AUTOSEARCH_PART2_FAIL = 0;
char f_PVC_DELETE_PART1_OK = 0;
char f_PVC_DELETE_PART2_OK = 0;
char f_AUTOSEARCH_PVC_DONE = 0;
char f_FOUND_EXISTED_PVC_FAIL = 0;
char f_AUTOSEARCH_BRIDGE_MODE = 0;
char f_AUTOSEARCH_ROUTER_MODE = 0;

int mac1;
int mac2;
int mac3;
int mac4;
int mac5;
int mac6;

int exist_vpi;
int exist_vci;
int prev_exist_vpi;
int prev_exist_vci;
char sValue[128];
char sCheck[128];


int as_run_dhcp(int nas)
{
    char cmd[512];
    memset(cmd, '0', 512);
    //sbin/udhcpc -b -i $wan_iface -p /var/run/udhcpc$1.pid -s /etc/rc.d/udhcpc.script &
    sprintf(cmd,
	    "/sbin/udhcpc -b -i nas%d -p /var/run/udhcpc%d.pid -s /etc/rc.d/udhcpc.script &",
	    nas, nas);
    printf("in as_run_dhcp cmd is %s\n", cmd);
    system(cmd);
    return 0;
}


int as_run_pppoe(int nas)
{
    char cmd[256];
    char cmd2[256];
    char cmd3[512];

    system("echo \"maxfail 0\" > /etc/ppp/options");
    system("echo \"persist\" >> /etc/ppp/options");
    memset(cmd, '0', 256);
    sprintf(cmd, "/ramdisk/etc/ppp/peers/pppoe%d", nas + 1);
    sprintf(cmd2, "linkname pppoe-%d", nas + 1);
    sprintf(cmd3, "echo %s > %s", cmd2, cmd);
    system(cmd3);
    memset(cmd3, '0', 512);
    sprintf(cmd3, "echo lcp-echo-interval 10 >> %s", cmd);
    system(cmd3);
    memset(cmd3, '0', 512);
    sprintf(cmd3, "echo lcp-echo-failure 3 >> %s", cmd);
    system(cmd3);
    memset(cmd3, '0', 512);
    sprintf(cmd3, "echo unit 0 >> %s", cmd);
    system(cmd3);
    memset(cmd3, '0', 512);
    sprintf(cmd3, "echo maxfail 0 >> %s", cmd);
    system(cmd3);
    memset(cmd3, '0', 512);
    sprintf(cmd3, "echo usepeerdns >> %s", cmd);
    system(cmd3);
    memset(cmd3, '0', 512);
    sprintf(cmd3, "echo defaultroute >> %s", cmd);
    system(cmd3);
    memset(cmd3, '0', 512);
    sprintf(cmd3, "echo user chap1 >> %s", cmd);
    system(cmd3);
    memset(cmd3, '0', 512);
    sprintf(cmd3, "echo password chap1 >> %s", cmd);
    system(cmd3);
    memset(cmd3, '0', 512);
    sprintf(cmd3, "echo mtu 1400 >> %s", cmd);
    system(cmd3);
    memset(cmd3, '0', 512);
    sprintf(cmd3, "echo mru 1400 >> %s", cmd);
    system(cmd3);
    memset(cmd3, '0', 512);
    sprintf(cmd3, "echo holdoff 4 >> %s", cmd);
    system(cmd3);
    memset(cmd3, '0', 512);
    sprintf(cmd3, "echo persist >> %s", cmd);
    system(cmd3);
    memset(cmd3, '0', 512);
    sprintf(cmd3, "echo plugin /usr/lib/pppd/2.4.2/rp-pppoe.so >> %s",
	    cmd);
    system(cmd3);
    memset(cmd3, '0', 512);
    memset(cmd2, '0', 256);
    sprintf(cmd2, "nas%d", nas);
    sprintf(cmd3, "echo %s >> %s", cmd2, cmd);
    system(cmd3);
    memset(cmd3, '0', 512);
    sprintf(cmd3, "echo debug >> %s", cmd);
    system(cmd3);

    memset(cmd3, '0', 512);
    memset(cmd2, '0', 256);
    sprintf(cmd2, "pppoe%d", nas + 1);
    sprintf(cmd3, "/usr/sbin/pppd file /etc/ppp/options call  %s", cmd2);
    system(cmd3);
    return 0;
}

int as_create_pvc(int nas, int vpi, int vci)
{
    char cmd[256];
    memset(cmd, '0', 256);
    sprintf(cmd, "br2684ctl -c %d -a %d.%d", nas, vpi, vci);
    printf("in as_create_pvc cmd is %s\n", cmd);
    system(cmd);
    return 0;
}

int as_kill_pvc(int nas)
{
    char cmd[256];
    memset(cmd, '0', 256);
    sprintf(cmd, "br2684ctl -k %d ", nas);
    printf("in as_kill_pvc cmd is %s\n", cmd);
    system(cmd);
    return 0;
}

int as_addbr(int nas)
{
    char cmd[256];
    memset(cmd, '0', 256);
    sprintf(cmd, "brctl addif br0 nas%d", nas);
    printf("in as_addbr cmd is %s\n", cmd);
    system(cmd);
    return 0;
}

int as_ifup(int nas)
{
    char cmd[256];
    memset(cmd, '0', 256);
    sprintf(cmd, "ifconfig nas%d up", nas);
    printf("in as_ifup cmd is %s\n", cmd);
    system(cmd);
    return 0;
}


int as_get_cpe_mac()
{
    FILE *fd;
    char buff[30] = { 0 };
 
    system("upgrade mac_get 1 > /tmp/tmp_mac");
    fd = fopen("/tmp/tmp_mac", "rb");
    if (fd == NULL) {
	printf("get mac error\n");
	exit(-1);
    }
    fread(buff, 1, 18, fd);
    sscanf(buff, "%x:%x:%x:%x:%x:%x", &mac1, &mac2, &mac3, &mac4, &mac5,
	   &mac6);
    printf("current mac2  is %02x:%02x:%02x:%02x:%02x:%02x \n", mac1, mac2,
	   mac3, mac4, mac5, mac6);
   return 0;
}

int as_change_mac(int nas)
{
    char cmd[256];
    memset(cmd, '0', 256);
    sprintf(cmd, "ifconfig nas%d hw ether  %02x:%02x:%02x:%02x:%02x:%02x",
	    nas, mac1, mac2, mac3, mac4, mac5, mac6 + 3 + nas);
    printf("in as_change_mac cmd is %s\n", cmd);
    system(cmd);
    return 0;
}

int main(int argc, char *argv[])
{
    FILE *f_ash;
    int pid = 0;
    //char cmd[128];
   // char cmd2[128];
    //int found_pvc_before = 0;

    create_nl_socket();
    pid = getpid();
    f_ash = fopen("/var/run/ash.pid", "w");
    if (!f_ash) {
	printf("/n Error opening file: /var/run/ash.pid !\n");
	return -1;
    }

    fprintf(f_ash, "%d", pid);
    fclose(f_ash);

    // grep the latest mac    
    as_get_cpe_mac();

    ifx_GetCfgData(FILE_RC_CONF, "auto_pvc_mode", "autopvc_mode", sValue);
    if (sValue[0] == '0') {
	printf("bridge mode\n");
	autosearch_action(AUTOSEARCH_BRIDGE_MODE);
	f_AUTOSEARCH_BRIDGE_MODE = 1;
    } else {
	autosearch_action(AUTOSEARCH_ROUTER_MODE);
	f_AUTOSEARCH_ROUTER_MODE = 1;
    }

    //check whether we have ran autosearch before 
    //create only one PVC and send PVC_CREATION_OK to kernel


    ifx_GetCfgData(FILE_RC_CONF, "auto_pvc_db_previous",
		   "autovcc_previous", sValue);
    printf("exist sValue is %s \n", sValue);
    sscanf(sValue, "%d/%d", &prev_exist_vpi, &prev_exist_vci);
    printf("vpi is %d vci is %d\n", prev_exist_vpi, prev_exist_vci);
    if (prev_exist_vpi != -1 && prev_exist_vci != -1) {
	autosearch_action(FOUND_EXISTED_PVC);
    } else {
	autosearch_action(PVC_CREATION_PART1_OK);
    }

    while (1) {
	
	//polling autosearch status
	autosearch_action(AUTOSEARCH_POLLING);

	if (f_AUTOSEARCH_PART1_FAIL) {
	    autosearch_action(PVC_DELETE_PART1_OK);
	    f_AUTOSEARCH_PART1_FAIL = 0;
	}

	if (f_AUTOSEARCH_PART2_FAIL) {
	    autosearch_action(PVC_DELETE_PART2_OK);
	    f_AUTOSEARCH_PART2_FAIL = 0;
	    as_retry++;
	    if (as_retry <= AUTOSEARCH_MAX_RETRY) {
		autosearch_action(PVC_CREATION_PART1_OK);
	    } else {
		printf
		    ("Autosearch has tried %d time,but no PVC found . Stop here.\n",
		     AUTOSEARCH_MAX_RETRY);
		break;
	    }
	}

	if (f_PVC_DELETE_PART1_OK) {
	    autosearch_action(PVC_CREATION_PART2_OK);
	    f_PVC_DELETE_PART1_OK = 0;
	}
	if (f_FOUND_EXISTED_PVC_FAIL) {
	    //need to delete existed PVC here
	    system("br2684ctl -k 0");
	    autosearch_action(PVC_CREATION_PART1_OK);
	    f_FOUND_EXISTED_PVC_FAIL = 0;
	}

	if (f_AUTOSEARCH_PVC_DONE) {
	    //printf("break Autosearch user space app !!! \n");
	    break;
	}

    }

    printf("Autosearch Userspace Application ends\n");

    return 0;
}





int autosearch_action(int arg)
{
    struct nlmsghdr *nlh = NULL;
    int size;
    struct sockaddr_nl dest_addr;
    struct msghdr rxmsg, txmsg;
    struct iovec rxiov, txiov;
    unsigned char as_msg[128];
    unsigned char as_vpi;
    unsigned short as_vci;
    int i;
    //char cmd[128];
    char cmd2[128];

    memset(&dest_addr, 0, sizeof(dest_addr));

    dest_addr.nl_family = AF_NETLINK;
    dest_addr.nl_pid = 0;
    dest_addr.nl_groups = 0;

    nlh = (struct nlmsghdr *) malloc(64);
    nlh->nlmsg_len = 64;
    nlh->nlmsg_pid = getpid();
    nlh->nlmsg_flags = 0;


    txiov.iov_base = (void *) nlh;
    txiov.iov_len = nlh->nlmsg_len;

    txmsg.msg_name = (void *) &dest_addr;
    txmsg.msg_namelen = sizeof(dest_addr);
    txmsg.msg_iov = &txiov;
    txmsg.msg_iovlen = 1;
    txmsg.msg_control = NULL;
    txmsg.msg_controllen = 0;
    txmsg.msg_flags = 0;
    switch (arg) {

    case FOUND_EXISTED_PVC:
	as_create_pvc(0, prev_exist_vpi, prev_exist_vci);
	as_change_mac(0);
	as_msg[0] = FOUND_EXISTED_PVC;
	as_msg[1] = '\0';
	strcpy(NLMSG_DATA(nlh), as_msg);
	system("ifconfig nas0 up");
	if (f_AUTOSEARCH_BRIDGE_MODE) {
	    system("brctl addif br0 nas0");
	} else			//Roter mode
	{
	    as_run_pppoe(0);
	}

	break;

    case AUTOSEARCH_BRIDGE_MODE:
	as_msg[0] = AUTOSEARCH_BRIDGE_MODE;
	as_msg[1] = '\0';
	strcpy(NLMSG_DATA(nlh), as_msg);
	break;

    case AUTOSEARCH_ROUTER_MODE:
	as_msg[0] = AUTOSEARCH_ROUTER_MODE;
	as_msg[1] = '\0';
	strcpy(NLMSG_DATA(nlh), as_msg);
	break;


    case PVC_CREATION_PART1_OK:

	for (i = 0; i < MAX_PVC_TRYING; i++) {
	    sprintf(cmd2, "autovcc_%d", i);
	    ifx_GetCfgData(FILE_RC_CONF, "auto_pvc_db", cmd2, sValue);
	    sscanf(sValue, "%d/%d", &exist_vpi, &exist_vci);
	    if (exist_vpi != -1 && exist_vci != -1) {
		as_create_pvc(i, exist_vpi, exist_vci);
		as_change_mac(i);
		as_ifup(i);
		if (f_AUTOSEARCH_BRIDGE_MODE) {
		    as_addbr(i);
		} else		//AUTOSEARCH_ROUTER_MODE
		{

		    printf("saerch %dth PVC\n", i);
		    //as_run_pppoe(i);
		    as_run_dhcp(i);
		    sleep(3);
		    autosearch_action(AUTOSEARCH_POLLING);
		    if (f_AUTOSEARCH_PVC_DONE) {
			break;	//found PVC
		    }
		    as_run_pppoe(i);
		    //as_run_dhcp(i);
		    sleep(2);
		    autosearch_action(AUTOSEARCH_POLLING);
		    if (f_AUTOSEARCH_PVC_DONE) {
			break;	//found PVC
		    } else {
			as_kill_pvc(i);
			if (i == (MAX_PVC_TRYING - 1))
			    f_PVC_DELETE_PART1_OK = 1;
			else
			    continue;
		    }

		}

	    }
	}


	as_msg[0] = PVC_CREATION_PART1_OK;
	as_msg[1] = '\0';
	strcpy(NLMSG_DATA(nlh), as_msg);
	break;

    case PVC_CREATION_PART2_OK:
	for (i = 0; i < MAX_AUTOSEARCH_PVC - MAX_PVC_TRYING; i++) {
	    sprintf(cmd2, "autovcc_%d", i + MAX_PVC_TRYING);
	    ifx_GetCfgData(FILE_RC_CONF, "auto_pvc_db", cmd2, sValue);
	    sscanf(sValue, "%d/%d", &exist_vpi, &exist_vci);
	    if (exist_vpi != -1 && exist_vci != -1) {
		as_create_pvc(i, exist_vpi, exist_vci);
		as_change_mac(i);
		as_ifup(i);
		if (f_AUTOSEARCH_BRIDGE_MODE) {
		    as_addbr(i);
		} else		//AUTOSEARCH_ROUTER_MODE
		{
		    printf("saerch %dth PVC\n", i);
		    as_run_dhcp(i);
		    //as_run_pppoe(i);
		    sleep(3);
		    autosearch_action(AUTOSEARCH_POLLING);
		    if (f_AUTOSEARCH_PVC_DONE) {
			break;	//found PVC
		    }
		    as_run_pppoe(i);
		    //as_run_dhcp(i);
		    sleep(2);
		    autosearch_action(AUTOSEARCH_POLLING);
		    if (f_AUTOSEARCH_PVC_DONE) {
			break;	//found PVC
		    } else {
			if (i == (MAX_AUTOSEARCH_PVC - MAX_PVC_TRYING - 1)) {
			    f_AUTOSEARCH_PART2_FAIL = 1;
			} else {
			    as_kill_pvc(i);
			}
		    }
		}

	    }
	}


	as_msg[0] = PVC_CREATION_PART2_OK;
	as_msg[1] = '\0';
	strcpy(NLMSG_DATA(nlh), as_msg);
	printf("Send PVC_CREATION_PART2_OK to kernel\n ");
	break;

	/*case PVC_CREATION_PART3_OK:
	   as_msg[0] = PVC_CREATION_PART3_OK ;
	   as_msg[1] = '\0' ;
	   strcpy(NLMSG_DATA(nlh),as_msg);
	   printf("Send PVC_CREATION_PART3_OK to kernel\n ");
	   break;
	 */
    case PVC_DELETE_PART1_OK:
	//delete all nas
	for (i = 0; i < MAX_PVC_TRYING; i++) {
	    as_kill_pvc(i);
	}

	as_msg[0] = PVC_DELETE_PART1_OK;
	as_msg[1] = '\0';
	strcpy(NLMSG_DATA(nlh), as_msg);
	printf("Send PVC_DELETE_PART1_OK to kernel\n");
	f_PVC_DELETE_PART1_OK = 1;
	break;

    case PVC_DELETE_PART2_OK:
	//delete all nas
	for (i = 0; i < MAX_AUTOSEARCH_PVC - MAX_PVC_TRYING; i++) {
	    as_kill_pvc(i);
	}

	as_msg[0] = PVC_DELETE_PART2_OK;
	as_msg[1] = '\0';
	strcpy(NLMSG_DATA(nlh), as_msg);
	printf("Send PVC_DELETE_PART2_OK to kernel\n");
	f_PVC_DELETE_PART2_OK = 1;
	break;

    case AUTOSEARCH_POLLING:
	as_msg[0] = AUTOSEARCH_POLLING;
	as_msg[1] = '\0';
	strcpy(NLMSG_DATA(nlh), as_msg);

	break;

    default:
	break;
    }

    if (sendmsg(ash_sd, &txmsg, 0) < 0) {
	printf("\n tx_msg autosearch error!  ");
	return -1;
    }

    memset(nlh, '0', 64);
    rxiov.iov_base = (void *) nlh;
    rxiov.iov_len = nlh->nlmsg_len;


    rxmsg.msg_name = (void *) &dest_addr;
    rxmsg.msg_namelen = sizeof(dest_addr);
    rxmsg.msg_iov = &rxiov;
    rxmsg.msg_iovlen = 1;
    rxmsg.msg_control = NULL;
    rxmsg.msg_controllen = 0;
    rxmsg.msg_flags = 0;



    /* read whole structure */

    size = recvmsg(ash_sd, &rxmsg, 0);
    unsigned char *rcv_status;
    rcv_status = NLMSG_DATA(nlh);

    switch (rcv_status[0]) {
    case AUTOSEARCH_PART1_FAIL:
	f_AUTOSEARCH_PART1_FAIL = 1;
#ifdef IFX_AUTOSEARCH_DEBUG
	printf("!!!! AUTOSEARCH_PART1_FAIL !!!! \n");
#endif

	break;


    case AUTOSEARCH_PART2_FAIL:
	f_AUTOSEARCH_PART2_FAIL = 1;
#ifdef IFX_AUTOSEARCH_DEBUG
	printf("!!!! AUTOSEARCH_PART2_FAIL !!!! \n");
#endif

	break;

    case FOUND_EXISTED_PVC_FAIL:
	f_FOUND_EXISTED_PVC_FAIL = 1;
#ifdef IFX_AUTOSEARCH_DEBUG
	printf("!!!! FOUND_EXISTED_PVC_FAIL !!!! \n");
#endif
	break;

    case AUTOSEARCH_PVC_DONE:
	f_AUTOSEARCH_PVC_DONE = 1;

	if (rcv_status[1] == PVC_SPECIAL_CASE) {
	    as_vpi = 0;
	} else {
	    as_vpi = rcv_status[2];
	}

	if (rcv_status[3] == PVC_SPECIAL_CASE) {
	    as_vci = 0;
	} else {
	    as_vci = (0xff00 & rcv_status[5] << 8) + rcv_status[4];
	}


	//Only write to flash if we found need PVC
	if (as_vpi != prev_exist_vpi && as_vci != prev_exist_vci) {
	    sprintf(sCheck, "autovcc_previous=\"%d/%d\"\n", as_vpi,
		    as_vci);
	    ifx_SetCfgData(FILE_RC_CONF, "auto_pvc_db_previous", 1,
			   sCheck);
	    if (ifx_flash_write() <= 0) {
		printf("write flash_error\n");
	    }
	}

	printf
	    ("AUTOSEARCH_PVC_DONE: VPI1111 in user space is %d VCI is %d \n",
	     as_vpi, as_vci);

	break;

    default:
#ifdef IFX_AUTOSEARCH_DEBUG
	printf("Default rcv in user space \n");
	if (rcv_status != NULL) {
	    printf("Current[0] %d \n", rcv_status[0]);
	    printf("Current[1] %d \n", rcv_status[1]);
	    printf("Current[2] %d \n", rcv_status[2]);
	    printf("Current[3] %d \n", rcv_status[3]);
	}
#endif				//IFX_AUTOSEARCH_DEBUG
	break;

    }
    free(nlh);
    return 0;
}






int create_nl_socket(void)
{

    struct sockaddr_nl src_addr;//, dest_addr;
    int addr_len;

    ash_sd = socket(AF_NETLINK, SOCK_RAW, NETLINK_IFX_ASH);
    if (ash_sd < 0) {
	printf("Error opening Autosearch socket");
    }

    memset(&src_addr, 0, sizeof(src_addr));
    /* bind socket */
    src_addr.nl_family = AF_NETLINK;
    src_addr.nl_pad = 0;
    src_addr.nl_pid = getpid();
    src_addr.nl_groups = 0;

    if (bind(ash_sd, (struct sockaddr *) &src_addr, sizeof(src_addr)) < 0) {
	printf(" Error binding Autosearch socket");
    }

    addr_len = sizeof(src_addr);

    if (getsockname(ash_sd, (struct sockaddr *) &src_addr, &addr_len) < 0) {
	printf("cannot getsockname");
	return -1;
    }

    if (addr_len != sizeof(src_addr)) {
	printf("wrong address lenght %d\n", addr_len);
	return -1;
    }

    if (src_addr.nl_family != AF_NETLINK) {
	printf("wrong address family %d\n", src_addr.nl_family);
	return -1;
    }


    return 0;
}
