/* ============================================================================
 * Copyright (C) 2004 - Infineon Technologies.
 *
 * All rights reserved.
 * ============================================================================
 *
 * ============================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ============================================================================
 */
/*
506211:tc.chen 2005/06/11 fix application services can not work from wan side.
507141:tc.chen 2005/07/14 add netfilter module enable/disable code 
510251: sumedh Support for DoS, ALGs, QoS, Policy based Routing
604041: sumedh Parental Control feature added (Modified MAC Filter)
*/

#include <ifx_config.h>

#if defined(CONFIG_FEATURE_FIREWALL) || defined(CONFIG_FEATURE_NAPT)

#ifndef __be16
#define __be16 short int
#endif


#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <getopt.h>
#include <string.h>

#include <ifx_config.h>
#include <ifx_api_fw.h>
#include <ifx_api_napt.h>
#include "ifx_amazon_cfg.h"

#define TAG_LAN_IF	"lan_interface"
#define TAG_WAN_IF	"wan_interface"
#define FILE_SYSTEM_STATUS	"/tmp/system_status"

#ifdef IFX_MULTILIB_UTIL
#define main	naptcfg_main 
#endif

static void INIT_SERVICES();
static void INIT_SERVICES_ACL();

bool mac_strtoint(char *,char *);
bool IFX_FIREWALL_INIT();
bool IFXSetNAPTEnable(int,bool *);
bool IFX_SET_NAPT_DMZ(int operation,__u32 );
bool IFXSetFirewallServiceAclEntry(int,P_IFX_IPT_RULE pCfg,int *);
bool IFXSetFirewallPacketFilterEntry(int,P_IFX_IPT_RULE pCfg,int *);
bool IFXSetPolicyRouteEntry(int,P_IFX_IPT_RULE pCfg,int *);
bool IFX_SET_NAPT_DNAT_VIRTUALSERVER_Entry(int,P_IFX_IPT_RULE pCfg,int );
bool IFX_SET_NAPT_DNAT_PORTMAPPING_Entry(int,P_IFX_IPT_RULE pCfg,int *);
bool IFX_SET_FIREWALL_SERVICES_ACL_ENABLE(int,bool *);
bool IFXSetAppFilterYahoo(int);
bool IFXSetAppFilterMsn(int);
bool IFXSetAppFilter(int);
bool  IFX_NAPT_INIT();

int Get_LAN_IF(char *IF)
{
#ifdef CONFIG_FEATURE_IFX_WIRELESS_ATH
    char  sValue[256];

    if (ifx_GetCfgData("/etc/rc.conf", "wlan_status", "wlan_enable", sValue) == 1)
    {
        if (!strcmp(sValue,"1"))
	{
	    sprintf(IF,"%s","br0");
    	    return 0;
	}
    }
#endif
    //506211:tc.chen sprintf(IF,"%s","eth0");
    sprintf(IF,"%s","br0");
    return 0;
}

/* 507141:tc.chen add enable/disable netfilter module code  start*/
int update_netfilter_enable_flag()
{
	unsigned short pService_Info[]= {
#ifdef CONFIG_PACKAGE_IFX_HTTPD
		80,PROTO_TCP,
#endif
#ifdef CONFIG_FEATURE_TELNET_SERVER
	23,PROTO_TCP,
#endif
#ifdef CONFIG_FEATURE_SSH_SERVER
	22,PROTO_TCP,
#endif
#ifdef CONFIG_FEATURE_TFTP_SERVER
	69,PROTO_UDP,
#endif
#ifdef CONFIG_FEATURE_FTP_SERVER
	21,PROTO_TCP,
#endif
	};
	char	sParams[][32]={
#ifdef CONFIG_PACKAGE_IFX_HTTPD
	"WEB_WAN_ENABLE",   "WEB_WAN_PORT",   "WEB_LAN_ENABLE",
#endif //CONFIG_PACKAGE_IFX_HTTPD
#ifdef CONFIG_FEATURE_TELNET_SERVER
	"TELNET_WAN_ENABLE","TELNET_WAN_PORT","TELNET_LAN_ENABLE",
#endif //CONFIG_FEATURE_TELNET_SERVER
#ifdef CONFIG_FEATURE_SSH_SERVER
	"SSH_WAN_ENABLE",   "SSH_WAN_PORT",   "SSH_LAN_ENABLE",
#endif //CONFIG_FEATURE_SSH_SERVER
#ifdef CONFIG_FEATURE_TFTP_SERVER
	"TFTP_WAN_ENABLE",  "TFTP_WAN_PORT",  "TFTP_LAN_ENABLE",
#endif
#ifdef CONFIG_FEATURE_FTP_SERVER
	"FTP_WAN_ENABLE",   "FTP_WAN_PORT",   "FTP_LAN_ENABLE",
#endif //CONFIG_FEATURE_FTP_SERVER
	};
	bool bFWEnable,bACLEnable,bNAPTEnable,bQOS,bFWServiceEnable,bNAPTServiceEnable,	bPPACompiled = 0;
	int i=0;
	char sValue[3][32];
	char sPPACompiled[32];

	bFWEnable=bACLEnable=bNAPTEnable=bQOS=bFWServiceEnable=bNAPTServiceEnable=0;
    	if (ifx_GetCfgData("/etc/rc.conf","qos_config","QOS_ENABLE",sValue[0])==1)
	{
		if (sValue[0][0]=='1')
			bQOS = 1;
	}

	if (bQOS==1)
	{
	   	bFWEnable = bNAPTEnable = 1;	
	}else
	{
		IFX_SET_FIREWALL_SERVICES_ACL_ENABLE(GET, &bACLEnable);
    		IFXSetFirewallEnable(GET, &bFWEnable);
    		IFXSetNAPTEnable(GET, &bNAPTEnable);
		if (bFWEnable == 0 || bNAPTEnable == 0)
		{
			for (i=0;i<sizeof(sParams)/32;i++)
			{
				memset(sValue[i%3],0,32);
	    			ifx_GetCfgData("/etc/rc.conf","application_server",sParams[i],sValue[i%3]);
				if (i%3==0)
				{
					if (sValue[0][0]=='0')
						bFWServiceEnable=1;
				}
				if (i%3==1)
				{
					if (sValue[0][0]=='1' && atoi(sValue[1])!=pService_Info[i*2/3])
						bNAPTServiceEnable=1;
				}
			}
		}
	}
	if (ifx_GetCfgData("/tmp/system_status", "ppe_config_status", "ppe_firmware", sPPACompiled) == 1)
    {
   	    if (strcmp(sPPACompiled,"E1") || strcmp(sPPACompiled,"A1") || strcmp(sPPACompiled,"A2"))
			bPPACompiled = 1;
		else
			bPPACompiled = 0;
	}
	if (bACLEnable || bFWEnable || bFWServiceEnable || bNAPTServiceEnable || bNAPTEnable || bPPACompiled)
	{
		system("echo '1' > /proc/sys/net/ipv4/netfilter_input_enable");
		system("echo '1' > /proc/sys/net/ipv4/netfilter_output_enable");
		system("echo '1' > /proc/sys/net/ipv4/netfilter_forward_enable");
		system("echo '1' > /proc/sys/net/ipv4/netfilter_prerouting_enable");
		system("echo '1' > /proc/sys/net/ipv4/netfilter_postrouting_enable");
		//Nirav - Enable iptables for bridged traffic
#if defined(CONFIG_FEATURE_QOS) && defined(CONFIG_FEATURE_QOS_8021P)
		system("echo '1' > /proc/sys/net/ipv4/netfilter_bridged_enable");
		system("echo '1' > /proc/sys/net/bridge/bridge-nf-local-in-enable");
		system("echo '1' > /proc/sys/net/bridge/bridge-nf-local-out-enable");
		if (bNAPTEnable)
		{
			system("echo '1' > /proc/sys/net/bridge/bridge-nf-pre-routing-enable");
			system("echo '1' > /proc/sys/net/bridge/bridge-nf-post-routing-enable");
			system("echo '1' > /proc/sys/net/bridge/bridge-nf-forward-enable");
		}
#endif
#if defined(CONFIG_FEATURE_IFX_TURBONAT)
		system("insmod turbo_nat");
#endif
	}else
	{
		system("echo '0' > /proc/sys/net/ipv4/netfilter_input_enable");
		system("echo '0' > /proc/sys/net/ipv4/netfilter_output_enable");
		system("echo '0' > /proc/sys/net/ipv4/netfilter_forward_enable");
		system("echo '0' > /proc/sys/net/ipv4/netfilter_prerouting_enable");
		system("echo '0' > /proc/sys/net/ipv4/netfilter_postrouting_enable");
#if defined(CONFIG_FEATURE_QOS) && defined(CONFIG_FEATURE_QOS_8021P)
		//Nirav - Disable iptables for bridged traffic
		system("echo '0' > /proc/sys/net/ipv4/netfilter_bridged_enable");
		system("echo '0' > /proc/sys/net/bridge/bridge-nf-pre-routing-enable");
		system("echo '0' > /proc/sys/net/bridge/bridge-nf-local-in-enable");
		system("echo '0' > /proc/sys/net/bridge/bridge-nf-forward-enable");
		system("echo '0' > /proc/sys/net/bridge/bridge-nf-local-out-enable");
		system("echo '0' > /proc/sys/net/bridge/bridge-nf-post-routing-enable");
#endif
#if defined(CONFIG_FEATURE_IFX_TURBONAT)
		system("rmmod turbo_nat");
#endif
	}
	return 0;
}
/* 507141:tc.chen end*/

#ifdef ORGCODE
void DMZ_INIT()
{
	char sValue[64];
	bool bEnable=0;
	char sWANIF[64];

	IFX_SET_NAPT_DMZ(DELETE_ALL,0);
	if (ifx_GetCfgData("/etc/rc.conf","firewall_dmz","DMZ_HOST",sValue)==1) {
			IFX_SET_NAPT_DMZ(ADD,inet_addr(sValue));
		}

}

#else

void DMZ_INIT()
{
	char sValue[64];
	bool bEnable;
	int outFlag = IFX_F_DEFAULT;

	IFX_SET_NAPT_DMZ(DELETE_ALL,0);

	if (ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_DMZ,
	                   TAG_FIREWALL_DMZ "_enable",
	                   IFX_F_GET_ENA, &outFlag, sValue) != IFX_SUCCESS) {
			IFX_DBG("In function [%s]: Failed to get initialize Firewall DMZ Chain !!\n", __FUNCTION__);
			return;
		}

	if ((atoi(sValue))==1) {

			bEnable = 1;
			IFX_SET_NAPT_DMZ_ENABLE(SET,&bEnable);
					
			if (ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_DMZ,
			                   TAG_FIREWALL_DMZ "_ipAddr",
			                   IFX_F_GET_ENA, &outFlag, sValue) != IFX_SUCCESS) {
					IFX_DBG("In function [%s]: Failed to get initialize Firewall DMZ Chain !!\n", __FUNCTION__);
					return;
				}

			IFX_SET_NAPT_DMZ(ADD,inet_addr(sValue));

	} else {
		bEnable = 0;       
		IFX_SET_NAPT_DMZ_ENABLE(SET,&bEnable);
	}
	

}

#endif
//510251: sumedh start (Policy based Routing)
void POLICYROUTING_INIT(int status)
{

		int entry_size = 0;
		IFX_IPT_RULE query_rule;
		char sValue[64];
		char sItem[64];
		int cf_num=0,i;
		char sIP_SRC_IP[64],sIP_SRC_MASK[64];
		char sPort_SRC[64] = {0};
		char sIP_DST_IP[64],sIP_DST_MASK[64],sPort_DST[64];
		char sDiffServ[64], sOpIf[64];
		char sProto[64];

		//printf("\n\n=== INIT POLICY RTNG ===\n");
		IFXSetPolicyRouteEntry(DELETE_ALL,NULL,NULL);

		ifx_GetCfgData(FILE_RC_CONF,TAG_POLICY_ROUTING,"PR_Count",sValue);

		//printf("\nPR_Count = %s\n",sValue);

		cf_num = atoi(sValue);
		if(status==1 && (cf_num >=0) && (cf_num < 32767 ))
		{
				for (i=0;i<cf_num;i++)
				{
						sprintf(sItem,"PR_R%d",i);
						ifx_GetCfgData(FILE_RC_CONF,TAG_POLICY_ROUTING,sItem,sValue);
						if (atoi(sValue)==1)
						{
								sprintf(sItem,"PR_SRC_IP%d",i);
								ifx_GetCfgData(FILE_RC_CONF,TAG_POLICY_ROUTING,sItem,sIP_SRC_IP);
								sprintf(sItem,"PR_IP_SRC_MASK%d",i);
								ifx_GetCfgData(FILE_RC_CONF,TAG_POLICY_ROUTING,sItem,sIP_SRC_MASK);
								sprintf(sItem,"PR_SRC_PORT%d",i);
								sprintf(sItem,"PR_DST_IP%d",i);
								ifx_GetCfgData(FILE_RC_CONF,TAG_POLICY_ROUTING,sItem,sIP_DST_IP);
								sprintf(sItem,"PR_IP_DST_MASK%d",i);
								ifx_GetCfgData(FILE_RC_CONF,TAG_POLICY_ROUTING,sItem,sIP_DST_MASK);
								sprintf(sItem,"PR_DST_PORT%d",i);
								ifx_GetCfgData(FILE_RC_CONF,TAG_POLICY_ROUTING,sItem,sPort_DST);
								sprintf(sItem,"PR_PROTOCOL%d",i);
								ifx_GetCfgData(FILE_RC_CONF,TAG_POLICY_ROUTING,sItem,sProto);
								sprintf(sItem,"PR_DIFFSERV%d",i);
								ifx_GetCfgData(FILE_RC_CONF,TAG_POLICY_ROUTING,sItem,sDiffServ);
								sprintf(sItem,"PR_OP_IF%d",i);
								ifx_GetCfgData(FILE_RC_CONF,TAG_POLICY_ROUTING,sItem,sOpIf);
								memset(&query_rule,0,sizeof(query_rule));
								query_rule.protocol=atoi(sProto);

								if (sIP_SRC_IP[0]!='*')
								{
										query_rule.srcip=inet_addr(sIP_SRC_IP);
										query_rule.srcip_mask=atoi(sIP_SRC_MASK);
										if (query_rule.srcip_mask>31)
										{
												query_rule.srcip_mask=0;
										}
								}
								if (sPort_SRC[0]!='*')
								{
										query_rule.srcport_start=htons(atoi(sPort_SRC));
								}
								if (sIP_DST_IP[0]!='*')
								{
										query_rule.dstip=inet_addr(sIP_DST_IP);
										query_rule.dstip_mask=atoi(sIP_DST_MASK);
										if ( query_rule.dstip_mask>31)
												query_rule.dstip_mask=0;
								}
								if (sPort_DST[0]!='*')
								{
										query_rule.dstport_start=htons(atoi(sPort_DST));
								}
								if( sDiffServ[0]!='*')	
										strcpy(query_rule.diffserv,sDiffServ);

								if( sOpIf[0]!='*')
										strcpy(query_rule.route_oif, sOpIf);
								query_rule.route_continue = 1;

								entry_size = 1;
								IFXSetPolicyRouteEntry(ADD,&query_rule,&entry_size); 
						}
				}
		}	
}
//510251: sumedh end (Policy based Routing)
#ifdef ORGCODE
void PACKETFILTER_INIT()
{

    bool bEnable=0;
    int entry_size = 0;
    IFX_IPT_RULE query_rule;
    char sValue[64];
    char sItem[64];
    int cf_num=0,i;
		char sIP_SRC_IP[64],sIP_SRC_MASK[64],sPort_SRC_S[64],sPort_SRC_E[64], sInInterface[64];
		char sIP_DST_IP[64],sIP_DST_MASK[64],sPort_DST_S[64],sPort_DST_E[64], sOutInterface[64];
    char sProto[64],sIP_tmp[64];
   
    IFXSetFirewallPacketFilterEntry(DELETE_ALL,NULL,NULL);

    ifx_GetCfgData("/etc/rc.conf","firewall_packetfilter","PF_Count",sValue);
    
    cf_num = atoi(sValue);
    for (i=0;i<cf_num;i++)
    {
        sprintf(sItem,"PF_F%d",i);
        ifx_GetCfgData("/etc/rc.conf","firewall_packetfilter",sItem,sValue);
        if (atoi(sValue)==1)
        {
            sprintf(sItem,"PF_IP_SRC_IP%d",i);
            ifx_GetCfgData("/etc/rc.conf","firewall_packetfilter",sItem,sIP_SRC_IP);
            sprintf(sItem,"PF_IP_SRC_MASK%d",i);
            ifx_GetCfgData("/etc/rc.conf","firewall_packetfilter",sItem,sIP_SRC_MASK);
            sprintf(sItem,"PF_PORT_SRC_START%d",i);
            ifx_GetCfgData("/etc/rc.conf","firewall_packetfilter",sItem,sPort_SRC_S);
            sprintf(sItem,"PF_PORT_SRC_END%d",i);
            ifx_GetCfgData("/etc/rc.conf","firewall_packetfilter",sItem,sPort_SRC_E);
            sprintf(sItem,"PF_IP_DST_IP%d",i);
            ifx_GetCfgData("/etc/rc.conf","firewall_packetfilter",sItem,sIP_DST_IP);
            sprintf(sItem,"PF_IP_DST_MASK%d",i);
            ifx_GetCfgData("/etc/rc.conf","firewall_packetfilter",sItem,sIP_DST_MASK);
            sprintf(sItem,"PF_PORT_DST_START%d",i);
            ifx_GetCfgData("/etc/rc.conf","firewall_packetfilter",sItem,sPort_DST_S);
            sprintf(sItem,"PF_PORT_DST_END%d",i);
            ifx_GetCfgData("/etc/rc.conf","firewall_packetfilter",sItem,sPort_DST_E);
            sprintf(sItem,"PF_TYPE%d",i);
            ifx_GetCfgData("/etc/rc.conf","firewall_packetfilter",sItem,sProto);
						//Sumedh: support for interface based packet filtering
						sprintf(sItem,"PF_IN_IF%d",i);
						ifx_GetCfgData("/etc/rc.conf","firewall_packetfilter",sItem,sInInterface);
						if(strcmp(sInInterface,"*")==0)
							strcpy(sInInterface,""); //in case no interface was specified from web, * is stored in its place, but rule should have "any" as interface, which will happen if interface is null
						sprintf(sItem,"PF_OUT_IF%d",i);
						ifx_GetCfgData("/etc/rc.conf","firewall_packetfilter",sItem,sOutInterface);
						if(strcmp(sOutInterface,"*")==0)
							strcpy(sOutInterface,"");
						//Sumedh
            memset(&query_rule,0,sizeof(query_rule));
            query_rule.protocol=atoi(sProto);
                
	    if (sIP_SRC_IP[0]!='*')
	    {
                query_rule.srcip=inet_addr(sIP_SRC_IP);
		query_rule.srcip_mask=atoi(sIP_SRC_MASK);
		if (query_rule.srcip_mask>31)
		{
		    query_rule.srcip_mask=0;
		}
	    }
	    if (sPort_SRC_S[0]!='*')
	    {
            	query_rule.srcport_start=htons(atoi(sPort_SRC_S));
	    	if (strcmp(sPort_SRC_S,sPort_SRC_E)!=0)
	    	{
            		query_rule.srcport_end=htons(atoi(sPort_SRC_E));
	    	}
	    }
	    if (sIP_DST_IP[0]!='*')
	    {
            	query_rule.dstip=inet_addr(sIP_DST_IP);
		query_rule.dstip_mask=atoi(sIP_DST_MASK);
		if ( query_rule.dstip_mask>31)
		    query_rule.dstip_mask=0;
	    }
	    if (sPort_DST_S[0]!='*')
	    {
            	query_rule.dstport_start=htons(atoi(sPort_DST_S));
	    	if (strcmp(sPort_DST_S,sPort_DST_E)!=0)
	    	{
            		query_rule.dstport_end=htons(atoi(sPort_DST_E));
	    	}
	    }
						strcpy(query_rule.inif, sInInterface);
						strcpy(query_rule.outif, sOutInterface);

            entry_size = 1;
            IFXSetFirewallPacketFilterEntry(ADD,&query_rule,&entry_size);
            
				}
		}

}

#else

void PACKETFILTER_INIT()
{

	int entry_size = 0;
	IFX_IPT_RULE query_rule;
	char sValue[64];
	char sItem[64];
	int cf_num=0,i, j, k;
	char sIP_SRC_IP[64],sIP_SRC_MASK[64],sPort_SRC_S[64],sPort_SRC_E[64], sInInterface[64];
	char sIP_DST_IP[64],sIP_DST_MASK[64],sPort_DST_S[64],sPort_DST_E[64], sOutInterface[64];
	char sMAC_ADR[64];
	char sProto[64];
	char * temp = NULL, *tmp;
	int outFlag = IFX_F_DEFAULT;
	bool bEna = 0;
	unsigned char *tok_val = NULL;
	memset(sValue, 0x00, sizeof(sValue));
	memset(sIP_SRC_IP, 0x00, sizeof(sIP_SRC_IP));
	memset(sIP_SRC_MASK, 0x00, sizeof(sIP_SRC_MASK));
	memset(sPort_SRC_S, 0x00, sizeof(sPort_SRC_S));
	memset(sPort_SRC_E, 0x00, sizeof(sPort_SRC_E));
	memset(sInInterface, 0x00, sizeof(sInInterface));
	memset(sIP_DST_IP, 0x00, sizeof(sIP_DST_IP));
	memset(sIP_DST_MASK, 0x00, sizeof(sIP_DST_MASK));
	memset(sPort_DST_E, 0x00, sizeof(sPort_DST_E));
	memset(sPort_DST_S, 0x00, sizeof(sPort_DST_S));
	memset(sOutInterface, 0x00, sizeof(sOutInterface));
	memset(sProto, 0x00, sizeof(sProto));
	memset(sMAC_ADR, 0x00, sizeof(sMAC_ADR));

	IFXSetFirewallPacketFilterEntry(DELETE_ALL,NULL,NULL);
	
	if (ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER_STATUS, TAG_FIREWALL_PACKETFILTER_STATUS "_enable",
                           IFX_F_GET_ENA, &outFlag, sValue) != IFX_SUCCESS) {
               IFX_DBG("In function [%s]: Failed to get initialize Firewall Packet Filter Chain !!\n", __FUNCTION__);
               return;
        }

	bEna=(bool)atoi(sValue);
	if(bEna==1)
		 IFXSetFirewallPacketFilterEnable(SET,&bEna);
	
	memset(sValue, 0x00, sizeof(sValue));	
	if (ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER,
	                   TAG_FIREWALL_PACKETFILTER "_Count",
	                   IFX_F_GET_ENA, &outFlag, sValue) != IFX_SUCCESS) {
			IFX_DBG("In function [%s]: Failed to get initialize Firewall Packet Filter Chain !!\n", __FUNCTION__);
			return;
		}

	cf_num = atoi(sValue);

	for (i=0;i<cf_num;i++) {
			// reading the status of each rule

			memset(sValue, 0x00, sizeof(sValue));
			sprintf(sItem,"%s_%d_enable",TAG_FIREWALL_PACKETFILTER, i);
			if (ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER,
			                   sItem, IFX_F_GET_ENA, &outFlag, sValue) != IFX_SUCCESS) {
					IFX_DBG("In function [%s]: Failed to get initialize Firewall Packet Filter Chain !!\n", __FUNCTION__);
					return;
				}
			// status = enable
			if (atoi(sValue)==1) {

					sprintf(sItem,"%s_%d_protoType",TAG_FIREWALL_PACKETFILTER, i);
					if (ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER,
					                   sItem, IFX_F_GET_ENA, &outFlag, sProto) != IFX_SUCCESS) {
							IFX_DBG("In function [%s]: Failed to get initialize Firewall Packet Filter Chain !!\n", __FUNCTION__);
							return;
						}

					sprintf(sItem,"%s_%d_srcIp",TAG_FIREWALL_PACKETFILTER, i);
					if (ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER,
					                   sItem, IFX_F_GET_ENA, &outFlag, sIP_SRC_IP) != IFX_SUCCESS) {
							IFX_DBG("In function [%s]: Failed to get initialize Firewall Packet Filter Chain !!\n", __FUNCTION__);
							return;
						}

					sprintf(sItem,"%s_%d_srcMask",TAG_FIREWALL_PACKETFILTER, i);
					if (ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER,
					                   sItem, IFX_F_GET_ENA, &outFlag, sIP_SRC_MASK) != IFX_SUCCESS) {
							IFX_DBG("In function [%s]: Failed to get initialize Firewall Packet Filter Chain !!\n", __FUNCTION__);
							return;
						}

					memset(sValue, 0x00, sizeof(sValue));
					sprintf(sItem,"%s_%d_sPortRange",TAG_FIREWALL_PACKETFILTER, i);
					if (ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER,
					                   sItem, IFX_F_GET_ENA, &outFlag, sValue) != IFX_SUCCESS) {
							IFX_DBG("In function [%s]: Failed to get initialize Firewall Packet Filter Chain !!\n", __FUNCTION__);
							return;
						}

					if (strlen(sValue)) {
							temp = strchr(sValue,':');
							if (temp!=NULL) {
									strcpy(sPort_SRC_E,temp+1);
									*temp = '\0';
								}
							strcpy(sPort_SRC_S,sValue);
							temp=NULL;
						}

					sprintf(sItem,"%s_%d_iif",TAG_FIREWALL_PACKETFILTER, i);
					if (ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER,
					                   sItem, IFX_F_GET_ENA, &outFlag, sInInterface) != IFX_SUCCESS) {
							IFX_DBG("In function [%s]: Failed to get initialize Firewall Packet Filter Chain !!\n", __FUNCTION__);
							return;
						}

					sprintf(sItem,"%s_%d_dstIp",TAG_FIREWALL_PACKETFILTER, i);
					if (ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER,
					                   sItem, IFX_F_GET_ENA, &outFlag, sIP_DST_IP) != IFX_SUCCESS) {
							IFX_DBG("In function [%s]: Failed to get initialize Firewall Packet Filter Chain !!\n", __FUNCTION__);
							return;
						}

					sprintf(sItem,"%s_%d_dstMask",TAG_FIREWALL_PACKETFILTER, i);
					if (ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER,
					                   sItem, IFX_F_GET_ENA, &outFlag, sIP_DST_MASK) != IFX_SUCCESS) {
							IFX_DBG("In function [%s]: Failed to get initialize Firewall Packet Filter Chain !!\n", __FUNCTION__);
							return;
						}

					memset(sValue, 0x00, sizeof(sValue));
					sprintf(sItem,"%s_%d_dPortRange",TAG_FIREWALL_PACKETFILTER, i);
					if (ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER,
					                   sItem, IFX_F_GET_ENA, &outFlag, sValue) != IFX_SUCCESS) {
							IFX_DBG("In function [%s]: Failed to get initialize Firewall Packet Filter Chain !!\n", __FUNCTION__);
							return;
						}

					if (strlen(sValue)) {
							temp = strchr(sValue,':');
							if (temp!=NULL) {
									strcpy(sPort_DST_E,temp+1);
									*temp = '\0';
								}
							strcpy(sPort_DST_S,sValue);
							temp=NULL;
						}


					sprintf(sItem,"%s_%d_oif",TAG_FIREWALL_PACKETFILTER, i);
					if (ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER,
					                   sItem, IFX_F_GET_ENA, &outFlag, sOutInterface) != IFX_SUCCESS) {
							IFX_DBG("In function [%s]: Failed to get initialize Firewall Packet Filter Chain !!\n", __FUNCTION__);
							return;
						}

					sprintf(sItem,"%s_%d_sMacAddr",TAG_FIREWALL_PACKETFILTER, i);
					if (ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER,
					                   sItem, IFX_F_GET_ENA, &outFlag, sMAC_ADR) != IFX_SUCCESS) {
							IFX_DBG("In function [%s]: Failed to get initialize Firewall Packet Filter Chain !!\n", __FUNCTION__);
							return;
						}

					memset(&query_rule,0,sizeof(query_rule));
					query_rule.protocol=atoi(sProto);

					if (strlen(sIP_SRC_IP)!=0) {
							query_rule.srcip = inet_addr(sIP_SRC_IP);
							query_rule.srcip_mask = netmask2bits(inet_addr(sIP_SRC_MASK));
							if (query_rule.srcip_mask>31) {
									query_rule.srcip_mask=0;
								}
						}

					if (strlen(sPort_SRC_S)!=0) {
							query_rule.srcport_start=htons(atoi(sPort_SRC_S));
							if (strcmp(sPort_SRC_S,sPort_SRC_E)!=0) {
									query_rule.srcport_end=htons(atoi(sPort_SRC_E));
								}
						}
					if (strlen(sIP_DST_IP)!=0) {
							query_rule.dstip=inet_addr(sIP_DST_IP);
							query_rule.dstip_mask=netmask2bits(inet_addr(sIP_DST_MASK));
							if ( query_rule.dstip_mask>31)
								query_rule.dstip_mask=0;
						}
					if (strlen(sPort_DST_S)!=0) {
							query_rule.dstport_start=htons(atoi(sPort_DST_S));
							if (strcmp(sPort_DST_S,sPort_DST_E)!=0) {
									query_rule.dstport_end=htons(atoi(sPort_DST_E));
								}
						}

					strcpy(query_rule.inif, sInInterface);
					strcpy(query_rule.outif, sOutInterface);
//					strcpy(query_rule.MAC, sMAC_ADR);
					if(strlen(sMAC_ADR)>0) {	
						tmp=sMAC_ADR;
						for(j=0,k=0;k<strlen(sMAC_ADR) && j<ETH_ALEN;k++) {
							if(sMAC_ADR[k]==':' || sMAC_ADR[k]=='\0') {
								tok_val = strtok(tmp,":");
								if(tok_val != NULL)
								{
									query_rule.MAC[j]=(unsigned char)strtol(tok_val,NULL,16);
									tmp=NULL;						
									j++;
								}
							}
						}
					}

					entry_size = 1;
					IFXSetFirewallPacketFilterEntry(ADD,&query_rule,&entry_size);

				}
		}

}


#endif
//604041:Sumedh Parental Control (Modified MAC Filter) --Added extra fields that need to be processed here
void MACFILTER_INIT()
{

    int entry_size = 0;
    IFX_IPT_RULE query_rule;
    char sItem[64];
    int mac_num=0,i;
    char sValue[64];
	int nPolicy=0;
    
    IFXSetFirewallMacFilterDropEntry(DELETE_ALL,NULL,NULL);
    IFXSetFirewallMacFilterPermitEntry(DELETE_ALL,NULL,NULL);
		ifx_GetCfgData(FILE_RC_CONF,TAG_FIREWALLMAC,"PC_Count",sValue);
    
    mac_num = atoi(sValue);
	printf("\n MACFILTER_INIT : mac_num=%d\n",mac_num);
	if((mac_num >=0) && (mac_num < 32767))
	{
		for (i=0;i<mac_num;i++)
		{
			sprintf(sItem,"PC_STATUS%d",i);
			ifx_GetCfgData(FILE_RC_CONF,TAG_FIREWALLMAC,sItem,sValue);
			nPolicy=atoi(sValue);
			if (nPolicy)
			{
				memset(&query_rule,0,sizeof(query_rule));
				query_rule.protocol=PROTO_ALL;

				sprintf(sItem,"PC_MACADDR%d",i);
				ifx_GetCfgData(FILE_RC_CONF,TAG_FIREWALLMAC,sItem,sValue);
				mac_strtoint(sValue,query_rule.MAC);

				sprintf(sItem,"PC_DAYSELECTION%d",i);
				ifx_GetCfgData(FILE_RC_CONF,TAG_FIREWALLMAC,sItem,sValue);
				strcpy(query_rule.DAY,sValue);

				sprintf(sItem,"PC_TIMESTART%d",i);
				ifx_GetCfgData(FILE_RC_CONF,TAG_FIREWALLMAC,sItem,sValue);
				strcpy(query_rule.TIMESTART,sValue);

				sprintf(sItem,"PC_TIMEEND%d",i);
				ifx_GetCfgData(FILE_RC_CONF,TAG_FIREWALLMAC,sItem,sValue);
				strcpy(query_rule.TIMEEND,sValue);

				printf("\nQUERY RULE = %s : %s : %s : %s", query_rule.MAC, query_rule.DAY, query_rule.TIMESTART, query_rule.TIMEEND);

				entry_size = 1;
				if (nPolicy==MAC_DROP)
				{
					printf("\t POLICY : DROP\n");
					IFXSetFirewallMacFilterDropEntry(ADD,&query_rule,&entry_size);
				}
				else if (nPolicy==MAC_PERMIT)
				{
					printf("\t POLICY : PERMIT\n");
					IFXSetFirewallMacFilterPermitEntry(ADD,&query_rule,&entry_size);
				}
			}
		}
	}

}
// Sumedh Parental Control (Modified MAC Filter) ends

#ifdef ORGCODE
void VS_INIT()
{
    int entry_size = 0;
    char sItem[64];
    int vs_num=0,i;
    char sValue[64];
    IFX_IPT_RULE query_rule;
    char sTargetIP[64],sTargetPort[64],sProto[64],sWanPort[64];

    IFX_SET_NAPT_DNAT_VIRTUALSERVER_Entry(DELETE_ALL,NULL,0);
    ifx_GetCfgData("/etc/rc.conf","nat_virtualser","NATVS_NUM",sValue);
    
    vs_num = atoi(sValue);

    for (i=1;i<=vs_num;i++)
    {
        sprintf(sItem,"NATVS_F%d",i);
        ifx_GetCfgData("/etc/rc.conf","nat_virtualser",sItem,sValue);
        if (atoi(sValue)==1)
        {
            sprintf(sItem,"NATVS_PIP%d",i);
            ifx_GetCfgData("/etc/rc.conf","nat_virtualser",sItem,sTargetIP);
            sprintf(sItem,"NATVS_PPORT%d",i);
            ifx_GetCfgData("/etc/rc.conf","nat_virtualser",sItem,sTargetPort);
            
            sprintf(sItem,"NATVS_PTYPE%d",i);
            ifx_GetCfgData("/etc/rc.conf","nat_virtualser",sItem,sProto);
            
            sprintf(sItem,"NATVS_PUPORT%d",i);
            ifx_GetCfgData("/etc/rc.conf","nat_virtualser",sItem,sWanPort);
            
            memset(&query_rule,0,sizeof(query_rule));
            if (!strcmp(sProto,"TCP"))
                query_rule.protocol=PROTO_TCP;
            else if (!strcmp(sProto,"UDP"))
                query_rule.protocol=PROTO_UDP;
            else
                query_rule.protocol=PROTO_ALL;
                
            query_rule.dstport_start=htons(atoi(sWanPort));
            query_rule.targetip=inet_addr(sTargetIP);
            query_rule.targetport_start=htons(atoi(sTargetPort));    
            
            entry_size = 1;        
            IFX_SET_NAPT_DNAT_VIRTUALSERVER_Entry(ADD,&query_rule,entry_size);
        }
    }
}
#else
//vipul start
void VS_INIT()
{
	int entry_size = 0;
	char sItem[300];
	int vs_num=0, i=0;
	IFX_IPT_RULE query_rule;
	char sWanPort[64],eWanPort[64];
	int outFlag = IFX_F_DEFAULT;
	int f_enable=0;
	char sValue[32], sLanIP[24], sWanHostIP[24], sConnName[260], sLanPort[16],eLanPort[16],
		 sProto[16],ifName[15],enable[20];

	memset(sValue, 0x00, sizeof(sValue));
	memset(sItem, 0x00, sizeof(sItem));
	memset(sLanIP, 0x00, sizeof(sLanIP));
	memset(sWanHostIP, 0x00, sizeof(sWanHostIP));
	memset(sLanPort, 0x00, sizeof(sLanPort));
	memset(eLanPort, 0x00, sizeof(eLanPort));
	memset(sProto, 0x00, sizeof(sProto));
	memset(sWanPort, 0x00, sizeof(sWanPort));
       memset(eWanPort, 0x00, sizeof(eWanPort));
	memset(sConnName, 0x00, sizeof(sConnName));
	 memset(enable, 0x00, sizeof(enable));
	memset(&query_rule, 0x00, sizeof(query_rule));

	/* First flush all the previously configured Virtual Server Rules */
	// NOT Needed: As when the board comes up everything is flushed out!
	IFX_SET_NAPT_DNAT_VIRTUALSERVER_Entry(DELETE_ALL,NULL,0);

	if (ifx_GetObjData(FILE_RC_CONF, TAG_NAT_VIRTUALSER, "nat_virtualser_Count",
			IFX_F_GET_ENA, &outFlag, sValue) != IFX_SUCCESS) {
		IFX_DBG("In function [%s]: Failed to get initialize Virtual Server NAT Chain !!\n", __FUNCTION__);
		return;
	}

	vs_num = atoi(sValue);
	/* Start Adding each of the rules */
	for (i=0; i<vs_num; i++)	{
		sprintf(sItem,"%s_%d_privateIp",TAG_NAT_VIRTUALSER,i);
		if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, sItem,
								IFX_F_GET_ANY, &outFlag, sLanIP) != IFX_SUCCESS) {
			IFX_DBG("In function [%s]: Failed to get Virtual Server Info: [%s]!!\n", __FUNCTION__, sItem);
			return;
		}
		query_rule.targetip=inet_addr(sLanIP);

		memset(sItem, 0x00, sizeof(sItem));
		sprintf(sItem,"%s_%d_remoteIp",TAG_NAT_VIRTUALSER,i);
		if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, sItem,
								IFX_F_GET_ANY, &outFlag, sWanHostIP) != IFX_SUCCESS) {
			IFX_DBG("In function [%s]: Failed to get Virtual Server Info: [%s]!!\n", __FUNCTION__, sItem);
		}
		else {
			if (!strncmp(sWanHostIP, "*", 1))
				query_rule.srcip=0;
			else
				query_rule.srcip=inet_addr(sWanHostIP);
		}

		memset(sItem, 0x00, sizeof(sItem));
		sprintf(sItem,"%s_%d_spport",TAG_NAT_VIRTUALSER,i);
		if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, sItem,
								IFX_F_GET_ANY, &outFlag, sLanPort) != IFX_SUCCESS) {
			IFX_DBG("In function [%s]: Failed to get Virtual Server Info: [%s]!!\n", __FUNCTION__, sItem);
			return;
		}
		query_rule.targetport_start=htons(atoi(sLanPort));


		 memset(sItem, 0x00, sizeof(sItem));
                sprintf(sItem,"%s_%d_epport",TAG_NAT_VIRTUALSER,i);
                if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, sItem,
                                                                IFX_F_GET_ANY, &outFlag, eLanPort) != IFX_SUCCESS) {
                        IFX_DBG("In function [%s]: Failed to get Virtual Server Info: [%s]!!\n", __FUNCTION__, sItem);
                        return;
                }
                query_rule.targetport_end=htons(atoi(eLanPort));






		memset(sItem, 0x00, sizeof(sItem));
		sprintf(sItem,"%s_%d_ptype",TAG_NAT_VIRTUALSER,i);
		if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, sItem,
								IFX_F_GET_ANY, &outFlag, sProto) != IFX_SUCCESS) {
			IFX_DBG("In function [%s]: Failed to get Virtual Server Info: [%s]!!\n", __FUNCTION__, sItem);
			return;
		}
		if (atoi(sProto) == NAT_VS_PROTOCOL_TCP)
		{
			query_rule.protocol=PROTO_TCP;
		}
		else if (atoi(sProto) == NAT_VS_PROTOCOL_UDP)
		{
			query_rule.protocol=PROTO_UDP;
		}
		else if (atoi(sProto) == NAT_VS_PROTOCOL_TCP_UDP)
		{
			query_rule.protocol = PROTO_TCP; //To be set UDP for 2nd rule later.
		}
		else
		{
			query_rule.protocol=PROTO_ALL;
		}	

		memset(sItem, 0x00, sizeof(sItem));
		sprintf(sItem,"%s_%d_spuport",TAG_NAT_VIRTUALSER,i);
		if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, sItem,
								IFX_F_GET_ANY, &outFlag, sWanPort) != IFX_SUCCESS) {
			IFX_DBG("In function [%s]: Failed to get Virtual Server Info: [%s]!!\n", __FUNCTION__, sItem);
			return;
		}
		query_rule.dstport_start=htons(atoi(sWanPort));


		 memset(sItem, 0x00, sizeof(sItem));
                sprintf(sItem,"%s_%d_epuport",TAG_NAT_VIRTUALSER,i);
                if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, sItem,
                                                                IFX_F_GET_ANY, &outFlag, eWanPort) != IFX_SUCCESS) {
                        IFX_DBG("In function [%s]: Failed to get Virtual Server Info: [%s]!!\n", __FUNCTION__, sItem);
                        return;
                }
                query_rule.dstport_end=htons(atoi(eWanPort));


		memset(sItem, 0x00, sizeof(sItem));
		sprintf(sItem,"%s_%d_wanConnIf",TAG_NAT_VIRTUALSER,i);
		if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, sItem,
								IFX_F_GET_ANY, &outFlag, sConnName) != IFX_SUCCESS) {
			IFX_DBG("In function [%s]: Failed to get Virtual Server Info: [%s]!!\n", __FUNCTION__, sItem);
			return;
		}
		
		memset(sItem, 0x00, sizeof(sItem));
                sprintf(sItem,"%s_%d_fEnable",TAG_NAT_VIRTUALSER,i);
                if (ifx_GetObjDataOpt(FILE_RC_CONF, TAG_NAT_VIRTUALSER, sItem,
                                                                IFX_F_GET_ANY, &outFlag, enable) != IFX_SUCCESS) {
                        IFX_DBG("In function [%s]: Failed to get Virtual Server Info: [%s]!!\n", __FUNCTION__, sItem);
                        return;
                }

		f_enable = atoi(enable);

		if(ifx_get_wan_ifname_from_connName(sConnName, ifName) != IFX_SUCCESS) {
			IFX_DBG("\nIn Function [%s] : Error--> Failed to get the interface name for wan Connection [%s] !!\n\n",
							__FUNCTION__, sConnName);
			return;
		}
		strncpy(query_rule.inif, ifName, strlen(ifName));
		query_rule.inif[strlen(ifName)] = '\0';

		entry_size = 1;        
		if(f_enable==1){
			IFX_SET_NAPT_DNAT_VIRTUALSERVER_Entry(ADD,&query_rule,entry_size);

			if (atoi(sProto) == NAT_VS_PROTOCOL_TCP_UDP) {
				query_rule.protocol = PROTO_UDP; //To be set for UDP.

				if (IFX_SET_NAPT_DNAT_VIRTUALSERVER_Entry(ADD,&query_rule,entry_size) != IFX_SUCCESS){
#ifdef IFX_LOG_DEBUG
					IFX_DBG("[%s:%d]", __FUNCTION__, __LINE__);
#endif

				}
			}
		}

		else 
			continue;	
	}
}
//vipul end
#endif


void PM_INIT()
{
    int entry_size = 0;
    char sItem[64];
    int vs_num=0,i,j;
    int sTP_num=0;
    char sValue[64];
    IFX_IPT_RULE query_rule[2];
    char sTargetIP[64],sTargetPort_NUM[64],sTargetPorts[64];
    char *pTargetPortS,*pTargetPortE;
    char delim[]=": \n";

    IFX_SET_NAPT_DNAT_PORTMAPPING_Entry(DELETE_ALL,NULL,NULL);

    ifx_GetCfgData("/etc/rc.conf","nat_portmap","CLONE_NUM",sValue);
    
    vs_num = atoi(sValue);
    if((vs_num >=0) && (vs_num < 32767))
    {
	    for (i=1;i<=vs_num;i++)
	    {
		    sprintf(sItem,"CLONE_ENABLE%d",i);
		    ifx_GetCfgData("/etc/rc.conf","nat_portmap",sItem,sValue);
		    if (atoi(sValue)==1)
		    {
			    sprintf(sItem,"CLONE_IP%d",i);
			    ifx_GetCfgData("/etc/rc.conf","nat_portmap",sItem,sTargetIP);
			    sprintf(sItem,"CLONE_PORTS%d_NUM",i);
			    ifx_GetCfgData("/etc/rc.conf","nat_portmap",sItem,sTargetPort_NUM);

			    memset(&query_rule,0,sizeof(IFX_IPT_RULE)*2);
			    query_rule[0].targetip=inet_addr(sTargetIP);
			    sTP_num = atoi(sTargetPort_NUM);
			    if((sTP_num >=0) && (sTP_num < 32767))
			    {
				    for (j=1;j<=sTP_num;j++)
				    {
					    sprintf(sItem,"CLONE_PORTS%d_%d",i,j);                
					    ifx_GetCfgData("/etc/rc.conf","nat_portmap",sItem,sTargetPorts);
					    pTargetPortS=strtok(sTargetPorts,delim);
					    if(pTargetPortS == NULL)
					    {
						    return;
					    }
					    query_rule[0].dstport_start=htons(atoi(pTargetPortS));
					    query_rule[0].targetport_start=htons(atoi(pTargetPortS));


					    pTargetPortE=strtok(NULL,delim);
					    if (pTargetPortE && atoi(pTargetPortS)!=atoi(pTargetPortE))
					    {
						    query_rule[0].dstport_end=htons(atoi(pTargetPortE));
						    query_rule[0].targetport_end=query_rule[0].dstport_end;
					    }else
					    {
						    query_rule[0].dstport_end=0;
						    query_rule[0].targetport_end=query_rule[0].dstport_end;
					    }

					    query_rule[0].protocol=PROTO_TCP;      
					    memcpy(&query_rule[1],&query_rule[0],sizeof(IFX_IPT_RULE));
					    query_rule[1].protocol=PROTO_UDP;
					    entry_size = 2;                     
					    IFX_SET_NAPT_DNAT_PORTMAPPING_Entry(ADD,query_rule,&entry_size);                
				    }
			    }
		    }
	    }
    }


}

void INIT_ALL()
{
	IFX_FIREWALL_INIT();
	IFX_NAPT_INIT();	
	INIT_SERVICES();
	INIT_SERVICES_ACL();
	MACFILTER_INIT();
	PACKETFILTER_INIT();
	VS_INIT();
	PM_INIT();			
        DMZ_INIT();
}

__u32 GET_IF_IP_ADDRESS(char *ifname)
{
	char command[128],buffer[64];
	__u32 ip = 0;
	FILE *fp;

	sprintf(command,"ifconfig %s |grep \"inet addr\" |cut -f2 -d: | cut -f1 -d\" \"",ifname);
	fp = popen(command,"r");
	if(fp == NULL)
	{
		return;
	}
	fgets(buffer,sizeof(buffer),fp);
	ip = inet_addr(buffer);
	fclose(fp);

	return ip;
}

static void INIT_SERVICES()
{
	int i=0;
        char ifname[32];
	unsigned short pService_Info[]= {
#ifdef CONFIG_PACKAGE_IFX_HTTPD
	80,PROTO_TCP,
#endif
#ifdef CONFIG_FEATURE_TELNET_SERVER
	23,PROTO_TCP,
#endif
#ifdef CONFIG_FEATURE_SSH_SERVER
	22,PROTO_TCP,
#endif
#ifdef CONFIG_FEATURE_TFTP_SERVER
	69,PROTO_UDP,
#endif
#ifdef CONFIG_FEATURE_FTP_SERVER
	21,PROTO_TCP,
#endif
	};
	char	sParams[][32]={
#ifdef CONFIG_PACKAGE_IFX_HTTPD
	"WEB_WAN_ENABLE",   "WEB_WAN_PORT",   "WEB_LAN_ENABLE",
#endif //CONFIG_PACKAGE_IFX_HTTPD
#ifdef CONFIG_FEATURE_TELNET_SERVER
	"TELNET_WAN_ENABLE","TELNET_WAN_PORT","TELNET_LAN_ENABLE",
#endif //CONFIG_FEATURE_TELNET_SERVER
#ifdef CONFIG_FEATURE_SSH_SERVER
	"SSH_WAN_ENABLE",   "SSH_WAN_PORT",   "SSH_LAN_ENABLE",
#endif //CONFIG_FEATURE_SSH_SERVER
#ifdef CONFIG_FEATURE_TFTP_SERVER
	"TFTP_WAN_ENABLE",  "TFTP_WAN_PORT",  "TFTP_LAN_ENABLE",
#endif
#ifdef CONFIG_FEATURE_FTP_SERVER
	"FTP_WAN_ENABLE",   "FTP_WAN_PORT",   "FTP_LAN_ENABLE",
#endif //CONFIG_FEATURE_FTP_SERVER
	};
	char	sValue[3][64];
	__u32 IPADDR;
	
	Get_LAN_IF(ifname);
	IPADDR = GET_IF_IP_ADDRESS(ifname);

	IFX_SET_NAPT_REDIRECT_SERVICES(DELETE_ALL,0,0,0,0);
	IFX_SET_FIREWALL_DENY_SERVICES(DELETE_ALL,IF_LAN,0,0);
	IFX_SET_FIREWALL_DENY_SERVICES(DELETE_ALL,IF_WAN,0,0);
	IFX_SET_FIREWALL_ACCEPT_SERVICES(DELETE_ALL,0,0,0);
	IFX_SET_FIREWALL_ACCEPT_SERVICES(DELETE_ALL,0,0,1);

	for (i=0;i<sizeof(sParams)/32;i++)
	{
		memset(sValue[i%3],0,64);
    		ifx_GetCfgData("/etc/rc.conf","application_server",sParams[i],sValue[i%3]);
		if (i%3==2)
		{
			if (!strcmp(sValue[0],"1"))
			{
				// redirect port if wan port is not same as default port
				if (pService_Info[(i/3)*2]!= atoi(sValue[1]))
				{
					IFX_SET_NAPT_REDIRECT_SERVICES(ADD,htons(atoi(sValue[1])),pService_Info[(i/3)*2+1],IPADDR,htons(pService_Info[(i/3)*2]));

				        IFX_SET_FIREWALL_DENY_SERVICES(ADD,IF_WAN,pService_Info[(i/3)*2],pService_Info[(i/3)*2+1]);
				        IFX_SET_FIREWALL_ACCEPT_SERVICES(ADD,htons(atoi(sValue[1])),pService_Info[(i/3)*2+1],1);
				}else
				{
				        IFX_SET_FIREWALL_ACCEPT_SERVICES(ADD,htons(pService_Info[(i/3)*2]),pService_Info[(i/3)*2+1],1);
				}
			}else
			{
				// drop packet 
				IFX_SET_FIREWALL_DENY_SERVICES(ADD,IF_WAN,pService_Info[(i/3)*2],pService_Info[(i/3)*2+1]);
			}
			if (!strcmp(sValue[2],"0"))
			{
				IFX_SET_FIREWALL_DENY_SERVICES(ADD,IF_LAN,pService_Info[(i/3)*2],pService_Info[(i/3)*2+1]);
			}else
			{
				IFX_SET_FIREWALL_ACCEPT_SERVICES(ADD,pService_Info[(i/3)*2],pService_Info[(i/3)*2+1],1);
			}
		}
	}

	// snmp 
    	ifx_GetCfgData("/etc/rc.conf","application_server","SNMP_WAN_ENABLE",sValue[0]);
	if (!strcmp(sValue[0],"1"))
	{
	        IFX_SET_FIREWALL_ACCEPT_SERVICES(ADD,htons(161),PROTO_UDP,1);
	}else
	{
		// drop packet 
		IFX_SET_FIREWALL_DENY_SERVICES(ADD,IF_WAN,htons(161),PROTO_UDP);
	}


	// rip
    	ifx_GetCfgData("/etc/rc.conf","route_dynamic","RDYN_STATUS",sValue[0]);
	if (!strcmp(sValue[0],"1"))
	{
	        IFX_SET_FIREWALL_ACCEPT_SERVICES(ADD,htons(520),PROTO_UDP,0);
	}else
	{
		// drop packet 
		IFX_SET_FIREWALL_DENY_SERVICES(ADD,IF_WAN,htons(520),PROTO_UDP);
	}

	update_netfilter_enable_flag(); //507141:tc.chen
}
static void INIT_SERVICES_ACL()
{
	int i=0;
	char	sCFG_NAME[32];
	char	sValue[32];
    	int entry_size = 0;
    	IFX_IPT_RULE query_rule;
	
	IFXSetFirewallServiceAclEntry(DELETE_ALL,NULL,NULL);
	for (i=0;i<16;i++)
	{
		sprintf(sCFG_NAME,"SERVERS_ACL%d",i);
    		if (ifx_GetCfgData("/etc/rc.conf","servers_acl",sCFG_NAME,sValue)==1)
		{
			if (strcmp(sValue,"0"))
			{
            			memset(&query_rule,0,sizeof(query_rule));
				query_rule.srcip=inet_addr(sValue);
				entry_size=1;
				IFXSetFirewallServiceAclEntry(ADD,&query_rule,&entry_size);	
			}
		}
	}
	// disable ACL 
	entry_size = 0;
	IFX_SET_FIREWALL_SERVICES_ACL_ENABLE(SET,(bool *)&entry_size);

	update_netfilter_enable_flag();//507141:tc.chen 
}

static void usage(char *programname)
{
	printf("Usage: %s [options]\n",programname);
	printf(" --NAPTinit\t\t\t Initial NAPT\n");
	printf(" --FWinit\t\t\t Initial Firewall\n");
	printf(" --MACFilterinit\t\t\t Initial MAC Filter\n");
	printf(" --PacketFilter\t\t\t\tInitial Packet Filter");
	printf(" --PMinit\t\t\t Initial Port Mapping\n");
	printf(" --DMZinit\t\t\t Initial DMZ\n");
	printf(" --VSinit\t\t\t Initial Virtual Server\n");
	printf(" --INITALL\t\t\t Initial All\n");
	printf(" --Servicesinit\t\t\t Initial Application Services \n");
	printf(" --ServicesACLinit\t\t\t Initial Application Services ACL\n");
	printf(" --ServicesACL {0,1}\t\t\t Initial Application Services ACL\n");
	printf(" --UpdateNetfilterFlag\t\tUpdate Netfilter Flag to enable/disable netfilter hook point\n"); //507141:tc.chen
	printf(" --FW {0,1}\t\t\t 0: Disable Firewall, 1: Enable Firewall\n");
	printf(" --NAPT {0,1}\t\t\t 0: Disable NAPT, 1: Enable NAPT\n");
#ifdef IFX_DOS_ENABLE
	printf(" --DOS_ENABLE {0,1}\t\t\t\t 0: Disable Dos, 1: Enable DoS\n");
	printf(" --PING_FORWARD {0,1}\t\t\t 0: Allow Ping Forward, 1: Block Ping Forward\n"); 
	printf(" --PING_GW {0,1}\t\t\t 0: Allow Ping the gateway, 1: Block Ping the gateway\n");
#endif
	printf(" --MACFilter {0,1}\t\t\t\t 0: Disable Mac Filter, 1: Enable Mac Filter\n");
	printf(" --PacketFilter {0,1}\t\t\t\t 0: Disable Packet Filter, 1: Enable Packet Filter\n");
	printf(" --DMZ {0,1}\t\t\t\t 0: Disable DMZ, 1: Enable DMZ\n");
	printf(" --VS {0,1}\t\t\t\t 0: Disable Virtual Server, 1: Enable Virtual Server\n");
	printf(" --PM {0,1}\t\t\t\t 0: Disable Port Mapping, 1: Enable Port Mapping\n");

	printf(" --ADDLAN interface_name\t\t\t\t\t add a lan interface to NAPT and firewall\n");
	printf(" --ADDWANIF interface_name\t\t\t\t\t add a wan interface to NAPT and firewall\n");
	printf(" --ADDWANIP interface_name\t\t\t\t\t add a wan ip to NAPT and firewall\n");
	printf(" --DELLAN interface_name\t\t\t\t\t del a lan interface to NAPT and firewall\n");
	printf(" --DELWANIF interface_name\t\t\t\t\t del a wan interface to NAPT and firewall\n");
	printf(" --DELWANIP interface_name\t\t\t\t\t del a wan ip to NAPT and firewall\n");
#ifdef IFX_DOS_ENABLE
		//510251: sumedh start	
		printf(" --Winnuke {0:<oldports>:<ports>,1:<oldports>:<ports>}\t\t\t\t\t Provide protection against winnuke DoS attack\n");
		printf(" --Tcpsynflood {0:<oldlimit>:<oldburst>:<limit>:<burst>,1:<oldlimit>:<oldburst>:<limit>:<burst>}\t\t\t\t\t Provide protection against TCP Synflood DoS attack\n");
		printf(" --Xmas {0,1}\t\t\t\t\t Provide protection against Xmas DoS attack\n");
		printf(" --Hijacking {0,1}\t\t\t\t\t Provide protection against TCP Hijacking DoS attack\n");
		printf(" --Hotsync {0:<oldports>:<ports>,1:<oldports>:<ports>}\t\t\t\t\t Provide protection against Hotsync Manager DoS attack\n");
		printf(" --Yahoo {0:<oldports>:<ports>,1:<oldports>:<ports>}\t\t\t\t\t Provide protection against Yahoo Messenger DoS attack\n");
		printf(" --Portscan {0:<old_low_port_weight>:<old_hi_port_weight>:<old_delay_threshold>:<old_weight_threshold>,1:<low_port_weight>:<hi_port_weight>:<delay_threshold>:<weight_threshold>}\t\t\t\t\t Provide protection against Port Scan DoS attack\n");
		printf(" --Mime {0:<oldports>:<ports>,1:<oldports>:<ports>}\t\t\t\t\t Provide protection against Malformed MIME DoS attack\n");
		printf(" --Codered2 {0:<old_web_ports>:<web_ports>,1:<old_web_ports>:<web_ports>}\t\t\t\t\t Provide protection against Code Red II DoS attack\n");
		printf(" --Codered {0:<old_web_ports>:<web_ports>,1:<old_web_ports>:<web_ports>}\t\t\t\t\t Provide protection against Code Red DoS attack\n");
		printf(" --FtpPR {0,1}\t\t\t\t\t Provide protection against FTP Port Restricted DoS attack\n");
		printf(" --Land {0,1}\t\t\t\t\t Provide protection against Land DoS attack\n");
		printf(" --Loopback {0:<old_loopback_ports>:<loopback_ports>,1:<old_loopback_ports>:<loopback_ports>}\t\t\t\t\t Provide protection against UDP Port Loopback DoS attack\n");
		printf(" --Fraggle {0:<old_loopback_ports>:<loopback_ports>:<old_fraggle_rate>:<fraggle_rate>,1:<old_loopback_ports>:<loopback_ports>:<old_fraggle_rate>:<fraggle_rate>}\t\t\t\t\t Provide protection against Fraggle DoS attack\n");
		printf(" --Bomb {0,1}\t\t\t\t\t Provide protection against UDP Bomb DoS attack\n");
		printf(" --Icq {0:<old_web_ports>:<web_ports>,1:<old_web_ports>:<web_ports>}\t\t\t\t\t Provide protection against ICQ DoS attack\n");
#endif
		printf(" --PolicyRoutingInit {0,1}\t\t\t\t\t Initialise Policy Based Routing\n");
		printf(" --APP_FILTER {0,1}\t\t\t\t\t Initialise Applicaion Based Firewall\n");
		printf(" --APP_FILTER_MSN {0,1}\t(Un)Block MSN Messenger\n");
		printf(" --APP_FILTER_YAHOO {0,1}\t(Un)Block YAHOO Messenger\n");
		//510251: sumedh end	
}

int main(int argc, char *argv[])
{        

    static int FWINIT=0,NAPTINIT=0;
    static int DOS=-1,PING=-1,MACFILTER=-1,PACKETFILTER=-1,WPING=-1;
    static int MACFILTERINIT=0,PACKETFILTERINIT=0;
    static int DMZ=-1,VS=-1,PM=-1;
    static int DMZINIT=0,VSINIT=0,PMINIT=0;
    static int INITALL=-1;
    static int IFOPR=-1;
    static int FWENABLE=-1;
    static int NAPTENABLE=-1;
    static int SERVICES=-1;
    static int SERVICES_ACL=-1;
    static int SERVICES_ACL_ENABLE=-1;
    static int UDNF=0;//507141:tc.chen
    __u32    ip=0,netmask=0;
    FILE *fp;
    char ifname[32];
    int option_index = 0;    
    bool bEnable=0;
    char command[128],buffer[64];
    char sCFG_IFNAME[64],sCFG_IFIP[64],sCFG_IFNETMASK[64];
    struct in_addr tmp_ip;
    
		//510251: sumedh start	
		static int POLICYROUTING=-1;
#ifdef IFX_DOS_ENABLE
		static int DOSENABLE=-1;
		char old_winnuke_ports[10],old_tcpsynflood_limit[10],old_tcpsynflood_burst[10], old_hotsync_port[10], old_yahoo_port[10], old_loport_weight[10], old_hiport_weight[10], old_delay_threshold[10], old_weight_threshold[10], old_mime_port[10], old_web_port[10], old_loopback_ports[10], old_fraggle_rate[10];

		char winnuke_ports[10],tcpsynflood_limit[10],tcpsynflood_burst[10], hotsync_port[10], yahoo_port[10], loport_weight[10], hiport_weight[10], delay_threshold[10], weight_threshold[10],  mime_port[10], web_port[10], loopback_ports[10], fraggle_rate[10];

		int WINNUKE=-1, TCPSYNFLOOD=-1, XMAS=-1, HIJACKING=-1, HOTSYNC=-1,YAHOO=-1, PORTSCAN=-1, MIME=-1, CODERED2=-1, CODERED=-1, FTPPR=-1, LAND=-1, LOOPBACK=-1, FRAGGLE=-1, BOMB=-1, ICQ=-1 ;
#endif

		//510251: sumedh ends	

		int APP_FILTER_ENABLE=-1, APP_FILTER_MSN=-1, APP_FILTER_YAHOO=-1; 

    static struct option long_options[] =
    {
            {"NAPTinit", no_argument, &NAPTINIT, 1},
            {"FWinit", no_argument, &FWINIT, 1},
            {"MACFilterinit", no_argument, &MACFILTERINIT, 1},
            {"PacketFilterinit", no_argument, &PACKETFILTERINIT, 1},
            {"PMinit", no_argument, &PMINIT, 1},
            {"DMZinit", no_argument, &DMZINIT, 1},
            {"VSinit", no_argument, &VSINIT, 1},
	    {"INITALL", no_argument,&INITALL,1},
            {"Servicesinit", no_argument, &SERVICES, 1},
            {"ServicesACLinit", no_argument, &SERVICES_ACL, 1},
            {"ServicesACL", required_argument, 0, 'a'},
	    {"UpdateNetfilterFlag",no_argument,&UDNF,1},//507141:tc.chen

            {"FW", required_argument, 0, 'f'},
            {"NAPT", required_argument, 0, 'n'},
#ifdef IFX_DOS_ENABLE
            {"DoS", required_argument, 0, 'o'},
            {"PING_FORWARD", required_argument, 0, 'g'},
            {"PING_GW", required_argument, 0, 'w'},
#endif
            {"MACFilter", required_argument, 0, 'm'},
            {"PacketFilter", required_argument, 0, 'k'},
            {"DMZ", required_argument, 0, 'z'},
            {"VS", required_argument, 0, 'v'},
            {"PM", required_argument, 0, 'p'},
            {"ADDLAN", required_argument, 0, '0'},
            {"ADDWANIF", required_argument, 0, '1'},
            {"ADDWANIP", required_argument, 0, '2'},
            {"DELLAN", required_argument, 0, '3'},
            {"DELWANIF", required_argument, 0, '4'},
            {"DELWANIP", required_argument, 0, '5'},

				//510251: sumedh start
				{"PolicyRoutingInit", required_argument, 0, 'y'},
#ifdef IFX_DOS_ENABLE
				{"DOS_ENABLE", required_argument, 0, 'x'},
				{"Winnuke", required_argument, 0, 'N'},
				{"Tcpsynflood", required_argument, 0, 'S'},
				{"Xmas", required_argument, 0, 'X'},
				{"Tcphijacking", required_argument, 0, 'H'},
				{"Hotsync", required_argument, 0, 'C'},
				{"Yahoo", required_argument, 0, 'Y'},
				{"Portscan", required_argument, 0, 'P'},
				{"Mime", required_argument, 0, 'M'},
				{"Codered2", required_argument, 0, 'R'},
				{"Codered", required_argument, 0, 'D'},
				{"FtpPR", required_argument, 0, 'F'},
				{"Land", required_argument, 0, 'L'},
				{"Loopback", required_argument, 0, 'K'},
				{"Fraggle", required_argument, 0, 'G'},
				{"Bomb", required_argument, 0, 'B'},
				{"Icq", required_argument, 0, 'I'},
#endif

				{"Real_ALG", required_argument, 0, 'r'},
				{"Netmeeting_ALG", required_argument, 0, 'E'},
				{"Ipsec_ALG", required_argument, 0, 'c'},
				{"Ftp_ALG", required_argument, 0, 'T'},
				{"Sip_ALG", required_argument, 0, 's'},
				{"Pptp_ALG", required_argument, 0, 't'},
				//510251: sumedh end
				{"APP_FILTER", required_argument, 0, 'b'},
				{"APP_FILTER_MSN", required_argument, 0, 'c'},
				{"APP_FILTER_YAHOO", required_argument, 0, 'd'},

            {NULL, 0, 0, 0}
    };

    int ch;
    int outFlag= IFX_F_DEFAULT;
    bool bExist;
    char sValue[64];
   
    opterr = 0;
    memset(ifname,0,32);
    
    if (argc >1)
    while ((ch = getopt_long(argc, argv,"a:f:n:g:w:m:k:o:z:v:p:0:1:2:3:4:5:6:7:8:9:b:c:d", long_options, &option_index)) != EOF)
    {
        switch (ch)
        {
#ifdef IFX_DOS_ENABLE
								//510251: sumedh start 
								case 'x':
										DOSENABLE=optarg[0]-'0';
										IFXSetDoSEnable(DOSENABLE);
										break;
								case 'N':
										WINNUKE=optarg[0]-'0';//character to integer
										strtok(optarg,":");
										strcpy(old_winnuke_ports,strtok(NULL,":"));
										strcpy(winnuke_ports,strtok(NULL,":"));
										IFXSetFirewallDoSWinnuke(old_winnuke_ports, winnuke_ports,&WINNUKE);
										break;
								case 'S':
										TCPSYNFLOOD=optarg[0]-'0';//character to integer
										strtok(optarg,":");
										strcpy(old_tcpsynflood_limit,strtok(NULL,":"));
										strcpy(old_tcpsynflood_burst,strtok(NULL,":"));
										strcpy(tcpsynflood_limit,strtok(NULL,":"));
										strcpy(tcpsynflood_burst,strtok(NULL,":"));
										IFXSetFirewallDoSTcpsynflood(old_tcpsynflood_limit, old_tcpsynflood_burst, tcpsynflood_limit, tcpsynflood_burst, &TCPSYNFLOOD);
										break;
								case 'X':
										XMAS=optarg[0]-'0';//character to integer	
										IFXSetFirewallDoSXmas(&XMAS);
										break;    
								case 'H':
										HIJACKING=optarg[0]-'0';//character to integer
										IFXSetFirewallDoSHijacking(&HIJACKING);
										break;
								case 'C':
										HOTSYNC=optarg[0]-'0';
										strtok(optarg,":");
										strcpy(old_hotsync_port,strtok(NULL,":"));
										strcpy(hotsync_port,strtok(NULL,":"));
										IFXSetFirewallDoSHotsync(old_hotsync_port, hotsync_port, &HOTSYNC);
										break;
								case 'Y':
										YAHOO=optarg[0]-'0';
										strtok(optarg,":");
										strcpy(old_yahoo_port,strtok(NULL,":"));
										strcpy(yahoo_port,strtok(NULL,":"));
										IFXSetFirewallDoSYahoo(old_yahoo_port, yahoo_port, &YAHOO);
										break;
								case 'P':
										PORTSCAN=optarg[0]-'0';
										strtok(optarg,":");
										strcpy(old_loport_weight,strtok(NULL,":"));
										strcpy(old_hiport_weight,strtok(NULL,":"));
										strcpy(old_delay_threshold,strtok(NULL,":"));
										strcpy(old_weight_threshold,strtok(NULL,":"));
										strcpy(loport_weight,strtok(NULL,":"));
										strcpy(hiport_weight,strtok(NULL,":"));
										strcpy(delay_threshold,strtok(NULL,":"));
										strcpy(weight_threshold,strtok(NULL,":"));
										IFXSetFirewallDoSPortscan(old_loport_weight, old_hiport_weight, old_delay_threshold, old_weight_threshold, loport_weight, hiport_weight, delay_threshold, weight_threshold, &PORTSCAN);
										break;
								case 'M':
										MIME=optarg[0]-'0';
										strtok(optarg,":");
										strcpy(old_mime_port,strtok(NULL,":"));
										strcpy(mime_port,strtok(NULL,":"));
										IFXSetFirewallDoSMime(old_mime_port, mime_port, &MIME);
										break;
								case 'R':
										CODERED2=optarg[0]-'0';
										strtok(optarg,":");
										strcpy(old_web_port,strtok(NULL,":"));
										strcpy(web_port,strtok(NULL,":"));
										IFXSetFirewallDoSCodered2(old_web_port, web_port, &CODERED2);
										break;
								case 'D':
										CODERED=optarg[0]-'0';
										strtok(optarg,":");
										strcpy(old_web_port,strtok(NULL,":"));
										strcpy(web_port,strtok(NULL,":"));
										IFXSetFirewallDoSCodered(old_web_port, web_port, &CODERED);
										break;
								case 'F':
										FTPPR = optarg[0]-'0';
										IFXSetFirewallDoSFtpPR(&FTPPR);
										break;
								case 'L':
										LAND = optarg[0]-'0';
										IFXSetFirewallDoSLand(&LAND);
										break;
								case 'K':
										LOOPBACK=optarg[0]-'0';
										strtok(optarg,":");
										strcpy(old_loopback_ports,strtok(NULL,":"));
										strcpy(loopback_ports,strtok(NULL,":"));
										IFXSetFirewallDoSLoopback(old_loopback_ports, loopback_ports, &LOOPBACK);
										break;
								case 'G':
										FRAGGLE=optarg[0]-'0';
										strtok(optarg,":");
										strcpy(old_loopback_ports,strtok(NULL,":"));
										strcpy(loopback_ports,strtok(NULL,":"));
										strcpy(old_fraggle_rate,strtok(NULL,":"));
										strcpy(fraggle_rate,strtok(NULL,":"));
										IFXSetFirewallDoSFraggle(old_loopback_ports, loopback_ports, old_fraggle_rate, fraggle_rate, &FRAGGLE);
										break;
								case 'B':
										BOMB = optarg[0]-'0';
										IFXSetFirewallDoSBomb(&BOMB);
										break;
								case 'I':
										ICQ=optarg[0]-'0';
										strtok(optarg,":");
										strcpy(old_web_port,strtok(NULL,":"));
										strcpy(web_port,strtok(NULL,":"));
										IFXSetFirewallDoSIcq(old_web_port, web_port, &ICQ);
										break;
#endif
								case 'y':
										POLICYROUTING=optarg[0]-'0';
										POLICYROUTING_INIT(POLICYROUTING);
										break;
										//510251: sumedh end 
								case 'b':
										APP_FILTER_ENABLE=optarg[0]-'0';
										IFXSetAppFilter(APP_FILTER_ENABLE);
										break;
								case 'c':
										APP_FILTER_MSN=optarg[0]-'0';
										IFXSetAppFilterMsn(APP_FILTER_MSN);
										break;
								case 'd':
										APP_FILTER_YAHOO=optarg[0]-'0';
										IFXSetAppFilterYahoo(APP_FILTER_YAHOO);
										break;
										

	    case 'a':
		SERVICES_ACL_ENABLE=atoi(optarg);
		break;
	    case 'f':
		FWENABLE=atoi(optarg);
		break;
            case 'g':
                PING=atoi(optarg);
                break;
	    case 'n':
		NAPTENABLE=atoi(optarg);
		break;
            case 'w':
                WPING=atoi(optarg);
                break;
            case 'm':
                MACFILTER=atoi(optarg);
                break;
            case 'k':
                PACKETFILTER=atoi(optarg);
                break;
            case 'z':
                DMZ=atoi(optarg);
                break;                                                                
            case 'v':
                VS=atoi(optarg);
                break;                                                                
            case 'p':
                PM=atoi(optarg);
                break;                                                                
            case 'o':
                DOS=atoi(optarg);
                break;

	    // ADD LAN
	    case '0':
		ip = GET_IF_IP_ADDRESS(optarg);
	    // ADD WAN IF
	    case '1':
	    // DEL LAN
	    case '3':
	    // DEL WAN IF
	    case '4':
                IFOPR = ch - '0';
                strcpy(ifname,optarg);
		break;
	    // ADD WAN IP
	    case '2':
	    // DEL WAN IP
	    case '5':
                IFOPR = ch - '0';
        	ip = inet_addr(optarg);
		break;
#if 0
            case '0':
            case '1':
	    case '2':
	    case '4':
            case '5':
	    case '6':
	    case '7':
                IFOPR = ch - '0';
                strcpy(ifname,optarg);
		ip = GET_IF_IP_ADDRESS(ifname);
		break;
            case '3':
	    case '8':
            case '9':
                IFOPR = ch - '0';
                strcpy(ifname,optarg);
		break;
#endif
            case 0:
                break;
                                                   
            default:
		printf("Unknown command\n");
                usage(argv[0]);
                break;
            
        }
    }

    if (INITALL==1)
    {
	INIT_ALL();
    }

    if (FWINIT==1)
    {
        IFX_FIREWALL_INIT();
    }
    
    if (FWENABLE>=0)
    {
	if (ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_MAIN, TAG_FIREWALL_MAIN "_enable",
                           IFX_F_GET_ENA, &outFlag, sValue) != IFX_SUCCESS) {
               IFX_DBG("In function [%s]: Failed to get initialize Firewall Packet Filter Chain !!\n", __FUNCTION__);
               return 1;
        }

	IFXSetFirewallEnable(GET, &bExist);
	
        bEnable = atoi(sValue);
        
	if (bEnable == 0){
		if(bExist == 1)
            		IFXSetFirewallEnable(SET, &bEnable);
	}
        else if (bEnable == 1)
            	IFXSetFirewallEnable(SET, &bEnable);

	update_netfilter_enable_flag();//507141:tc.chen
    }
    if (NAPTINIT==1)
    {
        IFX_NAPT_INIT();
    }
    
    if (NAPTENABLE>=0)
    {
    	IFXSetNAPTEnable(GET, &bEnable);
    	if ( bEnable == 0)
    	{
	    if (NAPTENABLE==1)
           {
            	bEnable=1;
            	IFXSetNAPTEnable(SET, &bEnable);
	    }
        }else if (bEnable == 1)
	{
	   if (NAPTENABLE==0)
           {
            	bEnable=0;
            	IFXSetNAPTEnable(SET, &bEnable);
	    }
	}
	update_netfilter_enable_flag();//507141:tc.chen
    }
    

		/*510251:sumedh (old DoS implementation is commented out, as new one is in use)

    if (DOS>=0)
    {
         /////////////////////////////////////////////////////////////////////
        // set DoS Protect Enable
        /////////////////////////////////////////////////////////////////////
        IFXSetFirewallDosProtoectEnable(GET , &bEnable);
        if ( bEnable == 0)
        {
            if (DOS==1)
            {
                bEnable=1;
                IFXSetFirewallDosProtoectEnable(SET, &bEnable);
                bEnable = 0;
            }
        }else if (bEnable == 1)
        {
            if (DOS==0)
            {
                bEnable=0;
                IFXSetFirewallDosProtoectEnable(SET, &bEnable);
                bEnable = 0;
            }
        }
    }
		 */    
    if (WPING>=0)
    {
    
        /////////////////////////////////////////////////////////////////////
        // Enable Discard WAN Ping Response!
        /////////////////////////////////////////////////////////////////////
        
        IFXSetFirewallPingResponse(GET, DISCARD_PING_WAN_RESPONSE, &bEnable);
        if ( bEnable == 0)
        {
            if (WPING==1)
            {
                bEnable=1;
                IFXSetFirewallPingResponse(SET,DISCARD_PING_WAN_RESPONSE, &bEnable);
                bEnable = 0;
             }
            
        }else if (bEnable == 1)
        {
            if (WPING==0)
            {
                bEnable=0;
                IFXSetFirewallPingResponse(SET,DISCARD_PING_WAN_RESPONSE, &bEnable);
                bEnable = 0;
             }
        }
    }
    if (PING >=0)
    {    
        /////////////////////////////////////////////////////////////////////
        // Enable discard Ping Response Forward!
        /////////////////////////////////////////////////////////////////////
        
        IFXSetFirewallPingResponse(GET, DISCARD_PING_FORWARD_RESONSE, &bEnable);
        if ( bEnable == 0)
        {
            if (PING == 1)
            {
                bEnable=1;
                IFXSetFirewallPingResponse(SET,DISCARD_PING_FORWARD_RESONSE, &bEnable);
                bEnable = 0;
            }
            
        }else if ( bEnable == 1)
        {
            if (PING == 0)
            {
                bEnable=0;
                IFXSetFirewallPingResponse(SET,DISCARD_PING_FORWARD_RESONSE, &bEnable);
                bEnable = 0;
            }
            
        }
    }
    
    if (MACFILTER>=0)
    {
        /////////////////////////////////////////////////////////////////////
        //    Enable MAC Filter
        /////////////////////////////////////////////////////////////////////
        
        IFXSetFirewallMacFilterEnable(GET,&bEnable);
        if ( MACFILTER!=bEnable)
        {
            bEnable = MACFILTER;
            IFXSetFirewallMacFilterEnable(SET,&bEnable);
        }
    }
    
    if (MACFILTERINIT==1)
    {
        MACFILTER_INIT();
    }
    
    if (PACKETFILTER>=0)
    {
        
	if (ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_PACKETFILTER_STATUS, TAG_FIREWALL_PACKETFILTER_STATUS "_enable",
                           IFX_F_GET_ENA, &outFlag, sValue) != IFX_SUCCESS) {
               IFX_DBG("In function [%s]: Failed to get initialize Firewall Packet Filter Chain !!\n", __FUNCTION__);
               return 1;
        }
	
	IFXSetFirewallPacketFilterEnable(GET,&bExist);
	
	bEnable = atoi(sValue);
        if (bEnable == 0) {
		if(bExist == 1)
                	IFXSetFirewallPacketFilterEnable(SET,&bEnable);
        }
	else if (bEnable == 1)
                IFXSetFirewallPacketFilterEnable(SET,&bEnable);
    }
    
    if (PACKETFILTERINIT==1)
    {
        PACKETFILTER_INIT();
    }
    
    if (DMZ>=0)
    {
        if (ifx_GetObjData(FILE_RC_CONF, TAG_FIREWALL_DMZ, TAG_FIREWALL_DMZ "_enable",
                           IFX_F_GET_ENA, &outFlag, sValue) != IFX_SUCCESS) {
               IFX_DBG("In function [%s]: Failed to get initialize Firewall Packet Filter Chain !!\n", __FUNCTION__);
               return 1;
       }
	IFX_SET_NAPT_DMZ_ENABLE(GET,&bExist);

        bEnable = atoi(sValue);
        if (bEnable == 0) {
		if(bExist == 1)
	        	IFX_SET_NAPT_DMZ_ENABLE(SET,&bEnable);
	}
        else if (bEnable==1)
                IFX_SET_NAPT_DMZ_ENABLE(SET,&bEnable);
    }       
    
    if (DMZINIT==1)
    {
        DMZ_INIT();
    }
    
    if (VS>=0)
    {
            IFX_SET_NAPT_DNAT_VIRTUALSERVER_ENABLE(GET,&bEnable);
    
        if (bEnable==0)
        {
            if (VS==1)
            {
                bEnable = 1;        
                IFX_SET_NAPT_DNAT_VIRTUALSERVER_ENABLE(SET,&bEnable);
            }
        }else if (bEnable==1)
        {
            if (VS==0)
            {
                bEnable = 0;        
                IFX_SET_NAPT_DNAT_VIRTUALSERVER_ENABLE(SET,&bEnable);
            }
        }
    }       
    if (VSINIT==1)
    {
        VS_INIT();
    }
    
    if (PM>=0)
    {
        IFX_SET_NAPT_DNAT_PORTMAPPING_ENABLE(GET,&bEnable);
    
        if (bEnable==0)
        {
            if (PM==1)
            {
                bEnable = 1;        
                IFX_SET_NAPT_DNAT_PORTMAPPING_ENABLE(SET,&bEnable);
            }
        }else if (bEnable==1)
        {
            if (PM==0)
            {
                bEnable = 0;        
                IFX_SET_NAPT_DNAT_PORTMAPPING_ENABLE(SET,&bEnable);
            }
        }
    }       
    if (PMINIT==1)
    {
        PM_INIT();
    }
    
    if (IFOPR>= 0)
    {
	if (IFOPR==0)
	{
		sprintf(command,"ifconfig %s |grep \"Mask\" |cut -f4 -d: | cut -f1 -d\" \"",ifname);
		fp = popen(command,"r");
		if(fp == NULL)
		{
			return 0;
		}
		fgets(buffer,sizeof(buffer),fp);
		netmask = inet_addr(buffer);
		pclose(fp);
		sprintf(sCFG_IFNAME,"%s_%s\n",TAG_LAN_IF,ifname);
		tmp_ip.s_addr=ip;
		sprintf(sCFG_IFIP,"ip=%s\n",inet_ntoa(tmp_ip));
		snprintf(sCFG_IFNETMASK,sizeof(sCFG_IFNETMASK),"netmask=%s",buffer);
		ifx_SetCfgData(FILE_SYSTEM_STATUS, sCFG_IFNAME, 2, sCFG_IFIP,sCFG_IFNETMASK);
	} 
	else if (IFOPR==3)
	{
		sprintf(sCFG_IFNAME,"%s_%s\n",TAG_LAN_IF,ifname);
		ifx_GetCfgData(FILE_SYSTEM_STATUS, sCFG_IFNAME, "ip", sCFG_IFIP);
		ifx_GetCfgData(FILE_SYSTEM_STATUS, sCFG_IFNAME, "netmask", sCFG_IFNETMASK);
		ip = inet_addr(sCFG_IFIP);
                netmask = inet_addr(sCFG_IFNETMASK);
	}
#if 0
    if ( (ip != 0 && ip != 0xFFFFFFFF) || (IFOPR==3 || IFOPR>7))
    {
	// lan interface
	if (IFOPR==0)
	{
		sprintf(command,"ifconfig %s |grep \"Mask\" |cut -f4 -d: | cut -f1 -d\" \"",ifname);
		fp = popen(command,"r");
		fgets(buffer,sizeof(buffer),fp);
                netmask = inet_addr(buffer);
		pclose(fp);
		sprintf(sCFG_IFNAME,"if=%s\n",ifname);
		tmp_ip.s_addr=ip;
		sprintf(sCFG_IFIP,"ip=%s\n",inet_ntoa(tmp_ip));
		sprintf(sCFG_IFNETMASK,"netmask=%s",buffer);
		if (IFOPR<2)
		ifx_SetCfgData(FILE_SYSTEM_STATUS, TAG_LAN_IF, 3, sCFG_IFNAME,sCFG_IFIP,sCFG_IFNETMASK);
		else
		ifx_SetCfgData(FILE_SYSTEM_STATUS, TAG_WAN_IF, 3, sCFG_IFNAME,sCFG_IFIP,sCFG_IFNETMASK);
	// wan interface
	}else if (IFOPR>4 && IFOPR<=9)
	{
		if (IFOPR<7)
		{
			ifx_GetCfgData(FILE_SYSTEM_STATUS, TAG_LAN_IF, "ip", sCFG_IFIP);
			ifx_GetCfgData(FILE_SYSTEM_STATUS, TAG_LAN_IF, "netmask", sCFG_IFNETMASK);
		}
		else
		{
			ifx_GetCfgData(FILE_SYSTEM_STATUS, TAG_WAN_IF, "ip", sCFG_IFIP);
			ifx_GetCfgData(FILE_SYSTEM_STATUS, TAG_WAN_IF, "netmask", sCFG_IFNETMASK);
		}
		ip = inet_addr(sCFG_IFIP);
                netmask = inet_addr(sCFG_IFNETMASK);
	}
    	switch (IFOPR)
    	{
	    case 0:
            	IFX_FIREWALL_SET_LAN_IF(ADD,ifname,ip);
	    	break;
	    case 1:
            	IFX_NAPT_SET_LAN_IF(ADD,ifname,ip,netmask);
	    	break;
	    case 2:
            	IFX_FIREWALL_SET_WAN_IF(ADD,ifname,ip);
	    	break;
	    case 3:
            	IFX_NAPT_SET_WAN_IF(ADD,ifname);
	    	break;
	    case 4:
            	IFX_NAPT_SET_WAN_IP(ADD,ip);
	    	break;
	    case 5:
        	IFX_FIREWALL_SET_LAN_IF(DELETE,ifname,ip);
	    	break;
	    case 6:
        	IFX_NAPT_SET_LAN_IF(DELETE,ifname,ip,netmask);
	    	break;
	    case 7:
        	IFX_FIREWALL_SET_WAN_IF(DELETE,ifname,ip);
	   	break;
	    case 8:
        	IFX_NAPT_SET_WAN_IF(DELETE,ifname);
	    	break;
	    case 9:
        	IFX_NAPT_SET_WAN_IP(DELETE,ip);
	    	break;
        }
#endif
    	switch (IFOPR)
    	{
	    // ADD LAN
	    case 0:
		if ( ip != 0 && ip != 0xFFFFFFFF)
		{
            		IFX_FIREWALL_SET_LAN(ADD,ifname,ip);
            		IFX_NAPT_SET_LAN(ADD,ifname,ip,netmask);
		}
	    	break;
	    // ADD WAN IF
	    case 1:
            	IFX_FIREWALL_SET_WAN_IF(ADD,ifname);
            	IFX_NAPT_SET_WAN_IF(ADD,ifname);
	    	break;
	    // ADD WAN IP
	    case 2:
		if ( ip != 0 && ip != 0xFFFFFFFF)
		{
            		IFX_FIREWALL_SET_WAN_IP(ADD,ip);
            		IFX_NAPT_SET_WAN_IP(ADD,ip);
		}
	    	break;
	    // DEL LAN 
	    case 3:
		if ( ip != 0 && ip != 0xFFFFFFFF)
		{
        		IFX_FIREWALL_SET_LAN(DELETE,ifname,ip);
        		IFX_NAPT_SET_LAN(DELETE,ifname,ip,netmask);
		}
	    	break;
	    // DEL WAN IF
	    case 4:
        	IFX_FIREWALL_SET_WAN_IF(DELETE,ifname);
        	IFX_NAPT_SET_WAN_IF(DELETE,ifname);
	    	break;
	    // DEL WAN IP
	    case 5:
		if ( ip != 0 && ip != 0xFFFFFFFF)
		{
        		IFX_FIREWALL_SET_WAN_IP(DELETE,ip);
        		IFX_NAPT_SET_WAN_IP(DELETE,ip);
		}
	   	break;
        }
    }

    if (SERVICES==1)
    {
	INIT_SERVICES();
    }
    if (SERVICES_ACL==1)
    {
	INIT_SERVICES_ACL();
    }
    if (SERVICES_ACL_ENABLE>=0)
    {
	IFX_SET_FIREWALL_SERVICES_ACL_ENABLE(GET, &bEnable);
    	if ( bEnable == 0)
    	{
	    if (SERVICES_ACL_ENABLE==1)
           {
            	bEnable=1;
		IFX_SET_FIREWALL_SERVICES_ACL_ENABLE(SET, &bEnable);
	    }
        }else if (bEnable == 1)
	{
	   if (SERVICES_ACL_ENABLE==0)
           {
            	bEnable=0;
		IFX_SET_FIREWALL_SERVICES_ACL_ENABLE(SET, &bEnable);
	    }
	}
	update_netfilter_enable_flag();//507141:tc.chen
    }

/* 507141:tc.chen start */
    if (UDNF)
	update_netfilter_enable_flag();
/* 507141:tc.chen end */

    return 0;
}

#endif // (CONFIG_FEATURE_FIREWALL) || defined(CONFIG_FEATURE_NAPT)
