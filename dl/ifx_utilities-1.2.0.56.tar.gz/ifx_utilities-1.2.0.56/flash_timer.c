#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <string.h>
#include "ifx_types.h"
#include "drv_tapi_io.h"

#ifdef IFX_MULTILIB_UTIL
#define	main    flash_timer_main	
#endif

int print_help()
{
  printf("Usage: flash_timer ch min max\n");
  printf("Where is ch: 1/2\n");
  printf("        min: 100 ~ 500\n");
  printf("        max: 100 ~ 500\n");
  printf("        and  min < max \n");
}

int main (int argc, char** argv)
{
        int fd, ch;
	IFX_TAPI_LINE_HOOK_VT_t param;

 	if (argc != 4) 
	{
	  print_help();
	  return;
	}
 	if ( !((atoi(argv[1]) == 1)||(atoi(argv[1]) == 2)) )
	{
	  print_help();
	  return;
	}
 	if ( atoi(argv[2]) < 100 || atoi(argv[2]) > 500 ) 
	{
	  print_help();
	  return;
	}
 	if ( atoi(argv[3]) < 100 || atoi(argv[3]) > 500 ) 
	{
	  print_help();
	  return;
	}
 	if ( atoi(argv[2]) >= atoi(argv[3]) ) 
	{
	  print_help();
	  return;
	}
	memset(&param, 0, sizeof(IFX_TAPI_LINE_HOOK_VT_t));
        ch = atoi(argv[1]);
        switch (ch)
        {
          case 1: fd = open("/dev/vin11",O_RDWR);

          case 2: fd = open("/dev/vin12",O_RDWR);
        }
   	param.nType = IFX_TAPI_LINE_HOOK_VT_DIGITLOW_TIME;
        param.nMinTime = atoi(argv[2]); 
        param.nMaxTime = atoi(argv[3]); 
        ioctl(fd, IFX_TAPI_LINE_HOOK_VT_SET, (int)&param);
        close(fd);

 	return 0;	     
}
