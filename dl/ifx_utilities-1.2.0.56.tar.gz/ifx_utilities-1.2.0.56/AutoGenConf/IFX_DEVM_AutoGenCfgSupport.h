/* 
** =============================================================================
**   FILE NAME        : ifx_common.h
**   PROJECT          : AMAZON MAPI
**   DATE             : 19-Jun-2006
**   AUTHOR           : Amazon API Team
**   DESCRIPTION      : This file contains the common definitions used across
			the IFX User sources including the MAPI framework

**   REFERENCES       : 
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/
/*
000002:tc.chen 2005/06/10 add get_adsl_rate and ifx_makeCMV api
*/
#ifndef __IFX_COMMON_H
#define __IFX_COMMON_H
/* 000002:Nirav: from 2.1.22 package*/

#ifndef DONT_USE_IFX_BASIC_TYPES_H
//OMKAR#include <ifx_basic_types.h>
#endif

typedef char char8;
typedef unsigned char uchar8;
typedef unsigned char uint8_t;
typedef char int8;
typedef unsigned char uint8;
typedef short int int16;
typedef unsigned short int uint16;
typedef int int32;
typedef unsigned int uint32;
typedef long long int int64;
typedef unsigned long long int uint64;
typedef float float32;
typedef double float64;
typedef void IFIN_TR69_Void;
typedef char bool;


#include <syslog.h>
#include <stdarg.h>


#define IFX_IN
#define IFX_OUT
#define IFX_IN_OUT

#define BUF_SIZE_50K                    2*32768 //604181: Sumedh - change size of buffer to account for increased size of rc.conf
#define MAX_FILESIZE					2*256*1024
#define BUF_SIZE_1K                     1024
#ifndef MAX_DATA_LEN
//#define MAX_DATA_LEN                    128 /* 64 */
#define MAX_DATA_LEN                    2*2000
#endif
#ifndef MAX_FILELINE_LEN
#define MAX_FILELINE_LEN                256
#endif
#define MAX_FILENAME_LEN                256
#define MAX_TAG_LEN                     64
#define MAX_NAME_LEN                    96
#define NODE_AGE_TIME			4*60*60 /* 000001:Nirav4 hrs of Age Time in Secs */
#define	FALSE				0
#define TRUE				1
#define FILE_UPDATE_TMP                    "/tmp/update.tmp"
#ifndef FILE_RC_CONF
#define FILE_RC_CONF                    "/flash/rc.conf"
#endif // FILE_RC_CONF
#define FILE_RC_CONF_BACKUP             "/tmp/rc.conf.backup"
#ifndef FILE_SYSTEM_STATUS
#define FILE_SYSTEM_STATUS		"/tmp/system_status"
#endif // FILE_SYSTEM_STATUS

//Error Codes returned in GetCfgData in outFlag.
#define IFX_E_INT_ERROR                 -2
#define IFX_E_SEC_NOT_FOUND             -3
#define IFX_E_PARAM_NOT_FOUND           -4
#define IFX_E_UNMATCHED_INPUT           -5
#define IFX_E_SEC_EMPTY                 -6
#define IFX_E_INVALID_INPUT             -7

#if 0
char global_buf[5*1024];

	#define IFX_DBG(fmt, args...)	sprintf(global_buf, fmt, ##args); \
									syslog(LOG_ERR, "%s", global_buf) 
#else
	#define IFX_DBG(fmt, args...)	syslog(LOG_ERR, fmt, ##args)	
#endif


#define IFX_F_DEFAULT    0x0           //Backward compatibility..same old behav.

#define IFX_ACL_CHECK_FAILED -100

// SetCfg Flags
//EXTERNAL FLAGS
#define IFX_F_DONT_ACTIVATE       0x01      //Does not activate the entry.
#define IFX_F_DEACTIVATE          0x01<<1   //Deacte the entry prepend with #   
#define IFX_F_INCOMPLETE          0x01<<2   //Mark entry incomp prepend with #$
#define IFX_F_MODIFY              0x01<<3   //Modify action
#define IFX_F_DELETE              0x01<<4   //Delete Action
#define IFX_F_DONT_VALIDATE       0x01<<5   // Dont Validate
#define IFX_F_DONT_WRITE_TO_FLASH 0x01<<6   //Dont Write To Flash
#define IFX_F_DONT_CHECKPOINT     0x01<<7   //Dont CheckPoint.

//INTERNAL FLAGS
#define IFX_F_INT_ADD        0x01<<31     //Internal-Add to distinguish the overwrite case.
#define IFX_F_INT_MOD_ADD    0x01<<30    //Case of ADD in Modify op.
#define IFX_F_INT_BACKUP     0x01<<29    //Backup File Action
#define IFX_F_INT_RESTORE    0x01<<28    //Restore File Action
#define IFX_F_INT_RESTORE_FROM_FLASH   0x01<<27   //Restore File from Flash Action
#define IFX_F_INT_DONT_RESTART_SERVICES  0x01<<26   //Dont Restart services

//GetCfgData or GetCfgObj Flags
#define IFX_F_GET_ANY        0x01<<8    //Flag used in GetCfg or Obj for no check on status.
#define IFX_F_GET_ENA        IFX_F_MODIFY    //Flag used in GetCfg or Obj for Active check on status.
#define IFX_F_GET_DIS        IFX_F_DEACTIVATE   //Flag used in GetCfg or Obj for Deactivated check on status.
#define IFX_F_GET_INCOMP     IFX_F_INCOMPLETE   //Flag used in GetCfg for Incomp check on status.

#define IFX_F_GETCFG_MASK  IFX_F_GET_ANY|IFX_F_GET_ENA|IFX_F_GET_DIS|IFX_F_GET_INCOMP
#define IFX_F_SETCFG_MASK IFX_F_DONT_ACTIVATE|IFX_F_DEACTIVATE| \
                            IFX_F_INCOMPLETE|IFX_F_MODIFY|IFX_F_DELETE| \
                            IFX_F_DONT_VALIDATE|IFX_F_DONT_WRITE_TO_FLASH| \
                            IFX_F_DONT_CHECKPOINT|IFX_F_INT_ADD| \
                            IFX_F_INT_MOD_ADD|IFX_F_INT_BACKUP| \
                            IFX_F_INT_RESTORE|IFX_F_INT_RESTORE_FROM_FLASH| \
                            IFX_F_INT_DONT_RESTART_SERVICES

//Macros to check the flags set or not set.
#define IFX_DONT_ACTIVATE_F_SET(__flag__) ((__flag__) & IFX_F_DONT_ACTIVATE)
#define IFX_DONT_ACTIVATE_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_DONT_ACTIVATE))

#define IFX_DEACTIVATE_F_SET(__flag__) ((__flag__) & IFX_F_DEACTIVATE)
#define IFX_DEACTIVATE_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_DEACTIVATE))

#define IFX_INCOMPLETE_F_SET(__flag__) ((__flag__) & IFX_F_INCOMPLETE)
#define IFX_INCOMPLETE_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_INCOMPLETE))

#define IFX_MODIFY_F_SET(__flag__) ((__flag__) & IFX_F_MODIFY)
#define IFX_MODIFY_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_MODIFY))

#define IFX_DELETE_F_SET(__flag__) ((__flag__) & IFX_F_DELETE)
#define IFX_DELETE_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_DELETE))

#define IFX_DONT_VALIDATE_F_SET(__flag__) ((__flag__) & IFX_F_DONT_VALIDATE)
#define IFX_DONT_VALIDATE_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_DONT_VALIDATE))

#define IFX_DONT_WRITE_TO_FLASH_F_SET(__flag__) ((__flag__) & IFX_F_DONT_WRITE_TO_FLASH)
#define IFX_DONT_WRITE_TO_FLASH_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_DONT_WRITE_TO_FLASH))

#define IFX_DONT_CHECKPOINT_F_SET(__flag__) ((__flag__) & IFX_F_DONT_CHECKPOINT)
#define IFX_DONT_CHECKPOINT_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_DONT_CHECKPOINT))

#define IFX_ADD_F_SET(__flag__) (!((__flag__) & (IFX_F_DELETE | IFX_F_MODIFY)))
#define IFX_ADD_F_NOT_SET(__flag__) ((__flag__) & (IFX_F_DELETE | IFX_F_MODIFY))

#define IFX_INT_ADD_F_SET(__flag__) ((__flag__) & IFX_F_INT_ADD)
#define IFX_INT_ADD_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_INT_ADD))

#define IFX_INT_MOD_ADD_F_SET(__flag__) ((__flag__) & IFX_F_INT_MOD_ADD)
#define IFX_INT_MOD_ADD_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_INT_MOD_ADD))

#define IFX_INT_BACKUP_F_SET(__flag__) ((__flag__) & IFX_F_INT_BACKUP)
#define IFX_INT_BACKUP_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_INT_BACKUP))

#define IFX_INT_RESTORE_F_SET(__flag__) ((__flag__) & IFX_F_INT_RESTORE)
#define IFX_INT_RESTORE_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_INT_RESTORE))

#define IFX_INT_RESTORE_FROM_FLASH_F_SET(__flag__) ((__flag__) & IFX_F_INT_RESTORE_FROM_FLASH)
#define IFX_INT_RESTORE_FROM_FLASH_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_INT_RESTORE_FROM_FLASH))

#define IFX_INT_DONT_RESTART_SERVICES_F_SET(__flag__) ((__flag__) & IFX_F_INT_DONT_RESTART_SERVICES)
#define IFX_INT_DONT_RESTART_SERVICES_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_INT_DONT_RESTART_SERVICES))

#define IFX_GET_ANY_F_SET(__flag__) ((__flag__) & IFX_F_GET_ANY)
#define IFX_GET_ANY_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_GET_ANY))

#define IFX_GET_ENA_F_SET(__flag__) ((__flag__) & IFX_F_GET_ENA)
#define IFX_GET_ENA_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_GET_ENA))

#define IFX_GET_DIS_F_SET(__flag__) ((__flag__) & IFX_F_GET_DIS)
#define IFX_GET_DIS_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_GET_DIS))

#define IFX_GET_INCOMP_F_SET(__flag__) ((__flag__) & IFX_F_GET_INCOMP)
#define IFX_GET_INCOMP_F_NOT_SET(__flag__) (!((__flag__) & IFX_F_GET_INCOMP))

#define IFX_CONFIG_OWNER_NOT_TR69(iid) (!((iid.config_owner) & (IFX_TR69)))

/* Now include all the API includes */
//OMKAR#include <ifx_api_include.h>


#ifdef ORGCODE
enum {
    ATM_QOS_UBR = 0,
    ATM_QOS_CBR,
    ATM_QOS_NRT_VBR,
    ATM_QOS_RT_VBR,
    ATM_QOS_UBR_PLUS,			/* 507121:linmars */
};

#else
/* This is put for WEB/CLI/SNMP/TR69 to be in
 * synch with the ATM QoS values of the Kernel */
enum {
    ATM_QOS_UBR = 1,
    ATM_QOS_CBR=2,
    ATM_QOS_NRT_VBR=3,
    ATM_QOS_RT_VBR=6,
    ATM_QOS_UBR_PLUS=7,			
};
#endif //ORGCODE

/* 000001:Nirav start */
struct st_versionnode {
   pid_t  UI_pid;
   unsigned int config_version;
   long int timeval;
   struct st_versionnode *next;
};
/* 000001:Nirav end */

extern int ifx_run_command(char *command);

extern int ifx_create_pid_file(char *file_prefix);

extern int ifx_get_process_pid(char *file_prefix);

extern int ifx_rm_pid_file(char *file_prefix);

extern void ifx_rm_pid_file_atexit(void);

extern int ifx_validate_pid(pid_t pid, char *cmd_arg);

extern void ifx_web_convert_string(char *p);


extern int ifx_GetCfgData(char *pFileName, char *pTag, char *pData, char *pRetValue);
extern char *ifx_GetCfgDatafromString(char *pString, char *pSymbol);

extern int ifx_SetCfgData(const char* pFileName, const char* pTag, int nDataCount, const char *pData, ... );

extern int32 ifx_GetCfgDatafromString1(char *pString, char *pSymbol, unsigned long *stateFlag, char *pRet);

extern int ifx_GetCfgData1( IFX_IN const char     *pFileName, 
                           IFX_IN const char     *pTag, 
                           IFX_IN char           *pData, 
                           IFX_IN uint32 inFlag, 
                           IFX_OUT uint32 *outFlag, 
                           IFX_OUT char          *pRetValue);

extern int ifx_GetCfgObject(IFX_IN const char *pFileName, 
                            IFX_IN const char *pTag, 
                            IFX_IN char *pData, 
                            IFX_OUT uint32 stateFlag, 
                            IFX_OUT char **pRetValue);

extern int ifx_SetCfgData1( IFX_IN const char* pFileName, 
                           IFX_IN const char* pTag, 
                           IFX_IN uint32 operFlag, 
                           IFX_IN int nDataCount, 
                           IFX_IN const char* pData, 
                           IFX_IN ... );

extern int ifx_CompactCfgSection( IFX_IN const char* pFileName,
                           IFX_IN const char* pTag,
                           IFX_IN uint32	flag);

extern int ifx_dhcp_renew(char * itf_name);

extern int ifx_dhcp_release(char * itf_name);

extern int ifx_flash_write(void);

extern char *ifx_get_atm_qos_name_by_id(int id);

extern int ifx_change_system_username_password(char *name, char *pasword);

extern char *ifx_strstr(const char *origin, const char *substr);

/* 000002:Nirav start */
extern int ifx_chkImage(char *name,char *errorMsg,char *img_type,int *iExapndDir);

extern int ifx_invokeUpgd(char *fName,char *img_type,int iExapndDir);

#if 0
int ifx_chkImageMem(char *buf);
#endif
/* 000002:Nirav end */
// 000002:tc.chen start
extern int ifx_makeCMV(unsigned char opcode, unsigned char group, unsigned short address, unsigned short index, int size, unsigned short * data, unsigned short *Message, int msg_len);
extern int adsl_get_rate(int type,unsigned long *rate,unsigned long *rate_remainder);
// 000002:tc.chen end
extern int ifx_flash_write_voip_config(void); // 000020:jelly:7/29

#endif /* ] ! __IFX_COMMON_H */
