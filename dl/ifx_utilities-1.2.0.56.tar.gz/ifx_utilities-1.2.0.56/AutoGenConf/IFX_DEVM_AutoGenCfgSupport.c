/* 
** =============================================================================
**   FILE NAME        : ifx_common.c
**   PROJECT          : AMAZON MAPI
**   DATE             : 19-Jun-2006
**   AUTHOR           : Amazon API Team
**   DESCRIPTION      : This file contains the functions related to Amazon
			Database(rc.conf) Management

**   REFERENCES       : 
**   COPYRIGHT        : Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**   HISTORY          : 
**   $Date            $Author                         $Comment
**
** ============================================================================
*/
/*
000002:tc.chen 2005/06/10 add get_adsl_rate and ifx_makeCMV api
*/

//303002:JackLee 2005/06/16 Fix_webUI_firmware_upgrading_causes_webpage_error_issue
//508101:tc.chen 2005/08/10 fix ifxCfgData can not get data if the tag name is at the beginning of the file.
/* 512151:jelly lin:2005/12/15:add new feature "firmware upgrade" */ 
// 608291:jelly 2006/8/29 fix rootfs.img upgrade bug
//6090602:hsumc change default libcrypt-0.9.26.so to libcrypt-0.9.27.so
#define _GNU_SOURCE
#include <stdio.h>
#include <syslog.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/wait.h>
/* 000002:Nirav start */
/* file locks & versioning */
#include <sys/time.h>
#include <sys/file.h>
/* 000002:Nirav end */
#include "IFX_DEVM_AutoGenCfgSupport.h"
#if defined(IFX_SMALL_FOOTPRINT) && defined(IFX_DLOAD_LIBCRYPT)
//6090602:hsumc change default libcrypt-0.9.26.so to libcrypt.so
#define LIBCRYPT	"libcrypt.so"
#include <dlfcn.h>
#else
#include "crypt.h"
#endif

/* 000002:Nirav start */
#include <fcntl.h>
//#define uint32_t		unsigned int
//#define uint8_t			unsigned char
//OMKAR#include "image.h"
//OMKAR#include "crc32.h"
/* 000002:Nirav end */
//000002:tc.chen start
//#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>

#if 0 //OMKAR
//607132:linmars start
#ifdef CPU_DANUBE
//165200:henryhsu 2006-05-04 Modify for Danube
#define ADSL_DEV  "/dev/danube/mei"
#define _AMAZON_ADSL_APP
#include "asm/danube/danube_mei_app_ioctl.h"
#include "asm/danube/danube_mei_ioctl.h"
#include "asm/danube/danube_mei.h"
#define AMAZON_MEI_CMV_WINHOST DANUBE_MEI_CMV_WINHOST
#elif defined(CPU_AMAZON)
#define ADSL_DEV  "/dev/amazon/mei"
#define _AMAZON_ADSL_APP
#include <asm/amazon/amazon_mei_app_ioctl.h>
#include <asm/amazon/amazon_mei_ioctl.h>
#include <asm/amazon/amazon_mei.h>
#endif
//607132:linmars end

//000002:tc.chen end
/* 509202:linmars start */
#include "admioctl.h"
/* 509202:linmars end */
#define IFX_MAX_PID_FILENAME	100
#define IFX_PID_FILE_PATH		"/var/run"

#undef DHCLIENT
#define UDHCPC

#ifdef DHCLIENT
	#define DHCP_COMMAND "dhclient"
#endif

#ifdef UDHCPC
	#define DHCP_COMMAND "udhcpc -i"
#endif

#endif //OMKAR

/* #if 0
	#define IFX_DBG(fmt, args...)	printf("(%s)" fmt, __func__, ##args)
#else
	#define IFX_DBG(fmt, args...)
#endif */

#if 1
	#define IFX_ERR(fmt, args...)	printf("(%s)-Error:" fmt, __func__, ##args)
#else
	#define IFX_ERR(fmt, args...)
#endif

/* 000001:Nirav start */
#define config_start_tag	"#<< ConfigID"
#define config_end_tag	"#>> ConfigID"

unsigned int g_ifx_version = 0;
struct st_versionnode *configheadNode = NULL;
/* 000001:Nirav end */

/* 000001:Nirav start */
int delete_config_node(struct st_versionnode *, struct st_versionnode *);

int get_config_version(const char *configFile, char *version)
{
 char pTag[] = "ConfigID";
 return (ifx_GetCfgData((char *)configFile, pTag, "config_version", version)); 

}


int set_config_version(const char *configFile, int version)
{
 char pTag[] = "ConfigID";
 char pversion[15] = {'\0'};
 snprintf(pversion,sizeof(pversion), ("config_version=\"%d\"\n"), version);
 IFX_DBG("Config Version String ---> %s\n", pversion);
 return (ifx_SetCfgData(configFile, pTag, 1, pversion));

}


struct st_versionnode *delete_node (struct st_versionnode *prev, struct st_versionnode *p)
{

   if ( p == prev) {
      /* Head node */
	prev = p->next;
	configheadNode = prev;
    } else
	prev->next = p->next;
    free (p);
    return (prev);
}


struct st_versionnode *search_config_node(struct st_versionnode **configheadNode, pid_t configPID)
{
  struct timeval tv;	
  struct st_versionnode *matchNode = *configheadNode, *prevnode = *configheadNode;
  gettimeofday(&tv, NULL);
  
  for (; matchNode != NULL; ) {
    if (matchNode->UI_pid == configPID) {
	/* Reset the Timer */
	matchNode->timeval = tv.tv_sec;
	return matchNode;
    }
	  
    /* Delete the Entries which have aged out */
    if ((tv.tv_sec - matchNode->timeval) >= NODE_AGE_TIME) {
	prevnode = delete_node(prevnode, matchNode);
	if (prevnode == *configheadNode) 
	    matchNode = prevnode;
	else
	    matchNode = prevnode->next;
	continue;
    }
    
    prevnode = matchNode;
    matchNode = matchNode->next;
  }
  
  if (matchNode == NULL) 
	IFX_DBG("No matching node for the specified PID:%d\n", configPID);
  return NULL;
  
}


int add_config_node(struct st_versionnode **configheadNode, pid_t newPID)
{
  struct st_versionnode *tempnode = *configheadNode, *newnode;
  char str_version[5] = {'\0'};
  struct timeval tv;
  
  if (search_config_node(configheadNode, newPID) == NULL) {
      newnode = calloc (1, sizeof(struct st_versionnode));
      if (newnode == NULL) {
		IFX_ERR("Not enough memory to malloc for Config Node\n");
        return FALSE;
      }
      newnode->UI_pid = newPID;
      if (get_config_version(FILE_RC_CONF, str_version) != 0)
	 	newnode->config_version = atoi(str_version);
	  else {
		IFX_ERR("Unable to read Version from rc.conf\n");
		free(newnode);
        return FALSE;
	  }	  
      gettimeofday(&tv, NULL);
      newnode->timeval = tv.tv_sec;
      newnode->next = NULL;

      if (*configheadNode == NULL)
	  *configheadNode = newnode;
      else {      
      	while (tempnode->next != NULL)
	   tempnode = tempnode->next;
        /* Add the newly created node at the end */
        tempnode->next = newnode; 
      }
      return TRUE;
  }
  else
   IFX_DBG("Add node already exists\n");
   return FALSE;  

}


int match_config_version(struct st_versionnode **configheadNode, pid_t configPID)
{
  char str_rc_conf_version[15] = {'\0'};
  struct st_versionnode *configNode = NULL;
 /* Get the node based on the PID */
   configNode = search_config_node(configheadNode, configPID);
   if (configNode == NULL)
    return FALSE;
   get_config_version(FILE_RC_CONF, str_rc_conf_version);
   if (configNode->config_version == atoi(str_rc_conf_version))
    return TRUE;
   else
    return FALSE;	
}
/* 000002:Nirav end */


#if 0
int ifx_create_pid_file(char *file_prefix)
{
	int process_id = 0;
	FILE *fp;
	char file_name[IFX_MAX_PID_FILENAME];

	process_id = getpid();

	sprintf(file_name,"%s/%s.pid",IFX_PID_FILE_PATH, file_prefix);	
	fp = fopen(file_name,"w");
	if (fp == NULL) {
		syslog(LOG_INFO, "Error : Couldn't open file [%s] in write mode!",file_name);
		return -1;
	} else {
		fprintf(fp,"%d",process_id);
		fclose(fp);
	}
	strcpy(g_ifx_pidfile_prefix, file_prefix);
	atexit(ifx_rm_pid_file_atexit);
	return 0;
}

int ifx_get_process_pid(char *file_prefix)
{
	int process_id=-1;
	char file_name[IFX_MAX_PID_FILENAME];
	FILE *fp = NULL;

	sprintf(file_name,"%s/%s.pid",IFX_PID_FILE_PATH, file_prefix);	
	fp = fopen(file_name,"r");
	if (fp == NULL) {
		syslog(LOG_INFO, "Error : Couldn't open file [%s] in read mode!",file_name);
		return (process_id);
	} else {
		if (fscanf(fp,"%d",&process_id) < 0) {
			process_id=-1; /* Error */
		}
		fclose(fp);
	}
	return process_id;
}
#endif

/* the function will find the sub-string whole words only */
char *ifx_strstr(const char *origin, const char *substr)
{
	char c;
	char *ptr=(char *)origin;
	int length=strlen(substr);

	while ((ptr = strstr(ptr,substr)))
	{
		c = ptr[length];
		if (!((c>='0' && c<='9') || (c>='A' && c<='Z') || (c>='a' && c<='z') || c=='_'))
		{
			if (ptr > origin) //508101:tc.chen : prevent access invalidate memory space
			{
				c = ptr[-1];
				if (!((c>='0' && c<='9') || (c>='A' && c<='Z') || (c>='a' && c<='z') || c=='_'))
		    			return ptr;
			}else { // 508101:tc.chen
		    		return ptr; //508101:tc.chen
			}
		}
        ptr+=length;
	}
   	return NULL;
}

#if 0
int ifx_rm_pid_file(char *file_prefix)
{
	char file_name[IFX_MAX_PID_FILENAME];


	sprintf(file_name,"%s/%s.pid",IFX_PID_FILE_PATH, file_prefix);	

	return (unlink(file_name));
}

void ifx_rm_pid_file_atexit(void)
{
	ifx_rm_pid_file(g_ifx_pidfile_prefix);
}

/* Check if this pid is indeed the process that we wanted. We do this
 * by opening the process' command line in /proc. It is not an exact
 * match, in that one may want to call this fn multiple times with different
 * parameters to match. For eg., first with <progname> as cmd_arg, then 
 * <arg1> as cmd_arg, and so on ...
 */
int ifx_validate_pid(pid_t pid, char *cmd_arg)
{
	FILE *fp = NULL;
	char file_name[IFX_MAX_PID_FILENAME];
	char *cmd_buff = NULL;
	int len=0, ret=-1;
	
	sprintf(file_name,"/proc/%d/cmdline",pid);
	IFX_DBG("Trying to open file %s ...\n",file_name);
	
	fp = fopen(file_name,"r");
	if (fp == NULL) {
		IFX_ERR("Could Not open File %s",
				file_name);
		goto lbl_end0;
	}
	
	ret = getline(&cmd_buff,&len,fp);
	if (ret < 0) {
		IFX_ERR("getline() function fail ret[%d], len[%d]\n",
			ret, len);
		ret =  -1;
		goto lbl_end1;
	}
  
	IFX_DBG("Command in file is %s",cmd_buff);

	if(strstr(cmd_buff, cmd_arg) == NULL ) {
		IFX_ERR("[%s] Not found in cmd line for pid[%d] \n"
				, cmd_arg, pid);
		ret =  -1;
		goto lbl_end2;
	} else {
		IFX_DBG("[%s] found in cmd line for pid[%d]!\n",
				cmd_arg, pid);
		ret = 0;
	}
 
lbl_end2:	
	if (cmd_buff)
		free(cmd_buff);
lbl_end1:
	fclose(fp);

lbl_end0:
	return (ret);
}

#endif

/////////////////////////////////////////////////////////////////////////////////
//ifx_GetCfgDatafromString(...)
//      DESCRIPTION:    find the data in the string pString
//      pString :
//      pSymbol : Search Name
//      Return Value :  a pointer to the beginning of the Data which found,
//                      or NULL if the pSymbol is not found
/////////////////////////////////////////////////////////////////////////////////
char *ifx_GetCfgDatafromString(char *pString, char *pSymbol)
{
        char  seps[]   = "\t\n\"";
        char *endstr;

        if ((endstr=strstr(pString+4,"#<< ")) == NULL)
            endstr=(char*)0xffffffff;

        if ((pString = ifx_strstr(pString, pSymbol)) == NULL)
        {
                return NULL;
        }

        if (strtok(pString, "=") == NULL)
        {
                return NULL;
        }

        pString = strtok(NULL, seps);
        return ((unsigned long)pString>(unsigned long)endstr)? NULL : pString;
}



//ifx_VerifyGetFlagCombination(...)
int ifx_VerifyGetFlagCombination(unsigned long *flagOp, unsigned long state)
{
    if (flagOp == NULL)
    {
       if (state == IFX_F_GET_INCOMP)
          return -1;
       else
          return 0;
    }

    if IFX_GET_ENA_F_SET(*flagOp)
    {
       if (state != IFX_F_GET_ENA)
          return -1;
    }
    else if IFX_GET_DIS_F_SET(*flagOp)
    {
       if (state != IFX_F_GET_DIS)
          return 0;
    }
    else if IFX_GET_INCOMP_F_SET(*flagOp)
    {
       if (state != IFX_F_GET_INCOMP)
          return 0;
    }
    else if IFX_GET_ANY_F_SET(*flagOp)
    {
       return 0;
    }
    else   //Default behaviour
    {
       if (state == IFX_F_GET_INCOMP)
          return -1;
    }
    
    return 0;
}
 
 


/////////////////////////////////////////////////////////////////////////////////
//ifx_GetCfgDatafromString1(...)
//      DESCRIPTION:    find the data in the string pString
//      pString :
//      pSymbol : Search Name
//      Return Value :  a pointer to the beginning of the Data which found,
//                      or NULL if the pSymbol is not found
/////////////////////////////////////////////////////////////////////////////////
int32 ifx_GetCfgDatafromString1(char *pString, char *pSymbol, unsigned long *stateFlag, char *pRet)
{

	char *dataBgn, *dataEnd, *temp;
	unsigned long actualState;

	dataBgn = dataEnd = temp = NULL;

	if ((pString = ifx_strstr(pString, pSymbol)) == NULL) {
		return IFX_E_PARAM_NOT_FOUND;
	}

	//Check the actual state of entry.
	temp = pString-1;

	if (*temp == '#') 
		actualState = IFX_F_GET_DIS;
	else if (*temp == '$')
		actualState = IFX_F_GET_INCOMP;
	else
		actualState = IFX_F_GET_ENA;

	if (ifx_VerifyGetFlagCombination(stateFlag, actualState) != 0) {
		IFX_DBG("State Conditions do not find a valid combination\n");
		if (stateFlag != NULL)
			*stateFlag = actualState;
		return IFX_E_UNMATCHED_INPUT;
	}

	if ((dataEnd = strchr(pString, '\n')) == NULL)
	{
		return IFX_E_INT_ERROR;
	}

	if ((dataBgn = strchr(pString, '=')) == NULL)
	{
		return IFX_E_INT_ERROR;
	}

	if (stateFlag != NULL)
		*stateFlag = actualState;

	do {
		dataBgn++;
		if (dataBgn >= dataEnd) {
			*pRet = '\0';
			return 0;
		}
	}
	while ((*dataBgn == '\t') || (*dataBgn == '\"'));

	strncpy(pRet, dataBgn, (dataEnd-dataBgn)-1);
    pRet[dataEnd-dataBgn-1] = '\0';
	return  0;

}


void ifx_parse_cmd(char *cmd_buff)
{
	char *temp,*cmd_ptr;
	char current_cmd[1024],cmd_added[100];
	int file_input = 0 , file_output = 1;
	int pipe_found_flag = 0;

	cmd_ptr = cmd_buff;
	while((temp = strchr(cmd_ptr,'|')) != NULL)
	{
		
		memset(current_cmd,'\0',1024);
		strncpy(current_cmd,cmd_ptr,(char *)temp - (char *)cmd_ptr);
                current_cmd[(char *)temp - (char *)cmd_ptr] = '\0';

		// If first command of pipe so input file is not require 
		if (pipe_found_flag == 0)
		{
			sprintf(cmd_added," > /tmp/ifx_f%d",file_output);
		}
		else
		{
#if 0
			if (strstr(current_cmd,"grep"))
			{
				sprintf(cmd_added," -F /tmp/ifx_f%d > /tmp/ifx_f%d",file_input,file_output);
			}
			else
#endif
			{
				if (strstr(current_cmd,"tr"))
				{
					sprintf(cmd_added," < /tmp/ifx_f%d > /tmp/ifx_f%d",file_input,file_output);
				}
				else
				{
					sprintf(cmd_added," /tmp/ifx_f%d > /tmp/ifx_f%d",file_input,file_output);

				}
			}
				
		}

		strcat(current_cmd,cmd_added);
		//printf("\n COMMAND ( %s ) \n",current_cmd);
		system(current_cmd);

		cmd_ptr = temp + 1;
		file_input = file_output;
		file_output = file_output ? 0 :1;
		pipe_found_flag = 1;
	} // End of while Loop
	
	if (pipe_found_flag != 0)
	{
		temp = strchr(cmd_ptr,'\0');
		memset(current_cmd,'\0',1024);
		strncpy(current_cmd,cmd_ptr,(char *)temp - (char *)cmd_ptr);
		current_cmd[(char *)temp - (char *)cmd_ptr] = '\0';
		if (strstr(current_cmd,"grep"))
			{
				sprintf(cmd_added," -F /tmp/ifx_f%d",file_input);
			}		
			else
			{
				if (strstr(current_cmd,"tr"))
				{
					sprintf(cmd_added," < /tmp/ifx_f%d ",file_input);
				}
				else		
				{
					sprintf(cmd_added," /tmp/ifx_f%d ",file_input);
	
				}
			}
		strcat(current_cmd,cmd_added);
		strcpy(cmd_buff,current_cmd);
		//system(current_cmd);
		//printf("Now cmd_buff (%s)",cmd_buff);
	}
	else
	{
		//printf("\nPipe not found \n");
	}


	return;
}


void ifx_web_convert_string(char *p)
{
	char* desbuf=(char *)malloc(128);
	if(desbuf == NULL)
	{
		return;
	}	
	int i,j;
	memset(desbuf,0x00,128);
	for( i=0,j=0; i<127 && j<127 ; i++,j++ )
		{
			if(p[i]=='\0')
			{
				desbuf[j]=p[i];
				break;
			}
			else if(p[i]=='%')
			{
				desbuf[j]=p[i];
				desbuf[j+1]=p[i];
				j++;
			}
			else
			{
				desbuf[j]=p[i];
			}
		}
	strcpy(p,desbuf);
	free(desbuf);

}

/////////////////////////////////////////////////////////////////////////////////
//ifx_GetCfgData(...)
//      Variable Name   ==>     File Name               ;       Pipe Command
//-------------------------------------------------------------------------------
//      pFileName               ==>     Open File Name  ;       Open pipe command
//      pTag                    ==>     TAG_xxx                 ;       NULL
//      pData                   ==>     Search Name             ;       which Line obtained
//      pRetValue               ==>     Return string.  ;       Return string.
//
//      Return Value :  0 is FALSE. 1 is TRUE
//
//      ex1. File Name ==>      if ( ifx_GetCfgData(FILE_RC_CONF, TAG_DHCP_BINPOND, "Server", sValue) == 1)
//      ex2. Pipe          ==>  if ( ifx_GetCfgData(&command, NULL, "1", sValue) == 1 )
///////////////////////////////////////////////////////////////////////////////////

int ifx_GetCfgData(char *pFileName, char *pTag, char *pData, char *pRetValue)
{
    FILE  *fd;
    char  *pBeginString = NULL;
    char buffer[MAX_FILESIZE];
    char  arrBeginTag[64];
    char  sValue[1024];
    int   nLine = 0;
    int   nIndex = 1;

    if (pTag){
        memset(buffer, 0x00, sizeof(buffer));
        if ((fd = fopen(pFileName, "r")) != NULL) {
            fread(buffer, sizeof(char), sizeof(buffer), fd);
            fclose(fd);

            sprintf(arrBeginTag, "#<< %s", pTag);
            if ((pBeginString = ifx_strstr(buffer, arrBeginTag)) == NULL)
                return 0;

            pBeginString = ifx_GetCfgDatafromString(pBeginString, pData);
            if (pBeginString == NULL)
                return 0;
            strcpy(pRetValue, pBeginString);
        }
        else
            return 0;
    }
    else {
		

	//	ifx_parse_cmd(pFileName);	//This function is added to handle pipe command sequentially
	//	printf("\n pFileName cmd (%s)\n",pFileName);

        memset(sValue, 0x00, 1024);

				
        nLine = atoi(pData);
        if ((fd = popen(pFileName, "r")) == NULL)
		{
			system("rm -f /tmp/ifx_f0");
			system("rm -f /tmp/ifx_f1");
            return 0;
		}
/* 000002:Nirav start */
  	    /* Get a Shared Read Lock on Pipe*/
  	    if (flock(fileno(fd), LOCK_SH) < 0) {
  			IFX_ERR("Unable to Lock pipe: %s\n", pFileName);
  			return 0;
  	    }
/* 000002:Nirav end */
        while ( fgets(sValue, 1024, fd) )  {
            if (nIndex == nLine) {
                sValue[strlen(sValue)-1] = 0; // remove "\n" and keep string only
                strcpy(pRetValue, sValue);
				system("rm -f /tmp/ifx_f0");
				system("rm -f /tmp/ifx_f1");
/* 000002:Nirav start*/
	   			/* Release the Read Lock on Pipe */
  	   			flock(fileno(fd), LOCK_UN);
/* 000002:Nirav end */
				pclose(fd);		//BUG FIX : This is added to close the pipe.
                return 1;
            }
            nIndex++;
        }
/* 000002:Nirav start */
        /* Release the Read Lock on Pipe */
  		flock(fileno(fd), LOCK_UN);
/* 000002:Nirav end */
        pclose(fd);
		system("rm -f /tmp/ifx_f0");
		system("rm -f /tmp/ifx_f1");

        return 0;
    }
    return 1;
}

int ifx_ReadObject(char *secBuf, char *pattern, uint32 stateFlag, char **pRetVal)
{
   char          *pString, *pString1, *temp, *pRet;
   unsigned char matchFlag, formString, size;
   unsigned long totalSize, filledSize;

   matchFlag = formString = FALSE;
 
   totalSize = filledSize = size = 0;

   pString1 = temp = pRet = *pRetVal = NULL;

   pString = secBuf;

   if (!strlen(secBuf)) {  //Section is empty. 
		IFX_DBG("In Function [%s]:[%d] Error --> Section is Empty!!\n", __FUNCTION__, 
					__LINE__);
        return IFX_E_SEC_EMPTY;
	}
                                                               
   if (pattern == NULL)   //Pattern not inputted.
   {
       if (stateFlag == IFX_F_GET_ANY)  {
          pRet = (char *)malloc((strlen(secBuf)+1));
	  if(pRet != NULL)
	  {
		  strcpy(pRet, secBuf);
		  *pRetVal = pRet;
	  }
	  return 0;
       }
       else  {
          while ((pString1 = strchr(pString, '\n')) != NULL) {
             if (pString[0] != '#') {  //Non-hashed - Enabled entry.
                if ((stateFlag == IFX_F_GET_ENA) || (stateFlag == IFX_F_DEFAULT))  {
                    size = pString1-pString+1;
                    temp = pString;
                    matchFlag = formString = TRUE;
                }
             } else { //Hashed - Disabled or Incomplete entry.
                 if (pString[1] == '$') {  //Incomplete entry
                    if (stateFlag == IFX_F_GET_INCOMP)  {
                        size = pString1-pString-1;
                        temp = &pString[2];
                        matchFlag = formString = TRUE;
                    }
                 } else {   //Disabled Entry
                    if ((stateFlag == IFX_F_GET_DIS) || (stateFlag == IFX_F_DEFAULT))  {
                        size = pString1-pString;
                        temp = &pString[1];
                        matchFlag = formString = TRUE;
                    }
                }
             }
             if (matchFlag)  { //Realloc size+string-termination(1)
                if ((pRet = (char *)realloc(pRet, filledSize+size+1)) != NULL) {
                   memcpy((pRet+filledSize), temp, size); //With NL
                   filledSize += size;
                   matchFlag = FALSE;
                }
             }
             pString += (pString1-pString)+1;
          } //while
        } //else !ANY
    }
    else {
       //Partial Pattern given .. do wild carding
       if ((pString = strstr(secBuf, pattern)) == NULL) {
			IFX_DBG("In Function [%s]:[%d] Error --> Substring pattern match failed!!\n", __FUNCTION__, 
						__LINE__);
           return -1; 
		}

       while (pString != NULL) {
          if ((pString1 = strchr(pString, '\n')) != NULL) {
             size = pString1-pString+1;
             if (*(pString -1) == '$') {
                if ((stateFlag == IFX_F_GET_INCOMP) || (stateFlag == IFX_F_GET_ANY)) 
                    matchFlag = formString = TRUE;
               
                }
               else {
                 if (*(pString-1) == '#') {
                    if ((stateFlag == IFX_F_GET_DIS) || (stateFlag == IFX_F_GET_ANY) || (stateFlag == IFX_F_DEFAULT))
                       matchFlag = formString = TRUE;
                 }
                 else {
                    if ((stateFlag == IFX_F_GET_ENA) || (stateFlag == IFX_F_GET_ANY) || (stateFlag == IFX_F_DEFAULT))
                       matchFlag = formString = TRUE;
                 }
              }
              if (matchFlag) {
                 pRet = (char *)realloc(pRet, filledSize+size+1);
                 memcpy(pRet+filledSize, pString, size); //With NL
                 filledSize += size;
                 matchFlag = FALSE;
              }
              pString += size;
              pString = strstr(pString, pattern);
          }
      }
	}
    if(pRet != NULL)
    {
	    if (formString) {
		    *(pRet+filledSize) = '\0';
		    *pRetVal = pRet;
		    return 0;
	    }
    }
	IFX_DBG("In Function [%s]:[%d] Error --> No match for Substring pattern !!\n", __FUNCTION__, 
						__LINE__);

	return IFX_E_UNMATCHED_INPUT;
}


/////////////////////////////////////////////////////////////////////////////////
//ifx_GetCfgData1(...)
//      Variable Name   ==>     File Name               ;       Pipe Command
//-------------------------------------------------------------------------------
//      pFileName               ==>     Open File Name  ;       Open pipe command
//      pTag                    ==>     TAG_xxx                 ;       NULL
//      pData                   ==>     Search Name             ;       which Line obtained
//      inFlag                  ==>     State filter inputted by user;
//      pOutFlag                ==>     Output actual State given back;
//      pRetValue               ==>     Return string.  ;       Return string.
//
//      Return Value :  0 is FALSE. 1 is TRUE
//
//      ex1. File Name ==>      if ( ifx_GetCfgData(FILE_RC_CONF, TAG_DHCP_BINPOND, "Server", sValue) == 1)
//      ex2. Pipe          ==>  if ( ifx_GetCfgData(&command, NULL, "1", sValue) == 1 )
///////////////////////////////////////////////////////////////////////////////////
int ifx_GetCfgData1( IFX_IN  const char    *pFileName,
                    IFX_IN  const char    *pTag,
                    IFX_IN  char          *pData,
                    IFX_IN  uint32 inFlag,
                    IFX_OUT uint32 *outFlag,
                    IFX_OUT char          *pRetValue)
{
    FILE  *fd = NULL;
    char  *pBeginString = NULL;
    char  *pEndString = NULL;
    char  buffer[MAX_FILESIZE];
    char  secTag[MAX_TAG_LEN];
    char  sValue[1024];
    int   nLine = 0;
    int   nIndex = 1;

    if (outFlag)
       *outFlag = inFlag;

    if (pTag){
        memset(buffer, 0x00, sizeof(buffer));
        if ((fd = fopen(pFileName, "r")) != NULL) {
            fread(buffer, sizeof(char), sizeof(buffer), fd);
            fclose(fd);

            sprintf(secTag, "#<< %s", pTag);
            if ((pBeginString = ifx_strstr(buffer, secTag)) == NULL) {
				// IFX_DBG("In Function [%s:%d] : [%s] not found in [%s] !!", __FUNCTION__, __LINE__, secTag, buffer);
				IFX_DBG("In Function [%s:%d] : [%s] not found !!", __FUNCTION__, __LINE__, secTag);
               return IFX_E_SEC_NOT_FOUND;
            }

            sprintf(secTag, "#>> %s", pTag);
            if ((pEndString = ifx_strstr(buffer, secTag)) == NULL) {
				// IFX_DBG("In Function [%s:%d] : [%s] not found in [%s] !!", __FUNCTION__, __LINE__, secTag, buffer);
				IFX_DBG("In Function [%s:%d] : [%s] not found in !!", __FUNCTION__, __LINE__, secTag);
               return IFX_E_SEC_NOT_FOUND;
            }

            *pEndString = '\0';

            return ifx_GetCfgDatafromString1(pBeginString, pData, (unsigned long *) outFlag, pRetValue);
        }
        else {
			IFX_DBG("In Function [%s]:[%d] Error --> DB file [%s] Internal Error!!\n", __FUNCTION__, 
					__LINE__, pFileName);
			return IFX_E_INT_ERROR;
		}
    }
    else {
		

	//	ifx_parse_cmd(pFileName);	//This function is added to handle pipe command sequentially
	//	IFX_DBG("\n pFileName cmd (%s)\n",pFileName);

        memset(sValue, 0x00, 1024);

				
        nLine = atoi(pData);
        if ((fd = popen(pFileName, "r")) == NULL)
		{
			system("rm -f /tmp/ifx_f0");
			system("rm -f /tmp/ifx_f1");
			IFX_DBG("In Function [%s]:[%d] Error --> Unable to open DB file [%s] !!\n", __FUNCTION__, 
				__LINE__, pFileName);
			return -1;
            // return 0;
		}
/* 000002:Nirav start */
  	    /* Get a Shared Read Lock on Pipe*/
  	    if (flock(fileno(fd), LOCK_SH) < 0) {
  			IFX_ERR("Unable to Lock pipe: %s\n", pFileName);
			IFX_DBG("In Function [%s]:[%d] Error --> Unable to Lock pipe !!\n", __FUNCTION__, 
				__LINE__);
  			return -1;
  	    }
/* 000002:Nirav end */
        while ( fgets(sValue, 1024, fd) )  {
            if (nIndex == nLine) {
                sValue[strlen(sValue)-1] = -1; // remove "\n" and keep string only
                strcpy(pRetValue, sValue);
				system("rm -f /tmp/ifx_f0");
				system("rm -f /tmp/ifx_f1");
/* 000002:Nirav start*/
	   			/* Release the Read Lock on Pipe */
  	   			flock(fileno(fd), LOCK_UN);
/* 000002:Nirav end */
				pclose(fd);		//BUG FIX : This is added to close the pipe.
                return 0;
            }
            nIndex++;
        }
/* 000002:Nirav start */
        /* Release the Read Lock on Pipe */
  		flock(fileno(fd), LOCK_UN);
/* 000002:Nirav end */
        pclose(fd);
		system("rm -f /tmp/ifx_f0");
		system("rm -f /tmp/ifx_f1");
		IFX_DBG("In Function [%s]:[%d] Error --> Release Lock failed !!\n", __FUNCTION__, 
				__LINE__);

        return -1;
    }
    return 0;
}

/////////////////////////////////////////////////////////////////////////////////
//ifx_GetCfgObject(...)
//      Variable Name   ==>     File Name               ;       Pipe Command
//-------------------------------------------------------------------------------
//      pFileName               ==>     Open File Name  ;       Open pipe command
//      pTag                    ==>     TAG_xxx         ;       NULL
//      pData                   ==>     Search Name     ;       which Line obtained
//      pRetValue               ==>     Return string Ptr.  ;       Return string.
//
//      Return Value :  0 is FALSE. 1 is TRUE
//
///////////////////////////////////////////////////////////////////////////////////

int ifx_GetCfgObject(const char *pFileName, const char *pTag, char *pData, uint32 stateFlag, char **pRetValue)
{
    FILE  *fd;
    char  *pBgnString, *pEndString; /* , *pString; */
    char  buffer[MAX_FILESIZE];
    char  beginTag[MAX_TAG_LEN], endTag[MAX_TAG_LEN];

    pBgnString = pEndString = NULL;
    memset(buffer, 0x00, sizeof(buffer));

    if (pTag) 
    {
        if ((fd = fopen(pFileName, "r")) != NULL) {
            fread(buffer, sizeof(char), sizeof(buffer), fd);
            fclose(fd);

            sprintf(beginTag, "#<< %s", pTag);
            if ((pBgnString = ifx_strstr(buffer, beginTag)) == NULL) {
				IFX_DBG("In Function [%s]:[%d] Error --> DB file Section [%s] not Found!!\n", __FUNCTION__, 
						__LINE__, beginTag);
                return IFX_E_SEC_NOT_FOUND;
			}
            sprintf(endTag, "#>> %s", pTag);
            if ((pEndString = ifx_strstr(buffer, endTag)) == NULL) {
				IFX_DBG("In Function [%s]:[%d] Error --> DB file Section [%s] not Found!!\n", __FUNCTION__, 
						__LINE__, endTag);
                return IFX_E_SEC_NOT_FOUND;
			}
            if ((pBgnString = strchr(pBgnString, '\n')) == NULL) {
				IFX_DBG("In Function [%s]:[%d] Error --> DB file [%s] Section Empty!!\n", __FUNCTION__, 
						__LINE__, pFileName);
                return IFX_E_SEC_EMPTY;
			}

            pBgnString++;     //Advance after NL.

            //Retain only contents between begin and end tag
            strcpy(pEndString, "\0");  
  
            return ifx_ReadObject(pBgnString, pData, stateFlag, pRetValue);
       }
    }
	IFX_DBG("In Function [%s]:[%d] Error --> No matching section tags!!\n", __FUNCTION__, 
						__LINE__);
    return -1;
}
////////////////////////////////////////////////////////////////////////////////
//ifx_SetCfgData(...)
//    Variable Name    ==>    File Name
//------------------------------------------------------------------------------
//    pFileName        ==>    Open File Name
//    pTag            ==>    TAG_xxx
//    nDataCount        ==>    Data number for setting.
//    pData            ==>    Data content for setting.
//
//    Return Value :    0 is FALSE. 1 is TRUE
//

int ifx_SetCfgData(const char* pFileName, const char* pTag, int nDataCount,
    const char* pData, ... )
{
    FILE       *fdIn, *fdOut;
    char     arrInLine[MAX_FILELINE_LEN];
    char    strTempName[MAX_FILENAME_LEN];
    char    buf[BUF_SIZE_50K];
    char     arrBeginTag[MAX_TAG_LEN], arrEndTag[MAX_TAG_LEN];
    unsigned char  bTagArea = FALSE,bFound = FALSE;
    va_list    args;

    // First, extract data for list and store into buffer
    va_start( args, pData );
    strcpy(buf, pData);

    while( --nDataCount )
    {
        pData = va_arg(args, char *);
        strcat(buf, pData);
    }
    va_end(args);

    memset(arrBeginTag, 0x00, sizeof(arrBeginTag));
    memset(arrEndTag, 0x00, sizeof(arrEndTag));
    sprintf(arrBeginTag, "#<< %s", pTag);
    sprintf(arrEndTag, "#>> %s", pTag);

    if ((fdIn = fopen(pFileName, "r+t")) == NULL)
    {
        return 0;
    }

/* 000002:Nirav start */
    /* Get an Exclusive Write Lock */ 
    if (flock(fileno(fdIn), LOCK_EX) < 0) {
       IFX_ERR("Unable to perform Exclusive Lock on: %s\n", pFileName);
       fclose(fdIn);
       return -1;
    }
/* 000002:Nirav end */
    sprintf(strTempName, "%s", FILE_UPDATE_TMP);
    if ((fdOut = fopen(strTempName, "w+")) == NULL)
    {
/* 000002:Nirav start */
	/* Release the Write lock just in case we fail! */
//		IFX_DBG("BOOL BOOL Val is [%d] Cannot lock [%s]\n", 
//				set_version_entered, strTempName);
  	flock(fileno(fdIn), LOCK_UN);
/* 000002:Nirav end */
        fclose(fdIn);
        return 0;
    }

/* 000002:Nirav start */
    /* Get an Exclusive Write Lock on Tmp file 
     * Just in case somebody tries
     * to tamper with it */ 
    if (flock(fileno(fdOut), LOCK_EX) < 0) {
       IFX_ERR("Unable to perform Exclusive Lock on: %s\n", strTempName);
       fclose(fdOut);
       fclose(fdIn);
       return 0;
    }
/* 000002:Nirav end */

    while (fgets(arrInLine, sizeof(arrInLine), fdIn))
    {
        if (!strlen(arrInLine)) continue; //Null line

        // remove "\n" and keep string only
        arrInLine[strlen(arrInLine)-1] = 0;
/* 000002:Nirav start */
		if (!strncmp(arrInLine, config_start_tag, strlen(config_start_tag))) {
			fprintf(fdOut, "%s\n", arrInLine);
			/* Increment and write config_version out */
			g_ifx_version++;
 			fprintf(fdOut, ("config_version=\"%d\"\n"), g_ifx_version);
            while (fgets(arrInLine, sizeof(arrInLine), fdIn))
            {
                arrInLine[strlen(arrInLine)-1] = 0;
                if (strncmp(arrInLine, config_end_tag, strlen(config_end_tag) ) == 0)
                {
                  //  fprintf(fdOut, "%s\n", arrInLine);
                    break;
                }
            }
		}
/* 000002:Nirav end */

        if (strncmp(arrInLine, arrBeginTag, sizeof(arrBeginTag)) == 0)
        {
            bTagArea = TRUE;
	    bFound = TRUE;
        }

        fprintf(fdOut, "%s\n", arrInLine);

        if (bTagArea)
        {
            // Print all datas to file
            fprintf(fdOut, "%s", buf);

            while (fgets(arrInLine, sizeof(arrInLine), fdIn))
            {
                arrInLine[strlen(arrInLine)-1] = 0;
                if (strncmp(arrInLine, arrEndTag, sizeof(arrEndTag)) == 0)
                {
                    fprintf(fdOut, "%s\n", arrInLine);
                    bTagArea = FALSE;
                    break;
                }
            }
        }
    }

    // no tag found, append to end
    if (!bFound)
    {
        fprintf(fdOut, "%s\n", arrBeginTag);
        fprintf(fdOut, "%s", buf);
        fprintf(fdOut, "%s\n", arrEndTag);
    }
/* 000002:Nirav start */
    /* Release the Write Locks */
    flock(fileno(fdIn), LOCK_UN);
    flock(fileno(fdOut), LOCK_UN);
/* 000002:Nirav end */
    fclose(fdIn);
    fclose(fdOut);
    if (remove(pFileName) == 0)
    {
        rename(strTempName, pFileName);
    }
    else
    {
    }

    return 1;
}


int ifx_FormSectionLineWithInput(char *secLine, char *buf, uint32 flag, char *outLine)
{
   char    *pString, *pString1; /* , *pString2; */
   char    tBuf[MAX_FILELINE_LEN];
   char    cpySecLine[MAX_FILELINE_LEN];
   char    pattern[MAX_FILELINE_LEN];
   // uint8_t bFilled = FALSE;

   pString = buf;

   memset(tBuf, '\0', MAX_FILELINE_LEN);
   memset(outLine, '\0', MAX_FILELINE_LEN);
   memset(cpySecLine, '\0', MAX_FILELINE_LEN);
   memset(pattern, '\0', MAX_FILELINE_LEN);


   //Remove "#" and "#$" characters for pattern searching in Copy of SecLine
   if (secLine[0] == '#')  {
      if (secLine[1] == '$')
          strcpy(cpySecLine, &secLine[2]);
      else
          strcpy(cpySecLine, &secLine[1]);
   }
   else
       strcpy(cpySecLine, secLine);

   //For Delete or Add Action ..check in whole buffer
   if (IFX_DELETE_F_SET(flag) || IFX_INT_ADD_F_SET(flag) || IFX_INT_MOD_ADD_F_SET(flag))
   {
      //Iterate with patterns in buffer comparing with section Line name.
      while ((pString1 = strchr(pString, '=')) != NULL)
      {
         if (strncmp(cpySecLine, pString, (pString1-pString)) == 0) {
			if (IFX_DELETE_F_SET(flag))
                return 0;
            else
                return -1; //Already exists can not be added.
         }

         pString1 = strchr(pString, '\n');
         
         pString += (pString1-pString)+1;
      }

      strcpy(outLine, secLine);
      return 0;
   }

   //For rest type of actions check with pattern 
   strcpy(pattern, cpySecLine);
         
   if (strtok(pattern, "=") == NULL)
   {
        strcpy(outLine, secLine);
        return 0;
    }

    if ((pString = ifx_strstr(pString, pattern)) == NULL)
    {//Line does not find match in user input buffer
         strncpy(outLine, secLine,strlen(secLine));
	 outLine[strlen(secLine)] = '\0';
         return 0;
    }

   if (IFX_MODIFY_F_SET(flag))  {
          pString1 = strchr(pString, '\n');
          memcpy(tBuf, pString, (pString1-pString)); //Without NL
	  tBuf[pString1-pString] = '\0';
          strcpy(outLine, tBuf);

          if (IFX_DONT_ACTIVATE_F_SET(flag) || IFX_DEACTIVATE_F_SET(flag)) {
               outLine[0] = '#';
               strcpy(&outLine[1], tBuf);
           }
       }

      // ADD-DISABLE case is handled separately - shailesh
      if (((IFX_DEACTIVATE_F_SET(flag)) || (IFX_DONT_ACTIVATE_F_SET(flag))) &&
           !(IFX_INT_ADD_F_SET(flag) || (IFX_INT_MOD_ADD_F_SET(flag))))
      {
          outLine[0] = '#';

          if (IFX_MODIFY_F_SET(flag))  //Already re-filled in Mod op.
               strcpy(&outLine[1], tBuf);
           else
               strcpy(&outLine[1], cpySecLine);
       }

      // ADD-INCOMPLETE case is handled separately
      if (IFX_INCOMPLETE_F_SET(flag) &&
           !(IFX_INT_ADD_F_SET(flag) || (IFX_INT_MOD_ADD_F_SET(flag))))
      {
          outLine[0] = '#';
          outLine[1] = '$';

          if (IFX_MODIFY_F_SET(flag))  //Already re-filled in Mod op.
               strcpy(&outLine[2], tBuf);
           else
               strcpy(&outLine[2], cpySecLine);
     }

   return 0;
}


int ifx_FormatAddition(char *inBuf, uint32 flag, char *outBuf)
{
    char    splPrep[3];
    char    *pString = NULL;
    char    *destString = outBuf;
    char    *inString = inBuf;

    memset(splPrep, '\0', 3);

	if(IFX_DEACTIVATE_F_SET(flag) || IFX_DONT_ACTIVATE_F_SET(flag))
       splPrep[0] = '#';
	else if(IFX_INCOMPLETE_F_SET(flag)) {
       splPrep[0] = '#';
       splPrep[1] = '$';
    }
    
    while ((pString = strchr(inString, '\n')) != NULL)
    {
       memcpy(destString, splPrep, strlen(splPrep));
       memcpy(destString+strlen(splPrep), inString, (pString-inString)+1);
       destString+=strlen(splPrep)+(pString-inString)+1;
       inString = inString+(pString-inString)+1;
    }

   return 0;
}
////////////////////////////////////////////////////////////////////////////////
//ifx_SetCfgData1(...)
//    Variable Name    ==>    File Name
//------------------------------------------------------------------------------
//    pFileName        ==>    Open File Name
//    pTag            ==>    TAG_xxx
//    nDataCount        ==>    Data number for setting.
//    pData            ==>    Data content for setting.
//
//    Return Value :    0 is FALSE. 1 is TRUE
//

int ifx_SetCfgData1(IFX_IN  const char*   pFileName,
                    IFX_IN  const char*   pTag,
                    IFX_IN  uint32		  operFlag,
                    IFX_IN  int           nDataCount,
                    IFX_IN  const char*   pData,
                    IFX_IN  ... )
{
    FILE       *fdIn, *fdOut;
    char       arrInLine[MAX_FILELINE_LEN];
    char       outLine[MAX_FILELINE_LEN];
    char       strTempName[MAX_FILENAME_LEN];
    char       buf[BUF_SIZE_50K];
    char       *outBuf, *sectionBuf;
    char       arrBeginTag[MAX_TAG_LEN], arrEndTag[MAX_TAG_LEN];
    uint8_t    bTagArea = FALSE, bFound = FALSE;
    va_list    args;
    int        retVal = -1;

    outBuf = sectionBuf = NULL;

    memset(buf, '\0', BUF_SIZE_50K);

    // First, extract data from var list and store into buffer
    if (nDataCount) {
       va_start( args, pData );
       strcpy(buf, pData);

       while(--nDataCount )
       {
           pData = va_arg(args, char *);
           strcat(buf, pData);
       }
       va_end(args);
   }

    memset(arrBeginTag, 0x00, sizeof(arrBeginTag));
    memset(arrEndTag, 0x00, sizeof(arrEndTag));
    sprintf(arrBeginTag, "#<< %s", pTag);
    sprintf(arrEndTag, "#>> %s", pTag);

    if ((fdIn = fopen(pFileName, "r+t")) == NULL)
    {
		IFX_DBG("In Function [%s]:[%d] Error --> DB file [%s] open failed!!\n", __FUNCTION__, 
					__LINE__, pFileName);
        return retVal;
    }

    /* Get an Exclusive Write Lock */ 
    if (flock(fileno(fdIn), LOCK_EX) < 0) {
       IFX_ERR("Unable to perform Exclusive Lock on: %s\n", pFileName);
       fclose(fdIn);
       return IFX_E_INT_ERROR;
    }
    sprintf(strTempName, "%s", FILE_UPDATE_TMP);
    if ((fdOut = fopen(strTempName, "w+")) == NULL)
    {
	/* Release the Write lock just in case we fail! */
//SHAIL		IFX_DBG("BOOL BOOL Val is [%d] Cannot lock [%s]\n", 
//SHAIL				set_version_entered, strTempName);
  	flock(fileno(fdIn), LOCK_UN);
        fclose(fdIn);
		IFX_DBG("In Function [%s]:[%d] Internal Error !!\n", __FUNCTION__, __LINE__);
        return IFX_E_INT_ERROR;
    }

    /* Get an Exclusive Write Lock on Tmp file 
     * Just in case somebody tries
     * to tamper with it */ 
    if (flock(fileno(fdOut), LOCK_EX) < 0) {
	   IFX_DBG("In Function [%s]:[%d] Exclusive lock SET on [%s] failed !!\n", __FUNCTION__, __LINE__,
				strTempName);
       fclose(fdOut);
       fclose(fdIn);
       return IFX_E_INT_ERROR;
    }

    while (fgets(arrInLine, sizeof(arrInLine), fdIn))
    {
        if (!strlen(arrInLine)) continue; //Null line

        // remove "\n" and keep string only
        arrInLine[strlen(arrInLine)-1] = 0;
	if (!strncmp(arrInLine, config_start_tag, strlen(config_start_tag))) {
	    fprintf(fdOut, "%s\n", arrInLine);
	    /* Increment and write config_version out */
	    g_ifx_version++;
 	    fprintf(fdOut, ("config_version=\"%d\"\n"), g_ifx_version);
            while (fgets(arrInLine, sizeof(arrInLine), fdIn))
            {
                arrInLine[strlen(arrInLine)-1] = 0;
                if (strncmp(arrInLine, config_end_tag, strlen(config_end_tag) ) == 0)
                {
                  //  fprintf(fdOut, "%s\n", arrInLine);
                    break;
                }
            }
	}

        if (strncmp(arrInLine, arrBeginTag, sizeof(arrBeginTag)) == 0)
        {
            bTagArea = TRUE;
	    bFound = TRUE;
        }

        fprintf(fdOut, "%s\n", arrInLine); //Write Begin Tag or Other Line.

        if (bTagArea)
        {
            if (!operFlag)   //default - overwrite case.
            {
               fprintf(fdOut, "%s", buf);
               while (fgets(arrInLine, sizeof(arrInLine), fdIn))
               {
                   arrInLine[strlen(arrInLine)-1] = 0;
                   if (!strncmp(arrInLine, arrEndTag, sizeof(arrEndTag)))
                   { //EndTag Found - write it
                       fprintf(fdOut, "%s\n",arrInLine);
                       bTagArea = FALSE;
                       break;
                   }
               }
            }
            else
            {
               while (fgets(arrInLine, sizeof(arrInLine), fdIn))
               {
                   arrInLine[strlen(arrInLine)-1] = 0;
                   if (strncmp(arrInLine, arrEndTag, sizeof(arrEndTag)) != 0)
                   {
                      if (ifx_FormSectionLineWithInput(arrInLine, buf, operFlag, outLine) != 0)
                         goto lbl_end;

                      if (!strlen(outLine)) continue; //Null line
                         fprintf(fdOut, "%s\n",outLine);

                   }
                   else
                   {   //EndTag found
                       if ((operFlag & IFX_F_INT_ADD) || (operFlag & IFX_F_INT_MOD_ADD))
                       {
                           outBuf = (char *)malloc(sizeof(buf));
                           if (outBuf != NULL)  {
                               memset(outBuf, '\0', sizeof(buf));
                               ifx_FormatAddition(buf, operFlag, outBuf);
                               if (!strlen(outBuf)) {
                                   free(outBuf);
                                   continue; //Null line
                               }
                               fprintf(fdOut, "%s", outBuf);
                               free(outBuf);
                          }
                       }
                       // Write the Section End Tag now.
                       fprintf(fdOut, "%s\n", arrInLine);
                       bTagArea = FALSE;
                       break;
                   }
               }
            }
        }
    }

    // no tag found, append to end
    if (!bFound)
    {
        fprintf(fdOut, "%s\n", arrBeginTag);

        if (operFlag & IFX_F_INT_ADD)
        {
            outBuf = (char *)malloc(sizeof(buf));
            if (outBuf != NULL)  {
                memset(outBuf, '\0', sizeof(buf));
                ifx_FormatAddition(buf, operFlag, outBuf);
                if (strlen(outBuf)) 
                   fprintf(fdOut, "%s", outBuf);
                free(outBuf);
           }
        }
        else
           fprintf(fdOut, "%s", buf);
          
        fprintf(fdOut, "%s\n", arrEndTag);
    }
 
    retVal = 0;

lbl_end:	
    /* Release the Write Locks */
    flock(fileno(fdIn), LOCK_UN);
    flock(fileno(fdOut), LOCK_UN);
    fclose(fdIn);
    fclose(fdOut);

    if (retVal == 0) {
        if (remove(pFileName) == 0)
        {
            rename(strTempName, pFileName);
        }
        else
        {
           IFX_ERR("Remove rc.conf file failed.. cant do anything ???\n");
        }
    }
    else
    {
        if (remove(strTempName) != 0)
        {
           IFX_ERR("Remove Temp file failed.. cant do anything ???\n");
        }
    }

    return retVal;
}
////////////////////////////////////////////////////////////////////////////////
//ifx_CompactCfgSection(...)
//    Variable Name    ==>    File Name
//------------------------------------------------------------------------------
//    pFileName        ==>    Open File Name
//    pTag            ==>    TAG_xxx
//    Return Value :    0 is FALSE. 1 is TRUE
//

int ifx_CompactCfgSection( IFX_IN const char* pFileName,
                           IFX_IN const char* pTag,
                           IFX_IN uint32	flag)
{
   char          *secBuf, *pString, *pString1, *pString2, *temp;
   char *pStr = '\0';
   char          lineBuf[MAX_FILELINE_LEN], nameBuf[MAX_FILELINE_LEN], valBuf[MAX_FILELINE_LEN];
   char          outBuf[BUF_SIZE_50K];
   uint8_t       i, numLine=0, numFlagSet = FALSE;
   int count=0, index=0;

   memset(outBuf, 0, sizeof(outBuf));
   memset(lineBuf, 0, sizeof(lineBuf));

   if (!(IFX_DELETE_F_SET(flag) || IFX_INT_ADD_F_SET(flag) || IFX_INT_MOD_ADD_F_SET(flag)))
       return -1;

   if (pTag) {
       if (!(ifx_GetCfgObject((char *)pFileName, (char *)pTag, NULL, IFX_F_GET_ANY, &secBuf)))
       { 
           sprintf(lineBuf, "%s_Count", pTag);
	   if(secBuf == NULL)
	   {
		   return -1;
	   }
	   if ((pStr = ifx_strstr(secBuf, lineBuf)) == NULL) {
		   printf("in function [%s] :linebuf [%s] not found in [%s] secbuf !!\n", __FUNCTION__, lineBuf, secBuf);
		   free(secBuf);
		   return -1;
	   }


	   pString = pStr;

	   if ((pString = strchr(pString, '\n')) == NULL) {
		   free(secBuf);
		   printf("in [%s] : no \\n in pstring [%s] !!\n", __FUNCTION__, pString);
		   return -1;
	   }

           pString++;

           while ((pString = strstr(pString, "_cpeId")) != NULL)
           {
              count++;
              pString = strchr(pString, '\n');
	      if(pString == NULL)
	      {
		      break;
	      }
              if (!numFlagSet)
              {
                temp = pString;
                if ((pString1 = strstr(pString, "_cpeId")) == NULL)
                {
					numLine++;
                   while ((pString = strchr(pString, '\n')) != NULL) {
                      numLine++;
                      pString++;
                   }
                }
                else
                {
                   while ((pString = strchr(pString, '\n')) != NULL) {
                      numLine++;
                      pString++;
                      if (pString > pString1)
                         break;
                   }
                }
                numLine--;
                numFlagSet = TRUE;
                pString = temp;
             }
          } //while

          //Form the section and invoke SetCfgData with overwrite flag .
          sprintf(outBuf,"%s=\"%d\"\n",lineBuf, count);
          temp = outBuf+strlen(outBuf);

          pString = pStr;  //beginning of section starting with count
          pString = strchr(pString, '\n'); 
          pString++;       //Next Line after count

          while (count != 0) {
             for (i=0; i<numLine; i++) {
                pString1 = strchr(pString, '\n'); 

                memset(lineBuf, '\0', sizeof(lineBuf));
                memset(nameBuf, '\0', sizeof(nameBuf));
                memset(valBuf, '\0', sizeof(valBuf));

                memcpy(lineBuf, pString, pString1-pString+1);
		lineBuf[pString1-pString+1] = '\0';	       

                if ((pString2 = strrchr(lineBuf,'=')) != NULL) {

                   memcpy(nameBuf, lineBuf, pString2-lineBuf+1);
		   nameBuf[pString2-lineBuf+1] = '\0';
                   memcpy(valBuf, pString2+1, strlen(lineBuf)-(pString2-lineBuf+1));
		   valBuf[strlen(lineBuf)-(pString2-lineBuf+1)] = '\0';

                   if ((pString1 = strrchr(nameBuf,'_')) != NULL) {
                      pStr = pString1;
                      while ((*(--pStr) != '_')) 
                         continue;

                      memcpy(temp, nameBuf, pStr-nameBuf+1);
                      temp += (pStr-nameBuf+1);

                      sprintf(temp,"%d",index);

                      strcat(outBuf, pString1); 
                      strcat(outBuf, valBuf); //Include NL
                      temp = outBuf + strlen(outBuf);;

                      pString = strchr(pString, '\n');
                      pString++;
                }
              }
            }
            count--;
            index++;
         }
         free(secBuf);
         return (ifx_SetCfgData1(pFileName, pTag, IFX_F_DEFAULT, 1, outBuf));
      }
    }
       
   return -1;
}
int ifx_run_command(char *command)
{
	int status =0,ret = 0; 

	status = system(command);
	if(status != -1)
	{
		waitpid(-1,&status,0);
		if (WIFEXITED(status))     
	    	{
			ret = WEXITSTATUS(status);
        	//	IFX_DBG("\n Command status is %d\n", ret);
		} 
		else
		{
    			IFX_DBG("\n ERROR : system command not exited properly \n");
			exit(0);
		}
	}
	return ret;
}

#if 0
int ifx_dhcp_renew(char * itf_name)
{
	sprintf(ifx_command_buff,"%s %s",DHCP_COMMAND,itf_name);
	IFX_DBG("\n Now Command is %s\n",ifx_command_buff);
	return ifx_run_command(ifx_command_buff);
}

int ifx_dhcp_release(char * itf_name)
{
	sprintf(ifx_command_buff,"%s -r %s",DHCP_COMMAND,itf_name);
	IFX_DBG("\n Now Command is %s\n",ifx_command_buff);
	return ifx_run_command(ifx_command_buff);
}

/*****************************************************************************
* Function Name: ifx_flash_write
* Description  : save configuration data 
* Input Value  : 
* Output Value :
* Return Value : 0:Fail 1: Success
* Notes	:
*****************************************************************************/
int ifx_flash_write(void)
{
  ifx_run_command("/etc/rc.d/backup");
  return 1;
}

// 000020:jelly:start:7/28
int ifx_flash_write_voip_config(void)
{
  ifx_run_command("/etc/rc.d/backup_voip");
  return 1;
}
// 000020:jelly:end

char *ifx_get_atm_qos_name_by_id(int id)
{
    switch (id)
    {
    case ATM_QOS_CBR:
        return "CBR";
    case ATM_QOS_RT_VBR:
        return "RT-VBR";
    case ATM_QOS_NRT_VBR:
        return "NRT-VBR";
    case ATM_QOS_UBR_PLUS:	/* 507121:linmars */
        return "UBR+";
    case ATM_QOS_UBR:
    default:
        break;
    }
    return "UBR";
}

int ifx_change_system_username_password(char *name, char *password)
{
    const char *fname = "/ramdisk/flash/passwd";
    FILE *fp = NULL;
    char *cp = NULL;
#if defined(IFX_SMALL_FOOTPRINT) && defined(IFX_DLOAD_LIBCRYPT)
	char *(*crypt_ptr)(char *,char *) = NULL;
	void *dlHandle = NULL;
	char *error = NULL;
#endif

    if ((fp = fopen(fname, "w+")) == NULL)
    {
        IFX_DBG("\nCan't open/create file %s\n", fname);
        return -1;
    }
#if defined(IFX_SMALL_FOOTPRINT) && defined(IFX_DLOAD_LIBCRYPT)
	dlHandle = dlopen(LIBCRYPT,RTLD_LAZY);
	if(dlHandle) {
		crypt_ptr = dlsym(dlHandle,"crypt");
		if((error = dlerror()) != NULL) {
			IFX_DBG( "could not find function crypt in libcrypt. Error : %s\n",error);
		}
		cp = (char *)(*crypt_ptr)(password, "$1$");
		dlclose(dlHandle);
	} else {
		IFX_DBG( "could not open library %s",LIBCRYPT);
	}
#else
    cp = (char *)crypt(password, "$1$");
#endif
    fprintf(fp, "root:%s:0:0:root:/root:/bin/sh", cp);
    fflush(fp);
    fclose(fp);
    return 0;
}

/* 000002:Nirav start */
#define TEMP_BUF	4096
#define	RESTART_PROCESS_FILE	"/tmp/restart_porcess.sh"

int ifx_chkImage(char *name,char *errorMsg,char *img_type,int *iExapndDir)
{
	char buf[TEMP_BUF];
	int fd_img;
	int len;
	image_header_t img_header;
	unsigned int crc;
	int retval = 0;

	fd_img = open(name,O_RDONLY);
	if(fd_img <= 0)
	{
		sprintf(errorMsg,"Could not open image %s\n",name);
		retval = 1;
		goto abort;
	}
	read(fd_img,&img_header,sizeof(image_header_t));
	if(img_header.ih_magic != IH_MAGIC)
	{
		sprintf(errorMsg,"The image %s does not contain valid header\n",name);
		retval = 1;
		goto abort;
	}

	crc = 0x00000000 ^ 0xffffffff;
	len = 0;
	memset(buf,0x00,sizeof(buf));
	while((len = read(fd_img,buf,sizeof(buf) - 1)) > 0)
	{
		crc = crc32(crc,buf,len);
		memset(buf,0x00,sizeof(buf));
	}
	crc ^= 0xffffffff;

	if(crc != img_header.ih_dcrc)
	{
		sprintf(errorMsg,"The image %s does not contain valid checksum",name);
		retval = 1;
		goto abort;
	}

	memset(img_type,0x00,sizeof(img_type));
	if(strstr(img_header.ih_name,"linux") || strstr(img_header.ih_name,"Linux") || img_header.ih_type == IH_TYPE_KERNEL)
	{
		strcpy(img_type,"kernel");
		*iExapndDir = 1;

// 608291:jelly start
	//} else if(strstr(img_header.ih_name,"rootfs") || strstr(img_header.ih_name,"Rootfs") )
	} else if(strstr(img_header.ih_name,"rootfs") || strstr(img_header.ih_name,"Rootfs") || strstr(img_header.ih_name,"RootFS"))
// 608291:jelly end
	{
		strcpy(img_type,"rootfs");
		*iExapndDir = 0;
	} else if(strstr(img_header.ih_name,"firmware") || strstr(img_header.ih_name,"Firmware") || img_header.ih_type == IH_TYPE_FIRMWARE)
	{
		strcpy(img_type,"firmware");
		*iExapndDir = 0;
	} else if(strstr(img_header.ih_name,"sysconfig") || strstr(img_header.ih_name,"Sysconfig"))
	{
		strcpy(img_type,"sysconfig");
		*iExapndDir = 0;
	} else if(strstr(img_header.ih_name,"ubootconfig") || strstr(img_header.ih_name,"Ubootconfig")) 
	{
		strcpy(img_type,"ubootconfig");
		*iExapndDir = 0;
	} else 
	{
		sprintf(errorMsg,"Uploaded image type = %d and name [%s] are unknown. The name could be one of [L|l]inux, [R|r]ootfs, [F|f]irmware, [S|s]ysconfig, [U|u]bootconfig only.\n",img_header.ih_type,img_header.ih_name);
		retval = 1;
	}
abort:
	if(retval) {
		char command[128];
		sprintf(command,"%s &",RESTART_PROCESS_FILE);
		system(command);
		unlink(RESTART_PROCESS_FILE);
	}
	return retval;
}

int ifx_invokeUpgd(char *fName,char *img_type,int iExapndDir)
{
	char command[256];

	memset(command,0x00,sizeof(command));
	//303002:JackLee		
	sprintf(command,"/etc/rc.d/invoke_upgrade.sh %s %s %d 1 reboot", fName, img_type, iExapndDir);
	system(command);
	return 0;
}

int ifx_chkImageMem(char *buf)
{
	image_header_t *pimg_header;
	char command[128];

	pimg_header = (image_header_t *)buf;
	if(pimg_header->ih_magic != IH_MAGIC) {
		return 1;
	}
	sprintf(command,"/etc/rc.d/free_memory.sh");
	system(command);	
	return 0;
}
// 512151:jelly:start
int ifx_chkImageMem(char *buf,char *appname)
{
	image_header_t *pimg_header;
	char command[128];

	pimg_header = (image_header_t *)buf;
	if(pimg_header->ih_magic != IH_MAGIC) {
		return 1;
	}
	sprintf(command,"/etc/rc.d/free_memory.sh %s",appname);
	system(command);	
	return 0;
}
//512151:jelly:end
/* 000002:Nirav end */


#if 1 //165200:henryhsu 2006-05-04 Modify for Danube
// 000002:tc.chen start add ifx_makeCMV and get_adsl_rate api
int ifx_makeCMV(unsigned char opcode, unsigned char group, unsigned short address, unsigned short index, int size, unsigned short * data, unsigned short *Message, int msg_len)
{
	if (msg_len < 16*2)
		return -1;
        memset(Message, 0, 16*2);
        Message[0]= (opcode<<4) + (size&0xf);
        if(opcode == H2D_DEBUG_WRITE_DM)
                Message[1]= (group&0x7f);
        else
                Message[1]= (((index==0)?0:1)<<7) + (group&0x7f);
        Message[2]= address;
        Message[3]= index;
        if((opcode == H2D_CMV_WRITE)||(opcode == H2D_DEBUG_WRITE_DM))
                memcpy(Message+4, data, size*2);

        return 0;
}

// get adsl downstream/upstream rate 
int adsl_get_rate(int type,unsigned long *rate,unsigned long *rate_remainder)
{
    int up_lsw=0,up_msw=0,down_lsw,down_msw;
    unsigned short Message[16];
    int LatencyType=0,adsl_status=0;
    int fd_mei=0,adsl_mode = 0;
    unsigned long usDataRate=0,dsDataRate=0;
    unsigned long usDataRate_remain=0,dsDataRate_remain=0;

    //607132:linmars
    fd_mei=open(ADSL_DEV, O_RDWR);

    if (ifx_makeCMV(H2D_CMV_READ,2, 0, 0, 1, NULL,Message,sizeof(Message))<0)
	goto err_exit;
    if (ioctl(fd_mei, AMAZON_MEI_CMV_WINHOST, &Message)<0)
	goto err_exit;
    adsl_status=Message[4]&0x0f;

    if (adsl_status == 7)
    {
    //LatencyType [stat,12,0]
        if (ifx_makeCMV(H2D_CMV_READ,2, 12, 0, 1, NULL,Message,sizeof(Message))<0)
	    goto err_exit;
        if (ioctl(fd_mei, AMAZON_MEI_CMV_WINHOST, &Message)<0)
	    goto err_exit;
        LatencyType=Message[4]&0x03;//[0:1]

        //data rate -start
        if (LatencyType>0 && LatencyType<3)
        {
            if (adsl_mode<=8){//ADSL
		switch (type)
                {
		case 0:
                    if (ifx_makeCMV(H2D_CMV_READ,6, 0, (LatencyType-1)*2, 1, NULL,Message,sizeof(Message))<0)
	   	        goto err_exit;
                    if (ioctl(fd_mei, AMAZON_MEI_CMV_WINHOST, &Message)<0)
	   	        goto err_exit;
                    up_lsw=Message[4];//UpDataRate
                    if (ifx_makeCMV(H2D_CMV_READ,6, 0, (LatencyType-1)*2+1, 1, NULL,Message,sizeof(Message))<0)
		        goto err_exit;
                    if (ioctl(fd_mei, AMAZON_MEI_CMV_WINHOST, &Message)<0)
		        goto err_exit;
                    up_msw=Message[4];//UpDataRate
                    usDataRate=(up_msw*65536 +up_lsw)/1000; //unit:*1000
		    usDataRate_remain=(up_msw*65536 +up_lsw)%1000;  //unit:*1000
		    break;
		case 1:
                    if (ifx_makeCMV(H2D_CMV_READ,6, 1, (LatencyType-1)*2, 1, NULL,Message,sizeof(Message))<0)
		     goto err_exit;
                    if (ioctl(fd_mei, AMAZON_MEI_CMV_WINHOST, &Message)<0)
		     goto err_exit;
                    down_lsw=Message[4];//DownDataRate
                    if (ifx_makeCMV(H2D_CMV_READ,6, 1, (LatencyType-1)*2+1, 1, NULL,Message,sizeof(Message))<0)
		     goto err_exit;
                    if (ioctl(fd_mei, AMAZON_MEI_CMV_WINHOST, &Message)<0)
		     goto err_exit;
                    down_msw=Message[4];//DownDataRate
                    dsDataRate=(down_msw*65536 + down_lsw)/1000;    //unit:*1000
		    dsDataRate_remain=(down_msw*65536 + down_lsw)%1000;     //unit:*1000
		    break;
		default:
		    goto err_exit;

                 }
            }else { // ADSL2/2+
                 unsigned long Mp,Lp,Tp,Rp,Kp,Bpn;
                 // down stream data rate
    
                switch (type)
                {
		case 0:
                    if (ifx_makeCMV(H2D_CMV_READ,8, 25, LatencyType-1, 1, NULL,Message,sizeof(Message))<0)
		        goto err_exit;
                    if (ioctl(fd_mei, AMAZON_MEI_CMV_WINHOST, &Message)<0)
		        goto err_exit;
                    Lp=Message[4];

                    if (ifx_makeCMV(H2D_CMV_READ,8, 23, LatencyType-1, 1, NULL,Message,sizeof(Message))<0)
		        goto err_exit;
                    if (ioctl(fd_mei, AMAZON_MEI_CMV_WINHOST, &Message)<0)
		        goto err_exit;
                    Rp=Message[4];
 
                    if (ifx_makeCMV(H2D_CMV_READ,8, 24, LatencyType-1, 1, NULL,Message,sizeof(Message))<0)
  		        goto err_exit;
                    if (ioctl(fd_mei, AMAZON_MEI_CMV_WINHOST, &Message)<0)
		        goto err_exit;
                    Mp=Message[4];

                    if (ifx_makeCMV(H2D_CMV_READ,8, 26, LatencyType-1, 1, NULL,Message,sizeof(Message))<0)
		        goto err_exit;
                    if (ioctl(fd_mei, AMAZON_MEI_CMV_WINHOST, &Message)<0)
		        goto err_exit;
                    Tp=Message[4];

                    if (ifx_makeCMV(H2D_CMV_READ,8, 28, (LatencyType-1)*2, 2, NULL,Message,sizeof(Message))<0)
		        goto err_exit;
                    if (ioctl(fd_mei, AMAZON_MEI_CMV_WINHOST, &Message)<0)
		        goto err_exit;
                    Kp=Message[4]+ Message[5]+1;
                    Bpn=Message[4]+ Message[5];
                    dsDataRate=((Tp*(Bpn+1)-1)*Mp*Lp*4)/(Tp*(Kp*Mp+Rp));
		    dsDataRate_remain=((((Tp*(Bpn+1)-1)*Mp*Lp*4)%(Tp*(Kp*Mp+Rp)))*1000)/(Tp*(Kp*Mp+Rp));
		    break;

		case 1:

                    //// up stream data rate
                    if (ifx_makeCMV(H2D_CMV_READ,8, 14, LatencyType-1, 1, NULL,Message,sizeof(Message))<0)
	   	        goto err_exit;
                    if (ioctl(fd_mei, AMAZON_MEI_CMV_WINHOST, &Message)<0)
		        goto err_exit;
                    Lp=Message[4];
   
                    if (ifx_makeCMV(H2D_CMV_READ,8, 12, LatencyType-1, 1, NULL,Message,sizeof(Message))<0)
	   	        goto err_exit;
                    if (ioctl(fd_mei, AMAZON_MEI_CMV_WINHOST, &Message)<0)
		        goto err_exit;
                    Rp=Message[4];

                    if (ifx_makeCMV(H2D_CMV_READ,8, 13, LatencyType-1, 1, NULL,Message,sizeof(Message))<0)
		        goto err_exit;
                    if (ioctl(fd_mei, AMAZON_MEI_CMV_WINHOST, &Message)<0)
		        goto err_exit;
                    Mp=Message[4];

                    if (ifx_makeCMV(H2D_CMV_READ,8, 15, LatencyType-1, 1, NULL,Message,sizeof(Message))<0)
		        goto err_exit;
                    if (ioctl(fd_mei, AMAZON_MEI_CMV_WINHOST, &Message)<0)
		        goto err_exit;
                    Tp=Message[4];

                    if (ifx_makeCMV(H2D_CMV_READ,8, 17, (LatencyType-1)*2, 2, NULL,Message,sizeof(Message))<0)
		        goto err_exit;
                    if (ioctl(fd_mei, AMAZON_MEI_CMV_WINHOST, &Message)<0)
		        goto err_exit;
                    Kp=Message[4]+ Message[5]+1;
                    Bpn=Message[4]+ Message[5];

                    usDataRate=((Tp*(Bpn+1)-1)*Mp*Lp*4)/(Tp*(Kp*Mp+Rp));
                    usDataRate_remain=((((Tp*(Bpn+1)-1)*Mp*Lp*4)%(Tp*(Kp*Mp+Rp)))*1000)/(Tp*(Kp*Mp+Rp));
		    break;
		default:
			goto err_exit;
		}
             }
        }
    }else
	goto err_exit;
    close(fd_mei);
    if (type ==  0)
    {
	*rate = usDataRate;	
	*rate_remainder = usDataRate_remain;	
    }
    else if (type ==  1)
    {
	*rate = dsDataRate;	
	*rate_remainder = dsDataRate_remain;	
    }
    else
	goto err_exit;

    return 0;

err_exit:
    close(fd_mei);
    return -1;
}
// 000002:tc.chen end
#endif //165200:henryhsu




#endif
/* 509203:linmars end */
