#include "common.h"
#include "cmd_upgrade.h"
#include "command.h"
#include "crc32.h"

#include <ctype.h>

 env_t env;
void program_img(env_t *,int ,int ); 
void flash_sect_erase(unsigned long,int );
void flash_write(char *,unsigned long,int );

/* kamal: newly added functions to support the new method find_mtd in 5.1 */
int get_partName(unsigned long addr_first, char *name, unsigned long *part_begin_addr, char *mtd_dev);
/* kamal: newly added functions to support the new method find_mtd in 5.1 
 * ENDS */

#ifdef CONFIG_BOOT_FROM_NAND
#define TEMP_ENV_FILE "/tmp/ubootconfig"
#endif
int read_env()
{
	int dev_fd;
	unsigned long crc = 0;

#ifdef CONFIG_BOOT_FROM_NAND
	char cmd[255];
	cmd[0] = '\0';
	sprintf(cmd, "nanddump -q -f %s -o -l %u %s", TEMP_ENV_FILE, CFG_ENV_SIZE, MTD_CONFIG_DEV_NAME);
	system(cmd);
	/* system("nanddump -q -f /root/ubootconfig -o -l 4096 /dev/mtd5"); */
	dev_fd = open(TEMP_ENV_FILE, O_SYNC | O_RDWR);
#else
	dev_fd = open(MTD_CONFIG_DEV_NAME,O_SYNC | O_RDWR);
#endif
	if(dev_fd < 0){
		ifx_debug_printf("The device %s could not be opened\n", MTD_CONFIG_DEV_NAME);
		return 1;
	}

#ifndef CONFIG_BOOT_FROM_NAND
	//printf("CFG_ENV_ADDR 0x%08lx  MTD_DEV_START_ADD 0x%08lx\n", CFG_ENV_ADDR, MTD_DEV_START_ADD);
	//lseek(dev_fd, CFG_ENV_ADDR - MTD_DEV_START_ADD, SEEK_CUR);   /* kamal: commented off in ugw5.1 for working with updated uboot */
#endif
#if 0
	/* incorrect reading offset, a hidden problem when we really use full ENV_SIZE buffer */
	ifx_debug_printf("read_env : Reading env for %d bytes at offset 0x%08lx\n", sizeof(env) - 1, CFG_ENV_ADDR - MTD_DEV_START_ADD);
	read(dev_fd,(void *)&env,sizeof(env) - 1);
#else
	/* ifx_debug_printf("read_env : Reading env for %d bytes at offset 0x%08lx\n", sizeof(env), CFG_ENV_ADDR - MTD_DEV_START_ADD); */
	read(dev_fd, (void *)&env, sizeof(env));
#endif
	close(dev_fd);
	
	crc ^= 0xffffffffL;
	crc = crc32(crc, env.data, ENV_SIZE);
	crc ^= 0xffffffffL;

	//printf("crc: 0x%08lx env.crc: 0x%08lx\n", crc, env.crc);

	if (crc != env.crc) {
		ifx_debug_printf("For enviornment CRC32 is not OK\n");
		return 1;
	}
	return 0;
}

int envmatch (unsigned char *s1, int i2)
{
	while (*s1 == env.data[i2++])
		if (*s1++ == '=')
			return(i2);
	if (*s1 == '\0' && env.data[i2-1] == '=')
		return(i2);
	return(-1);
}

char *get_env (unsigned char *name)
{
	int i, nxt;

	for (i=0;i<ENV_SIZE && env.data[i] != '\0'; i=nxt+1) {
		int val;

		for (nxt=i;nxt<ENV_SIZE && env.data[nxt] != '\0'; nxt++) {
			if (nxt >= ENV_SIZE) {
				ifx_debug_printf("Did not get var %s with nxt = %d\n",name,nxt);
				return (NULL);
			}
		}
		if ((val=envmatch(name, i)) < 0)
			continue;
		return (&env.data[val]);
	}

	return (NULL);
}

void env_crc_update (void)
{
	env.crc = 0x00000000 ^ 0xffffffff;
	env.crc = crc32(env.crc, env.data, ENV_SIZE);
	env.crc ^= 0xffffffff;
}

int set_env(char *name,char *val)
{
	int  len, oldval;
	unsigned char *envptr, *nxt = NULL;
	unsigned char *env_data = env.data;

	if (!env_data)	/* need copy in RAM */
	{
		ifx_debug_printf("set_env(): env_data doesn't exist\n");
		return 1;
	}

	/*
	 * search if variable with this name already exists
	 */
	oldval = -1;
	for (envptr=env_data; *envptr; envptr=nxt+1) {
		for (nxt=envptr; *nxt; ++nxt)
			;
		if ((oldval = envmatch(name, envptr-env_data)) >= 0)
			break;
	}

	ifx_debug_printf("set_env : the old value of %s = %s\n",name,envptr);
	/*
	 * Delete any existing definition
	 */
	if (oldval >= 0) {
		if (*++nxt == '\0') {
			if (envptr > env_data) {
				envptr--;
			} else {
				*envptr = '\0';
			}
		} else {
			for (;;) {
				*envptr = *nxt++;
				if ((*envptr == '\0') && (*nxt == '\0'))
					break;
				++envptr;
			}
		}
		*++envptr = '\0';
	}

	/*
	 * Append new definition at the end
	 */
	for (envptr=env_data; *envptr || *(envptr+1); ++envptr)
		;
	if (envptr > env_data)
		++envptr;
	/*
	 * Overflow when:
	 * "name" + "=" + "val" +"\0\0"  > ENV_SIZE - (envptr-env_data)
	 */
	len = strlen(name) + 2;
	/* add '=' for first arg, ' ' for all others */
	len += strlen(val) + 1;
	ifx_debug_printf("set_env : setting %s=%s for %d bytes\n",name,val,len);

	if (len > (&env_data[ENV_SIZE]-envptr)) {
		ifx_debug_printf ("## Error: environment overflow, \"%s\" deleted\n", name);
		return 1;
	}
	while ((*envptr = *name++) != '\0')
		envptr++;

	*envptr = '=';
	while ((*++envptr = *val++) != '\0')
		;

	/* end is marked with double '\0' */
	*++envptr = '\0';

	/* Update CRC */
	env_crc_update ();
	ifx_debug_printf("set_env(): CRC updated\n");

	return 0;
}

#define getenv(x)		get_env(x)

int saveenv()
{
#ifdef CONFIG_BOOT_FROM_NAND
	int fd, len = 0;

	char cmd[255];
	cmd[0] = '\0';

	sprintf(cmd, "flash_erase %s", MTD_CONFIG_DEV_NAME);
	system(cmd);
	/* system("flash_erase /dev/mtd5"); */
	fd = open(TEMP_ENV_FILE, O_WRONLY | O_TRUNC | O_CREAT, 0644);
	if (fd < 0) {
		close(fd);
		ifx_debug_printf("Saving enviornment failed for NAND\n");
		return 1;
	}
	len = write(fd, (void*)&env, sizeof(env));
	if (len < sizeof(env)) {
		ifx_debug_printf("Saving enviornment failed for NAND. bytes written = %d acutal size = %d\n",len,sizeof(env));
	//	return 2;
	}
	close (fd);
	cmd[0] = '\0';
	sprintf(cmd, "nandwrite -q %s %s", MTD_CONFIG_DEV_NAME, TEMP_ENV_FILE);
	system(cmd);
	/* system("nandwrite -q /dev/mtd5 /root/ubootconfig"); */
	ifx_debug_printf("Saving enviornment with CRC 0x%08lx\n",env.crc);
#else
	ifx_debug_printf("Saving enviornment with CRC 0x%08lx\n",env.crc);
	program_img(&env,sizeof(env),CFG_ENV_ADDR);
#endif
	return 0;
}

int saveenv_copy()
{
	unsigned long ubootconfig_copy_addr;
	char *kernel_addr;
	char ubootconfig_copy_data[sizeof(env) + sizeof(UBOOTCONFIG_COPY_HEADER)];

	kernel_addr = getenv("f_kernel_addr");
	if(kernel_addr != NULL)
	{
		ubootconfig_copy_addr = strtoul(kernel_addr,NULL,16) - sizeof(ubootconfig_copy_data); 
		memset(ubootconfig_copy_data,0x00,sizeof(ubootconfig_copy_data));
		sprintf(ubootconfig_copy_data,"%s",UBOOTCONFIG_COPY_HEADER);
		memcpy(ubootconfig_copy_data + sizeof(UBOOTCONFIG_COPY_HEADER),&env,sizeof(env));

		flash_sect_erase(ubootconfig_copy_addr,ubootconfig_copy_addr + sizeof(ubootconfig_copy_data) - 1);

		flash_write(ubootconfig_copy_data,ubootconfig_copy_addr,sizeof(ubootconfig_copy_data));

	}
return 0;
}

/* kamal: newly added functions to support the new method find_mtd in 5.1 */
int get_partName(unsigned long addr_first, char *name, unsigned long *part_begin_addr, char *mtd_dev)
{
	int i, state =0, cnt=0, mtd=0, rootfsp=0;
        char cr, *buf, b_size='k';
        char val[10], priv_part[16];

	buf = (char *)getenv("mtdparts");
	//printf("kamal: buf %s\n",buf);

	memset(val,0x00,sizeof(val));
        memset(name,0x00,sizeof(name));
	memset(priv_part,0x00,sizeof(priv_part));

	unsigned long offset_addr = strtoul((char *)getenv("part0_begin"),NULL,16);
        unsigned long flash_end = strtoul((char *)getenv("flash_end"),NULL,16);
	unsigned long prev_offset = offset_addr;
	if(buf != NULL)
	{
		for(i=0;i<=strlen(buf);i++) {
			cr =  *(buf+i);
			switch(state) {
				case 0:
					if(isdigit(cr)) { val[cnt++]=cr; state = 1; }
					if(cr=='-') { state=2; strcpy(val,"0"); cnt=0; }
					break;
				case 1:
					if(cr==':') { state=0; cnt=0; memset(val,0x00,sizeof(val)); }
					else if (cr=='k' || cr =='m' || cr =='K' || cr == 'M') { state=2; val[cnt]='\0'; b_size=cr; cnt=0; }
					else if(isdigit(cr)) { val[cnt++]=cr; }
					break;
				case 2:
					if(cr=='(') { state=3; cnt=0; }
					else state =0;
					break;
				case 3:
					if(cr==')') { state=4; name[cnt]='\0'; cnt=0; }
					else { name[cnt++]=cr; }
					break;
				case 4:
					if(cr==',') {
						if(addr_first == offset_addr) {
							*part_begin_addr=offset_addr;
							sprintf(mtd_dev,"/dev/mtd/%d",mtd);
							return 0;
						} else if(addr_first < offset_addr) {
							*part_begin_addr=prev_offset;
							strcpy(name,priv_part);
							sprintf(mtd_dev,"/dev/mtd/%d",mtd-1-rootfsp);
							return 0;
						}
						prev_offset=offset_addr;
						strcpy(priv_part,name);
						if(b_size=='m' || b_size =='M')
							offset_addr+=(atoi(val)*1024*1024);
						else
							offset_addr+=(atoi(val)*1024);
						cnt =0;
						state =0;
						mtd++;
#ifndef CONFIG_BOOT_FROM_NAND 			
						if(strcmp(name,"rootfs")==0) {
							mtd++;			//kamal: rootfs partition has both kernel & rootfs
							rootfsp=1;
						}
#endif
					} else if(cr=='\0') {
						if(addr_first < flash_end) {
							*part_begin_addr=offset_addr;
							sprintf(mtd_dev,"/dev/mtd/%d",mtd);
							return 0;
						}
					}
					break;
				default:
					break;
			}
		}
	}

	return 1;
}

/* kamal: newly added functions to support the new method find_mtd in 5.1 :
 * ENDS*/

unsigned long find_mtd(unsigned long addr_first,char *mtd_dev)
{
//	char strPartName[16];
	char part_name[16];
	unsigned long part_addr=0;
//	unsigned long part_begin_addr[MAX_PARTITION];
//	int nPartNo,i;


	/* kamal: new method introduced in 5.1  */
//	printf("kamal: find_mtd addr_first=0x%08lx\n",addr_first);

 	if(get_partName(addr_first,part_name,&part_addr, mtd_dev)!=0){
		printf("Unable to find the partion name\n");
		return 0;
	}

//	printf("kamal: part_name %s\n",part_name);
//	sleep(1);

	return part_addr;

	/*kamal: new method ends  */

	/*
	nPartNo = strtoul((char *)getenv("total_part"),NULL,10);
	if(nPartNo <= 0 || nPartNo >= MAX_PARTITION){
		ifx_debug_printf("Total no. of current partitions [%d] is out of limit (0,%d)\n",MAX_PARTITION);
		return 0;
	}

	for(i = 0; i < nPartNo; i++){
		memset(strPartName,0x00,sizeof(strPartName));
		sprintf(strPartName,"part%d_begin",i);
		part_begin_addr[i] = strtoul((char *)getenv(strPartName),NULL,16);
	}
	part_begin_addr[i] = strtoul((char *)getenv("flash_end"),NULL,16) + 1;

	for(i = 0; i < nPartNo; i++){
		if(addr_first >= part_begin_addr[i] && addr_first < part_begin_addr[i+1])
		{
			sprintf(mtd_dev,"/dev/mtd/%d",i);
			return (part_begin_addr[i]);	
		}
	}
	return 0;
	*/
}
