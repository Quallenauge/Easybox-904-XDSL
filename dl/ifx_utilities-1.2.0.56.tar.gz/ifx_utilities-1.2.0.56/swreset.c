#include <stdio.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <ifx_config.h>
#include <string.h>
#include "ifx_types.h"
#include <common.h>

#ifdef IFX_MULTILIB_UTIL
#define	main	swreset_main
#endif

extern int32 ifx_mapi_trigger_wps_pbc (uint32);

void wall(char*);

void wall(char* msg)
{
    int fd,flags,i;
        FILE* fp = NULL;
        char path[4][20];
    strcpy(path[0],"/dev/ttyS0");  //serial console
        strcpy(path[1],"/dev/pts/0");  // telnet session 1
        strcpy(path[2],"/dev/pts/1");  // telnet session 2
        strcpy(path[3],"/dev/ttyS1");  //serial console
        i = 4;
        while(i) {
                i--;
		flags = O_WRONLY|O_NDELAY|O_NOCTTY;
		if ((fd = open(path[i], flags)) >= 0) {
			if (isatty(fd) && (fp = fdopen(fd, "w")) != NULL) {
				fputs(msg, fp);
				fflush(fp);
			}
			if (fd >= 0) close(fd);
			if (fp != NULL) fclose(fp);
		}
        }
        return;
}

//int main()
int main (int argc, char *argv[])
{       
           fd_set rfds;
           struct timeval tv;
           int retval;
           int fd;
           char buf[10];
          
           fd = open("/dev/pb",O_RDONLY|O_NONBLOCK);
 
           while(1)
	   { 
               tv.tv_sec = 1;
               tv.tv_usec = 0;
               FD_ZERO(&rfds);
               FD_SET(fd, &rfds);

               retval = select(fd+1, &rfds, NULL, NULL, NULL);

               if (FD_ISSET(fd,&rfds))
               {
                   read(fd,buf,10);
                   retval = atoi(buf);
		   printf("the value is %d.%d seconds\n",retval/10,retval%10);

                  if ((retval/10) < 5)
                  {
                      /* Normal Reset */
                      //wall("Normal Reset...\n");
                      printf("Normal Reset...\n");
                      system("/etc/rc.d/rebootcpe.sh 5");
                      sleep(1000);
                  }
                  else if(((retval/10) >= 5) &&((retval/10) < 10))
                  {
#ifdef CONFIG_FEATURE_IFX_WIRELESS
                      /* WPS */
                      //wall("WPS...\n");
                      printf("WPS...\n");
#ifdef CONFIG_FEATURE_IFX_WLAN_WPS
                      ifx_mapi_trigger_wps_pbc(1);
#endif
#else
                      /* Normal Reset */
                      //wall("Normal Reset...\n");
                      printf("Normal Reset...\n");
                      system("/etc/rc.d/rebootcpe.sh 5");
                      sleep(1000);
#endif
                  }
                  else
                  {
                      /* Factory Default */

                      //wall("Factory Default Reset...\n");
                      printf("Factory Default Reset...\n");
                      system("/usr/sbin/upgrade /etc/rc.conf.gz sysconfig 0 0");
#ifdef CONFIG_FEATURE_IFX_VOIP
                      system("/usr/sbin/upgrade /etc/voip.conf.gz voip 0 0");
#endif
                      system("/etc/rc.d/rebootcpe.sh 5");
                      sleep(1000);
                  }
               }
           }                                                                     
           close(fd);
           return 0;
}
