#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <fcntl.h>   /* open */
#include <unistd.h> /* close */
#include <errno.h>
#include <ctype.h>

#include <ifx_types.h>
#include <ifx_ethsw.h>

#include <ifx_ethsw_api.h>

#ifdef IFX_MULTILIB_UTIL
#define main	qos_rate_update_main 
#endif

typedef enum ifx_mapi_qos_interface_type {
        IFX_MAPI_QoS_LAN_ALL = 0,  /*!<  All interface in LAN side (TR-098 data model) */
        IFX_MAPI_QoS_LAN_ETH = 1,  /*!<  Ethernet LAN interface */
        IFX_MAPI_QoS_LAN_USB = 2,  /*!<  USB LAN Interface */
        IFX_MAPI_QoS_LAN_WIFI = 3, /*!<  WIFI LAN Interface */
        IFX_MAPI_QoS_WAN_ALL = 4,  /*!<  All Interface in WAN (TR-098 data model) */
        IFX_MAPI_QoS_WAN_IP = 5,   /*!<  WAN IP  */
        IFX_MAPI_QoS_WAN_PPP = 6,  /*!<  WAN PPP */
        IFX_MAPI_QoS_LOCAL = 7,    /*!<  Local Interface */
        IFX_MAPI_QoS_SPECIFIC = 8, /*!<  Specific Interface */
        IFX_MAPI_QoS_WAN_ATM = 9,  /*!<  ATM wan interface */
        IFX_MAPI_QoS_WAN_PTM = 10,  /*!<  PTM wan interface */
        IFX_MAPI_QoS_WAN_ETH_0 = 11,  /*!< Eth wan mii0 interface */
        IFX_MAPI_QoS_WAN_ETH_1 = 12,  /*!< Eth wan mii1 interface */
        IFX_MAPI_QoS_ALL = 13,       /*!<  All Interface */
        IFX_MAPI_QoS_LAN_SPECIFIC = 14 /*!< Specific LAN interface */
} IFX_MAPI_QoS_Interface_Type;

IFX_MAPI_QoS_Interface_Type ifx_mapi_get_active_qos_iface();

int main (int argc, char *argv[])
{
	char command[256];
	int port_rate = 0;
	static int switch_fd = 0;
	void* ioctl_params = NULL;
	union ifx_sw_param x;
	int retval;
	static char switch_dev[256]="";

	IFX_MAPI_QoS_Interface_Type ifType = IFX_MAPI_QoS_ALL;
	ifType = ifx_mapi_get_active_qos_iface();

	if (ifType == IFX_MAPI_QoS_WAN_ETH_0)
	{
#ifdef PLATFORM_AR9
		sprintf(switch_dev,"/dev/switch_api/1");
#endif
#if defined(PLATFORM_AR9) && defined(CONFIG_PACKAGE_KMOD_LTQCPE_GW188_SUPPORT)
		sprintf(switch_dev,"/dev/switch_api/1");
#endif
		
#ifdef PLATFORM_DANUBE
		sprintf(switch_dev,"/dev/switch_api/1");
#endif
#ifdef PLATFORM_VR9
		sprintf(switch_dev,"/dev/switch_api/0");
#endif
#ifdef PLATFORM_AMAZON_SE
		sprintf(switch_dev,"/dev/switch_api/1");
#endif
	} 
	else if (ifType == IFX_MAPI_QoS_WAN_ETH_1)
	{
#ifdef PLATFORM_AR9
		sprintf(switch_dev,"/dev/switch_api/0");
#endif
#if defined(PLATFORM_AR9) && defined(CONFIG_PACKAGE_KMOD_LTQCPE_GW188_SUPPORT)
		sprintf(switch_dev,"/dev/switch_api/0");
#endif
#ifdef PLATFORM_DANUBE
		sprintf(switch_dev,"/dev/switch_api/1");
#endif
#ifdef PLATFORM_VR9
		sprintf(switch_dev,"/dev/switch_api/0");
#endif
#ifdef PLATFORM_AMAZON_SE
		sprintf(switch_dev,"/dev/switch_api/1");
#endif
	}
	else
	{
//      		printf("qos_rate_update util not required. exiting\n");
		return 0;
	}

   while(1)
   {
	

	if((switch_fd=open(switch_dev, O_RDONLY))==-1)
   	{
      		printf("Error opening char device %s\n", switch_dev);
      		return -1; 
   	}

        memset(&x.portlinkcfgGet, 0x00, sizeof(x.portlinkcfgGet));
	if (ifType == IFX_MAPI_QoS_WAN_ETH_0)
	{
#ifdef PLATFORM_AR9
        	x.portlinkcfgGet.nPortId = 4;
#endif
//fix for  issue:UGW_SW1514
#if defined(PLATFORM_AR9) && defined(CONFIG_PACKAGE_KMOD_LTQCPE_GW188_SUPPORT)
                x.portlinkcfgGet.nPortId = 3;
#endif
#ifdef PLATFORM_DANUBE
        	x.portlinkcfgGet.nPortId = 4;
#endif
#ifdef PLATFORM_VR9
        	x.portlinkcfgGet.nPortId = 4; //VR9 Does not have MII0 Mode. Will never come here
#endif
#ifdef PLATFORM_AMAZON_SE
        	x.portlinkcfgGet.nPortId = 4; //TBD: Check once MII0 mode is supported
#endif
	}
	if (ifType == IFX_MAPI_QoS_WAN_ETH_1)
	{
#ifdef PLATFORM_AR9
        	x.portlinkcfgGet.nPortId = 1;
#endif
#if defined(PLATFORM_AR9) && defined(CONFIG_PACKAGE_KMOD_LTQCPE_GW188_SUPPORT)
        	x.portlinkcfgGet.nPortId = 1;
#endif
#ifdef PLATFORM_DANUBE
        	x.portlinkcfgGet.nPortId = 4; //DANUBE Does not have MII1 Mode. Will never come here
#endif
#ifdef PLATFORM_VR9
        	x.portlinkcfgGet.nPortId = 5;
#endif
#ifdef PLATFORM_AMAZON_SE
        	x.portlinkcfgGet.nPortId = 4; //TBD: Check once MII0 mode is supported
#endif
	}
        ioctl_params = (void *)&x.portlinkcfgGet;

   	retval=ioctl( switch_fd, IFX_ETHSW_PORT_LINK_CFG_GET, ioctl_params );
	
        if(retval != 0)
   	{
      		printf("qos_rate_update.c: IOCTL failed \n");
      		//return -1;
    	}

        if (port_rate != x.portlinkcfgGet.eSpeed)
        {
            port_rate = x.portlinkcfgGet.eSpeed;
//        	printf("qos_rate_update.c -> eSpeed is [%d]\n", x.portlinkcfgGet.eSpeed);
            sprintf(command,"/etc/rc.d/ipqos_rate_update %d %d", port_rate * 1000, port_rate * 1000);
            system(command);
        }
        close(switch_fd);
	sleep(10);
	//return 0;
   }

}
/*
static int switch_fd = 0;
#ifdef AR9
static char switch_dev[]="/dev/switch_api/1";
#endif

#ifdef DANUBE
static char switch_dev[]="/dev/switch_api/1";
#endif

#ifdef AMAZON_SE
static char switch_dev[]="/dev/switch_api/1";
#endif

#ifdef VR9
static char switch_dev[]="/dev/switch_api/0";
#endif
*/

