
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <fcntl.h>
#include <unistd.h>


#ifdef IFX_DEBUG
#define	ifx_debug_printf(format, args...) printf(format, ##args)
#else
#define	ifx_debug_printf(format, args...)
#endif
