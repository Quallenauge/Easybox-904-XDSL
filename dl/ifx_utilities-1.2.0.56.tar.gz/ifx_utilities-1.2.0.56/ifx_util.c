// 511091:leejack 2005/11/09 add bringup_wan bringup_oam bringup_pppoe bringup_pppoa
// 601111:leejack 2000/01/11 add bringup_dns_relay

/* ============================================================================
 * Copyright (C) 2005 -Infineon Technologies AG.
 *
 * All rights reserved.
 * ============================================================================
 *
 *============================================================================
 *
 * This document contains proprietary information belonging to Infineon 
 * Technologies AG. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 * 
 * ============================================================================
 */

 
/* ===========================================================================
 *
 * File Name:   ifx_util.c
 * Author :     Nirav Salot
 * Date: 		14th January, 2005
 *
 * ===========================================================================
 *
 * Project: Amazon
 *
 * ===========================================================================
 * Contents: This is the main for IFX utility multi-binary. It supports
 *           several misc small utilities.
 *  
 * ===========================================================================
 * References: 
 *
 */


/* ===========================================================================
 * Revision History:
 *
 * $Log$
 * ===========================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <ifx_config.h>
#include<string.h>
struct ifx_util_cmd
{
	char *cmd_name;
	int (*cmd_func)(int argc,char *argv[]);
};


int swreset_main(int argc,char *argv[]);
//int next_macaddr_main(int argc,char *argv[]);
//int status_oper_main(int argc,char *argv[]);
//int upgrade_main(int argc,char *argv[]);
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
int get_atmqos_name_main(int argc,char *argv[]);
int check_dsl_main(int argc,char *argv[]);
int get_adsl_rate_main(int argc,char *argv[]);
extern int adslinfo_main(int argc,char *argv[]);
#endif
//int mknod_util_main(int argc,char *argv[]);
int read_img_main(int argc,char *argv[]);
int uboot_env_main(int argc,char *argv[]);
#if defined(CONFIG_FEATURE_FIREWALL) || defined(CONFIG_FEATURE_NAPT)
int naptcfg_main(int argc,char *argv[]);
#endif
#if defined(CONFIG_FEATURE_IFX_IPQOS)
int queuecfg_main(int argc, char *argv[]);
int qos_rate_update_main(int argc, char *argv[]);
#endif
#ifdef CONFIG_FEATURE_IFX_ADM6996_UTILITY
int adm6996_main(int argc,char *argv[]);
/* 509021:linmars int vlan_main(int argc,char *argv[]); */
#endif 
#ifdef CONFIG_FEATURE_IFX_VOIP
int voip_relay_main(int argc,char *argv[]);
//int flash_timer_main(int argc,char *argv[]); // 000060:jelly:8/25
#endif
#ifdef CONFIG_FEATURE_IFX_DEBUG
int mem_main(int argc, char *argv[]);
int nohup_main(int argc, char *argv[]);
#endif

//int usb_util_main(int argc, char *argv[]);    // 707311:leon
extern int get_if_index_main(int argc, char *argv[]);
extern int ifx_event_util_main(int argc, char *argv[]);
extern int route_util_main(int argc, char *argv[]);

//20-July-2010: pmcu is added as a separate package and this is no more compiled from ifx_utilities
//#ifdef CONFIG_FEATURE_IFX_PMCU_DEMO
//extern int pmcu_main(int argc, char *argv[]);
//#endif

struct ifx_util_cmd ifx_commands[] = 	{ 
//	{"swreset",swreset_main}, //165200:henryhsu 2006-05-04
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
	{"get_atmqos_name",get_atmqos_name_main},
#endif
//#ifdef CONFIG_FEATURE_IFX_PMCU_DEMO
//	{"pmcu", pmcu_main},
//#endif
	//{"next_macaddr",next_macaddr_main},
	//{"status_oper",status_oper_main},
//	{"upgrade",upgrade_main},
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
//#else
//	{"check_dsl",check_dsl_main},
	{"get_adsl_rate",get_adsl_rate_main},
#endif
	//{"mknod_util",mknod_util_main},
	{"read_img",read_img_main},
	{"uboot_env", uboot_env_main},
#ifdef CONFIG_FEATURE_IFX_DEBUG
	{"mem", mem_main},
	{"nohup", nohup_main},
#endif
#ifdef CONFIG_FEATURE_IFX_ADM6996_UTILITY
	{"adm6996",adm6996_main},
/*509021:linmars	{"vlan",vlan_main}, */
#endif
#if defined(CONFIG_FEATURE_FIREWALL) || defined(CONFIG_FEATURE_NAPT)
	{"naptcfg",naptcfg_main},
#endif
#if defined(CONFIG_FEATURE_IFX_IPQOS)
        {"queuecfg",queuecfg_main},
        {"qos_rate_update",qos_rate_update_main},
#endif
#ifdef CONFIG_FEATURE_IFX_VOIP
//	{"voip_relay",voip_relay_main},
//	{"flash_timer",flash_timer_main}, // 000060:jelly:8/25 
#endif
//	{"usb_util", usb_util_main},             // 707311:leon
	{"get_if_index", get_if_index_main},	// 508302:linmars
#ifdef CONFIG_PACKAGE_IFX_DEVM
	{"ifx_event_util", ifx_event_util_main}, // 705177:Pramod
#endif
	{"route_util", route_util_main},
#ifdef CONFIG_PACKAGE_IFX_DSL_CPE_API
	{"adslinfo", adslinfo_main}
#endif
};


int main(int argc,char *argv[])
{
	int i;
	char *strcmd = argv[0];
	char *pTemp = NULL;
	
	while((pTemp = strchr(strcmd,'/')))
	{
		strcmd = pTemp + 1;
	}

	for(i = 0; i < sizeof(ifx_commands) / sizeof(struct ifx_util_cmd); i++)
	{
		if(strcmp(ifx_commands[i].cmd_name,strcmd) == 0)
	{
			return ((ifx_commands[i].cmd_func)(argc,argv));
	}
	}

	printf("ifx_util : can not find utility %s\n",strcmd);
	return 1;
}
