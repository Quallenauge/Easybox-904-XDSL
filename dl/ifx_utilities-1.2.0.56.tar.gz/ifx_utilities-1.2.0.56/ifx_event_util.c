// #705175:Pramod start

#include <stdio.h>
#include <stdlib.h>
#include "ifx_event.h"
#include<strings.h>
#ifdef IFX_MULTILIB_UTIL 
#define main	ifx_event_util_main
#endif

typedef struct _val_set {
		char8 *name;
		int32 value;
} ifx_val_set;

/* define different event types and correpsonding enum value */
ifx_val_set evt_type_set[] = {
		{"LAN_INTERFACE", EVT_TYPE_LAN_INTERFACE},
		{"WAN_INTERFACE", EVT_TYPE_WAN_INTERFACE},
		{"LAN_IPADDRESS", EVT_TYPE_LAN_IPADDRESS},
		{"WAN_IPADDRESS", EVT_TYPE_WAN_IPADDRESS},
		{"ROUTE", EVT_TYPE_ROUTE},
		{"LAN_PHY", EVT_TYPE_LAN_PHY},
		{"WAN_PHY", EVT_TYPE_WAN_PHY},
		{"ADSL_LINK", EVT_TYPE_ADSL_LINK_STATUS},
		{"WLAN_STATUS", EVT_TYPE_WLAN_STATUS},
		{"DEFAULT_WAN", EVT_TYPE_DEFAULT_WAN}
};

// #define EVT_TYPE_ARRAY_SIZE 8
#define EVT_TYPE_ARRAY_SIZE (sizeof(evt_type_set) / sizeof(ifx_val_set))

/* define different event states and correpsonding enum value */
ifx_val_set evt_state_set[] = {
		{"UP", EVT_STATE_UP},
		{"DOWN", EVT_STATE_DOWN},
		{"MOD", EVT_STATE_MOD},
		{"ADD", EVT_STATE_ADD},
		{"DEL", EVT_STATE_DEL},
		{"ENA", EVT_STATE_ENA},
		{"DIS", EVT_STATE_DIS},
		{"ERR", EVT_STATE_ERR},
		{"START", EVT_STATE_START},
		{"STOP", EVT_STATE_STOP},
		{"COMPLETE", EVT_STATE_COMPLETE}
};

// #define EVT_STATE_ARRAY_SIZE 8
#define EVT_STATE_ARRAY_SIZE (sizeof(evt_state_set) / sizeof(ifx_val_set))

/* This functions takes name of event type and returns enum defined for it */
static int32 event_name_to_val(const char8 *evt, uint8 isEvtType)
{
	int32 arSize, i;
	ifx_val_set *ar;

	if (isEvtType) {
		arSize = EVT_TYPE_ARRAY_SIZE;
		ar = evt_type_set;
	}
	else {
		arSize = EVT_STATE_ARRAY_SIZE;
		ar = evt_state_set;
	}

	for (i = 0; i < arSize; i++) {
		/* case sensitive compare */	
		if (!strcasecmp(evt, ar[i].name)) 
			return ar[i].value;
	}

	return -1;
}


int32 main(int32 argc, char8 *argv[])
{
		int32 evtType, evtState;
		int32 count = 0, i = 0;
		char8 *optional1, *optional2;
		char8 cmd_args[10][50];

		optional1 = optional2 = NULL;

		/* first get the event type and event state
			then check on the number of arguments based on event type */
		if ((evtType = event_name_to_val(argv[1], TRUE)) == -1) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("Invalid Event Type : %s\n",argv[1]);
#endif
				return 1;
		}

		if ((evtState = event_name_to_val(argv[2], FALSE)) == -1) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("Invalid Event State : %s\n",argv[2]);
#endif
				return 1;
		}

//706123 start - in case of adsl link event call ifx_event_handler with null arguments except event type and state
		if(evtType == EVT_TYPE_ADSL_LINK_STATUS || evtType == EVT_TYPE_WLAN_STATUS) { /* ADSL_UP / ADSL_DOWN */
			if (argc < 3) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("Usage : ifx_evt_util event_type event_state NVP-String(optional) Logging-String(optional)\n");
#endif
				return 1;
			}

			/* call event handler function which will process the input data
				and call respective event handlers of mgmt. interfaces */
			ifx_event_handler(evtType, evtState, NULL, argc - 3, NULL);
		}
//706123 start - in case of default wan event call ifx_event_handler with null arguments except event type and state
		else if(evtType == EVT_TYPE_DEFAULT_WAN) { /* DEFAULT_WAN*/
			if (argc < 3) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("Usage : ifx_evt_util event_type event_state NVP-String(optional) Logging-String(optional)\n");
#endif
				return 1;
			}

			/* call event handler function which will process the input data
				and call respective event handlers of mgmt. interfaces */
			ifx_event_handler(evtType, evtState, NULL, argc - 3, NULL);
		}
		else if(evtType == EVT_TYPE_WAN_INTERFACE || evtType == EVT_TYPE_WAN_IPADDRESS) { /* WAN_IPADDRESS, WAN_INTERFACE */
			if (argc < 4) {
#ifdef IFX_LOG_DEBUG
				IFX_DBG("Usage : ifx_evt_util event_type event_state event_object NVP-String(optional) Logging-String(optional)\n");
#endif
				return 1;
			}

			count = argc - 4;

			while(count>0) {
					sprintf(cmd_args[i], "%s", argv[4+i]);
					i++;
					count--;
			}

			/* call event handler function which will process the input data
				and call respective event handlers of mgmt. interfaces */
			ifx_event_handler(evtType, evtState, argv[3], argc - 4, (void *)cmd_args);
		}
//706123 end

		return 0;
} 

// #705175:Pramod end
