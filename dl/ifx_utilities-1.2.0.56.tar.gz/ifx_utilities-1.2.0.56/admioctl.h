//joelin
#include <linux/ioctl.h>

/* type definitions */
typedef unsigned char U8;
typedef unsigned short U16;
typedef unsigned int U32;

typedef struct _REGRW_
{
  unsigned int addr;
  unsigned int value;
  unsigned int mode;
}REGRW, *PREGRW;

//joelin adm6996i
typedef struct _MACENTRY_
{
	unsigned char mac_addr[6];
	unsigned long fid:4;
            unsigned long portmap:6;
	union  {
		unsigned long age_timer:9;
		unsigned long info_ctrl:9;
	} ctrl;
	unsigned long occupy:1;
	unsigned long info_type:1;
	unsigned long bad:1;
	unsigned long result:3;//000:command ok ,001:all entry used,010:Entry Not found  ,011:try next entry ,101:command error
	
 }MACENTRY, *PMACENTRY;
typedef struct _PROTOCOLFILTER_
{
	int protocol_filter_num;//[0~7]
	int ip_p; //Value Compared with Protocol in IP Heade[7:0]
	char action:2;//Action for protocol Filter .
//00 = Protocol Portmap is Default Output Ports.
//01 = Protocol Portmap is 6'b0.
//10 = Protocol Portmap is the CPU port if the incoming port 
//is not the CPU port. But if the incoming port is the CPU port, then Type Portmap contains Default Output Ports, excluding the CPU port.
 }PROTOCOLFILTER, *PPROTOCOLFILTER;

//joelin adm6996i
typedef struct _IGMPMACENTRY_
{
	unsigned char mac_addr[3];
    unsigned int  portmap:6;
	unsigned int  occupy;
	unsigned int  index;
	
 }IGMPMACENTRY, *PIGMPMACENTRY;





/* IOCTL keys */
#define KEY_IOCTL_ADM_REGRW		0x01
#define KEY_IOCTL_ADM_SW_REGRW		0x02
#define KEY_IOCTL_ADM_SW_PORTSTS	0x03
#define KEY_IOCTL_ADM_SW_INIT		0x04

//for adm6996i-start
#define	KEY_IOCTL_ADM_SW_IOCTL_MACENTRY_ADD		0x05
#define	KEY_IOCTL_ADM_SW_IOCTL_MACENTRY_DEL		0x06
#define	KEY_IOCTL_ADM_SW_IOCTL_MACENTRY_GET_INIT	0x07
#define	KEY_IOCTL_ADM_SW_IOCTL_MACENTRY_GET_MORE	0x08
#define	KEY_IOCTL_ADM_SW_IOCTL_FILTER_ADD		0x09
#define	KEY_IOCTL_ADM_SW_IOCTL_FILTER_DEL		0x0a
#define	KEY_IOCTL_ADM_SW_IOCTL_FILTER_GET		0x0b
#define	KEY_IOCTL_ADM_SW_IOCTL_IGMP_ADD		0x0c
#define	KEY_IOCTL_ADM_SW_IOCTL_IGMP_DEL		0x0d
 
//adm6996i #define KEY_IOCTL_MAX_KEY       0x05
#define KEY_IOCTL_MAX_KEY       0x0c
 

/* IOCTL MAGIC */
static const unsigned char ADM_MAGIC = 'a'|'d'|'m'|'t'|'e'|'k';

/* IOCTL parameters */
#define ADM_IOCTL_REGRW			_IOWR(ADM_MAGIC, KEY_IOCTL_ADM_REGRW, REGRW)
#define ADM_SW_IOCTL_REGRW		_IOWR(ADM_MAGIC, KEY_IOCTL_ADM_SW_REGRW, REGRW)
#define ADM_SW_IOCTL_PORTSTS		_IOWR(ADM_MAGIC, KEY_IOCTL_ADM_SW_PORTSTS, NULL)
#define ADM_SW_IOCTL_INIT		_IOWR(ADM_MAGIC, KEY_IOCTL_ADM_SW_INIT, NULL)

//6996i-stat
#define ADM_SW_IOCTL_MACENTRY_ADD	    _IOWR(ADM_MAGIC, KEY_IOCTL_ADM_SW_IOCTL_MACENTRY_ADD,MACENTRY)
#define ADM_SW_IOCTL_MACENTRY_DEL	    _IOWR(ADM_MAGIC, KEY_IOCTL_ADM_SW_IOCTL_MACENTRY_DEL,MACENTRY)
#define ADM_SW_IOCTL_MACENTRY_GET_INIT      _IOWR(ADM_MAGIC, KEY_IOCTL_ADM_SW_IOCTL_MACENTRY_GET_INIT,MACENTRY)
#define ADM_SW_IOCTL_MACENTRY_GET_MORE      _IOWR(ADM_MAGIC, KEY_IOCTL_ADM_SW_IOCTL_MACENTRY_GET_MORE,MACENTRY)
#define ADM_SW_IOCTL_FILTER_ADD	    	    _IOWR(ADM_MAGIC, KEY_IOCTL_ADM_SW_IOCTL_FILTER_ADD,PROTOCOLFILTER)	
#define ADM_SW_IOCTL_FILTER_DEL	            _IOWR(ADM_MAGIC, KEY_IOCTL_ADM_SW_IOCTL_FILTER_DEL,PROTOCOLFILTER)
#define ADM_SW_IOCTL_FILTER_GET	            _IOWR(ADM_MAGIC, KEY_IOCTL_ADM_SW_IOCTL_FILTER_GET,PROTOCOLFILTER)	
 
#define ADM_SW_IOCTL_IGMP_ADD	            _IOWR(ADM_MAGIC, KEY_IOCTL_ADM_SW_IOCTL_IGMP_ADD,IGMPMACENTRY)	
#define ADM_SW_IOCTL_IGMP_DEL	            _IOWR(ADM_MAGIC, KEY_IOCTL_ADM_SW_IOCTL_IGMP_DEL,IGMPMACENTRY)	
//6996i-end

#define REG_READ	0x0
#define REG_WRITE	0x1
