#include <stdio.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include "multicase_upgrade.h"

static int process_message(int listen_socket);
void ifx_multicase_upgrade(void *host_addr);
//void upgrading_daemon(cyg_addrword_t data);

static	int		listen_socket;
static  int     	listen_port;
int 			batch_upgrading_thread_stop;

static unsigned int g_rcvd_img_len=0;
static unsigned int g_img_file_len=0;
static unsigned int g_seq_no=0;
static unsigned int times_of_rcvd=0;


/****************************************************************************
			thread sleep. 
****************************************************************************/
int msleep(unsigned long milisec)
{
    struct timespec req={0},rem={0};
    time_t sec=(int)(milisec/1000);
    milisec=milisec-(sec*1000);
    req.tv_sec=sec;
    req.tv_nsec=milisec*1000000L;
    nanosleep(&req,&rem);
    return 1;
}




/*****************************************************************************
		 		open_connection 
******************************************************************************/
int     open_connection(int port,char *host_addr)
{

	int                     socketDescriptor;

	int error;
	
	struct sockaddr_in      mySocketAddress;
     	struct ip_mreq 		mreq;


	if ( !listen_port ) 
	{
		MUPG_DBG("The specified port is '0'\n");
		return -1;
	}

	
	socketDescriptor = socket(AF_INET, SOCK_DGRAM, 0);
	MUPG_DBG("socket returned %d ",socketDescriptor);
	if (socketDescriptor < 0)
	{
		printf ("error calling \"socket()\"\n.");
		return -1;
	}


	mySocketAddress.sin_family = AF_INET;
	mySocketAddress.sin_addr.s_addr = inet_addr(MCASTGRP);

	if (sizeof (mySocketAddress.sin_port) == 2) 
	{
		*(short *)&mySocketAddress.sin_port = htons((short) port);
	} 
	else if (sizeof (mySocketAddress.sin_port) == 4) 
	{
		*(long *)&mySocketAddress.sin_port = htonl(port);
	} 
	else 
	{
		return -1;
	}

	error=bind(socketDescriptor, (struct sockaddr *)&mySocketAddress, sizeof(mySocketAddress));

	perror("bind");
	
	if (error)
	{
		printf ("error calling \"bind()\"\n.");
		return -1;
	}

	memset(&mreq,0, sizeof(mreq));
	perror("memset");
	
     	mreq.imr_multiaddr.s_addr=inet_addr(MCASTGRP);
	mreq.imr_interface.s_addr=inet_addr(host_addr);

	MUPG_DBG("Multiaddr= %08x\n",mreq.imr_multiaddr.s_addr);
	MUPG_DBG("Interfaceaddr= %08x\n",mreq.imr_interface.s_addr);

	error=setsockopt(socketDescriptor, IPPROTO_IP, IP_ADD_MEMBERSHIP, &mreq, sizeof(mreq));

	if (error < 0) 
	{
		perror("setsockopt");
		close(socketDescriptor);
	  	return -1;	
	}
	return (socketDescriptor);
}


void Free_Memory(void)
{

pthread_detach(pthread_self());
system("killall -9 rc.bringup_wan");
system("killall -9 swreset"); 
system("killall -9 dnrd");
system("killall -9 syslogd");
system("killall -9 atmarpd"); 
system("killall -9 devm");
system("killall -9 devmapp");
system("killall -9 dsl_cpe_control;sleep 1");
system("killall -9 br2684ctld;sleep 1");
system("killall -9 autosearch_main;sleep 1");
system("rm -rf /ramdisk/flash /ramdisk/var /ramdisk/tmp/* /ramdisk/etc/dnrd");
system("rm -rf /ramdisk/etc/hosts /ramdisk/etc/inetd.conf ramdisk/etc/resolv.conf /ramdisk/etc/udhcpd.conf");		
system("/bin/mknod /dev/free_dma_dev c 235 0;sleep 1");
system("/sbin/insmod free_dma.o;sleep 1;");
system("/usr/sbin/free_dma 2");
pthread_exit(0);
}




/*****************************************************************************
		void ifx_multicase_upgrade(cyg_addrword_t data)
******************************************************************************/

void ifx_multicase_upgrade(void *host_addr)
{
     	int 			ret = APP_FALSE;
		
	MUPG_DBG("host_addr=%s\n",(char *)host_addr);

	listen_port = (int)LISTEN_PORT;
        listen_socket = open_connection(listen_port,host_addr);
	if(listen_socket == -1)
	{
		MUPG_DBG("Error in opening socket with port %d ",listen_port);	
		pthread_exit(0);
	}
	else	
		MUPG_DBG("Successfully opened UDP socket(%d) with port %d ", listen_socket, listen_port);	

        /* Listen to the network */
		
        while(1) 
	{
                                               
		ret = process_message(listen_socket);

		if(ret != APP_FALSE)		/*all packets have been received properly */
		{
			close(listen_socket);

			if(g_rcvd_img_len>=g_img_file_len)
			{

			batch_upgrading_thread_stop=1;

			/*Start firmware upgrade*/
			system("/etc/rc.d/invoke_upgrade.sh /ramdisk/upgrade_image fullimage 0 1 reboot");

			break;
			}
			else
			{
			MUPG_DBG("image successfully received (size = %d bytes)", ret);	
			ret=APP_FALSE;
			}

			if(ret == APP_FALSE)
			{
				listen_socket = open_connection(listen_port,host_addr);
				if(listen_socket == -1)
				{
					MUPG_DBG("Error in opening socket with port %d ",listen_port);	
					pthread_exit(0);
				}
				else
					MUPG_DBG("Successfully opened UDP socket(%d) with port %d ", listen_socket, listen_port);
				
			}
		}
		else				/*Some error has occured 		*/
		{
			MUPG_DBG("Error in receiving image ");	
		}

        }

                if (batch_upgrading_thread_stop)
                {
                        if(listen_socket)
                        {
                                close(listen_socket);
                                listen_socket = 0;
                        }
                        pthread_exit(0);
                }

}
               
        
/*****************************************************************************
		static 	int 	process_message(int listen_socket)
******************************************************************************/
static 	int 	process_message(int listen_socket)
{
	int     		count;
	int     		timeout_count = 0;
	int     		rcvd_img_len  = 0;
	int     		size_to_copy  = 0;
	//int     		avail_buffer  = 0;
	//int     		memory_needed = APP_TRUE;
	int			seq_no = 0;
	int     		bytes 	 = 0;
	int     		from_len = 0;
	unsigned int		img_crc  = 0;
	//unsigned int		wrong_img_crc  = 0;
        int     		numfds;
        //int     		ret = APP_FALSE;
        fd_set  		fdset;
        struct 	timeval 	timeout;
       // chain_buf 		*ch_buf  = NULL;
       // chain_buf 		*tail_buf;
        //chain_buf 		*tmp_buf;
	static	pkt_format	*img_data_pkt;	
	struct	sockaddr_in 	MUT_server;
	int			partition_desc_pkt_rcvd_flag = 0; /* Default is not rcvd */ /* 0:No Rcvd , 1 Rcvd*/
	
        int fd = 0;
	int write_flag;

	pthread_t free_memory;
	

		
	img_data_pkt 		= (pkt_format *)malloc(sizeof(pkt_format));
	
	if(!img_data_pkt)
	{
		msleep(500);	
		return APP_FALSE;
	}
	
	while(1)
	{
		numfds = 0;
		FD_ZERO(&fdset);
		numfds = listen_socket + 1;
		FD_SET(listen_socket, &fdset);

		timeout.tv_sec = CON_TIME_OUT;
		timeout.tv_usec = 0;
		count = select(numfds, &fdset, 0, 0, &timeout);

		if (count > 0) 
		{				/*some data has been received 	*/
			if (FD_ISSET(listen_socket, &fdset)) 
			{
				bytes = recvfrom(listen_socket, img_data_pkt, sizeof(pkt_format), 0,
						(struct sockaddr *)&MUT_server,
						&from_len);
				MUPG_DBG("%d BYTES received",bytes);

				if(bytes <= 0)
				{

					MUPG_DBG("returning.. ");
					goto err_out;
				}

				if(partition_desc_pkt_rcvd_flag == 0) /*1st pkt , partition description pkt */ 
				{
					if(times_of_rcvd > 0)
					{

						if(img_data_pkt->id == PARTITION_DESC_PKT_ID)
						{
						//TODO more checks on part. desc. pkt

							printf("Start to recive file for upgrade......\n");

#ifndef x86
							seq_no  = cpu_to_le32(img_data_pkt->pkt_seq);
#else
							seq_no  = img_data_pkt->pkt_seq; //for x86
#endif			
							img_crc = img_data_pkt->img_crc;

							if(seq_no != 0)
							{
								MUPG_DBG("seq_no wrong, wait for next cycle!!");
								continue;	
							}
							partition_desc_pkt_rcvd_flag = 1;	
							SHOW_PKT(img_data_pkt);
							//display(img_data_pkt->pkt_data.img_data-2,MAX_IMAGE_DATA);
						}
				    	}
					else
					{
						if(img_data_pkt->id == PARTITION_DESC_PKT_ID)
						{
							printf("Multicase upgrade start to prepare environment...........\n");
							times_of_rcvd++;

                					/*******Open a file to store rcvd packet****************/
#ifndef x86
                					fd=creat(UPGRADE_IMG,S_IRWXU);
#else
                					fd=creat("UPGRADE_IMG",S_IRWXU);
#endif
                					if(fd== -1)
                        				{
                                				printf("cannot open file\n");
                                				return APP_FALSE;
                        				}
#ifndef x86
							/******Create a thread for free memory*****************/
							pthread_create( &free_memory, NULL,(void*)&Free_Memory, NULL);
							
							/**************************************************/
#endif	
						}
						continue;
					}

				}	
				else if (partition_desc_pkt_rcvd_flag == 1)
				{


					SHOW_PKT(img_data_pkt);

#ifndef x86
					MUPG_DBG("seq_no = %d",cpu_to_le32(img_data_pkt->pkt_seq));
					g_seq_no=cpu_to_le32(img_data_pkt->pkt_seq);
#else
					MUPG_DBG("seq_no = %d",img_data_pkt->pkt_seq);
					g_seq_no=img_data_pkt->pkt_seq;
#endif

								/*check the seq no.*/

#ifndef x86
					if(cpu_to_le32(img_data_pkt->pkt_seq) != (seq_no + 1))
#else
					if(img_data_pkt->pkt_seq != (seq_no + 1))
#endif
					{
						partition_desc_pkt_rcvd_flag=0;

						/*outof order pkt */
						printf("waiting for seq_no = %d \n", (seq_no + 1));
						partition_desc_pkt_rcvd_flag=0;
						continue;
					}

					seq_no = seq_no + 1;	/* update the local seq. no. */


					
					/***************************************/
					/*	Write received packet to a file*/	
					/***************************************/

					size_to_copy = bytes - 62;//offsetof(pkt_format, pkt_data);

		
					rcvd_img_len += size_to_copy;
				
					MUPG_DBG("rcvd img size = %d ",rcvd_img_len);

#ifndef x86
					g_rcvd_img_len=rcvd_img_len;
					g_img_file_len=cpu_to_le32(img_data_pkt->img_file_len);
#else
					g_rcvd_img_len=rcvd_img_len;
					g_img_file_len=img_data_pkt->img_file_len;
#endif


#ifndef x86
					if(rcvd_img_len >= cpu_to_le32(img_data_pkt->img_file_len))
#else
					if(rcvd_img_len >= img_data_pkt->img_file_len)
#endif
					{
					

#ifndef x86	
       			                 write_flag=write(fd,img_data_pkt->pkt_data.img_data-2,\
						img_data_pkt->pkt_len-(rcvd_img_len-cpu_to_le32(img_data_pkt->img_file_len)));
					 printf("Seq_no=%d\n",cpu_to_le32(img_data_pkt->pkt_seq));
#else
                                         write_flag=write(fd,img_data_pkt->pkt_data.img_data-2,\
                                                img_data_pkt->pkt_len-(rcvd_img_len-img_data_pkt->img_file_len));
					 printf("Seq_no=%d\n",img_data_pkt->pkt_seq);
#endif

						
						SHOW_PKT(img_data_pkt);
						printf("image received completely.. \n");
						free(img_data_pkt);
						close(fd);
						printf("Image file prepared\n");
						return APP_TRUE;
					}
					else
					{
                                        	write_flag=write(fd,img_data_pkt->pkt_data.img_data-2,img_data_pkt->pkt_len);
                                        	if(write_flag!=img_data_pkt->pkt_len)
                                        	{
                                                	perror("write:");
                                                	printf("write packet to file error!!\n");
                                                	partition_desc_pkt_rcvd_flag=0;
                                                	close(fd);
                                                	system("rm -rf /tmp/upgrade_image");
                                                	continue;
						}
                                        }


				}/*image data processing end */
				
			}/*end of if(FD_ISSET()) */
			else	/* socket not readable 	*/
			{
				free(img_data_pkt);
				MUPG_DBG("returning.. ");
				return APP_FALSE;
			}	
			timeout_count = 0;
		}
		else /* select timed out */	
		{
			timeout_count  ++;
			if(timeout_count == MAX_WAIT_CNT(WAIT_TIME_MIN))
			{
				MUPG_DBG("returning select timed out for %d times",MAX_WAIT_CNT(WAIT_TIME_MIN));	
				goto err_out;
			}
		}  /*end of if (count > 0 )*/
	}	/*while(1) loop */	
err_out:
	free(img_data_pkt);
	return APP_FALSE;
}

/*****************************************************************************
                        int bat_up_start()
******************************************************************************/

int main(int argc,char **argv)
{
//pthread_t thread;

//pthread_create( &thread, NULL,
//(void*)&ifx_multicase_upgrade, (void*)argv[1]);

ifx_multicase_upgrade((void*)argv[1]);

//while(1);

//exit(0);

return 0;
}













