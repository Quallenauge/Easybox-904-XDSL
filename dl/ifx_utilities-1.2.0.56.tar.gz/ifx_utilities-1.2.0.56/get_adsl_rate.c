/* ============================================================================
 * Copyright (C) 2004 - Infineon Technologies.
 *
 * All rights reserved.
 * ============================================================================
 *
 * ============================================================================
 *
 * This document contains proprietary information belonging to Infineon
 * Technologies. Passing on and copying of this document, and communication
 * of its contents is not permitted without prior written authorisation.
 *
 * ============================================================================
 * Author: Lin Mars (mars.lin@infineon.com)
 */
/*
000002:tc.chen 2005/06/10 using get_adsl_rate api to get adsl rate
*/
#include <stdio.h>
#include <stdlib.h>

#ifdef IFX_MULTILIB_UTIL 
#define main	get_adsl_rate_main
#endif

extern int adsl_get_rate(int,unsigned long *,unsigned long *);

#if 0 //000002:tc.chen remove start
static int adsl_run_command(char *cmd, char *retbuf)
{
	FILE	*fd = NULL;

	if ((fd=popen(cmd, "r")) == NULL)
	{
		system("rm -f /tmp/ifx_f0");
		system("rm -f /tmp/ifx_f1");
		return -1;
	}
	fgets(retbuf, 1024, fd);
	pclose(fd);
	return 0;
}

static int adsl_get_link_mode(void)
{
	char	cmd[] = "cmvread stat 12 0 1";
	int		fd = -1;
	char	buf[1024];
	char	*ptr = buf;

	if (adsl_run_command(cmd, ptr) < 0)
			return -1;
	
	return (atoi(buf) & 0x03);
}

static int adsl_get_data_rate(int type)
{
	int mode = adsl_get_link_mode();
	int fd = -1;
	char *cmd[8] = {
		"cmvread rate 0 0 1",
		"cmvread rate 0 1 1",
		"cmvread rate 0 2 1",
		"cmvread rate 0 3 1",
		"cmvread rate 1 0 1",
		"cmvread rate 1 1 1",
		"cmvread rate 1 2 1",
		"cmvread rate 1 3 1"
	};
	char *cmd1 = NULL, *cmd2 = NULL;
	char buf[1024];
	char *ptr = buf;
	long lsw = 0, msw = 0;
	
	if (mode == 1)	/* interleave */
	{
		if (type == 0)
		{
			cmd1 = cmd[0];
			cmd2 = cmd[1];
		}
		else
		{
			cmd1 = cmd[4];
			cmd2 = cmd[5];
		}
	}
	else if (mode == 2)	/* fast */
	{
		if (type == 0)
		{
			cmd1 = cmd[2];
			cmd2 = cmd[3];
		}
		else
		{
			cmd1 = cmd[6];
			cmd2 = cmd[7];
		}
	}
	else
		goto err_exit;

	memset(buf, 0x00, 1024);
	if (adsl_run_command(cmd1, ptr) < 0)
		goto err_exit;
	lsw = atoi(buf);
	memset(buf, 0x00, 1024);
	if (adsl_run_command(cmd2, ptr) < 0)
		goto err_exit;
	msw = atoi(buf);
	lsw=(msw*65536+lsw)/1000;   			
	return lsw;

err_exit:
	return 0;
}

int main (int argc, char *argv[])
{
	int id = -1;
	int ret = 0;
	if (argc > 1)
	{
		id = atoi(argv[1]);
		if (id == 0)
			ret = adsl_get_data_rate(0);
		else
			ret = adsl_get_data_rate(1);
	}
	printf("%d", ret);
	return 0;
}
#endif //000002:tc.chen remove end
// 000002:tc.chen start
int main (int argc, char *argv[])
{
	unsigned long rate = 0;
	unsigned long rate_remainder;
	int id = -1,ret = -1;
	if (argc > 1)
	{
		id = atoi(argv[1]);
		ret=adsl_get_rate(id,&rate,&rate_remainder);
	}
	if (ret>=0)
		printf("%ld",rate);
	else
		printf("0");
	return 0;
}
// 000002:tc.chen end
