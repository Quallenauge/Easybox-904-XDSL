/******************************************************************************
     Copyright (c) 2004, Infineon Technologies.  All rights reserved.

                               No Warranty
   Because the program is licensed free of charge, there is no warranty for
   the program, to the extent permitted by applicable law.  Except when
   otherwise stated in writing the copyright holders and/or other parties
   provide the program "as is" without warranty of any kind, either
   expressed or implied, including, but not limited to, the implied
   warranties of merchantability and fitness for a particular purpose. The
   entire risk as to the quality and performance of the program is with
   you.  should the program prove defective, you assume the cost of all
   necessary servicing, repair or correction.

   In no event unless required by applicable law or agreed to in writing
   will any copyright holder, or any other party who may modify and/or
   redistribute the program as permitted above, be liable to you for
   damages, including any general, special, incidental or consequential
   damages arising out of the use or inability to use the program
   (including but not limited to loss of data or data being rendered
   inaccurate or losses sustained by you or third parties or a failure of
   the program to operate with any other programs), even if such holder or
   other party has been advised of the possibility of such damages.
 ******************************************************************************
   Module      : admctl.c
   Date        : 2004-09-01
   Description : JoeLin
   Remarks:

 *****************************************************************************/
/* 509203:linmars move 6996 API to IFX common library */
#include <ifx_config.h>

#ifdef CONFIG_FEATURE_IFX_ADM6996_UTILITY

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
//#include <fcntl.h>
#include <sys/file.h>
#include <sys/ioctl.h>
#include <string.h>
//#include <malloc.h>
/* 509203:linmars start */
#include <ifx_common.h>
#include "common.h"
#include "admioctl.h"
/* 509203:linmars end */

#ifdef IFX_MULTILIB_UTIL
#define	main	adm6996_main
#endif

#define IGMP_TABLE_ADD    1 
#define IGMP_TABLE_DEL    2 

void Usage(char *prog)
{
    printf("*****************************************************************\n");
    printf("Usage: \n");
    printf("\n\t%s <r|w> <address> [value] \n", prog);
    printf("\tr|w: read, or write adm5120 registers\n");
    printf("\taddress: address offset of that register (HEX)\n");
    printf("\tvalue: value of the register if in write mode (HEX)\n");
    printf("\n\t%s <rsw|wsw> <address> [value] \n", prog);
    printf("\trsw|wsw: read, or write adm6996 registers\n");
    printf("\taddress: address offset of that register (HEX)\n");
    printf("\tvalue: value of the register if in write mode (HEX)\n");
    printf("\n\t%s <swinit> \n", prog);
    printf("\tInit adm6996 states \n");
    printf("\n\t%s <swsts> \n", prog);
    printf("\tReport adm6996 status \n");
    
    printf("\n\t%s <FILTER_ADD/filter_add> <protocol_filter_num> <action> <ip_p> \n", prog);
    printf("\n\t%s <FILTER_DEL/filter_del> <protocol_filter_num>   \n", prog);    
    printf("\n\t%s <FILTER_GET/filter_get> <protocol_filter_num>   \n", prog);    
   
    printf("\n\t%s <macentry_add>  \n", prog);
    printf("\n\t%s <macentry_del>    \n", prog);    
    printf("\n\t%s <macentry_get_init> \n", prog);       
    printf("\n\t%s <macentry_get_more> \n", prog); 
    printf("\n\t%s <dump_reg> \n", prog); 
    printf("\n\t%s <dump_igmp_table> \n", prog); 
    printf("\n\t%s <igmp_table_add> \n", prog); 
    printf("\n\t%s <igmp_table_del> \n", prog); 
    printf("*****************************************************************\n");
}

/* 509203:linmars start */
#if 0
void RWReg(int rwmode, int addr, int *value, int fd)
{
  PREGRW uREGRW;
  
  uREGRW = (PREGRW)malloc(sizeof(REGRW));
  	
  uREGRW->addr = addr;
  uREGRW->mode = rwmode;
  if (rwmode) /* write */
  {
     uREGRW->value = *value;
	  
     if( ioctl(fd, ADM_IOCTL_REGRW, uREGRW) )
     {
       printf("IOCTL write ERROR!\n");
       return;
     }
	
  }else 	/* read */
  {
     if( ioctl(fd, ADM_IOCTL_REGRW, uREGRW) )
     {
       printf("ioctl error\n");
       return;
     }
	  
     *value = uREGRW->value;
  }

  free(uREGRW);
}


void RWSWReg(int rwmode, int addr, int *value, int fd)
{
  PREGRW uREGRW;
  
  uREGRW = (PREGRW)malloc(sizeof(REGRW));
  	
  uREGRW->addr = addr;
  uREGRW->mode = rwmode;
  if (rwmode) /* write */
  {
     uREGRW->value = *value;
	  
     if( ioctl(fd, ADM_SW_IOCTL_REGRW, uREGRW) )
     {
       printf("IOCTL write ERROR!\n");
       return;
     }
	
  }else 	/* read */
  {
     if( ioctl(fd, ADM_SW_IOCTL_REGRW, uREGRW) )
     {
       printf("ioctl error\n");
       return;
     }
	  
     *value = uREGRW->value;
  }


  free(uREGRW);
	
}
#endif

void ADM6996_RWReg(int rwmode, int addr, int *value, int fd)
{
  PREGRW uREGRW;
  
  uREGRW = (PREGRW)malloc(sizeof(REGRW));
  	
  uREGRW->addr = addr;
  uREGRW->mode = rwmode;
  if (rwmode) /* write */
  {
     uREGRW->value = *value;
	  
     if( ioctl(fd, ADM_IOCTL_REGRW, uREGRW) )
     {
       printf("IOCTL write ERROR!\n");
       return;
     }
	
  }else 	/* read */
  {
     if( ioctl(fd, ADM_IOCTL_REGRW, uREGRW) )
     {
       printf("ioctl error\n");
       return;
     }
	  
     *value = uREGRW->value;
  }

  free(uREGRW);
}

void ADM6996_RWSWReg(int rwmode, int addr, int *value, int fd)
{
  PREGRW uREGRW;
  
  uREGRW = (PREGRW)malloc(sizeof(REGRW));
  	
  uREGRW->addr = addr;
  uREGRW->mode = rwmode;
  if (rwmode) /* write */
  {
     uREGRW->value = *value;
	  
     if( ioctl(fd, ADM_SW_IOCTL_REGRW, uREGRW) )
     {
       printf("IOCTL write ERROR!\n");
       return;
     }
	
  }else 	/* read */
  {
     if( ioctl(fd, ADM_SW_IOCTL_REGRW, uREGRW) )
     {
       printf("ioctl error\n");
       return;
     }
	  
     *value = uREGRW->value;
  }


  free(uREGRW);
	
}



/* 509203:linmars end */
unsigned char conv_x(char *str)
{
   char a[3]={0};

   a[0] = str[0];
   a[1] = str[1];
   a[2] = '\0';
   //printf("a = [%s][%x:%x]\n", a, a[0], a[1]);
   //printf("a = %x[%d]\n", strtoul(a, NULL, 16), strtoul(a, NULL, 16));
   return (strtoul(a, NULL, 16));
}

int check_busy_bit(int fd, int addr)
{
	int  rwmode = 0, value = 0x800;
	while (value & 0x8000)
	{
		printf ("still busy....");
		ADM6996_RWSWReg(rwmode, addr, &value, fd);
	}
	return 0;
}

int dump_adm6996_registers (int fd)
{
	int index = 0x0, rwmode = 0;
	int value = 0x0, addr = 0x0;
	  
	for (index = 0x0; index < 0xff; index++)
	{
		ADM6996_RWSWReg(rwmode, addr, &value, fd);
		printf("(READ) addr: %.4x, value: %.4x\n", addr, value);
		addr++;
	}	
	return 0;
}

int dump_igmp_table(int fd)
{
	int index = 0, portmap = 0x0;
	int pos = 0x0, val = 0, addr = 0;

	for (index = 0; index < 32; index++)
	{
		check_busy_bit(fd, 0x125);
		ADM6996_RWSWReg(1, 0x11e, &pos, fd); // 0-32 entries
		pos++;
		val = 0x0050;
		ADM6996_RWSWReg(1, 0x11f, &val, fd); // [6:4] = 101
		check_busy_bit(fd, 0x125);

		addr = 0x125;
		val = 0;
		ADM6996_RWSWReg(0, addr, &val, fd); // 
	  	printf("[%d]:[%.4x]",index, val);
		addr = 0x124;
		ADM6996_RWSWReg(0, addr, &val, fd); // 
	  	printf("[%.4x]",val);
		addr = 0x123;
		ADM6996_RWSWReg(0, addr, &val, fd); // 
	  	printf("[%.4x]",val);
		addr = 0x122;
		ADM6996_RWSWReg(0, addr, &val, fd); // 
	  	printf("[%.4x]",val);
		addr = 0x121;
		ADM6996_RWSWReg(0, addr, &val, fd); // 
	  	printf("[%.4x]",val);
		portmap = ((val & 0x1f80) >> 7); 
		addr = 0x120;
		val = 0;
		ADM6996_RWSWReg(0, addr, &val, fd); // 
	  	printf("[%.4x],portmap:",val);
		if (portmap & 0x20) // CPU port
		   printf ("5");
		else 
		   printf ("-");
		if (portmap & 0x08) // 
		   printf ("3");
		else 
		   printf ("-");
		if (portmap & 0x04) // 
		   printf ("2");
		else 
		   printf ("-");
		if (portmap & 0x02) // 
		   printf ("1");
		else 
		   printf ("-");
		if (portmap & 0x01) // 
		   printf ("0");
		else 
		   printf ("-");

		printf ("\n");
	}
	return 0;
}

int handle_igmp_table (unsigned int cmd, int fd)
{
	IGMPMACENTRY *mMacEntry;
	int value = 0x0;
	
	mMacEntry = (IGMPMACENTRY *) malloc (sizeof(IGMPMACENTRY));	
	printf ("mac[0] =>");
	scanf ("%x", &value);
	mMacEntry->mac_addr[0] = value;

	printf ("mac[1] =>");
	scanf ("%x", &value);
	mMacEntry->mac_addr[1] = value;

	printf ("mac[2] =>");
	scanf ("%x", &value);
	mMacEntry->mac_addr[2] = value;

	printf ("portmap =>");
	scanf ("%x", &value);
	mMacEntry->portmap = (value & 0x3f);

	printf ("occupy =>");
	scanf ("%x", &value);
	mMacEntry->occupy = value;

	printf ("index =>");
	scanf ("%d", &value);
	mMacEntry->index = value;

	if (cmd == IGMP_TABLE_ADD)
    		ioctl(fd, ADM_SW_IOCTL_IGMP_ADD, mMacEntry);
	else if (cmd == IGMP_TABLE_DEL)
    		ioctl(fd, ADM_SW_IOCTL_IGMP_DEL, mMacEntry);
	else
	{
		printf ("[%s]:[%d]-Undefined cmd\n", __FUNCTION__, __LINE__);
	}
	
	return 0;
}


int main(int argc, char* argv[])
{
	int fd;
	int rwmode, addr, value = 0;
	char *endptr; 

	if (argc < 2)
	{
	  Usage(argv[0]);
	  exit(1);
	}
	fd = open("/dev/adm6996", O_RDWR, 0);
	
//joelin for 6996i
	    unsigned int val;		//6996i
	    //unsigned int control[6] ;	//6996i
	    //unsigned int status[6] ;	//6996i
	if ((strstr(argv[1], "FILTER_ADD") != NULL)||(strstr(argv[1], "filter_add") != NULL))
	{	
	if (argc<=4) { printf("\n adm6996 <FILTER_ADD> <protocol_filter_num> <action> <ip_p> \n");goto myexit;}
 
    	PPROTOCOLFILTER uPROTOCOLFILTER ;///adm6996i	
	uPROTOCOLFILTER = (PPROTOCOLFILTER ) malloc(sizeof(PPROTOCOLFILTER));
    	uPROTOCOLFILTER->ip_p=strtoul(argv[3], &endptr, 16);;	//delet filter
	uPROTOCOLFILTER->action=strtoul(argv[4], &endptr, 16);;	//delete filter
	uPROTOCOLFILTER->protocol_filter_num=strtoul(argv[2], &endptr, 16);;
	val=(uPROTOCOLFILTER->action)&0x03;
	printf("(ADM_SW_IOCTL_FILTER_ADD) protocol_filter_num: %.4x, ip_p: %.4x ,action: %.4x\n",(uPROTOCOLFILTER->protocol_filter_num),uPROTOCOLFILTER->ip_p,val);
	ioctl(fd, ADM_SW_IOCTL_FILTER_ADD, uPROTOCOLFILTER);
	goto myexit;
	}
	if ((strstr(argv[1], "FILTER_DEL") != NULL)||(strstr(argv[1], "filter_del") != NULL))
	{	

	if (argc<=2)   {  printf("\n <FILTER_DEL> <protocol_filter_num>   \n");   goto myexit;}     
    	PPROTOCOLFILTER uPROTOCOLFILTER ;///adm6996i	
	uPROTOCOLFILTER = (PPROTOCOLFILTER ) malloc(sizeof(PPROTOCOLFILTER));

	uPROTOCOLFILTER->protocol_filter_num=strtoul(argv[2], &endptr, 16);;
	printf("(ADM_SW_IOCTL_FILTER_DEL) protocol_filter_num: %.4x\n",(uPROTOCOLFILTER->protocol_filter_num) );
	ioctl(fd, ADM_SW_IOCTL_FILTER_DEL, uPROTOCOLFILTER);
	goto myexit;
	}	
	if ((strstr(argv[1], "FILTER_GET") != NULL)||(strstr(argv[1], "filter_get") != NULL))
	{	

        if (argc<=2)    { printf("\n <FILTER_GET> <protocol_filter_num>   \n");        goto myexit;}
    	PPROTOCOLFILTER uPROTOCOLFILTER ;///adm6996i	
	uPROTOCOLFILTER = (PPROTOCOLFILTER ) malloc(sizeof(PPROTOCOLFILTER));

	uPROTOCOLFILTER->protocol_filter_num=strtoul(argv[2], &endptr, 16);;
 
	ioctl(fd, ADM_SW_IOCTL_FILTER_GET, uPROTOCOLFILTER);
	val=(uPROTOCOLFILTER->action)&0x03;

	printf("(ADM_SW_IOCTL_FILTER_GET) protocol_filter_num: %.4x, ip_p: %.4x ,action: %.4x\n",(uPROTOCOLFILTER->protocol_filter_num),uPROTOCOLFILTER->ip_p,val);
	
	goto myexit;
	}		

//MACENTRY_ADD
	if ((strstr(argv[1], "MACENTRY_ADD") != NULL)||(strstr(argv[1], "macentry_add") != NULL))
	{	
//	if (argc<=9) { printf("\n adm6996 <macentry_add> <mac_addr1(ad5:ad4:ad3)> <mac_addr2(ad2:ad1:ad0)><fid> <portmap> <info_ctrl/age_timer> <occupy> <info_type><bad>\n");goto myexit;}
 
 	int value_1; 
    	PMACENTRY mMACENTRY;//adm6996i
	mMACENTRY = (PMACENTRY )malloc(sizeof(PMACENTRY));

  
  	printf ("mac_addr0 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[0]=value;
	
  	printf ("mac_addr1 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[1]=value;
	
	  	printf ("mac_addr2 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[2]=value;
	
	  	printf ("mac_addr3 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[3]=value;
	
	  	printf ("mac_addr4 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[4]=value;
  	
  	printf ("mac_addr5 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[5]=value;
	  
 	printf ("mMACENTRY->fid ===>");
	scanf("%x", &value);
    	mMACENTRY->fid=((value)&0x0f);;	
    	
 	printf ("mMACENTRY->portmap ===>");
	scanf("%x", &value);
       	mMACENTRY->portmap=(value)&0x3f;;
      
// 	printf ("mMACENTRY->occupy ===>");
//	scanf("%x", &value);    	  
  //   	mMACENTRY->occupy=(value)&0x1;;

 	printf ("mMACENTRY->info_type ===>");
	scanf("%x", &value);
    	mMACENTRY->info_type=(value)&0x1;;
    	
    	if (mMACENTRY->info_type) {
  		printf ("mMACENTRY->ctrl.info_ctrl ===>");
	scanf("%x", &value);
    		
    		value_1=((mMACENTRY->ctrl.info_ctrl)=(value)&0x1ff);
      
		}
    		else {
  		printf ("mMACENTRY->ctrl.age_timer ===>");
	scanf("%x", &value);
    		
    		value_1=((mMACENTRY->ctrl.age_timer)=(value)&0x1ff);
      
		}
 //		printf ("mMACENTRY->bad ===>");
//	scanf("%x", &value);
 //
 //   	mMACENTRY->bad=value&0x1;;
   
   ioctl(fd, ADM_SW_IOCTL_MACENTRY_ADD, mMACENTRY);
   
	printf("(MACENTRY_ADD):\n\t mac_addr[0]=%.4x\n\t mac_addr[1]=%.4x\n\t mac_addr[2]=%.4x\n\t mac_addr[3]=%.4x\n\t mac_addr[4]=%.4x\n\t mac_addr[5]=%.4x\n\t fid= %.4x \n\t portmap: %.4x\n\t info_ctrl/age_timer: %.4x\n\t info_type: %.4x\n",
	 (mMACENTRY->mac_addr[0]),
    	(mMACENTRY->mac_addr[1]),
    	(mMACENTRY->mac_addr[2]),
    	(mMACENTRY->mac_addr[3]),
    	(mMACENTRY->mac_addr[4]),
    	(mMACENTRY->mac_addr[5]),
    	(mMACENTRY->fid)&0x0f,
    	(mMACENTRY->portmap)&0x3f,
    	(value_1),
    	(mMACENTRY->info_type)&0x1);	
	
    	
    	
	if (((mMACENTRY->result)&0x07)==000) printf("command ok\n");
		else 	if (((mMACENTRY->result)&0x07)==001) printf("ALL Entry used\n");
		else 	if (((mMACENTRY->result)&0x07)==002) printf("Entry Not found\n");
		else 	if (((mMACENTRY->result)&0x07)==003) printf("Try next Entry  \n");
		else 	if (((mMACENTRY->result)&0x07)==005) printf("command error\n");
	goto myexit;
	}	

//mac delete	
	if ((strstr(argv[1], "MACENTRY_DEL") != NULL)||(strstr(argv[1], "macentry_del") != NULL))
	{	
//	if (argc<=9) { printf("\n adm6996 <macentry_add> <mac_addr1(ad5:ad4:ad3)> <mac_addr2(ad2:ad1:ad0)><fid> <portmap> <info_ctrl/age_timer> <occupy> <info_type><bad>\n");goto myexit;}
 
    	PMACENTRY mMACENTRY;//adm6996i
	mMACENTRY = (PMACENTRY )malloc(sizeof(PMACENTRY));
 
  
  
  	printf ("mac_addr0 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[0]=value;
	
  	printf ("mac_addr1 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[1]=value;
	
	  	printf ("mac_addr2 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[2]=value;
	
	  	printf ("mac_addr3 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[3]=value;
	
	  	printf ("mac_addr1 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[4]=value;
  	
  	printf ("mac_addr5 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[5]=value;
	  
	printf ("mMACENTRY->fid ===>");
	scanf("%x", &value);
    	mMACENTRY->fid=((value)&0x0f);;		  
	  
 
   
	printf("(MACENTRY_DEL):\n\t mac_addr[0]=%.4x\n\t mac_addr[1]=%.4x\n\t mac_addr[2]=%.4x\n\t mac_addr[3]=%.4x\n\t mac_addr[4]=%.4x\n\t mac_addr[5]=%.4x\n\t fid=%.4x\n",
	 (mMACENTRY->mac_addr[0]),
    	(mMACENTRY->mac_addr[1]),
    	(mMACENTRY->mac_addr[2]),
    	(mMACENTRY->mac_addr[3]),
    	(mMACENTRY->mac_addr[4]),
    	(mMACENTRY->mac_addr[5]),
    	(mMACENTRY->fid)&0x0f
    	);
    	
    	
	ioctl(fd, ADM_SW_IOCTL_MACENTRY_DEL, mMACENTRY);
	
	if (((mMACENTRY->result)&0x07)==000) printf("command ok\n");
		else 	if (((mMACENTRY->result)&0x07)==001) printf("ALL Entry used\n");
		else 	if (((mMACENTRY->result)&0x07)==002) printf("Entry Not found\n");
		else 	if (((mMACENTRY->result)&0x07)==003) printf("Try next Entry  \n");
		else 	if (((mMACENTRY->result)&0x07)==005) printf("command error\n");
		else  printf("unknown error %x\n",((mMACENTRY->result)&0x07));

	
	
	goto myexit;
	}	
//mac serach
	if ((strstr(argv[1], "MACENTRY_GET_INIT") != NULL)||(strstr(argv[1], "macentry_get_init") != NULL))
	{	
//	if (argc<=9) { printf("\n adm6996 <macentry_add> <mac_addr1(ad5:ad4:ad3)> <mac_addr2(ad2:ad1:ad0)><fid> <portmap> <info_ctrl/age_timer> <occupy> <info_type><bad>\n");goto myexit;}
 
    	PMACENTRY mMACENTRY;//adm6996i
	mMACENTRY = (PMACENTRY )malloc(sizeof(PMACENTRY));
 
  
  int value_1;

           if (argc == 3)
	   {
        	mMACENTRY->mac_addr[0] =  (unsigned char)conv_x((&argv[2][10]));   
        	mMACENTRY->mac_addr[1] =  (unsigned char)conv_x((&argv[2][8]));   
        	mMACENTRY->mac_addr[2] =  (unsigned char)conv_x((&argv[2][6]));   
        	mMACENTRY->mac_addr[3] =  (unsigned char)conv_x((&argv[2][4]));   
        	mMACENTRY->mac_addr[4] =  (unsigned char)conv_x((&argv[2][2]));   
        	mMACENTRY->mac_addr[5] =  (unsigned char)conv_x((&argv[2][0]));   
           }
	   else
  	   {
  	printf ("mac_addr0 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[0]=value;
	
  	printf ("mac_addr1 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[1]=value;
	
	  	printf ("mac_addr2 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[2]=value;
	
	  	printf ("mac_addr3 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[3]=value;
	
	  	printf ("mac_addr1 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[4]=value;
  	
  	printf ("mac_addr5 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[5]=value;
	  
	}
    	
    	
	ioctl(fd, ADM_SW_IOCTL_MACENTRY_GET_INIT, mMACENTRY);
	
	if (((mMACENTRY->result)&0x07)==000) {
			printf("command ok\n");
		   	if (mMACENTRY->info_type)  value_1=((mMACENTRY->ctrl.info_ctrl) &0x1ff);
		  		else   	value_1=((mMACENTRY->ctrl.age_timer )&0x1ff);
		     				printf("(MACENTRY_GET_INIT):\n\t mac_addr[0]=%.4x\n\t mac_addr[1]=%.4x\n\t mac_addr[2]=%.4x\n\t mac_addr[3]=%.4x\n\t mac_addr[4]=%.4x\n\t mac_addr[5]=%.4x\n\t fid= %.4x \n\t portmap: %.4x\n\t info_ctrl/age_timer: %.4x\n\t occupy : %.4x\n\t info_type: %.4x\n\t bad: %.4x\n",
						 (mMACENTRY->mac_addr[0]),
					    	(mMACENTRY->mac_addr[1]),
					    	(mMACENTRY->mac_addr[2]),
					    	(mMACENTRY->mac_addr[3]),
					    	(mMACENTRY->mac_addr[4]),
					    	(mMACENTRY->mac_addr[5]),
					    	(mMACENTRY->fid)&0x0f,
					    	(mMACENTRY->portmap)&0x3f,
					    	(value_1),
					     	(mMACENTRY->occupy)&0x1,
					    	(mMACENTRY->info_type)&0x1, 
					    	(mMACENTRY->bad)&0x1);		
			
			
			
				}
		else 	if (((mMACENTRY->result)&0x07)==001) printf("ALL Entry used\n");
		else 	if (((mMACENTRY->result)&0x07)==002) printf("Entry Not found\n");
		else 	if (((mMACENTRY->result)&0x07)==003) printf("Try next Entry  \n");
		else 	if (((mMACENTRY->result)&0x07)==005) printf("command error\n");
	
	
	
	goto myexit;
	}	

//mac serach
	if ((strstr(argv[1], "MACENTRY_GET_MORE") != NULL)||(strstr(argv[1], "macentry_get_more") != NULL))
	{	
//	if (argc<=9) { printf("\n adm6996 <macentry_add> <mac_addr1(ad5:ad4:ad3)> <mac_addr2(ad2:ad1:ad0)><fid> <portmap> <info_ctrl/age_timer> <occupy> <info_type><bad>\n");goto myexit;}
 
    	PMACENTRY mMACENTRY;//adm6996i
	mMACENTRY = (PMACENTRY )malloc(sizeof(PMACENTRY));
 
  
  int value_1;
     if (argc == 3)
	   {
        	mMACENTRY->mac_addr[0] =  (unsigned char)(argv[2][5]);   
        	mMACENTRY->mac_addr[1] =  (unsigned char)(argv[2][4]);   
        	mMACENTRY->mac_addr[2] =  (unsigned char)(argv[2][3]);   
        	mMACENTRY->mac_addr[3] =  (unsigned char)(argv[2][2]);   
        	mMACENTRY->mac_addr[4] =  (unsigned char)(argv[2][1]);   
        	mMACENTRY->mac_addr[5] =  (unsigned char)(argv[2][0]);   
           }
	else {
  	printf ("mac_addr0 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[0]=value;
	
  	printf ("mac_addr1 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[1]=value;
	
	  	printf ("mac_addr2 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[2]=value;
	
	  	printf ("mac_addr3 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[3]=value;
	
	  	printf ("mac_addr1 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[4]=value;
  	
  	printf ("mac_addr5 ==>");
	scanf("%x", &value);
	mMACENTRY->mac_addr[5]=value;
	 } 

    	
    	
	ioctl(fd, ADM_SW_IOCTL_MACENTRY_GET_MORE, mMACENTRY);
	
	if (((mMACENTRY->result)&0x07)==000) {
			printf("command ok\n");
		   	if (mMACENTRY->info_type)  value_1=((mMACENTRY->ctrl.info_ctrl) &0x1ff);
		  		else   	value_1=((mMACENTRY->ctrl.age_timer )&0x1ff);
		     				printf("(MACENTRY_GET_MORE):\n\t mac_addr[0]=%.4x\n\t mac_addr[1]=%.4x\n\t mac_addr[2]=%.4x\n\t mac_addr[3]=%.4x\n\t mac_addr[4]=%.4x\n\t mac_addr[5]=%.4x\n\t fid= %.4x \n\t portmap: %.4x\n\t info_ctrl/age_timer: %.4x\n\t occupy : %.4x\n\t info_type: %.4x\n\t bad: %.4x\n",
						 (mMACENTRY->mac_addr[0]),
					    	(mMACENTRY->mac_addr[1]),
					    	(mMACENTRY->mac_addr[2]),
					    	(mMACENTRY->mac_addr[3]),
					    	(mMACENTRY->mac_addr[4]),
					    	(mMACENTRY->mac_addr[5]),
					    	(mMACENTRY->fid)&0x0f,
					    	(mMACENTRY->portmap)&0x3f,
					    	(value_1),
					     	(mMACENTRY->occupy)&0x1,
					    	(mMACENTRY->info_type)&0x1, 
					    	(mMACENTRY->bad)&0x1);		
			
			
			
				}
		else 	if (((mMACENTRY->result)&0x07)==001) printf("ALL Entry used\n");
		else 	if (((mMACENTRY->result)&0x07)==002) printf("Entry Not found\n");
		else 	if (((mMACENTRY->result)&0x07)==003) printf("Try next Entry  \n");
		else 	if (((mMACENTRY->result)&0x07)==005) printf("command error\n");

	
	
	
	goto myexit;
	}	
		
	if ((strstr(argv[1], "DUMP_REG") != NULL)||(strstr(argv[1], "dump_reg") != NULL))
	{	
		dump_adm6996_registers (fd);
		goto myexit;
	}
	if ((strstr(argv[1], "DUMP_IGMP_TABLE") != NULL)||(strstr(argv[1], "dump_igmp_table") != NULL))
	{	
		dump_igmp_table (fd);
		goto myexit;
	}
	if ((strstr(argv[1], "IGMP_TABLE_ADD") != NULL)||(strstr(argv[1], "igmp_table_add") != NULL))
	{	
		printf ("[%s]:[%d]\n", __FUNCTION__, __LINE__);
		handle_igmp_table (IGMP_TABLE_ADD, fd);
		printf ("[%s]:[%d]\n", __FUNCTION__, __LINE__);
		goto myexit;
	}
	if ((strstr(argv[1], "IGMP_TABLE_DEL") != NULL)||(strstr(argv[1], "igmp_table_del") != NULL))
	{	
		printf ("[%s]:[%d]\n", __FUNCTION__, __LINE__);
		handle_igmp_table (IGMP_TABLE_DEL, fd);
		printf ("[%s]:[%d]\n", __FUNCTION__, __LINE__);
		goto myexit;
	}
	
//joelin 6996i -end	
	
	if (strstr(argv[1], "rsw") != NULL)
	{
	  rwmode = 0;
	  if (!strncmp(argv[2], "0x", 2)) {
		  addr = strtoul(argv[2], &endptr, 16);
	  } else {
		  addr = strtoul(argv[2], &endptr, 10);
	  }
	  ADM6996_RWSWReg(rwmode, addr, &value, fd);
	  printf("(READ) addr: %.4x, value: %.4x\n", addr, value);
	  
	  goto myexit;
	}
	
	if (strstr(argv[1], "wsw") != NULL)
	{
	  rwmode = 1;
	  addr = strtoul(argv[2], &endptr, 16);
	  value = strtoul(argv[3], &endptr, 16);
	  printf("(WRITE) addr: %.4x, value: %.4x\n", addr, value);
	  ADM6996_RWSWReg(rwmode, addr, &value, fd);
	  
	  goto myexit;
	}
/* 509201:linmars start */
#if 0
	if (strstr(argv[1], "swsts"))
	{
      printf("test1:%x\n",fd);
	  ioctl(fd, ADM_SW_IOCTL_PORTSTS, NULL);
	  
	  goto myexit;
	}
	
	if (strstr(argv[1], "swinit"))
	{
      printf("test0:%x\n",fd);
	  ioctl(fd, ADM_SW_IOCTL_INIT, NULL);
	  
	  goto myexit;
	}
#endif
/* 509021:linmars end */	
	/* other read/write */
	if (strchr(argv[1], 'r') != NULL) rwmode = 0; else rwmode = 1;
	addr = strtoul(argv[2], &endptr, 16);
	if (rwmode == 1) value = strtoul(argv[3], &endptr, 16);
	
	printf("Mode: %d, Offset: 0x%x ", rwmode, addr);
	if (rwmode == 1) printf(",Value: %.8x\n", value); else printf("\n");
	
	ADM6996_RWReg(rwmode, addr, &value, fd);
	
	printf("Addr: %.8x, value: %.8x\n", addr, value);
	
myexit:	
	close(fd);
	return 0;
}

#endif //CONFIG_FEATURE_IFX_ADM6996_UTILITY
