#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ifx_common.h"

#ifdef IFX_MULTILIB_UTIL
#define	main	get_atmqos_name_main
#endif

int main (int argc, char *argv[])
{
	int id = -1;
	if (argc > 1)
		id = atoi(argv[1]);
	printf("%s", ifx_get_atm_qos_name_by_id(id));
	return 0;
}
