#ifdef IFX_MULTILIB_UTIL
#define main    adslinfo_main
#endif
#include <stdio.h>
#include <string.h>

#if defined(CONFIG_PACKAGE_IFX_DSL_CPE_API)
#include <sys/ioctl.h>
#include <drv_dsl_cpe_api.h>
#include <drv_dsl_cpe_api_ioctl.h>
#include <drv_dsl_cpe_api_g997.h>
#define DSL_CPE_DEVICE_NAME "/dev/dsl_cpe_api"
#include <ifx_config.h>
#include <ifx_common.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

//#include "ifx_cgi.h"
//#include "ifx_cgi_adsl_status.h"
//#endif
DSL_G997_LineInventory_t lineInventoryGet;
DSL_uint8_t FarEndSystemVendorID[DSL_G997_LI_MAXLEN_VENDOR_ID];
DSL_uint8_t FarEndVersionNumber[DSL_G997_LI_MAXLEN_VERSION];
DSL_uint8_t FarEndSerialNumber[DSL_G997_LI_MAXLEN_SERIAL];
DSL_LineState_t lineState;
DSL_G997_XTUSystemEnabling_t xtuSystemEnabling;
DSL_G997_PowerManagementStatus_t pwrMngStatus;
DSL_G997_PowerManagement_t PowerManagementStatus;
DSL_LineFeature_t lineFeatureConfig;
DSL_G997_FramingParameterStatus_t g997FramingParamStatusGet;
DSL_G997_ChannelStatus_t channelStatus;
DSL_uint32_t ActualInterleaveDelay;
DSL_uint32_t DownStreamActualDataRate;
DSL_uint32_t UpStreamActualDataRate;
DSL_G997_LineStatus_t lineStatus;
DSL_uint32_t DownStreamATTNDR;
DSL_uint32_t UpStreamATTNDR;
//DSL_uint32_t DownStreamINTLVDEPTH;
DSL_uint16_t DownStreamINTLVDEPTH;
//DSL_uint32_t UpStreamINTLVDEPTH;
DSL_uint16_t UpStreamINTLVDEPTH;
//DSL_uint32_t DownStreamLATN;
DSL_int16_t DownStreamLATN;
//DSL_uint32_t UpStreamLATN;
DSL_int16_t UpStreamLATN;
//DSL_uint32_t DownStreamSATN;
DSL_int16_t DownStreamSATN;
//DSL_uint32_t UpStreamSATN;
DSL_int16_t UpStreamSATN;
//DSL_uint32_t DownStreamSNR;
DSL_int16_t DownStreamSNR;
//DSL_uint32_t UpStreamSNR;
DSL_int16_t UpStreamSNR;
//DSL_uint32_t DownStreamACTATP;
DSL_int16_t DownStreamACTATP;
//DSL_uint32_t UpStreamACTATP;
DSL_int16_t UpStreamACTATP;
DSL_G997_LineFailures_t lineFailuresStatusGet;
DSL_G997_BF_LineFailures_t NearEndLOSFailure;
DSL_G997_BF_LineFailures_t FarEndLOSFailure;
DSL_G997_BF_LineFailures_t NearEndLOFFailure;
DSL_G997_BF_LineFailures_t FarEndLOFFailure;
DSL_G997_BF_LineFailures_t NearEndLPRFailure;
DSL_G997_BF_LineFailures_t FarEndLPRFailure;
DSL_G997_DataPathFailures_t dataPathFailuresStatusGet;
DSL_G997_BF_DataPathFailures_t NearEndNCDFailure;
DSL_G997_BF_DataPathFailures_t FarEndNCDFailure;
DSL_G997_BF_DataPathFailures_t NearEndLCDFailure;
DSL_G997_BF_DataPathFailures_t FarEndLCDFailure;
DSL_PM_ChannelCountersTotal_t pmChannelCountersTotal;
DSL_PM_ChannelCounters_t pmChannelCounters; //Eros add for use SHOWTIME counter
DSL_PM_DataPathCounters_t pmDataPathCounters; //Eros add for use SHOWTIME counter
DSL_uint32_t NearEndCRCFailure;
DSL_uint32_t FarEndCRCFailure;
DSL_uint32_t NearEndRSCorrectionFailure;
DSL_uint32_t FarEndRSCorrectionFailure;
DSL_uint32_t NearEndFECS;
DSL_uint32_t FarEndFECS;
DSL_PM_LineSecCountersTotal_t pmLineSecCountersTotal;
DSL_uint32_t NearEndES;
DSL_uint32_t FarEndES;
DSL_uint32_t NearEndSES;
DSL_uint32_t FarEndSES;
DSL_uint32_t NearEndLOSS;
DSL_uint32_t FarEndLOSS;
DSL_uint32_t NearEndUAS;
DSL_uint32_t FarEndUAS;
DSL_PM_DataPathCountersTotal_t pmDataPathCountersTotal;
DSL_uint32_t NearEndHEC;
DSL_uint32_t FarEndHEC;

DSL_IN DSL_DeltDataType_t gDeltDataType = DSL_DELT_DATA_SHOWTIME;


// Status
int ifx_get_ModemStatus()
{
  switch (lineState.data.nLineState)
  {
    case DSL_LINESTATE_NOT_INITIALIZED:
      printf("NOT INITIALIZED\n");
      break;
    case DSL_LINESTATE_EXCEPTION:
      printf("EXCEPTION\n");
      break;
    case DSL_LINESTATE_IDLE_REQUEST:
      printf("IDLE_REQUEST\n");
      break;
    case DSL_LINESTATE_IDLE:
      printf("IDLE\n");
      break;
    case DSL_LINESTATE_SILENT_REQUEST:
      printf("SILENT_REQUEST\n");
      break;
    case DSL_LINESTATE_SILENT:
      printf("SILENT\n");
      break;
    case DSL_LINESTATE_HANDSHAKE:
      printf("HANDSHAKE\n");
      break;
    case DSL_LINESTATE_FULL_INIT:
      printf("FULL_INIT\n");
      break;
    case DSL_LINESTATE_DISCOVERY:
      printf("DISCOVERY\n");
      break;
    case DSL_LINESTATE_TRAINING:
      printf("TRAINING\n");
      break;
    case DSL_LINESTATE_ANALYSIS:
      printf("ANALYSIS\n");
      break;
    case DSL_LINESTATE_EXCHANGE:
      printf("EXCHANGE\n");
      break;
    case DSL_LINESTATE_SHOWTIME_NO_SYNC:
      printf("SHOWTIME,NO SYNC\n");
      break;
    case DSL_LINESTATE_SHOWTIME_TC_SYNC:
      printf("SHOWTIME,SYNC\n");
      break;
    case DSL_LINESTATE_FASTRETRAIN:
      printf("FASTRETRAIN\n");
      break;
    case DSL_LINESTATE_LOWPOWER_L2:
      printf("LOWPOWER_L2\n");
      break;
    case DSL_LINESTATE_LOOPDIAGNOSTIC_ACTIVE:
      printf("DIAGNOSTIC ACTIVE\n");
      break;
    case DSL_LINESTATE_LOOPDIAGNOSTIC_DATA_EXCHANGE:
      printf("DIAGNOSTIC_DATA_EXCHANGE\n");
      break;
    case DSL_LINESTATE_LOOPDIAGNOSTIC_DATA_REQUEST:
      printf("DIAGNOSTIC_DATA_REQUEST\n");
      break;
    case DSL_LINESTATE_LOOPDIAGNOSTIC_COMPLETE:
      printf("DIAGNOSTIC COMPLETE\n");
      break;
    case DSL_LINESTATE_RESYNC:
      printf("RESYNC\n");
      break;
    case DSL_LINESTATE_TEST:
      printf("TEST\n");
      break;
    case DSL_LINESTATE_TEST_LOOP:
      printf("TEST_LOOP\n");
      break;
    case DSL_LINESTATE_TEST_REVERB:
      printf("TEST_REVERB\n");
      break;
    case DSL_LINESTATE_TEST_MEDLEY:
      printf("TEST_MEDLEY\n");
      break;
    case DSL_LINESTATE_TEST_SHOWTIME_LOCK:
      printf("TEST_SHOWTIME,LOCK\n");
      break;
    case DSL_LINESTATE_TEST_QUIET:
      printf("TEST_QUIET\n");
      break;
    case DSL_LINESTATE_LOWPOWER_L3:
      printf("LOWPOWER_L3\n");
      break;
    case DSL_LINESTATE_UNKNOWN:
      printf("UNKNOWN\n");
      break;
    case DSL_LINESTATE_NOT_UPDATED:
      printf("NOT_UPDATED\n");
	  break;
    case DSL_LINESTATE_SHORT_INIT_ENTRY:
	  break;
	default:
	  break;
  }				// switch     
  return 0;
}

int ifx_get_ModeSelected()
{
  // XTSE[1]
  if (xtuSystemEnabling.data.XTSE[0] & 0x01)
  {
    printf("ANSI T1.413\n");
  }

  if (xtuSystemEnabling.data.XTSE[0] & 0x02)
  {
    printf("Annex C\n");
  }

  if (xtuSystemEnabling.data.XTSE[0] & 0x04)
  {
    printf("G992_1_A\n");
  }

  if (xtuSystemEnabling.data.XTSE[0] & 0x10)
  {
    printf("G992_1_B\n");
  }
  // XTSE[2]
  if (xtuSystemEnabling.data.XTSE[1] & 0x01)
  {
    printf("G992_2_A\n");
  }
  // XTSE[3]
  if (xtuSystemEnabling.data.XTSE[2] & 0x04)
  {
    printf("G992_3_A\n");
  }

  if (xtuSystemEnabling.data.XTSE[2] & 0x10)
  {
    printf("G992_3_B\n");
  }
  // XTSE[4]
  if (xtuSystemEnabling.data.XTSE[3] & 0x01)
  {
    printf("G992_4_A\n");
  }

  if (xtuSystemEnabling.data.XTSE[3] & 0x10)
  {
    printf("G992_3_I\n");
  }

  if (xtuSystemEnabling.data.XTSE[3] & 0x40)
  {
    printf("G992_3_J\n");
  }
  // XTSE[5]
  if (xtuSystemEnabling.data.XTSE[4] & 0x04)
  {
    printf("G992_3_L\n");
  }

  if (xtuSystemEnabling.data.XTSE[4] & 0x08)
  {
    printf("G992_3_L\n");
  }

  if (xtuSystemEnabling.data.XTSE[4] & 0x40)
  {
    printf("G992_3_M\n");
  }
  // XTSE[6]
  if (xtuSystemEnabling.data.XTSE[5] & 0x01)
  {
    printf("G992_5_A\n");
  }

  if (xtuSystemEnabling.data.XTSE[5] & 0x04)
  {
    printf("G992_5_B\n");
  }

  if (xtuSystemEnabling.data.XTSE[5] & 0x40)
  {
    printf("G992_5_I\n");
  }
  // XTSE[7]
  if (xtuSystemEnabling.data.XTSE[6] & 0x01)
  {
    printf("G992_5_J\n");
  }

  if (xtuSystemEnabling.data.XTSE[6] & 0x04)
  {
    printf("G992_5_M\n");
  }
  // XTSE[8]
  if (xtuSystemEnabling.data.XTSE[7] & 0x01)
  {
    printf("G993_2_A\n");
  }

  if (xtuSystemEnabling.data.XTSE[7] & 0x02)
  {
    printf("G993_2_B\n");
  }

  if (xtuSystemEnabling.data.XTSE[7] & 0x04)
  {
    printf("G993_2_C\n");
  }

  return 0;
}


int ifx_get_TrellisCodedMod()
{
  switch (lineFeatureConfig.data.bTrellisEnable)
  {
    case DSL_TRUE:
      printf("Enable\n");
      break;
    case DSL_FALSE:
      printf("Disable\n");
      break;
  }
  return 0;
}

int ifx_get_LatencyType()
{
  if (ActualInterleaveDelay > 100)
  {
    printf("Interleave\n");
  }
  else
  {
    printf("Fast\n");
  }
  return 0;
}

// Rate
int ifx_get_DownDataRate()
{
  printf("%u kbps\t\t", DownStreamActualDataRate / 1000);
  return 0;
}

int ifx_get_UpDataRate()
{
  printf("%u kbps\n", UpStreamActualDataRate / 1000);
  return 0;
}

int ifx_get_ATTNDRds()
{
  printf("%u kbps\t\t", DownStreamATTNDR / 1000);
  return 0;
}

int ifx_get_ATTNDRus()
{
	/* Assuming Max ATTNDR as 48Mbps */
  if ((UpStreamATTNDR / 1000) <= 48)
	UpStreamATTNDR = UpStreamATTNDR * 1000; 	
  printf("%u kbps\n", UpStreamATTNDR / 1000);
  return 0;
}

char tmpstr[6];
int ifx_get_LATNds()
{
  sprintf(tmpstr, "%.1f", (float)DownStreamLATN / 10);
  printf("%s dB\t\t\t", tmpstr);
  return 0;
}

int ifx_get_LATNus()
{
  sprintf(tmpstr, "%.1f", (float)UpStreamLATN / 10);
  printf("%s dB\n", tmpstr);
  return 0;
}

int ifx_get_SATNds()
{
  sprintf(tmpstr, "%.1f", (float)DownStreamSATN / 10);
  printf("%s dB\t\t\t", tmpstr);
  return 0;
}

int ifx_get_SATNus()
{
  sprintf(tmpstr, "%.1f", (float)UpStreamSATN / 10);
  printf("%s dB\n", tmpstr);
  return 0;
}
int ifx_get_SNRMds()
{
  sprintf(tmpstr, "%.1f", (float)DownStreamSNR / 10);
  printf("%s dB\t\t\t", tmpstr);
  return 0;
}

int ifx_get_SNRMus()
{
  sprintf(tmpstr, "%.1f", (float)UpStreamSNR / 10);
  printf("%s dB\n", tmpstr);
  return 0;
}

int ifx_get_ACATPds()
{
  sprintf(tmpstr, "%.1f", (float)DownStreamACTATP / 10);
  printf("%s dB\t\t\t", tmpstr);
  return 0;
}

int ifx_get_ACATPus()
{
  sprintf(tmpstr, "%.1f", (float)UpStreamACTATP / 10);
  printf("%s dB\n", tmpstr);
  return 0;
}
#endif

int main(int argc,char *argv[]){
  int ret = 0;
  int ret1 = 0;
  int fd = 0;
  //int i;
  #if defined(CONFIG_PACKAGE_IFX_DSL_CPE_API)
  // DSL_Open
   fd = open(DSL_CPE_DEVICE_NAME, O_RDWR);
  if (fd < 0)
  {
        printf("Can not open /dev/dsl_cpe_api for reading\n");
        return 1;  //ifx_httpdWrite(wp, T("cannot open device %s"), DSL_CPE_DEVICE_NAME);
  }


  // Modem Status
  memset(&lineState, 0x00, sizeof(DSL_LineState_t));
  ret = ioctl(fd, DSL_FIO_LINE_STATE_GET, &lineState);

  // modem selected
  memset(&xtuSystemEnabling, 0x00, sizeof(DSL_G997_XTUSystemEnabling_t));
  ret = ioctl(fd, DSL_FIO_G997_XTU_SYSTEM_ENABLING_STATUS_GET,
              &xtuSystemEnabling);

  // trellis-coded modulation
  memset(&lineFeatureConfig, 0x00, sizeof(DSL_LineFeature_t));
  ret = ioctl(fd, DSL_FIO_LINE_FEATURE_STATUS_GET, &lineFeatureConfig);

  // latency type
  memset(&channelStatus, 0x00, sizeof(DSL_G997_ChannelStatus_t));
  ret = ioctl(fd, DSL_FIO_G997_CHANNEL_STATUS_GET, &channelStatus);
  ActualInterleaveDelay = channelStatus.data.ActualInterleaveDelay;

  // Data Rate
  memset(&channelStatus, 0x00, sizeof(DSL_G997_ChannelStatus_t));
  channelStatus.nDirection = DSL_DOWNSTREAM;
  ret = ioctl(fd, DSL_FIO_G997_CHANNEL_STATUS_GET, &channelStatus);
  DownStreamActualDataRate = channelStatus.data.ActualDataRate;

  memset(&channelStatus, 0x00, sizeof(DSL_G997_ChannelStatus_t));
  channelStatus.nDirection = DSL_UPSTREAM;
  ret = ioctl(fd, DSL_FIO_G997_CHANNEL_STATUS_GET, &channelStatus);
  UpStreamActualDataRate = channelStatus.data.ActualDataRate;

  // Update G997LineStatus values for downstream
  memset(&lineStatus, 0x00, sizeof(DSL_G997_LineStatus_t));
  lineStatus.nDirection = DSL_DOWNSTREAM;
  lineStatus.nDeltDataType = gDeltDataType;
  ret = ioctl(fd, DSL_FIO_G997_LINE_STATUS_GET, &lineStatus);
  // SNRds
  DownStreamSNR = lineStatus.data.SNR;

  // LATNds
  DownStreamLATN = lineStatus.data.LATN;

  // SATNds
  DownStreamSATN = lineStatus.data.SATN;

  // ACTATPds
  DownStreamACTATP = lineStatus.data.ACTATP;

  // ATTNDRds
  DownStreamATTNDR = lineStatus.data.ATTNDR;

  // Update G997LineStatus values for upstream
  memset(&lineStatus, 0x00, sizeof(DSL_G997_LineStatus_t));
  lineStatus.nDirection = DSL_UPSTREAM;
  lineStatus.nDeltDataType = gDeltDataType;
  ret = ioctl(fd, DSL_FIO_G997_LINE_STATUS_GET, &lineStatus);
  // SNRus
  UpStreamSNR = lineStatus.data.SNR;

  // LATNus
  UpStreamLATN = lineStatus.data.LATN;

  // SATNus
  UpStreamSATN = lineStatus.data.SATN;

  // ACTATPus
  UpStreamACTATP = lineStatus.data.ACTATP;

  // ATTNDRus
  UpStreamATTNDR = lineStatus.data.ATTNDR;

  // close device
  close(fd);

  //print format
  printf("\nADSL Line Status\n");
  printf("\nProvides information about ADSL line's current attributes\n");

  printf("\nStatus\n");
  printf("\nModem Status\t\t\t\t");
  ret1=ifx_get_ModemStatus();
  printf("Mode Selected\t\t\t\t");
  ret1=ifx_get_ModeSelected();
  printf("Trellis-Coded Modulation\t\t");
  ret1=ifx_get_TrellisCodedMod();
  printf("Latency Type\t\t\t\t");
  ret1=ifx_get_LatencyType();
  
  printf("\n\nRate\n");
  printf("\t\t\t\t\t\tDownstream\t\tUpstream\n");
  printf("Data Rate\t\t\t\t\t");
  ret1=ifx_get_DownDataRate();
  ret1=ifx_get_UpDataRate();
  printf("Maximum Attainable Data Rate(ATTNDR)\t\t");
  ret1=ifx_get_ATTNDRds();
  ret1=ifx_get_ATTNDRus();
  
  printf("\n\nInformation\n");
  printf("\t\t\t\t\t\tDownstream\t\tUpstream\n");
  printf("Line Attenuation(LATN)\t\t\t\t");
  ret1=ifx_get_LATNds();
  ret1=ifx_get_LATNus();
  printf("Signal Attenuation(SATN)\t\t\t");
  ret1=ifx_get_SATNds();
  ret1=ifx_get_SATNus();
  printf("Signal-to-Noise Ratio Margin(SNRM)\t\t");
  ret1=ifx_get_SNRMds();
  ret1=ifx_get_SNRMus();
  printf("Actual Aggregate Transmit Power(ACATP)\t\t");
  ret1=ifx_get_ACATPds();
  ret1=ifx_get_ACATPus();
  #endif
  return 0;
  
}

