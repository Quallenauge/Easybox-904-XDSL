/*****************************************************************************
  **   FILE NAME        : ifx_hapi.h
  **   PROJECT          : Inca IP Phone
  **   MODULES          : hapi
  **   SRC VERSION      :
  **   DATE             : 25-02-2004
  **   AUTHOR           : Narendra
  **   DESCRIPTION      : 
  **   FUNCTIONS        :
  **   COMPILER         : MIPS 4KC cross compiler
  **   REFERENCE        : DIS of hapi
  **							  INCA-IP User Manual
  **							  INCA-IP Firmware Manual
  **							  INCA-IP Programmer's Reference Manual 
  **   COPYRIGHT		: Copyright � 2004
  **							Infineon Technologies AG
  **							St. Martin Strasse 53; 81669 M�nchen, Germany
  **   Disclaimer		: Any use of this Software is subject to the conclusion of 
  **					  a respective License Agreement. Without such a License 
  **					  Agreement no rights to the Software are granted.

  **  Version Control Section  **
  **   $Author$
  **   $Date$
  **   $Revisions$
  **   $Log$       Revision history
  *****************************************************************************/
#ifndef __INCA_HAPI_H__
#define	__INCA_HAPI_H__

#define	char8	char
#define uchar8	unsigned char
#define int8	char
#define uint8	unsigned char
#define int16	short int
#define uint16	unsigned short int
#define	uint32	unsigned int
#define int32	int
#define	int64	long  long
#define	uint64	unsigned long long 
#define	ulong32	unsigned long   
#define	long32	long    

#define	bool	uchar8

#define  IFX_HAPI_DISPLAY_MAXROW	4
#define  IFX_HAPI_DISPLAY_MAXCOLUMN	20

#define  IFX_HAPI_DISPLAY_LEFT		0
#define  IFX_HAPI_DISPLAY_RIGHT		1
#define  IFX_HAPI_DISPLAY_HOME		2
#define  IFX_HAPI_DISPLAY_NEXTLINE	3
#define  IFX_HAPI_DISPLAY_ROWHOME	4
#define  IFX_HAPI_DISPLAY_PREVLINE	5

#define  IFX_HAPI_MAX_CSRC			2

#define  IFX_HAPI_CRYPTO_MAX_KEY_SIZE	(256/8)

/* Volume levels */
#define	IFX_HAPI_LEVEL1	0
#define	IFX_HAPI_LEVEL2	1
#define	IFX_HAPI_LEVEL3	2
#define	IFX_HAPI_LEVEL4	3
#define	IFX_HAPI_LEVEL5	4
#define	IFX_HAPI_LEVEL6	5
#define	IFX_HAPI_LEVEL7	6
#define	IFX_HAPI_LEVEL8	7

/* room type */
#define	IFX_HAPI_MUFFLED	0X00
#define	IFX_HAPI_NORMAL		0X01
#define	IFX_HAPI_ECHOIC		0X02

/*CODEC bit patterns*/

#define	 IFX_HAPI_G711_ALAW_CODEC	     0X01
#define	 IFX_HAPI_G711_ULAW_CODEC	     0X02
#define	 IFX_HAPI_G729_8KBPS_CODEC	     0X04
#define	 IFX_HAPI_G723_5_3KBPS_CODEC	 0X08
#define	 IFX_HAPI_G723_6_3KBPS_CODEC	 0X10
#define	 IFX_HAPI_G722_64KBPS_CODEC	     0X20
#define	 IFX_HAPI_LINEAR_256KBPS_CODEC	 0X40
#define	 IFX_HAPI_G726_16KBPS_CODEC	         0X80
#define	 IFX_HAPI_G726_24KBPS_CODEC	         0X100
#define	 IFX_HAPI_G726_32KBPS_CODEC	         0X200
#define	 IFX_HAPI_G726_40KBPS_CODEC	         0X400
typedef enum
{
	IFX_HAPI_NO_CODEC ,
	IFX_HAPI_G711_ALAW ,
	IFX_HAPI_G711_ULAW ,
	IFX_HAPI_G729_8KBPS ,
	IFX_HAPI_G723_5_3KBPS ,
	IFX_HAPI_G723_6_3KBPS ,
	IFX_HAPI_G722_64KBPS ,
	IFX_HAPI_LINEAR_256KBPS ,
	IFX_HAPI_G726_16KBPS,
	IFX_HAPI_G726_24KBPS,
	IFX_HAPI_G726_32KBPS,
	IFX_HAPI_G726_40KBPS,
	IFX_HAPI_MAX_CODEC

} e_IFX_HAPI_Codec; 

typedef enum
{
	IFX_HAPI_AFE_HEADSET_MIC,
	IFX_HAPI_AFE_HANDSET_MIC,
	IFX_HAPI_AFE_SPEAKER_PHONE_MIC
} e_IFX_HAPI_DeviceType;


typedef struct
{
#define	IFX_HAPI_LED_ETH_SPD		0X01
#define	IFX_HAPI_LED_ETH_ACT		0X02
#define	IFX_HAPI_LED_ETH_DPX		0X04
#define	IFX_HAPI_LED_ETH_STA		0X08
#define	IFX_HAPI_LED_ETH_TL			0X10

	int32	iEthPort;
	uchar8 	ucEthLEDs;

} x_IFX_HAPI_LEDEthCtrl;


typedef struct
{
	uchar8	ucMaxRow;
	uchar8	ucMaxColumn;

} x_IFX_HAPI_MaxRowColumn;


typedef struct
{
	uchar8	ucRow;
	uchar8	ucColumn;

} x_IFX_HAPI_CursorPosition, x_IFX_HAPI_DisplayGoTo;


typedef struct
{
	int32	iNumber;
	char8	*pszString;

} x_IFX_HAPI_DisplayPrint;


typedef struct
{
	uchar8	ucKey;
	uint32	uiDuration;

} x_IFX_HAPI_KeyInfo;


typedef struct
{
#define IFX_HAPI_HOOK_STATUS 0
#define IFX_HAPI_KEY_PRESSED 1

	uchar8	eEventType; 
	union
	{
		#define IFX_HAPI_ON_HOOK  0
		#define IFX_HAPI_OFF_HOOK 1

		uchar8			    ucHookStatus;
		x_IFX_HAPI_KeyInfo  xKeyInfo;
	} uxEventType;

} x_IFX_HAPI_PhoneEvent;


typedef struct
{
	uchar8	bWideBand;
	uchar8	bHighPass;
	uint16	unInterfaceGain1;
	uint16	unInterfaceGain2;

} x_IFX_HAPI_AFEConfig;


typedef struct
{

#define	IFX_HAPI_DECODER_DISABLE		0x01
#define	IFX_HAPI_INTERRUPT_MODE			0x02
#define	IFX_HAPI_SILENCE_COMPRESSION	0x04

	uchar8				ucConfigOptions;
	uchar8				ucEncoderPktTime;
	e_IFX_HAPI_Codec	eEncoder;
	uchar8              ucDynPt;

} x_IFX_HAPI_CoderConfig;


typedef struct
{
#define	IFX_HAPI_MODIFY_PTE		0x01
#define	IFX_HAPI_MODIFY_ENC		0x02

	uchar8					ucModifyOpts;
	x_IFX_HAPI_CoderConfig	xCoderConfig;

} x_IFX_HAPI_ModifyCoder;


typedef struct
{
	uchar8				bBFI;
	uchar8				bSID;
	e_IFX_HAPI_Codec	eDecoder;

} x_IFX_HAPI_DecoderStats;




typedef struct
{
   uint16	unPayloadType;   /* Voice IANA Payload Type */
   uint32 	uiTimeStamp;     /* RTP TimeStamp */
   uchar8	*pacDataBuffer;  /* Header + Payload */
   uchar8	bSID;            /* Voice + SID packet indicator */
   uchar8	ucPadding;	     /* set to 1, if padding bit is set */
   uint16 	unLength;        /* Length of Header + Payload */
} x_IFX_HAPI_VoiceData;

typedef struct
{
   uint16  	unPayloadType;   /* Dynamic IANA DTMF Payload Type */
   uint32  	uiTimeStamp;     /* RTP TimeStamp */
   uchar8 	ucDTMFDigit;     /* DTMF Digit */
   uint16 	uiDuration;      /* Total Duration of tone till now */
   uchar8   bEnd;            /* Tone End Indicator */ 
   uchar8	ucVolume;        /* Volume in dB */
   char8 	*pacDataBuffer;  	/* Event Header + Payload */
   uchar8	ucMarker; 			/* Start of new Event */
   
} x_IFX_HAPI_EventData;

typedef struct
{
#define	IFX_HAPI_VOICE_PACKET	0
#define	IFX_HAPI_EVENT_PACKET	1

	uchar8		ucReadType;
	union
	{
		x_IFX_HAPI_VoiceData	xVoiceData;
		x_IFX_HAPI_EventData	xEventData;
	} uxReadType;
} x_IFX_HAPI_ReadData;
	

typedef struct
{
	uint16	unLength;
	char8	*pacBuffer;
	uchar8	*pucIV; /* needed if encryption is enabled */
	uint16	unIVSize;

} x_IFX_HAPI_ReadRTPData;


typedef struct
{

	uchar8				ucPacketTime;
	uchar8				bCombinePacket;
	uint16				unLength;
	char8				*pszDataBuffer;
	uchar8				bSID;
	e_IFX_HAPI_Codec	eDecoder;

} x_IFX_HAPI_WriteData;


typedef struct
{
	uint16	unLength;
	uchar8	*pacRTPData;
	uchar8	*pucIV; /* needed if encryption is enabled */
	uint16	unIVSize;

} x_IFX_HAPI_WriteToJB;


typedef struct
{
	uint16	unSeqNo;
	uint32	uiSSrc;
	uchar8	ucCC; /* CSrc count */
	uint32	uiCSrc[IFX_HAPI_MAX_CSRC];
} x_IFX_HAPI_EncoderInfo;
	
typedef struct
{
#define	IFX_HAPI_CONFIG_SSRC_SN		0X01
#define	IFX_HAPI_CONFIG_CSRC		0X02

	uchar8					ucConfigType;
	x_IFX_HAPI_EncoderInfo	xEncInfo;
} x_IFX_HAPI_RtpConfig;

typedef struct
{
	uchar8	ucJBType; /* 1 - Fixed, 2 - Adaptive */
	uint16	unInitSize;
	uint16	unMinSize;
	uint16	unMaxSize;
	uint16	unScaleFactor;
} x_IFX_HAPI_JBConfig;

typedef struct
{
	uchar8	ucNumOfCodecs;
	uchar8	*pucIanaPayloadType;
} x_IFX_HAPI_JBCoderTable;

typedef struct
{
	uint32	uiVoiceTime;
	uint32	uiCngTime;
	uint16	unNetworkJitter;
	uint16	unActualPlayOutDelay;
	uint16	unMaxPlayOutDelay;
	uint16	unMinPlayOutDelay;
	uint32	uiRxPktsCount;
	uint16	unLostPktsCount;
	uint16	unInvalidPktsCount;
	uint16	unDupPktsCount;
	uint16	unLatePktsCount;
	uint16	unEarlyPktsCount;
	uint16	unResyncCount;
	uint16	unRxPktDecoder;
	uint16	unJBType;
} x_IFX_HAPI_JBStats;


typedef struct
{
	uint32	uiSsrc;
	uint16	unFractionPktsLost;
	uint32	uiCumPktsLost;
	uint32	uiExtHighestSeqNo;
	uint32	uiInterArrivalJitter;
} x_IFX_HAPI_RTCPStats;


typedef struct
{
#define	IFX_HAPI_OUT_OF_BAND		0X01
#define	IFX_HAPI_INBAND_VOICE		0X02
#define	IFX_HAPI_INBAND_EVENT		0X03
#define	IFX_HAPI_INBAND_VOICE_EVENT	0X04

	uchar8	ucInbandType; 
	uchar8	ucPayloadType; /* iana payload type */
} x_IFX_HAPI_Inband;


typedef struct
{
	uchar8	ucIndex;
	uchar8	bWideBand;
	uchar8	bSQRT;
	uchar8	ucCtrlGenerator;
	uint16	unTON;
	uint16	unTOFF;
	uint16	unT1;
	uint16	unF1;
	uint16	unG1;
	uint16	unT2;
	uint16	unF2;
	uint16	unG2;
	uint16	unT3;
	uint16	unF3;
	uint16	unG3;
	uint16	unFD;
	uint16	unGD;
	uint16	unGS;

} x_IFX_HAPI_ToneConfig;


typedef struct
{
	uint16	unFreq1;
	uint16	unFreq2;
	uchar8	ucLevel1;
	uchar8	ucLevel2;
	uchar8	ucATT1;
	uchar8	ucATT2;
} x_IFX_HAPI_DTMFParams;


typedef struct
{
	uchar8	bMode;
	uchar8	ucDTC;

} x_IFX_HAPI_DTMFMode;


typedef struct
{
	uchar8	ucFeatures;
	uchar8	ucSW;
	uchar8	ucCVERS;
	uchar8	ucChipType;

} x_IFX_HAPI_FirmwareVersion;


typedef struct
{
	uint32	*pcData;
	uint32	unLength;

} x_IFX_HAPI_FWDownLoad;


typedef struct
{
	uchar8	*pacBuffer;
	uint16	unLength;

} x_IFX_HAPI_VoiceParams;

typedef struct
{

/* algo values */
#define IFX_HAPI_CRYPTO_AES		0X00
#define	IFX_HAPI_CRYPTO_DES		0x01
#define	IFX_HAPI_CRYPTO_3DES	0x02

/* mode values */
#define	IFX_HAPI_CRYPTO_CTR		0X00
#define	IFX_HAPI_CRYPTO_OFB		0x01
#define	IFX_HAPI_CRYPTO_CFB		0X02
#define	IFX_HAPI_CRYPTO_CBC		0X03
#define	IFX_HAPI_CRYPTO_ECB		0x04

	uchar8		ucAlgo;
	uchar8		ucMode;
	uchar8		acKey[IFX_HAPI_CRYPTO_MAX_KEY_SIZE];
	uchar8		ucKeyLength; /*
							  * should be apt with the algorithm:
							  * for DES/3DES - 64 / 8
							  * for AES - 128/8 or 192/8 or 256/8 
							  */
	/* 
	 *	Feedback Size defined only for CFB and OFB operation modes 
	 *  Values (in bit(s)): 1/4/8/16/32/64/128
	 *  128 bits is only for AES and other values apply for all the
   	 *  algorithms viz. AES, DES, 3DES
   	 */
	uchar8		ucFeedbackSize; /* currently this is hardcoded in driver */

} x_IFX_HAPI_CryptoParam;

typedef struct
{
	x_IFX_HAPI_CryptoParam	xCryptoParam;
	uchar8		*pucInputData;
	uchar8		*pucOutputData;
	uint16		unDataSize;
	uchar8		*pucIV;
	uint16		unIVSize; /* 
						   * for DES/3Des - 64/8
						   * for AES - 128/8
						   */
} x_IFX_HAPI_CryptoInfo;	

///////////////////////////Speech Recognition////////////////////////
#define IFX_HAPI_SPEECH_REC_MAXREFVCTR 	20
#define IFX_HAPI_JIT_DELAY 				4
#define IFX_HAPI_SPEECH_TRAINING 		1
#define IFX_HAPI_SPEECH_RECOGNITION 	0

typedef struct 
{
	uchar8  ucWinLen;
	uchar8  ucProcessEnd;
	uchar8  ucMinLen;
	uchar8  ucMaxLen;
	uchar8  ucMinPauseBeg;
	uchar8  ucMinPauseEnd;
	uchar8  ucAddPauseBeg;
	uchar8  ucAddPauseEnd;
	uchar8  ucBnsTime;
	uchar8  ucMinEnergyDif;
}x_IFX_HAPI_SpeechRec_WordDetectionCoef;

typedef struct
{
	uchar8  ucDiffDetected;
	uchar8  ucDiff2Detected;
	uchar8  ucDiffSure;
	uchar8  ucMaxDurRed;
	uchar8  ucMaxDurInc;
} x_IFX_HAPI_SpeechRec_RecRejectCoef;

typedef struct
{
	uchar8  ucMinDiff;
	uchar8  ucMaxDiff;
	uchar8  ucThr2Best;
	uchar8  ucThrRef;
	uint16  unMaxTolScore;
	uchar8  ucMaxratioTrain;	
} x_IFX_HAPI_SpeechRec_TrainRejectCoef;

typedef struct x_Statuspkt  
{
	char  cRefNum;
	char cScore;
} x_Statuspkt  ;

typedef struct
{
	uchar8  ucChnlId;
	uchar8  ucTotRefVector;

# define IFX_HAPI_SURELY_DET 1
# define IFX_HAPI_NOT_SURELY_DET 2
# define IFX_HAPI_NOT_DET 3

	int32  iStatus;
	x_Statuspkt  ax_StatusPkt[5];
	uint32   *punvector;	
	uint32  *punAdptVector;	
} x_IFX_HAPI_SpeechRec_Recon_En;

typedef struct
{
	uchar8  ucChnlId;
	uchar8  ucRefNum;
	uchar8  ucTotRefVector;
	uint32   *punvector;
	uint32   *punReTrnVector;

# define IFX_HAPI_SURE_TRN	0
# define IFX_HAPI_CLOSE_TO_OTHER	1
# define IFX_HAPI_VERY_CLOSE_TO_OTHER	2
# define IFX_HAPI_VERYMUCH_DIFFERENT	3

	int32  iStatus;
	x_Statuspkt  ax_StatusPkt[2];
} x_IFX_HAPI_SpeechRec_ReTrain_En;



typedef struct
{
	uchar8  ucChnlId;
	uchar8  ucRefNum;
	uint32   *punvector;
} x_IFX_HAPI_SpeechRec_Train_En;

/*
typedef struct 
{
#define IFX_HAPI_SPEECH_REC_CHNL_FREE 0x00
#define IFX_HAPI_SPEECH_REC_CHNL_BUSY 0x01
#define IFX_HAPI_SPEECH_REC_CHNL_TIMEOUT 0x04
#define IFX_HAPI_SPEECH_REC_CHNL_EVENT 0x03
#define IFX_HAPI_SPEECH_REC_CHNL_INIT 0x10
#define IFX_HAPI_SPEECH_REC_MEM_INIT 0x20

	 int uiStatus;
	unsigned int *pauiRefVector;
	wait_queue_head_t  wq;
}ifx_hapi_speech_rec;
*/
///////////////////////////Speech Recognition////////////////////////


#define	HAPI_IOC_MAGIC	'H'

#define	IFX_HAPI_PHONE_INIT					_IO(HAPI_IOC_MAGIC, 0)
#define	IFX_HAPI_LED_ON						_IO(HAPI_IOC_MAGIC, 1)
#define	IFX_HAPI_LED_OFF					_IO(HAPI_IOC_MAGIC, 2)
#define	IFX_HAPI_LED_ETH_CTRL				_IO(HAPI_IOC_MAGIC, 3)

#define	IFX_HAPI_GET_PHONE_EVENT			_IO(HAPI_IOC_MAGIC, 4)
#define	IFX_HAPI_FIRMWARE_DOWNLOAD			_IO(HAPI_IOC_MAGIC, 5)

#define IFX_HAPI_SET_ROOM_TYPE				_IO(HAPI_IOC_MAGIC, 6)
#define IFX_HAPI_SET_VOLUME_LEVEL			_IO(HAPI_IOC_MAGIC, 7)

#define	IFX_HAPI_AFE_HANDSET_EN				_IO(HAPI_IOC_MAGIC, 8) 
#define	IFX_HAPI_AFE_HANDSET_DIS			_IO(HAPI_IOC_MAGIC, 9)
#define	IFX_HAPI_AFE_HEADSET_EN				_IO(HAPI_IOC_MAGIC, 10)
#define	IFX_HAPI_AFE_HEADSET_DIS			_IO(HAPI_IOC_MAGIC, 11)
#define	IFX_HAPI_AFE_SPEAKER_PHONE_EN		_IO(HAPI_IOC_MAGIC, 12)
#define	IFX_HAPI_AFE_SPEAKER_PHONE_DIS		_IO(HAPI_IOC_MAGIC, 13)
#define	IFX_HAPI_AFE_LOUDHEARING_MODE_EN	_IO(HAPI_IOC_MAGIC, 14)
#define	IFX_HAPI_AFE_LOUDHEARING_MODE_DIS	_IO(HAPI_IOC_MAGIC, 15)
#define	IFX_HAPI_AFE_MICROPHONE_EN			_IO(HAPI_IOC_MAGIC, 16)
#define	IFX_HAPI_AFE_MICROPHONE_DIS			_IO(HAPI_IOC_MAGIC, 17)

#define	IFX_HAPI_PLAY_TONE					_IO(HAPI_IOC_MAGIC, 18)
#define	IFX_HAPI_STOP_TONE					_IO(HAPI_IOC_MAGIC, 19) 
#define	IFX_HAPI_ADD_TONE					_IO(HAPI_IOC_MAGIC, 20)
#define	IFX_HAPI_GET_TONE_CONFIG			_IO(HAPI_IOC_MAGIC, 21)
#define	IFX_HAPI_MODIFY_TONE_CONFIG			_IO(HAPI_IOC_MAGIC, 22)

#define	IFX_HAPI_GET_MAX_ROW_COLUMN			_IO(HAPI_IOC_MAGIC, 23)
#define	IFX_HAPI_GET_CURSOR_POS				_IO(HAPI_IOC_MAGIC, 24)
#define	IFX_HAPI_DISPLAY_CLEAR				_IO(HAPI_IOC_MAGIC, 25)
#define	IFX_HAPI_DISPLAY_GOTO				_IO(HAPI_IOC_MAGIC, 26)
#define	IFX_HAPI_DISPLAY_PRINT				_IO(HAPI_IOC_MAGIC, 27)
#define	IFX_HAPI_DISPLAY_MOVE_CURSOR		_IO(HAPI_IOC_MAGIC, 28)
#define	IFX_HAPI_DISPLAY_POWER_CTRL			_IO(HAPI_IOC_MAGIC, 29)
#define	IFX_HAPI_DISPLAY_SET_CONTRAST		_IO(HAPI_IOC_MAGIC, 30)
#define	IFX_HAPI_DISPLAY_GET_CONTRAST		_IO(HAPI_IOC_MAGIC, 31)
#define	IFX_HAPI_DISPLAY_SET_BRIGHTNESS		_IO(HAPI_IOC_MAGIC, 32)
#define	IFX_HAPI_DISPLAY_GET_BRIGHTNESS		_IO(HAPI_IOC_MAGIC, 33)

#define	IFX_HAPI_SET_DTMF_PARAMS			_IO(HAPI_IOC_MAGIC, 34)
#define	IFX_HAPI_APPLY_DTMF_TONE			_IO(HAPI_IOC_MAGIC, 35)
#define	IFX_HAPI_STOP_DTMF_TONE				_IO(HAPI_IOC_MAGIC, 36)

#define	IFX_HAPI_CODER_CHANNEL_EN			_IO(HAPI_IOC_MAGIC, 37)
#define	IFX_HAPI_CODER_CHANNEL_DIS			_IO(HAPI_IOC_MAGIC, 38)

#ifdef NOT_REQD
#define	IFX_HAPI_DECODER_EN					_IO(HAPI_IOC_MAGIC, 39)
#define	IFX_HAPI_DECODER_DIS				_IO(HAPI_IOC_MAGIC, 40)

#define	IFX_HAPI_SILENCE_COMPRESSION_ON		_IO(HAPI_IOC_MAGIC, 41)
#define	IFX_HAPI_SILENCE_COMPRESSION_OFF	_IO(HAPI_IOC_MAGIC, 42)
#define	IFX_HAPI_MODIFY_ENC_PACKET_TIME		_IO(HAPI_IOC_MAGIC, 43)
#define	IFX_HAPI_MODIFY_ENCODER				_IO(HAPI_IOC_MAGIC, 44)
#endif /* NOT_REQD */

#define	IFX_HAPI_MODIFY_CODER_CONFIG		_IO(HAPI_IOC_MAGIC, 39)
#define	IFX_HAPI_GET_DECODER_STATUS			_IO(HAPI_IOC_MAGIC, 40)
#define	IFX_HAPI_SET_RTP_TIMESTAMP			_IO(HAPI_IOC_MAGIC, 41)
#define	IFX_HAPI_GET_RTP_TIMESTAMP			_IO(HAPI_IOC_MAGIC, 42)
#define	IFX_HAPI_READ_DATA					_IO(HAPI_IOC_MAGIC, 43)
#define	IFX_HAPI_READ_RTP_DATA				_IO(HAPI_IOC_MAGIC, 44)
#define	IFX_HAPI_WRITE_DATA					_IO(HAPI_IOC_MAGIC, 45)
#define	IFX_HAPI_WRITE_TO_JB				_IO(HAPI_IOC_MAGIC, 46)
#define	IFX_HAPI_RTP_CONFIG					_IO(HAPI_IOC_MAGIC, 47)

#define	IFX_HAPI_JB_SET_CONFIG				_IO(HAPI_IOC_MAGIC, 48)
#define	IFX_HAPI_JB_QUERY_STATS				_IO(HAPI_IOC_MAGIC, 49)
#define IFX_HAPI_GET_RTCP_STATS				_IO(HAPI_IOC_MAGIC, 50)
#define IFX_HAPI_UPDATE_CODER_TABLE			_IO(HAPI_IOC_MAGIC, 51)

#define	IFX_HAPI_DTMF_INBAND_EN				_IO(HAPI_IOC_MAGIC, 52)
#define IFX_HAPI_DTMF_INBAND_DIS			_IO(HAPI_IOC_MAGIC, 53)

#define	IFX_HAPI_GET_VERSION				_IO(HAPI_IOC_MAGIC, 54)

#define	IFX_HAPI_GET_CAPABILITY				_IO(HAPI_IOC_MAGIC, 55)
#define	IFX_HAPI_SET_MIC_AMPLIFIER			_IO(HAPI_IOC_MAGIC, 56)

#define	IFX_HAPI_ENABLE_MIXING				_IO(HAPI_IOC_MAGIC, 57)
#define	IFX_HAPI_DISABLE_MIXING				_IO(HAPI_IOC_MAGIC, 58)

#define IFX_HAPI_READ_REGISTER				_IO(HAPI_IOC_MAGIC, 59)
#define	IFX_HAPI_MAP_SCANCODE_TO_DIGIT		_IO(HAPI_IOC_MAGIC, 60)

#define IFX_HAPI_ENCRYPTION_ENABLE			_IO(HAPI_IOC_MAGIC, 61)
#define IFX_HAPI_ENCRYPTION_DISABLE			_IO(HAPI_IOC_MAGIC, 62)
#define IFX_HAPI_DECRYPTION_ENABLE			_IO(HAPI_IOC_MAGIC, 63)
#define IFX_HAPI_DECRYPTION_DISABLE			_IO(HAPI_IOC_MAGIC, 64)

#define IFX_HAPI_ENCRYPT_DATA				_IO(HAPI_IOC_MAGIC, 65)
#define IFX_HAPI_DECRYPT_DATA				_IO(HAPI_IOC_MAGIC, 66)

////////////////////////Speechhhh  Recccccccc////////////////
#define	IFX_HAPI_CONFIG_NUM_VECT			_IO(HAPI_IOC_MAGIC, 67)
#define	IFX_HAPI_SET_WORD_DET_COEF			_IO(HAPI_IOC_MAGIC, 68)
#define	IFX_HAPI_SET_REJ_COEF_REC			_IO(HAPI_IOC_MAGIC, 69)
#define	IFX_HAPI_SET_REJ_COEF_TRAIN			_IO(HAPI_IOC_MAGIC, 70)
#define	IFX_HAPI_TRAINING_EN				_IO(HAPI_IOC_MAGIC, 71)
#define	IFX_HAPI_RETRAINING_EN				_IO(HAPI_IOC_MAGIC, 72)
#define	IFX_HAPI_RECOGNITION_EN				_IO(HAPI_IOC_MAGIC, 73)
#define	IFX_HAPI_SPEECH_REC_DISABLE			_IO(HAPI_IOC_MAGIC, 74)
#define	IFX_HAPI_GET_WORD_DET_COEF			_IO(HAPI_IOC_MAGIC, 75)
#define	IFX_HAPI_GET_REJ_COEF_REC			_IO(HAPI_IOC_MAGIC, 76)
#define	IFX_HAPI_GET_REJ_COEF_TRAIN			_IO(HAPI_IOC_MAGIC, 77)
#define	IFX_HAPI_GET_MAX_REFVECT_CONFIG		_IO(HAPI_IOC_MAGIC, 78)
////////////////////////Speechhhh  Recccccccc////////////////

#define	IFX_HAPI_MAX_CMDS					_IO(HAPI_IOC_MAGIC, 79)

#endif /* __INCA_HAPI_H__ */
