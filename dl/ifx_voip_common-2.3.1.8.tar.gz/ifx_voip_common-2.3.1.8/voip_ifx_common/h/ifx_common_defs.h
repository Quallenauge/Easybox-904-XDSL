/*****************************************************************************
 **   FILE NAME    : ifx_common_defs.h
 **   PROJECT      : All Projects
 **   MODULES      : All Modules
 **   SRC VERSION  : V1.0
 **
 **   DATE         : 14-01-2004
 **   AUTHOR       : IFIN COM Engineers
 **   DESCRIPTION  :
 **   FUNCTIONS    :
 **   COMPILER     :
 **   REFERENCE    : Coding guide lines for VSS, DIS of CCS.
 **   COPYRIGHT    : Infineon Technologies AG 2003 - 2004
 **
 **  Version Control Section
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
 ****************************************************************************/
#ifndef		__IFX_COMMON_DEFS_H__
#define		__IFX_COMMON_DEFS_H__
#define _IFX_BASIC_TYPES_H    /*to avoid the inclusion of ifx_basic_types.h */
#define __IFX_MMGR_TYPES_H__  /*to avoid the inclusion of ifx_gateway_appln/MediaMgr/h/IFX_MediaMgrTypes.h */
#define   __IFIN_TR69_TYPES_H__  /*ifx_IFXAPIs/include/ifx_types.h*/

/*! \file ifx_common_defs.h
    \brief This File contains the Constants, enumerations, related Data
    structures and API's common for all modules in GW SS.
*/


/** \addtogroup UTIL_APIs Utilities
	\brief This section lists the api's provided for various utilities
*/

//#include <asm-mips/ifx/ifx_types.h>

/* @{ */

/** \defgroup UTIL_MISC_APIs Misc Service
	\brief This section lists the functions provided for miscellaneous services
*/


/* @{ */
/*!
	\brief Public 
*/
#define	PUBLIC
/*!
	\brief Extern 
*/
#define	EXTERN			extern
/*!
	\brief Static 
*/
#define	STATIC			static

/*!
	\brief Print 
*/
#define	PRINT			printf

/*!
	\brief IN 
*/
#define	IN
/*!
	\brief OUT 
*/
#define	OUT
/*!
	\brief IN_OUT 
*/
#define	IN_OUT

/*!
	\brief nullptr 
*/
#define nullptr(Type)	(Type *)NULL

#ifndef IFX_TR104_COMPLIE_FLG
/*!
	\brief char8
*/
typedef char               char8;
/*!
	\brief uchar8 
*/
typedef unsigned char      uchar8;
/*!
	\brief int8  
*/
typedef char               int8;
/*!
	\brief uint8 
*/
typedef unsigned char      uint8;
/*!
	\brief int16 
*/
typedef short int	         int16;
/*!
	\brief uint16 
*/
typedef unsigned short int	uint16;
/*!
	\brief int32 
*/
typedef int                int32;
/*!
	\brief uint32 
*/
typedef unsigned int	      uint32;

/*!
	\brief int64 
*/
#ifdef __LINUX__
typedef long long int      int64;
#else
typedef long int      int64;
#endif

/*!
	\brief uint64 
*/
#ifdef __LINUX__
typedef unsigned long long int	uint64;
#else
typedef unsigned long int	uint64;
#endif

/*!
	\brief float32 
*/
typedef float              float32;
/*!
	\brief float64 
*/
typedef double             float64;
/*!
	\brief double32 
*/
typedef float              double32;
/*!
	\brief double64  
*/
typedef double             double64;
/*!
	\brief long32 
*/
typedef long               long32;
/*!
	\brief ulong32 
*/
typedef unsigned long      ulong32;
/*!
	\brief bool 
*/
#ifdef __LINUX__
typedef char               bool;
#endif


#endif
/* ON / OFF flags */
#define IFX_OFF 0
#define IFX_ON  1
//#define IFX_PENDING 2

#ifndef TAPI_TYPES_DEFINED
/*!
    \brief Return values for all IFX functions.
*/
#ifndef IFX_TR104_COMPLIE_FLG

/*!
    \brief Return values for all IFX functions.
*/

typedef enum{
  IFX_FAILURE=-1,/*!< Failure */
#ifndef _IFX_TYPES_H
	IFX_SUCCESS=0, /*!< Success */
#endif
  IFX_PROCESSED=1, /*!< Processed */
  IFX_PENDING=2, /*!< Pending */
}e_IFX_Return;
#endif

#ifdef __LINUX__
#ifndef IFX_TRUE
/*! 
    \brief An Enumeration defining Boolean.
*/
typedef enum{
  IFX_FALSE=0,/*!< False */
  IFX_TRUE=1/*!< True */
} e_IFX_Boolean;
#endif
/*!
	\brief boolean
*/
//typedef IFX_boolean_t boolean;
typedef int boolean;
#endif
#endif
/*!
	\brief Number of  Fax protocols supported 
*/
#define IFX_MAX_FAX_PROTO 2

/*! 
	\brief Call on Hold Address Zero on hold
*/
#define IFX_USE_ZERO_ADDR_ONHOLD 0
/*! 
	\brief Call on Hold RFC 3264
*/
#define IFX_USE_RFC3264_ON_HOLD 1

/*!
	\brief Transport Address Size 
*/
#define IFX_MAX_TSP_ADDR 128

/*! 
	\brief Display name Size 
*/
#define IFX_MAX_DISP_NAME 32  

/*! 
	\brief User name Size 
*/
#define IFX_MAX_USR_NAME 32

/*! 
 	\brief Max number of digits 
*/
#define IFX_MAX_DIGITS IFX_MAX_USR_NAME

/*!  
	\brief Ip address length inclusive ipv6
*/
#define IFX_IP_ADDR_LEN 50

/*!  
	\brief Maximum length of base name
*/
#define IFX_MAX_BASENAME 18

/*!
	\brief Enumerations for DTMF 
*/ 
typedef enum
{ 
   IFX_DTMF_NONE = 0, /*!< No Transmission Method*/
   IFX_DTMF_INBAND_EVENT = 2,/*!< RFC 2833*/
   IFX_DTMF_INBAND_VOICE = 1,/*!< Voice Path*/
   IFX_DTMF_BOTH = 4 , /*!< Voice Path and RFC 2833*/
   IFX_DTMF_SIP_INFO = 3 /*!< SIP Info method*/
} e_IFX_DtmfType; 


/*!
	\brief Address Type for SIP addressed
*/
typedef  enum 
{  IFX_IP_ADDR=1,/*!< Address in an IP address*/
   IFX_TEL_NUM=2,/*!< Address is an TEL number*/
   IFX_SIP_URL=3,/*!< Address in a SIP URI*/
   IFX_EXTN=4/*!< Address is an SIP Extension*/
} e_IFX_AddrType;

/*! 
	\brief Enumerations for Transport Type 
*/
typedef enum
{
   IFX_TRPROTO_AUTO=0,/*!< No choice*/
   IFX_TRPROTO_UDP=1,/*!< UDP*/
   IFX_TRPROTO_TCP=2,/*!< TCP*/
   IFX_TRPROTO_TLS=3,/*!< TLS*/
   IFX_TRPROTO_SCTP=4/*!< SCTP*/
} e_IFX_TransportType;

/*!  
	\brief Address Info for SIP addresses 
*/ 
typedef struct 
{ 
   uchar8  ucAddrType;
   /*!< Type of address being given */

   char8 acDisplayName[IFX_MAX_DISP_NAME];
   /*!< Display Name of the destination */ 

   char8 acUserName[IFX_MAX_USR_NAME];
   /*!< User Name of the destination/Phone Number */ 

   char8 acCalledAddr[IFX_MAX_TSP_ADDR]; 
   /*!< IP address/FQDN */

   uint16 unPort; 
   /*!< Port Number on which th destination can be reached */ 
    
   uchar8  ucAddrProto;
   /*!< Adddress Book Protocol can hold any value of e_IFX_SipTransportType 
	 signifies which protocol to be used by sip for connection establishment*/
} x_IFX_CalledAddr; 


/* Codec list */
/*!  
	\brief G.711 A
*/
#define IFX_G711_ALAW     0x00000001
/*!  
	\brief G.711 U
*/
#define IFX_G711_ULAW     0x00000002
/*!  
	\brief G.729 8 
*/
#define IFX_G729_8        0x00000004
/*!  
	\brief G.729 E
*/
#define IFX_G729_E        0x00000008
/*!  
	\brief G.723 
*/
#define IFX_G723          0x00000010
/*!  
	\brief G.723 5 3 
*/
#define IFX_G723_5_3      0x00000020
/*!  
	\brief G.723 6 3 
*/
#define IFX_G723_6_3      0x00000040
/*!  
	\brief G.728 
*/
#define IFX_G728          0x00000080

//#define IFX_LINEAR_256    0x00000100

//#define IFX_LINEAR_16     0x00000200

//#define IFX_LINEAR_8      0x00000400
/*!  
	\brief G.726 16 
*/
#define IFX_G726_16        0x00000800 
/*!  
	\brief G.726 24 
*/
#define IFX_G726_24        0x00001000
/*!  
	\brief G.726 32 
*/
#define IFX_G726_32        0x00002000
/*!  
	\brief G.726 40 
*/
#define IFX_G726_40       0x00004000 
/*!  
	\brief iLBC 
*/
#define IFX_ILBC          0x00100000
/*!  
	\brief T.38 UDP 
*/
#define IFX_T38_UDP       0x00400000 //0x00002000
/*!  
	\brief T.38 TCP 
*/
#define IFX_T38_TCP       0x00800000 //0x00004000
/*!  
	\brief G.726 64 
*/
#define IFX_G722_64       0x00008000
/*!  
	\brief G.722 64 2 
*/
#define IFX_G722_64_2     0x00010000

/*!  
	\brief RFC 2833 Digit Trans 
*/
#define IFX_DIGIT_2833     0x00020000

/*!  
	\brief G.722 1 24 
*/
#define IFX_G722_1_24  		0x00040000
/*!  
	\brief G.722 1 32 
*/
#define IFX_G722_1_32 		0x00080000
/*!  
	\brief Max number of codecs supported in system
*/
#define IFX_MAX_CODECS 20

/*!
	 \brief Default Start Port for RTP 
*/

#define IFX_RTP_AGENT_PORT_START 50000

/*!
	 \brief Structure containing codec Information, maintained per codec 
*/
typedef struct
{
   uint32 uiCodec;
   /*!< Codec Name */
    
   uchar8 ucFrameSize;
   /*!< Frame Size*/
    
   uchar8 ucDynPT;
   /*!< Dynamic Payload Type*/
} x_IFX_Codec;

/*!  \brief Array of codec related information*/
typedef struct
{
   uint16 unNoOfCodecs; /*!< number of codecs in the list*/
   x_IFX_Codec axCodec[IFX_MAX_CODECS];/*!< Array of codecs*/
} x_IFX_CodecList;

/*!
	 \brief T38 Fax Capability - Fill Bit Removal
*/
#define IFIN_FA_CAP_FL_OPT_FILL_BIT_REMOVAL  0x0001
/*!
	 \brief T38 Fax Capability - Transcoding MMR
*/
#define IFIN_FA_CAP_FL_OPT_TRANSCODING_MMR   0x0002
/*!
	 \brief T38 Fax Capability - Transcoding JBIG
*/
#define IFIN_FA_CAP_FL_OPT_TRANSCODING_JBIG  0x0004

/*!
	 \brief T38 Fax Capability - TCF Local
*/
#define IFIN_FA_CAP_FL_TCF_LOCAL             0x01
/*!
	 \brief T38 Fax Capability - TCF Transferred
*/
#define IFIN_FA_CAP_FL_TCF_TRANSFERRED       0x02

/*!
	 \brief T38 Fax Capability - Error Correction Redundancy
*/
#define IFIN_FA_CAP_FL_EC_REDUNDANCY         0x01
/*!
	 \brief T38 Fax Capability - Error Correction FEC
*/
#define IFIN_FA_CAP_FL_EC_FEC                0x02
/*!
	 \brief Structure conatining FAX information. For use of CMGR, 
SIP Agent and Fax Agent.
*/
typedef struct
{
   uint32 uiTransportProtocol;
   /*!< Protocol Type */

   uchar8 ucVersion;
   /*!< T38 Protocol Version */
   
   uchar8 ucRateManagement;
   /*!< Rate management*/

   uint16 unMaxBitRate;
   /*!<  Kilobits/s */

   uint32 uiBitOptions;
	/*!< Options*/
	
   uint16 unUDPMaxBufferSize;
   /*!< UDP Maximum buffer Size */
   uint16 unUDPMaxDatagramSize;
   /*!< UDP Maximum data-gram Size */

   uchar8 ucUDPErrCorrection;
   /*!< UDP Error Correction */
} x_IFX_FaxCfg;

/*!
  \brief Structure contains FAX related Parameters
 */
typedef struct
{
	x_IFX_FaxCfg xFaxCfg; /*!< Fax Info*/
	uchar8 szLocalFaxIpAddr[IFX_IP_ADDR_LEN]; /*!< Local Fax IP address*/	
	uint32 uiLocalFaxPort; /*!< Local Fax Port above*/
	uchar8 szRemoteFaxIpAddr[IFX_IP_ADDR_LEN];/*!< Remote Fax IP address*/	
	uint32 uiRemoteFaxPort; /*!< Remote Fax Port above*/
}x_IFX_FaxParams;

/*!  
	\brief SDP modes 
*/
typedef enum{
  IFX_SENDRECV = 0,/*!< Send Recive*/
  IFX_SENDONLY = 1,/*!< Send Only*/
  IFX_RECVONLY = 2,/*!< Recv Only */
  IFX_INACTIVE = 3/*!< INACTIVE */
}e_IFX_Mode;

/*!
 	\brief contains the RTP parameters information
*/
typedef struct
{
	uchar8 szLocalRtpIpAddr[IFX_IP_ADDR_LEN]; /*!< Local RTP IP address*/	
	uint32 uiLocalRtpPort; /*!< Local RTP Port above*/
	uint32 uiLocalRtcpPort; /*!< Local RTCP Port above*/
	uchar8 szRemoteRtpIpAddr[IFX_IP_ADDR_LEN];/*!< Remote RTP IP address*/	
	uint32 uiRemoteRtpPort; /*!< Remote RTP Port above*/
	uchar8 szRemoteRtcpIpAddr[IFX_IP_ADDR_LEN];/*!< Remote RTCP IP address*/	
	uint32 uiRemoteRtcpPort; /*!< Remote RTCP Port above*/
	e_IFX_Mode eSdpMode;/*!< SDP mode*/
}x_IFX_RtpParams;

/*! \brief Index of the UDP related information 
	in the x_IFX_FaxParams array in x_IFX_MediaParams. */
#define IFX_FAX_UDP_ARR_LOC 0

/*! \brief Index of the TCP related information 
	in the x_IFX_FaxParams array in x_IFX_MediaParams. */
#define IFX_FAX_TCP_ARR_LOC 1

/*!
   \brief Structure contains media related parameters for NA
*/
typedef struct
{
   x_IFX_CodecList xCodecParams;/*!< Will contain Codec List info */
   x_IFX_RtpParams xRtpParams;/*!< Will contain Codec RTP info*/
   x_IFX_FaxParams axFaxParams[IFX_MAX_FAX_PROTO];/*!< Parameters
                                                         needed for FAX*/
}x_IFX_MediaParams;
/*!
	\brief Enumeration defining the various failure responses
*/
typedef enum 
{
	IFX_NO_RESOURCE=0,/*!< No resource for making a call etc.*/
	IFX_CALL_ANSWERED=1, /*!< Call has been answered*/
	IFX_CALL_FORWARD=2,/*!< Call being forwarded*/
	IFX_MEDIA_MISMATCH=3,/*!< Codec Mismatch*/
	IFX_ENDPOINT_BUSY=4,/*!< Endpoint Busy*/
	IFX_ENDPOINT_RINGING=5,/*!< Endpoint Ringing - For FXS*/
	IFX_USER_NOT_FOUND=6,/*!< requested user was not found on the system*/
	IFX_TRANSFER_SUCCESS=7,/*!< Transfer suceeded*/
	IFX_TRANSFER_FAIL=8,/*!< Transfer failed*/
	IFX_RTP_PORT_OPEN_FAIL=9,/*!< Opening an RTP port failed*/
	IFX_CMGR_CONF_ENABLED=10, /*!< Conference Enabled*/
	IFX_CMGR_CONF_DISABLED=11,/*!< Conference Disabled*/
	IFX_CMGR_MOVED_TEMP=12,/*!< SIP 302*/
	IFX_CMGR_MOVED_PERM=13,/*!< SIP 301*/
  IFX_INTERNAL_ERR=14, /*!< Internal Error */
  IFX_TIMEOUT=15, /*!< Timeout */
  IFX_REQ_PENDING=16, /*!< Request Pending */
	IFX_TERMINATED=17, /* To send 4XX or Cancel use IFX_TERMINATED*/ /*!< Terminated */
  IFX_INVALID_DEST=18, /*!< Invalid Destination */
  IFX_REMOTE_UNAVAIL=19, /*!< Remote Unavailable */
  IFX_MEDIA_ERROR=20, /*!< Media Error */
	IFX_RTP_AGENT_INIT_FAIL=21,/*21*/ /*!< RTP Agent Initialization Failure */
  IFX_RTP_AGENT_OPEN_FAIL=22, /*!< RTP Agent Session Open failure */
  IFX_RTP_AGENT_CLOSE_FAIL=23, /*!< RTP Agent Session Open failure */
  IFX_RTP_AGENT_BYE_ARRIVED=24, /*!< RTP Agent BYE arrived */
  IFX_RTP_AGENT_CLOSE_IND=25, /*!< RTP Agent close indication */
  IFX_RTCP_AGENT_INACTIVITY_IND=26, /*!< RTP Agent inactivity indication */
	IFX_RTCP_AGENT_BYE_IND=27, /*!< RTP Agent BYE indication */
  IFX_RTP_AGENT_MODIFY_FAIL=28, /*!< RTP Agent session modification failure */
  IFX_FAX_END_SESSION=29, /*!< Fax Agent session close */
  IFX_FAX_TIMEOUT=30, /*!< Fax Agent Timeout */
	IFX_FAXAPP_START_T38_SESSION_ERR_RSP=31, /*!< Fax Agent T38 session start error */
	IFX_FAXAPP_END_T38_SESSION_ERR_RSP=32, /*!< Fax Agent T38 session end error */
	IFX_FAXAPP_START_SERVER_T38_SESSION_ERR_RSP=33, /*!< Fax Agent T38 server start error */
  IFX_100_RESP=34, /*!< SIP 100 Response */
  IFX_200_RESP=35, /*!< SIP 200 Response */
  IFX_202_RESP=36, /*!< SIP 202 Response */
  IFX_300_RESP=37, /*!< SIP 300 Response */
  IFX_400_RESP=38, /*!< SIP 400 Response */
  IFX_404_RESP=39, /*!< SIP 404 Response */
  IFX_488_RESP=40, /*!< SIP 488 Response */
  IFX_415_RESP=41, /*!< SIP 415 Response */
  IFX_486_RESP=42, /*!< SIP 486 Response */
  IFX_500_RESP=43, /*!< SIP 500 Response */
  IFX_600_RESP=44, /*!< SIP 600 Response */
  IFX_REL_NO_NOTIFY=45, /*!< Release Notify */
	IFX_CIF_INVALID_VOICELINE=46, /** Invalid Voice line ID */
	IFX_CIF_VOICELINE_DISABLED=47, /** Voice line disabled */
	IFX_CIF_CONFIG_ERROR=48, /** Error while reading/writing config */
	IFX_CIF_INVALID_ENDPOINT=49, /** Invalid endpoint id */
	IFX_CIF_ELEMENT_NOT_FOUND=50, /** Element not found in config */
	IFX_CIF_INSUFFICIENT_ARRAY_SIZE=51, /** Element not found in config */
	IFX_UNSUBSCRIBE=52,/*Unsbscribe for a Event*/ /*!< Unsubscribe of an event */
  IFX_OPTION_ARRIVED=53, /*!< OPTION message arrived */
	IFX_ABNORMAL_RELEASE=54, /*Used when DECT HS is out of sync or Switched OFF*/
	IFX_DEFLECTION=55,
	IFX_MAX_REASON=56 /*!< Max reason code */
}e_IFX_ReasonCode;


/* Debug Level Types*/
/*!
	\brief Debug Level None
*/
#define IFX_DBG_LVL_NONE 0
/*!
	\brief Debug Level Error
*/
#define IFX_DBG_LVL_ERROR 1
/*!
	\brief Debug Level Low
*/
#define IFX_DBG_LVL_LOW 2
/*!
	\brief Debug Level Normal
*/
#define IFX_DBG_LVL_NORMAL 3
/*!
	\brief Debug Level High
*/
#define IFX_DBG_LVL_HIGH 4

/* Debug Types */
/*!
	\brief Debug Type None
*/
#define IFX_DBG_TYPE_NONE    0
/*!
	\brief Debug Type Console
*/
#define IFX_DBG_TYPE_CONSOLE 1
/*!
	\brief Debug Type File
*/
#define IFX_DBG_TYPE_FILE 2

/* @} */
/* @} */
#endif	/* __IFX_COMMON_DEFS_H__ */
