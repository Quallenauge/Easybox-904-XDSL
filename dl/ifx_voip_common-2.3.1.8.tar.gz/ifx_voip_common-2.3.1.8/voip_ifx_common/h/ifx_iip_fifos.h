/*****************************************************************************
 **   FILE NAME    : ifx_iip_fifos.h
 **   PROJECT      : All Projects
 **   MODULES      : All Modules
 **   SRC VERSION  : V1.0
 **
 **   DATE         : 06-05-2004
 **   AUTHOR       : Hari
 **   DESCRIPTION  :
 **   FUNCTIONS    :
 **   COMPILER     :
 **   REFERENCE    : Coding guide lines for IFIN COM
 **   COPYRIGHT    : Infineon Technologies AG 2003 - 2004
 **
 **  Version Control Section
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
 ****************************************************************************/
#ifndef		__IFX_IIP_FIFOS_H__
#define		__IFX_IIP_FIFOS_H__

#ifdef IIP
#define IFX_IIP_FIFO_DIR   "./tmp"
#endif
#ifdef ATA
#define IFX_IIP_FIFO_DIR   "/tmp"
#endif

#define IFX_IIP_FIFO_PERM  0644

/* RM Rx FIFO */
/* All modules write to RM thru this Fifo */
#define IFX_IIP_RM_FIFO        IFX_IIP_FIFO_DIR"/RmFifo"

/* Between RM and Other Modules */
/* RM writes to RTP thru this Fifo */
#define IFX_IIP_RM_RTP_FIFO    IFX_IIP_FIFO_DIR"/RmRtpFifo"
/* RM writes to SS thru this Fifo */
#define IFX_IIP_RM_SS_FIFO     IFX_IIP_FIFO_DIR"/RmSsFifo"
/* RM writes to PA thru this Fifo */
#define IFX_IIP_RM_PA_FIFO     IFX_IIP_FIFO_DIR"/RmPaFifo"
/* RM writes to CM thru this Fifo */
#define IFX_IIP_RM_CM_FIFO     IFX_IIP_FIFO_DIR"/RmCmFifo"
/* RM writes to FA thru this Fifo */
#define IFX_ATA_RM_FA_FIFO     IFX_IIP_FIFO_DIR"/RmFaFifo"

/* Between PA and Other Modules */
/* PA writes to SS thru this Fifo */
#define IFX_IIP_PA_SS_FIFO     IFX_IIP_FIFO_DIR"/PaSsFifo"
/* PA writes to CM thru this Fifo */
#define IFX_IIP_PA_CM_FIFO     IFX_IIP_FIFO_DIR"/PaCmFifo"

/* Between CM and Other Modules */
/* CM writes to SS thru this Fifo */
#define IFX_IIP_CM_SS_FIFO     IFX_IIP_FIFO_DIR"/CmSsFifo"
/* CM writes to PA thru this Fifo */
#define IFX_IIP_CM_PA_FIFO     IFX_IIP_FIFO_DIR"/CmPaFifo"
/* CM writes to RM thru this Fifo */
#define IFX_IIP_CM_RM_FIFO     IFX_IIP_FIFO_DIR "/CmRmFifo"
/* CM writes to FA thru this Fifo */
#define IFX_ATA_CM_FA_FIFO     IFX_IIP_FIFO_DIR "/CmFaFifo"


/* Between SS and Other Modules */
/* SS writes to RTP thru this Fifo */
#define IFX_IIP_SS_RTP_FIFO     IFX_IIP_FIFO_DIR "/SsRtpFifo"
/* SS writes to PA thru this Fifo */
#define IFX_IIP_SS_PA_FIFO      IFX_IIP_FIFO_DIR "/SsPaFifo"
/* SS writes to CM thru this Fifo */
#define IFX_IIP_SS_CM_FIFO      IFX_IIP_FIFO_DIR "/SsCmFifo"


/* Between RTP and Other Modules */
/* RTP writes to SS thru this Fifo */
#define IFX_IIP_RTP_SS_FIFO     IFX_IIP_FIFO_DIR"/RtpSsFifo"

/* Webserver writes to CM thru this Fifo */
#define IFX_ATA_WEB_CM_FIFO   IFX_IIP_FIFO_DIR"/WebCmFifo"
/* CM writes to WebServer thru this Fifo */
#define IFX_ATA_CM_WEB_FIFO   IFX_IIP_FIFO_DIR"/CmWebFifo"

/* Between Fax Agent and Other Modules */
/* FA Writes to SS thru this Fifo */
#define IFX_ATA_FA_SS_FIFO    IFX_IIP_FIFO_DIR"/FaSsFifo"
/* FA Writes to CM thru this Fifo */
#define IFX_ATA_FA_CM_FIFO    IFX_IIP_FIFO_DIR"/FaCmFifo"


/* All modules viz., APP & SS write to Fax Agent thru this Fifo */
#define IFX_ATA_FA_FIFO       IFX_IIP_FIFO_DIR"/FaFifo"

/* Key managment Related Fifo's */
#define IFX_IIP_RTP_CM_FIFO  IFX_IIP_FIFO_DIR"/rtpCmFifo"
#define IFX_IIP_CM_RTP_FIFO  IFX_IIP_FIFO_DIR"/CmrtpFifo"

/* FIFO between DHCP Client and CM */
#define IFX_IIP_DHCP_CM_FIFO  IFX_IIP_FIFO_DIR"/DhcpCmFifo"

#endif	/* __IFX_IIP_FIFOS_H__ */
