/***************************************************************************
 **   SRC_FILE          : IFIN_MLIB_Main.h
 **   PROJECT           : Memory library
 **   MODULES           : Memory library
 **   SRC VERSION       : v2.0
 **   DATE              : 
 **   AUTHOR            : Kumar Swamy .D
 **   DESCRIPTION	: 
 **   FUNCTIONS         : 
 **   COMPILER          : Microsoft Visual C++ Studio, Version 6.0
 **   REFERENCE         : 
			
 **   COPYRIGHT         : Infineon Technologies AG 2000-2001
 **  Version Control Section  **        
 **   $Author$    
 **   $Date$      
 **   $Revisions$ 
 **   $Log$       
****************************************************************************/                                                                                                 

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <string.h>
#include <errno.h>

#ifndef __IFIN_MLIB_MAIN_H__



#define __IFIN_MLIB_MAIN_H__





#define IFIN_MLIB_PROTECT  								1
#define IFIN_MLIB_DEBUG        						        1
#define IFIN_MLIB_FLOW_DEBUG   						0

#define IFIN_MLIB_USER_MEMORY        			0x01
#define IFIN_MLIB_DYNAMIC_MEMORY     			0x02
#define IFIN_MLIB_SHARED_MEMORY      			0x03

#define IFIN_MLIB_ERRORNO_KEY_EXISTS      17
#define IFIN_MLIB_ERRORNO_NO_KEY_EXISTS   2

#define IFIN_MLIB_PTR_FEATURE        			0x10
#define IFIN_MLIB_PTR_OFFSET_FEATURE 			0x20


#define IFIN_MLIB_NULL         						0

#define IFIN_MLIB_HEAD_OFFSET  						0
#define IFIN_MLIB_TAIL_OFFSET  						1

#define IFIN_MLIB_NO_WAIT     						1
#define IFIN_MLIB_WAIT_FOREVER 						0xffff

#define IFIN_MLIB_FREE         						1
#define IFIN_MLIB_NOT_FREE								0

#define IFIN_MLIB_YES          						1
#define IFIN_MLIB_NO           						0

#define IFIN_MLIB_SUCCESS                 0
#define IFIN_MLIB_FAILURE                -1  /*65535*/

#define IFIN_MLIB_INSUFFICEINT_DATA      -2  /*65534*/
#define IFIN_MLIB_OUT_OF_SEM_MEMORY      -3  /*65533*/
#define IFIN_MLIB_OUT_OF_MEMORY          -4  /*65532*/
#define IFIN_MLIB_OUT_OF_SHM             -5  /*65531*/

#define IFIN_MLIB_WRONG_DATA             -6  /*65530*/

#define IFIN_MLIB_ZERO_SEG_SIZE          -7  /*65529*/
#define IFIN_MLIB_CROSSED_MAX_SIZE       -8  /*65528*/
#define IFIN_MLIB_BUFFERS_EMPTY          -9  /*65527*/
#define IFIN_MLIB_INVALID                -10 /*65526*/

#define IFIN_MLIB_WRONG_SEG_NUMBER       -11 /*65525*/
#define IFIN_MLIB_SEG_IS_ALREADY_FREED   -12 /*65524*/

#define IFIN_MLIB_KEY_ALREADY_EXISTS     -13  /*65523*/
#define IFIN_MLIB_KEY_NOT_EXISTS         -14  /*65522*/
#define IFIN_MLIB_USER_DATA_MISSED       -15  /*65521*/


#define IFIN_MLIB_PERMS        0666

/* typedef uchar8* IFIN_MLIB_Id;*/
#define IFIN_MLIB_Id uchar8*

/********************************************************************

Required Segments information. Information will be given by user.

********************************************************************/

typedef struct
{
  uint16 unNumOfSegs;
  uint32 uiSegSize;
}x_IFIN_MLIB_SegInfo;




/********************************************************************

Segments Group ( according to size) management information. 
Internal structure.

********************************************************************/

typedef  struct
{
  uint32 uiSegSize;
  uint16 unNumOfSegs;
  uint16 unNumOfFreeSeg;

  uint16 unRdIndex;
  uint16 unWrIndex;

  uint16 unSegListOffset;

#if IFIN_MLIB_DEBUG
  uint16 unMaxSegsUtilized;
  uint16 unBF_CrossedTimes;
  uint32 uiMaxMsgSize;
  uint32 uiMinMsgSize;
#endif
}x_IFIN_MLIB_SegGrpMgtInfo;




/********************************************************************

Individual Segments management information for 	FULL features. 
Internal structure .

********************************************************************/
typedef struct
{
  uint32 uiHeadOffset;
  uint32 uiTailOffset;
  uint8  ucDupCnt;
  uint16 unSegNum;
}x_IFIN_MLIB_SegMgtInfo;

/* Note: For pointer based operation , only seg number will be there */

/********************************************************************

Entire MLIB management information. 
Internal structure.

********************************************************************/
typedef  struct
{
  int32         iShmId;
  int32         iSemId;
  int32         iSharedDataSemId;

  uint32        uiSharedDataSize;

  uint8         ucSegSizeGroups;
  uint8         ucMlibType;

  uint16        unSegGrpMgtInfoOffset;

  uint16        unSegStartAddrOffset;
  uint16        unSharedDataAddrOffset;


  #if IFIN_MLIB_PROTECT

  uint32        uiSegMaxSize;
  uint16        unNumOfSegs;
  uint16	      unSegStatusOffset;

  #endif

  #if IFIN_MLIB_DEBUG

  uint16	      unSegMsgSizesOffset;

  #endif


}x_IFIN_MLIB_MgtInfo;






int16 IFIN_MLIB_Init(
                      IFIN_MLIB_Id         *pMlibId,
                      uint16               unKeyId,
                      uchar8                ucMmuType,
                      uchar8                *pucUserMemory,
                      x_IFIN_MLIB_SegInfo  *pxSegInfo,
                      uint32                uiSharedDataSize
                    ) ;

IFIN_MLIB_Id IFIN_MLIB_GetId( uint16 unKeyId);

int16 IFIN_MLIB_GetSeg( IFIN_MLIB_Id MlibId, 
                         uint32 uiSegSize, uint16 *punSegNum);

#if IFIN_MLIB_DEBUG
   
void IFIN_MLIB_GetSideUpdateDbgInfo( IFIN_MLIB_Id        MlibId,
                                     uchar8              ucDbgIndex,
                                     uchar8              ucIndex,
                                     uint32              uiMsgSize,
                                     uint16              unSegNum
                                   );

void IFIN_MLIB_FreeSideUpdateDbgInfo(IFIN_MLIB_Id        MlibId,
                                     uint8               ucGrpNum,
                                     uint16              unSegNum
                                   );
#endif   

uchar8* IFIN_MLIB_GetSegAddr (IFIN_MLIB_Id MlibId, uint16 unSegNum);

uint32 IFIN_MLIB_GetSegSize(IFIN_MLIB_Id MlibId, uint16 unSegNum);

int16 IFIN_MLIB_SetSegOffset(IFIN_MLIB_Id MlibId, uint16 unSegNum, 
                              uint8 ucOffsetType,  uint32 uiOffsetValue);

int16 IFIN_MLIB_GetSegOffset(IFIN_MLIB_Id MlibId, uint16 unSegNum, 
                             uint8 ucOffsetType,  uint32* puiOffsetValue);

int16 IFIN_MLIB_DupSeg(IFIN_MLIB_Id MlibId, uint16 unSegNum);

int16 IFIN_MLIB_FreeSeg(IFIN_MLIB_Id MlibId, uint16 unSegNum);

uchar8* IFIN_MLIB_AllocMem( IFIN_MLIB_Id MlibId,uint32 uiSegSize );

int16 IFIN_MLIB_GetSegNumOfAddr(IFIN_MLIB_Id MlibId,uchar8 *pucSegAddr);

uint32 IFIN_MLIB_GetMemSize(IFIN_MLIB_Id MlibId, uchar8 *pucSegAddr );

int16 IFIN_MLIB_SetMemOffset(IFIN_MLIB_Id MlibId, uchar8* pucSegAddr, 
                              uint8 ucOffsetType,  uint32 uiOffsetValue);

int16 IFIN_MLIB_GetMemOffset(IFIN_MLIB_Id MlibId, uchar8* pucSegAddr, 
                              uint8 ucOffsetType,  uint32* puiOffsetValue);

int16 IFIN_MLIB_DupMem(IFIN_MLIB_Id MlibId, uchar8* pucSegAddr);

int16 IFIN_MLIB_FreeMem(IFIN_MLIB_Id MlibId,uchar8 *pSegAddr);

uchar8* IFIN_MLIB_LockShm(IFIN_MLIB_Id MlibId, uint16 unWaitNum);

int16   IFIN_MLIB_UnlockShm(IFIN_MLIB_Id MlibId);

int16 IFIN_MLIB_Free(IFIN_MLIB_Id MlibId);

#if IFIN_MLIB_DEBUG

void IFIN_MLIB_DbgInfo(IFIN_MLIB_Id MlibId);

#endif   

#if IFIN_MLIB_FLOW_DEBUG
void IFIN_MLIB_PrintMem(uchar8 *pucAddr, uint32 uiSize); 
#endif

#endif

