/***************************************************************************
 **   SRC_FILE          : IFX_MLIB_Main.h
 **   PROJECT           : Memory library
 **   MODULES           : Memory library
 **   SRC VERSION       : v2.0
 **   DATE              : 
 **   AUTHOR            : Kumar Swamy .D
 **   DESCRIPTION	: 
 **   FUNCTIONS         : 
 **   COMPILER          : Microsoft Visual C++ Studio, Version 6.0
 **   REFERENCE         : 
			
 **   COPYRIGHT         : Infineon Technologies AG 2000-2001
 **  Version Control Section  **        
 **   $Author$    
 **   $Date$      
 **   $Revisions$ 
 **   $Log$       
****************************************************************************/                                                                                                 

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <string.h>
#include <errno.h>

#ifndef __IFX_MLIB_MAIN_H__



#define __IFX_MLIB_MAIN_H__





#define IFX_MLIB_PROTECT  								1
#define IFX_MLIB_DEBUG        						        1
#define IFX_MLIB_FLOW_DEBUG   						0

#define IFX_MLIB_USER_MEMORY        			0x01
#define IFX_MLIB_DYNAMIC_MEMORY     			0x02
#define IFX_MLIB_SHARED_MEMORY      			0x03

#define IFX_MLIB_ERRORNO_KEY_EXISTS      17
#define IFX_MLIB_ERRORNO_NO_KEY_EXISTS   2

#define IFX_MLIB_PTR_FEATURE        			0x10
#define IFX_MLIB_PTR_OFFSET_FEATURE 			0x20


#define IFX_MLIB_NULL         						0

#define IFX_MLIB_HEAD_OFFSET  						0
#define IFX_MLIB_TAIL_OFFSET  						1

#define IFX_MLIB_NO_WAIT     						1
#define IFX_MLIB_WAIT_FOREVER 						0xffff

#define IFX_MLIB_FREE         						1
#define IFX_MLIB_NOT_FREE								0

#define IFX_MLIB_YES          						1
#define IFX_MLIB_NO           						0

#define IFX_MLIB_SUCCESS                 0
#define IFX_MLIB_FAILURE                -1  /*65535*/

#define IFX_MLIB_INSUFFICEINT_DATA      -2  /*65534*/
#define IFX_MLIB_OUT_OF_SEM_MEMORY      -3  /*65533*/
#define IFX_MLIB_OUT_OF_MEMORY          -4  /*65532*/
#define IFX_MLIB_OUT_OF_SHM             -5  /*65531*/

#define IFX_MLIB_WRONG_DATA             -6  /*65530*/

#define IFX_MLIB_ZERO_SEG_SIZE          -7  /*65529*/
#define IFX_MLIB_CROSSED_MAX_SIZE       -8  /*65528*/
#define IFX_MLIB_BUFFERS_EMPTY          -9  /*65527*/
#define IFX_MLIB_INVALID                -10 /*65526*/

#define IFX_MLIB_WRONG_SEG_NUMBER       -11 /*65525*/
#define IFX_MLIB_SEG_IS_ALREADY_FREED   -12 /*65524*/

#define IFX_MLIB_KEY_ALREADY_EXISTS     -13  /*65523*/
#define IFX_MLIB_KEY_NOT_EXISTS         -14  /*65522*/
#define IFX_MLIB_USER_DATA_MISSED       -15  /*65521*/


#define IFX_MLIB_PERMS        0666

/* typedef uchar8* IFX_MLIB_Id;*/
#define IFX_MLIB_Id uchar8*

/********************************************************************

Required Segments information. Information will be given by user.

********************************************************************/

typedef struct
{
  uint16 unNumOfSegs;
  uint32 uiSegSize;
}x_IFX_MLIB_SegInfo;




/********************************************************************

Segments Group ( according to size) management information. 
Internal structure.

********************************************************************/

typedef  struct
{
  uint32 uiSegSize;
  uint16 unNumOfSegs;
  uint16 unNumOfFreeSeg;

  uint16 unRdIndex;
  uint16 unWrIndex;

  uint16 unSegListOffset;

#if IFX_MLIB_DEBUG
  uint16 unMaxSegsUtilized;
  uint16 unBF_CrossedTimes;
  uint32 uiMaxMsgSize;
  uint32 uiMinMsgSize;
#endif
}x_IFX_MLIB_SegGrpMgtInfo;




/********************************************************************

Individual Segments management information for 	FULL features. 
Internal structure .

********************************************************************/
typedef struct
{
  uint32 uiHeadOffset;
  uint32 uiTailOffset;
  uint8  ucDupCnt;
  uint16 unSegNum;
}x_IFX_MLIB_SegMgtInfo;

/* Note: For pointer based operation , only seg number will be there */

/********************************************************************

Entire MLIB management information. 
Internal structure.

********************************************************************/
typedef  struct
{
  int32         iShmId;
  int32         iSemId;
  int32         iSharedDataSemId;

  uint32        uiSharedDataSize;

  uint8         ucSegSizeGroups;
  uint8         ucMlibType;

  uint16        unSegGrpMgtInfoOffset;

  uint16        unSegStartAddrOffset;
  uint16        unSharedDataAddrOffset;


  #if IFX_MLIB_PROTECT

  uint32        uiSegMaxSize;
  uint16        unNumOfSegs;
  uint16	      unSegStatusOffset;

  #endif

  #if IFX_MLIB_DEBUG

  uint16	      unSegMsgSizesOffset;

  #endif


}x_IFX_MLIB_MgtInfo;






int16 IFX_MLIB_Init(
                      IFX_MLIB_Id         *pMlibId,
                      uint16               unKeyId,
                      uchar8                ucMmuType,
                      uchar8                *pucUserMemory,
                      x_IFX_MLIB_SegInfo  *pxSegInfo,
                      uint32                uiSharedDataSize
                    ) ;

IFX_MLIB_Id IFX_MLIB_GetId( uint16 unKeyId);

int16 IFX_MLIB_GetSeg( IFX_MLIB_Id MlibId, 
                         uint32 uiSegSize, uint16 *punSegNum);

#if IFX_MLIB_DEBUG
   
void IFX_MLIB_GetSideUpdateDbgInfo( IFX_MLIB_Id        MlibId,
                                     uchar8              ucDbgIndex,
                                     uchar8              ucIndex,
                                     uint32              uiMsgSize,
                                     uint16              unSegNum
                                   );

void IFX_MLIB_FreeSideUpdateDbgInfo(IFX_MLIB_Id        MlibId,
                                     uint8               ucGrpNum,
                                     uint16              unSegNum
                                   );
#endif   

uchar8* IFX_MLIB_GetSegAddr (IFX_MLIB_Id MlibId, uint16 unSegNum);

uint32 IFX_MLIB_GetSegSize(IFX_MLIB_Id MlibId, uint16 unSegNum);

int16 IFX_MLIB_SetSegOffset(IFX_MLIB_Id MlibId, uint16 unSegNum, 
                              uint8 ucOffsetType,  uint32 uiOffsetValue);

int16 IFX_MLIB_GetSegOffset(IFX_MLIB_Id MlibId, uint16 unSegNum, 
                             uint8 ucOffsetType,  uint32* puiOffsetValue);

int16 IFX_MLIB_DupSeg(IFX_MLIB_Id MlibId, uint16 unSegNum);

int16 IFX_MLIB_FreeSeg(IFX_MLIB_Id MlibId, uint16 unSegNum);

uchar8* IFX_MLIB_AllocMem( IFX_MLIB_Id MlibId,uint32 uiSegSize );

int16 IFX_MLIB_GetSegNumOfAddr(IFX_MLIB_Id MlibId,uchar8 *pucSegAddr);

uint32 IFX_MLIB_GetMemSize(IFX_MLIB_Id MlibId, uchar8 *pucSegAddr );

int16 IFX_MLIB_SetMemOffset(IFX_MLIB_Id MlibId, uchar8* pucSegAddr, 
                              uint8 ucOffsetType,  uint32 uiOffsetValue);

int16 IFX_MLIB_GetMemOffset(IFX_MLIB_Id MlibId, uchar8* pucSegAddr, 
                              uint8 ucOffsetType,  uint32* puiOffsetValue);

int16 IFX_MLIB_DupMem(IFX_MLIB_Id MlibId, uchar8* pucSegAddr);

int16 IFX_MLIB_FreeMem(IFX_MLIB_Id MlibId,uchar8 *pSegAddr);

uchar8* IFX_MLIB_LockShm(IFX_MLIB_Id MlibId, uint16 unWaitNum);

int16   IFX_MLIB_UnlockShm(IFX_MLIB_Id MlibId);

int16 IFX_MLIB_Free(IFX_MLIB_Id MlibId);

#if IFX_MLIB_DEBUG

void IFX_MLIB_DbgInfo(IFX_MLIB_Id MlibId);

#endif   

#if IFX_MLIB_FLOW_DEBUG
void IFX_MLIB_PrintMem(uchar8 *pucAddr, uint32 uiSize); 
#endif

#endif

