/*****************************************************************************
 **   FILE NAME    : IFX_IAD_Common.h
 **   PROJECT      : All Projects
 **   MODULES      : All Modules
 **   SRC VERSION  : V1.0
 **
 **   DATE         : 14-01-2004
 **   AUTHOR       : IFIN COM Engineers
 **   DESCRIPTION  :
 **   FUNCTIONS    :
 **   COMPILER     :
 **   REFERENCE    : Coding guide lines for IFIN COM
 **   COPYRIGHT    : Infineon Technologies AG 2003 - 2004
 **
 **  Version Control Section
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
 ****************************************************************************/
#ifndef		__IFX_IAD_COMMON_H__
#define		__IFX_IAD_COMMON_H__

#include "ifx_common_defs.h"

#endif		/* __IFX_SIP_TYPES_H__ */
