/******************************************************************************

                                Copyright (c) 2006
                             Infineon Technologies AG
                        Am Campeon 1-12, 85579 Neubiberg, Germany

        This program is free software; you can redistribute it and/or modify
        it under the terms of the GNU General Public License as published by
        the Free Software Foundation; either version 2 of the License, or
        (at your option) any later version.

*******************************************************************************/
//#include <linux/config.h>
#include <linux/module.h>

#include <linux/kernel.h>   
#include <linux/slab.h>
#include <linux/fs.h>       
#include <linux/errno.h>    
#include <linux/types.h>    
#include <linux/init.h>
#include <linux/proc_fs.h>
#include <linux/poll.h>
#include <linux/ioport.h>
#include <linux/vmalloc.h>
#include <linux/delay.h>
#include <linux/sched.h>
#include <linux/param.h>
#include <linux/timer.h>
#include <linux/interrupt.h>
#include <asm/uaccess.h>
#include <asm/io.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,26)
#include <asm/semaphore.h>
#else
#include <linux/semaphore.h>
#endif
#include <asm/irq.h>

#include "ifx_voip_timer_driver.h"        
#define VOIPTIMER_VERSION "2.2.0.0"
#if CONFIG_PROC_FS
static struct proc_dir_entry *dect_proc_dir;
int voip_drv_read_proc(char *page, char **start, off_t off,
                int count, int *eof, void *data);

int voip_drv_get_version_proc(char *buf);
#endif /* CONFIG_PROC_FS */


static int timer_interval = 1000; /*1000msec*/
static struct IFX_Timer_CntrlBlock xdrvTimerCB[IFX_TIMER_MAX_PROCESS];

void IFX_TimerCallBk(unsigned long data)
{
  struct IFX_Timer_CntrlBlock *pxdrvTimerCB=(struct IFX_Timer_CntrlBlock *)data; 
  pxdrvTimerCB->Timer_excpFlag = 1;
  wake_up_interruptible(&pxdrvTimerCB->Timer_WakeupList);

}

/*
 * File operations
 */
int IFX_Timer_Open   (struct inode *inode, struct file *filp);
int IFX_Timer_Release(struct inode *inode, struct file *filp);
int IFX_Timer_Ioctl  (struct inode *inode, struct file *filp, unsigned int cmd, unsigned long arg);
int IFX_Timer_Poll(struct file *file_p, struct poll_table_struct *wait);
int IFX_Timer_Write  (struct file *file_p,const char __user *buf, size_t count, loff_t *ppos);
int IFX_Timer_Read   (struct file *file_p, char *buf, size_t count, loff_t *ppos);

/* 
 * The operations for device node handled.
 */
static struct file_operations IFX_Timer_fops =
{
    owner:
        THIS_MODULE,
    read:
        IFX_Timer_Read,
    write:
        (void*)IFX_Timer_Write,
    poll: 
        (void*)IFX_Timer_Poll,
    ioctl:
        IFX_Timer_Ioctl,
    open:
        IFX_Timer_Open,
    release:
        IFX_Timer_Release
};

int IFX_Timer_Read(struct file *file_p, char *buf, size_t count, loff_t *ppos)
{
  return 0;
}


int IFX_Timer_Write(struct file *file_p, const char __user *buf, size_t count, loff_t *ppos)
{
  return 0;
}

int IFX_Timer_Poll(struct file *file_p, struct poll_table_struct *wait)
{
  struct IFX_Timer_CntrlBlock *pxdrvTimerCB=(struct IFX_Timer_CntrlBlock *)file_p->private_data; 
  int ret = 0;
  /* install the poll queues of events to poll on */
  poll_wait(file_p, &(pxdrvTimerCB->Timer_WakeupList), wait);
  
  if (pxdrvTimerCB->Timer_excpFlag)
  {
    ret = POLLIN | POLLRDNORM;
    pxdrvTimerCB->Timer_excpFlag = 0;
  }
  return ret;
}

int IFX_Timer_Ioctl(struct inode *inode, struct file *file_p, unsigned int cmd, unsigned long arg)
{
  struct IFX_Timer_CntrlBlock *pxdrvTimerCB=(struct IFX_Timer_CntrlBlock *)file_p->private_data; 
  switch(cmd)
  {
    case IFX_TIMER_DRV_MODE_CHANGE:
        del_timer(&pxdrvTimerCB->timer);       
        if (arg){
          timer_interval = arg;
        }
        pxdrvTimerCB->timer.function = IFX_TimerCallBk;
        pxdrvTimerCB->timer.data = (unsigned long)pxdrvTimerCB;
      	if (timer_interval <= 1000){
          pxdrvTimerCB->timer.expires = jiffies + (HZ/IFX_EXPIRE_TIME_DEVIDE);
        }
        else {
          pxdrvTimerCB->timer.expires = jiffies + (IFX_EXPIRE_TIME_MULTY);
        }
        add_timer(&pxdrvTimerCB->timer);
    default:
	  break;	
  }
  return 0;
}


int IFX_Timer_Open(struct inode *inode, struct file *file_p)
{
  unsigned int num = MINOR(inode->i_rdev);
  int iCount=0,isFree=-1;
  /*printk(IFX_TIMER_DEVICE_NAME " : Device open (%d, %d)\n\n", MAJOR(inode->i_rdev), MINOR(inode->i_rdev));
  printk(IFX_TIMER_DEVICE_NAME "Device opened by PID: %d \n\n", current->pid);*/
  if (num > IFX_TIMER_DRV_MINOR_1)
  {
    printk("voip_timer_driver: Minor number error!\n");
    return -1;
  }
  for(iCount=0;iCount<IFX_TIMER_MAX_PROCESS;iCount++){
      if((xdrvTimerCB[iCount].pxtask !=NULL)&&(xdrvTimerCB[iCount].pxtask->pid == current->pid)){
        return -1;
      }
      if(xdrvTimerCB[iCount].pxtask == NULL){
         isFree=iCount;
      }
  }
  if(isFree < 0){
    return isFree;
  } 

  init_timer(&xdrvTimerCB[isFree].timer);
  
  xdrvTimerCB[isFree].pxtask = current;
  
  /* Use filp->private_data to point to the device data. */
  file_p->private_data = (void *)&xdrvTimerCB[isFree];
  
  /* Initialize a wait_queue list for the system poll function. */ 
  init_waitqueue_head(&xdrvTimerCB[isFree].Timer_WakeupList);

  /* Increment module use counter */
//  MOD_INC_USE_COUNT;
#if CONFIG_PROC_FS

  dect_proc_dir = proc_mkdir("driver/voip_timer", NULL);

  if (dect_proc_dir != NULL)
  {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,30)
    dect_proc_dir->owner = THIS_MODULE;
#endif
    create_proc_read_entry("version", S_IFREG|S_IRUGO, dect_proc_dir,
                    voip_drv_read_proc, voip_drv_get_version_proc);
  }
#endif /* CONFIG_PROC_FS */


  return 0;
}


int IFX_Timer_Release(struct inode *inode, struct file *file_p)
{
  struct IFX_Timer_CntrlBlock *pxdrvTimerCB=(struct IFX_Timer_CntrlBlock *)file_p->private_data; 
  /*printk(IFX_TIMER_DEVICE_NAME " : Device release (%d, %d)\n\n", MAJOR(inode->i_rdev), MINOR(inode->i_rdev));*/
  del_timer(&(pxdrvTimerCB->timer));
  pxdrvTimerCB->pxtask=NULL;
//  MOD_DEC_USE_COUNT;
	#if CONFIG_PROC_FS
  	remove_proc_entry("version",dect_proc_dir);
  	remove_proc_entry("driver/voip_timer", NULL);
	#endif /* CONFIG_PROC_FS */	
  return 0;
}


int IFX_Timer_Init(void)
{
  int result;

  result = register_chrdev(IFX_TIMER_DRV_MAJOR, IFX_TIMER_DEVICE_NAME, &IFX_Timer_fops);
  
  if (result < 0){
    printk(KERN_INFO "voip_timer_driver: Unable to get major %d\n", IFX_TIMER_DRV_MAJOR);
    return result;
  }
  return 0;
}


void IFX_Timer_Cleanup(void)
{
  unregister_chrdev(IFX_TIMER_DRV_MAJOR, IFX_TIMER_DEVICE_NAME);
}
#if CONFIG_PROC_FS
int voip_drv_read_proc(char *page, char **start, off_t off,
                int count, int *eof, void *data)
{
  int len;
  int (*fn)(char *buf);

  if (data != NULL)
  {
    fn = data;
    len = fn(page);
  }
  else
    return 0;

  if (len <= off+count)
    *eof = 1;

  *start = page + off;

  len -= off;

  if (len > count)
    len = count;

  if (len < 0)
    len = 0;

  return len;

}
int voip_drv_get_version_proc(char *buf)
{
  int len;
  unsigned char ucVersion[]=VOIPTIMER_VERSION;
  len = sprintf(buf, "Voip Timer Driver Version:%s\n Built Time stamp:Date-%sTime-%s\n",ucVersion,__DATE__,__TIME__);
  return len;
}

#endif /*CONFIG_PROC_FS*/

module_init(IFX_Timer_Init);
module_exit(IFX_Timer_Cleanup);

MODULE_DESCRIPTION("Infineon Timer device");
MODULE_AUTHOR("Infineon Bangalore");
MODULE_LICENSE("GPL");

