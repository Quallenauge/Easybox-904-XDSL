#ifndef IFX_CGI_COMMON_H
#define IFX_CGI_COMMON_H
#include <sys/syslog.h>
#include <ifx_emf.h>

#include <signal.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ioctl.h>

#define MAX_FIELD_LEN   128

#define IFX_GET_WAN_SELECTED_INDEX(flags, outFlag, sWAN_IDX, nWAN_IDX) { \
                if(ifx_GetObjData(FILE_SYSTEM_STATUS, "http_wan_vcc_select", "WAN_VCC", flags, \
                                  &outFlag, sWAN_IDX) != IFX_SUCCESS) { \
                        ifx_httpdError(wp, 400, T("Failed to get wan index !!\n\n")); \
                        return -1; \
                } \
                nWAN_IDX=atoi(sWAN_IDX); \
                if (nWAN_IDX<1) \
                        nWAN_IDX=1; \
        }

#define IFX_GET_WAN_CONN_NAME_LIST(i, count, wan_iface, wan_conn_names) { \
                for (i = 0; i < count; i++) { \
                        if(!gstrcmp(wan_iface, GET_WAN_CONN_NAME(wan_conn_names, i))) \
                                ifx_httpdWrite(wp, T("<option value=\"%s\" %s>%s</option>"), GET_WAN_CONN_NAME(wan_conn_names, i), "SELECTED", (GET_WAN_CONN_NAME(wan_conn_names, i))); \
                        else \
                                ifx_httpdWrite(wp, T("<option value=\"%s\">%s</option>"), GET_WAN_CONN_NAME(wan_conn_names, i), GET_WAN_CONN_NAME(wan_conn_names, i)); \
                } \
        }

#define IFX_WRITE_CHECKBOX_STATUS(tagname, secname, retvalue) { \
                if (ifx_GetCfgData(FILE_RC_CONF, tagname, secname, retvalue)) { \
                        ifx_httpdWrite(wp, T("%s"), (!gstrcmp(retvalue, "1"))?"checked":""); \
                } \
        }
#define IFX_GET_WAN_CONN_STATE_STRING(wan_cfg, str_status) { \
                switch(wan_cfg->type) { \
      	        case WAN_LINK_TYPE_ETH: \
                case WAN_LINK_TYPE_PTM: \
                case WAN_LINK_TYPE_EOATM: \
                case WAN_LINK_TYPE_IPOATM: \
                case WAN_LINK_TYPE_CLIP: /* is an ip connection */ \
                        switch(wan_cfg->WAN_IP_CONN.conn_status) { \
                        case WAN_IP_CONN_STATUS_UNCONFIGURED: \
                                sprintf(str_status, "%s", "Unconfigured"); \
                                break; \
                        case WAN_IP_CONN_STATUS_CONNECTING: \
                                sprintf(str_status, "%s", "Connecting"); \
                                break; \
                        case WAN_IP_CONN_STATUS_CONNECTED: \
                                sprintf(str_status, "%s", "Connected"); \
                                break; \
                        case WAN_IP_CONN_STATUS_PENDING_DISCONNECT: \
                                sprintf(str_status, "%s", "Pending Disconnect"); \
                                break; \
                        case WAN_IP_CONN_STATUS_DISCONNECTING: \
                                sprintf(str_status, "%s", "Disconnecting"); \
                                break; \
                        case WAN_IP_CONN_STATUS_DISCONNECTED: \
                                sprintf(str_status, "%s", "Disconnected"); \
                                break; \
                        } \
                        break; \
 case WAN_LINK_TYPE_PPPOATM: \
                case WAN_LINK_TYPE_PPPOE: /* is a ppp connection */ \
                        switch(wan_cfg->WAN_PPP_CONN.conn_status) { \
                        case WAN_PPP_CONN_STATUS_UNCONFIGURED: \
                                sprintf(str_status, "%s", "Unconfigured"); \
                                break; \
                        case WAN_PPP_CONN_STATUS_CONNECTING: \
                                sprintf(str_status, "%s", "Connecting"); \
                                break; \
                        case WAN_PPP_CONN_STATUS_CONNECTED: \
                                sprintf(str_status, "%s", "Connected"); \
                                break; \
                        case WAN_PPP_CONN_STATUS_PENDING_DISCONNECT: \
                                sprintf(str_status, "%s", "Pending Disconnect"); \
                                break; \
                        case WAN_PPP_CONN_STATUS_DISCONNECTING: \
                                sprintf(str_status, "%s", "Disconnecting"); \
                                break; \
                        case WAN_PPP_CONN_STATUS_DISCONNECTED: \
                                sprintf(str_status, "%s", "Disconnected"); \
                                break; \
                        case WAN_PPP_CONN_STATUS_AUTHENTICATING: \
                                if(wan_cfg->WAN_PPP_CONN.last_conn_error == WANPPP_LAST_CONN_ERROR_AUTHENTICATION_FAILURE) \
                                        sprintf(str_status, "%s", "Authentication Failure"); \
                                else \
                                        sprintf(str_status, "%s", "Authenticating"); \
                        } \
                        break; \
                } \
        }

#ifdef CONFIG_FEATURE_RIP
#define GET_GLOBAL_RIP_LISTEN_MODE(rxMode) {}
#else
#define GET_GLOBAL_RIP_LISTEN_MODE(rxMode) { \
                char_t  temp_value[MAX_FILELINE_LEN]; \
                uint32  temp_outFlag = IFX_F_DEFAULT; \
                if(ifx_GetObjData(FILE_RC_CONF, TAG_ROUTE_DYNAMIC, "route_dynamic_listenMode", IFX_F_DEFAULT, &temp_outFlag, temp_value) != IFX_SUCCESS) \
                        rxMode = 0; \
                else \
                        rxMode = atoi(temp_value); \
        }
#endif

#define COPY_TO_STATUS(fmt, args...) { \
                if(!(status_str = (char *)calloc(LINE_LEN, 1))) { \
                        ret = IFX_FAILURE; \
                        goto IFX_Handler; \
                } \
                sprintf(status_str, fmt, ##args); \
        }


#define IFX_GET_WAN_SELECTED_INDEX(flags, outFlag, sWAN_IDX, nWAN_IDX) { \
                if(ifx_GetObjData(FILE_SYSTEM_STATUS, "http_wan_vcc_select", "WAN_VCC", flags, \
                                  &outFlag, sWAN_IDX) != IFX_SUCCESS) { \
                        ifx_httpdError(wp, 400, T("Failed to get wan index !!\n\n")); \
                        return -1;\
                } \
                nWAN_IDX=atoi(sWAN_IDX); \
                if (nWAN_IDX<1) \
                        nWAN_IDX=1; \
        }


#ifdef CONFIG_FEATURE_IFX_IPQOS
#define IFX_GET_QOS_DROP_TYPE_STR(dropType, pDrop) { \
                                                     switch(dropType) { \
                                                        case IFX_MAPI_QoS_Drop_DT: \
                                                                          pDrop = "DT"; \
                                                                          break; \
                                                        case IFX_MAPI_QoS_Drop_RED: \
                                                                          pDrop = "RED"; \
                                                                          break; \
							case IFX_MAPI_QoS_Drop_NONE: \
					      				  pDrop = "NONE"; \
									  break; \
					     		case IFX_MAPI_QoS_Drop_WRED: \
                                                                          pDrop = "WRED"; \
                                                                          break; \
                                                        case IFX_MAPI_QoS_Drop_BLUE: \
                                                                          pDrop = "BLUE"; \
                                                                          break; \
                                 } \
                           }

#define IFX_GET_QOS_SCHED_TYPE_STR(schedType, pSched) { \
                                                             switch(schedType) { \
                                                                case IFX_MAPI_QoS_Sched_SP: \
                                                                                  pSched = "SP"; \
                                                                                  break; \
                                                                case IFX_MAPI_QoS_Sched_WRR: \
                                                                                  pSched = "WRR"; \
                                                                                  break; \
                                                                case IFX_MAPI_QoS_Sched_WFQ: \
                                                                                  pSched = "WFQ"; \
                                                                                  break; \
                                                                case IFX_MAPI_QoS_Sched_HTB: \
                                                                                  pSched = "HTB"; \
                                                                                  break; \
                                                             } \
                                           }



#endif // CONFIG_FEATURE_IFX_IPQOS
#endif
