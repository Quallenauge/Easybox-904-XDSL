/******************************************************************************
**
** FILE NAME    : 
** PROJECT      : 
** MODULES      : 
**
** DATE         : 
** AUTHOR       : 
** DESCRIPTION  : 
** COPYRIGHT    :       Copyright (c) 2006
**                      Infineon Technologies AG
**                      Am Campeon 1-12, 85579 Neubiberg, Germany
**
**    This program is free software; you can redistribute it and/or modify
**    it under the terms of the GNU General Public License as published by
**    the Free Software Foundation; either version 2 of the License, or
**    (at your option) any later version.
**
** HISTORY
** $Date        $Author         $Comment
** 
*******************************************************************************/

#include <stdio.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>

int main()
{       
           fd_set rfds;
           struct timeval tv;
           int retval;
           int fd;
           char buf[10];
          
           fd = open("/dev/pb",O_RDONLY|O_NONBLOCK);
 
           while(1)
	   { 
               tv.tv_sec = 1;
               tv.tv_usec = 0;
               FD_ZERO(&rfds);
               FD_SET(fd, &rfds);

               retval = select(fd+1, &rfds, NULL, NULL, NULL);

               if (FD_ISSET(fd,&rfds))
               {
                   read(fd,buf,10);
                   printf("the buffer is %s\n",buf);
               }
           }                                                                     
           close(fd);
           return 0;


}
@
