/**************************************************************************
**   FILE NAME     : IFX_DECT_TK_Examples.h
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-09-2008
**   AUTHOR        : 
**   DESCRIPTION   : Examples for usage of DECT TK API
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software is granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_DECT_TK_Examples.h
    \brief This file contains examples to illustrate the usage of DECT TK APIs.  
                The usage of the DECT TK APIs for some scenarios has been described.  
*/

/** \defgroup DECT_TOOLKIT_EXAMPLES API Usage Examples
    \brief This section captures some examples that illustrate the 
                usage of the DECT TK API.  Usage examples have been 
                provided for scenarios involving \n
                1> Init and Config Unit\n
                2> Call Service Unit\n
                3> Management Unit\n
                4> Data Packet Service Unit\n
                5> Short Message Service Unit\n
                6>  Extension Service Unit\n
                7> IE Parsing (Encoding and Decoding)\n.
                
                It is not the intention of this section to describe usage
                examples for each and every function within the toolkit.
                A few scenarios are taken and the usage of the DECT TK
                API within the scenarios are described.  
*/

/** \ingroup DECT_TOOLKIT_EXAMPLES
       \defgroup INIT_EXAMPLES Init and Shutdown 
       \brief The section illustrates the example(s) for the Init and Config Unit API. \n\n
*/
/* @{ */

 /*! 
   \fn e_IFX_Return AppInit() 
   \brief This function demonstrates the SYNC and ASYNC init functions.
 \code
 e_IFX_Return AppInit()
 {
      x_IFX_DECT_StackInitCfg xInitCfg = {0};

      // Fill RFPI
      FILL_RFPI_IN_HEX(xInitCfg.aucRfpi); 

      // Fill values for BMC, default shown below
      xInitCfg.xBMCPrams.ucRSSIFreeLevel= 47; 
      xInitCfg.xBMCPrams.ucRSSIBusyLevel=178;
      xInitCfg.xBMCPrams.ucBearerChgLim=125; 
      xInitCfg.xBMCPrams.ucDelayReg=0; 
      xInitCfg.xBMCPrams.ucDefaultAntenna=129; 
      xInitCfg.xBMCPrams.ucDRONCtrlReg=104; 
      xInitCfg.xBMCPrams.ucDSPFrameReset=0; 
      xInitCfg.xBMCPrams.ucModeCtrlReg2=0; 
      xInitCfg.xBMCPrams.ucClkRecovery=0; 
      xInitCfg.xBMCPrams.ucWOPNSF=32;
      xInitCfg.xBMCPrams.ucWWSF=8;
      xInitCfg.xBMCPrams.ucCRRStart=3;
      xInitCfg.xBMCPrams.ucCRREnd=255 ;
      xInitCfg.xBMCPrams.ucPLLSettleTime=255;
      xInitCfg.xBMCPrams.ucGaussianEnable=0x03;
      xInitCfg.xBMCPrams.ucRXDSGDeact=0;
      xInitCfg.xBMCPrams.ucGenModeCtrl2=4;
      xInitCfg.xBMCPrams.ucHandOverEvalper=164;
      xInitCfg.xBMCPrams.ucGENMUTCTRL0=0;
      xInitCfg.xBMCPrams.ucGENMUTCTRL1=0;
      xInitCfg.xBMCPrams.ucEXTMUTCTRL0=137;

      // Fill OscTrimval, default values shown below
      xInitCfg.xOscTrimVal.ucOscTrimValHI = 0;  
      xInitCfg.xOscTrimVal.ucOscTrimValLOW = 47;
      strcpy(xInitCfg.xOscTrimVal.aucCheckSum,"0"); 

      // Fill Gaussian value, default shown below
      xInitCfg.ucGaussianVal = 175;
      // Fill PIN
      strcpy(xInitCfg.acBasePin, "0000");
      // Fill already subscribed PP numbers 
      xInitCfg.ucNoOfReg = 2;

      // Fill subscription information assuming 
      // pxPPSubInfo contains necessary info
      memcpy(&xInitCfg.xRegList,pxPPSubInfo,
                                sizeof(x_IFX_DECT_FTRegList)*6);

      // call ASYNC init with application 
      // initstatus callback function 
      IFX_DECT_Async_Init(&xInitCfg, App_Toolkit_InitStatus);

      // OR For Sync mode init with call back function
      xCallbks.pfnAddFDToSelect = App_CMGR_RegFd;
      xCallbks.pfnRemoveFDToSelect = App_CMGR_UnRegFd;

      IFX_DECT_Sync_Init(&xInitCfg,IFX_DECT_InitStatus,&xCallbks);
      return IFX_SUCCESS;

 } // AppInit


 // Main Program
int main()
{
      // Initilize the toolkit
      AppInit(ASYNC_MODE);
      // Register all callbacks
      App_MU_RegCallBk();
      App_CSU_RegisterCallBks();
      App_SMSU_RegisterCallBks();

      //Poll for events 
      while(1)
      {
           poll(PageFD,.....);
           // Act on Events
           if(PageFD ubblocked)
           {
                 read(PageFD,&duration);
                 App_MU_PrcPageKey(duration);
           }
       // Act on Other Events
      }
} 
 \endcode
 
 
 \fn e_IFX_Return AppShut() 
 \brief This function demonstrates the shutdown function.
 
 \code
 
 e_IFX_Return AppShut()
 {
      // Free all App resources
      // Call DECT Shut function
      IFX_DECT_Shut();
      return IFX_SUCCESS;
 } // AppShut
* \endcode 
 
 
*/
 e_IFX_Return AppInit(void);
 e_IFX_Return AppShut(void);
/* @} */ 
 

/*! \ingroup DECT_TOOLKIT_EXAMPLES
    \defgroup CSU_EXAMPLES Call Service Unit
    \brief The section illustrates the example(s) for the Call Service Unit API. 
*/
 
 /* @{  */
 
/*!
 \fn e_IFX_Return App_CSU_RegisterCallBks() 
 \brief This function demonstrates the CSU register callback function.
 
\code
e_IFX_Return App_CSU_RegisterCallBks()
{
   x_IFX_DECT_CSU_CallBks xCSUCbs;

    xCSUCbs.pfnCallInitiate = App_CSU_CallInitiate;
    xCSUCbs.pfnCallAccept = App_CSU_CallAccept;
    xCSUCbs.pfnCallAnswer = App_CSU_CallAnswer;
    xCSUCbs.pfnCallRelease = App_CSU_CallRelease;
    xCSUCbs.pfnInfoReceived = App_CSU_InfoReceived;
    xCSUCbs.pfnServiceChange = App_CSU_ServiceChange;
    xCSUCbs.pfnModifyVoice = App_CSU_ModifyVoice;

    IFX_DECT_CSU_RegisterCallBks(&xCSUCbs);
   return IFX_SUCCESS;
} // App_CSU_RegisterCallBks
\endcode 


 \fn e_IFX_Return App_CSU_CallInitiate(
                            IN uint32 uiCallHdl,
                            IN uchar8 ucHandsetId,
                            IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                            OUT uchar8 *pucRejectReason,
                            OUT uint32 *puiPrivateData) 
  \param[in] uiCallHdl Call Handle of the call 
  \param[in] ucHandsetId Handset Identifier of source PT
   \param[in] pxCallParams Reference to call parameters
   \param[out] pucRejectReason Reason if the call is rejected
  \param[out] puiPrivateData Reference to the private data area of the FT 
                                  application. CSU shall maintain this handle and 
                                  pass it to the FT Application in all callback(s).
                                  The FT application shall fill in the address of the Private
                                  Data area.
  \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING 
 \brief This function demonstrates the call initiate callback function.
 
   
\code

//global variables to store call originator handset call handle(H1) and
//call terminating handset(H2) and there capability 
boolean bwideband;
uint32 uiSrcHandsetCallHdl;
uint32 uiDstHandsetCallHdl;

e_IFX_Return 
App_CSU_CallInitiate(IN uint32 uiSrcCallHdl,
                     IN uchar8 ucHandsetId,
                     IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                     OUT uchar8 *pucRejectReason,
                     OUT  uint32 *puiPrivateData)
{
   // Store the CallHdl of DectToolkit.
   // Check for call block for the caller Id
   // Allocate DECT telephony resource [e.g. TAPI]
   // Check for media params which contains the codec information
   // if wideband requested then check whether handset is wideband enabled
    
   // Store the requested media codec narrowband=G726 wideband=g722
   bwideband = pxCallParams->bwideband;
   // Store source Call handle
   uiSrcHandsetCallHdl = uiCallHdl;
    // provide the FT application handle if any to the toolkit.
   *puiPrivateData = FTApplicationHandle;
}
\endcode 
 
 
 \fn e_IFX_Return App_CSU_InfoReceived(
                     IN uint32 uiCallHdl,
                     IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                     IN uint32 uiPrivateData)
\brief  This callback function is used to inform the FT application about the 
                   call related information received from the PT.  
   \param[in] uiCallHdl Call Handle of the call 
   \param[in] pxCallParams Reference to call parameters. 
   \param[in] uiPrivateData Reference to the private data handle of the
              FT application.    
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING 
 
 
\code
 
 e_IFX_Return
App_CSU_InfoReceived(
                     IN uint32 uiCallHdl, 
                     IN x_IFX_DECT_CSU_CallParams *pxCallParams, 
                     IN uint32 uiPrivateData)
{
    x_IFX_DECT_CSU_CallParams xCallParams={0};
  
  // Get the media codec offered during call initiate
  xCallParams.bwideband = bwideband;

  // The destination handset number is provided in the CC-INFO 
  // which is in pxCallParams->acRecvDigits
  // Initiate call with the handset 2, 
  // i.e. assuming pxCallParams->acRecvDigits[0] =2
  IFX_DECT_CSU_CallInitiate(pxCallParams->acRecvDigits[0], 
                            &xCallParams, NULL,
                            &uiDstHandsetCallHdl);
  return IFX_SUCCESS;
} //App_CSU_InfoReceived
 
\endcode
 
 
   \fn e_IFX_Return App_CSU_CallAccept(
                                       IN uint32 uiCallHdl, 
                                       IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                       IN uint32 uiPrivateData)
   \brief  This callback function is used to inform the FT application that the
                   call is accepted at the PT and the PT is in the alerting state.  
   \param[in] uiCallHdl Call Handle of the call 
   \param[in] pxCallParams Reference to call parameters
   \param[in] uiPrivateData Reference to the private data handle of the
    FT application.    
   \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
\code

e_IFX_Return App_CSU_CallAccept(
                                IN uint32 uiDstCallHdl, 
                                IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                IN uint32 uiPrivateData)
{
   // Check for the accepted codec[WB/NB] information in the call params
   bwideband = pxCallParams->bwideband;
   // Send call accept for handset 1 using the stored uiSrcHandsetCallHdl
   IFX_DECT_CSU_CallAccept(uiSrcHandsetCallHdl,
                         pxCallParams);
   return IFX_SUCCESS;
} //App_CSU_CallAccept 
\endcode
 
 
 \fn  e_IFX_Return App_CSU_CallAnswer(
                                IN uint32 uiCallHdl, 
                                IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                IN uint32 uiPrivateData)

 \brief  This callback function is used to inform the FT application that the
                   call is answered at the PT.  
 \param[in] uiCallHdl Call Handle of the call 
 \param[in] pxCallParams Reference to call parameters
 \param[in] uiPrivateData Reference to the private data handle of the FT application.    
 \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING
 
\code
 
e_IFX_Return App_CSU_CallAnswer(
                                IN uint32 uiDstCallHdl,
                                IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                IN uint32 uiPrivateData)
{
    // Check for the codec[WB/NB] information in the call params
    bwideband = pxCallParams->bwideband;
    // Allocate telephony resource [e.g. TAPI], 
    // get allocated unDectChannel
    IFX_DECT_CSU_CallAnswer(uiSrcHandsetCallHdl,
                             &xCallParams);
     // Start voice on both handsets at dect 
    // side using the stored call handles
    IFX_DECT_CSU_ModifyVoice(uiSrcHandsetCallHdl, 
           pxCallParams, IFX_DECT_START_VOICE, 
           GetDectHwChannel(uiSrcHandsetCallHdl)); //return dect channel
   IFX_DECT_CSU_ModifyVoice(uiDstHandsetCallHdl, 
                             pxCallParams, IFX_DECT_START_VOICE, 
                             GetDectHwChannel(uiDstHandsetCallHdl);
   // Update state to conversation or active state
   return IFX_SUCCESS;
} //App_CSU_CallAnswer
\endcode
 
 
 \fn e_IFX_Return App_CSU_CallRelease(
                                      IN uint32 uiCallHdl, 
                                      IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                      e_IFX_DECT_RelType eReason,
                                      IN uint32 uiPrivateData)
 \brief  This callback function is used to inform the FT application that the
                   call has been released at the PT.  
 \param[in] uiCallHdl Call Handle of the call 
 \param[in] pxCallParams Reference to call parameters
 \param[in] eReason Reason for release of the call. It may help FT application in
    send out an appropriate message to remote party.
 \param[in] uiPrivateData Reference to the private data handle of the
    FT application. 
 \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING 
 
\code
 
e_IFX_Return App_CSU_CallRelease(
                                 IN uint32 uiSrcCallHdl, 
                                 IN e_IFX_DECT_RelType eReason,
                                 IN uint32 uiPrivateData)
{
    // Stop voice on dect side for handset 1. 
    IFX_DECT_CSU_ModifyVoice(uiSrcHandsetCallHdl, // use the one when called initiate
                             pxCallParams, IFX_DECT_STOP_VOICE, 
                             GetDectHwChannel(uiHandsetSrcCallHdl);
    // Send Release to the destination handset h2
    IFX_DECT_CSU_CallRelease(uiDstHandsetCallHdl,
                             pxCallParams,
                         eReason);
    // Stop voice on dect side for handset 2
  IFX_DECT_CSU_ModifyVoice(uiDstHandsetCallHdl, // use the one when called initiate
                             pxCallParams, IFX_DECT_STOP_VOICE, 
                             GetDectHwChannel(uiDstHandsetCal2Hdl);
   // De-allocate telephony resource [e.g. TAPI]
   // Update state to idle state
   bwideband=0;
   uiSrcHandsetCallHdl=0;
   uiDstHandsetCallHdl=0;
   return IFX_SUCCESS;
} //App_CSU_CallRelease

\endcode
*/
 
e_IFX_Return App_CSU_RegisterCallBks(void);
e_IFX_Return App_CSU_CallInitiate(IN uint32 uiCallHdl, 
                                  IN uchar8 ucHandsetId,
                                  IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                  OUT uchar8 *pucRejectReason,
                                  OUT uint32 *puiPrivateData);
 e_IFX_Return App_CSU_InfoReceived(IN uint32 uiCallHdl,
                                   IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                   IN uint32 uiPrivateData);
e_IFX_Return App_CSU_CallAccept(IN uint32 uiDstCallHdl, 
                                IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                IN uint32 uiPrivateData);
e_IFX_Return App_CSU_CallAnswer(IN uint32 uiCallHdl, 
                                IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                IN uint32 uiPrivateData);
 e_IFX_Return App_CSU_CallRelease(IN uint32 uiCallHdl, 
                                  IN x_IFX_DECT_CSU_CallParams *pxCallParams,
                                  e_IFX_DECT_RelType eReason,
                                  IN uint32 uiPrivateData);
/* @} */ 
 
 /*! \ingroup DECT_TOOLKIT_EXAMPLES
    \defgroup MU_EXAMPLES Management Service Unit
    \brief The section illustrates the example(s) for the Management Service Unit API. 
*/
 
 /* @{  */
 
/*!
 \fn  e_IFX_Return App_MU_RegCallBk()
 \brief This function demonstrates the registration of MU callback functions.
 
\code
e_IFX_Return App_MU_RegCallBk()
{
      x_IFX_DECT_MU_CallBks xMUCbs;
  
      // Fill Reg callback functions
      xMUCbs.pf_MU_NotifyPT = App_MU_Notify;
      xMUCbs.pf_MU_ModemReset = App_MU_ModemReset;
      // Register the callbacks
      IFX_DECT_MU_RegisterCallBks(&xMUCbs);
      return IFX_SUCCESS;
} // App_MU_RegCallBk 
\endcode 

 
 \fn e_IFX_Return App_MU_Notify(
                    IN x_IFX_DECT_MU_NotifyInfo *pxNotifyInfo)
 \param[in] pxNotifyInfo Pointer to the notification information 

 \brief  This callback function is used to inform the FT application of
                   management activity at the PT. 
 
\code
e_IFX_Return App_MU_Notify(
                                IN x_IFX_DECT_MU_NotifyInfo *pxNotifyInfo)
{
      switch(pxNotifyInfo->eEvent)
      {
         case IFX_DECT_MU_REGISTERED:
         {
            // handle Handset registration, use pxNotifyInfo->ucHandSet 
            // to update cfg data base, use codec info to know the 
            // capability, IFX_CIF_DectSubsInfoSet ??
            break;
         }
         case IFX_DECT_MU_ATTACHED:
         {
            // handle Handset attachment, use pxNotifyInfo->ucHandSet 
            // to update cfg data base IFX_CIF_DectSubsInfoSet ??
            break;
         }
         case IFX_DECT_MU_UNREGISTERED:
         {
            // handle Handset unregistration, use pxNotifyInfo->ucHandSet 
            // to update cfg data base 
            break;
         } 
         default:
            break;

      } // switch
   return IFX_SUCCESS;
 } //App_MU_Notify 
\endcode
 
 
 \fn e_IFX_Return App_MU_ModemReset()
 \brief This callback function is invoked by the DECT TK when it receives 
         information on the modem reset status from the DECT Protocol stack 
 
\code
e_IFX_Return App_MU_ModemReset()
{
       // Terminate all DECT calls. send dect on hook indication to
       // all attached handsets (if they have a call)
}
   
\endcode
 
 
 \fn e_IFX_Return App_MU_PrcPageKey(IN uint32 uiPagingKeyPressedDur)
 \brief This function is used to process page key.
 \param[in]  uiPagingKeyPressedDur Page duration
 
 
\code
e_IFX_Return App_MU_PrcPageKey(uint32 uiPagingKeyPressedDur)  // dur in ms)
{
   if( uiPagingKeyPressedDur < 5000) // 5000ms
   {
      uchar8 ucIndex ;
       // Start paging if key press is not identified previously
      if (bPagingOn == TRUE) // assuming bPagingOn holds the status 
      {
         IFX_DECT_MU_PagingStart();
      }
      // Stop paging since key is pressed previously 
      else
      {
        IFX_DECT_MU_PagingStop();
      }
       for(ucIndex = 0; ucIndex < IFX_MMGR_MAX_DECT_CHANNELS; ++ucIndex)
      {
         //for all PP that is attached, initiate/stop paging
      }
   }
   else
   { 
      //Event is for registration
      printf("User Pressed Registration Key. Allowing Registration...." );
      IFX_DECT_MU_AllowRegistration(IFX_DECT_REG_DURATION);
   }
   return IFX_SUCCESS;
} //App_MU_PrcPageKey
 
\endcode
*/
e_IFX_Return App_MU_RegCallBk(void);
e_IFX_Return App_MU_Notify(IN x_IFX_DECT_MU_NotifyInfo *pxNotifyInfo);
e_IFX_Return App_MU_Notify(IN x_IFX_DECT_MU_NotifyInfo *);
e_IFX_Return App_MU_ModemReset(void);
e_IFX_Return App_MU_ModemReset(void);
e_IFX_Return App_MU_PrcPageKey(IN uint32 uiPagingKeyPressedDur);
/* @} */ 
 
 
  /*! \ingroup DECT_TOOLKIT_EXAMPLES
    \defgroup SMSU_EXAMPLES Short Message Service Unit 
    \brief The section illustrates the example(s) for the Short Message Service Unit API. 
 
*/
 /* @{  */
 
/*!
 \fn  e_IFX_Return App_SMSU_RegisterCallBks()
 \brief This function demonstrates the registration of SMSU callback functions.
 
\code
e_IFX_Return App_SMSU_RegisterCallBks()
{
   x_IFX_DECT_SMSU_CallBks xSMSUCbs;

   xSMSUCbs.pf_SMSU_SendMessageOut = App_SMSU_SendMessageOut ;
   xSMSUCbs.pf_SMSU_GetMesg = App_SMSU_GetMesg ;
   xSMSUCbs.pf_SMSU_GetHdrs = App_SMSU_GetHdrs ;
   xSMSUCbs.pf_SMSU_DeleteMesg = App_SMSU_DeleteMesg ;
 
   IFX_DECT_SMSU_RegisterCallBks(&xSMSUCbs);
   IFX_DECT_SMSU_Init();
   return IFX_SUCCESS;
 } // App_SMSU_RegisterCallBks 
\endcode 
 
 
 \fn e_IFX_Return App_MsgRcv(IN uchar8 ucVoipLine)
 \brief This function is called when SMS received from VOIP Line 
 \param[in] ucVoipLine Voip Line Id 
 
\code
e_IFX_Return App_MsgRcv(IN uchar8 ucVoipLine)
{
    e_IFX_Return eRet = IFX_SUCCESS;
    uchar8 ucNoOfHandsets, ucNoOfUnReadMsg;
    char8 aszHandset[6];
    e_IFX_ReasonCode eReason;
    uchar8 ucCnt =0;

    // Get the Number of UnRead messages, 
    // ucNoOfUnReadMsg for the VOIP line the message is received
    ucNoOfUnReadMsg= GetUnReadMsgs(ucVoipLine);

    // Get the associated handset Id list aszHandset[] for 
    // that voice line  and the number of handsets
   // associated with the VOIP line into ucNoOfHandsets
    GetHandsetAssoicatedWithLine(ucVoipLine,aszHandset,&ucNoOfHandsets);

    // Send the alert message to all the associated handsets
    for(ucCnt =0;  ucCnt<ucNoOfHandsets ; ucCnt++) 
    {
        IFX_DECT_SMSU_SendAlert(aszHandset[ucCnt],ucNoOfUnReadMsg);
    }
    return IFX_SUCCESS;
} // App_MsgRcv 
\endcode
 
 
 \fn e_IFX_Return App_SMSU_GetHdrs(
                                   IN uchar8 ucHandSet, 
                                   IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
                                   OUT x_IFX_DECT_SMSU_HeaderBlock *pxHeaders,
                                   OUT uchar8 *pucNoHeaders)
 \brief This callback function is used to inform the FT application that the PT
                   wants to read the header list. 
 \param[in] ucHandSet Handset Number.
 \param[in] eMesgBox Type of message box:Inbox or Outbox.
 \param[out] pxHeaders Pointer to the block of headers.
 \param[out] pucNoHeaders Number of headers in the block.
 \return IFX_SUCCESS or IFX_FAILURE or IFX_PENDING.
 
\code
e_IFX_Return App_SMSU_GetHdrs(
                              IN uchar8 ucHandSet, 
                              IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
                              OUT x_IFX_DECT_SMSU_HeaderBlock *pxHeaders,
                              OUT uchar8 *pucNoHeaders)
{
    uint16 i;
    uchar8 ucVoipLine;
     
    // Get the VOIP line to which this handset is associated
 ucVoipLine = GetAssociatedLine(ucHandset);

    // Update the number of message present in the eMessageBox
 if(eMesgBox == IFX_DECT_SMSU_INBOX)
 {
    // Update the number of messages present in the 
    // inbox of the VOIP line into pucNoHeaders
      *pucNoHeaders = GetMessageCount(ucVoipLine,IFX_DECT_SMSU_INBOX);
   // Update the from address,message preamble and Read status field respectively
      for(i=0;i<*pucNoHeaders;i++) 
      {
        strcpy(pxHeaders[i].aucToFromNumber,
                        GetMessageFromAddr(ucVoipLine,IFX_DECT_SMSU_INBOX,i));
        strncpy(pxHeaders[i].aucMesgPreamble,
                        GetMessagePreamble(ucVoipLine,IFX_DECT_SMSU_INBOX,i), 16);
        pxHeaders[i].ucMesgStatus= 
                      GetMessageReadStatus(ucVoipLine,IFX_DECT_SMSU_INBOX,i);
      }
    }else if(eMesgBox == IFX_DECT_SMSU_OUTBOX){
   
   // Update the number of messages present 
   // in the outbox of the VOIP line into pucNoHeaders
   *pucNoHeaders = GetMessageCount(ucVoipLine,IFX_DECT_SMSU_OUTBOX);
   
   // Update the from address and message preamble field respectively
      for(i=0;i<*pucNoHeaders;i++) 
      {
            strcpy(pxHeaders[i].aucToFromNumber,
                        GetMessageFromAddr(ucVoipLine,IFX_DECT_SMSU_OUTBOX,i));
            strncpy(pxHeaders[i].aucMesgPreamble,
                        GetMessagePreamble(ucVoipLine,IFX_DECT_SMSU_OUTBOX,i),16);
            pxHeaders[i].ucMesgStatus= 
                        GetMessageReadStatus(ucVoipLine,IFX_DECT_SMSU_OUTBOX,i);
     } 
  }
 // similarly update time stamps and other fields of header block
  return IFX_SUCCESS;
} //App_SMSU_GetHdrs 
\endcode
 
 
 
 \fn e_IFX_Return App_SMSU_GetMesg(
                                   IN uchar8 ucHandSet, 
                                   IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
                                   IN uchar8 ucMesgIndex,
                                   OUT x_IFX_DECT_SMSU_Mesg *pxMesg)
 
 \brief This callback function is used to inform the FT application that the PT
                   wants to read the contents of a particular message
 \param[in] ucHandSet Handset Number.
 \param[in] eMesgBox Type of message box:Inbox or Outbox.
 \param[in] ucMesgIndex Message Index.
 \param[out] pxMesg pointer to the requested message.
    \return IFX_SUCCESS or IFX_FAILURE or IFX_PENDING. 
 
\code
 
e_IFX_Return App_SMSU_GetMesg(
                              IN uchar8 ucHandSet, 
                              IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
                              IN uchar8 ucMesgIndex,
                              OUT x_IFX_DECT_SMSU_Mesg *pxMesg)
{
    uchar8 ucVoipLine;
    // Get the VOIP line to which this handset is associated
    ucVoipLine = GetAssociatedLine(ucHandset);
    //Get the message buffer to pxMesg->aucMesgContents and from info to pxMesg->aucToFromNumber
    GetMessageFromLine(ucVoipLine,eMesgBox,pxMesg->acMesgContents);
    pxMesg->ucMesgSize = strlen(pxMesg->acMesgContents);
   // similarly update time stamps and other fields of Message Box
    return IFX_SUCCESS;
} // App_SMSU_GetMesg
  
\endcode
 
 
 \fn e_IFX_Return App_SMSU_SendMessageOut(
                                          IN uchar8 ucHandSet, 
                                          IN x_IFX_DECT_SMSU_Mesg xMesg,
                                          OUT uchar8 *pucMesgIndex)
 \brief This function is used to send the message out.
 \param[in] ucHandSet Handset Number.
 \param[in] xMesg message to be sent out
 \param[out] pucMesgIndex Message Index.
 
\code
 
e_IFX_Return App_SMSU_SendMessageOut(
                                     IN uchar8 ucHandSet, 
                                     IN x_IFX_DECT_SMSU_Mesg xMesg,
                                     OUT uchar8 *pucMesgIndex)
{
    uchar8 ucVoipLine;
    // Get the VOIP line to which this handset is associated
    ucVoipLine = GetAssociatedLine(ucHandset);
    // store the message
    // update the message index  pucMesgIndex
    // Send the message over the VOIP Line
    SendMessageOverLine(ucVoipLine,xMesg,pucMesgIndex);
    return IFX_SUCCESS;
} //App_SMSU_SendMessageOut
  
\endcode
*/

e_IFX_Return App_SMSU_RegisterCallBks();
e_IFX_Return App_MsgRcv(IN uchar8 ucVoipLine);
e_IFX_Return App_SMSU_GetHdrs(IN uchar8 ucHandSet, 
                              IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
                              OUT x_IFX_DECT_SMSU_HeaderBlock *pxHeaders,
                              OUT uchar8 *pucNoHeaders);
e_IFX_Return App_SMSU_GetMesg(IN uchar8 ucHandSet, 
                              IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
                              IN uchar8 ucMesgIndex,
                              OUT x_IFX_DECT_SMSU_Mesg *pxMesg);
e_IFX_Return App_SMSU_SendMessageOut(IN uchar8 ucHandSet, 
                                     IN x_IFX_DECT_SMSU_Mesg xMesg,
                                     OUT uchar8 *pucMesgIndex);
/* @} */ 

/*! \ingroup DECT_TOOLKIT_EXAMPLES
    \defgroup IE_EXAMPLES IE Parser
    \brief The section illustrates the example(s) for the IE Parser API. 
*/
 
/* @{  */
/*!
 \fn  e_IFX_Return AppEncodeIWU(
                                char8 *pcIWU_Data,
                                int32 iIWU_DataLen,
                                uint32 uiIEHdl)
 \brief This function is used encode an IWU message using AddIE.
 \param[in] pcIWU_Data IWU Data 
 \param[in] iIWU_DataLen Data Length of IWU message
 \param[in] uiIEHdl Handle to IE message 
 
\code
uchar8 acBuff[250];
uint32 uiIEHdl = IFX_DECT_IE_CreateNewIE(acBuff);
e_IFX_Return AppEncodeIWU(
                          char8 *pcIWU_Data,
                          int32 iIWU_DataLen,
                          uint32 uiIEHdl)
{
      x_IFX_DECT_IE_IWUToIWUInfo xIWU_Mesg = {0};
      int32 i = 0;
      uchar8 ucOctet4_Bit8 = 1;
      char8 ucDiscType = 1;

      // Fill the IWU message as required some example shown below
      xIWU_Mesg.ucSR = 1;
      xIWU_Mesg.ucPD = 0;
      xIWU_Mesg.ucDefault1 = 1;
      xIWU_Mesg.ucIWUToIWUInfoLen = iIWU_DataLen + 4;
      xIWU_Mesg.acIWUToIWUInfo[0] = ucOctet4_Bit8;
      xIWU_Mesg.acIWUToIWUInfo[0] <<= 7;
      xIWU_Mesg.acIWUToIWUInfo[0] |= ucDiscType;
      xIWU_Mesg.acIWUToIWUInfo[1] = 0x00;//EMC HIGH.
      xIWU_Mesg.acIWUToIWUInfo[2] = 0xC0;//EMC LOW.
      xIWU_Mesg.acIWUToIWUInfo[3] = 1;//Proprietary Type SMS=1
      memcpy((char*)&xIWU_Mesg.acIWUToIWUInfo[4],(char*)pcIWU_Data,iIWU_DataLen);
      IFX_DECT_IE_AddIE(uiIEHdl,IFX_DECT_IE_IWUTOIWU,(void *)&xIWU_Mesg);
      return IFX_SUCCESS;
} // AppEncodeIWU 
\endcode 
 
 
 
 \fn e_IFX_Return App_DecodeIWU (IN uint32 uiIEHdl)
 \brief This function is decode a IWU message using GetIE
 \param[in] uiIEHdl Handle to IE message 
 
\code
 
e_IFX_Return App_DecodeIWU (IN uint32 uiIEHdl)
{
   e_IFX_Return eRet = IFX_SUCCESS;
  x_IFX_DECT_IE_IWUToIWUInfo xIWU_Mesg = {0};
 
   // get the location of IWUtoIWU IE
  while(IFX_DECT_IE_GetIEType(uiIEHdl) != IFX_DECT_IE_IWUTOIWU)
  {
        if(IFX_DECT_IE_GetNextIEHandler(&uiIEHdl) == IFX_FAILURE)
        {
            eRet = IFX_FAILURE;
            break;
        }
  }
  if(IFX_SUCCESS == eRet)
  {
        // Get the IWUtoIWU in structure format
        IFX_DECT_IE_GetIWUToIWUInfo(uiIEHdl,&xIWU_Mesg);
  }
  return eRet;
} //App_DecodeIWU
  
\endcode
*/

e_IFX_Return AppEncodeIWU(char8 *pcIWU_Data,
                          int32 iIWU_DataLen,
                          uint32 uiIEHdl);
e_IFX_Return App_DecodeIWU (IN uint32 uiIEHdl);
/* @} */ 

  
