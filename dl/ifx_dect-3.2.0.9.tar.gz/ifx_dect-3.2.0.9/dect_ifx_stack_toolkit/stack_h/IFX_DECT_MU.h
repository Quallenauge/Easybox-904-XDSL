/**************************************************************************
**   FILE NAME     : IFX_DECT_MU.h
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V2.0 
**   DATE          : 15-12-2008
**   AUTHOR        : VOIP Team.
**   DESCRIPTION   : Function prototypes of MU functions.
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_DECT_MU.h
    \brief This file contains the Management Unit (MU) functions 
                and data structures of DECT Toolkit.  The Management 
                Unit shall be responsible for managing the handsets with 
                respect to several operations involving registration and call setup.
*/

/** \defgroup DECT_TOOLKIT_MODULES Description of Sub-Modules
    \brief This section describes the modules of the DECT Toolkit.
                 The DECT Toolkit is not just an API.  It comprises of a set 
                 of service units.  Hence the name Toolkit.  The service units
                 have DECT protocol intelligence and hide the protocol
                 complexity from the application developers. 
*/
/* @{ */
/* @} */ /* DECT Toolkit Modules */
/*---------- First Level Grouping ---------------------*/

/** \ingroup DECT_TOOLKIT_MODULES
       \defgroup MU_MODULE Management Unit
       \brief The Management Unit manages the mobility management
        needs of a base station.  It provides the fresh registration,
        attachment to handsets and maintains the status of the handset.
        The MU is CAT iq 2.0 compliant.  The MU also supports the easy
        pairing as described in CAT iq 2.0.  The interface provided by the MU is 
        listed in the chapter on Toolkit API.  The examples chapter
        provides source code examples illustrating the usage of the MU
        interfaces.
       
*/
/* @{ */
/* @} */

/** \defgroup DECT_TOOLKIT_API DECT Toolkit API
    \brief This section describes the API provided by different sub-modules 
                of the DECT Toolkit.  This document refers the application
                using the DECT Toolkit as FT application.
                The DECT Toolkit provides easy and simplified interfaces 
                for FT application developers. The DECT toolkit implements 
                services for Call Control, Data channel and SMS.  For services 
                not provided within the DECT toolkit, it provides an Extension 
                service that can be used by the FT application developers to 
                implement their own services.  An Information Element 
                parser/encoder is also provided within the Toolkit for FT 
                application developers, to add and interpret the DECT Protocol IE's.
*/
/* @{ */
/* @} */ /* DECT Toolkit API */
/*---------- First Level Grouping ---------------------*/



#ifndef __IFX_DECT_MU_H__
#define __IFX_DECT_MU_H__

/** \ingroup DECT_TOOLKIT_API
       \defgroup MU_API Management Unit
       \brief This group contains the Management Unit (MU) functions of DECT Toolkit.
           The Management Unit is responsible for managing 6 handset resource and functionalities like\n
		   1> Enabling handset(s) registration.\n
		   2> Handsets location by paging\n
		   3> Maintain handset state and appropriately allow the application to use the states\n
		   4> Manage Line and Call identifications for CatIQ 2.0 features\n
		   5> Other control functionality\n
*/
/* @{ */


/*! \enum e_IFX_DECT_MU_Events
      \brief Enum defining events notified by MU to the FT Application.
*/
typedef enum{
  IFX_DECT_MU_REGISTERED =0,/*!< Handset is Registered*/
  IFX_DECT_MU_UNREGISTERED=1,/*!< Handset is Unregistered*/
  IFX_DECT_MU_ATTACHED=2,/*!< Handset is Attached*/
  IFX_DECT_MU_STOPPED_PAGING=3,/*!< Handset as acknowledged the paging, so stopped paging*/
  IFX_DECT_MU_PROP_INFO=4,/*!< Prop Info arrived in Locate Request */
}e_IFX_DECT_MU_Events;

/*! \enum e_IFX_DECT_MU_TermCap
    \brief This enum defines DECT Terminal Capabilitites 
*/
typedef enum{
  IFX_DECT_MU_HS_CALLWAITTONE =0x1,/*!< Handset supports Call Waiting Tone*/
  IFX_DECT_MU_HS_FULLSLOT =0x2,/*!< Handset supports Full Slot*/
  IFX_DECT_MU_HS_GAP =0x4,/*!< Handset supports only GAP Profile*/
  IFX_DECT_MU_HS_DPRS=0x8,/*!< Handset supports DPRS profile */
  IFX_DECT_MU_HS_NEMO=0x10,/*!< Handset supports No Emisson mode*/
  IFX_DECT_MU_HS_WB=0x20,/*!< Handset supports Wideband Call*/
  IFX_DECT_MU_HS_CAT2=0x40,/*!< Handset supports CATIQ 2.0 features*/
  IFX_DECT_MU_HS_CID=0x80,/*!< Handset supports Call Idenitification */
  IFX_DECT_MU_HS_PCALL=0x100,/*!< Handset supports Paralel Call feature*/
  IFX_DECT_MU_HS_MLINE=0x200,/*!< Handset supports Multiple Line feature*/
  IFX_DECT_MU_HS_HPP=0x400,/*!< Handset supports Headset Management Features*/
  IFX_DECT_MU_HS_ECHO_NA=0x800,/*!< Echo Params - NA */
  IFX_DECT_MU_HS_ECHO_MINTCL=0x1000,/*!< Echo Params - MIN TCL */
  IFX_DECT_MU_HS_ECHO_TCL_46=0x2000,/*!< Echo Params - TCL 46 DB*/
  IFX_DECT_MU_HS_ECHO_TCL_55=0x4000,/*!< Echo Params - TCL 55 DB*/
}e_IFX_DECT_MU_TermCap;


/*!
    \brief Structure containing Notification information passed on to FT application.
*/
typedef struct{
  e_IFX_DECT_MU_Events eEvent;/*!< Event to be notified*/
  uchar8 ucHandSet;/*!< Handset number in the range  1-6 */
  x_IFX_DECT_SubscInfo *pxSubscInfo;/*!< Subscription info valid only in the case of attachment*/
  uchar8 ucCodec_Pri1;/*!< Codec Priority 1*/
  uchar8 ucCodec_Pri2;/*!< Codec Priority 2*/
  uchar8 ucCodec_Pri3;/*!< Codec Priority 3*/
  uint32 uiReserved; /*!< Reserved for Future use*/
  uint32 uiTermCap;/*!< Terminal Capability*/
  uint32 uiIEHdlr; /*!< Prop information IE Handler*/
  uchar8 ucDspLines;/*!< Number of Display Lines*/
  uchar8 ucCharPerLine; /*!< Number of Character per Line*/
}x_IFX_DECT_MU_NotifyInfo;


/*! \brief  This callback function is used to inform the FT application of
                   any activity at the PT.  This callback function
                   is invoked by the DECT TK when it receives information on the
                   registration/attachment status of a PT from the DECT Protocol stack.
*/                   
typedef int32 (*pfn_IFX_DECT_MU_Notify)(IN x_IFX_DECT_MU_NotifyInfo *pxNotifyInfo);

/*! \brief  This callback function is invoked by the DECT TK when it receives information on the
                   modem reset status from the DECT Protocol stack.
*/  
typedef int32 (*pfn_IFX_DECT_MU_ModemReset)();


/*! 
    \brief Structure defining Management Unit Callbacks that are supplied by the FT application.
*/
typedef struct {
	pfn_IFX_DECT_MU_Notify pfn_MU_Notify;/*!< Callback for notifying events
	like Registration/UnRegistration and Attachment*/
	pfn_IFX_DECT_MU_ModemReset pfn_MU_ModemReset;/*!< Callback for notifying a Modem Reset to FT Application, due to which all calls
	and attachment information are lost.*/
  int32 uiReserved; /*!< Reserved For Future Use*/

}x_IFX_DECT_MU_CallBks;

/*! \brief This function is used to register MU Notification Callbacks. This 
                  function is called by the FT application during module initialization. 
                  The Callback functions shall be registered for \n
                  1> Notification of events like Registration/Un-Registration/Attachment and\n
                  2> Notification of modem reset\n
                  The Callbacks shall be invoked by the MU when events like 
                  Registration/Un-Registration/Attachment and modem reset occur.
	       The notification for Registration/Attachment carries status and 
                  capability of handsets. When modem reset event is notified, all 
                  ongoing calls and attachment information are lost.
	 \param[in] pxCCCallBks Pointer to to event notify callback structure
	 \return IFX_SUCCESS or IFX_FAILURE
*/
PUBLIC e_IFX_Return IFX_DECT_MU_CallBksRegister(IN x_IFX_DECT_MU_CallBks *pxCCCallBks);


/*! \brief This function is used to Unregister one or all handsets from 
                    the base. This function is called by the FT application to 
                    terminate the handset from utilizing the FT services. 
                    Upon invocation, the MU unit shall initiate access right 
                    termination procedure for the specified handsets. 
                    The FT application must terminate other services like CSU, DPSU, etc 
                    before invoking this function. 
	 \param[in] isAll True, if registrations need to be erased for all handsets
	 \param[in] ucHandset Handset Number in the range 1-6
    \return  IFX_SUCCESS or IFX_FAILURE
*/
PUBLIC e_IFX_Return IFX_DECT_MU_UNRegister(IN uchar8 isAll,
                                           IN uchar8 ucHandset);

/*! \brief This function is used to register handsets. 
                  This function is called by the FT application to put the
                  DECT stack in subscription mode in order to allow the handsets
                  to register with the base. The FT application shall invoke this
                  function after receiving the input from the paging button to 
                  initiate the subscription interval.  The MU unit shall stop 
                  the registration of the handsets after the specified time 
                  interval or handset registration, which ever is earlier. 
	 \param[in] uiTime Subscription interval time in seconds.
            \param[in] pcBaseName Name of the basestation.
    \return  IFX_SUCCESS or IFX_FAILURE
*/
PUBLIC e_IFX_Return IFX_DECT_MU_RegistrationAllow(IN uint32 uiTime,
                                                  IN char8 * pcBaseName);


/*! \brief This function is used to page all handsets.  Paging is initiated
                   to all the handsets that are not in a call.  This function is called by 
                   the FT application to locate a handset or to verify the 
                   successful registration of handsets.
    \param[in] pcCnip reference to CNIP to be displayed while paging.
	\param[in] pcClip reference to CLIP to be displayed while paging.
    \return  IFX_SUCCESS or IFX_FAILURE
*/
PUBLIC e_IFX_Return IFX_DECT_MU_PageAllHandsets(IN uchar8 *pcCnip, IN uchar8 *pcClip);

/*! \brief This function is used to page a perticular handsets.  Paging is initiated
                   to the handsets if it is not in a call.  This function is called by 
                   the FT application to locate a handset or to verify the 
                   successful registration of handsets.
    \param[in] ucHandset Handset number.
	\param[in] pcCnip reference to CNIP to be displayed while paging.
	\param[in] pcClip reference to CLIP to be displayed while paging.
    \return  IFX_SUCCESS or IFX_FAILURE
*/
PUBLIC e_IFX_Return IFX_DECT_MU_PageHandset(IN uchar8 ucHandset, IN uchar8 *pcCnip,IN uchar8 *pcClip);


/*! \brief This function is used to stop paging a particular handsets.
    \param[in] ucHandset Handset number.
	\return  IFX_SUCCESS or IFX_FAILURE
*/
PUBLIC e_IFX_Return IFX_DECT_MU_StopPagingHandset(IN uchar8 ucHandset);


/*! \brief  This function is used to cancel a paging request.  This function is called by the FT
            application to stop paging process.
	  \return IFX_SUCCESS or IFX_FAILURE
*/
PUBLIC e_IFX_Return IFX_DECT_MU_PageCancel(void);

/*! \brief  This function is used to switch on/off the DECT No Emission feature. 
        \param[in] bOnOff Turn On/Off NEMO. 0 to turn on NEMO, 
                           1 to turn off NEMO
        \return IFX_SUCCESS / IFX_FAILURE
*/                                       
e_IFX_Return IFX_DECT_MU_NemoConfig(IN boolean bOnOff);



/* @} */

#endif /* __IFX_DECT_MU_H__*/

