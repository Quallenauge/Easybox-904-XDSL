/**************************************************************************
**   FILE NAME     : IFX_DECT_IEParser.h
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0
**   DATE          : 26-09-2008
**   AUTHOR        :
**   DESCRIPTION   : Function Prototypes to parse DECT Information Elements
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
***********************************************************************/
/*! \file  IFX_DECT_IEParser.h
    \brief This file contains the Information Elements parsing
                functions.  The functions help in decoding and encoding
                DECT Protocol Information Elements (IEs).
*/
/** \ingroup DECT_TOOLKIT_MODULES
       \defgroup IE_MODULE IE Parser 
       \brief The IE Parser is designed to abstract the DECT protocol
        structures from the application developer.  By encapsulating the 
        protocol complexity within, the IE parser relieves the application
        developer of the nitty-gritties of the IE's, their alignments, default
        values, etc.  The IE parser provides the parsing functionality for 
        approximately 40 IE's.  This set caters to the requirements of a
        CAT iq 2.0 system.  The interface provided by the 
        IE parser is listed in the chapter on Toolkit API.  The examples chapter
        provides source code examples illustrating the usage of the IE parser
        interfaces.
*/
/* @{ */
/* @} */


#ifndef __IFX_DECT_IEPARSER_H__
#define __IFX_DECT_IEPARSER_H__

#ifdef LITTLE_ENDIAN
#undef LITTLE_ENDIAN
#endif

/** \ingroup DECT_TOOLKIT_API
	\defgroup IE_API IE Parser
    \brief This group contains the IE parser functions of the DECT Toolkit. 
                 Parser functions include both encoding and decoding.  
                 Both Little endian and Big endian system needs are addressed within. 
                 The following function set is provided by this group:\n
                 1> Decoding of IEs from the DECT messages\n
                 2> Encoding of IEs to form the DECT messages
 */
/* @{ */

/*! \def IFX_DECT_IE_MAXCODEC
   \brief Macro that specifices the maximum number of Codecs
*/
#define IFX_DECT_IE_MAXCODEC 7

/*! \def IFX_DECT_IE_MAX_IDVALUE_SIZE
   \brief Macro that specifices the maximum size of the Identifier value
*/
#define IFX_DECT_IE_MAX_IDVALUE_SIZE 1

/*! \enum e_IFX_DECT_IE
   \brief Enum containing the IE's first octet value that uniquely identifies it
*/
typedef enum
{
    IFX_DECT_IE_BASICSERVICE = 0XE0,  /*!< Basic Service IE*/
    IFX_DECT_IE_SIGNAL = 0XE4, /*!< Signal IE*/
    IFX_DECT_IE_SINGLEKEYPAD = 0XE9, /*!< Single Keypad IE */
    IFX_DECT_IE_CALLATTRIBUTES = 0X13,/*!< Call Attributes IE */
    IFX_DECT_IE_CALLEDPARTYNUMBER = 0X70,/*!< Called Party Number IE */
    IFX_DECT_IE_CALLINGPARTYNAME = 0X6D,/*!< Calling Party Name IE*/
    IFX_DECT_IE_CONNECTIONATTRIBUTES = 0X17,/*!< Connection Attributes IE */
    IFX_DECT_IE_CONNECTIONIDENTITY = 0X1B,/*!< Connection Identity IE*/
    IFX_DECT_IE_FACILITY = 0X1C,/*!< Facility IE*/
    IFX_DECT_IE_IWUATTRIBUTES = 0X12,/*!< IWU Attributes IE*/
    IFX_DECT_IE_IWUTOIWU = 0X77,/*!< IWU To IWU IE*/
    IFX_DECT_IE_MULTIKEYPAD = 0X2C,/*!< MultiKeypad IE*/
    IFX_DECT_IE_MULTIDISPLAY = 0X28,/*!< Multi Display IE*/
    IFX_DECT_IE_ESCAPETOPROPRIETARY = 0X7B,/*!< Escape To Proprietary IE*/
    IFX_DECT_IE_TIMEDATE = 0X23,/*!< Time Date IE*/
    IFX_DECT_IE_PORTABLEIDENTITY = 0X05,/*!<Portable Identity IE */
    IFX_DECT_IE_FIXEDIDENTITY = 0X06,/*!<Fixed Identity IE */
    IFX_DECT_IE_CALLINGPARTYNUMBER = 0X6C,/*!<Calling Party Number IE */
    IFX_DECT_IE_IWUPACKET = 0X7A,/*!< IWU Packet IE */
    IFX_DECT_IE_CODECLIST = 0X7C,/*!< Codec List IE */
    IFX_DECT_IE_WINDOWSIZE = 0X67,/*!< Window Size IE*/
    IFX_DECT_IE_SINGLEDISPLAY = 0XE8,/*!<Single Display IE */
    IFX_DECT_IE_REPEATINDICATOR = 0XD0, /*!<Repeat Indicator IE, Most significant nibble. Least significant nibble=0  */
    IFX_DECT_IE_PROGRESSINDICATOR = 0X1E,/*!<Progress Indicator IE  */
    IFX_DECT_IE_SERVICECHANGEINFO = 0X16,/*!<Service Change Info IE */
    IFX_DECT_IE_LOCATIONAREA = 0X07,/*!< Location Area IE*/
    IFX_DECT_IE_AUTHTYPE = 0X0A,/*!<Auth type IE*/
    IFX_DECT_IE_CIPHERINFO = 0X19,/*!<Cipher Info IE */
    IFX_DECT_IE_SERVICECLASS = 0X54,/*!<Service Class IE */
    IFX_DECT_IE_SETUPCAPABILITY = 0X62,/*!<Setup Capability IE */
    IFX_DECT_IE_TERMCAPABILITY = 0X63,/*!<Terminal Capability IE */
    IFX_DECT_IE_MODELIDENTIFIER =0X78,/*!<Model Identifier IE */
    IFX_DECT_IE_REJECTREASON = 0X60,/*!<Reject Reason IE */
    IFX_DECT_IE_DURATION = 0X72,/*!<Duration IE */
    IFX_DECT_IE_RAND = 0X0C,/*!<RAND IE  */
    IFX_DECT_IE_RES =0X0D,/*!<Reserved IE  */
    IFX_DECT_IE_RS =0X0E,/*!<RS IE */
    IFX_DECT_IE_USETPUI = 0XA3,/*!< UseTPUI IE */
    IFX_DECT_IE_TIMERRESTART = 0XE5,/*!<Timer Restart IE */
	IFX_DECT_IE_EVENTNOTIFY = 0x7D,/*!< Event Notification IE*/
	IFX_DECT_IE_CALLINFORMATION =0x7E,/*!< Call Information IE*/
    IFX_DECT_IE_NOTIE = 0X00,/*!< Invalid IE */
    IFX_DECT_IE_GENERICIE = 0XFF /*!< IE not in this list */
}e_IFX_DECT_IE;


/*!
    \brief Structure of the Event Type IE
*/
typedef struct
{
    #ifdef LITTLE_ENDIAN
		uchar8 ucEventType:7;/*!< Event Type*/
        uchar8 ucIsEventSubType:1;/*!< Is Event Subtype Exsiting 0-exists, 1-Does not exist*/
        uchar8 ucEventSubType:7;/*!<Event Subtype Exsiting*/
        uchar8 ucDefault1:1;/*!<Default value is 1 */
        uchar8 ucEventMultiFirstByte:7;/*!< Event Multiplicity value, if extension=0 it contains higher byte */
		uchar8 ucEventMultiExtn:1;/*!< Event Multiplicity extends to second byte. 0-extension exist, 1-extension does not exist*/
        uchar8 ucEventMultiSecondByte:8;/*!< Event Multiplicity value, if extension=0 it contains lower byte */
    #else // Big Endian
        uchar8 ucIsEventSubType:1;/*!< Is Event Subtype Exsiting 0-exists, 1-Does not exist*/
		uchar8 ucEventType:7;/*!< Event Type*/
        uchar8 ucDefault1:1;/*!<Default value is 1 */
        uchar8 ucEventSubType:7;/*!<Event Subtype Exsiting*/
		uchar8 ucEventMultiExtn:1;/*!< Event Multiplicity extends to second byte. 0-extension exist, 1-extension does not exist*/
        uchar8 ucEventMultiFirstByte:7;/*!< Event Multiplicity value, if extension=0 it contains higher byte */
        uchar8 ucEventMultiSecondByte:8;/*!< Event Multiplicity value, if extension=0 it contains lower byte */
    #endif
}x_IFX_DECT_IE_EventType;

/*!
    \brief Structure of the Event Notification IE
*/
typedef struct
{
  uchar8 ucNoOfEvents; /*!< Number of Events */
  x_IFX_DECT_IE_EventType axEvent[10]; /*!< Event Type List */
}x_IFX_DECT_IE_EventNotify;

/*!
    \brief Structure defining the Identifier Value
*/
typedef	struct 
{
#ifdef LITTLE_ENDIAN
    uchar8 ucIDValueFirstByte:7;/*!< Identifier value, if extension=0 it contains higher byte */
	uchar8 ucIDValueExtn:1;/*!< Identifier value extends to next byte. 0-extension exist, 1-extension does not exist*/
#else /* BIG_ENDIAN */
    uchar8 ucIDValueExtn:1;/*!< Identifier value extends to next byte. 0-extension exist, 1-extension does not exist*/
    uchar8 ucIDValueFirstByte:7;/*!< Identifier value, if extension=0 it contains higher byte */
#endif     
} x_IFX_DECT_IE_IdValue;            

/*!
    \brief Structure of the CALL Information Type IE
*/
typedef struct
{
    #ifdef LITTLE_ENDIAN
		uchar8 ucIDType:8;/*!< Identifier Type*/
        uchar8 ucIDSubType:8;/*!<Identifier Subtype*/
		x_IFX_DECT_IE_IdValue axIDValue[IFX_DECT_IE_MAX_IDVALUE_SIZE]; /*!<Identifier Value */
    #else // Big Endian
		uchar8 ucIDType:8;/*!< Identifier Type*/
        uchar8 ucIDSubType:8;/*!<Identifier Subtype Exsiting*/
        x_IFX_DECT_IE_IdValue axIDValue[IFX_DECT_IE_MAX_IDVALUE_SIZE]; /*!<Identifier Value */
    #endif
}x_IFX_DECT_IE_CallInfoType;

/*!
    \brief Structure of the Call Information IE
*/
typedef struct
{
  uchar8 ucNoOfIdentifiers;/*!< Number of Identifiers*/
  x_IFX_DECT_IE_CallInfoType axID[10];/*!< List of Identifier*/
}x_IFX_DECT_IE_CallInfo;

/*!
    \brief Structure of the Portable Identity IE
*/

typedef struct
{
    #ifdef LITTLE_ENDIAN
        uchar8 ucType:7;/*!< Identity Type*/
        uchar8 ucDefault1:1;/*!<Default value is 1 */
        uchar8 ucIDValLen:7;/*!< Identity value length */
        uchar8 ucDefault2:1;/*!< Identity Type*/
        uchar8 acIDVal[250];/*!< Identity value length */
    #else // Big Endian
        uchar8 ucDefault1:1;/*!<Default value is 1 */
        uchar8 ucType:7;/*!< Identity Type*/
        uchar8 ucDefault2:1;/*!< Identity Type*/
        uchar8 ucIDValLen:7;/*!< Identity value length */
        uchar8 acIDVal[250];/*!< Identity value length */
    #endif
}x_IFX_DECT_IE_PortableIdentity;


/*! \brief Structure of the Fixed Identity IE
*/

typedef struct
{
    #ifdef LITTLE_ENDIAN
        uchar8 ucType:7;/*!< Identity Type*/
        uchar8 ucDefault1:1;/*!< Default value is 1*/
        uchar8 ucIDValLen:7;/*!< Identity value length*/
        uchar8 ucDefault2:1;/*!< Default value is 1*/
        uchar8 ucARD:4;/*!< Access Right Details*/
        uchar8 ucARC:3;/*!< Access Rights Coding*/
        uchar8 ucDefault3:1;/*!<Default value is 0 */
        uchar8 acARD_RPN[250];/*!< ARD and RPN(Radio Fixed Part) array  */
    #else  
        uchar8 ucDefault1:1; /*!< Default value is 1*/
        uchar8 ucType:7; /*!< Identity Type*/
        uchar8 ucDefault2:1; /*!< Default value is 1*/
        uchar8 ucIDValLen:7; /*!< Identity value length*/
        uchar8 ucDefault3:1; /*!<Default value is 0 */
        uchar8 ucARC:3; /*!< Access Rights Coding*/
        uchar8 ucARD:4; /*!< Access Right Details*/
        uchar8 acARD_RPN[250]; /*!< ARD and RPN(Radio Fixed Part) array  */
    #endif
}x_IFX_DECT_IE_FixedIdentity;

 
/*! \brief Structure of the Basic Service IE 
*/

typedef struct
{
    #ifdef LITTLE_ENDIAN
        uchar8 ucBasicService:4;             /*!<Basic Service*/
        uchar8 ucCallClass:4;                /*!< Call Class */
    #else //Big Endian
        uchar8 ucCallClass:4; /*!< Call Class */
        uchar8 ucBasicService:4; /*!<Basic Service*/
    #endif
}x_IFX_DECT_IE_BasicService;

/*! \brief Structure of the Calling Party Number IE
*/
  
typedef struct
{
    #ifdef LITTLE_ENDIAN
        uchar8 ucNPI:4; /*!< Numbering Plan Identification */
        uchar8 ucNumberType:3; /*!<Number Type */
        uchar8 ucExtn3:1;/*!< Extension bit for octet 3 - Value 0 => next octet of the octet group is present */
        uchar8 ucSI:2;/*!<Screening Indicator */
        uchar8 ucSpare:3;/*!<Spare bits */
        uchar8 ucPI:2;/*!<Present Indicator */
        uchar8 ucExtn3a:1;/*!< Extn bit for octet 3a - Default value is 1  */
        uchar8 acCPA[250];/*!< Calling Party Address */
        uchar8 ucCPALen;/*!< Calling Party Address Length */
    #else
        uchar8 ucExtn3:1; /*!< Extension bit for octet 3 - Value 0 => next octet of the octet group is present */
        uchar8 ucNumberType:3; /*!<Number Type */
        uchar8 ucNPI:4; /*!< Numbering Plan Identification */
        uchar8 ucExtn3a:1; /*!< Extn bit for octet 3a - Default value is 1  */
        uchar8 ucPI:2; /*!<Present Indicator */
        uchar8 ucSpare:3; /*!<Spare bits */
        uchar8 ucSI:2; /*!<Screening Indicator */
        uchar8 acCPA[250]; /*!< Calling Party Address */
        uchar8 ucCPALen; /*!< Calling Party Address Length */
#endif
}x_IFX_DECT_IE_CallingPartyNumber;

/*! \brief Structure of the Called Party Number IE
*/

typedef struct
{
    #ifdef LITTLE_ENDIAN
        uchar8 ucNPI:4;/*!< Numbering Plan Identification*/
        uchar8 ucNumberType:3;/*!< Number Type*/
        uchar8 ucDefault1:1;/*!< Default value is 1 */
        uchar8 acCPA[250];/*!< Called Party Address*/
        uchar8 ucCPALen;/*!< Called Party Address length */
    #else //Big Endian
        uchar8 ucDefault1:1; /*!< Default value is 1 */
        uchar8 ucNumberType:3; /*!< Number Type*/
        uchar8 ucNPI:4; /*!< Numbering Plan Identification*/
        uchar8 acCPA[250]; /*!< Called Party Address*/
        uchar8 ucCPALen; /*!< Called Party Address length */
    #endif
}x_IFX_DECT_IE_CalledPartyNumber;

/*! \brief Structure containing fields contents of IWU-TO-IWU IE
*/

typedef struct
{
    #ifdef LITTLE_ENDIAN
        uchar8 ucPD:6;/*!<Protocol Discriminator */
        uchar8 ucSR:1;/*!< Send/Reject bit */
        uchar8 ucDefault1:1;/*!< Default value is 1*/
        uchar8 acIWUToIWU[250];/*!< IWU To IWU Information */
        uchar8 ucIWUToIWULen;/*!< IWU To IWU Information length */
    #else
        uchar8 ucDefault1:1; /*!< Default value is 1*/
        uchar8 ucSR:1; /*!< Send/Reject bit */
        uchar8 ucPD:6; /*!<Protocol Discriminator */
        uchar8 acIWUToIWU[250]; /*!< IWU To IWU Information */
        uchar8 ucIWUToIWULen; /*!< IWU To IWU Information length */
    #endif
}x_IFX_DECT_IE_IWUToIWU;

/*! \brief Structure containing fields contents of each Codec 
*/

#ifdef LITTLE_ENDIAN
typedef struct
{
    uchar8 ucCIdf:7;/*!< Codec Identifier */
    uchar8 ucExtn:1;/*!<Extn bit for octet k - Value 0 */
    uchar8 ucMDS:4;/*!< MAC and DLC Service*/
    uchar8 ucReserved2:3;/*!<Reserve bits */
    uchar8 ucExtna:1;/*!<Extn bit for octet ka - value 0*/
    uchar8 ucSS:4;/*!<Slot Size */
    uchar8 ucCPR:3;/*!< C-Plane Routing */
    uchar8 ucExtnb:1;/*!<Extn bit for octet kb - Value 0 or 1 */
}x_IFX_DECT_IE_CodecList_SS;
#else
typedef struct
{
    uchar8 ucExtn:1; /*!<Extn bit for octet k - Value 0 */
    uchar8 ucCIdf:7; /*!< Codec Identifier */
    uchar8 ucExtna:1; /*!<Extn bit for octet ka - value 0*/
    uchar8 ucReserved2:3; /*!<Reserve bits */
    uchar8 ucMDS:4; /*!< MAC and DLC Service*/
    uchar8 ucExtnb:1; /*!<Extn bit for octet kb - Value 0 or 1 */
    uchar8 ucCPR:3; /*!< C-Plane Routing */
    uchar8 ucSS:4; /*!<Slot Size */
}x_IFX_DECT_IE_CodecList_SS;
#endif

/*! \brief Structure of the Codec List IE
*/
typedef struct 
{
#ifdef LITTLE_ENDIAN
    uchar8 ucReserved1:4;/*!< Reserve bits*/
    uchar8 ucNI:3;/*!< Negotiation Indicator*/
    uchar8 ucDefault1:1;/*!<Default value is 1 */
    x_IFX_DECT_IE_CodecList_SS xCodecListSS[IFX_DECT_IE_MAXCODEC];/*!<Codec structure*/
    uchar8 ucNumCodecs;/*!< Number of Codecs */
#else
    uchar8 ucDefault1:1; /*!<Default value is 1 */
    uchar8 ucNI:3; /*!< Negotiation Indicator*/
    uchar8 ucReserved1:4; /*!< Reserve bits*/
    x_IFX_DECT_IE_CodecList_SS xCodecListSS[IFX_DECT_IE_MAXCODEC]; /*!<Codec structure*/
    uchar8 ucNumCodecs; /*!< Number of Codecs */
#endif
}x_IFX_DECT_IE_CodecList;

/*! \brief Structure of the IWU-Packet IE
*/
typedef struct
{
#ifdef LITTLE_ENDIAN
    uchar8 ucL2PID:5;/*!< L2 Protocol ID*/
    uchar8 ucDefault1:1;/*!<Spare bit */
    uchar8 ucSR:1;/*!<Send/Reject bit */
    uchar8 ucExtn3:1;/*!<Extn bit for octet 3 - Value 0 => next octet of the octet group is present */
    uchar8 ucL3PID:5;/*!< L3 Protocol ID */
    uchar8 ucDefault2:2;/*!< Default value is 3 */
    uchar8 ucExtn3a:1;/*!< Extn bit for octet 3a - Default value is 1*/
    uchar8 acIWUP[250];/*!<IWU Packet Information */
    uchar8 ucIWUPLen;/*!< IWU Packet Information Length*/
#else
    uchar8 ucExtn3:1; /*!<Extn bit for octet 3 - Value 0 => next octet of the octet group is present */
    uchar8 ucSR:1; /*!<Send/Reject bit */
    uchar8 ucDefault1:1; /*!<Spare bit */
    uchar8 ucL2PID:5; /*!< L2 Protocol ID*/
    uchar8 ucExtn3a:1; /*!< Extn bit for octet 3a - Default value is 1*/
    uchar8 ucDefault2:2; /*!< Default value is 3 */
    uchar8 ucL3PID:5; /*!< L3 Protocol ID */
    uchar8 acIWUP[250]; /*!<IWU Packet Information */
    uchar8 ucIWUPLen; /*!< IWU Packet Information Length*/
#endif
}x_IFX_DECT_IE_IWUPacket;

/*! \brief Structure of the Escape to Proprietary IE  
*/

typedef struct
{
#ifdef LITTLE_ENDIAN
    uchar8 ucDT:7;/*!< Discriminator Type*/
    uchar8 ucDefault1:1;/*!< Default value is 1*/
    uchar8 acUSC[250];/*!<User Specific Contents */
    uchar8 ucUSCLen;/*!< User Specific Contents Length*/
#else
    uchar8 ucDefault1:1; /*!< Default value is 1*/
    uchar8 ucDT:7; /*!< Discriminator Type*/
    uchar8 acUSC[250]; /*!<User Specific Contents */
    uchar8 ucUSCLen; /*!< User Specific Contents Length*/
#endif
}x_IFX_DECT_IE_EscapeToProprietary;

/*! \brief Structure of the Calling Party Name IE
*/

typedef struct
{
#ifdef LITTLE_ENDIAN
    uchar8 ucSI:2;/*!< Screening Indicator*/
    uchar8 ucUA:3;/*!< Used Alphabet*/
    uchar8 ucPI:2;/*!< Present Indicator */
    uchar8 ucDefault1:1;/*!<Default value is 0 */
    uchar8 acCPN[250];/*!< Calling Party Name*/
    uchar8 ucCPNLen;/*!<Calling Party Name Length */
#else
    uchar8 ucDefault1:1; /*!<Default value is 0 */
    uchar8 ucPI:2; /*!< Present Indicator */
    uchar8 ucUA:3; /*!< Used Alphabet*/
    uchar8 ucSI:2; /*!< Screening Indicator*/
    uchar8 acCPN[250]; /*!< Calling Party Name*/
    uchar8 ucCPNLen; /*!<Calling Party Name Length */
#endif
}x_IFX_DECT_IE_CallingPartyName;

/*! \brief Structure of the Window Size IE 
*/

typedef struct
{
#ifdef LITTLE_ENDIAN
    uchar8 ucWSVF:7;/*!< Window Size Value (Forward)*/
    uchar8 ucExtn3:1;/*!< Extn bit for octet 3 - Default value is 0*/
    uchar8 ucWSVC:7;/*!<Window Size Value continue*/
    uchar8 ucExtn3a:1;/*!< Extn bit for octet 3a - Value 0 => next octet of the octet group is present*/
    uchar8 ucMPDULF:7;/*!< Maximum Protocol Data Unit Length (Forward)*/
    uchar8 ucExtn3b:1;/*!< Extn bit for octet 3b - Value 0 => next octet of the octet group is present*/
    uchar8 ucSDULAPUTF:7;/*!< Service Data Unit LAPU Timer (Forward) */
    uchar8 ucExtn3c:1;/*!<Extn bit for octet 3c - Default value is 1 */
    uchar8 ucWSVB:7;/*!<Window Size Value (Backward) */
    uchar8 ucExtn4:1;/*!< Extn bit for octet 4 - Default value is 0 */
    uchar8 ucWSVCB:7;/*!< Window size value continue */
    uchar8 ucExtn4a:1;/*!<Extn bit for octet 4a - Value 0 => next octet of the octet group is present */
    uchar8 ucMPDULB:7;/*!< Maximum Protocol Data Unit Length (Backward) */
    uchar8 ucExtn4b:1;/*!<Extn bit for octet 4b - Value 0 => next octet of the octet group is present */
    uchar8 ucSDULAPUTB:7;/*!< Service Data Unit LAPU Timer (Backward) */
    uchar8 ucExtn4c:1;/*!<Extn bit for octet 4c - Default value is 1 */
    uchar8 ucOctet4;/*!< Flag to denote the presence of octet 4*/
#else
    uchar8 ucExtn3:1; /*!< Extn bit for octet 3 - Default value is 0*/
    uchar8 ucWSVF:7; /*!< Window Size Value (Forward)*/
    uchar8 ucExtn3a:1; /*!< Extn bit for octet 3a - Value 0 => next octet of the octet group is present*/
    uchar8 ucWSVC:7; /*!<Window Size Value continue*/
    uchar8 ucExtn3b:1; /*!< Extn bit for octet 3b - Value 0 => next octet of the octet group is present*/
    uchar8 ucMPDULF:7; /*!< Maximum Protocol Data Unit Length (Forward)*/
    uchar8 ucExtn3c:1; /*!<Extn bit for octet 3c - Default value is 1 */
    uchar8 ucSDULAPUTF:7; /*!< Service Data Unit LAPU Timer (Forward) */
    uchar8 ucExtn4:1; /*!< Extn bit for octet 4 - Default value is 0 */
    uchar8 ucWSVB:7; /*!<Window Size Value (Backward) */
    uchar8 ucExtn4a:1; /*!<Extn bit for octet 4a - Value 0 => next octet of the octet group is present */
    uchar8 ucWSVCB:7; /*!< Window size value continue */
    uchar8 ucExtn4b:1; /*!<Extn bit for octet 4b - Value 0 => next octet of the octet group is present */
    uchar8 ucMPDULB:7; /*!< Maximum Protocol Data Unit Length (Backward) */
    uchar8 ucExtn4c:1; /*!<Extn bit for octet 4c - Default value is 1 */
    uchar8 ucSDULAPUTB:7; /*!< Service Data Unit LAPU Timer (Backward) */
    uchar8 ucOctet4; /*!< Flag to denote the presence of octet 4*/
#endif
}x_IFX_DECT_IE_WindowSize;

/*! \brief Structure of the Call Attributes IE
*/

typedef struct
{
#ifdef LITTLE_ENDIAN
    uchar8 ucNWKLA:5;/*!< Network Layer Attributes */
    uchar8 ucCS:2;/*!< Coding Standard*/
    uchar8 ucDefault1:1;/*!< Default value is 1*/
    uchar8 ucCPR:4;/*!< C-Plane Routing*/
    uchar8 ucCPC:3;/*!<C-Plane Class */
    uchar8 ucDefault2:1;/*!<Default value is 1 */
    uchar8 ucLUID:5;/*!<LU Identification */
    uchar8 ucUPS:2;/*!<U-Plane Symmetry */
    uchar8 ucExtn5:1;/*!<Extn bit for octet 5 - Value 0 => next octet of the octet group is present */
    uchar8 ucLUIDFTP:5;/*!< LU Plane Identification F=>P Direction*/
    uchar8 ucS:2;/*!< Spare */
    uchar8 ucExtn5a:1;/*!<Extn bit for octet 5a -  Default value is 1 */
    uchar8 ucUPFT:4;/*!< U-Plane Frame Type */
    uchar8 ucUPC:3;/*!< U-Plane Class */
    uchar8 ucExtn6:1;/*!<Extn bit for octet 6 - Value 0 => next octet of the octet group is present */
    uchar8 ucUPFTFTP:4;/*!<U-Plane Frame Type F=>P */
    uchar8 ucUPCFTP:3;/*!<U-Plane Class F=>P */
    uchar8 ucExtn6a:1;/*!<Default value is 1 */
#else
    uchar8 ucDefault1:1; /*!< Default value is 1*/
    uchar8 ucCS:2; /*!< Coding Standard*/
    uchar8 ucNWKLA:5; /*!< Network Layer Attributes */
    uchar8 ucDefault2:1; /*!<Default value is 1 */
    uchar8 ucCPC:3; /*!<C-Plane Class */
    uchar8 ucCPR:4; /*!< C-Plane Routing*/
    uchar8 ucExtn5:1; /*!<Extn bit for octet 5 - Value 0 => next octet of the octet group is present */
    uchar8 ucUPS:2; /*!<U-Plane Symmetry */
    uchar8 ucLUID:5; /*!<LU Identification */
    uchar8 ucExtn5a:1; /*!<Extn bit for octet 5a -  Default value is 1 */
    uchar8 ucS:2; /*!< Spare */
    uchar8 ucLUIDFTP:5; /*!< LU Plane Identification F=>P Direction*/
    uchar8 ucExtn6:1; /*!<Extn bit for octet 6 - Value 0 => next octet of the octet group is present */
    uchar8 ucUPC:3; /*!< U-Plane Class */
    uchar8 ucUPFT:4; /*!< U-Plane Frame Type */
    uchar8 ucExtn6a:1; /*!<Default value is 1 */
    uchar8 ucUPCFTP:3; /*!<U-Plane Class F=>P */
    uchar8 ucUPFTFTP:4; /*!<U-Plane Frame Type F=>P */
#endif
}x_IFX_DECT_IE_CallAttributes;

/*! \brief Structure of the Connection Attributes IE
*/

typedef struct
{
#ifdef LITTLE_ENDIAN
    uchar8 ucCID:4;/*!< Connection Identity*/ 
    uchar8 ucSymmetry:3;/*!< Symmetry*/
    uchar8 ucDefault1:1;/*!<Default value is 1 */
    uchar8 ucTBPFD:5;/*!<Target Bearers P=>F Direction */
    uchar8 ucDefault2:2;/*!<Default value is 0 */
    uchar8 ucExtn4:1;/*!<Extn bit for octet 4 - Value 0 => next octet of the octet group is present*/
    uchar8 ucMBPFD:5;/*!<Minimum Bearers P=>F Direction */
    uchar8 ucDefault3:2;/*!<Default value is 1 */
    uchar8 ucExtn4a:1;/*!<Extn bit for octet 4a - Value 0 => next octet of the octet group is present */
    uchar8 ucTBFPD:5;/*!< Target Bearers F=>P Direction */
    uchar8 ucDefault4:2;/*!<Default value is 2 */
    uchar8 ucExtn4b:1;/*!<Extn bit for octet 4b - Value 0 => next octet of the octet group is present */
    uchar8 ucMBFPD:5;/*!<Minimum Bearers F=>P Direction */
    uchar8 ucDefault5:2;/*!<Default value is 3 */
    uchar8 ucExtn4c:1;/*!<Extn bit for octet 4c - Value 0 => next octet of the octet group is present */
    uchar8 ucMACS:4;/*!< MAC Service*/
    uchar8 ucSS:3;/*!< Slot Size */
    uchar8 ucExtn5:1;/*!<Extn bit for octet 5 - Value 0 => next octet of the octet group is present */
    uchar8 ucMACSFP:4;/*!<MAC Service F=>P */
    uchar8 ucDefault6:3;/*!< Default value is 0 */
    uchar8 ucExtn5a:1;/*!<Extn bit for octet 5a - Value 0 => next octet of the octet group is present */
    uchar8 ucMACPL:4;/*!<MAC Packet Lifetime */
    uchar8 ucCFCA:3;/*!<CF Channel Attributes */
    uchar8 ucExtn6:1;/*!<Extn bit for octet 6 - Value 0 => next octet of the octet group is present */
    uchar8 ucMACPLFP:4;/*!<MAC Packet Lifetime F=>P */
    uchar8 ucCFCAFP:3;/*!< CF Channel Attributes f=>P */
    uchar8 ucExtn6a:1;/*!<Extn bit for octet 6a - Default value is 1 */
    uchar8 ucBA:3;/*!<B Attributes */
    uchar8 ucSpare:1;/*!<Spare bits*/
    uchar8 ucAA:3;/*!< A Attributes*/
    uchar8 ucExtn7:1;/*!<Extn bit for octet 7 - Value 0 => next octet of the octet group is present */
#else
    uchar8 ucDefault1:1; /*!<Default value is 1 */
    uchar8 ucSymmetry:3; /*!< Symmetry*/
    uchar8 ucCID:4; /*!< Connection Identity*/ 
    uchar8 ucExtn4:1; /*!<Extn bit for octet 4 - Value 0 => next octet of the octet group is present*/
    uchar8 ucDefault2:2; /*!<Default value is 0 */
    uchar8 ucTBPFD:5; /*!<Target Bearers P=>F Direction */
    uchar8 ucExtn4a:1; /*!<Extn bit for octet 4a - Value 0 => next octet of the octet group is present */
    uchar8 ucDefault3:2; /*!<Default value is 1 */
    uchar8 ucMBPFD:5; /*!<Minimum Bearers P=>F Direction */
    uchar8 ucExtn4b:1; /*!<Extn bit for octet 4b - Value 0 => next octet of the octet group is present */
    uchar8 ucDefault4:2; /*!<Default value is 2 */
    uchar8 ucTBFPD:5; /*!< Target Bearers F=>P Direction */ 
    uchar8 ucExtn4c:1; /*!<Extn bit for octet 4c - Value 0 => next octet of the octet group is present */ 
    uchar8 ucDefault5:2; /*!<Default value is 3 */
    uchar8 ucMBFPD:5; /*!<Minimum Bearers F=>P Direction */
    uchar8 ucExtn5:1; /*!<Extn bit for octet 5 - Value 0 => next octet of the octet group is present */
    uchar8 ucSS:3; /*!< Slot Size */
    uchar8 ucMACS:4; /*!< MAC Service*/
    uchar8 ucExtn5a:1; /*!<Extn bit for octet 5a - Value 0 => next octet of the octet group is present */
    uchar8 ucDefault6:3; /*!< Default value is 0 */
    uchar8 ucMACSFP:4; /*!<MAC Service F=>P */
    uchar8 ucExtn6:1; /*!<Extn bit for octet 6 - Value 0 => next octet of the octet group is present */
    uchar8 ucCFCA:3; /*!<CF Channel Attributes */
    uchar8 ucMACPL:4; /*!<MAC Packet Lifetime */
    uchar8 ucExtn6a:1; /*!<Extn bit for octet 6a - Default value is 1 */
    uchar8 ucCFCAFP:3; /*!< CF Channel Attributes f=>P */
    uchar8 ucMACPLFP:4; /*!<MAC Packet Lifetime F=>P */ 
    uchar8 ucExtn7:1;  /*!<Extn bit for octet 7 - Value 0 => next octet of the octet group is present */
    uchar8 ucAA:3; /*!< A Attributes*/
    uchar8 ucSpare:1;  /*!<Spare bits*/
    uchar8 ucBA:3; /*!<B Attributes */
#endif
}x_IFX_DECT_IE_ConnectionAttributes;


/*! \brief Structure of the Facility IE
*/

typedef struct
{
#ifdef LITTLE_ENDIAN
    uchar8 ucSD:5;/*!< Service Discriminator*/
    uchar8 ucDefault1:2;/*!< Default value is 0*/
    uchar8 ucDefault2:1;/*!< Default value is 1*/
    uchar8 ucComponents;/*!< Component(s)*/
#else
    uchar8 ucDefault2:1; /*!< Default value is 1*/
    uchar8 ucDefault1:2; /*!< Default value is 0*/
    uchar8 ucSD:5; /*!< Service Discriminator*/
    uchar8 ucComponents; /*!< Component(s)*/
#endif
}x_IFX_DECT_IE_Facility;


/*! \brief Structure of the MultiDisplay IE
*/

typedef struct
{
    uchar8 acDisplay[250];/*!< List of Display Information (DECT Characters)*/
    uchar8 ucDisplayLen;/*!< Length of acDisplay array*/
}x_IFX_DECT_IE_MultiDisplay;


/*! \brief Structure of the MultiKeypad IE
*/

typedef struct
{
    uchar8 acKeypad[250];/*!<List of Keypad Information (DECT Characters) */
    uchar8 ucKeypadLen;/*!< Length of acKeypad array */
}x_IFX_DECT_IE_MultiKeypad;


/*! \brief Structure of the Connection Identity IE
*/

typedef struct
{
#ifdef LITTLE_ENDIAN
    uchar8 ucCID:4;/*!<Connection Identity */
    uchar8 ucUPLID:4;/*!< U-Plane Link Identity*/
    uchar8 ucLCA;/*!<List of other U-Plane connection associations */
#else
    uchar8 ucUPLID:4; /*!< U-Plane Link Identity*/
    uchar8 ucCID:4; /*!<Connection Identity */
    uchar8 ucLCA; /*!<List of other U-Plane connection associations */
#endif
}x_IFX_DECT_IE_ConnectionIdentity;


/*! \brief Structure of the Progress Indicator IE
*/

typedef struct
{
#ifdef LITTLE_ENDIAN
    uchar8 ucLocation:4;/*!< Location*/
    uchar8 ucDefault1:1;/*!<Default value is 0 */
    uchar8 ucCS:2;/*!<Coding Standard*/
    uchar8 ucDefault2:1;/*!<Default value is 1 */
    uchar8 ucPD:7;/*!<Progress Description */
    uchar8 ucDefault3:1;/*!<Default value is 1 */
#else
    uchar8 ucDefault2:1; /*!<Default value is 1 */
    uchar8 ucCS:2; /*!<Coding Standard*/
    uchar8 ucDefault1:1; /*!<Default value is 0 */
    uchar8 ucLocation:4; /*!< Location*/
    uchar8 ucDefault3:1; /*!<Default value is 1 */
    uchar8 ucPD:7; /*!<Progress Description */
#endif
}x_IFX_DECT_IE_ProgressIndicator;


/*! \brief Structure of the Service Change  IE
*/

typedef struct
{
#ifdef LITTLE_ENDIAN
    uchar8 ucChangeMode:4;/*!< Change Mode */
    uchar8 ucM:1;/*!< Master Coding*/
    uchar8 ucCS:2;/*!<Coding Standard */
    uchar8 ucExtn3:1;/*!<Extn bit for octet 3 - Value 0 => next octet of the octet group is present */
    uchar8 ucECM:7;/*!< Extended Change Mode*/
    uchar8 ucExtn3a:1;/*!<Extn bit for octet 3a -  Default value is 1*/
    uchar8 ucBA:3;/*!< B Attributes*/
    uchar8 ucR:1;/*!< Reset coding*/
    uchar8 ucAA:3;/*!< A Attributes*/
    uchar8 ucDefault1:1;/*!< Default value is 1*/
#else
    uchar8 ucExtn3:1; /*!<Extn bit for octet 3 - Value 0 => next octet of the octet group is present */
    uchar8 ucCS:2; /*!<Coding Standard */
    uchar8 ucM:1; /*!< Master Coding*/
    uchar8 ucChangeMode:4; /*!< Change Mode */
    uchar8 ucExtn3a:1; /*!<Extn bit for octet 3a -  Default value is 1*/
    uchar8 ucECM:7; /*!< Extended Change Mode*/
    uchar8 ucDefault1:1; /*!< Default value is 1*/
    uchar8 ucAA:3; /*!< A Attributes*/
    uchar8 ucR:1; /*!< Reset coding*/
    uchar8 ucBA:3; /*!< B Attributes*/
#endif
}x_IFX_DECT_IE_ServiceChange;


/*! \brief Structure of the TimeDate IE
*/

typedef struct
{
#ifdef LITTLE_ENDIAN
    uchar8 ucInterpretation:6;/*!< Interpretation*/
    uchar8 ucCoding:2;/*!<Coding */
    uchar8 acTimeDate[250];/*!< Time and Date Information*/
    uchar8 ucTimeDateLen;/*!<Time and Date Information Length */
#else
    uchar8 ucCoding:2; /*!<Coding */
    uchar8 ucInterpretation:6; /*!< Interpretation*/
    uchar8 acTimeDate[250]; /*!< Time and Date Information*/
    uchar8 ucTimeDateLen; /*!<Time and Date Information Length */
#endif
}x_IFX_DECT_IE_TimeDate;


/*! \brief Structure of the Location Area IE
*/

typedef struct
{
#ifdef LITTLE_ENDIAN
    uchar8 ucLAL:6;/*!< Location Area Level*/
    uchar8 ucLIType:2;/*!< Location Information Type*/
    uchar8 ucELI1:4;/*!<Extended Location Information most significant bits */
    uchar8 ucELIType:4;/*!< Extended Location Information Type */
    uchar8 ucMCCDigit1:4;/*!< Mobile Country Code Digit 1*/
    uchar8 ucMCCDigit2:4;/*!< Mobile Country Code Digit 2*/
    uchar8 ucMCCDigit3:4;/*!< Mobile Country Code Digit 3*/
    uchar8 ucDefault1:4;/*!< Default value is 15*/
    uchar8 ucMNCDigit1:4;/*!<Mobile Network Code Digit 1 */
    uchar8 ucMNCDigit2:4;/*!<Mobile Network Code Digit 2 */
    uchar8 ucLAC;/*!<Location Area Code */
    uchar8 ucLACCont;/*!< Location Area Code Continued */
    uchar8 ucCI;/*!<Cell Identity */
    uchar8 ucCICont;/*!< Cell Identity Continued*/
#else 
    uchar8 ucLIType:2; /*!< Location Information Type*/
    uchar8 ucLAL:6; /*!< Location Area Level*/
    uchar8 ucELIType:4; /*!< Extended Location Information Type */
    uchar8 ucELI1:4; /*!<Extended Location Information most significant bits */
    uchar8 ucMCCDigit2:4; /*!< Mobile Country Code Digit 2*/
    uchar8 ucMCCDigit1:4; /*!< Mobile Country Code Digit 1*/
    uchar8 ucDefault1:4; /*!< Default value is 15*/
    uchar8 ucMCCDigit3:4; /*!< Mobile Country Code Digit 3*/
    uchar8 ucMNCDigit2:4; /*!<Mobile Network Code Digit 2 */
    uchar8 ucMNCDigit1:4; /*!<Mobile Network Code Digit 1 */
    uchar8 ucLAC;  /*!<Location Area Code */
    uchar8 ucLACCont; /*!< Location Area Code Continued */
    uchar8 ucCI; /*!<Cell Identity */
    uchar8 ucCICont; /*!< Cell Identity Continued*/
#endif
}x_IFX_DECT_IE_LocationArea;


/*! \brief Structure of the Auth Type  IE
*/

typedef struct
{
#ifdef LITTLE_ENDIAN
    uchar8 ucAAI;/*!< Authentication Algorithm Identifier*/
    uchar8 ucPAI;/*!<Proprietary Algorithm Identifier*/
    uchar8 ucAKN:4;/*!< Authentication Key Number*/
    uchar8 ucAKT:4;/*!< Authentication Key Type*/
    uchar8 ucCKN:4;/*!< Cipher Key Number*/
    uchar8 ucUPC:1;/*!< UPC bit */
    uchar8 ucTXC:1;/*!< TXC bit */
    uchar8 ucDefault1:1;/*!< Default value is 0*/
    uchar8 ucINC:1;/*!<INC bit */
#else 
    uchar8 ucAAI; /*!< Authentication Algorithm Identifier*/
    uchar8 ucPAI; /*!<Proprietary Algorithm Identifier*/
    uchar8 ucAKT:4; /*!< Authentication Key Type*/
    uchar8 ucAKN:4; /*!< Authentication Key Number*/
    uchar8 ucINC:1; /*!<INC bit */ 
    uchar8 ucDefault1:1; /*!< Default value is 0*/
    uchar8 ucTXC:1; /*!< TXC bit */
    uchar8 ucUPC:1; /*!< UPC bit */
    uchar8 ucCKN:4; /*!< Cipher Key Number*/
#endif
}x_IFX_DECT_IE_AuthType;


/*! \brief Structure of the Cipher  IE
*/

typedef struct
{
#ifdef LITTLE_ENDIAN
    uchar8 ucCAI:7;/*!<Cipher Algorithm Identifier*/
    uchar8 ucYN:1;/*!<Disable/Enable Ciphering*/
    uchar8 ucPAI;/*!< Proprietary Algorithm Identifier*/
    uchar8 ucCKN:4;/*!<Cipher Key Number */
    uchar8 ucCKT:4;/*!<Cipher Key Type*/
#else
    uchar8 ucYN:1; /*!<Disable/Enable Ciphering*/
    uchar8 ucCAI:7; /*!<Cipher Algorithm Identifier*/
    uchar8 ucPAI; /*!< Proprietary Algorithm Identifier*/
    uchar8 ucCKT:4; /*!<Cipher Key Type*/
    uchar8 ucCKN:4; /*!<Cipher Key Number */
#endif
}x_IFX_DECT_IE_Cipher;


/*! \brief Structure of the Setup Capability IE
*/

typedef struct
{
#ifdef LITTLE_ENDIAN
    uchar8 ucPage:2;/*!<Page Capability */
    uchar8 ucSetup:2;/*!<Setup Capability*/
    uchar8 ucPD:3;/*!< Protocol discriminator*/
    uchar8 ucExtn3:1;/*!<Extn bit for octet 3 - Value 0 => next octet of the octet group is present*/
    uchar8 ucDefault1;/*!<Default value is 128*/
    uchar8 acSpare[250];/*!<Spare bytes*/
    uchar8 ucSpareLen;/*!< Spare bytes length */
#else
    uchar8 ucExtn3:1; /*!<Extn bit for octet 3 - Value 0 => next octet of the octet group is present*/
    uchar8 ucPD:3; /*!< Protocol discriminator*/
    uchar8 ucSetup:2; /*!<Setup Capability*/
    uchar8 ucPage:2; /*!<Page Capability */
    uchar8 ucDefault1; /*!<Default value is 128*/
    uchar8 acSpare[250]; /*!<Spare bytes*/
    uchar8 ucSpareLen; /*!< Spare bytes length */
#endif
}x_IFX_DECT_IE_SetupCapability;

#ifdef CAT_IQ2_0
/*! \brief Structure of the Terminal capabilities IE. 
*/
typedef struct
{
#ifdef LITTLE_ENDIAN
    uchar8  ucDispCap:4; /*!<  Display capabilities  */
    uchar8  ucToneCap:3; /*!<  Tone capabilities  */
    uchar8  ucExtn3:1; /*!<  Extn bit for octet 3 */
    uchar8  ucAVOL:2; /*!<  Volume  */
    uchar8  ucNREJ:2; /*!<  Noise rejection  */
    uchar8  ucEchoParam:3; /*!< Echo Parameter   */
    uchar8  ucExtn3b:1; /*!<  Extn bit for octet 3b */
    uchar8  ucSlotTypeCap:7; /*!<  Slot Type Capability  */
    uchar8  ucExtn3c:1; /*!<  Extn bit for octet 3c */
    uchar8  ucMSNoOfStrdDispChr:7; /*!< Most significant bits of no. of stored display characters  */
    uchar8  ucExtn3d:1; /*!<  Extn bit for octet 3d */
    uchar8  ucLSNoOfStrdDispChr:7; /*!<  Least significant bits of no. of stored display characters  */
    uchar8  ucExtn3e:1; /*!< Extn bit for octet 3e  */
    uchar8  ucNoOfLinesPhyDisp:7; /*!<  Number of characters in Physical display */
    uchar8  ucExtn3f:1; /*!<  Extn bit for octet 3f */
    uchar8  ucNoOfChrInLine:7; /*!<  Number of characters in a line  */
    uchar8  ucExtn3g:1; /*!<  Extn bit for octet 3g */
    uchar8  ucScrollBehavior:7; /*!<  Scroll behaviour  */
    uchar8  ucExtn3h:1; /*!<  Extn bit for octet 3h */
    uchar8  ucProfInd1:7; /*!<   Profile Indicator 1 */
    uchar8  ucExtn4:1; /*!<  Extn bit for octet 4 */
    uchar8  ucProfInd2:7; /*!<  Profile Indicator 2 */
    uchar8  ucExtn4a:1; /*!<   Extn bit for octet 4a */
    uchar8  ucProfInd3:7;/*!<  Profile Indicator 3 */
    uchar8  ucExtn4b:1; /*!<  Extn bit for octet 4b */
    uchar8  ucProfInd4:7; /*!<  Profile Indicator 4 */
    uchar8  ucExtn4c:1; /*!<  Extn bit for octet 4c */
    uchar8  ucProfInd5:7; /*!<  Profile Indicator 5 */
    uchar8  ucExtn4d:1; /*!<  Extn bit for octet 4d */
    uchar8  ucProfInd6:7; /*!< Profile Indicator 6  */
    uchar8  ucExtn4e:1; /*!<  Extn bit for octet 4e */
    uchar8  ucProfInd7:7; /*!<  Profile Indicator 7 */
    uchar8  ucExtn4f:1; /*!<  Extn bit for octet 4f */
    uchar8  ucProfInd8:7; /*!<  Profile Indicator 8 */
    uchar8  ucExtn4g:1; /*!< Extn bit for octet 4g  */
    uchar8  ucCtrlCode:3; /*!<  Control Codes */
    uchar8  ucRsvd5:4; /*!<  Unused filled with zeroes always  */
    uchar8  ucExtn5:1; /*!<   Extn bit for octet 5 */
    uchar8  ucSpare:8; /*!< Spare field   */
    uchar8  ucEscTo8ChrSets:7; /*!<  Escape to 8bit character set  */
    uchar8  ucExtn5a:1; /*!<  Extn bit for octet 5a */
    uchar8  ucSp4:1; /*!<   Slot indication */
    uchar8  ucSp3:1; /*!<  Slot indication  */
    uchar8  ucSp2:1; /*!<  Slot indication  */
    uchar8  ucSp1:1; /*!<  Slot indication  */
    uchar8  ucSp0:1; /*!<  Slot indication  */
    uchar8  ucBlindSlotInd:2; /*!<  Blind Slot Indication  */
    uchar8  ucExtn6:1; /*!<  Extn bit for octet 6 */
    uchar8  ucSp11:1; /*!<  Slot indication  */
    uchar8  ucSp10:1; /*!<  Slot indication  */
    uchar8  ucSp9:1; /*!<  Slot indication  */
    uchar8  ucSp8:1; /*!<  Slot indication  */
    uchar8  ucSp7:1; /*!<  Slot indication  */
    uchar8  ucSp6:1; /*!<  Slot indication  */
    uchar8  ucSp5:1; /*!<  Slot indication  */
    uchar8  ucExtn6a:1; /*!<  Extn bit for octet 6a, This is always 1 */
#else
    uchar8  ucExtn3:1; /*!<  Extn bit for octet 3 */
    uchar8  ucToneCap:3; /*!<  Tone capabilities  */
    uchar8  ucDispCap:4; /*!<  Display capabilities  */
	
    uchar8  ucExtn3b:1; /*!<  Extn bit for octet 3b */
    uchar8  ucEchoParam:3; /*!< Echo Parameter   */
    uchar8  ucNREJ:2; /*!<  Noise rejection  */
    uchar8  ucAVOL:2; /*!<  Volume  */
	
    uchar8  ucExtn3c:1; /*!<  Extn bit for octet 3c */
    uchar8  ucSlotTypeCap:7; /*!<  Slot Type Capability  */
	
    uchar8  ucExtn3d:1; /*!<  Extn bit for octet 3d */
    uchar8  ucMSNoOfStrdDispChr:7; /*!< Most significant bits of no. of stored display characters  */
    uchar8  ucExtn3e:1; /*!< Extn bit for octet 3e  */
    uchar8  ucLSNoOfStrdDispChr:7; /*!<  Least significant bits of no. of stored display characters  */
    uchar8  ucExtn3f:1; /*!<  Extn bit for octet 3f */
    uchar8  ucNoOfLinesPhyDisp:7; /*!<  Number of characters in Physical display */
    uchar8  ucExtn3g:1; /*!<  Extn bit for octet 3g */
    uchar8  ucNoOfChrInLine:7; /*!<  Number of characters in a line  */
    uchar8  ucExtn3h:1; /*!<  Extn bit for octet 3h */
    uchar8  ucScrollBehavior:7; /*!<  Scroll behaviour  */
    uchar8  ucExtn4:1; /*!<  Extn bit for octet 4 */
    uchar8  ucProfInd1:7; /*!<   Profile Indicator 1 */
    uchar8  ucExtn4a:1; /*!<   Extn bit for octet 4a */
    uchar8  ucProfInd2:7; /*!<  Profile Indicator 2 */
    uchar8  ucExtn4b:1; /*!<  Extn bit for octet 4b */
    uchar8  ucProfInd3:7;/*!<  Profile Indicator 3 */
    uchar8  ucExtn4c:1; /*!<  Extn bit for octet 4c */
    uchar8  ucProfInd4:7; /*!<  Profile Indicator 4 */
    uchar8  ucExtn4d:1; /*!<  Extn bit for octet 4d */
    uchar8  ucProfInd5:7; /*!<  Profile Indicator 5 */
    uchar8  ucExtn4e:1; /*!<  Extn bit for octet 4e */
    uchar8  ucProfInd6:7; /*!< Profile Indicator 6  */
    uchar8  ucExtn4f:1; /*!<  Extn bit for octet 4f */
    uchar8  ucProfInd7:7; /*!<  Profile Indicator 7 */
    uchar8  ucExtn4g:1; /*!< Extn bit for octet 4g  */
    uchar8  ucProfInd8:7; /*!<  Profile Indicator 8 */
	
    uchar8  ucExtn5:1; /*!<   Extn bit for octet 5 */
    uchar8  ucRsvd5:4; /*!<  Unused filled with zeroes always  */
    uchar8  ucCtrlCode:3; /*!<  Control Codes */
	
    uchar8  ucSpare:8; /*!< Spare field   */
    uchar8  ucExtn5a:1; /*!<  Extn bit for octet 5a */
    uchar8  ucEscTo8ChrSets:7; /*!<  Escape to 8bit character set  */
	
    uchar8  ucExtn6:1; /*!<  Extn bit for octet 6 */
    uchar8  ucBlindSlotInd:2; /*!<  Blind Slot Indication  */
    uchar8  ucSp0:1; /*!<  Slot indication  */
    uchar8  ucSp1:1; /*!<  Slot indication  */
    uchar8  ucSp2:1; /*!<  Slot indication  */
    uchar8  ucSp3:1; /*!<  Slot indication  */
    uchar8  ucSp4:1; /*!<   Slot indication */
	
    uchar8  ucExtn6a:1; /*!<  Extn bit for octet 6a, This is always 1 */
    uchar8  ucSp5:1; /*!<  Slot indication  */
    uchar8  ucSp6:1; /*!<  Slot indication  */
    uchar8  ucSp7:1; /*!<  Slot indication  */
    uchar8  ucSp8:1; /*!<  Slot indication  */
    uchar8  ucSp9:1; /*!<  Slot indication  */
    uchar8  ucSp10:1; /*!<  Slot indication  */
    uchar8  ucSp11:1; /*!<  Slot indication  */
#endif    
} x_IFX_DECT_IE_Term_Capability;

#endif /*  CAT_IQ2_0 */

/*! \brief Structure of the Model Identifier IE
*/

typedef struct 
{
    uchar8 acModelValue[250];/*!<Model Value */ 
    uchar8 ucModelValueLen;/*!<Model Value Length*/
}x_IFX_DECT_IE_ModelIdentifier;


/*! \brief Structure of the Duration IE
*/

typedef struct
{
#ifdef LITTLE_ENDIAN
    uchar8 ucTimeLimits:4;/*!< Time Limits*/
    uchar8 ucLockLimits:3;/*!< Lock Limits*/
    uchar8 ucExtn3:1;/*!<Extn bit for octet 3 - Value 0 => next octet of the octet group is present*/
    uchar8 ucTimeDuration;/*!<Time Duration*/
#else 
    uchar8 ucExtn3:1; /*!<Extn bit for octet 3 - Value 0 => next octet of the octet group is present*/
    uchar8 ucLockLimits:3; /*!< Lock Limits*/
    uchar8 ucTimeLimits:4; /*!< Time Limits*/
    uchar8 ucTimeDuration; /*!<Time Duration*/
#endif
}x_IFX_DECT_IE_Duration;


/*! \brief Structure of the RAND IE
*/

typedef struct
{
    uchar8 acRANDField[250];/*!<RAND Field*/
    uchar8 ucRANDFieldLen;/*!<RAND Field Length*/
}x_IFX_DECT_IE_RAND;


/*! \brief Structure of the RES IE
*/

typedef struct
{
    uchar8 acRESField[250];/*!< RES Field*/
    uchar8 ucRESFieldLen;/*!< RES Field Length*/
}x_IFX_DECT_IE_RES;


/*! \brief Structure of the RS IE
*/

typedef struct
{
    uchar8 acRSField[250];/*!<RS FIeld*/
    uchar8 ucRSFieldLen;/*!<RS Field Length*/
}x_IFX_DECT_IE_RS;


/*! \brief Structure of the IWU Attributes IE
*/
typedef struct
{
#ifdef LITTLE_ENDIAN
    uchar8 ucECT:4;/*!<External Connection Type*/
    uchar8 ucNI:3;/*!<Negotiation Indicator */
    uchar8 ucDefault2:1;/*!<Default value is 1 */
    uchar8 ucITR:5;/*!<Information Transfer Rate */
    uchar8 ucTM:2;/*!<Transfer Mode */
    uchar8 ucExtn5:1;/*!<Extn bit for octet 5 - Value 0 => next octet of the octet group is present */
    uchar8 ucRM:5;/*!<Rate Multiplier */
    uchar8 ucUR:2;/*!< Unit Rate*/
    uchar8 ucExtn5a:1;/*!<Extn bit for octet 5a - Value 0 => next octet of the octet group is present */
    uchar8 ucEstab:2;/*!<Establishment */
    uchar8 ucConfig:2;/*!<Configuration*/
    uchar8 ucStructure:3;/*!<Structure*/
    uchar8 ucExtn5b:1;/*!<Extn bit for octet 5b - Value 0 => next octet of the octet group is present */
    uchar8 ucITRDO:5;/*!<Information Transfer Rate Dest=>Originator */
    uchar8 ucSymmetry:2;/*!<Symmetry*/
    uchar8 ucExtn5c:1;/*!<Extn bit for octet 5c - Value 0 => next octet of the octet group is present */
    uchar8 ucRMDO:5;/*!<Rate Multiplier Dest=>Originator */
    uchar8 ucURDO:2;/*!<Unit Rate*/
    uchar8 ucExtn5d:1;/*!<Extn bit for octet 5d - Default value is 1*/
    uchar8 ucUPID:5;/*!<User Protocol ID*/
    uchar8 ucDefault3:2;/*!<Default value is 0*/
    uchar8 ucExtn6:1;/*!<Extn bit for octet 6 - Value 0 => next octet of the octet group is present */
    uchar8 ucL3PID:5;/*!<Layer3 Protocol ID*/
    uchar8 ucDefault4:2;/*!<Default value is 1*/
    uchar8 ucExtn6a:1;/*!<Extn bit for octet 6a - Value 0 => next octet of the octet group is present */
    uchar8 ucL2PID:5;/*!<Layer2 Protocol ID*/
    uchar8 ucDefault5:2;/*!<Default value is 0*/
    uchar8 ucExtn6b:1;/*!<Extn bit for octet 6b - Value 0 => next octet of the octet group is present */
#else
    uchar8 ucDefault2:1; /*!<Default value is 1 */
    uchar8 ucNI:3; /*!<Negotiation Indicator */
    uchar8 ucECT:4; /*!<External Connection Type*/
    uchar8 ucExtn5:1; /*!<Extn bit for octet 5 - Value 0 => next octet of the octet group is present */
    uchar8 ucTM:2; /*!<Transfer Mode */
    uchar8 ucITR:5; /*!<Information Transfer Rate */
    uchar8 ucExtn5a:1; /*!<Extn bit for octet 5a - Value 0 => next octet of the octet group is present */
    uchar8 ucUR:2; /*!< Unit Rate*/
    uchar8 ucRM:5; /*!<Rate Multiplier */
    uchar8 ucExtn5b:1; /*!<Extn bit for octet 5b - Value 0 => next octet of the octet group is present */
    uchar8 ucStructure:3; /*!<Structure*/ 
    uchar8 ucConfig:2; /*!<Configuration*/
    uchar8 ucEstab:2; /*!<Establishment */
    uchar8 ucExtn5c:1; /*!<Extn bit for octet 5c - Value 0 => next octet of the octet group is present */
    uchar8 ucSymmetry:2; /*!<Symmetry*/
    uchar8 ucITRDO:5; /*!<Information Transfer Rate Dest=>Originator */
    uchar8 ucExtn5d:1; /*!<Extn bit for octet 5d - Default value is 1*/
    uchar8 ucURDO:2; /*!<Unit Rate*/
    uchar8 ucRMDO:5; /*!<Rate Multiplier Dest=>Originator */
    uchar8 ucExtn6:1; /*!<Extn bit for octet 6 - Value 0 => next octet of the octet group is present */
    uchar8 ucDefault3:2; /*!<Default value is 0*/
    uchar8 ucUPID:5; /*!<User Protocol ID*/
    uchar8 ucExtn6a:1; /*!<Extn bit for octet 6a - Value 0 => next octet of the octet group is present */
    uchar8 ucDefault4:2; /*!<Default value is 1*/
    uchar8 ucL3PID:5; /*!<Layer3 Protocol ID*/
    uchar8 ucExtn6b:1; /*!<Extn bit for octet 6b - Value 0 => next octet of the octet group is present */
    uchar8 ucDefault5:2; /*!<Default value is 0*/
    uchar8 ucL2PID:5; /*!<Layer2 Protocol ID*/
#endif
}x_IFX_DECT_IE_IWUAttributes_DectSS;


/*! \brief Structure of the IWU Attribute IE
*/
typedef struct
{
#ifdef LITTLE_ENDIAN
    uchar8 ucPST:4;/*!<Profile SubType */
    uchar8 ucNI:3;/*!< Negotiation Indicator*/
    uchar8 ucDefault2:1;/*!<Default value is 1 */
    uchar8 ucMaxSDUSizeM:7;/*!<Maximun SDU Size - Most Significant 7 bits */
    uchar8 ucExtn5:1;/*!<Extn bit for octet 5 -  Value 0 => next octet of the octet group is present */
    uchar8 ucMaxSDUSizeL:7;/*!<Maximum SDU Size - Least Significant 7 bits */
    uchar8 ucExtn5a:1;/*!<Extn bit for octet 5a -  Value 0 => next octet of the octet group is present*/
    uchar8 ucPSA:7;/*!<Profile Subtype Attributes */
    uchar8 ucDefault3:1;/*!<Default value is 1 */
    uchar8 ucOctet6;/*!<Octet 6 Flag P/A P==1*/
#else 
    uchar8 ucDefault2:1; /*!<Default value is 1 */
    uchar8 ucNI:3; /*!< Negotiation Indicator*/
    uchar8 ucPST:4; /*!<Profile SubType */
    uchar8 ucExtn5:1; /*!<Extn bit for octet 5 -  Value 0 => next octet of the octet group is present */
    uchar8 ucMaxSDUSizeM:7; /*!<Maximun SDU Size - Most Significant 7 bits */
    uchar8 ucExtn5a:1; /*!<Extn bit for octet 5a -  Value 0 => next octet of the octet group is present*/
    uchar8 ucMaxSDUSizeL:7; /*!<Maximum SDU Size - Least Significant 7 bits */
    uchar8 ucDefault3:1; /*!<Default value is 1 */
    uchar8 ucPSA:7; /*!<Profile Subtype Attributes */
    uchar8 ucOctet6; /*!<Octet 6 Flag P/A P==1*/
#endif
}x_IFX_DECT_IE_IWUAttributes_ProfileSS;


/*! \brief Union containing fields DECT SS or Profile SS
*/
typedef union{
  x_IFX_DECT_IE_IWUAttributes_DectSS xDectSS; /*!< IWU Attributes DECT */
  x_IFX_DECT_IE_IWUAttributes_ProfileSS xProfileSS; /*!< IWU Attributes Profile */
}ux_IFX_DECT_IE_IWUAttributes_DectOrProf;

/*! \brief Structure of the IWU Attributes IE
*/
typedef struct
{
#ifdef LITTLE_ENDIAN
    uchar8 ucProfileOrITC:5;/*!< based on coding standard, it would contain ITC or Profile */
    uchar8 ucCodeStd:2;/*!<Coding Standard- DECT or Profile */
    uchar8 ucDefault1:1;/*!<Default value is 1 */
#else
    uchar8 ucDefault1:1;/*!<Default value is 1 */
    uchar8 ucCodeStd:2;/*!<Coding Standard- DECT or Profile */
    uchar8 ucProfileOrITC:5;/*!< Based on coding standard, it would contain ITC or Profile */
#endif
    ux_IFX_DECT_IE_IWUAttributes_DectOrProf uxDectOrProf; /*!< Union of ITC and Profile */

}x_IFX_DECT_IE_IWUAttributes;

/*****************************************************************************
 * Decoding Functions 
 ******************************************************************************/
   
/*! \brief This function is used to fetch the IE type pointed by the IE Handle.
    \param[in] uiIEHdl Handle to the IE buffer
    \return    IE Type
*/
e_IFX_DECT_IE IFX_DECT_IE_TypeGet(IN uint32 uiIEHdl);

/*! \brief This function is used to fetch the address of succeeding IE. The current
           IE is checked to be a single octet, double octet or variable length 
           IE(content length specified in second octet) and address of the next
           IE is determined
    \param[out] puiIEHdl Pointer to IE Handle
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_NextIEHandlerGet(IN_OUT uint32 *puiIEHdl);

/*! \brief This function is used to fetch the contents of the Basic Service IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Basic Service content structure.
    \param[in] uiIEHdl Handle to the Basic Service IE
    \param[out] pxBasicService Basic Service IE content structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/

e_IFX_Return IFX_DECT_IE_BasicServiceGet(IN uint32 uiIEHdl, 
                                         OUT x_IFX_DECT_IE_BasicService *pxBasicService);

/*! \brief This function is used to fetch the contents of the Single Keypad IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the location pointed by the content pointer.
    \param[in] uiIEHdl Handle to the Single Keypad IE
    \param[out] pucSingleKeypad Single Keypad IE content pointer   
    \return    IFX_SUCCESS / IFX_FAILURE
*/

e_IFX_Return IFX_DECT_IE_SingleKeypadGet(IN uint32 uiIEHdl,
                                         OUT uchar8 *pucSingleKeypad);

/*! \brief This function is used to fetch the contents of the Single Display IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the location pointed by the content pointer.
    \param[in] uiIEHdl Handle to the Single Keypad IE
    \param[out] pucSingleDisplay Single Keypad IE content pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_SingleDisplayGet(IN uint32 uiIEHdl, 
                                          OUT uchar8* pucSingleDisplay);


/*! \brief This function is used to fetch the contents of the Signal IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the location pointed by the content pointer.
    \param[in] uiIEHdl Handle to the Signal IE
    \param[out] pucSignal Signal  IE content pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/

e_IFX_Return IFX_DECT_IE_SignalGet(IN uint32 uiIEHdl, 
                                   OUT uchar8* pucSignal);

/*! \brief This function is used to fetch the contents of the Portable Identity IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Portable Identity content structure.
    \param[in] uiIEHdl Handle to the Portable Identity IE
    \param[out] pxPortableIdentity Portable Identity IE content
                structure pointer
      \return    IFX_SUCCESS / IFX_FAILURE
*/

e_IFX_Return IFX_DECT_IE_PortableIdentityGet(IN uint32 uiIEHdl, 
                                             OUT x_IFX_DECT_IE_PortableIdentity *pxPortableIdentity);


/*! \brief This function is used to fetch the contents of the Fixed Identity IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Fixed Identity content structure
    \param[in] uiIEHdl Handle to the Fixed Identity IE
    \param[out] pxFixedIdentity Fixed Identity IE content structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/

e_IFX_Return IFX_DECT_IE_FixedIdentityGet(IN uint32 uiIEHdl, 
                                          OUT x_IFX_DECT_IE_FixedIdentity *pxFixedIdentity);

                                    
/*! \brief This function is used to fetch the contents of the Calling Party Number IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Calling Party Number content structure
    \param[in] uiIEHdl Handle to the Calling Party Number IE
    \param[out] pxCallingPartyNumber Calling Party Number IE content
                structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/

e_IFX_Return IFX_DECT_IE_CallingPartyNumberGet(IN uint32 uiIEHdl, 
                                               OUT x_IFX_DECT_IE_CallingPartyNumber *pxCallingPartyNumber);

/*! \brief This function is used to fetch the contents of the Called Party Number IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Called Party Number content structure
    \param[in] uiIEHdl Handle to the Called Party Number IE
    \param[out] pxCalledPartyNumber Called Party Number IE content
                structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/

e_IFX_Return IFX_DECT_IE_CalledPartyNumberGet(IN uint32 uiIEHdl, 
                                              OUT x_IFX_DECT_IE_CalledPartyNumber *pxCalledPartyNumber);

/*! \brief This function is used to fetch the contents of the IWU To IWU IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the IWU To IWU content structure
    \param[in] uiIEHdl Handle to the IWU To IWU IE
    \param[out] pxIWUToIWU IWU To IWU IE content structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_IWUToIWUGet(IN uint32 uiIEHdl, 
                                     OUT x_IFX_DECT_IE_IWUToIWU *pxIWUToIWU);

/*! \brief This function is used to fetch the contents of the IWU Packet IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the IWU Packet content structure
    \param[in] uiIEHdl Handle to the IWU Packet IE
    \param[out] pxIWUPacket Calling Party Number IE content structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_IWUPacketGet(IN uint32 uiIEHdl, 
                                      OUT x_IFX_DECT_IE_IWUPacket *pxIWUPacket);

/*! \brief This function is used to fetch the contents of the Codec List IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Codec List content structure
    \param[in] uiIEHdl Handle to the Codec List IE
    \param[out] pxCodecList Codec List IE content structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_CodecListGet(IN uint32 uiIEHdl, 
                                      OUT x_IFX_DECT_IE_CodecList *pxCodecList);

/*! \brief This function is used to fetch the contents of the Escape To Proprietary IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Escape To Proprietary content structure
    \param[in] uiIEHdl Handle to the Escape To Proprietary IE
    \param[out] pxEscapeToProprietary Escape To Proprietary IE content
                structure pointer
    \return     IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_EscapeToProprietaryGet(IN uint32 uiIEHdl, 
                                                OUT x_IFX_DECT_IE_EscapeToProprietary *pxEscapeToProprietary);

/*! \brief This function is used to fetch the contents of the Calling Party Name IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Calling Party Name content structure
    \param[in] uiIEHdl Handle to the Calling Party Name IE
    \param[out] pxCallingPartyName Calling Party Name IE content
                structure pointer
       \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_CallingPartyNameGet(IN uint32 uiIEHdl, 
                                             OUT x_IFX_DECT_IE_CallingPartyName *pxCallingPartyName);

/*! \brief This function is used to fetch the contents of the Window Size IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Window Size content structure
    \param[in] uiIEHdl Handle to the Window Size IE
    \param[out] pxWindowSize Window Size IE content structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_WindowSizeGet(IN uint32 uiIEHdl, 
                                       OUT x_IFX_DECT_IE_WindowSize *pxWindowSize);

/*! \brief This function is used to fetch the contents of the Call Attributes IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Call Attributes content structure
    \param[in] uiIEHdl Handle to the Call Attributes IE
    \param[out] pxCallAttributes Call Attributes IE content structure
                pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_CallAttributesGet(IN uint32 uiIEHdl, 
                                           OUT x_IFX_DECT_IE_CallAttributes *pxCallAttributes);

/*! \brief This function is used to fetch the contents of the Connection
           Attributes IE. Contents of the IE are fetched from
           the given IE Handle and filled up in the Connection Attributes
           content structure
    \param[in] uiIEHdl Handle to the Connection Attributes IE
    \param[out] pxConnectionAttributes Connection Attributes IE content
                structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_ConnectionAttributesGet(IN uint32 uiIEHdl, 
                                                 OUT x_IFX_DECT_IE_ConnectionAttributes *pxConnectionAttributes);

/*! \brief This function is used to fetch the contents of the Facility IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Facility content structure
    \param[in] uiIEHdl Handle to the Facility IE
    \param[out] pxFacility Facility IE content structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_FacilityGet(IN uint32 uiIEHdl, 
                                     OUT x_IFX_DECT_IE_Facility *pxFacility);

/*! \brief This function is used to fetch the contents of the Multi Display IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Multi Display content structure
    \param[in] uiIEHdl Handle to the Multi Display IE
    \param[out] pxMultiDisplay Multi Display IE content structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_MultiDisplayGet(IN uint32 uiIEHdl, 
                                         OUT x_IFX_DECT_IE_MultiDisplay *pxMultiDisplay);

/*! \brief This function is used to fetch the contents of the Multi Keypad IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Multi Keypad content structure
    \param[in] uiIEHdl Handle to the Multi Keypad IE
    \param[out] pxMultiKeypad Multi Keypad IE content structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_MultiKeypadGet(IN uint32 uiIEHdl, 
                                        OUT x_IFX_DECT_IE_MultiKeypad *pxMultiKeypad);

/*! \brief This function is used to fetch the contents of the Connection Identity IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Connection Identity content structure
    \param[in] uiIEHdl Handle to the Connection Identity IE
    \param[out] pxConnectionIdentity Connection Identity IE content
                structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_ConnectionIdentityGet(IN uint32 uiIEHdl, 
                                               OUT x_IFX_DECT_IE_ConnectionIdentity *pxConnectionIdentity);

/*! \brief This function is used to fetch the contents of the Repeat Indicator IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Repeat Indicator content structure
    \param[in] uiIEHdl Handle to the Repeat Indicator IE
    \param[out] pucRepeatIndicator Repeat Indicator IE content char pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_RepeatIndicatorGet(IN uint32 uiIEHdl, 
                                            OUT uchar8 *pucRepeatIndicator);

/*! \brief This function is used to fetch the contents of the Progress Indicator IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Progress Indicator content structure
    \param[in] uiIEHdl Handle to the Progress Indicator IE
    \param[out] pxProgressIndicator Progress Indicator IE content
                structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_ProgressIndicatorGet(IN uint32 uiIEHdl, 
                                              OUT x_IFX_DECT_IE_ProgressIndicator *pxProgressIndicator);

/*! \brief This function is used to fetch the contents of the Service Change  IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Service Change  content structure
    \param[in] uiIEHdl Handle to the Service Change  IE
    \param[out] pxServiceChange Service Change  IE content
                structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_ServiceChangeGet(IN uint32 uiIEHdl, 
                                          OUT x_IFX_DECT_IE_ServiceChange *pxServiceChange);

/*! \brief This function is used to fetch the contents of the Time Date IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Time Date content structure
    \param[in] uiIEHdl Handle to the Time Date IE
    \param[out] pxTimeDate Time Date IE content structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_TimeDateGet(IN uint32 uiIEHdl, 
                                     OUT x_IFX_DECT_IE_TimeDate *pxTimeDate);

/*! \brief This function is used to fetch the contents of the Location Area IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Location Area content structure
    \param[in] uiIEHdl Handle to the Calling Party Number IE
    \param[out] pxLocationArea Location Area IE content structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_LocationAreaGet(IN uint32 uiIEHdl, 
                                         OUT x_IFX_DECT_IE_LocationArea *pxLocationArea);

/*! \brief This function is used to fetch the contents of the Auth Type IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Auth Type content structure
    \param[in] uiIEHdl Handle to the Auth Type IE
    \param[out] pxAuthType Auth Type IE content structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_AuthTypeGet(IN uint32 uiIEHdl, 
                                     OUT x_IFX_DECT_IE_AuthType *pxAuthType);

/*! \brief This function is used to fetch the contents of the Cipher  IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Cipher  content structure
    \param[in] uiIEHdl Handle to the Cipher  IE
    \param[out] pxCipher Cipher  IE content structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_CipherGet(IN uint32 uiIEHdl, 
                                   OUT x_IFX_DECT_IE_Cipher *pxCipher);

/*! \brief This function is used to fetch the contents of the Service Class IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the location pointed by content pointer
    \param[in] uiIEHdl Handle to the Service Class IE
    \param[out] pucServiceClass Service Class IE content pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_ServiceClassGet(IN uint32 uiIEHdl, 
                                         OUT uchar8 *pucServiceClass);

/*! \brief This function is used to fetch the contents of the Setup Capability IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Setup Capability content structure
    \param[in] uiIEHdl Handle to the Setup Capability IE
    \param[out] pxSetupCapability Setup Capability IE content
                structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_SetupCapabilityGet(IN uint32 uiIEHdl, 
                                            OUT x_IFX_DECT_IE_SetupCapability *pxSetupCapability);

/*! \brief This function is used to fetch the contents of the Model Identifier IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Model Identifier content structure
    \param[in] uiIEHdl Handle to the Model Identifier IE
    \param[out] pxModelIdentifier Calling Party Number IE content
                structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_ModelIdentifierGet(IN uint32 uiIEHdl, 
                                            OUT x_IFX_DECT_IE_ModelIdentifier *pxModelIdentifier);

/*! \brief This function is used to fetch the contents of the Reject Reason IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Reject Reason content structure
    \param[in] uiIEHdl Handle to the Reject Reason IE
    \param[out] pucRejectReason Reject Reason IE content structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_RejectReasonGet(IN uint32 uiIEHdl, 
                                         OUT uchar8 *pucRejectReason);

/*! \brief This function is used to fetch the contents of the Duration IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the Duration content structure
    \param[in] uiIEHdl Handle to the Duration IE
    \param[out] pxDuration Duration IE content structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_DurationGet(IN uint32 uiIEHdl, 
                                     OUT x_IFX_DECT_IE_Duration *pxDuration);

/*! \brief This function is used to fetch the contents of the RAND IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the RAND content structure
    \param[in] uiIEHdl Handle to the RAND IE
    \param[out] pxRAND RAND IE content structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_RANDGet(IN uint32 uiIEHdl, 
                                 OUT x_IFX_DECT_IE_RAND *pxRAND);

/*! \brief This function is used to fetch the contents of the RES IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the RES content structure
    \param[in] uiIEHdl Handle to the RES IE
    \param[out] pxRES RES IE content structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_RESGet(IN uint32 uiIEHdl, 
                                OUT x_IFX_DECT_IE_RES *pxRES);

/*! \brief This function is used to fetch the contents of the RS IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the RS content structure
    \param[in] uiIEHdl Handle to the RS IE
    \param[out] pxRS RS IE content structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_RSGet(IN uint32 uiIEHdl, 
                               OUT x_IFX_DECT_IE_RS *pxRS);

/*! \brief This function is used to fetch the contents of the Use TPUI IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the location pointed by the content pointer
    \param[in] uiIEHdl Handle to the Use TPUI IE
    \param[out] pucUseTPUI Use TPUI IE content pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_UseTPUIGet(IN uint32 uiIEHdl, 
                                    OUT uchar8 *pucUseTPUI);

/*! \brief This function is used to fetch the contents of the IWU Attributes IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the IWU Attributes content structure
    \param[in] uiIEHdl Handle to the IWU Attributes IE
    \param[out] pxIWUAttributes IWU Attributes IE content structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_IWUAttributesGet(IN uint32 uiIEHdl, 
                                          OUT x_IFX_DECT_IE_IWUAttributes *pxIWUAttributes);

/*! \brief This function is used to fetch the contents of the Timer Restart IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the location pointed by the content pointer
    \param[in] uiIEHdl Handle to the Timer Restart IE
    \param[out] pucTimerRestart Timer Restart IE content pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_TimerRestartGet(IN uint32 uiIEHdl, 
                                         OUT uchar8 *pucTimerRestart);
										 
/*! \brief This function is used to fetch the contents of the Event Notification IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the location pointed by the content pointer
    \param[in] uiIEHdl Handle to the Event notification IE
    \param[out] pxEventNotify Event Notification IE content structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_EventNotifyGet(IN uint32 uiIEHdl, 
                                        OUT x_IFX_DECT_IE_EventNotify *pxEventNotify);
										
/*! \brief This function is used to fetch the contents of the Call Information IE.
           Contents of the IE are fetched from the given IE Handle and filled 
           up in the location pointed by the content pointer
    \param[in] uiIEHdl Handle to the Call Information IE
    \param[out] pxCallInfo Call Information IE content structure pointer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_CallInformationGet(IN uint32 uiIEHdl, 
                                            OUT x_IFX_DECT_IE_CallInfo *pxCallInfo);
	
/*****************************************************************************
 * Encoding Functions 
 ******************************************************************************/
 
/*! \brief     This function is used to add an IE to the existing message structure.
               The location in the structure, where the new IE is to be added 
               is determined and the contents of the new IE are filled in that
               location. The function ensures that the IEs added to the message
               are arranged in ascending order of their enumerated values.
    \param[out] uiMsgHdl Message handle
    \param[in] eIE The IE to be added
    \param[in] pvIEStruct Pointer to the IE content
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_IEAdd(IN_OUT uint32 uiMsgHdl, 
                               IN e_IFX_DECT_IE eIE,
                               IN void *pvIEStruct);  
 

/*! \brief     This function moves a set of IEs from source memory location
               to destination memory location present in the message structure.
    \param[in] uiDMsgHdl Pointer to the first IE of the destination message structure
    \param[in] uiSMsgHdl Pointer to the first IE of the set of IEs at source memory
               location. 
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_IEAppend(IN uint32 uiDMsgHdl, 
                                  IN uint32 uiSMsgHdl);

/*! \brief     This function is used to create data frame from the
               provided space of (250 bytes).
    \return    return IE handler
	\note      The Application should make sure the space provided is not
	           freed till its usage is complete.
*/
uint32 IFX_DECT_IE_NewIECreate(uchar8 aucBuff[250]);

/*! \brief     This function is used to copy a single IE from source memory location to 
               a destination memory location present in the message structure. The FT application
			   shall use this function to encode IE's that are not implemented by the DECT TK.
    \param[in] uiDMsgHdl Handle to the first IE of the destination message structure
    \param[in] pucBuff Reference to the generic IE buffer
    \param[in] ucIELen Length in bytes of the generic IE.
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_GenericIEAdd(IN uint32 uiDMsgHdl, 
                                IN uchar8 *pucBuff, 
                                IN uchar8 ucIELen);

/*! \brief     This function is used to get the IE handle and content length of a 
               generic IE from the message structure. The FT Application shall use this function
			   to parse a IE that is not known by the DECT Toolkit.
    \param[in] uiIEHdl Handle to the IE in the message structure
    \param[out] pucIEHdl Pointer to the IE buffer
    \param[out] pucIELen Size of the IE buffer
    \return    IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_IE_GenericIEGet(IN uint32 uiIEHdl,
                                      OUT uchar8 *pucIEHdl, 
                                      OUT uchar8 *pucIELen);

/* @} */

#endif    /* __IFX_DECT_IEPARSER_H__ */
