/**************************************************************************
**   FILE NAME     : IFX_DECT_Platform.h
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-09-2008
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Call Control
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_DECT_Platform.h
    \brief This File includes all reference of the Timer Related Stuff.
*/
#ifndef __IFX_DECT_PLATFORM_H__
#define __IFX_DECT_PLATFORM_H__

#ifdef __LINUX__
#include <stdio.h>       
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <stdarg.h>
#include <time.h>
#include <sys/time.h>

#include "ifx_common_defs.h"
#include "ifx_os.h"
#include "ifx_debug.h"
#include "ifx_ipc.h"

#endif

#ifdef SUPERTASK
#include "ifx_common_defs.h"
#include "sys_mem.h"
#include "sys_timer.h"
//#include "mt.h"
#define NULL 0

#endif
/* Code was commented in ifx_os.h so, added with define flags here */
#ifndef IFX_OS_Malloc
#define IFX_OS_Malloc(iBytes) malloc(iBytes)
#endif
#ifndef IFX_OS_Free
#define IFX_OS_Free(pBuff) free(pBuff)
#endif

/*! 
	\brief	This is the timer callback function.  This function is implemented
	by the module, requesting for services from the Timer module.  This function
	pointer needs to be passed to the Timer module when requesting for a timer 
	to be started.  This function will be called back when the timer expires.
	\param[in] uiTimerId The timer Id of the Timer which is expired.  
	\param[in] pvPrivateData Pointer to Data given by 
					the module which triggered the timer
	\return 	void No Value
*/
typedef void (*pfn_IFX_DECT_TimerCallBack)(
	                 IN uint32 uiTimerId,
	                 IN void* pvPrivateData );


/* Timer Releated Functions */
e_IFX_Return IFX_DECT_StartTimer(
			  IN uint32 uiTimeOut,
			  IN void* pvPrivateData,
			  IN uint16 unPrivateDataLen,
			  IN pfn_IFX_DECT_TimerCallBack pfnTimerCallBack,
			  OUT uint32* puiTimerId);
			  
e_IFX_Return IFX_DECT_StopTimer(IN uint32 uiTimerId);
/* Thread Releated Functions */
#ifdef __LINUX__
#define IFX_DECT_CreateThread IFX_OS_CreateThread
#endif
#ifdef SUPERTASK
#define IFX_DECT_CreateThread(x,y) x(y)
#endif

/* Semphore Releated Functions */
#ifdef __LINUX__
#define IFX_DECT_LockCreate IFX_OS_LockCreate
#endif

//#ifdef SUPERTASK
//#define IFX_DECT_LockCreate(x) IFX_SUCCESS
#define IFX_OS_LockAcquire(x) IFX_SUCCESS
#define IFX_OS_LockRelease(x) IFX_SUCCESS

//#endif

/* DEbug Related*/
#ifdef __LINUX__

#endif /*__LINUX__*/
#ifdef SUPERTASK
typedef enum
{
   IFX_DBG_STR,
   IFX_DBG_INT,
   IFX_DBG_ATA_STRING_INFO,
   IFX_DBG_ATA_INT_INFO,
} x_IFX_DBG_Types;
extern char8 * vacMsgTbl[];
#define IFX_DBGA(a,b,c,d)	cosic_printf( vacMsgTbl[c],d)
#define IFX_DBGA5(a,b,c,d,e)	cosic_printf( vacMsgTbl[c],d,e)
#define IFX_DBGC(a,b,c,d)	cosic_printf( vacMsgTbl[c],d)
#define IFX_DBGC5(a,b,c,d,e)	cosic_printf( vacMsgTbl[c],d,e)
#define iprintf cosic_printf
#define printf iprintf
#endif /* __LINUX__*/
#endif /* __IFX_DECT_PLATFORM_H__*/


