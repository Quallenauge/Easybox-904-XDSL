/*===========================================================================
 *    Filename:  IFX_DECT_LAU.c
 * Description:  This File Contains Description of List Access Unit
 *     Version:  1.0
 *     Created:  Monday 06 April 2009
 *    Revision:  none
 *    Compiler:  gcc
 *      Author:  DECT Tool kit Team
 *     Company:  IFIN
 *============================================================================
 */

#ifndef __IFX_DECT_LAU_INFO_H__
#define __IFX_DECT_LAU_INFO_H__

/* For checking list support */
#define	IFX_DECT_LAU_MISSED_CALLS_LS             0x00000001
#define IFX_DECT_LAU_OUTGOING_CALLS_LS           0x00000002
#define IFX_DECT_LAU_INCOMING_ACCEPT_CALLS_LS    0x00000004
#define IFX_DECT_LAU_ALL_CALLS_LS                0x00000008
#define IFX_DECT_LAU_CONTACTS_LS                 0x00000010
#define IFX_DECT_LAU_INTERNAL_NAMES_LS           0x00000020
#define IFX_DECT_LAU_SYS_SETTINGS_LS             0x00000040
#define IFX_DECT_LAU_LINE_SETTINGS_LS            0x00000080
#define IFX_DECT_LAU_ALL_INCOMING_CALLS_LS       0x00000100
#define IFX_DECT_LAU_PROPRIETARY_LS              0x00000200


#define IFX_DECT_LAU_MAX_DATA_PER_PKT 56

typedef struct{
  uchar8 ucIsUsed; /* Indicates if this block is in use */
  uchar8 ucCallId;/* Call Id associated with session */
  uchar8 ucNoOfReqFields;     /*!< Number of requested fields */
  uchar8 ucNoOfEntries;     /*!< Max entries in the list */
  uchar8 ucOrder;     /*!< Stored for Entry Id handling */
  int16 nStartIdx;     /*!< Start Index */
  uchar8 aucFieldIdsList[IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE]; /*!< List of
		                               fields identifiers*/
  e_IFX_DECT_LAU_ListId eListId; /*!< List Identifier*/ 
}x_IFX_DECT_LAU_Info;



/********************************************************************************/
/*Event & Identifier List*/
/*******************************************************************************/
#define IFX_DECT_LAU_MAX_EVENTS 7
#define IFX_DECT_LAU_MAX_IDENTIFIERS 10


e_IFX_Return
IFX_DECT_LAU_GetHSIdFromSessId(OUT uchar8 *pucHandsetId, IN int16 nSessId);


e_IFX_Return 
IFX_DECT_LAU_ProcessStackMsg(IN x_IFX_DECT_IPC_Msg *pxIPCMsg);

e_IFX_Return 
IFX_DECT_LAU_CheckPD(x_IFX_DECT_IPC_Msg *pxIPCMsg);

#endif /*__IFX_DECT_LAU_INFO_H__*/
