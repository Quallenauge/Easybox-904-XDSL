#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>
#include "ifx_common_defs.h"
#include "ifx_os.h"
#include "ifx_debug.h"
#include "ifx_ipc.h"
#include "pthread.h"
#include "IFX_DECT_Stack.h"
#include "IFX_DECT_StackIf.h"
#include "IFX_DECT_GlobalInfo.h"
#include "IFX_DECT_MsgRouter.h"
#include "IFX_DECT_MsgEncoder.h"
#include "IFX_DECT_MU.h"
#include "IFX_DECT_MU_Fsm.h"
#include "IFX_DECT_SMSU.h"
#include "IFX_DECT_SMSU_fsm.h"
  
x_IFX_DECT_SMSU_Info vxSMS_STUB_Info[IFX_DECT_MAX_HS];

uchar8 ucHandSet[IFX_DECT_MAX_HS];

uchar8 acMesg[IFX_DECT_SMSU_MAX_MESG][IFX_DECT_SMSU_MAX_MESG_DATALEN];//Message List.

int32 IFX_DECT_SMSU_Main();


int32 IFX_DECT_SMSU_StubInit()
{
  pthread_t Thread2=0;
  pthread_attr_t xAttrib;
  int32 iRetVal;
  iRetVal = pthread_attr_init(&xAttrib);
  iRetVal = pthread_attr_setdetachstate(&xAttrib, PTHREAD_CREATE_DETACHED);
  uchar8 i;
  printf("in SMSU STUB init\n");
  for(i=0;i<6;++i) 
  {
     vxSMS_STUB_Info[i].uxSMS_Data.xMesgBlock.xMesgUpper.ucMesgSize=0;
     vxSMS_STUB_Info[i].uxSMS_Data.xHeaderGroup.ucHeaderCount = 0;
     vxSMS_STUB_Info[i].eSMS_State=IFX_DECT_SMSU_IDLE;
     vxSMS_STUB_Info[i].ucInstance = 0;
     vxSMS_STUB_Info[i].ucMesgIndex = 0;
     vxSMS_STUB_Info[i].ucUnread=0;
     vxSMSInfo[i].ucMesgBlkSize = 0;
     vxSMSInfo[i].ucHeaderGrpSize = 0;
		 ucHandSet[i] = 0;
  }
	printf("before thread\n");
  if (pthread_create (&Thread2, &xAttrib,IFX_DECT_SMSU_Main, NULL))
  {
  	printf("in thread fail\n");  
    return IFX_FAILURE;
	}
	printf("after thread success\n");  
	return IFX_SUCCESS;
}
 


#if 0
e_IFX_Return EncodeIWU_STUB_SMS(char8 *pcIWU_Data,int32 iIWU_DataLen,char8 *pcIWU_String){

  x_IFX_DECT_IE_IWUToIWUInfo xIWU_Mesg = {0};

  uchar8 ucOctet4_Bit8 = 1;
  char8 ucDiscType = 1;
  uchar8 ucIEType = IFX_DECT_IE_IWUTOIWU;

  xIWU_Mesg.ucSR = 1;
  xIWU_Mesg.ucPD = 0;
  xIWU_Mesg.ucDefault1 = 1;
  xIWU_Mesg.ucIWUToIWUInfoLen = iIWU_DataLen + 4;
  xIWU_Mesg.acIWUToIWUInfo[0] = ucOctet4_Bit8;
  xIWU_Mesg.acIWUToIWUInfo[0] <<= 7/*SEVEN*/;
  xIWU_Mesg.acIWUToIWUInfo[0] |= ucDiscType;
  xIWU_Mesg.acIWUToIWUInfo[1] = 0x00;//EMC HIGH.
  xIWU_Mesg.acIWUToIWUInfo[2] = 0xC0;//EMC LOW.
  xIWU_Mesg.acIWUToIWUInfo[3] = 1;//Proprietary Type SMS=1
  strncat((char*)xIWU_Mesg.acIWUToIWUInfo,(char*)pcIWU_Data,iIWU_DataLen);
  strncpy(pcIWU_String,&ucIEType,sizeof(uchar8));
  strncat(pcIWU_String,&xIWU_Mesg,sizeof(x_IFX_DECT_IE_IWUToIWUInfo));
   return IFX_SUCCESS;
}
#endif

int32 IFX_DECT_STUB_GetFreeHandSetNo(){
  int32 iCount = 0;
  for(iCount = 0;iCount < IFX_DECT_MAX_HS;iCount++){
    if(ucHandSet[iCount] == 0){
      ucHandSet[iCount] = iCount+1;
      return ucHandSet[iCount];
    }  
  }
  return IFX_FAILURE; 
} 

e_IFX_Return IFX_DECT_STUB_ResetAllHandsets(){
  int32 iCount = 0;
  for(iCount = 0;iCount < IFX_DECT_MAX_HS;iCount++){
      ucHandSet[iCount] = 0;
    }  
  return IFX_SUCCESS; 
} 


int32 IFX_DECT_STUB_GetFreeInstanceNo(){
  int32 iCount = 0;
  for(iCount = 0;iCount < IFX_DECT_MAX_HS;iCount++){
    if(vxSMS_STUB_Info[iCount].ucInstance == 0){
      vxSMS_STUB_Info[iCount].ucInstance = iCount;
      return iCount;
    }  
  }
  return IFX_FAILURE; 
} 

e_IFX_Return IFX_DECT_SMSU_STUB_ComposeIpcMessage(IN uchar8 ucMsgId,IN uchar8 ucHandSet,
		                                  IN uchar8 ucInstance,OUT x_IFX_DECT_IPC_Msg *pxIpcMsg){
  
  pxIpcMsg->ucMsgId = ucMsgId;
  pxIpcMsg->ucInstance = ucInstance;
  pxIpcMsg->ucPara1 = ucHandSet;
  pxIpcMsg->ucPara2 = 0;
  pxIpcMsg->ucPara3 = 0;
  pxIpcMsg->ucPara4 = 0;
  
  return IFX_SUCCESS;
}

e_IFX_Return IFX_DECT_SMSU_STUB_ComposeDataReq(IN e_IFX_DECT_SMSU_DataType eDataType,IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
		                               IN uchar8 ucMesgIndex,OUT x_IFX_DECT_SMSU_DataReq *pxDataReq){

  pxDataReq->ucReqType = eDataType;
  pxDataReq->ucMesgBox = eMesgBox;
  pxDataReq->ucPrimitive = IFX_DECT_SMSU_DATA_REQ;
  pxDataReq->ucMesgIndex = ucMesgIndex;

  return IFX_SUCCESS;
} 

e_IFX_Return IFX_DECT_SMSU_STUB_ComposeDelReq(IN e_IFX_DECT_SMSU_DeleteReqType eReqType,
                                              IN e_IFX_DECT_SMSU_MesgBox eMesgBox,
                                              IN uchar8 ucMesgIndex,
                                              OUT x_IFX_DECT_SMSU_DeleteReq *pxDelReq){

  pxDelReq->ucReqType = eReqType;
  pxDelReq->ucMesgBox = eMesgBox;
  pxDelReq->ucPrimitive = IFX_DECT_SMSU_DELETE_REQ;
  pxDelReq->ucMesgIndex = ucMesgIndex;

  return IFX_SUCCESS;

}
 
e_IFX_Return IFX_DECT_STUB_ComposeSendReq(IN uchar8 ucMesgSize,OUT x_IFX_DECT_SMSU_SendReqUpper *pxSendReq){

  pxSendReq->ucPrimitive = IFX_DECT_SMSU_SEND_REQ;
  pxSendReq->ucMesgSize = ucMesgSize;

  return IFX_SUCCESS;
}


e_IFX_Return IFX_DECT_STUB_EncodeCCInfo(IN uchar8 ucHandset,IN uchar8 ucInstance,IN uchar8 ucSignal,
                                        OUT x_IFX_DECT_IPC_Msg *pxIpcMsg){

  pxIpcMsg->ucMsgId = FP_INFO_IN_CC;
  pxIpcMsg->ucInstance = ucInstance;
  pxIpcMsg->ucPara1 = ucHandset;
  pxIpcMsg->ucPara2 = ucSignal;

  return IFX_SUCCESS;	
}

e_IFX_Return IFX_DECT_STUB_PrintMessage(IN uchar8 ucHandSet){

  int16 iToFromNumber = 0;
  int32 i = 0;
  printf("\nPrinting the Message Block.\n");
  printf("\n Size of Origination Number:%d",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.ucToFromNumberSize);
  for(i = 0;i <= vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.ucToFromNumberSize-1;i++){
    iToFromNumber |= vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.aucToFromNumber[i];
    if(i == vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.ucToFromNumberSize-1){
      continue;
    } 
    iToFromNumber <<= 8;
  }
  printf("\n Origination Number:%x",iToFromNumber);
  printf("\n Size of Message:%d",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.ucMesgSize);
  printf("\n Message Contents:\n");
  printf("%s",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.aucMesgContents);
  printf("\n Timestamp:\n");
  printf("\nYear:%d",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgLower.xMesgTimeStamp.ucYear);
  printf("\nMonth:%d",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgLower.xMesgTimeStamp.ucMonth);
  printf("\nDay:%d",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgLower.xMesgTimeStamp.ucDay);
  printf("\nHour:%d",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgLower.xMesgTimeStamp.ucHour);
  printf("\nMinute:%d",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgLower.xMesgTimeStamp.ucMinute);
  printf("\nSecond:%d",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgLower.xMesgTimeStamp.ucSecond);
  printf("\nTime Zone:%d",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgLower.xMesgTimeStamp.ucTimeZone);
  printf("\n Extension Number:%d",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgLower.ucExtnNumber);
  printf("\n Checksum:%d",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgLower.ucChecksum);
  	
  return IFX_SUCCESS;
}	

e_IFX_Return IFX_DECT_STUB_PrintHeaders(IN uchar8 ucHandSet){
	
  int32 i = 0;
  int32 j = 0;
  int16 iToFromNumber = 0;
  printf("\nPrinting the Header Group.\n");
  printf("\nNumber of Headers:%d",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucHeaderCount);
  for(i = 0;i < vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucHeaderCount;i++){
    printf("\n\nPRINTING HEADER BLOCK[%d].\n",i+1);
    printf("\nMessage Index:%d",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xHeaderGroup.axHeaders[i].ucMesgIndex);
    printf("\nSize of Origination Number:%d",
           vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xHeaderGroup.axHeaders[i].ucToFromNumberSize);
    for(j = vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xHeaderGroup.axHeaders[i].ucToFromNumberSize-1;j >= 0;j--){
      iToFromNumber |= vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xHeaderGroup.axHeaders[i].aucToFromNumber[j];
      if(j == 0){
        continue;
      }
      iToFromNumber <<= 8;
    }

    printf("\n Origination Number:%d",iToFromNumber);
    printf("Message Status(Read-0,Unread-1):%d",
           vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xHeaderGroup.axHeaders[i].ucMesgStatus);
    printf("\nMessage Preamble:\n");
    printf("%s",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xHeaderGroup.axHeaders[i].aucMesgPreamble);
    printf("\n Extension Number:%d",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xHeaderGroup.axHeaders[i].ucExtnNumber);
  }
  printf("\nChecksum:%d",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucChecksum);
  return IFX_SUCCESS;
}	
	
e_IFX_Return IFX_DECT_SMSU_STUB_PostToStub(IN x_IFX_DECT_IPC_Msg *pxIpcMsg){

  e_IFX_DECT_SMSU_Primitive ePrimitive;
  e_IFX_DECT_SMSU_SegPrimitive eSegPrimitive;
  char8 acSMS_Primitive[200] = "";
  int32 iPrimitiveSize = 0;
  int32 i =0;
  switch(pxIpcMsg->ucMsgId){
	  
    case FP_CC_INFO_RQ:
				printf("<STUB>FP_CC_INFO_RQ received\n");
        if(IFX_DECT_SMSU_FetchPrimitive(pxIpcMsg,acSMS_Primitive,&iPrimitiveSize) !=IFX_SUCCESS){
          return IFX_FAILURE;
        } 
        printf("<STUB> acSMS_Primitive[0]=%x\n",acSMS_Primitive[0]);
        /*for(i = 0;i < iPrimitiveSize;i++){
           printf("<STUB> acSMS_Primitive[%d]=%x\n",i,acSMS_Primitive[i]);
        }*/
        ePrimitive = acSMS_Primitive[0] & IFX_DECT_SMSU_LOWER_NIBBLE_MASK;

        switch(ePrimitive){

            case IFX_DECT_SMSU_DATA_RSP:
								printf("<STUB>Primitive is Data Rsp\n");
                return IFX_DECT_SMSU_STUB_DataRsp(acSMS_Primitive,iPrimitiveSize,pxIpcMsg);
                break;

            case IFX_DECT_SMSU_DELETE_RSP:

                return IFX_DECT_SMSU_STUB_DelRsp(acSMS_Primitive,iPrimitiveSize,pxIpcMsg);

            case IFX_DECT_SMSU_SEND_RSP:
              
                return IFX_DECT_SMSU_STUB_SendRsp(acSMS_Primitive,iPrimitiveSize,pxIpcMsg);
                break;

            default:
              
                eSegPrimitive = acSMS_Primitive[0] & IFX_DECT_SMSU_LOWER_TRIPLET_MASK;
                switch(eSegPrimitive){

                  case IFX_DECT_SMSU_SEGMENT:

                      return IFX_DECT_SMSU_STUB_DataRsp(acSMS_Primitive,iPrimitiveSize,pxIpcMsg);
                      break;

                  case IFX_DECT_SMSU_SEG_ACK:



                      break;

                  default:

                      printf("Primitive not understood\n");
                      return IFX_FAILURE;
                      break;
                } 
        }
        break;

    default:

        printf("CC Message Not Understood\n");
        return IFX_FAILURE; 
        break;
  }

  return IFX_SUCCESS;
  
}

e_IFX_Return IFX_DECT_SMSU_STUB_DataRsp(IN char8 *pcPrimitiveMesg, IN int32 iPrimitiveLen,
                                     IN x_IFX_DECT_IPC_Msg *pxIpcMsg){

  uchar8 ucHandSet = 0;	
  int32 iReplyLen = 0;
  x_IFX_DECT_SMSU_DataRspUpper *pxDataRsp = NULL;
  x_IFX_DECT_SMSU_SegmentPacketHeader *pxSeg = NULL;
  x_IFX_DECT_SMSU_DataReq xDataReq = {0};
  x_IFX_DECT_SMSU_SegAck xSegAck = {0};
  x_IFX_DECT_IPC_Msg xIpcReply = {0};
  e_IFX_DECT_SMSU_MesgBox eMesgBox;
  e_IFX_DECT_SMSU_DataType eDataType;
	int32 i =0;
  e_IFX_DECT_SMSU_Primitive ePrimitive;
  e_IFX_DECT_SMSU_SegPrimitive eSegPrimitive;
  
	printf("<IFX_DECT_SMSU_STUB_DataRsp> Entry\n"); 
  ucHandSet = pxIpcMsg->ucPara1;
	printf("<IFX_DECT_SMSU_STUB_DataRsp> For Handset %d\n",ucHandSet); 

  ePrimitive = (pcPrimitiveMesg[0] & IFX_DECT_SMSU_LOWER_NIBBLE_MASK);

  switch(pxDataRsp->ucPrimitive){
    
    case IFX_DECT_SMSU_DATA_RSP:

        pxDataRsp= (x_IFX_DECT_SMSU_DataRspUpper*)pcPrimitiveMesg;
        pcPrimitiveMesg += sizeof(x_IFX_DECT_SMSU_DataRspUpper);
        printf("<STUB>pxDataRsp->ucMesgSize=%x:%d",pxDataRsp->ucMesgSize,pxDataRsp->ucMesgSize);
        printf("\n No Segments Present");

        switch(pxDataRsp->ucMesgBox){

          case IFX_DECT_SMSU_INBOX:

              eMesgBox = IFX_DECT_SMSU_INBOX;
              break;

         case IFX_DECT_SMSU_OUTBOX:

             eMesgBox = IFX_DECT_SMSU_OUTBOX;
             break;

        }

        switch(pxDataRsp->ucReqType){

          case IFX_DECT_SMSU_HEADERS:

              printf("\n<STUB>Printing Headers Received From Stk");
              vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucHeaderCount = *((uchar8*)pcPrimitiveMesg);
              printf("\n<STUB>ucHeaderCount:%d",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucHeaderCount);
              pcPrimitiveMesg += sizeof(uchar8);
              printf("<STUB>HeaderBlockSize :%d",pxDataRsp->ucMesgSize-2*sizeof(uchar8));

          /*for(i = 0;i < pxDataRsp->ucMesgSize-2*sizeof(uchar8);i++){
            printf("<STUB> pcPrimitiveMesg[%d]=%x:%c\n",i,pcPrimitiveMesg[i],pcPrimitiveMesg[i]);
          }*/
              memcpy(&vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xHeaderGroup.axHeaders[0],
                  pcPrimitiveMesg,/*strlen(pcPrimitiveMesg)-sizeof(uchar8)*/
              pxDataRsp->ucMesgSize-2*sizeof(uchar8));
              printf("\n<STUB> After memcpy\n");

              pcPrimitiveMesg += /*strlen(pcPrimitiveMesg)-sizeof(uchar8)*/pxDataRsp->ucMesgSize-2*sizeof(uchar8);
              vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucChecksum = *((uchar8*)pcPrimitiveMesg);
              printf("\n<STUB>ucChecksum:%d",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucChecksum);
              IFX_DECT_STUB_PrintHeaders(ucHandSet);

              break;

          case IFX_DECT_SMSU_MESG:
              printf("\n<STUB>Printing Message Received From Stk");
              memcpy(&vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper,
                  pcPrimitiveMesg,sizeof(x_IFX_DECT_SMSU_DataBlock_Upper));
              memcpy(vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.aucMesgContents,
                  pcPrimitiveMesg+sizeof(x_IFX_DECT_SMSU_DataBlock_Upper),
                  vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.ucMesgSize);
              memcpy(&vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgLower,
                  pcPrimitiveMesg+/*strlen(pcPrimitiveMesg)-sizeof(x_IFX_DECT_SMSU_DataBlock_Lower)*/
                    sizeof(x_IFX_DECT_SMSU_DataBlock_Upper)+
                   vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.ucMesgSize,
                  sizeof(x_IFX_DECT_SMSU_DataBlock_Lower));
              IFX_DECT_STUB_PrintMessage(ucHandSet);
              break;
        }//Switch endsi.
        break;
    
    default:
 
        eSegPrimitive = (pcPrimitiveMesg[0] & IFX_DECT_SMSU_LOWER_TRIPLET_MASK); 

        switch(eSegPrimitive){

          case IFX_DECT_SMSU_SEGMENT:

              printf("\n Segments Present.\n");
              pxSeg = (x_IFX_DECT_SMSU_SegmentPacketHeader*)pcPrimitiveMesg;
              pcPrimitiveMesg += sizeof(x_IFX_DECT_SMSU_SegmentPacketHeader);
              printf("\n Segment Number:%d",pxSeg->ucSeg_num);

              if(pxSeg->ucSbit = IFX_DECT_SMSU_MORE_SEGMENTS){
                
                if(pxSeg->ucSeg_num == 1){
                     
                  pxDataRsp= (x_IFX_DECT_SMSU_DataRspUpper*)pcPrimitiveMesg;
                  pcPrimitiveMesg += sizeof(x_IFX_DECT_SMSU_DataRspUpper);
                  switch(pxDataRsp->ucReqType){
 
                    case IFX_DECT_SMSU_HEADERS:

                        vxSMS_STUB_Info[ucHandSet-1].ucMesgIndex = 0;

                        memcpy(&vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucHeaderCount,
                               pcPrimitiveMesg,sizeof(uchar8));
                        pcPrimitiveMesg += sizeof(uchar8);

                        pxSeg->ucSegmentSize = pxSeg->ucSegmentSize-sizeof(uchar8)
                                               -sizeof(x_IFX_DECT_SMSU_DataRspUpper);

                        memcpy(&vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xHeaderGroup.axHeaders[0]+
                              ((pxSeg->ucSeg_num-1)*IFX_DECT_SMSU_MAX_SEG_DATALEN)/*-sizeof(uchar8)
                                -sizeof(x_IFX_DECT_SMSU_DataRspUpper)*/,
                              pcPrimitiveMesg,pxSeg->ucSegmentSize);//Check...

                        break;

                    case IFX_DECT_SMSU_MESG:

                        vxSMS_STUB_Info[ucHandSet-1].ucMesgIndex = pxDataRsp->ucMesgIndex;
                         
                        memcpy(&vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper,
                               pcPrimitiveMesg,sizeof(x_IFX_DECT_SMSU_DataBlock_Upper));
                               pcPrimitiveMesg += sizeof(x_IFX_DECT_SMSU_DataBlock_Upper);
                               pxSeg->ucSegmentSize = pxSeg->ucSegmentSize-
                                                      sizeof(x_IFX_DECT_SMSU_DataBlock_Upper)
                                                      -sizeof(x_IFX_DECT_SMSU_DataRspUpper);


                        memcpy(vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.aucMesgContents+
                               ((pxSeg->ucSeg_num-1)*IFX_DECT_SMSU_MAX_SEG_DATALEN),
                               pcPrimitiveMesg,pxSeg->ucSegmentSize);

                        break;
                  }

                }else{
              
                  if(0 == vxSMS_STUB_Info[ucHandSet-1].ucMesgIndex){
                    memcpy(&vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xHeaderGroup.axHeaders[0]+
                          (((pxSeg->ucSeg_num-1)*IFX_DECT_SMSU_MAX_SEG_DATALEN)-sizeof(uchar8)-
                           sizeof(x_IFX_DECT_SMSU_DataRspUpper)),
                           pcPrimitiveMesg,pxSeg->ucSegmentSize);//Check...
                  
                  }else{
 
                    memcpy(vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.aucMesgContents+
                          ((pxSeg->ucSeg_num-1)*IFX_DECT_SMSU_MAX_SEG_DATALEN)
                            -sizeof(x_IFX_DECT_SMSU_DataBlock_Upper)
                            -sizeof(x_IFX_DECT_SMSU_DataRspUpper),
                            pcPrimitiveMesg,pxSeg->ucSegmentSize);
                   }

                 }
                 IFX_DECT_SMSU_ComposeSegAck(pxSeg->ucSeg_num+1,0/*ucAsmStatus*/,0/*ucFailReason*/,&xSegAck);

              }else if(pxSeg->ucSbit == IFX_DECT_SMSU_LAST_SEGMENT){

                printf("\n Last Segment.\n");
                for( i = 0;i< pxSeg->ucSegmentSize; i++){
                   printf("\npcPrimitiveMesg[%d] =%c\n",i,pcPrimitiveMesg[i]);
                }
                if(0 == vxSMS_STUB_Info[ucHandSet-1].ucMesgIndex){
                  memcpy((uchar8 *)(&vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xHeaderGroup.axHeaders[0])+
                        (((pxSeg->ucSeg_num-1)*IFX_DECT_SMSU_MAX_SEG_DATALEN)-sizeof(uchar8)
                        -sizeof(x_IFX_DECT_SMSU_DataRspUpper)),
                        pcPrimitiveMesg,pxSeg->ucSegmentSize-sizeof(uchar8));//Check...

                  pcPrimitiveMesg += (pxSeg->ucSegmentSize-sizeof(uchar8));
                  memcpy(&vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xHeaderGroup.ucChecksum,
                         pcPrimitiveMesg,sizeof(uchar8));//Check..
                
                }else{

                  memcpy(vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.aucMesgContents+
                        ((pxSeg->ucSeg_num-1)*IFX_DECT_SMSU_MAX_SEG_DATALEN)
                         -sizeof(x_IFX_DECT_SMSU_DataBlock_Upper)-sizeof(x_IFX_DECT_SMSU_DataRspUpper),
                        pcPrimitiveMesg,pxSeg->ucSegmentSize-sizeof(x_IFX_DECT_SMSU_DataBlock_Lower));

                  pcPrimitiveMesg += pxSeg->ucSegmentSize-sizeof(x_IFX_DECT_SMSU_DataBlock_Lower);

                  memcpy(&vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgLower,
                         pcPrimitiveMesg,
                         sizeof(x_IFX_DECT_SMSU_DataBlock_Lower));

                 } 
                IFX_DECT_SMSU_ComposeSegAck(0,0/*ucAsmStatus*/,0/*ucFailReason*/,&xSegAck);

               }
							if(0 == vxSMS_STUB_Info[ucHandSet-1].ucMesgIndex){

                 IFX_DECT_STUB_PrintHeaders(ucHandSet);

               }else{

                 IFX_DECT_STUB_PrintMessage(ucHandSet);
               }
               memcpy(vxSMS_STUB_Info[ucHandSet-1].acBuff,&xSegAck,sizeof(x_IFX_DECT_SMSU_SegAck));

               iReplyLen = sizeof(x_IFX_DECT_SMSU_SegAck);
  
               EncodeIWU_SMS(vxSMS_STUB_Info[ucHandSet-1].acBuff,iReplyLen,xIpcReply.acData);
               IFX_DECT_STUB_EncodeCCInfo(ucHandSet,vxSMS_STUB_Info[ucHandSet-1].ucInstance,
                                      0/*ucSignal*/,&xIpcReply);
               return IFX_DECT_SMSU_ProcessStackMsg(&xIpcReply);

              break;

          default:

              return IFX_FAILURE;
        }
        break;
  }
  return IFX_SUCCESS;
}


e_IFX_Return IFX_DECT_SMSU_STUB_DelRsp(IN char8 *pcPrimitiveMesg, IN int32 iPrimitiveLen,
                                     IN x_IFX_DECT_IPC_Msg *pxIpcMsg){

  x_IFX_DECT_SMSU_DeleteRsp *pxDelRsp = NULL; 
  
  pxDelRsp = (x_IFX_DECT_SMSU_DeleteRsp*)pcPrimitiveMesg;
  printf("\n Deletion Status:%d",pxDelRsp->ucDeleteDeliverStatus);

  switch(pxDelRsp->ucDeleteDeliverStatus){

    case IFX_DECT_SMSU_SUCCESS:
        printf("\n Message(s) deleted successfully.\n"); 
        break;

    case IFX_DECT_SMSU_FAILURE:
       
        printf("\n Deletion of message(s) failed.\n");
        printf("\n Reason for Failure:%d",pxDelRsp->ucFailureReasonCode);
        break;

	}

  return IFX_SUCCESS;
}


e_IFX_Return IFX_DECT_SMSU_STUB_SendRsp(IN char8 *pcPrimitiveMesg, IN int32 iPrimitiveLen,
                                     IN x_IFX_DECT_IPC_Msg *pxIpcMsg){
  
  
  uchar8 ucSegSize = 0;
  uchar8 ucHandSet = 0;
  uchar8 ucSbit = 0;
  uchar8 acData[300] = "";
  int32 iReplyLen = 0;
  x_IFX_DECT_SMSU_SendRsp *pxSendRsp = NULL;
  x_IFX_DECT_SMSU_SegAck *pxSegAck = NULL;
  x_IFX_DECT_SMSU_SegmentPacketHeader xSeg = {0};
  x_IFX_DECT_SMSU_SendReqUpper xSendReq = {0};
  x_IFX_DECT_IPC_Msg xIpcReply = {0};

  ucHandSet = pxIpcMsg->ucPara1;

  e_IFX_DECT_SMSU_Primitive ePrimitive;
  e_IFX_DECT_SMSU_SegPrimitive eSegPrimitive;

  ePrimitive = (pcPrimitiveMesg[0] & IFX_DECT_SMSU_LOWER_NIBBLE_MASK);
 
  switch(ePrimitive){

    case IFX_DECT_SMSU_SEND_RSP:

        pxSendRsp = (x_IFX_DECT_SMSU_SendRsp*)pcPrimitiveMesg;

        printf("\n Status of Sent Message:%d",pxSendRsp->ucDeleteDeliverStatus);

        switch(pxSendRsp->ucDeleteDeliverStatus){

          case 1:
		  
	      printf("\n Message sent successfully.\n");	  
              break;

	  case 2:
	      
	      printf("\n Sending of message failed.\n");
              printf("\n Reason for Failure:%d",pxSendRsp->ucFailureReasonCode);
              /*Release Resources*/
              return IFX_FAILURE;
              break;

	  default: 
	    
	      return IFX_FAILURE;    
        }
    default:

        eSegPrimitive = (pcPrimitiveMesg[0] & IFX_DECT_SMSU_LOWER_TRIPLET_MASK);
        
        switch(eSegPrimitive){

          case IFX_DECT_SMSU_SEG_ACK:

              pxSegAck = (x_IFX_DECT_SMSU_SegAck*)pcPrimitiveMesg;
              pcPrimitiveMesg += sizeof(x_IFX_DECT_SMSU_SegAck);
              
	      if(pxSegAck->ucReqSegNo == 2){/* or iPrimitiveLen ==3)*/
		      
	        pxSendRsp = (x_IFX_DECT_SMSU_SendRsp*)pcPrimitiveMesg;
	        pcPrimitiveMesg += sizeof(x_IFX_DECT_SMSU_SendRsp);

		printf("\n Status of Sent Message:%d",pxSendRsp->ucDeleteDeliverStatus);

		switch(pxSendRsp->ucDeleteDeliverStatus){

	          case 1:

		      printf("\n Message sent successfully.\n");	  

	              break;

                  case 2:

		      printf("\n Sending of message failed.\n");
                      printf("\n Reason for Failure:%d",pxSendRsp->ucFailureReasonCode);
                      /*Release Resources*/
                      return IFX_FAILURE;
                      break;
 
		  default: return IFX_FAILURE;		      
                }		      

	      }else{

		if(pxSegAck->ucReqSegNo == 0){
                  return IFX_SUCCESS;
                }

	       }	     
	       if(pxSegAck->ucAsmStatus == 0){
              
                 ucSegSize =
                  (( vxSMS_STUB_Info[ucHandSet-1].ucBufLen - ((pxSegAck->ucReqSegNo-1)*IFX_DECT_SMSU_MAX_SEG_DATALEN))
                   >= IFX_DECT_SMSU_MAX_SEG_DATALEN) ? IFX_DECT_SMSU_MAX_SEG_DATALEN :
                   ( vxSMS_STUB_Info[ucHandSet-1].ucBufLen - ((pxSegAck->ucReqSegNo-1)*IFX_DECT_SMSU_MAX_SEG_DATALEN));
                 printf("\n <STUB>vxSMSInfo[ucHandSet-1].ucBufLen:%d\n",vxSMS_STUB_Info[ucHandSet-1].ucBufLen);
                 printf("\n<STUB> Segment Size:%d\n",ucSegSize); 
                 if(ucSegSize > IFX_DECT_SMSU_MAX_SEG_DATALEN){

                   ucSbit = IFX_DECT_SMSU_MORE_SEGMENTS;
                 }else{
                   ucSbit = IFX_DECT_SMSU_LAST_SEGMENT;
                  }
                 IFX_DECT_SMSU_ComposeSeg(ucSbit,pxSegAck->ucReqSegNo/*Seg_num*/,ucSegSize,&xSeg);
                 printf("\n ucSbit:%d\n",ucSbit);
              
                 printf("\n ucReqSegNo:%d\n",pxSegAck->ucReqSegNo);
		 
               }else if(pxSegAck->ucAsmStatus == 1){
                 return IFX_SUCCESS;//Need to check this??
                }else{
                  return IFX_FAILURE;
                 } 
	       IFX_DECT_SMSU_memcat(2,acData,&iReplyLen,
                                  &xSeg,sizeof(x_IFX_DECT_SMSU_SegmentPacketHeader),
                                  vxSMS_STUB_Info[ucHandSet-1].acBuff+
                                  ((pxSegAck->ucReqSegNo-1)*IFX_DECT_SMSU_MAX_SEG_DATALEN)
				  -sizeof(x_IFX_DECT_SMSU_SendReqUpper),
                                  xSeg.ucSegmentSize);
               *(acData+iReplyLen)='\0';
	       
               EncodeIWU_SMS(acData,iReplyLen,xIpcReply.acData);
               IFX_DECT_STUB_EncodeCCInfo(ucHandSet,vxSMS_STUB_Info[ucHandSet-1].ucInstance,
                                          0/*ucSignal*/,&xIpcReply);
               return IFX_DECT_SMSU_ProcessStackMsg(&xIpcReply);
               break;
   
          default:
           
              return IFX_FAILURE;

        }
        break:

  } 

}


e_IFX_Return IFX_DECT_STUB_ComposeMesg(OUT x_IFX_DECT_SMSU_Mesg *pxMesg){

  int32 i = 0;
  int16 iToFromNumber = 0;
  //int32 iYear = 0;
#if 0
  printf("\n\n Compose Message Block.\n\n");
  printf("\n Enter the Size of Destination Number(2 octets):");
  scanf("%u",&pxMesg->ucToFromNumberSize);
  printf("\n Enter the Destination Number:");
  scanf("%x",&iToFromNumber);//No check for overflow/size.
  memcpy(pxMesg->aucToFromNumber,&iToFromNumber,sizeof(pxMesg->aucToFromNumber)); 
  printf("\n Enter the size of the Message:");
  scanf("%u",&pxMesg->ucMesgSize);
  printf("\n Enter the Message Contents:\n");
  scanf("%s",pxMesg->acMesgContents);
  /*printf("\n Enter the Timestamp Information:\n");
  printf("\n Enter the year:");
  scanf("%d",&pxMesg->xMesgTimeStamp.ucYear);
  printf("\n Enter the Month:");
  scanf("%d",&pxMesg->xMesgTimeStamp.ucMonth);
  printf("\n Enter the Day:");
  scanf("%d",&pxMesg->xMesgTimeStamp.ucDay);
  printf("\n Enter the Hour:");
  scanf("%d",&pxMesg->xMesgTimeStamp.ucHour);
  printf("\n Enter the Minutes:");
  scanf("%d",&pxMesg->xMesgTimeStamp.ucMinute);
  printf("\n Enter the Seconds:");
  scanf("%d",&pxMesg->xMesgTimeStamp.ucSecond);
  printf("\n Enter the Time Zone:");
  scanf("%d",pxMesg->xMesgTimeStamp.ucTimeZone);*/
  IFX_DECT_SMSU_GetTimeStamp(&pxMesg->xMesgTimeStamp); //Check this. 
  printf("\n Enter the Extension Number:");
  scanf("%u",&pxMesg->ucExtnNumber);
  printf("\n Enter the Checksum:");
  scanf("%u",&pxMesg->ucChecksum);
# endif
 pxMesg->ucToFromNumberSize = 2;
 pxMesg->aucToFromNumber[0] = 0x12;
 pxMesg->aucToFromNumber[1] = 0x34;
 //strcpy(pxMesg->acMesgContents,"Hello,How r u?All of u are cordially invited.");
 strcpy(pxMesg->acMesgContents,"Hello,How r u?This is last test for SMSU module at Infineon India Pvt. Ltd.Have a nice day...All's well that ends well..Lets celebrate at CCD at ITPL Bangalore.All of u are cordially invited.");
 pxMesg->ucMesgSize = strlen(pxMesg->acMesgContents);
 IFX_DECT_SMSU_GetTimeStamp(&pxMesg->xMesgTimeStamp);
 pxMesg->ucExtnNumber = 2;
 pxMesg->ucChecksum = 0;

  return IFX_SUCCESS;

}


int IFX_DECT_SMSU_Main(){

  int32 iChoice = 0;
	int32 i=0;
  int32 iReq = 0;
  uchar8 ucReq = 0;
  int32 iBox = 0;
  uchar8 ucBox = 0;
  int32 iMesgIndex = 0;
  uchar8 ucMesgIndex = 0;
  uchar8 ucInstance = 0;
  uchar8 ucHandSet = 0;
  int32 iReplyLen = 0;
  uchar8 acData[300];
  uchar8 acMesg[IFX_DECT_SMSU_MAX_MESG][IFX_DECT_SMSU_MAX_MESG_DATALEN];
  x_IFX_DECT_IPC_Msg xIpcMsg = {0};
  x_IFX_DECT_SMSU_Mesg xMesg = {0};
  x_IFX_DECT_SMSU_DataReq xDataReq = {0};
  x_IFX_DECT_SMSU_DeleteReq xDelReq = {0};
  x_IFX_DECT_SMSU_SendReqUpper xSendReq = {0};
  x_IFX_DECT_SMSU_SegmentPacketHeader xSeg = {0};
  e_IFX_DECT_SMSU_MesgBox eMesgBox;
  e_IFX_DECT_SMSU_DataType eDataType;
  e_IFX_DECT_SMSU_DeleteReqType eReqType;
  
  while(1){	
  
  	x_IFX_DECT_IPC_Msg xIpcMsg = {0};
    IFX_DECT_STUB_ResetAllHandsets();
    printf("\n\t\t**************************MAIN MENU**************************\n");
    printf("\n\t1.Read Header//Message\n");
    printf("\n\t2.Delete Message\n");
    printf("\n\t3.Compose Message\n");
    printf("\n\t4.Exit\n");
    printf("\n Enter your choice(1-4):");
    scanf("%d",&iChoice);

    ucHandSet = IFX_DECT_STUB_GetFreeHandSetNo();
    if((char8)ucHandSet != IFX_FAILURE){
			 printf("Free Handset No is %d\n",ucHandSet);
    }else{
      printf("\n Free HandSet Number not available.\n");
      exit(1);
     }

    ucInstance = IFX_DECT_STUB_GetFreeInstanceNo();
    if((char8)ucInstance != IFX_FAILURE){
      printf("Free Instance No is %d\n",ucInstance);

    }else{
      printf("\n Free Instance Number not available.\n");
      exit(1);
     }
   
    IFX_DECT_SMSU_STUB_ComposeIpcMessage(FP_INFO_IN_CC,ucHandSet,ucInstance,&xIpcMsg);

    switch(iChoice){

      case 1://Fetch Message/Headers  
          
	        printf("\n Enter the Request Type(Headers-1,Message-2):");
	        scanf("%d",&iReq);
					printf("Request Type you choose is %d\n",iReq);
	  
	        switch(iReq){

            case IFX_DECT_SMSU_HEADERS:

		            eDataType = IFX_DECT_SMSU_HEADERS;
                iMesgIndex = 0;
	              break;

	          case IFX_DECT_SMSU_MESG:

		            eDataType = IFX_DECT_SMSU_MESG;
		            printf("\nEnter the Message Index(0-19):");
		            scanf("%d",&iMesgIndex);
								printf("Msg Index that you choose %d\n",iMesgIndex);
		            break;

            default:
              
                printf("\n You Entered wrong choice.Headers-1,Message-2");
                exit(1);		
          }	

          printf("\n Enter the Message Box Type(Inbox-1,Outbox-2):");
          scanf("%d",&iBox);

          switch(iBox){

            case IFX_DECT_SMSU_INBOX:

                eMesgBox = IFX_DECT_SMSU_INBOX;
                break;

            case IFX_DECT_SMSU_OUTBOX:

                eMesgBox = IFX_DECT_SMSU_OUTBOX;
                break;	

	    default:
	 
	        printf("You entered wrong choice.Inbox-1,Outbox-2.");
	        exit(1);	
          }		

          IFX_DECT_SMSU_STUB_ComposeDataReq(eDataType,eMesgBox,iMesgIndex,&xDataReq);
          printf("\n<STUB>MesgIndex=%d",xDataReq.ucMesgIndex); 
          EncodeIWU_SMS((char8*)&xDataReq,sizeof(x_IFX_DECT_SMSU_DataReq),&xIpcMsg.acData);
	  	  
          break;
  
      case 2://Delete Message

          printf("\n Enter the Message Box Type(Inbox-1,Outbox-2):");
          scanf("%d",&iBox);
        
          switch(iBox){

            case IFX_DECT_SMSU_INBOX:

                eMesgBox = IFX_DECT_SMSU_INBOX;
                break;

            case IFX_DECT_SMSU_OUTBOX:

                eMesgBox = IFX_DECT_SMSU_OUTBOX;
                break;

            default:

                printf("You entered wrong choice.Inbox-1,Outbox-2.");
                exit(1);
          }
     
          printf("\n Enter the Request Type(Single-1,All-2):");
          scanf("%d",&iReq);
          
          switch(iReq){

            case IFX_DECT_SMSU_SINGLE:

                eReqType = IFX_DECT_SMSU_SINGLE;
                printf("\nEnter the Message Index(0-19):");
                scanf("%d",&iMesgIndex);
                break;

            case IFX_DECT_SMSU_ALL:

                eReqType = IFX_DECT_SMSU_ALL;
                break;

            default:

                printf("You entered wrong choice.Single-1,All-2.");
                exit(1);
          }
          
          IFX_DECT_SMSU_STUB_ComposeDelReq(eReqType,eMesgBox,iMesgIndex,&xDelReq);
          EncodeIWU_SMS((char8*)&xDelReq,sizeof(x_IFX_DECT_SMSU_DeleteReq),xIpcMsg.acData);

          break;

      case 3://Composing a Message.

          printf("\n Compose Message(Short-1(<=113 bytes),Bulk-2(>113 and <160)):");
          scanf("%d",&iMesgIndex);

          if(IFX_DECT_STUB_ComposeMesg(&xMesg) == IFX_SUCCESS){
            printf("\n <STUB>Message Composed.\n");
          }
          //IFX_DECT_STUB_PrintMessage(ucHandSet);         
          memcpy(&vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock,&xMesg,sizeof(x_IFX_DECT_SMSU_Mesg));//Check??
          printf("\n <STUB>Mesg Contents:%s\n",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.aucMesgContents);
          #if 0
          memcpy(&vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper,
                       &xMesg,sizeof(x_IFX_DECT_SMSU_DataBlock_Upper));
          printf("<STUB>Number Size:%d",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.ucToFromNumberSize);
					printf("1\n");
          memcpy(vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.aucMesgContents,
                       (&xMesg)+sizeof(x_IFX_DECT_SMSU_DataBlock_Upper),
                        vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.ucMesgSize);
          printf("<STUB>Message Size:%d",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.ucMesgSize);
          
          printf("<STUB>Message:%s",vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.aucMesgContents);
					printf("2\n");

          memcpy(&vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgLower,
                       ((&xMesg)+sizeof(x_IFX_DECT_SMSU_DataBlock_Upper)+
                         vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.ucMesgSize)
                        /*sizeof(x_IFX_DECT_SMSU_Mesg)-sizeof(x_IFX_DECT_SMSU_DataBlock_Lower)*/
                        ,sizeof(x_IFX_DECT_SMSU_DataBlock_Lower));

					printf("3\n");
          #endif
          vxSMS_STUB_Info[ucHandSet-1].ucBufLen = sizeof(x_IFX_DECT_SMSU_DataBlock_Upper)+
                        sizeof(x_IFX_DECT_SMSU_DataBlock_Lower)+
                        vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.ucMesgSize+
                        sizeof(x_IFX_DECT_SMSU_SendReqUpper);
          printf("ucMesgBlkSize:%d",vxSMS_STUB_Info[ucHandSet-1].ucBufLen);
          IFX_DECT_STUB_PrintMessage(ucHandSet);
             
          switch(iMesgIndex){
 
            case 1:
                 //CASE 1:NO SEGMENTS.
                printf("\n <STUB>Short Mesg.No Segments.\n");
                IFX_DECT_STUB_ComposeSendReq(vxSMS_STUB_Info[ucHandSet-1].ucBufLen
                                             -sizeof(x_IFX_DECT_SMSU_SendReqUpper),
                                             &xSendReq);
                printf("\n <STUB>Send Req Compose.\n");
                IFX_DECT_SMSU_memcat(2,vxSMS_STUB_Info[ucHandSet-1].acBuff,&iReplyLen,
                          &xSendReq,sizeof(x_IFX_DECT_SMSU_SendReqUpper),
                          &xMesg,sizeof(x_IFX_DECT_SMSU_Mesg));

                *(vxSMS_STUB_Info[ucHandSet-1].acBuff + iReplyLen) = '\0';
                EncodeIWU_SMS(vxSMS_STUB_Info[ucHandSet-1].acBuff,iReplyLen,xIpcMsg.acData);
                printf("\n<STUB> Request Encoded.\n");
                break;

            case 2:
                 //CASE 2:SEGMENT THE MESSAGE.SEND 1st SEGMENT.
                IFX_DECT_SMSU_ComposeSeg(IFX_DECT_SMSU_MORE_SEGMENTS/*Sbit*/,1/*Seg_num*/,
                                         IFX_DECT_SMSU_MAX_SEG_DATALEN,&xSeg);
                IFX_DECT_STUB_ComposeSendReq(vxSMS_STUB_Info[ucHandSet-1].ucBufLen
                                             -sizeof(x_IFX_DECT_SMSU_SendReqUpper),
                                             &xSendReq);

                IFX_DECT_SMSU_memcat(4,vxSMS_STUB_Info[ucHandSet-1].acBuff,&iReplyLen,
                          &xSendReq,sizeof(x_IFX_DECT_SMSU_SendReqUpper),
                          &vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper,
                          sizeof(x_IFX_DECT_SMSU_DataBlock_Upper),
                          vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.aucMesgContents,
                          vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgUpper.ucMesgSize,
                             &vxSMS_STUB_Info[ucHandSet-1].uxSMS_Data.xMesgBlock.xMesgLower,
                         sizeof(x_IFX_DECT_SMSU_DataBlock_Lower)); 
                *(vxSMS_STUB_Info[ucHandSet-1].acBuff + iReplyLen) = '\0';
                iReplyLen = 0;
                IFX_DECT_SMSU_memcat(2,acData,&iReplyLen,
                                     &xSeg,sizeof(x_IFX_DECT_SMSU_SegmentPacketHeader),
                                     vxSMS_STUB_Info[ucHandSet-1].acBuff,IFX_DECT_SMSU_MAX_SEG_DATALEN);  
                *(acData + iReplyLen) = '\0';
                EncodeIWU_SMS(acData,iReplyLen,xIpcMsg.acData);
                break;
              
          }
      	  break;

      case 4:
         
          printf("\nYou chose to exit.\n"); 
          exit(0);
          break;	  

      default:
        
          printf("\nYou entered wrong choice.You had to enter between 1-4.\n");
          exit(1);
	  
    }//Switch ends       	  

#if 0
		for(i=0;i<9;i++) {
			printf("%d Data is %x\n",i,xIpcMsg.acData[i]);
		}

		xIpcMsg.acData[0] = 0x77;
		xIpcMsg.acData[1] = 0x07;
		xIpcMsg.acData[2] = 0xC0;
		xIpcMsg.acData[3] = 0x81;
		xIpcMsg.acData[4] = 0xC0;
		xIpcMsg.acData[5] = 0x00;
		xIpcMsg.acData[6] = 0x01;
		xIpcMsg.acData[7] = 0x51; //0x91;
		xIpcMsg.acData[8] = 0x02;

		

#endif
		for(i=10;i<19;i++) {
			printf("<STUB>%d Data is %x\n",i,xIpcMsg.acData[i]);
		}
    if(IFX_DECT_SMSU_ProcessStackMsg(&xIpcMsg) == IFX_FAILURE){
       printf("\n Error Processing Stack Message.");
			 sleep(2);
       //exit(1);
    }
	}    
  //return 0;
} 
