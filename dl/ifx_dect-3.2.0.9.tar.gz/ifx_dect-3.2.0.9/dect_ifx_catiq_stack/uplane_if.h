/*
***********************************************************************************
*                                                                                 *
*     Project    :  PRODECT - DECT Home System Protocol Software V9.0             *
*                   (c) 2008 IFX / PEUCON. All rights reserved.                   *
*                                                                                 *
***********************************************************************************
*                                                                                 *
*     Workfile   :  uplane_if.h                                                   *
*     Date       :  16 Sep, 2008                                                  *
*     Contents   :  Defines interface between DECT Stack an DECT Uplane Agent     *
*     Hardware   :                                                                *
*                                                                                 *
***********************************************************************************
*/
#ifndef _INC_UPLANE_IF
#define _INC_UPLANE_IF
#include "IFX_DECT_MsgRouter.h"
//#define FIFO_MAX_LU10_SDU	  IFX_IPC_DECT_MAX_DATA_SIZE       // maximum SDU size
//#define FIFO_MAX_LU10_SDU	  513       // maximum SDU size
#define FIFO_MAX_LU10_SDU	  124       // maximum SDU size

typedef x_IFX_DECT_IPC_Msg_u  x_IPC_UPlane_Msg;
   /* ============================                                         */
   /* Global function decalaration                                         */
   /* ============================                                         */

// Fifo -> Stack
int Serve_UPMessage_Stack(x_IPC_UPlane_Msg *result);

// Stack ->App
int Send_UPMessage_To_APP( unsigned  char msg, const unsigned char *ptr, unsigned  char inc,
                           unsigned  char parameter1,  unsigned  char parameter2,  unsigned  char parameter3,  unsigned  char parameter4 );

//int Send_Flow_Info_to_Agent(unsigned char freeBufs,unsigned long maxSDU);
#define Send_Flow_Info_to_Agent(freeBufs,maxSDU)\
   Send_UPMessage_To_APP(FP_MEDIA_SDU_FLOW_IN,NULL,0,freeBufs,(unsigned char)( maxSDU>>8),(unsigned char)maxSDU,0,0)

#endif                                 /* endif of #ifndef _INC_UPLANE_IF */

