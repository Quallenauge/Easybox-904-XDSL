On Windows open this file in WordPad.

Contents of the "windll/csharp" sub-archive

This directory contains a Visual C Sharp (C#) sample project for
using the zip32.dll library.  The zip and unzip projects were generously
donated by Adrian Maull.  The unzip project should be added to the next
unzip release.

The projects are based on .NET Framework 1.1.  They were contributed
to the Info-Zip project April 2005.  If you have questions or comments,
contact us at www.Info-ZIP.org or for specific questions about these
projects contact Adrian Maull directly at adrian.maull@sprintpcs.com.

See UnZip.cs and Zip.cs for information about each project.  Currently
the sample projects have some bugs as noted in the above files and
are only designed for Zip 2.3x and UnZip 5.5x.  We are looking to
port the projects to Zip 3 and UnZip 6.  These projects are mostly
untested by us at this time.

These sample projects are distributed as part of the Info-ZIP distribution
under the Info-ZIP license.

Note that the files may saved in unix format with carriage returns
stripped.  These may need to be restored before the project can be successfully
used.

Ed Gordon
7/18/2005
